﻿window.indicesController = (function() {
  function indicesController() {}

  indicesController.configurarVoltar = function() {
    return window.VoltarERecarregar = function() {
      return $as.Onegreen.Indices.Index.post().success(function(data) {
        return $('#main').html(data);
      });
    };
  };

  return indicesController;

})();
