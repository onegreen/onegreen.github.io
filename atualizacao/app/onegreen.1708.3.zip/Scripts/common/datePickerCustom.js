﻿var DatePickerCustom;

this.datePickerCustom || (this.datePickerCustom = {});

DatePickerCustom = (function() {
  function DatePickerCustom() {}

  DatePickerCustom.daysOfWeekDisabled;

  DatePickerCustom.setDatePickerCustom = function(idElementToClick, idElemetToClickContainer, idElementToValue, onChangeFunction, initialDate, startDate, endDate, showWeeks, minViewMode) {
    var datePickerContainer, elementHidden, elementToClick, elementToClickContainer, idDatePickerContainer, modal, picker;
    elementToClickContainer = $("#" + idElemetToClickContainer);
    elementToClick = $("#" + idElementToClick, elementToClickContainer);
    elementHidden = $("#" + idElementToValue, elementToClickContainer);
    datePickerContainer = idElementToClick + 'date-picker-container';
    idDatePickerContainer = "#" + datePickerContainer;
    if ($(idDatePickerContainer, elementToClickContainer).length === 0) {
      elementToClickContainer.append("<div id='" + datePickerContainer + "' class='modal-smart-data'></div>");
    }
    if ($('.modal-smart-picker', $(idDatePickerContainer)).is(":visible")) {
      $('.container-modal-smart-picker').remove();
      return $('.modal-smart-picker').remove();
    } else {
      $('.container-modal-smart-picker').remove();
      $('.modal-smart-picker').remove();
      $('body').append("<div id='container-modal-smart-picker' class='container-modal-smart-picker'> <div class='modal-smart bottom modal-smart-picker' style='z-index:9999; width:250px; display:none' id='modal-smart-picker'> <img src='" + CompleteHostAdress + "/Content/img/smartControls-up.png' class='seta-up' /> <div class='pam'> <div class='date' id='date-smart-picker'> </div> </div> </div> </div>");
      modal = '#modal-smart-picker';
      picker = '#date-smart-picker';
      showWeeks = showWeeks === void 0 ? false : showWeeks;
      $(idDatePickerContainer).empty().html($(modal));
      $(modal).show();
      $(picker).attr('data-date', initialDate);
      $(picker).empty();
      $(picker, $(modal)).datepicker({
        autoclose: true,
        calendarWeeks: showWeeks,
        minViewMode: minViewMode ? minViewMode : void 0,
        daysOfWeekDisabled: showWeeks ? "1,2,3,4,5,6" : ''
      });
      if (startDate) {
        $(picker, $(modal)).datepicker('setStartDate', startDate);
      }
      if (endDate) {
        $(picker, $(modal)).datepicker('setEndDate', endDate);
      }
      return $(picker, $(modal)).on("changeDate", function(e) {
        return setTimeout((function() {
          elementHidden.val($(picker, $(modal)).data('datepicker').getFormattedDate());
          onChangeFunction();
          $(modal).hide();
          $('#container-modal-smart-picker').empty().html($(modal));
          $(datePickerContainer).empty();
          $('.container-modal-smart-picker').remove();
          return $('.modal-smart-picker').remove();
        }), 0);
      });
    }
  };

  return DatePickerCustom;

})();
