﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.createEditGraficoDeIndicadorController = (function() {
  function createEditGraficoDeIndicadorController(view, options, resources) {
    this.view = view;
    this.options = options;
    this.resources = resources;
    this.configurarDatePickerFarolMensal = bind(this.configurarDatePickerFarolMensal, this);
    this.configurarDatePickerFarolSemana = bind(this.configurarDatePickerFarolSemana, this);
    this.configurarDatePickerFarolDiario = bind(this.configurarDatePickerFarolDiario, this);
    this.configurarDatepicker = bind(this.configurarDatepicker, this);
    this.desabilitarOcorrencia = bind(this.desabilitarOcorrencia, this);
    this.desabilitarFrequencias = bind(this.desabilitarFrequencias, this);
    this.desabilitarComboModelos = bind(this.desabilitarComboModelos, this);
    this.desabilitarComboIndicador = bind(this.desabilitarComboIndicador, this);
    this.desabilitarComboUnidades = bind(this.desabilitarComboUnidades, this);
    this.desabilitarCampos = bind(this.desabilitarCampos, this);
    this.carregarModelos = bind(this.carregarModelos, this);
    this.carregarComutadorDeFrequencias = bind(this.carregarComutadorDeFrequencias, this);
    this.bindFrequencia = bind(this.bindFrequencia, this);
    this.carregarComboDeIndicadores = bind(this.carregarComboDeIndicadores, this);
    this.carregarComboDeUnidades = bind(this.carregarComboDeUnidades, this);
    this.carregarComboDeUnidades();
    this.carregarComboDeIndicadores();
    this.bindFrequencia($('[name="Frequencia"]:enabled', this.view));
    if (this.options.edicao) {
      this.carregarModelos();
      this.configurarDatepicker();
    } else {
      this.desabilitarCampos();
    }
    $(this.view).window();
  }

  createEditGraficoDeIndicadorController.prototype.carregarComboDeUnidades = function() {
    var onSelectUnidade;
    onSelectUnidade = (function(_this) {
      return function() {
        _this.desabilitarComboIndicador();
        _this.desabilitarFrequencias();
        _this.desabilitarOcorrencia(true);
        return _this.desabilitarComboModelos();
      };
    })(this);
    return setCombo(this.view, "#SiglaDaUnidade", onSelectUnidade);
  };

  createEditGraficoDeIndicadorController.prototype.carregarComboDeIndicadores = function() {
    var onSelectIndicador, parameters;
    onSelectIndicador = (function(_this) {
      return function() {
        _this.desabilitarFrequencias();
        _this.desabilitarOcorrencia(true);
        _this.carregarComutadorDeFrequencias();
        return _this.desabilitarComboModelos();
      };
    })(this);
    parameters = {
      idUnidadeGerencial: (function(_this) {
        return function() {
          return $('#IdDaUnidade', _this.view).val();
        };
      })(this)
    };
    return Results.api.setComboIndicador(this.view, "#NomeDoIndicador", onSelectIndicador, parameters);
  };

  createEditGraficoDeIndicadorController.prototype.bindFrequencia = function(seletor) {
    return $(seletor, this.view).removeAttr('disabled').change((function(_this) {
      return function() {
        _this.carregarModelos();
        _this.desabilitarOcorrencia(false);
        return _this.configurarDatepicker();
      };
    })(this));
  };

  createEditGraficoDeIndicadorController.prototype.carregarComutadorDeFrequencias = function() {
    return $as.Performance.Indicadores.ObterFrequenciasAplicaveis.get({
      idDoIndicador: $('#IdDoIndicador', this.view).val()
    }).done((function(_this) {
      return function(frequencia) {
        if (frequencia.EDiario) {
          $('#EDiario', _this.view).val('true');
          _this.bindFrequencia('#Frequencia-Diaria');
        }
        if (frequencia.ESemanal) {
          $('#ESemanal', _this.view).val('true');
          _this.bindFrequencia('#Frequencia-Semanal');
        }
        if (frequencia.EMensal) {
          $('#EMensal', _this.view).val('true');
          return _this.bindFrequencia('#Frequencia-Mensal');
        }
      };
    })(this));
  };

  createEditGraficoDeIndicadorController.prototype.carregarModelos = function() {
    var parameters;
    if ($("#IdDoIndicador", this.view).val() !== '' && $('[name=Frequencia]:checked', this.view).val()) {
      $("#NomeDoModelo-Combo-As-DropdownBtn").removeAttr('disabled');
      $("#NomeDoModelo-Combo-As-Dropdown").removeAttr('disabled');
      parameters = {
        idDoIndicador: (function(_this) {
          return function() {
            return $('#IdDoIndicador', _this.view).val();
          };
        })(this),
        frequencia: (function(_this) {
          return function() {
            return $('[name=Frequencia]:checked', _this.view).val();
          };
        })(this)
      };
      setComboAsDropdown(this.view, "#NomeDoModelo", parameters);
    } else {
      this.desabilitarComboModelos();
    }
  };

  createEditGraficoDeIndicadorController.prototype.desabilitarCampos = function() {
    this.desabilitarComboIndicador();
    this.desabilitarComboUnidades();
    this.desabilitarFrequencias();
    this.desabilitarOcorrencia(true);
    return this.desabilitarComboModelos();
  };

  createEditGraficoDeIndicadorController.prototype.desabilitarComboUnidades = function() {
    $("#SiglaDaUnidade", this.view).val('');
    $("#IdDaUnidade", this.view).val('');
    return $("#SiglaDaUnidade", this.view).data('autocompleter');
  };

  createEditGraficoDeIndicadorController.prototype.desabilitarComboIndicador = function() {
    var bloquear, id;
    id = $('#IdDaUnidade', this.view).val();
    bloquear = id === '';
    $("#NomeDoIndicador", this.view).val('');
    $("#IdDoIndicador", this.view).val('');
    return $("#NomeDoIndicador", this.view).data('autocompleter').disableElseEnable(bloquear);
  };

  createEditGraficoDeIndicadorController.prototype.desabilitarComboModelos = function() {
    $("#NomeDoModelo-Combo-As-DropdownBtn").attr('disabled', 'disabled');
    $("#NomeDoModelo-Combo-As-Dropdown").attr('disabled', 'disabled');
    $("#NomeDoModelo-Combo-As-Dropdown").html(this.resources.Selecione);
    $('#IdDoModelo', this.view).val('');
    return $('#NomeDoModelo', this.view).val('');
  };

  createEditGraficoDeIndicadorController.prototype.desabilitarFrequencias = function() {
    var bloquear, id;
    id = $('#IdDoIndicador', this.view).val();
    bloquear = id === '';
    $('#Frequencia-Diaria', this.view).attr('disabled', 'disabled').removeAttr('checked').unbind();
    $('#Frequencia-Semanal', this.view).attr('disabled', 'disabled').removeAttr('checked').unbind();
    $('#Frequencia-Mensal', this.view).attr('disabled', 'disabled').removeAttr('checked').unbind();
    return dataToggle.activateBtnToggle();
  };

  createEditGraficoDeIndicadorController.prototype.desabilitarOcorrencia = function(bloquear) {
    var $ocorrencia;
    $ocorrencia = $("#Ocorrencia", this.view);
    $ocorrencia.val('');
    if ($ocorrencia.datepicker) {
      $ocorrencia.datepicker('remove');
    }
    if (bloquear) {
      return $ocorrencia.attr('disabled', 'disabled');
    }
  };

  createEditGraficoDeIndicadorController.prototype.configurarDatepicker = function() {
    var frequencia;
    frequencia = $('[name=Frequencia]:checked', this.view).val();
    $("#Ocorrencia", this.view).removeAttr('disabled');
    if (frequencia === 'Diaria') {
      return this.configurarDatePickerFarolDiario();
    } else if (frequencia === 'Mensal') {
      return this.configurarDatePickerFarolMensal();
    } else {
      return this.configurarDatePickerFarolSemana();
    }
  };

  createEditGraficoDeIndicadorController.prototype.configurarDatePickerFarolDiario = function(idInput) {
    return $("#Ocorrencia", this.view).datepicker({
      orientation: "top auto",
      autoclose: true,
      forceParse: true,
      startDate: this.options.startDate,
      endDate: this.options.endDate,
      calendarWeeks: false
    });
  };

  createEditGraficoDeIndicadorController.prototype.configurarDatePickerFarolSemana = function(idInput) {
    return $("#Ocorrencia", this.view).datepicker({
      orientation: "top auto",
      autoclose: true,
      forceParse: true,
      startDate: this.options.startDate,
      endDate: this.options.endDate,
      calendarWeeks: true,
      daysOfWeekDisabled: "1,2,3,4,5,6"
    });
  };

  createEditGraficoDeIndicadorController.prototype.configurarDatePickerFarolMensal = function(idInput) {
    return $("#Ocorrencia", this.view).datepicker({
      orientation: "top auto",
      autoclose: true,
      forceParse: true,
      startDate: this.options.startDate,
      endDate: this.options.endDate,
      calendarWeeks: false,
      minViewMode: 'months',
      maxViewMode: 'months'
    });
  };

  return createEditGraficoDeIndicadorController;

})();
