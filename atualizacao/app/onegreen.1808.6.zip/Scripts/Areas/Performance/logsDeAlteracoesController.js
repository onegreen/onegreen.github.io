﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.logsDeAlteracoesController = (function() {
  function logsDeAlteracoesController(contexto) {
    this.contexto = contexto;
    this.onSelectedMes = bind(this.onSelectedMes, this);
    this.loadComboMes = bind(this.loadComboMes, this);
    $(this.contexto).window();
    this.loadComboMes();
  }

  logsDeAlteracoesController.prototype.loadComboMes = function() {
    var opcoes;
    opcoes = {
      contextId: this.contexto,
      elementId: "#NomeDoMes",
      container: 'body',
      onSelected: this.onSelectedMes
    };
    return setComboJSON(opcoes);
  };

  logsDeAlteracoesController.prototype.onSelectedMes = function() {
    return $as.Performance.LogsDeAlteracoes.MudarMes.get({
      idDoIndicador: $("#IdDoPai", this.contexto).val(),
      mesSemanaDia: $("#MesSemanaDia", this.contexto).val()
    }).success((function(_this) {
      return function(data) {
        return $("#listagemDeLogsDeAlteracoes", _this.contexto).html(data);
      };
    })(this));
  };

  return logsDeAlteracoesController;

})();
