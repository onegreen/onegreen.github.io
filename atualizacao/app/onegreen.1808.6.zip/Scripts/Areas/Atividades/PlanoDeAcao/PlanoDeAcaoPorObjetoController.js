﻿var base,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

this.Atividades || (this.Atividades = {});

(base = this.Atividades).PlanoDeAcao || (base.PlanoDeAcao = {});

Atividades.PlanoDeAcao.PlanoDeAcaoPorObjetoController = (function(superClass) {
  extend(PlanoDeAcaoPorObjetoController, superClass);

  function PlanoDeAcaoPorObjetoController(view, cadastroSimplificado, urlComboResponsavel, objeto, idDoObjeto, tipoDoObjeto) {
    this.view = view;
    if (cadastroSimplificado == null) {
      cadastroSimplificado = false;
    }
    this.urlComboResponsavel = urlComboResponsavel;
    this.objeto = objeto != null ? objeto : "";
    this.idDoObjeto = idDoObjeto != null ? idDoObjeto : 0;
    this.tipoDoObjeto = tipoDoObjeto != null ? tipoDoObjeto : "";
    this.configurarComboResponsavel = bind(this.configurarComboResponsavel, this);
    this.tratarParametros = bind(this.tratarParametros, this);
    this.reload = bind(this.reload, this);
    PlanoDeAcaoPorObjetoController.__super__.constructor.call(this, this.view, cadastroSimplificado, this.urlComboResponsavel);
    this.tableContainer = $(this.view);
  }

  PlanoDeAcaoPorObjetoController.prototype.reload = function() {
    return $as.Atividades.PlanosDeAcao.IndexPorObjeto.get({
      idDoPlanoDeAcao: this.id,
      idObjeto: this.idDoObjeto,
      tipoObjeto: this.tipoDoObjeto
    }).done((function(_this) {
      return function(data) {
        _this.tableContainer.replaceWith(data);
        $("[rel=tooltip]", _this.view).tooltip();
        _this.atualizarCascata();
        Atividades.PlanoDeAcao.api.reload(_this.id);
      };
    })(this));
  };

  PlanoDeAcaoPorObjetoController.prototype.tratarParametros = function(parametros) {
    if (this.tipoDoObjeto && this.idDoObjeto) {
      parametros = parametros + "&atividade.TipoDoObjeto=" + this.tipoDoObjeto + "&atividade.IdeDoObjeto=" + this.idDoObjeto;
    }
    return PlanoDeAcaoPorObjetoController.__super__.tratarParametros.call(this, parametros);
  };

  PlanoDeAcaoPorObjetoController.prototype.configurarComboResponsavel = function() {
    return $("#NomeDoResponsavelDaTarefa" + this.objeto).autocompleter(this.urlComboResponsavel, {
      loadOnDemand: true,
      elementToClick: "#NomeDoResponsavelDaTarefa" + this.objeto + "Btn",
      keyElement: "#ResponsavelDaTarefaId" + this.objeto
    });
  };

  return PlanoDeAcaoPorObjetoController;

})(Atividades.PlanoDeAcao.PlanoDeAcaoController);
