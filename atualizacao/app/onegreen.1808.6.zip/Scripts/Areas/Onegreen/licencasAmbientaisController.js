var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.licencasAmbientaisController = (function() {
  function licencasAmbientaisController(contexto, options, resource) {
    this.contexto = contexto;
    this.options = options;
    this.resource = resource;
    this.gerarfce = bind(this.gerarfce, this);
    this.calcularVencimentoFOB = bind(this.calcularVencimentoFOB, this);
    this.configurarCalculoDoVencimentoFOB = bind(this.configurarCalculoDoVencimentoFOB, this);
    this.mostrarJustificativaDaDataRenovacao = bind(this.mostrarJustificativaDaDataRenovacao, this);
    this.mostrarJustificativaDaDataValidade = bind(this.mostrarJustificativaDaDataValidade, this);
    this.mostrarJustificativaDaDataPrevisao = bind(this.mostrarJustificativaDaDataPrevisao, this);
    this.configurarExibicaoDosCampos = bind(this.configurarExibicaoDosCampos, this);
    this.configurarReload = bind(this.configurarReload, this);
    this.mostrarJustificativaDoVencimentoFOB = bind(this.mostrarJustificativaDoVencimentoFOB, this);
    this.mostrarItensPorTipoDeLicenca = bind(this.mostrarItensPorTipoDeLicenca, this);
    this.alterarCamposPeloTipoDaLicenca = bind(this.alterarCamposPeloTipoDaLicenca, this);
    this.configurarComboDnpms = bind(this.configurarComboDnpms, this);
    this.configurarComboStatusLicenca = bind(this.configurarComboStatusLicenca, this);
    this.configurarComboTipoDeLicenca = bind(this.configurarComboTipoDeLicenca, this);
    this.configurarComboSolicitacaoDeLicenciamento = bind(this.configurarComboSolicitacaoDeLicenciamento, this);
    this.configurarComboReponsavel = bind(this.configurarComboReponsavel, this);
    this.configurarExibirSolicitacaoDeLicenciamento = bind(this.configurarExibirSolicitacaoDeLicenciamento, this);
    this.exibirEsconderSolicitacaoDeLicenciamento = bind(this.exibirEsconderSolicitacaoDeLicenciamento, this);
    this.configurarCombos = bind(this.configurarCombos, this);
    this.configurarDatePicker = bind(this.configurarDatePicker, this);
    this.carregarMascaras = bind(this.carregarMascaras, this);
    this.configurarPopoverDeInformacoes = bind(this.configurarPopoverDeInformacoes, this);
    this.aoAlterarDataDeRenovacao = bind(this.aoAlterarDataDeRenovacao, this);
    this.aoAlterarDataDeValidade = bind(this.aoAlterarDataDeValidade, this);
    this.alternarRenovacaoManualAutomatico = bind(this.alternarRenovacaoManualAutomatico, this);
    this.alternarCustoManualAutomatico = bind(this.alternarCustoManualAutomatico, this);
    this.removerTagLicenca = bind(this.removerTagLicenca, this);
    this.adicionarTagLicenca = bind(this.adicionarTagLicenca, this);
    this.configurarTagsLicenca = bind(this.configurarTagsLicenca, this);
    this.alterarStatus = bind(this.alterarStatus, this);
    this.alterarStatusLicenca = bind(this.alterarStatusLicenca, this);
    this.mostrarEsconderOpcoesStatusLicenca = bind(this.mostrarEsconderOpcoesStatusLicenca, this);
    this.statusAlterar = null;
    this.carregarMascaras();
    this.configurarDatePicker();
    this.configurarCombos();
    this.configurarReload();
    this.configurarExibicaoDosCampos();
    this.configurarCalculoDoVencimentoFOB();
    this.configurarPopoverDeInformacoes();
    this.configurarTagsLicenca();
    this.mostrarEsconderOpcoesStatusLicenca();
    this.configurarExibirSolicitacaoDeLicenciamento();
    if ($('input[name=CustoManual]', this.contexto).val() === "True") {
      $("#CustoPrevisto", this.contexto).prop('disabled', false);
    }
    if ($('input[name=DataLimiteParaRenovacaoManual]', this.contexto).val() === "False") {
      $("#DataLimiteParaRenovacao", this.contexto).prop('readonly', true);
      $("#DataLimiteParaRenovacaoBtn", '#permite-renovacao-container').attr('disabled', 'disabled');
    }
    $("#VencimentoFOB", this.contexto).on("change", this.mostrarJustificativaDoVencimentoFOB).change();
    $('#btnEnableDisable', this.contexto).unbind('click').bind('click', this.alternarCustoManualAutomatico);
    $('#btnEnableDisableRenovacao', this.contexto).unbind('click').bind('click', (function(_this) {
      return function(e) {
        return _this.alternarRenovacaoManualAutomatico(e);
      };
    })(this));
    $('#btnStatusLicenca', this.contexto).unbind('click').bind('click', this.mostrarEsconderOpcoesStatusLicenca);
    $('#btnConcluirLicenca', this.contexto).unbind('click').bind('click', (function(_this) {
      return function(e) {
        return _this.alterarStatusLicenca(e);
      };
    })(this));
    $('#btnCancelarLicenca', this.contexto).unbind('click').bind('click', (function(_this) {
      return function(e) {
        return _this.alterarStatusLicenca(e);
      };
    })(this));
    $('#btnIndeferirLicenca', this.contexto).unbind('click').bind('click', (function(_this) {
      return function(e) {
        return _this.alterarStatusLicenca(e);
      };
    })(this));
    $('#btnReativarLicenca', this.contexto).unbind('click').bind('click', (function(_this) {
      return function(e) {
        return _this.alterarStatusLicenca(e);
      };
    })(this));
    $("#editar-solicitacao", this.contexto).on('click', this.exibirEsconderSolicitacaoDeLicenciamento);
    $("#DataPrevisao", this.contexto).on("change", this.mostrarJustificativaDaDataPrevisao).change();
    $("#DataValidade", this.contexto).on("change", this.aoAlterarDataDeValidade);
    $("#DataLimiteParaRenovacao", this.contexto).on("change", this.aoAlterarDataDeRenovacao);
    this.licenca = {
      protocoloFOB: ko.observable(this.options.protocoloFOB),
      diasVencimentoFOB: ko.observable(this.options.diasVencimentoFOB)
    };
    $("[rel=tooltip]").tooltip();
  }

  licencasAmbientaisController.prototype.mostrarEsconderOpcoesStatusLicenca = function() {
    var timeFade;
    timeFade = 300;
    if ($("#opcoesStatusLicenca").hasClass('js-hide')) {
      $("#opcoesStatusLicenca").removeClass('js-hide');
      return $("#opcoesStatusLicenca").fadeIn(timeFade);
    } else {
      $("#opcoesStatusLicenca").addClass('js-hide');
      return $("#opcoesStatusLicenca").fadeOut(timeFade);
    }
  };

  licencasAmbientaisController.prototype.alterarStatusLicenca = function(event) {
    this.statusAlterar = $(event.target).attr("data-status");
    this.mensagemAlterarStatus = $(event.target).attr("data-confirm");
    return window.modalConfirm(this.mensagemAlterarStatus, this.alterarStatus);
  };

  licencasAmbientaisController.prototype.alterarStatus = function() {
    return $as.Onegreen.LicencasAmbientais.AlterarStatus.post({
      id: this.options.idDaLicenca,
      statusLicenca: this.statusAlterar
    });
  };

  licencasAmbientaisController.prototype.configurarTagsLicenca = function() {
    return $as.Onegreen.Tags.RetornarTags.get().success((function(_this) {
      return function(data) {
        return $('#agregadorDeTags', _this.contexto).tagit({
          availableTags: data,
          tagListUl: $('#tagsListUl', _this.contexto),
          afterTagAdded: _this.adicionarTagLicenca,
          afterTagRemoved: _this.removerTagLicenca
        });
      };
    })(this));
  };

  licencasAmbientaisController.prototype.adicionarTagLicenca = function(event, ui) {
    return $as.Onegreen.LicencasAmbientais.AdicionarTagLicenca.post({
      id: this.options.idDaLicenca,
      nomeTag: ui.tagLabel
    });
  };

  licencasAmbientaisController.prototype.removerTagLicenca = function(event, ui) {
    return $as.Onegreen.LicencasAmbientais.RemoverTagLicenca.post({
      id: this.options.idDaLicenca,
      nomeTag: ui.tagLabel
    });
  };

  licencasAmbientaisController.prototype.alternarCustoManualAutomatico = function() {
    if ($('input[name=CustoManual]', this.contexto).val() === "False") {
      $('#btnEnableDisable', this.contexto).addClass("btn-warning");
      $('input[name=CustoManual]', this.contexto).val("True");
      $("#CustoPrevisto", this.contexto).prop('disabled', false);
      $("#CustoPrevisto", this.contexto).val(this.options.custoPrevisto);
      $("#checkIcon", this.contexto).removeClass("fa-cogs");
      $("#checkIcon", this.contexto).addClass("fa-hand-paper-o");
      return $("#CustoPrevisto", this.contexto).focus();
    } else {
      $('#btnEnableDisable', this.contexto).removeClass("btn-warning");
      $('input[name=CustoManual]', this.contexto).val("False");
      $("#CustoPrevisto", this.contexto).prop('disabled', true);
      $("#CustoPrevisto", this.contexto).val(this.options.valorPrevistoAutomatico);
      $("#checkIcon", this.contexto).addClass("fa-cogs");
      return $("#checkIcon", this.contexto).removeClass("fa-hand-paper-o");
    }
  };

  licencasAmbientaisController.prototype.alternarRenovacaoManualAutomatico = function(e) {
    if ($('input[name=DataLimiteParaRenovacaoManual]', '#permite-renovacao-container').val() === "False") {
      $('#btnEnableDisableRenovacao', '#permite-renovacao-container').addClass("btn-warning");
      $('input[name=DataLimiteParaRenovacaoManual]', '#permite-renovacao-container').val("True");
      $("#DataLimiteParaRenovacao", '#permite-renovacao-container').prop('readonly', false);
      $("#DataLimiteParaRenovacaoBtn", '#permite-renovacao-container').removeAttr('disabled');
      $("#DataLimiteParaRenovacao", '#permite-renovacao-container').val(this.options.dataLimiteParaRenovacao);
      $("#checkIcon", '#permite-renovacao-container').removeClass("fa-cogs");
      $("#checkIcon", '#permite-renovacao-container').addClass("fa-hand-paper-o");
      $("#DataLimiteParaRenovacao", '#permite-renovacao-container').focus();
    } else {
      $('#btnEnableDisableRenovacao', '#permite-renovacao-container').removeClass("btn-warning");
      $('input[name=DataLimiteParaRenovacaoManual]', '#permite-renovacao-container').val("False");
      $("#DataLimiteParaRenovacao", '#permite-renovacao-container').prop('readonly', true);
      $("#DataLimiteParaRenovacaoBtn", '#permite-renovacao-container').attr('disabled', 'disabled');
      $("#DataLimiteParaRenovacao", '#permite-renovacao-container').val(this.options.dataLimiteParaRenovacaoAutomatico);
      $("#checkIcon", '#permite-renovacao-container').addClass("fa-cogs");
      $("#checkIcon", '#permite-renovacao-container').removeClass("fa-hand-paper-o");
      e.preventDefault();
    }
    return this.mostrarJustificativaDaDataRenovacao();
  };

  licencasAmbientaisController.prototype.aoAlterarDataDeValidade = function(event) {
    this.mostrarJustificativaDaDataValidade();
    return this.alterarCamposPeloTipoDaLicenca($("#Tipo_Id", this.options.contexto).val());
  };

  licencasAmbientaisController.prototype.aoAlterarDataDeRenovacao = function(event) {
    return this.mostrarJustificativaDaDataRenovacao();
  };

  licencasAmbientaisController.prototype.configurarPopoverDeInformacoes = function() {
    $("[rel=popover]").popover({
      title: this.resource.Informacoes + '<span class="fr cursor-pointer" onclick="popover.close($(this))"><i class="fa fa-times fa-1"></i></span>'
    });
    $(window).scroll((function(_this) {
      return function() {
        return $('.popover').remove();
      };
    })(this));
    $("#popover-de-informacoes-de-custo").attr("data-content", $("#tabela-informacoes-de-custo").html());
    $("#popover-do-valor-total-dos-estudos").attr("data-content", $("#tabela-valor-total-estudos").html());
    return $("#popover-do-datas-dos-estudos").attr("data-content", $("#tabela-datas-dos-estudos").html());
  };

  licencasAmbientaisController.prototype.carregarMascaras = function() {
    $("input[alt=date]").setMask();
    $("input[alt=decimal]").setMask();
    return $("input[id=DiasParaVencimentoFOB]").setMask({
      mask: '99999',
      maxLength: 5
    });
  };

  licencasAmbientaisController.prototype.configurarDatePicker = function() {
    return $(".date").datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true
    });
  };

  licencasAmbientaisController.prototype.configurarCombos = function() {
    this.configurarComboReponsavel();
    this.configurarComboSolicitacaoDeLicenciamento();
    this.configurarComboTipoDeLicenca();
    this.configurarComboStatusLicenca();
    return this.configurarComboDnpms();
  };

  licencasAmbientaisController.prototype.exibirEsconderSolicitacaoDeLicenciamento = function() {
    $("#informacoes-solicitacao", this.contexto).hide(500);
    return $("#dvSolicitacaoDeLicenciamento", this.contexto).show(500);
  };

  licencasAmbientaisController.prototype.configurarExibirSolicitacaoDeLicenciamento = function() {
    if (this.options.novoRegistro || this.options.idDaSolicitacao === 0) {
      return $("#dvSolicitacaoDeLicenciamento", this.contexto).show(0);
    } else {
      return $("#dvSolicitacaoDeLicenciamento", this.contexto).hide(0);
    }
  };

  licencasAmbientaisController.prototype.configurarComboReponsavel = function() {
    return setCombo(this.contexto, "#Responsavel_Nome");
  };

  licencasAmbientaisController.prototype.configurarComboSolicitacaoDeLicenciamento = function() {
    return setCombo(this.contexto, "#SolicitacaoDeLicenciamento_Descricao");
  };

  licencasAmbientaisController.prototype.configurarComboTipoDeLicenca = function() {
    var aoAlterarTipoDeLicenca, parametros;
    aoAlterarTipoDeLicenca = (function(_this) {
      return function(input) {
        return _this.alterarCamposPeloTipoDaLicenca(input.val());
      };
    })(this);
    parametros = {
      idLegislacaoAmbiental: (function(_this) {
        return function() {
          return _this.options.idLegislacaoAmbiental;
        };
      })(this),
      somenteEstatuais: (function(_this) {
        return function() {
          return _this.options.somenteEstatuais;
        };
      })(this)
    };
    return setCombo(this.contexto, "#Tipo_Descricao", aoAlterarTipoDeLicenca, parametros);
  };

  licencasAmbientaisController.prototype.configurarComboStatusLicenca = function() {
    return setDropDown(this.contexto, "#Status-dropdown");
  };

  licencasAmbientaisController.prototype.configurarComboDnpms = function() {
    var licencaViewModel;
    $.loadTemplate(this.options.urlTemplateDoComboDeDnpms, 'dnpmsTemplate');
    licencaViewModel = {
      dnpms: ko.observableArray(this.options.jsonDeDnpms),
      removeDnpm: function(dnpm) {
        return this.dnpms.remove(dnpm);
      }
    };
    window.licencaViewModel = licencaViewModel;
    ko.applyBindings(licencaViewModel, $('#dnpms_itens')[0]);
    return $("#DNPMsLicenca", this.contexto).autocompleter(this.options.urlComboDeDnpms, {
      elementToClick: "#DNPMsLicencaBtn",
      multiSelectArray: licencaViewModel.dnpms,
      multiSelectElement: "#dnpms_itens",
      keyName: "idsDnpms",
      multiSelectDescriptionName: "Descricao"
    });
  };

  licencasAmbientaisController.prototype.alterarCamposPeloTipoDaLicenca = function(idTipoDeLicenca) {
    if (idTipoDeLicenca !== "") {
      return $as.API.TiposDeLicenca.ObterInformacoesDoTipoDeLicenca.get({
        idDoTipoDeLicenca: idTipoDeLicenca,
        dataDeValidade: $("#DataValidade", this.options.contexto).val()
      }).success((function(_this) {
        return function(data) {
          if (data.permiteRenovacao) {
            $("#permite-renovacao-container", _this.options.contexto).show();
            $("#data-limite-para-renovacao", _this.options.contexto).val(data.dataLimiteParaRenovacao);
          } else {
            $("#permite-renovacao-container", _this.options.contexto).hide();
          }
          return _this.mostrarItensPorTipoDeLicenca(data.tipoDeLicenca);
        };
      })(this));
    } else {
      return this.mostrarItensPorTipoDeLicenca("");
    }
  };

  licencasAmbientaisController.prototype.mostrarItensPorTipoDeLicenca = function(tipoDeLicenca) {
    $("#dvIncluidaSolicitacaoFasePreOperacao", this.contexto).hide();
    $("#dvDataAudienciaPublica", this.contexto).hide();
    switch (tipoDeLicenca) {
      case this.options.licencaImplantacao:
      case this.options.licencaPreviaEImplantacao:
        $("#dvIncluidaSolicitacaoFasePreOperacao", this.contexto).show();
        return $("#dvDataAudienciaPublica input", this.contexto).val('');
      case this.options.LicencaPrevia:
        return $("#dvDataAudienciaPublica", this.contexto).show();
      default:
        $("#IncluidaSolicitacaoFasePreOperacao", this.contexto).removeAttr("checked");
        return $("#dvDataAudienciaPublica input", this.contexto).val('');
    }
  };

  licencasAmbientaisController.prototype.mostrarJustificativaDoVencimentoFOB = function() {
    var ocorreuMudanca;
    if (this.options.idDaLicenca > 0) {
      ocorreuMudanca = (this.options.tempoDeVencimentoFOB !== $("#ProtocoloFOB", this.contexto).val()) || this.options.diasParaVencimentoFOB !== $("#DiasParaVencimentoFOB").val();
      if (ocorreuMudanca && this.options.tempoDeVencimentoFOB !== "") {
        return $("#dvJusVencimentoFOB", this.contexto).show(1000);
      } else {
        return $("#dvJusVencimentoFOB", this.contexto).hide(1000);
      }
    }
  };

  licencasAmbientaisController.prototype.configurarReload = function() {
    return window.LicencaAmbiental = {
      reload: (function(_this) {
        return function() {
          return $as.Onegreen.Empreendimentos.Edit.get({
            id: _this.options.idDoEmpreendimento
          }).success(function(data) {
            $("#main").html(data);
            $('#lnkLicencas').click();
            return $('.alert').hide();
          });
        };
      })(this)
    };
  };

  licencasAmbientaisController.prototype.configurarExibicaoDosCampos = function() {
    var idDoTipoDaLicenca;
    idDoTipoDaLicenca = $("#Tipo_Id", this.contexto).val();
    $("#dvDataAudienciaPublica", this.contexto).hide();
    $('.justificativa', this.contexto).hide();
    if (this.options.idDaLicenca === 0) {
      $('.reprogramacoes').hide();
    }
    this.alterarCamposPeloTipoDaLicenca(idDoTipoDaLicenca);
    this.mostrarJustificativaDaDataPrevisao();
    this.mostrarJustificativaDoVencimentoFOB();
    this.mostrarJustificativaDaDataValidade();
    return this.mostrarJustificativaDaDataRenovacao();
  };

  licencasAmbientaisController.prototype.mostrarJustificativaDaDataPrevisao = function() {
    var ocorreuMudanca;
    if (this.options.idDaLicenca > 0) {
      ocorreuMudanca = this.options.dataPrevisao !== $("#DataPrevisao", this.contexto).val();
      if (ocorreuMudanca && this.options.dataPrevisao !== "") {
        return $("#dvJusDataPrevisao", this.contexto).show(1000);
      } else {
        return $("#dvJusDataPrevisao", this.contexto).hide(1000);
      }
    } else {
      return $("#dvJusDataPrevisao", this.contexto).hide(1000);
    }
  };

  licencasAmbientaisController.prototype.mostrarJustificativaDaDataValidade = function() {
    var ocorreuMudanca;
    if (this.options.idDaLicenca > 0) {
      ocorreuMudanca = this.options.dataValidade !== $("#DataValidade", this.contexto).val();
      $("#ValidadeFoiAlterada").val(ocorreuMudanca ? 1 : 0);
      if (ocorreuMudanca && this.options.dataValidade !== "") {
        return $("#dvJusDataValidade", this.contexto).show(1000);
      } else {
        return $("#dvJusDataValidade", this.contexto).hide(1000);
      }
    } else {
      return $("#dvJusDataValidade", this.contexto).hide(1000);
    }
  };

  licencasAmbientaisController.prototype.mostrarJustificativaDaDataRenovacao = function() {
    var ocorreuMudanca;
    if (this.options.idDaLicenca > 0) {
      ocorreuMudanca = this.options.dataLimiteParaRenovacao !== $("#DataLimiteParaRenovacao", this.contexto).val();
      console.log(ocorreuMudanca);
      $("#RenovacaoFoiAlterada").val(ocorreuMudanca ? 1 : 0);
      if (ocorreuMudanca && this.options.dataLimiteParaRenovacao !== "") {
        return $("#dvJusDataRenovacao", this.contexto).show(1000);
      } else {
        return $("#dvJusDataRenovacao", this.contexto).hide(1000);
      }
    } else {
      return $("#dvJusDataRenovacao", this.contexto).hide(1000);
    }
  };

  licencasAmbientaisController.prototype.configurarCalculoDoVencimentoFOB = function() {
    $("#ProtocoloFOB", this.contexto).on("change", (function(_this) {
      return function() {
        $("#spanErroDataFob").hide();
        $("#spanErroDataFobOriginal").html('');
        _this.licenca.protocoloFOB($( this ).val());
        _this.calcularVencimentoFOB();
        return _this.mostrarJustificativaDoVencimentoFOB();
      };
    })(this));
    $("#DiasParaVencimentoFOB", this.contexto).on("change", (function(_this) {
      return function() {
        _this.licenca.diasVencimentoFOB($( this ).val());
        _this.calcularVencimentoFOB();
        return _this.mostrarJustificativaDoVencimentoFOB();
      };
    })(this));
    return this.calcularVencimentoFOB();
  };

  licencasAmbientaisController.prototype.calcularVencimentoFOB = function() {
    var dataProtocoloFOB, diasParaVencimentoFOB;
    if ($("#ProtocoloFOB", this.contexto).val() === "" || $("#DiasParaVencimentoFOB", this.contexto).val() === "") {
      $("#VencimentoFOB").html(this.resource.Indeterminado);
    }
    dataProtocoloFOB = $("#ProtocoloFOB", this.contexto).val();
    diasParaVencimentoFOB = $("#DiasParaVencimentoFOB", this.contexto).val() === "" ? 0 : $("#DiasParaVencimentoFOB", this.contexto).val();
    return $as.Onegreen.LicencasAmbientais.AdicionarDiasEmData.get({
      data: dataProtocoloFOB,
      dias: diasParaVencimentoFOB
    }).success((function(_this) {
      return function(data) {
        if (data.erro === 'true' && $("#spanErroDataFobOriginal", _this.contexto).html() === '') {
          return $("#spanErroDataFob", _this.contexto).show();
        } else if (data.erro === 'false') {
          $("#VencimentoFOB").html(data.data);
          $("#spanErroDataFob").hide();
          return $("#spanErroDataFobOriginal").html('');
        }
      };
    })(this));
  };

  licencasAmbientaisController.prototype.gerarfce = function() {
    return $.get(this.options.urlGerarFCE);
  };

  return licencasAmbientaisController;

})();
