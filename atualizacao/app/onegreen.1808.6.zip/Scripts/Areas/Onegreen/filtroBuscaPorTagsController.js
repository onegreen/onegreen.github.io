﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.filtroBuscaPorTagsController = (function() {
  function filtroBuscaPorTagsController(opcoes) {
    this.opcoes = opcoes;
    this.limparComboLicencas = bind(this.limparComboLicencas, this);
    this.camposDependentesLicencaAmbiental = bind(this.camposDependentesLicencaAmbiental, this);
    this.marcarTodasAsOrigensDasTags = bind(this.marcarTodasAsOrigensDasTags, this);
    this.desmarcarTodasAsOrigensDasTags = bind(this.desmarcarTodasAsOrigensDasTags, this);
    this.AplicarFiltro = bind(this.AplicarFiltro, this);
    this.configurarFiltro = bind(this.configurarFiltro, this);
    this.habilitarEnter = bind(this.habilitarEnter, this);
    this.configurarTags = bind(this.configurarTags, this);
    this.loadComboLicencasAmbientais = bind(this.loadComboLicencasAmbientais, this);
    this.loadComboNomeProjeto = bind(this.loadComboNomeProjeto, this);
    this.loadComboUnidadeGerencial = bind(this.loadComboUnidadeGerencial, this);
    this.configurarTags();
    this.configurarFiltro();
    this.loadComboUnidadeGerencial();
    this.loadComboNomeProjeto();
    this.loadComboLicencasAmbientais();
    this.habilitarEnter();
    this.camposDependentesLicencaAmbiental();
    this.marcarTodasAsOrigensDasTags();
    this.desmarcarTodasAsOrigensDasTags();
    $('.aplicarFiltro').unbind('click').click(this.AplicarFiltro);
  }

  filtroBuscaPorTagsController.prototype.loadComboUnidadeGerencial = function() {
    return setCombo(this.opcoes.contexto, "#NomeDaUnidadeGerencial");
  };

  filtroBuscaPorTagsController.prototype.loadComboNomeProjeto = function() {
    $("#EmpreendimentoNome", this.opcoes.contexto).change((function(_this) {
      return function() {
        if ($("#EmpreendimentoNome", _this.opcoes.contexto).val() === '') {
          $('#LicencaAmbientalNome').data('autocompleter').disableElseEnable(true);
          return _this.limparComboLicencas();
        }
      };
    })(this));
    return setCombo(this.opcoes.contexto, "#EmpreendimentoNome", this.camposDependentesLicencaAmbiental);
  };

  filtroBuscaPorTagsController.prototype.loadComboLicencasAmbientais = function() {
    var parametros;
    parametros = {
      idDoEmpreendimento: $('#Empreendimento').val()
    };
    return setCombo(this.opcoes.contexto, '#LicencaAmbientalNome', null, parametros);
  };

  filtroBuscaPorTagsController.prototype.configurarTags = function() {
    return $as.Onegreen.Tags.RetornarTags.get().success((function(_this) {
      return function(data) {
        return $('#NomeTag', '#main').tagit({
          combo: true,
          availableTags: data,
          tagListUl: $('#tagsListUL', '#main')
        });
      };
    })(this));
  };

  filtroBuscaPorTagsController.prototype.habilitarEnter = function() {
    return $('#NomeTag').keypress((function(_this) {
      return function(event) {
        if (event.keyCode === 13) {
          return _this.AplicarFiltro();
        }
      };
    })(this));
  };

  filtroBuscaPorTagsController.prototype.configurarFiltro = function() {
    $("#filtro-busca-por-tags").on('click', (function(_this) {
      return function() {
        return $("#filtro-busca-por-tags-container").toggle();
      };
    })(this));
    return $("#fechar-filtro", this.opcoes.contexto).on('click', (function(_this) {
      return function() {
        return $("#filtro-busca-por-tags-container").toggle();
      };
    })(this));
  };

  filtroBuscaPorTagsController.prototype.AplicarFiltro = function() {
    var dados;
    dados = $('#div-input-pesquisar', '#main').find('.tagit-hidden-field').serialize() + "&" + $(this.opcoes.contexto).find(":input").serialize();
    return $as.Onegreen.BuscarPorTags.Filtro.get(dados).success((function(_this) {
      return function(dados) {
        return $('#main').html(dados);
      };
    })(this));
  };

  filtroBuscaPorTagsController.prototype.desmarcarTodasAsOrigensDasTags = function() {
    return $("#desmarcar-todos").on('click', (function(_this) {
      return function() {
        return $("input", "#container-selecao-de-origem-das-tags").prop("checked", false);
      };
    })(this));
  };

  filtroBuscaPorTagsController.prototype.marcarTodasAsOrigensDasTags = function() {
    return $("#marcar-todos").on('click', (function(_this) {
      return function() {
        return $("input", "#container-selecao-de-origem-das-tags").prop("checked", true);
      };
    })(this));
  };

  filtroBuscaPorTagsController.prototype.camposDependentesLicencaAmbiental = function() {
    var empreendimentoSelecionado;
    empreendimentoSelecionado = $('#Empreendimento').val() !== null && $('#Empreendimento').val() !== 0 && $('#Empreendimento').val() !== void 0 && $('#Empreendimento').val() !== '';
    if (empreendimentoSelecionado) {
      this.loadComboLicencasAmbientais();
    } else {
      this.limparComboLicencas();
    }
    return $('#LicencaAmbientalNome').data('autocompleter').disableElseEnable(!empreendimentoSelecionado);
  };

  filtroBuscaPorTagsController.prototype.limparComboLicencas = function() {
    $('#LicencaAmbiental').val('');
    return $('#LicencaAmbientalNome').val('');
  };

  return filtroBuscaPorTagsController;

})();
