﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.vinculoDeSolicitacaoController = (function() {
  function vinculoDeSolicitacaoController(contexto1, options) {
    this.contexto = contexto1;
    this.options = options;
    this.onFormSuccess = bind(this.onFormSuccess, this);
    this.comboDeLicencas = bind(this.comboDeLicencas, this);
    this.comboDeEmpreendimento = bind(this.comboDeEmpreendimento, this);
    this.habilitarExecutarAcao = bind(this.habilitarExecutarAcao, this);
    this.configurarVoltarParaOpcoes = bind(this.configurarVoltarParaOpcoes, this);
    this.configurarSomenteAprovar = bind(this.configurarSomenteAprovar, this);
    this.configurarCriarUmNovoEmpreendimento = bind(this.configurarCriarUmNovoEmpreendimento, this);
    this.configurarVinvularAUmEmpreendimentoExistente = bind(this.configurarVinvularAUmEmpreendimentoExistente, this);
    this.configurarVinvularAUmaLicencaExistente = bind(this.configurarVinvularAUmaLicencaExistente, this);
    this.configurarCriarUmaNovaLicenca = bind(this.configurarCriarUmaNovaLicenca, this);
    this.configurarClick = bind(this.configurarClick, this);
    this.configurarClickAcoes = bind(this.configurarClickAcoes, this);
    $(this.contexto).window();
    this.configurarSomenteAprovar();
    this.configurarCriarUmNovoEmpreendimento();
    this.configurarVinvularAUmEmpreendimentoExistente();
    this.configurarCriarUmaNovaLicenca();
    this.configurarVinvularAUmaLicencaExistente();
    this.configurarVoltarParaOpcoes();
  }

  vinculoDeSolicitacaoController.prototype.configurarClickAcoes = function(link, idDoFormulario, utilizaComboDelicenca) {
    return $("#" + link, this.contexto).click((function(_this) {
      return function() {
        $("#acoes-solicitacao-container", _this.contexto).toggle("slide");
        _this.comboDeEmpreendimento("#" + link + "-container", utilizaComboDelicenca);
        return setTimeout(function() {
          $("#" + link + "-container", _this.contexto).show();
          $("#executar-acao", _this.contexto).attr("disabled", "disabled");
          $("#executar-acao", _this.contexto).show();
          return $("#executar-acao", _this.contexto).unbind("click").bind("click", function() {
            return $("#" + idDoFormulario).submit();
          });
        }, 400);
      };
    })(this));
  };

  vinculoDeSolicitacaoController.prototype.configurarClick = function(link, action, controller) {
    return $("#" + link, this.contexto).click((function(_this) {
      return function() {
        return $as.Onegreen["" + controller]["" + action].post({
          idDaSolicitacao: _this.options.idDaSolicitacao
        }).success(function(data) {
          $("#main").html(data);
          return $("#close-modal-vinculodesolicitacao").click();
        });
      };
    })(this));
  };

  vinculoDeSolicitacaoController.prototype.configurarCriarUmaNovaLicenca = function() {
    return this.configurarClickAcoes("criar-uma-nova-licenca", "form-criar-licenca", false);
  };

  vinculoDeSolicitacaoController.prototype.configurarVinvularAUmaLicencaExistente = function() {
    return this.configurarClickAcoes("vincular-a-uma-licenca", "form-vincular-licenca", true);
  };

  vinculoDeSolicitacaoController.prototype.configurarVinvularAUmEmpreendimentoExistente = function() {
    return this.configurarClickAcoes("vincular-a-um-empreendimento", "form-vincular-empreendimento", false);
  };

  vinculoDeSolicitacaoController.prototype.configurarCriarUmNovoEmpreendimento = function() {
    return this.configurarClick("criar-um-novo-empreendimento", "CriarNovoEmpreendimentoAPartirDeUmaSolicitacao", "Empreendimentos");
  };

  vinculoDeSolicitacaoController.prototype.configurarSomenteAprovar = function() {
    return this.configurarClick("somente-aprovar", "Aprovar", "SolicitacoesDeLicenciamento");
  };

  vinculoDeSolicitacaoController.prototype.configurarVoltarParaOpcoes = function() {
    return $(".js-voltar-para-opcoes", this.contexto).click((function(_this) {
      return function() {
        $("#acoes-solicitacao-container", _this.contexto).toggle("slide");
        $("#vincular-a-uma-licenca-container", _this.contexto).hide();
        $("#vincular-a-um-empreendimento-container", _this.contexto).hide();
        $("#criar-uma-nova-licenca-container", _this.contexto).hide();
        return $("#executar-acao", _this.contexto).hide();
      };
    })(this));
  };

  vinculoDeSolicitacaoController.prototype.habilitarExecutarAcao = function() {
    return $("#executar-acao", this.contexto).removeAttr("disabled");
  };

  vinculoDeSolicitacaoController.prototype.comboDeEmpreendimento = function(contexto, utilizaComboDelicenca) {
    if (utilizaComboDelicenca) {
      return setCombo(contexto, "#NomeDoEmpreendimento", this.comboDeLicencas);
    } else {
      $("#NomeDoEmpreendimento", contexto).change((function(_this) {
        return function(e) {
          if ($(e.delegateTarget).val() === '') {
            return $("#executar-acao", _this.contexto).attr("disabled", "disabled");
          }
        };
      })(this));
      return setCombo(contexto, "#NomeDoEmpreendimento", this.habilitarExecutarAcao);
    }
  };

  vinculoDeSolicitacaoController.prototype.comboDeLicencas = function() {
    var parametros;
    $("#NomeDaLicenca", "#vincular-a-uma-licenca-container").change((function(_this) {
      return function(e) {
        if ($(e.delegateTarget).val() === '') {
          return $("#executar-acao", _this.contexto).attr("disabled", "disabled");
        }
      };
    })(this));
    parametros = {
      idDoEmpreendimento: $('#IdDoEmpreendimento', "#vincular-a-uma-licenca-container").val()
    };
    return setCombo("#vincular-a-uma-licenca-container", '#NomeDaLicenca', this.habilitarExecutarAcao, parametros);
  };

  vinculoDeSolicitacaoController.prototype.onFormSuccess = function(data) {
    return $("#main").html(data);
  };

  return vinculoDeSolicitacaoController;

})();
