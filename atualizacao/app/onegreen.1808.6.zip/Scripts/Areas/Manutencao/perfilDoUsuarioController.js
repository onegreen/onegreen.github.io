﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.perfilDoUsuarioController = (function() {
  function perfilDoUsuarioController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.ativarJCrop = bind(this.ativarJCrop, this);
    this.configurarUpload = bind(this.configurarUpload, this);
    this.deletarFoto = bind(this.deletarFoto, this);
    this.definirBotaoDeExcluir = bind(this.definirBotaoDeExcluir, this);
    this.alterarEstadoCivil = bind(this.alterarEstadoCivil, this);
    this.alterarIDiomaETimeZone = bind(this.alterarIDiomaETimeZone, this);
    this.opcoesEstadoCivil = $("#opcoesEstadoCivil a", this.contexto);
    this.opcoesEstadoCivil.click(this.alterarEstadoCivil);
    this.linkRedefinirSenha = $('#aRedefinirSenha', this.contexto);
    this.dataDeNascimento = $("#DataDeNascimento", this.contexto);
    this.configurarDatePickers();
    this.deleteFoto = $('#DeleteFoto', this.contexto);
    this.deleteFoto.click(this.deletarFoto);
    this.definirBotaoDeExcluir(this.options.idDoUsuario);
    this.idiomaETimeZone = $('#idiomaETimeZone', this.contexto);
    this.idiomaETimeZone.click(this.alterarIDiomaETimeZone);
    this.uploadFoto = $('#UploadFoto', this.contexto);
    this.inputFoto = $('#inputFoto');
    this.configurarUpload();
    $('#foto-usuario', this.contexto).show();
    AjaxTab.BindTabs(this.contexto, this.contexto);
  }

  perfilDoUsuarioController.prototype.alterarIDiomaETimeZone = function() {
    return $as.API.Usuarios.AlteracaoDeIdioma.get({
      idDoUsuario: this.options.idDoUsuario
    }).done((function(_this) {
      return function(data) {
        $('#modal-container').html(data);
        return $('#idioma-modal').window();
      };
    })(this));
  };

  perfilDoUsuarioController.prototype.alterarEstadoCivil = function(evt) {
    var $elemento;
    $elemento = $(evt.currentTarget);
    $('#EstadoCivil', this.contexto).val($elemento.attr("option")).change();
    $('#labelEstadoCivil', this.contexto).text($elemento.text());
    return $('#labelEstadoCivil', this.contexto).append(' <span class="caret"></span>');
  };

  perfilDoUsuarioController.prototype.configurarDatePickers = function() {
    return this.dataDeNascimento.datepicker({
      yearRange: '-100:+0',
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      onSelect: (function(_this) {
        return function() {
          return _this.dataDeNascimento.change();
        };
      })(this)
    });
  };

  perfilDoUsuarioController.prototype.definirBotaoDeExcluir = function() {
    return $as.API.Usuarios.PossuiFoto.post({
      idDoUsuario: this.options.idDoUsuario
    }).done((function(_this) {
      return function(data) {
        if (!data.success) {
          $('#DeleteFoto', _this.contexto).hide();
          return $('#separadorFoto', _this.contexto).hide();
        }
      };
    })(this));
  };

  perfilDoUsuarioController.prototype.deletarFoto = function() {
    return $as.API.Usuarios.DeleteFoto.post({
      idDoUsuario: this.options.idDoUsuario
    }).done((function(_this) {
      return function(data) {
        $('#DeleteFoto', _this.contexto).hide();
        $('#separadorFoto', _this.contexto).hide();
        return _this.recarregarFoto();
      };
    })(this));
  };

  perfilDoUsuarioController.prototype.configurarUpload = function() {
    this.uploadFoto.click((function(_this) {
      return function() {
        return _this.inputFoto.click();
      };
    })(this));
    return this.inputFoto.change((function(_this) {
      return function() {
        var form;
        form = FileUpload.getFormData($("#FormUploadPerfil", _this.contexto));
        return $as.API.Usuarios.Upload.postFormData(form).done(function(data) {
          if (data.success) {
            return _this.iniciarCrop();
          } else {
            return window.MostrarMensagemAviso(data.message);
          }
        });
      };
    })(this));
  };

  perfilDoUsuarioController.prototype.iniciarCrop = function() {
    return $as.API.Usuarios.IniciarCrop.get({
      idDoUsuario: this.options.idDoUsuario
    }).done((function(_this) {
      return function(data) {
        $('#main-modal').html(data);
        return _this.ativarJCrop();
      };
    })(this));
  };

  perfilDoUsuarioController.prototype.ativarJCrop = function() {
    return $('#imagem_crop', "#modalSelecionaFoto").Jcrop({
      bgColor: 'black',
      bgOpacity: .4,
      aspectRatio: 1,
      setSelect: [0, 0, 60, 60],
      onSelect: this.showCoords,
      onChange: this.showCoords,
      allowSelect: false
    }, function() {
      var jcrop;
      return jcrop = this;
    });
  };

  perfilDoUsuarioController.prototype.showCoords = function(c) {
    var contextoCoords;
    contextoCoords = "#modalSelecionaFoto";
    $("#x1", contextoCoords).val(c.x);
    $("#x2", contextoCoords).val(c.x2);
    $("#y1", contextoCoords).val(c.y);
    $("#y2", contextoCoords).val(c.y2);
    return $("#recortar", contextoCoords).removeClass("hidden");
  };

  perfilDoUsuarioController.prototype.submitCrop = function() {
    return $as.API.Usuarios.Crop.post($("#modalSelecionaFoto :input").serialize()).done((function(_this) {
      return function(data) {
        $('#DeleteFoto', _this.contexto).show();
        $('#separadorFoto', _this.contexto).show();
        return _this.recarregarFoto();
      };
    })(this));
  };

  perfilDoUsuarioController.prototype.recarregarFoto = function() {
    return $as.API.Usuarios.RecarregarFoto.get({
      idDoUsuario: this.options.idDoUsuario
    }).done((function(_this) {
      return function(data) {
        return $('#foto-usuario', _this.contexto).html(data);
      };
    })(this));
  };

  return perfilDoUsuarioController;

})();
