﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.relatoriosController = (function(superClass) {
  extend(relatoriosController, superClass);

  function relatoriosController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.tornarPrincipal = bind(this.tornarPrincipal, this);
    this.excluirItem = bind(this.excluirItem, this);
    this.confirmarExclusao = bind(this.confirmarExclusao, this);
    this.loadIndex = bind(this.loadIndex, this);
    relatoriosController.__super__.constructor.call(this, this.view, this.model);
    this.loadIndex();
  }

  relatoriosController.prototype.loadIndex = function() {
    $("[rel=tooltip]").tooltip();
    return window.MarcarMenuSuperior("#lnkPagina");
  };

  relatoriosController.prototype.confirmarExclusao = function(event) {
    var target;
    target = $(event.delegateTarget);
    if (target.data('disabled') === "disabled") {
      return false;
    }
    return Confirmacao.mostrar("", (function(_this) {
      return function() {
        return _this.excluirItem(target);
      };
    })(this));
  };

  relatoriosController.prototype.excluirItem = function(element) {
    return $as.ReportSIM.Relatorios.Excluir.post({
      id: $(element).attr('data-id')
    }).done((function(_this) {
      return function(data) {
        return $(element).closest('tr').remove();
      };
    })(this));
  };

  relatoriosController.prototype.tornarPrincipal = function(event) {
    var element;
    element = $(event.delegateTarget);
    if (element.data('disabled') === "disabled") {
      return false;
    }
    return $as.ReportSIM.Relatorios.TornarRelatorioPadrao.post({
      id: $(element).attr('idPagina'),
      filtro: this.model.filtro
    }).done((function(_this) {
      return function(html) {
        $('#paginas-container').replaceWith($(html).filter('#paginas-container'));
        _this.view = $('#paginas-container');
        return _this.loadIndex();
      };
    })(this));
  };

  return relatoriosController;

})(window.baseController);
