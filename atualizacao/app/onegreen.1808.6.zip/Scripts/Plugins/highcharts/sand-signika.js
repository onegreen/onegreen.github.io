/**
 * Sand-Signika theme for Highcharts JS
 * @author Torstein Honsi
 */

// Load the fonts
/*Highcharts.createElement('link', {
	href: 'http://fonts.googleapis.com/css?family=Signika:400,700',
	rel: 'stylesheet',
	type: 'text/css'
}, null, document.getElementsByTagName('head')[0]);
*/



window.textureTheme = {
    setBackGround : function(){
        // Add the background image to the container
        Highcharts.wrap(Highcharts.Chart.prototype, 'getContainer', function (proceed) {
            proceed.call(this);
            this.container.style.background = 'url(' + CompleteHostAdress + '/Scripts/Plugins/highcharts/sand.png)';
        });
    },
    chart: {
        borderWidth: 0,
        plotBackgroundColor: null,
        plotShadow: false,
        plotBorderColor: '#606063',
        backgroundColor: null,
        style: { fontFamily: "Signika, serif" }
    },
    title: {
        style: {
            color: 'black',
            fontSize: '20px'
        }
    },
    subtitle: {
        style: {
            color: 'black',
        }
    },
    tooltip: {
        borderWidth: 0
    },
    legend: {
        itemStyle: {
            fontWeight: 'bold',
            fontSize: '13px'
        }
    },
    xAxis: {
        gridLineWidth: 0,
        gridLineColor: '#707073',
        lineColor: '#707073',
        tickColor: '#707073',
        labels: {
            style: {
                color: '#6e6e70',
                cursor: 'default',
                fontSize: '11px',
                lineHeight: '14px'
            }
        },
        title: {
            style: {
                color: 'black',
                fontWeight: 'bold'

            }
        },
        minorGridLineColor: '#505053',
    },
    yAxis: {
        gridLineColor: '#707073',
        minorTickInterval: null,
        labels: {
            style: {
                color: '#6e6e70', cursor: 'default',
                fontSize: '11px',
                lineHeight: '14px'
            }
        },
        lineColor: '#707073',
        minorGridLineColor: '#505053',
        lineWidth: 1,
        tickWidth: 1,
        tickColor: '#707073',
        tickWidth: 1,
        title: {
            style: {
                color: 'black',
                fontWeight: 'bold'
            }
        }
    },
    tooltip: {
        backgroundColor: 'rgba(255, 255, 255, 0.85)',
        style: {
            color: '#333'
        }
    },
    plotOptions: {
        series: {
            shadow: true,
            dataLabels: {
                color: '#000'
            },
            marker: {
                lineColor: '#333'
            }
        },
        boxplot: {
            fillColor: '#505053'
        },
        candlestick: {
            lineColor: 'white'
        },
        errorbar: {
            color: 'white'
        },
        candlestick: {
            lineColor: '#404048'
        },
        map: {
            shadow: false
        }
    },

    legend: {
        itemStyle: {
            color: '999',
            fontSize: '12px'
        },
        itemHoverStyle: {
            color: 'black'
        },
        itemHiddenStyle: {
            color: '#606063'
        }
    },
    credits: {
        style: {
            color: '#666'
        }
    },
    labels: {
        style: {
            color: '#707073'
        }
    },

    drilldown: {
        activeAxisLabelStyle: {
            color: '#F0F0F3'
        },
        activeDataLabelStyle: {
            color: '#F0F0F3'
        }
    },

    navigation: {
        buttonOptions: {
            symbolStroke: '#DDDDDD',
            theme: {
                fill: '#505053'
            }
        }
    },

    // scroll charts
    rangeSelector: {
        buttonTheme: {
            fill: '#505053',
            stroke: '#000000',
            style: {
                color: '#CCC'
            },
            states: {
                hover: {
                    fill: '#707073',
                    stroke: '#000000',
                    style: {
                        color: 'white'
                    }
                },
                select: {
                    fill: '#000003',
                    stroke: '#000000',
                    style: {
                        color: 'white'
                    }
                }
            }
        },
        inputBoxBorderColor: '#505053',
        inputStyle: {
            backgroundColor: '#333',
            color: 'silver'
        },
        labelStyle: {
            color: 'silver'
        }
    },

    navigator: {
        handles: {
            backgroundColor: '#666',
            borderColor: '#AAA'
        },
        outlineColor: '#CCC',
        maskFill: 'rgba(255,255,255,0.1)',
        series: {
            color: '#7798BF',
            lineColor: '#A6C7ED'
        },
        xAxis: {
            gridLineColor: '#505053'
        }
    },

    scrollbar: {
        barBackgroundColor: '#808083',
        barBorderColor: '#808083',
        buttonArrowColor: '#CCC',
        buttonBackgroundColor: '#606063',
        buttonBorderColor: '#606063',
        rifleColor: '#FFF',
        trackBackgroundColor: '#404043',
        trackBorderColor: '#404043'
    },

    // special colors for some of the
    legendBackgroundColor: 'rgba(0, 0, 0, 0.5)',
    background2: '#E0E0E8',
    dataLabelsColor: '#000',
    textColor: '#C0C0C0',
    contrastTextColor: '#F0F0F3',
    maskColor: 'rgba(255,255,255,0.3)'


};

