﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.planoDeGestaoController = (function() {
  function planoDeGestaoController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.salvar = bind(this.salvar, this);
    this.aoFechar = bind(this.aoFechar, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.setarMascaras = bind(this.setarMascaras, this);
    this.setarMascaras();
    this.configurarBinds();
  }

  planoDeGestaoController.prototype.setarMascaras = function() {
    return $("input[alt=integer_4]", this.contexto).setMask({
      autoTab: false
    });
  };

  planoDeGestaoController.prototype.configurarBinds = function() {
    $("#btn-Fechar").click(this.aoFechar);
    return $("#form-plano-de-gestao input", this.contexto).change(this.salvar);
  };

  planoDeGestaoController.prototype.aoFechar = function() {
    $("#plano-de-gestao-modal-container").html("");
    return PlanoDeGestao.reload();
  };

  planoDeGestaoController.prototype.salvar = function() {
    return $("#form-plano-de-gestao", this.contexto).submit();
  };

  return planoDeGestaoController;

})();
