﻿var dataToggle;

dataToggle = (function() {
  function dataToggle() {}

  dataToggle.enableDisable = function(elementoOrigem) {
    var checked, elem, itemsChecked, targetElem, targetSelector;
    elem = elementoOrigem;
    targetSelector = elem.attr("data-toggle-disabled");
    targetElem = $(targetSelector);
    checked = elem.attr("checked") === "checked";
    if ($('[data-toggle-disabled="' + targetSelector + '"]').length > 1) {
      itemsChecked = $('[data-toggle-disabled="' + targetSelector + '"]:checked');
      if (itemsChecked.length === 0 && (itemsChecked.attr("name") != null)) {
        checked = false;
      } else {
        checked = itemsChecked.length >= 1;
      }
    }
    if (checked) {
      targetElem.removeAttr("disabled");
    } else {
      targetElem.attr("disabled", "disabled");
    }
  };

  dataToggle.displayHide = function(elementoOrigem) {
    var checked, elem, itemsMarcados, targetElem, targetSelector;
    elem = elementoOrigem;
    elem.toggleClass("selecionado");
    targetSelector = elem.attr("data-toggle-display");
    targetElem = $(targetSelector);
    checked = elem.hasClass("selecionado");
    if ($('[data-toggle-display="' + targetSelector + '"]').length > 1) {
      itemsMarcados = $('[data-toggle-display="' + targetSelector + '"].selecionado');
      checked = itemsMarcados.length > 0;
    }
    targetElem.toggleClass("none", !checked);
  };

  dataToggle.updateBtnState = function(btn, input, updateRadios) {
    btn.toggleClass('active btn-warning', input.prop('checked'));
    btn.toggleClass('disabled', input.prop('disabled'));
    if (btn.attr("data-texto-active") !== void 0 && btn.attr("data-texto-inactive") !== void 0) {
      if (input.is(':checked')) {
        return btn.find('span').html(btn.attr('data-texto-active'));
      } else {
        return btn.find('span').html(btn.attr('data-texto-inactive'));
      }
    }
  };

  dataToggle.activateBtnToggle = function() {
    return $('.btn-toggle').each(function() {
      var btn, input;
      btn = $(this);
      input = btn.find('input');
      if ($.browser.msie && parseInt($.browser.version, 10) <= 8) {
        input.css('display', 'inline');
      }
      dataToggle.updateBtnState(btn, input);
    });
  };

  return dataToggle;

})();

$(function() {
  $(document).on("click", "[data-toggle-disabled]", function(e) {
    dataToggle.enableDisable($(this));
  });
  $(document).on("click", "[data-toggle-display]", function(e) {
    var evt, tag;
    evt = event || window.event;
    tag = evt.target.tagName || evt.srcElement.tagName;
    if (tag === 'A') {
      return;
    }
    dataToggle.displayHide($(this));
  });
  $('body').on('click.change.data-api', '[data-toggle="change"]', function(e) {
    var $target1, $target2, $this, targets;
    $this = $(this);
    targets = $this.attr('data-target').split(",");
    $target1 = $(targets[0]);
    $target2 = $(targets[1]);
    if ($target1.css("display") !== 'none') {
      $target1.hide();
      $target2.show();
    } else {
      $target2.hide();
      $target1.show().children(":input").focus();
    }
  });
  window.activateBtnToggle = dataToggle.activateBtnToggle;
  dataToggle.activateBtnToggle();
  $(document).on('change', '.btn-toggle input', function(e) {
    var btn, input, selector;
    input = $(e.target);
    if (input.is(':radio')) {
      selector = "input[type=radio][name='" + (input.attr('name')) + "']";
      $(selector).each(function() {
        var btn;
        input = $(this);
        btn = input.parents('.btn-toggle');
        dataToggle.updateBtnState(btn, input);
      });
    } else {
      btn = input.parents('.btn-toggle');
      dataToggle.updateBtnState(btn, input);
    }
  });
});
