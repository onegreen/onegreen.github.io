﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.iframeController = (function(superClass) {
  extend(iframeController, superClass);

  function iframeController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.recarregarTemplate = bind(this.recarregarTemplate, this);
    this.reload = bind(this.reload, this);
    this.excluirIframe = bind(this.excluirIframe, this);
    this.removerCartao = bind(this.removerCartao, this);
    this.editarCartao = bind(this.editarCartao, this);
    this.mostrarModalDeEdicao = bind(this.mostrarModalDeEdicao, this);
    this.ativarEventos = bind(this.ativarEventos, this);
    this.encontrarElementos = bind(this.encontrarElementos, this);
    iframeController.__super__.constructor.call(this, this.view, this.model, this.options);
  }

  iframeController.prototype.encontrarElementos = function() {
    iframeController.__super__.encontrarElementos.apply(this, arguments);
    this.IdDoPainel = $('#idDoPainel');
    return this.painelTemplate = $('#painel-template');
  };

  iframeController.prototype.ativarEventos = function() {
    iframeController.__super__.ativarEventos.apply(this, arguments);
    if (this.options.tipoSIMPart !== 'Relatorios') {
      return this.get(".js-RemoverCartao").unbind("click").bind("click", window.edicaoDashboard.tentarExcluirItem);
    }
  };

  iframeController.prototype.mostrarModalDeEdicao = function() {
    var ordem;
    ordem = $("#Item_" + this.options.IdDoItem).find('.js-ItemDeIndicador').length;
    if (this.options.tipoSIMPart !== 'Relatorios') {
      return $as.ReportSIM.Paineis.AdicionarIframe.get({
        idDoPainel: this.IdDoPainel.val(),
        referenciaNoTemplate: this.options.referenciaNoTemplate
      }).done((function(_this) {
        return function(html) {
          return $("#main-modal").html(html);
        };
      })(this));
    } else {
      return $as.ReportSIM.Relatorios.AdicionarIframe.get({
        idDoItem: this.options.IdDoItem,
        ordem: ordem,
        idDoRelatorio: this.options.Id
      }).done((function(_this) {
        return function(html) {
          return $("#main-modal").html(html);
        };
      })(this));
    }
  };

  iframeController.prototype.editarCartao = function(event) {
    var idDoIframe;
    idDoIframe = $(event.delegateTarget).data('idiframe');
    return $as.ReportSIM.Relatorios.EditarIframe.get({
      idDoItem: this.options.IdDoItem,
      idDoIframe: idDoIframe
    }).done((function(_this) {
      return function(html) {
        return $("#main-modal").html(html);
      };
    })(this));
  };

  iframeController.prototype.removerCartao = function(event) {
    return Confirmacao.mostrar(Resource.DesejaRealmenteExcluirEsteRegistro, (function(_this) {
      return function() {
        return _this.excluirIframe(event);
      };
    })(this));
  };

  iframeController.prototype.excluirIframe = function(event) {
    var idDoIframe;
    idDoIframe = $(event.delegateTarget).data('idiframe');
    return $as.ReportSIM.Relatorios.DeletarIframe.post({
      idDoItem: this.options.IdDoItem,
      idDoIframe: idDoIframe
    }).done((function(_this) {
      return function() {
        return _this.load();
      };
    })(this));
  };

  iframeController.prototype.reload = function() {
    edicaoDashboard.load();
    return this.load();
  };

  iframeController.prototype.recarregarTemplate = function() {
    return edicaoDashboard.reload();
  };

  return iframeController;

})(window.SIMPartsDeIndicador);
