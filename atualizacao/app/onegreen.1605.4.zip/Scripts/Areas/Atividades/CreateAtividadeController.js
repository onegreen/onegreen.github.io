﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.Atividades || (this.Atividades = {});

Atividades.CreateAtividadeController = (function() {
  CreateAtividadeController.prototype.id = 0;

  CreateAtividadeController.prototype.view = null;

  CreateAtividadeController.prototype.$view = null;

  function CreateAtividadeController(view) {
    this.view = view;
    this.marcarOpcaoUsuarioTerceiro = bind(this.marcarOpcaoUsuarioTerceiro, this);
    this.marcarOpcaoUsuarioDoSistema = bind(this.marcarOpcaoUsuarioDoSistema, this);
    this.configurarResponsavel = bind(this.configurarResponsavel, this);
    this.$view = $(this.view);
    this.id = this.$view.data('id');
    this.$view.data("controller", this);
    this.$view.css('z-index', ++window.WindowZIndex);
    setCombo(this.view, "#NomeDoExecutor");
    this.configurarResponsavel(this.id);
    this.ajustarDatePicker();
    this.btnTipoUsuario = $("#BotaoTipoUsuario", this.view).click(this.marcarOpcaoUsuarioDoSistema);
    this.btnTipoTerceiro = $("#BotaoTipoTerceiro", this.view).click(this.marcarOpcaoUsuarioTerceiro);
  }

  CreateAtividadeController.prototype.ajustarDatePicker = function() {
    $("#InicioPrevisto", this.view).datepicker({
      todayBtn: "linked",
      autoclose: true
    });
    $("#InicioPrevisto", this.view).change((function(_this) {
      return function() {
        if ($("#FimPrevisto", _this.view).val() === '') {
          return $("#FimPrevisto", _this.view).val($("#InicioPrevisto", _this.view).val());
        }
      };
    })(this));
    $("#FimPrevisto", this.view).datepicker({
      todayBtn: "linked",
      autoclose: true
    });
    $("#FimPrevisto", this.view).change((function(_this) {
      return function() {
        if ($("#InicioPrevisto", _this.view).val() === '') {
          return $("#InicioPrevisto", _this.view).val($("#FimPrevisto", _this.view).val());
        }
      };
    })(this));
  };

  CreateAtividadeController.prototype.configurarResponsavel = function(id) {
    this.responsavel = $('.js-nomeresponsavel', this.view);
    this.responsavel.unbind('click');
    if (id === 0 || id === void 0) {
      return setCombo(this.view, "#NomeDoResponsavel");
    }
  };

  CreateAtividadeController.prototype.marcarOpcaoUsuarioDoSistema = function() {
    this.btnTipoUsuario.addClass('btn-warning');
    this.btnTipoTerceiro.removeClass('btn-warning');
    $("#divUsuario", this.view).removeClass('none');
    $("#divUsuarioTerceiro", this.view).addClass('none');
    return $("#ResponsavelETerceiro", this.view).val(false);
  };

  CreateAtividadeController.prototype.marcarOpcaoUsuarioTerceiro = function() {
    this.btnTipoTerceiro.addClass('btn-warning');
    this.btnTipoUsuario.removeClass('btn-warning');
    $("#divUsuario", this.view).addClass('none');
    $("#divUsuarioTerceiro", this.view).removeClass('none');
    return $("#ResponsavelETerceiro", this.view).val(true);
  };

  return CreateAtividadeController;

})();
