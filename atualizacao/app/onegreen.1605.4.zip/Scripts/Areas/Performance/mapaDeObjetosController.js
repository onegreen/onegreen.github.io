﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.mapaDeObjetosController = (function() {
  function mapaDeObjetosController(contexto, opcoes, resources) {
    this.contexto = contexto;
    this.opcoes = opcoes;
    this.resources = resources;
    this.carregarGuide = bind(this.carregarGuide, this);
    this.vinculosDeDocumentos = bind(this.vinculosDeDocumentos, this);
    this.vinculosDoObjetivoEstrategico = bind(this.vinculosDoObjetivoEstrategico, this);
    this.atualizarMapasAcessiveis = bind(this.atualizarMapasAcessiveis, this);
    this.aoMarcarFavorito = bind(this.aoMarcarFavorito, this);
    this.marcarFavorito = bind(this.marcarFavorito, this);
    this.exibirDetalhesDoIndicador = bind(this.exibirDetalhesDoIndicador, this);
    this.ativarInformacoesDoIndicador = bind(this.ativarInformacoesDoIndicador, this);
    this.ativarDetalhesDoIndicadorDoObjetivoEstrategico = bind(this.ativarDetalhesDoIndicadorDoObjetivoEstrategico, this);
    this.ativarInformacoesDoObjetivoEstrategico = bind(this.ativarInformacoesDoObjetivoEstrategico, this);
    this.configurarComutadorDeOcorrenciaMensal = bind(this.configurarComutadorDeOcorrenciaMensal, this);
    this.configurarComutadorDeOcorrenciaDiaria = bind(this.configurarComutadorDeOcorrenciaDiaria, this);
    this.configurarComutadorDeOcorrenciaSemanal = bind(this.configurarComutadorDeOcorrenciaSemanal, this);
    this.configurarDatePickerMensal = bind(this.configurarDatePickerMensal, this);
    this.configurarDatePickerSemanal = bind(this.configurarDatePickerSemanal, this);
    this.configurarDatePickerDiario = bind(this.configurarDatePickerDiario, this);
    this.voltarParaVisualizacao = bind(this.voltarParaVisualizacao, this);
    this.filtrarFrequenciasAplicaveis = bind(this.filtrarFrequenciasAplicaveis, this);
    this.carregar = bind(this.carregar, this);
    this.comutarFrequencia = bind(this.comutarFrequencia, this);
    this.resize = bind(this.resize, this);
    this.aoExcluir = bind(this.aoExcluir, this);
    this.configurarSalvar = bind(this.configurarSalvar, this);
    this.aoExcluirObjeto = bind(this.aoExcluirObjeto, this);
    this.posicionarObjeto = bind(this.posicionarObjeto, this);
    this.dimensionarObjeto = bind(this.dimensionarObjeto, this);
    this.aoCriar = bind(this.aoCriar, this);
    this.configurarObjetos = bind(this.configurarObjetos, this);
    this.configurarVisualizacao = bind(this.configurarVisualizacao, this);
    this.configurarEdicao = bind(this.configurarEdicao, this);
    this.carregarBotaoAdicionar = bind(this.carregarBotaoAdicionar, this);
    this.alterarPlanoDeGestao = bind(this.alterarPlanoDeGestao, this);
    this.alterarUnidade = bind(this.alterarUnidade, this);
    $("#link-filtro-avancado", "#navbar-conteudo").hide();
    window.MarcarMenuSuperior("#lnkMapasDeObjetos");
    this.proximaOcorrencia;
    this.filtro = {};
    this.mapaContainer = $("#mapa-container", this.contexto);
    this.backgroundContainer = $("#background-container", this.contexto);
    this.idDoMapaAtual = $('#divCampos #idDoMapa', this.contexto);
    this.resize();
    this.resize();
    $(window).on('resize', this.resize);
    window.filtroUGEPlanoDeGestao.configurar('#filtro-ug-topo', this.alterarUnidade, this.alterarPlanoDeGestao);
    this.ativarInformacoesDoObjetivoEstrategico();
    this.ativarInformacoesDoIndicador();
    this.carregarBotaoAdicionar();
    this.carregarGuide();
    $("[rel=tooltip]").tooltip();
    $('#imgBackgroud', this.contexto).show();
  }

  mapaDeObjetosController.prototype.alterarUnidade = function(idDaUnidade) {
    return $.ajax({
      type: 'POST',
      url: $as.Performance.FiltroDeIndicadores.MudarUnidadeGerencial.url,
      data: {
        idDaUnidade: idDaUnidade
      },
      global: false,
      success: function(data) {
        return window.location = $as.Performance.Mapas.Index.url;
      }
    });
  };

  mapaDeObjetosController.prototype.alterarPlanoDeGestao = function(idDoPlanoDeGestao) {
    return $.ajax({
      type: 'POST',
      url: $as.Performance.FiltroDeIndicadores.MudarPlanoDeGestao.url,
      data: {
        idDoPlanoDeGestao: idDoPlanoDeGestao
      },
      global: false,
      success: function(data) {
        return window.location = $as.Performance.Mapas.Index.url;
      }
    });
  };

  mapaDeObjetosController.prototype.carregarBotaoAdicionar = function() {
    return $as.Performance.Mapas.BotaoAdicionarMapa.get().done((function(_this) {
      return function(data) {
        return $('#link-adicionar').html(data);
      };
    })(this));
  };

  mapaDeObjetosController.prototype.configurarEdicao = function() {
    this.formMapa = $("#form-mapa", this.contexto);
    this.botaoSelecionarBackground = $('#updload-imagem', this.contexto);
    this.botaoImagemDeFundo = $('#imagemDeFundo', this.contexto);
    this.botaoImagemDeFundo.on('change', (function(_this) {
      return function() {
        return _this.salvarBackground();
      };
    })(this));
    this.botaoSelecionarBackground.unbind('click').click((function(_this) {
      return function() {
        return _this.botaoImagemDeFundo.click();
      };
    })(this));
    this.configurarSalvar();
    this.configurarObjetos();
    return $("[rel=tooltip]").tooltip();
  };

  mapaDeObjetosController.prototype.configurarVisualizacao = function() {
    this.ComutadorDeFrequencia = $("#index-mapa .js-comutador-frequencia");
    this.ComutadorDeFrequencia.find("li").unbind('click').click(this.comutarFrequencia);
    $(".js-comutador-frequencia ul.dropdown-menu", this.contexto).addClass("pull-right");
    this.filtrarFrequenciasAplicaveis();
    if (this.opcoes.Frequencia === 'Mensal') {
      return this.configurarComutadorDeOcorrenciaMensal();
    } else if (this.opcoes.Frequencia === 'Semanal') {
      return this.configurarComutadorDeOcorrenciaSemanal();
    } else if (this.opcoes.Frequencia === 'Diaria') {
      return this.configurarComutadorDeOcorrenciaDiaria();
    }
  };

  mapaDeObjetosController.prototype.configurarObjetos = function() {
    var resizabeles;
    $('[data-toggle="popover"]').popover({
      delay: {
        show: 50,
        hide: 400
      }
    });
    $(".draggable").draggable({
      stop: (function(_this) {
        return function(event, ui) {
          return _this.posicionarObjeto(ui);
        };
      })(this),
      containment: this.contexto + " #container-imagem",
      scroll: true
    });
    resizabeles = $(".resizable");
    resizabeles.map((function(_this) {
      return function() {
        var minimoHeight, minimoWidth, objeto, salvarObjeto, ui;
        ui = $( this );
        objeto = $(".js-objeto", ui);
        minimoWidth = objeto.outerWidth();
        minimoHeight = objeto.outerHeight();
        salvarObjeto = false;
        if (minimoWidth > ui.width()) {
          ui.width(minimoWidth);
          salvarObjeto = true;
        }
        if (minimoHeight > ui.height()) {
          ui.height(minimoHeight);
          salvarObjeto = true;
        }
        if (salvarObjeto) {
          return _this.dimensionarObjeto(ui.data('id-objeto'), ui.width(), ui.height());
        }
      };
    })(this));
    return resizabeles.resizable({
      create: (function(_this) {
        return function(event, ui) {
          return $(".ui-resizable-e, .ui-resizable-s, .ui-icon-gripsmall-diagonal-se").hover(function() {
            return $(".popover").removeClass("in");
          });
        };
      })(this),
      stop: (function(_this) {
        return function(event, ui) {
          return _this.dimensionarObjeto(ui.element.data('id-objeto'), parseInt(ui.size.width), parseInt(ui.size.height));
        };
      })(this),
      resize: (function(_this) {
        return function(event, ui) {
          var height, minimoHeight, minimoWidth, objeto, width;
          objeto = $(".js-objeto", $(ui.element));
          width = ui.size.width;
          height = ui.size.height;
          minimoWidth = objeto.outerWidth();
          minimoHeight = objeto.outerHeight();
          if (minimoHeight > height) {
            ui.element.height(ui.size.height = minimoHeight);
          }
          if (minimoWidth > width) {
            return ui.element.width(ui.size.width = minimoWidth);
          }
        };
      })(this)
    });
  };

  mapaDeObjetosController.prototype.aoCriar = function(data) {
    return window.location = $as.Performance.Mapas.Edit.url + '/' + data.data.Id;
  };

  mapaDeObjetosController.prototype.salvarBackground = function() {
    var form;
    form = FileUpload.getFormData($("#FormUploadMapa", this.contexto));
    return $as.Performance.Mapas.Upload.postFormData(form).done((function(_this) {
      return function(data) {
        var $linkIndicador, $linkObjetivoEstrategico, urlAddIndicador, urlAddObjetivoEstrategico;
        $('#container-imagem', _this.contexto).html(data);
        $('#imgBackgroud', _this.contexto).fadeIn(1000);
        $('#item-link-indicador', _this.contexto).tooltip('destroy');
        $('#item-link-objetivo-estrategico', _this.contexto).tooltip('destroy');
        $linkIndicador = $(_this.contexto).find('#link-indicador');
        urlAddIndicador = $as.Performance.MapeamentosDeObjetos.AdicionarIndicador.url + '?idDoMapa=' + $linkIndicador.data('id-mapa');
        $linkIndicador.attr('href', urlAddIndicador);
        $linkObjetivoEstrategico = $(_this.contexto).find('#link-objetivo-estrategico');
        urlAddObjetivoEstrategico = $as.Performance.MapeamentosDeObjetos.AdicionarObjetivoEstrategico.url + '?idDoMapa=' + $linkObjetivoEstrategico.data('id-mapa');
        return $linkObjetivoEstrategico.attr('href', urlAddObjetivoEstrategico);
      };
    })(this));
  };

  mapaDeObjetosController.prototype.dimensionarObjeto = function(idObjeto, width, height) {
    var data;
    data = {
      id: idObjeto,
      largura: width,
      altura: height
    };
    return $as.Performance.MapeamentosDeObjetos.Dimensionar.post(data, {
      global: false
    }).done((function(_this) {
      return function(data) {};
    })(this));
  };

  mapaDeObjetosController.prototype.posicionarObjeto = function(ui) {
    var data;
    data = {
      id: ui.helper.data('id-objeto'),
      posicaoX: parseInt(ui.position.left),
      posicaoY: parseInt(ui.position.top)
    };
    return $as.Performance.MapeamentosDeObjetos.Posicionar.post(data, {
      global: false
    }).done((function(_this) {
      return function(data) {};
    })(this));
  };

  mapaDeObjetosController.prototype.reload = function(idDoMapa, animarItemAdicionado) {
    return $as.Performance.Mapas.Edit.get({
      id: idDoMapa
    }).done((function(_this) {
      return function(data) {
        $('#main').html(data);
        if (animarItemAdicionado) {
          return setTimeout(function() {
            return $('#background-container :last-child .objeto-popover', _this.contexto).append('<div class="new-map"><span /><span /><span /></div>');
          }, 200);
        }
      };
    })(this));
  };

  mapaDeObjetosController.prototype.aoExcluirObjeto = function(data) {
    return $("#objeto-" + data.data.Id).parent().remove();
  };

  mapaDeObjetosController.prototype.configurarSalvar = function() {
    $('input, textarea', this.formMapa).on("change", (function(_this) {
      return function(e) {
        var dados;
        dados = $('input, textarea', _this.formMapa).serialize();
        $as.Performance.Mapas.Edit.post(dados).done(function(data) {
          if (data.success) {
            return _this.reload(data.data.Id);
          } else {
            return $('#main').html(data);
          }
        });
      };
    })(this));
  };

  mapaDeObjetosController.prototype.aoExcluir = function(data) {
    return window.location = $as.Performance.Mapas.Index.url;
  };

  mapaDeObjetosController.prototype.resize = function() {
    return this.backgroundContainer.css({
      width: $(window).width() - parseInt(this.mapaContainer.css('margin-left')),
      height: $(window).height() - parseInt(this.mapaContainer.css('margin-top'))
    });
  };

  mapaDeObjetosController.prototype.comutarFrequencia = function(event) {
    var $elemento, formaDeVisualizacao, frequencia;
    $elemento = $(event.delegateTarget);
    frequencia = $elemento.data('frequencia');
    formaDeVisualizacao = $elemento.data('visualizacao');
    $("#frequencia", "#divCampos").val(frequencia);
    $("#tipo", "#divCampos").val(formaDeVisualizacao);
    return this.carregar();
  };

  mapaDeObjetosController.prototype.carregar = function() {
    this.filtro = {
      id: $('#idDoMapa', '#divCampos').val(),
      Frequencia: $('#frequencia', '#divCampos').val(),
      Tipo: $('#tipo', '#divCampos').val(),
      ocorrencia: $('#ocorrencia', "#divCampos").val(),
      proxima: this.proximaOcorrencia
    };
    return $as.Performance.Mapas.Mapa.get(this.filtro).done(function(data) {
      return $("#main").html(data);
    });
  };

  mapaDeObjetosController.prototype.filtrarFrequenciasAplicaveis = function() {
    if (!this.opcoes.FrequenciasAplicaveis.Mensal) {
      this.ComutadorDeFrequencia.find("li[data-frequencia='Mensal']").remove();
    }
    if (!this.opcoes.FrequenciasAplicaveis.Semanal) {
      this.ComutadorDeFrequencia.find("li[data-frequencia='Semanal']").remove();
    }
    if (!this.opcoes.FrequenciasAplicaveis.Diaria) {
      return this.ComutadorDeFrequencia.find("li[data-frequencia='Diaria']").remove();
    }
  };

  mapaDeObjetosController.prototype.voltarParaVisualizacao = function() {
    return $as.Performance.Mapas.Mapa.get(this.filtro).done(function(data) {
      return $("#main").html(data);
    });
  };

  mapaDeObjetosController.prototype.configurarDatePickerDiario = function() {
    var onChangeFunction;
    onChangeFunction = (function(_this) {
      return function() {
        $("#ocorrencia", _this.contexto).val($("#DataDoFiltro", _this.contexto).val());
        return _this.carregar();
      };
    })(this);
    return $('#date-picker-diario-farol', this.contexto).click((function(_this) {
      return function() {
        return DatePickerCustom.setDatePickerCustom('date-picker-diario-farol', 'comutador-frequencia-container', 'DataDoFiltro', onChangeFunction, $('#DataDoFiltro').val(), _this.opcoes.DataInicioLimite, _this.opcoes.DataFinalLimite);
      };
    })(this));
  };

  mapaDeObjetosController.prototype.configurarDatePickerSemanal = function() {
    var onChangeFunction;
    onChangeFunction = (function(_this) {
      return function() {
        $("#ocorrencia", _this.contexto).val($("#DataDoFiltro", _this.contexto).val());
        return _this.carregar();
      };
    })(this);
    return $('#date-picker-semanal-farol', this.contexto).click((function(_this) {
      return function() {
        return DatePickerCustom.setDatePickerCustom('date-picker-semanal-farol', 'comutador-frequencia-container', 'DataDoFiltro', onChangeFunction, $('#DataDoFiltro').val(), _this.opcoes.DataInicioLimite, _this.opcoes.DataFinalLimite, true);
      };
    })(this));
  };

  mapaDeObjetosController.prototype.configurarDatePickerMensal = function() {
    var onChangeFunction;
    onChangeFunction = (function(_this) {
      return function() {
        $("#ocorrencia", _this.contexto).val($("#DataDoFiltro", _this.contexto).val());
        return _this.carregar();
      };
    })(this);
    return $('#date-picker-mensal', this.contexto).click((function(_this) {
      return function() {
        return DatePickerCustom.setDatePickerCustom('date-picker-mensal', 'comutador-frequencia-container', 'DataDoFiltro', onChangeFunction, $('#DataDoFiltro').val(), _this.opcoes.DataInicioLimite, _this.opcoes.DataFinalLimite, false, 'months');
      };
    })(this));
  };

  mapaDeObjetosController.prototype.configurarComutadorDeOcorrenciaSemanal = function() {
    $("#proximaSemana", this.contexto).click((function(_this) {
      return function(e) {
        _this.proximaOcorrencia = 1;
        return _this.carregar();
      };
    })(this));
    $("#semanaAnterior", this.contexto).click((function(_this) {
      return function() {
        _this.proximaOcorrencia = -1;
        return _this.carregar();
      };
    })(this));
    return this.configurarDatePickerSemanal();
  };

  mapaDeObjetosController.prototype.configurarComutadorDeOcorrenciaDiaria = function() {
    $("#proximoDia", this.contexto).click((function(_this) {
      return function(e) {
        _this.proximaOcorrencia = 1;
        return _this.carregar();
      };
    })(this));
    $("#diaAnterior", this.contexto).click((function(_this) {
      return function() {
        _this.proximaOcorrencia = -1;
        return _this.carregar();
      };
    })(this));
    return this.configurarDatePickerDiario();
  };

  mapaDeObjetosController.prototype.configurarComutadorDeOcorrenciaMensal = function() {
    $("#proximoMes", this.contexto).click((function(_this) {
      return function(e) {
        _this.proximaOcorrencia = 1;
        return _this.carregar();
      };
    })(this));
    $("#mesAnterior", this.contexto).click((function(_this) {
      return function() {
        _this.proximaOcorrencia = -1;
        return _this.carregar();
      };
    })(this));
    return this.configurarDatePickerMensal();
  };

  mapaDeObjetosController.prototype.ativarInformacoesDoObjetivoEstrategico = function() {
    return $('div[data-objetivo-estrategico]').on("click", (function(_this) {
      return function(event) {
        var $el, idDoMapeamento;
        $el = $(event.delegateTarget);
        idDoMapeamento = $el.data("objetivo-estrategico");
        _this.filtro = {
          idDoMapeamento: idDoMapeamento,
          Frequencia: $('#frequencia', '#divCampos').val(),
          Tipo: $('#tipo', '#divCampos').val(),
          ocorrencia: $('#ocorrencia', "#divCampos").val(),
          proxima: _this.proximaOcorrencia
        };
        return $as.Performance.MapeamentosDeObjetos.IndicadoresDoObjetivoEstrategico.get(_this.filtro).success(function(data) {
          $("#main-modal").html(data);
          return $('a.js-exibir-detalhes-indicador').click(_this.ativarDetalhesDoIndicadorDoObjetivoEstrategico);
        });
      };
    })(this));
  };

  mapaDeObjetosController.prototype.ativarDetalhesDoIndicadorDoObjetivoEstrategico = function(event) {
    var idDoIndicador;
    idDoIndicador = $(event.delegateTarget).data('idindicador');
    return this.exibirDetalhesDoIndicador(idDoIndicador);
  };

  mapaDeObjetosController.prototype.ativarInformacoesDoIndicador = function() {
    return $('div[data-indicador]').on("click", (function(_this) {
      return function(event) {
        var $el, idDoMapeamento;
        $el = $(event.delegateTarget);
        idDoMapeamento = $el.data("indicador");
        return $as.Performance.MapeamentosDeObjetos.IndicadorDoMapeamento.get({
          idDoMapeamento: idDoMapeamento,
          frequenciaCorrente: $('#Filtro_Frequencia').val()
        }).success(function(data) {
          if (data.success) {
            return _this.exibirDetalhesDoIndicador(data.idDoIndicador);
          }
        });
      };
    })(this));
  };

  mapaDeObjetosController.prototype.exibirDetalhesDoIndicador = function(idDoIndicador) {
    return Results.api.exibirDetalhesPorIdDoIndicador(idDoIndicador, $("#DataDoFiltro", this.contexto).val(), $("#Filtro_Frequencia", this.contexto).val());
  };

  mapaDeObjetosController.prototype.marcarFavorito = function() {
    var parent;
    $('#marcarFavorito i', this.contexto).toggleClass('fa-star-o').toggleClass('fa-star').toggleClass('c-laranja');
    if ($('#marcarFavorito i', this.contexto).hasClass('fa-star')) {
      parent = $('#marcarFavorito i', this.contexto).parent();
      return parent.attr('data-original-title', parent.data('desmarcar-favorito'));
    } else {
      parent = $('#marcarFavorito i', this.contexto).parent();
      return parent.attr('data-original-title', parent.data('marcar-favorito'));
    }
  };

  mapaDeObjetosController.prototype.aoMarcarFavorito = function(data) {
    if (data.success) {
      this.marcarFavorito(data);
      return this.atualizarMapasAcessiveis();
    }
  };

  mapaDeObjetosController.prototype.atualizarMapasAcessiveis = function() {
    return $as.Performance.Mapas.MapasAcessiveis.post({
      idDoMapaAtual: this.idDoMapaAtual.val()
    }).done((function(_this) {
      return function(data) {
        return $('#menu-mapas-acessiveis', _this.contexto).replaceWith(data);
      };
    })(this));
  };

  mapaDeObjetosController.prototype.vinculosDoObjetivoEstrategico = function(e, id) {
    e.stopPropagation();
    return $as.Performance.MapeamentosDeObjetos.VinculosDoObjetivoEstrategico.get({
      idDoMapeamento: id
    }).done(function(html) {
      return $("#main-modal").html(html);
    });
  };

  mapaDeObjetosController.prototype.vinculosDeDocumentos = function(e, el, id, idAgregador) {
    e.stopPropagation();
    return Results.api.carregarDocumentosMapaDeObjetos(el, id, idAgregador);
  };

  mapaDeObjetosController.prototype.carregarGuide = function() {
    return window.guide.defineOffsetTop(400);
  };

  return mapaDeObjetosController;

})();
