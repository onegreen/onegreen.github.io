﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.itens3GeracoesController = (function() {
  var Excluir, IdDoItem;

  IdDoItem = 0;

  Excluir = "";

  function itens3GeracoesController() {
    this.ExcluirItem3Geracoes = bind(this.ExcluirItem3Geracoes, this);
    this.ExcluirPlanoDeRecuperacao3Geracoes = bind(this.ExcluirPlanoDeRecuperacao3Geracoes, this);
    this.Excluir3Geracoes = bind(this.Excluir3Geracoes, this);
    var IdDoPai;
    $("[rel=tooltip]").tooltip();
    this.CarregarComboMes();
    this.CarregarComboPerspectiva();
    IdDoPai = this.idDoPai;
  }

  itens3GeracoesController.prototype.ApagarPlanoDeRecuperacao = function(idDoItem, excluir) {
    IdDoItem = idDoItem;
    Excluir = excluir;
    return $('#modalConfirmarJavascript').modal('show');
  };

  itens3GeracoesController.prototype.ApagarItem3Geracoes = function(idDoItem, excluir) {
    IdDoItem = idDoItem;
    Excluir = excluir;
    return $('#modalConfirmarJavascript').modal('show');
  };

  itens3GeracoesController.prototype.Excluir3Geracoes = function() {
    if (Excluir === "ExcluirPlanoDeRecuperacao3Geracoes") {
      return this.ExcluirPlanoDeRecuperacao3Geracoes(this.IdDoItem);
    } else {
      return this.ExcluirItem3Geracoes(this.IdDoItem);
    }
  };

  itens3GeracoesController.prototype.ExcluirPlanoDeRecuperacao3Geracoes = function() {
    return $as.EPM.Itens3Geracoes.ExcluirPlanoDeRecuperacao.get({
      idDoItem: IdDoItem
    }).success((function(_this) {
      return function(data) {
        return $("#PlanoDeRecuperacao-tresgeracoes-" + IdDoItem).html(data);
      };
    })(this));
  };

  itens3GeracoesController.prototype.ExcluirItem3Geracoes = function() {
    return $as.EPM.Itens3Geracoes.ExcluirItem3Geracoes.get({
      idDoItem: IdDoItem,
      idDoPai: $("#idDoPai").val(),
      data: $("#MesSelecionado").val()
    }).success((function(_this) {
      return function(data) {
        return $("#itens-tresgeracoes-" + $("#idDoPai").val()).html(data);
      };
    })(this));
  };

  itens3GeracoesController.prototype.RecarregarItens = function() {
    return $as.EPM.Itens3Geracoes.CarregarItens.get({
      idDoPai: $("#idDoPai").val(),
      data: $("#MesSelecionado").val()
    }).success((function(_this) {
      return function(data) {
        $("#itens-tresgeracoes-" + $("#idDoPai").val()).html(data);
        return _this.CarregarComboPerspectiva();
      };
    })(this));
  };

  itens3GeracoesController.prototype.RecarregarItensReadOnly = function() {
    return $as.EPM.Itens3Geracoes.ItemReadOnly.get({
      idDoPai: $("#idDoPai").val(),
      data: $("#MesSelecionado").val()
    }).success((function(_this) {
      return function(data) {
        return $("#itens-tresgeracoes-" + $("#idDoPai").val()).html(data);
      };
    })(this));
  };

  itens3GeracoesController.prototype.AdicionarItem = function(idDoPai) {
    if ($("#PerspectivaSelecionada").val() !== "") {
      return $as.EPM.Itens3Geracoes.AdicionarItem.get({
        idDoPai: $("#idDoPai").val(),
        perspectiva: $("#PerspectivaSelecionada").val(),
        data: $("#MesSelecionado").val()
      }).success((function(_this) {
        return function(data) {
          $("#itens-tresgeracoes-" + $("#idDoPai").val()).html(data);
          $("#PerspectivaSelecionada").val("");
          $("#ComboPerspectiva").val("");
          return $("#AdicionarItem3G").addClass("disabled");
        };
      })(this));
    }
  };

  itens3GeracoesController.prototype.CarregarComboPerspectiva = function() {
    var $combo, $divCombo;
    $combo = $("#ComboPerspectiva", this.contexto);
    $divCombo = $combo.parents("div.autocompleter");
    return $combo.autocompleter($divCombo.attr("data-url"), {
      parameters: {
        idDoPai: $("#idDoPai").val(),
        mesSelecionado: $("#MesSelecionado").val()
      },
      mesSelecionado: $("#MesSelecionado").val(),
      loadOnDemand: true,
      elementToClick: "#ComboPerspectivaBtn",
      keyElement: "#PerspectivaSelecionada",
      onSelected: (function(_this) {
        return function(valueInput) {
          if ($("#PerspectivaSelecionada").val() !== "") {
            return $("#AdicionarItem3G").removeClass("disabled");
          }
        };
      })(this)
    });
  };

  itens3GeracoesController.prototype.CarregarComboMes = function() {
    var $combo, $divCombo;
    $combo = $("#ComboMes", this.contexto);
    $divCombo = $combo.parents("div.autocompleter");
    return $combo.autocompleter($divCombo.attr("data-url"), {
      parameters: {
        idDoPai: $("#idDoPai").val()
      },
      loadOnDemand: false,
      elementToClick: "#ComboMesBtn",
      keyElement: "#MesSelecionado",
      onSelected: (function(_this) {
        return function(valueInput) {
          if ($combo.parents().attr("readOnly")) {
            return _this.RecarregarItensReadOnly();
          } else {
            return _this.RecarregarItens();
          }
        };
      })(this)
    });
  };

  itens3GeracoesController.prototype.CarregarComboMesDoVinculo = function() {
    var $combo, $divCombo;
    $combo = $("#VinculoComboMes", this.contexto);
    $divCombo = $combo.parents("div.autocompleter");
    return $combo.autocompleter($divCombo.attr("data-url"), {
      loadOnDemand: false,
      elementToClick: "#VinculoComboMesBtn",
      keyElement: "#idDoItemSelecionado",
      onSelected: (function(_this) {
        return function(valueInput) {
          return _this.CarregarAtividadesDoPlanoDeRecuperacao(valueInput.val());
        };
      })(this)
    });
  };

  itens3GeracoesController.prototype.CarregarAtividadesDoPlanoDeRecuperacao = function(idDoItem) {
    return $as.EPM.Itens3Geracoes.ListarAtividadesDoPlanoDeRecuperacao.get({
      idDoItem: idDoItem
    }).success((function(_this) {
      return function(data) {
        return $("#atividades-plano-recuperacao").html(data);
      };
    })(this));
  };

  itens3GeracoesController.prototype.SalvarItem3Geracoes = function() {
    return $("#salvar_item").click();
  };

  return itens3GeracoesController;

})();
