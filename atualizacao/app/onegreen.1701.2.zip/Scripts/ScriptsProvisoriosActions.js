﻿var UsuarioParticipante;
var PlanoDeAcaoMelhorias
var UrlImprimirPlanoComunicacao;
var UrlImprimirPlanoAcao;
var UrlImprimirRisco;
var idFerramenta = 0;
var idPasso = 0;

function scriptsProvisoriosActions(usuarioParticipante, planoDeAcaoMelhorias, urlImprimirPlanoComunicacao, urlImprimirPlanoAcao, urlImprimirRisco) {
    UsuarioParticipante = usuarioParticipante;
    PlanoDeAcaoMelhorias = planoDeAcaoMelhorias;
    UrlImprimirPlanoComunicacao = urlImprimirPlanoComunicacao;
    UrlImprimirPlanoAcao = urlImprimirPlanoAcao;
    UrlImprimirRisco = urlImprimirRisco;

    $('[data-spy="scroll"]').each(function () {
        var $spy = $(this).scrollspy('refresh')
    });
}

function ApagarFerramenta(idPas, idFer) {
    idFerramenta = idFer;
    idPasso = idPas;
    $('#modalConfirmarJavascript').modal('show');
}

function ExcluirFerramenta() {
    $as.Ferramentas.ExcluirFerramenta.get({
        idPasso: idPasso,
        idFerramenta: idFerramenta
    })
}

function RecarregarFerramentas(id, abrirFerramenta) {
    $as.Ferramentas.Ferramentas.get({
        idPasso: id,
        participante: UsuarioParticipante
    }).success(function (data) {
        $('#ferramentas-container-' + id).html(data);
        if (abrirFerramenta) {
            var link = $('[id ^= anchor-fer]:last', '#ferramentas-container-' + id)
            link.click();
            setTimeout(function () { $(window).scrollTop(link.offset().top - 120); }, 500)
        }
    });
}

function RecarregarFerramentasEAbrirEspecifica(id, idDaFerramenta) {
    $as.Ferramentas.Ferramentas.get({
        idPasso: id,
        participante: UsuarioParticipante
    }).success(function (data) {
        $('#ferramentas-container-' + id).html(data);
        if (abrirFerramenta) {
            var link = $('#anchor-fer-' + idDaFerramenta, '#ferramentas-container-' + id)
            link.click();
            setTimeout(function () { $(window).scrollTop(link.offset().top - 120); }, 500)
        }
    });
}

function AlterarNomeDaFerramenta(idFerramenta) {
    $as.Ferramentas.AlterarNomeFerramenta.get({
        idFerramenta: idFerramenta,
        updateTargetId: 'alterar-ferramenta-modal-container'
    }).success(function (data) {
        $("#alterar-ferramenta-modal-container").html(data);
    });
}

function AplicarCronograma(idProjeto) {
    $as.EPM.Projetos.AplicarCronograma.get({
        idProjeto: idProjeto,
        updateTargetId: 'aplicar-cronograma-modal-container'
    }).success(function (data) {
        $("#aplicar-cronograma-modal-container").html(data);
    });
}

function MoverFerramentaParaCima(idFerramenta) {
    $as.Ferramentas.MoverFerramentaParaCima.get({ idFerramenta: idFerramenta });
}

function MoverFerramentaParaBaixo(idFerramenta) {
    $as.Ferramentas.MoverFerramentaParaBaixo.get({ idFerramenta: idFerramenta });
}

function AlterarDivNomeFerramenta(idFerramenta, nome) {
    $('#span-nome-ferramenta-' + idFerramenta).text(nome);
}

function AbrirModalAdicionarPlanoAcao(id) {
    $as.Ferramentas.AdicionarPlanoAcao.get({
        idPasso: id,
        updateTargetId: 'addPlanoAcao-modal-container',
        origemPlanoDeAcao: PlanoDeAcaoMelhorias
    }).success(function (data) {
        window.GetDiv("addPlanoAcao-modal-container").html(data);
    });
}

function AbrirModalAdicionarDocumento(id) {
    $as.Ferramentas.AdicionarDocumento.get({
        idPasso: id,
        updateTargetId: 'addDocumento-modal-container'
    }).success(function (data) {
        window.GetDiv("addDocumento-modal-container").html(data);
    });
}

function AbrirModalEditarDocumento(idDocumento) {
    $as.Ferramentas.EditarDocumento.get({
        id: idDocumento,
        updateTargetId: 'addDocumento-modal-container'
    }).success(function (data) {
        window.GetDiv("addDocumento-modal-container").html(data);
    });
}

function AbrirModalAdicionarPlanoDeRecuperacao(id) {
    var idDiv = 'createEditPlanoDeRecuPeracao';

    $as.Ferramentas.AdicionarPlanoDeRecuperacao.get({
        idPasso: id,
        updateTargetId: idDiv
    }).success(function (data) {
        window.GetDiv(idDiv).html(data);
    });
}

function AbrirModalEditarPlanoDeRecuperacao(id) {
    var idDiv = 'createEditPlanoDeRecuPeracao';

    $as.Ferramentas.EditarPlanoDeRecuperacao.get({
        idPasso: id,
        updateTargetId: idDiv
    }).success(function (data) {
        window.GetDiv(idDiv).html(data);
    });
}

function AbrirModalAdicionarBrainstorming(id) {
    $as.Ferramentas.AdicionarBrainstorming.get({
        idPasso: id,
        updateTargetId: 'addBrainstorming-modal-container'
    }).success(function (data) {
        window.GetDiv("addBrainstorming-modal-container").html(data);
    });
}

function AbrirModalAdicionarAnaliseDePareto(id) {
    $as.Ferramentas.AdicionarAnaliseDePareto.get({
        idPasso: id,
        updateTargetId: 'addAnaliseDePareto-modal-container'
    }).success(function (data) {
        window.GetDiv("addAnaliseDePareto-modal-container").html(data);
    });
}

function AbrirModalAdicionarAlbumDeFotos(idDoPasso) {
    $as.Ferramentas.AdicionarAlbumDeFotos.get({
        idDoPasso: idDoPasso
    }).success(function (data) {
        window.GetDiv("addAlbumDeFotos-modal-container").html(data);
    });
}

function AbrirModalAdicionarCincoPorques(idDoPasso) {
    $as.Ferramentas.AdicionarCincoPorques.get({
        idDoPasso: idDoPasso
    }).success(function (data) {
        window.GetDiv("addCincoPorques-modal-container").html(data);
    });
}

function AbrirModalAdicionarCausaEEfeito(idDoPasso, idDaSolucao) {
    $as.Ferramentas.AdicionarCausaEEfeito.get({
        idDoPasso: idDoPasso,
        idDaSolucaoDeProblema: idDaSolucao
    }).success(function (data) {
        window.GetDiv("addCausaEEfeito-modal-container").html(data);
    });
}

function AbrirModalAdicionarGraficoDeIndicador(idDoPasso) {
    $as.Melhorias.FerramentaGraficosDeIndicador.AdicionarFerramentaDeGraficos.get({
        idDoPasso: idDoPasso,
    }).success(function (data) {
        window.GetDiv("addGraficosDeIndicador-modal-container").html(data);
    });
}

function AbrirModalAdicionarGraficoDeIndicador30(idDoPasso) {
    $as.Melhorias.FerramentaGraficoDeIndicador30.CreateFerramentaGraficoDeIndicador30.get({
        idDoPasso: idDoPasso,
    }).success(function (data) {
        window.GetDiv("addGraficosDeIndicador-modal-container").html(data);
    });
}

function ConfigurarImpressaoFerramentaComunicacao() {
    $('#ImprimirPlanoComunicacao').click(function (e) {
        window.location.href = UrlImprimirPlanoComunicacao;
    });

    $('#ImprimirPlanoAcao').click(function (e) {
        window.location.href = UrlImprimirPlanoAcao;
    });

    $('#ImprimirRisco').click(function (e) {
        window.location.href = UrlImprimirRisco;
    });
}