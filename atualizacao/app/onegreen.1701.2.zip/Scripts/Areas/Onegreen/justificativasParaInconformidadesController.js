﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.JustificativasParaInconformidadesController = (function() {
  function JustificativasParaInconformidadesController(opcoes) {
    this.opcoes = opcoes;
    this.retornarLicenciamentosPorJustificativa = bind(this.retornarLicenciamentosPorJustificativa, this);
    this.abrirGraficoAtual = bind(this.abrirGraficoAtual, this);
    this.toogleGraficoJustificativa = bind(this.toogleGraficoJustificativa, this);
    $('#PossibilidadeComprometimento-Sim, #PossibilidadeComprometimento-Nao', this.opcoes.Contexto).unbind('change').bind('change', this.toogleGraficoJustificativa);
    this.abrirGraficoAtual(this.opcoes.TipoJustificativa);
  }

  JustificativasParaInconformidadesController.prototype.toogleGraficoJustificativa = function(event) {
    var input;
    input = $(event.delegateTarget);
    if (!input.closest('label').hasClass('active')) {
      return this.abrirGraficoAtual(input.val());
    }
  };

  JustificativasParaInconformidadesController.prototype.abrirGraficoAtual = function(tipoDeInconformidade) {
    var dados;
    $("#TipoJustificativa", this.opcoes.Contexto).val(tipoDeInconformidade);
    dados = $('#containerFiltroAvancado, #tipo-justificativa-container').find('input').serialize();
    return $as.Onegreen.GraficosEstatisticos.RetornarGraficoJustificativasParaInconformidades.get(dados).success((function(_this) {
      return function(data) {
        var divTipoHide, divTipoShow;
        if (tipoDeInconformidade === _this.opcoes.ComPossibilidadeDeComprometimentoDePrazo) {
          divTipoShow = $('.js-possibilidade-container');
          divTipoHide = $('.js-comprometido-container');
        } else {
          divTipoShow = $('.js-comprometido-container');
          divTipoHide = $('.js-possibilidade-container');
        }
        divTipoShow.html(data);
        divTipoShow.show();
        divTipoHide.html("");
        return divTipoHide.hide();
      };
    })(this));
  };

  JustificativasParaInconformidadesController.prototype.retornarLicenciamentosPorJustificativa = function(idDaJustificativa) {
    var dados;
    $("#Justificativa", "#possibilidade-comprometimento-container").val(idDaJustificativa);
    dados = $('#containerFiltroAvancado, #possibilidade-comprometimento-container').find('input').serialize();
    return $as.Onegreen.GraficosEstatisticos.RetornarDetalhesJustificativasDeInconformidades.get(dados).success((function(_this) {
      return function(data) {
        window.GetDiv('justificativasdeinconformidades-modal-container').html(data);
        return $('#justificativasdeinconformidades-modal').window();
      };
    })(this));
  };

  return JustificativasParaInconformidadesController;

})();
