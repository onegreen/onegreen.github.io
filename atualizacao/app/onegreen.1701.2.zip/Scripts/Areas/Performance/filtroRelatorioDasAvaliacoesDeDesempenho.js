﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.filtroRelatorioDasAvaliacoesDeDesempenho = (function() {
  function filtroRelatorioDasAvaliacoesDeDesempenho(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.aoSelecionarRelatorio = bind(this.aoSelecionarRelatorio, this);
    this.loadDropDownTipoDeRelatorio();
    $(this.contexto).window({
      minheight: 200
    });
  }

  filtroRelatorioDasAvaliacoesDeDesempenho.prototype.loadDropDownTipoDeRelatorio = function() {
    return setDropDown(this.contexto, '#TipoDeRelatorioDeAvaliacaoDesempenho-dropdown', this.aoSelecionarRelatorio);
  };

  filtroRelatorioDasAvaliacoesDeDesempenho.prototype.aoSelecionarRelatorio = function() {
    return $as.Performance.AvaliacoesDeDesempenho.FiltroRelatorioDasAvaliacoesDeDesempenho.get({
      idDoCiclo: $(this.contexto).find("#IdDoCiclo").val(),
      tipoDeRelatorio: $(this.contexto).find("#TipoDeRelatorio").val(),
      avaliacaoDeChefia: $(this.contexto).find("#AvaliacaoDeChefia").val(),
      IdDaUnidadeGerencial: $(this.contexto).find("#IdDaUnidadeGerencial").val(),
      UnidadeGerencialNome: $(this.contexto).find("#UnidadeGerencialNome").val()
    }).done((function(_this) {
      return function(html) {
        var $html, botoes;
        $html = $(html);
        botoes = $html.find("#botoes-container");
        $html.find("#botoes-container").remove();
        $(_this.contexto).find("#filtro-relatorio-content").html($html);
        return $(_this.contexto).find('.modal-footer').html(botoes.html());
      };
    })(this));
  };

  return filtroRelatorioDasAvaliacoesDeDesempenho;

})();
