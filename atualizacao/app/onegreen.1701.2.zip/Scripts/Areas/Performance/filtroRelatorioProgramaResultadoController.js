﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.filtroRelatorioProgramaResultadoController = (function() {
  function filtroRelatorioProgramaResultadoController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.changeDatePickerDate = bind(this.changeDatePickerDate, this);
    this.eventoChangeDatePickerDate = bind(this.eventoChangeDatePickerDate, this);
    this.datepicker = bind(this.datepicker, this);
    $(this.contexto).window({
      width: '400px'
    });
    this.datepicker();
  }

  filtroRelatorioProgramaResultadoController.prototype.datepicker = function() {
    var dataDoFiltro, idioma, mesInicio, meses;
    dataDoFiltro = $('#btnDataDoFiltro', this.contexto).datepicker({
      startDate: new Date(this.options.Ano, 0, 1),
      endDate: new Date(this.options.Ano, 11, 31),
      defaultDate: new Date(this.options.Ano, this.options.Mes - 1, 1),
      changeMonth: true,
      changeYear: false,
      showButtonPanel: true,
      autoclose: true,
      minViewMode: 1,
      startView: 1
    });
    idioma = dataDoFiltro.data('datepicker').language;
    meses = $.fn.datepicker.dates[idioma].months;
    mesInicio = meses[this.options.Mes - 1];
    $("#dataDoFiltroLabel", this.contexto).text(mesInicio);
    return dataDoFiltro.off('changeDate').on('changeDate', this.eventoChangeDatePickerDate);
  };

  filtroRelatorioProgramaResultadoController.prototype.eventoChangeDatePickerDate = function(ev) {
    var botao, hidden, label, lng, month, months, newDate;
    botao = $(ev.currentTarget);
    lng = botao.data('datepicker').language;
    newDate = new Date(ev.date);
    newDate.setDate(newDate.getDate() + 1);
    label = botao.data('label');
    hidden = botao.data('hidden');
    months = $.fn.datepicker.dates[lng].months;
    month = months[newDate.getMonth()];
    return this.changeDatePickerDate(month, label, hidden, newDate.toLocaleDateString(lng), newDate.getMonth() + 1);
  };

  filtroRelatorioProgramaResultadoController.prototype.changeDatePickerDate = function(texto, label, hidden, valor, mes) {
    $("#" + label, this.contexto).text(texto);
    $("#" + hidden, this.contexto).val(valor);
    $("#Mes").val(mes);
    return $('.datepicker').hide();
  };

  return filtroRelatorioProgramaResultadoController;

})();
