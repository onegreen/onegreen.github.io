﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.modeloDeGraficoController = (function(superClass) {
  extend(modeloDeGraficoController, superClass);

  function modeloDeGraficoController(view, opcoes) {
    this.view = view;
    this.opcoes = opcoes;
    this.setarLabelsDosEixos = bind(this.setarLabelsDosEixos, this);
    this.salvar = bind(this.salvar, this);
    this.atualizarHabilitarEstiloDasSecoes = bind(this.atualizarHabilitarEstiloDasSecoes, this);
    this.definirCorDePreenchimento = bind(this.definirCorDePreenchimento, this);
    this.definirCorDoFarol = bind(this.definirCorDoFarol, this);
    this.alterarEixoY = bind(this.alterarEixoY, this);
    this.alterarApresentarRotulo = bind(this.alterarApresentarRotulo, this);
    this.alterarApresentarNaLegenda = bind(this.alterarApresentarNaLegenda, this);
    this.start = bind(this.start, this);
    this.defineColorPicker = bind(this.defineColorPicker, this);
    this.defineIdDaSecao = bind(this.defineIdDaSecao, this);
    this.alterarTipo = bind(this.alterarTipo, this);
    modeloDeGraficoController.__super__.constructor.call(this, this.view, null);
    this.chart = null;
    this.idModelo = this.get('#Id').val();
    this.containerModeloDeGrafico = this.get('#container-modelo-grafico');
    this.detalhesGraficoContainer = this.get('#detalhes-grafico-container');
    this.corDeFundo = this.get('#CorDeFundo');
    this.opcoesModelo = this.get('#opcoes-modelo');
    this.opcoesTipo = this.get('#opcoes-tipo');
    this.start();
    if (series.length) {
      this.opcoesTipo.find('label').attr('disabled', 'disabled');
    }
    (this.get('input')).change(this.start);
    (this.get('[rel=tooltip]')).tooltip();
    (this.get('.js-formato')).click(function() {
      $('.js-formato').removeClass('active');
      return $(this).addClass('active');
    });
    (this.get('#ulthemes')).find('a').click((function(_this) {
      return function(e) {
        _this.corDeFundo.val($(e.currentTarget).data('theme'));
        return _this.corDeFundo.change();
      };
    })(this));
    this.opcoesModelo.find('label').click(function() {
      return $('#secoes-container', this.view).find('#Estilo').val($(this).data('estilo'));
    });
    this.opcoesTipo.find('input:radio').change(this.alterarTipo);
  }

  modeloDeGraficoController.prototype.alterarTipo = function(e) {
    var tipo;
    tipo = $(e.currentTarget).val();
    $as.Manutencao.ModelosDeGrafico.AlterarTipo.post({
      id: this.idModelo,
      tipo: tipo
    });
    return this.get('#close-selecionar-origem, #btn-cancelar-secao').click();
  };

  modeloDeGraficoController.prototype.defineIdDaSecao = function($el) {
    return this.idDaSecao = $el.closest('td').find('#IdSecao').val();
  };

  modeloDeGraficoController.prototype.defineColorPicker = function(elemento, exibirOpcaoFarol) {
    $(elemento).colorpicker({
      showOn: "button",
      history: false,
      displayIndicator: false,
      exibirOpcaoFarol: exibirOpcaoFarol,
      onClickCoresDoFarol: (function(_this) {
        return function() {
          return setTimeout(_this.definirCorDoFarol, 500);
        };
      })(this)
    }).on('change.color', (function(_this) {
      return function(evt, color) {
        return setTimeout(function() {
          return _this.definirCorDePreenchimento(color, 500);
        }, 50);
      };
    })(this));
    (this.get('#secoes-table')).find('[class*=evo-colorind]').each((function(_this) {
      return function() {
        var $parent;
        $parent = $( this ).closest('td');
        if ($parent.find('.js-cores-farol').length) {
          return $( this ).hide();
        }
      };
    })(this));
    (this.get('[class*=evo-colorind]')).click((function(_this) {
      return function() {
        return _this.defineIdDaSecao($( this ));
      };
    })(this));
    return (this.get('.js-cores-farol')).click((function(_this) {
      return function() {
        return _this.defineIdDaSecao($( this ));
      };
    })(this));
  };

  modeloDeGraficoController.prototype.start = function() {
    var config, ref, ref1, stacking;
    this.get('.cor-grafico').each((function(_this) {
      return function(index, elemento) {
        var exibirOpcaoFarol;
        exibirOpcaoFarol = $(elemento).data('estilo') !== 'spline';
        return _this.defineColorPicker(elemento, exibirOpcaoFarol);
      };
    })(this));
    stacking = null;
    if ((this.get('#EstiloDasSecoes-Acumulativo')).is(':checked')) {
      stacking = 'normal';
    }
    if ((this.get('#EstiloDasSecoes-Percentual')).is(':checked')) {
      stacking = 'percent';
    }
    config = ModelosDeGrafico.api.getConfig({
      temFarol: true,
      showGriX: (ref = (this.get('input[name=ExibirGradeNoEixoX]')).is(':checked')) != null ? ref : {
        1: 0
      },
      showGriY: (ref1 = (this.get('input[name=ExibirGradeNoEixoY]')).is(':checked')) != null ? ref1 : {
        1: 0
      },
      nomeEixoY1: (this.get('#NomeDoEixoY1')).val(),
      nomeEixoY2: (this.get('#NomeDoEixoY2')).val(),
      titulo: (this.get('#Nome')).val(),
      bgColor: (this.get('#CorDeFundo')).val(),
      unit: '$ x 1000',
      stacking: stacking,
      type: (this.get('#chartType')).val(),
      legendaAbaixo: (this.get('input[name=PosicaoDaLegenda]:checked')).val(),
      plotBand: {
        color: "#FCFFC5",
        from: '',
        to: ''
      }
    });
    if ((this.chart != null) && this.containerModeloDeGrafico.is(':visible')) {
      this.chart.destroy();
    }
    if (series.length) {
      this.detalhesGraficoContainer.show();
      this.containerModeloDeGrafico.show();
      this.opcoesTipo.find('label').attr('disabled', 'disabled');
      this.opcoesModelo.find('label').attr('disabled', 'disabled');
      return this.chart = ModelosDeGrafico.api.build(this.containerModeloDeGrafico, config, series);
    } else {
      this.detalhesGraficoContainer.hide();
      this.containerModeloDeGrafico.hide();
      this.opcoesTipo.find('label').removeAttr('disabled');
      return this.opcoesModelo.find('label').removeAttr('disabled');
    }
  };

  modeloDeGraficoController.prototype.alterarApresentarNaLegenda = function(id) {
    return $as.Manutencao.Secoes.AlterarApresentarNaLegenda.post({
      idDaSecao: id
    }).done((function(_this) {
      return function(data) {
        if (data.success) {
          return Secao.reload();
        }
      };
    })(this));
  };

  modeloDeGraficoController.prototype.alterarApresentarRotulo = function(id) {
    return $as.Manutencao.Secoes.AlterarApresentarRotulo.post({
      idDaSecao: id
    }).done((function(_this) {
      return function(data) {
        if (data.success) {
          return Secao.reload();
        }
      };
    })(this));
  };

  modeloDeGraficoController.prototype.alterarEixoY = function(id, eixoY) {
    return $as.Manutencao.Secoes.AlterarEixoY.post({
      idDaSecao: id,
      eixoY: eixoY
    }).done((function(_this) {
      return function(data) {
        if (data.success) {
          return Secao.reload();
        }
      };
    })(this));
  };

  modeloDeGraficoController.prototype.definirCorDoFarol = function(cor) {
    return $as.Manutencao.Secoes.DefinirCorDoFarol.post({
      idDaSecao: this.idDaSecao
    }).done((function(_this) {
      return function(data) {
        if (data.success) {
          return Secao.reload();
        }
      };
    })(this));
  };

  modeloDeGraficoController.prototype.definirCorDePreenchimento = function(cor) {
    return $as.Manutencao.Secoes.DefinirCorDePreenchimento.post({
      idDaSecao: this.idDaSecao,
      cor: cor
    }).done((function(_this) {
      return function(data) {
        if (data.success) {
          return Secao.reload();
        }
      };
    })(this));
  };

  modeloDeGraficoController.prototype.atualizarHabilitarEstiloDasSecoes = function(idDoModelo) {
    return $as.Manutencao.ModelosDeGrafico.AtualizarHabilitarEstiloDasSecoes.get({
      idDoModelo: idDoModelo
    }).done((function(_this) {
      return function(json) {
        if (json.habilitarEstilo === false) {
          return $('label', $("#estilo-secoes-container")).attr('disabled', 'disabled');
        } else {
          return $('label', $("#estilo-secoes-container")).removeAttr('disabled');
        }
      };
    })(this));
  };

  modeloDeGraficoController.prototype.salvar = function() {
    return $as.Manutencao.ModelosDeGrafico.Edit.post($('#formModeloDeGraficos').serialize()).done((function(_this) {
      return function(data) {
        if (data.success) {
          return window.location = $as.Manutencao.ModelosDeGrafico.Index.url;
        } else {
          return $('#main').html(data);
        }
      };
    })(this));
  };

  modeloDeGraficoController.reload = function() {
    return $as.Manutencao.ModelosDeGrafico.Index.get().done(function(data) {
      return $('#main').html(data);
    });
  };

  modeloDeGraficoController.prototype.setarLabelsDosEixos = function() {
    var eixo1, eixo2;
    eixo1 = this.get('.js-eixos:first .js-eixo1').text().trim();
    eixo2 = this.get('.js-eixos:first .js-eixo2').text().trim();
    this.get('#labelEixo1').text(this.opcoes.recursosEixos[eixo1]);
    return this.get('#labelEixo2').text(this.opcoes.recursosEixos[eixo2]);
  };

  return modeloDeGraficoController;

})(window.baseController);
