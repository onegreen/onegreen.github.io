﻿window.areasDeResultadoController = (function() {
  function areasDeResultadoController() {
    $("[data-moverareaderesultadoparacima]a").click(this.moverAreaDeResultadoParaCima);
    $("[data-moverareaderesultadoparabaixo]a").click(this.moverAreaDeResultadoParaBaixo);
  }

  areasDeResultadoController.prototype.moverAreaDeResultadoParaCima = function() {
    return $as.AreasDeResultado.MoverParaCima.post({
      idDaAreaDeResultado: $(this).data("moverareaderesultadoparacima")
    }).success((function(_this) {
      return function(data) {
        return $("#main").html(data);
      };
    })(this));
  };

  areasDeResultadoController.prototype.moverAreaDeResultadoParaBaixo = function() {
    return $as.AreasDeResultado.MoverParaBaixo.post({
      idDaAreaDeResultado: $(this).data("moverareaderesultadoparabaixo")
    }).success((function(_this) {
      return function(data) {
        return $("#main").html(data);
      };
    })(this));
  };

  areasDeResultadoController.aoSalvar = function(data) {
    switch (data.data.FormaDeSalvar) {
      case "Salvar":
        areasDeResultadoController.reload();
        return $('#main-modal').empty();
      case "SalvarEAdicionarNovo":
        areasDeResultadoController.reload();
        return $as.AreasDeResultado.Create.get().done(function(data) {
          return $("#main-modal").html(data);
        });
      case "SalvarEAdicionarDetalhes":
        areasDeResultadoController.reload();
        return $as.AreasDeResultado.Edit.get({
          id: data.data.Id
        }).done(function(data) {
          return $("#main-modal").html(data);
        });
    }
  };

  areasDeResultadoController.reload = function() {
    return $as.AreasDeResultado.Index.get().done(function(data) {
      return $("#main").html(data);
    });
  };

  return areasDeResultadoController;

})();
