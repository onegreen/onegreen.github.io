﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.itemDaFormulaController = (function(superClass) {
  extend(itemDaFormulaController, superClass);

  function itemDaFormulaController(view, options) {
    this.view = view;
    this.options = options;
    this.aoSalvar = bind(this.aoSalvar, this);
    this.configurarCombos = bind(this.configurarCombos, this);
    this.comboIndicador;
    this.comboUnidade;
    this.comboOrigem;
    this.configurarCombos();
    $('#close-modal-createedititemformula').click((function(_this) {
      return function() {
        return window.ItemDaFormula.reload();
      };
    })(this));
  }

  itemDaFormulaController.prototype.configurarCombos = function() {
    var onSelectUG, parameters;
    this.comboOrigem = setCombo(this.view, "#Origem_Nome");
    onSelectUG = (function(_this) {
      return function(input) {
        var disable;
        disable = $(input).val() === '';
        _this.comboIndicador.reset();
        return _this.comboIndicador.disableElseEnable(disable);
      };
    })(this);
    this.comboUnidade = setCombo(this.view, '#UnidadeGerencial_SiglaAtual', onSelectUG);
    parameters = {
      idUnidadeGerencial: (function(_this) {
        return function() {
          return _this.comboUnidade.value();
        };
      })(this)
    };
    this.comboIndicador = Results.api.setComboIndicador(this.view, '#Indicador_Nome', null, parameters);
    if (this.comboIndicador) {
      return this.comboIndicador.disableElseEnable(this.comboUnidade.value() === '');
    }
  };

  itemDaFormulaController.prototype.aoSalvar = function(data) {
    return window.ItemDaFormula.reload();
  };

  return itemDaFormulaController;

})(window.baseController);
