﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.camposComplementaresController = (function() {
  var contexto;

  function camposComplementaresController() {
    this.carregarComboTipoDaNaoConformidade = bind(this.carregarComboTipoDaNaoConformidade, this);
    this.carregarComboAcidentePessoal = bind(this.carregarComboAcidentePessoal, this);
    this.carregarComboIdentificadorDoLocal = bind(this.carregarComboIdentificadorDoLocal, this);
    this.carregarComboIdentificadorDaClassificacaoDaInteracao = bind(this.carregarComboIdentificadorDaClassificacaoDaInteracao, this);
    this.carregarComboComunidadeResponsavelInteracao = bind(this.carregarComboComunidadeResponsavelInteracao, this);
    this.carregarComboIdentificadorDeTurno = bind(this.carregarComboIdentificadorDeTurno, this);
    this.carregarComboAgenteCausador = bind(this.carregarComboAgenteCausador, this);
    this.carregarComboIdentificadorDaTurma = bind(this.carregarComboIdentificadorDaTurma, this);
    this.carregarComboClassificacaoDoAcidente = bind(this.carregarComboClassificacaoDoAcidente, this);
    this.carregarComboPotencialDeGravidade = bind(this.carregarComboPotencialDeGravidade, this);
    this.carregarComboClassificacaoDoProjeto = bind(this.carregarComboClassificacaoDoProjeto, this);
    this.carregarComboClassificacaoDoProjeto();
    this.carregarComboPotencialDeGravidade();
    this.carregarComboClassificacaoDoAcidente();
    this.carregarComboIdentificadorDaTurma();
    this.carregarComboAgenteCausador();
    this.carregarComboIdentificadorDeTurno();
    this.carregarComboComunidadeResponsavelInteracao();
    this.carregarComboIdentificadorDaClassificacaoDaInteracao();
    this.carregarComboIdentificadorDoLocal();
    this.carregarComboAcidentePessoal();
    this.carregarComboTipoDaNaoConformidade();
  }

  contexto = "#janelaProjeto";

  camposComplementaresController.prototype.carregarComboClassificacaoDoProjeto = function() {
    return setCombo(contexto, "#ClassificacaoDoProjetoNome");
  };

  camposComplementaresController.prototype.carregarComboPotencialDeGravidade = function() {
    return setCombo(contexto, "#PotencialDeGravidade_Gravidade");
  };

  camposComplementaresController.prototype.carregarComboClassificacaoDoAcidente = function() {
    return setCombo(contexto, "#ClassificacaoDoAcidente_Nome");
  };

  camposComplementaresController.prototype.carregarComboIdentificadorDaTurma = function() {
    return setCombo(contexto, "#IdentificadorDaTurma_Nome");
  };

  camposComplementaresController.prototype.carregarComboAgenteCausador = function() {
    return setCombo(contexto, "#AgenteCausador_Nome");
  };

  camposComplementaresController.prototype.carregarComboIdentificadorDeTurno = function() {
    return setCombo(contexto, "#IdentificadorDeTurno_Nome");
  };

  camposComplementaresController.prototype.carregarComboComunidadeResponsavelInteracao = function() {
    return setCombo(contexto, "#ComunidadeResponsavelInteracao_Nome");
  };

  camposComplementaresController.prototype.carregarComboIdentificadorDaClassificacaoDaInteracao = function() {
    return setCombo(contexto, "#IdentificadorDaClassificacaoDaInteracao_Nome");
  };

  camposComplementaresController.prototype.carregarComboIdentificadorDoLocal = function() {
    return setCombo(contexto, "#IdentificadorDoLocal_Nome");
  };

  camposComplementaresController.prototype.carregarComboAcidentePessoal = function() {
    return setCombo(contexto, "#AcidentePessoalNome");
  };

  camposComplementaresController.prototype.carregarComboTipoDaNaoConformidade = function() {
    return setCombo(contexto, "#TipoDaNaoConformidadeNome");
  };

  return camposComplementaresController;

})();
