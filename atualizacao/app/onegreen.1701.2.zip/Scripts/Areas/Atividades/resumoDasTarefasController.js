﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.Atividades || (this.Atividades = {});

Atividades.resumoDasTarefasController = (function() {
  function resumoDasTarefasController(contexto, resource) {
    this.contexto = contexto;
    this.resource = resource;
    this.configurarScrollDoFiltro = bind(this.configurarScrollDoFiltro, this);
    this.loadComboResponsavel = bind(this.loadComboResponsavel, this);
    this.loadComboEmpreendimento = bind(this.loadComboEmpreendimento, this);
    this.loadComboTipoDeLicenca = bind(this.loadComboTipoDeLicenca, this);
    this.loadComboTipologia = bind(this.loadComboTipologia, this);
    this.loadComboLegislacao = bind(this.loadComboLegislacao, this);
    this.aoSelecionarLegislacao = bind(this.aoSelecionarLegislacao, this);
    this.loadComboEndereco = bind(this.loadComboEndereco, this);
    this.loadComboUnidade = bind(this.loadComboUnidade, this);
    this.listarTarefas = bind(this.listarTarefas, this);
    this.configurarDatePickers = bind(this.configurarDatePickers, this);
    this.montarSeries = bind(this.montarSeries, this);
    this.montarCategorias = bind(this.montarCategorias, this);
    this.plotarGrafico = bind(this.plotarGrafico, this);
    this.configurarGrafico = bind(this.configurarGrafico, this);
    this.esconderAcoesDoTopo = bind(this.esconderAcoesDoTopo, this);
    this.loadCombos = bind(this.loadCombos, this);
    this.loadCombos();
    this.configurarDatePickers();
    this.esconderAcoesDoTopo();
    this.configurarScrollDoFiltro();
    $(window).resize((function(_this) {
      return function() {
        return _this.configurarScrollDoFiltro();
      };
    })(this));
    $("#marcar-todos", "#container-selecao-de-planos-de-acao").click(this.marcarTodosOsPlanosDeAcao);
    $("#desmarcar-todos", "#container-selecao-de-planos-de-acao").click(this.desmarcarTodosOsPlanosDeAcao);
    $(".js-grafico-das-tarefas", "#tabela-do-resumo-das-acoes").click(this.configurarGrafico);
    $("input[name='radio-tipo-de-grafico']", "#modal-de-graficos").change(function() {
      return $(".js-grafico-percentual-ou-quantidade").toggle(1000);
    });
    $('[rel="tooltip"]').tooltip();
    $("#menu-superior li").removeClass("active");
  }

  resumoDasTarefasController.prototype.loadCombos = function() {
    this.loadComboUnidade();
    this.loadComboEndereco();
    this.loadComboLegislacao();
    this.loadComboTipoDeLicenca();
    this.loadComboEmpreendimento();
    this.loadComboResponsavel();
    if ($("#NomeDaTipologia", this.contexto).val() !== "") {
      return this.loadComboTipologia();
    }
  };

  resumoDasTarefasController.prototype.esconderAcoesDoTopo = function() {
    $('#filtro-ug-topo').hide();
    $('#link-filtro-avancado').hide();
    return $('#link-adicionar').hide();
  };

  resumoDasTarefasController.prototype.configurarGrafico = function(e) {
    var categorias, options, series;
    options = $(e.delegateTarget).data("options");
    categorias = this.montarCategorias(options);
    series = this.montarSeries(options);
    this.plotarGrafico(options, categorias, series, "#grafico-percentual", "percent");
    this.plotarGrafico(options, categorias, series, "#grafico-quantidade", "column");
    return $("#modal-de-graficos").window({
      width: 620
    });
  };

  resumoDasTarefasController.prototype.plotarGrafico = function(options, categories, series, container, stacking) {
    var config;
    config = ModelosDeGrafico.api.getConfig({
      categories: categories,
      showGriX: 1,
      showGriY: 1,
      nomeEixoY1: '',
      nomeEixoY2: '',
      titulo: options.titulo,
      bgColor: 'default',
      unit: '',
      stacking: stacking,
      type: 'column',
      legendaAbaixo: '',
      tooltipNotShared: true
    });
    return ModelosDeGrafico.api.build(container, config, series);
  };

  resumoDasTarefasController.prototype.montarCategorias = function(options) {
    var categorias;
    categorias = [this.resource.Planejadas, this.resource.EmExecucao, this.resource.Finalizadas];
    return categorias;
  };

  resumoDasTarefasController.prototype.montarSeries = function(options) {
    var series;
    series = [
      {
        name: this.resource.NoPrazo,
        data: [
          {
            y: options.planejadas.noPrazo,
            descricao: options.planejadas.noPrazo,
            name: this.resource.NoPrazo
          }, {
            y: options.emExecucao.noPrazo,
            descricao: options.emExecucao.noPrazo,
            name: this.resource.NoPrazo
          }, {
            y: options.finalizada.noPrazo,
            descricao: options.finalizada.noPrazo,
            name: this.resource.NoPrazo
          }
        ],
        color: "#7cbc29",
        type: "column",
        yAxis: 1
      }, {
        name: this.resource.Atrasadas,
        color: "#e31b23",
        data: [
          {
            y: options.planejadas.atrasadas,
            descricao: options.planejadas.atrasadas,
            name: this.resource.Atrasadas
          }, {
            y: options.emExecucao.atrasadas,
            descricao: options.emExecucao.atrasadas,
            name: this.resource.Atrasadas
          }, {
            y: options.finalizada.atrasadas,
            descricao: options.finalizada.atrasadas,
            name: this.resource.Atrasadas
          }
        ],
        type: "column",
        yAxis: 1
      }, {
        name: this.resource.Total,
        data: [
          {
            y: 0,
            descricao: '',
            name: this.resource.Planejadas
          }, {
            y: 0,
            descricao: '',
            name: this.resource.EmExecucao
          }, {
            y: 0,
            descricao: '',
            name: this.resource.Finalizadas
          }
        ],
        type: "column",
        showInLegend: false,
        yAxis: 1
      }
    ];
    return series;
  };

  resumoDasTarefasController.prototype.configurarDatePickers = function() {
    $("#DataInicialParaFiltrarPeriodo", this.contexto).datepicker();
    return $("#DataFinalParaFiltrarPeriodo", this.contexto).datepicker();
  };

  resumoDasTarefasController.prototype.listarTarefas = function(json) {
    return $as.Atividades.ResumoDasTarefas.ObterListagemDasTarefas.post(json).success((function(_this) {
      return function(data) {
        $("#main-modal").html(data);
      };
    })(this));
  };

  resumoDasTarefasController.prototype.loadComboUnidade = function() {
    return setCombo(this.contexto, "#NomeDaUnidadeGerencial", null);
  };

  resumoDasTarefasController.prototype.loadComboEndereco = function() {
    return setCombo(this.contexto, "#NomeDoEndereco");
  };

  resumoDasTarefasController.prototype.aoSelecionarLegislacao = function(input) {
    $("#IdDaTipologia", this.contexto).val('');
    $("#NomeDaTipologia", this.contexto).val('');
    return this.loadComboTipologia(input.val());
  };

  resumoDasTarefasController.prototype.loadComboLegislacao = function() {
    $("#NomeDaTipologia", this.contexto).attr("disabled", "disabled");
    $("#NomeDaTipologiaBtn", this.contexto).attr("disabled", "disabled");
    $("#NomeDaLegislacaoAmbiental", this.contexto).change((function(_this) {
      return function() {
        if ($("#NomeDaLegislacaoAmbiental", _this.contexto).val() === '') {
          $("#NomeDaTipologia", _this.contexto).attr("disabled", "disabled");
          return $("#NomeDaTipologiaBtn", _this.contexto).attr("disabled", "disabled");
        }
      };
    })(this));
    return setCombo(this.contexto, "#NomeDaLegislacaoAmbiental", this.aoSelecionarLegislacao);
  };

  resumoDasTarefasController.prototype.loadComboTipologia = function(ideLegislacao) {
    var parametros;
    $("#NomeDaTipologia", this.contexto).removeAttr("disabled");
    $("#NomeDaTipologiaBtn", this.contexto).removeAttr("disabled");
    parametros = {
      ideLegislacao: ideLegislacao
    };
    return setCombo(this.contexto, "#NomeDaTipologia", null, parametros);
  };

  resumoDasTarefasController.prototype.loadComboTipoDeLicenca = function() {
    return setCombo(this.contexto, "#NomeDoTipoDeLicenca");
  };

  resumoDasTarefasController.prototype.loadComboEmpreendimento = function() {
    return setCombo(this.contexto, "#NomeDoEmpreendimento");
  };

  resumoDasTarefasController.prototype.loadComboResponsavel = function() {
    return setCombo(this.contexto, "#NomeDoUsuarioResponsavel");
  };

  resumoDasTarefasController.prototype.marcarTodosOsPlanosDeAcao = function() {
    return $("input", "#container-selecao-de-planos-de-acao").prop("checked", true);
  };

  resumoDasTarefasController.prototype.desmarcarTodosOsPlanosDeAcao = function() {
    return $("input", "#container-selecao-de-planos-de-acao").prop("checked", false);
  };

  resumoDasTarefasController.prototype.configurarScrollDoFiltro = function() {
    var alturaMaximaDoFiltro;
    alturaMaximaDoFiltro = $(window).height() - ($("#navbar-conteudo").innerHeight());
    return $(".coluna-calendario-agenda", this.contexto).css({
      'max-height': alturaMaximaDoFiltro + 'px',
      'overflow-x': 'hidden',
      'overflow-y': 'auto'
    });
  };

  return resumoDasTarefasController;

})();
