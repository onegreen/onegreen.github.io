﻿this.Notificacoes || (this.Notificacoes = {});

Notificacoes.api = (function() {
  function api() {}

  api.removerItem = function(id) {
    var $item;
    $item = $('#notificacao-' + id);
    $item.remove();
    return api.atualizarNotificacoes();
  };

  api.removerItemSemAtualizar = function(id) {
    var $item, $liFirstDivider, $liSecondDivider;
    $item = $('#notificacao-' + id);
    $liFirstDivider = $item.next();
    $liSecondDivider = $liFirstDivider.next();
    $item.remove();
    $liFirstDivider.remove();
    return $liSecondDivider.remove();
  };

  api.excluirTodas = function() {
    return $as.NotificacoesDoUsuario.Notificacoes.ExcluirTodas.post().done(function() {
      $('#quantidade-notificacoes').text('');
      $('#quantidade-notificacoes').hide();
      return api.atualizarNotificacoes();
    });
  };

  api.excluirNotificacao = function(id) {
    return $as.NotificacoesDoUsuario.Notificacoes.Excluir.post({
      id: id
    }).done(function(dados) {
      if (dados.quantidade) {
        $('#quantidade-notificacoes').text(dados.quantidade);
        $('#quantidade-notificacoes').show();
      } else {
        $('#quantidade-notificacoes').text('');
        $('#quantidade-notificacoes').hide();
      }
      return api.removerItem(id);
    });
  };

  api.atualizarNotificacoes = function() {
    $('.notificacoes').html('');
    return api.carregarNotificacoes();
  };

  api.habilitarDesabilitarOpcoes = function() {
    if ($('.sem-notificacao').length) {
      return $('.opcoesNotificacao').hide();
    } else {
      return $('.opcoesNotificacao').show();
    }
  };

  api.carregarNotificacoes = function(abrirNotificacoes) {
    if ($('.notificacoes').html() === '') {
      $as.NotificacoesDoUsuario.Notificacoes.ListarAtivasDoUsuarioAtual.get({
        skip: 0,
        take: 10
      }).done(function(html) {
        $('#notificacoes').find('#separador').html(html);
        $('#VerMaisNotificacoes').click(function(e) {
          return e.stopPropagation();
        });
        $('.js-ExcluirNotificacao').click(function(e) {
          return e.stopPropagation();
        });
        api.habilitarDesabilitarOpcoes();
        return api.exibirBotaoVerMais();
      });
    }
    if (abrirNotificacoes) {
      api.habilitarDesabilitarOpcoes();
      return $('#menuNotificacoes').closest('li').addClass('open');
    }
  };

  api.carregarMaisNotificacoes = function() {
    var skip;
    skip = $('#notificacoes').find('.js-notificacao').length;
    return $as.NotificacoesDoUsuario.Notificacoes.ListarAtivasDoUsuarioAtual.get({
      skip: skip,
      take: 10
    }).done(function(html) {
      var notificacoes;
      notificacoes = $(html).filter('li:not(.js-semRegistros)');
      if (notificacoes.lenth > 0 && skip === 0) {
        $('#notificacoes #separador').html(notificacoes);
      } else {
        $('#notificacoes #separador').append(notificacoes);
      }
      $('#VerMaisNotificacoes').click(function(e) {
        return e.stopPropagation();
      });
      $('.js-ExcluirNotificacao').click(function(e) {
        return e.stopPropagation();
      });
      api.habilitarDesabilitarOpcoes();
      return api.exibirBotaoVerMais();
    });
  };

  api.exibirBotaoVerMais = function() {
    var quantidadeCarregada, quantidadeTotal;
    if ($('#quantidade-notificacoes').text() !== '') {
      quantidadeTotal = parseInt($('#quantidade-notificacoes').text());
      quantidadeCarregada = $('#notificacoes').find('li').length;
      if (quantidadeTotal > quantidadeCarregada) {
        return $('#VerMaisNotificacoes').show();
      } else {
        return $('#VerMaisNotificacoes').hide();
      }
    } else {
      return $('#VerMaisNotificacoes').hide();
    }
  };

  api.atualizaContadorPeriodicamente = function(el, e, naoAtualizar) {
    if (e) {
      if (e.stopPropagation && e.preventDefault) {
        e.stopPropagation();
        e.preventDefault();
      } else {
        e.cancelBubble = true;
      }
    }
    $.ajax({
      url: $('#menuNotificacoes').attr('href'),
      type: 'get',
      global: false,
      success: function(dados) {
        var quantidadeAtual;
        noInternet.hide();
        quantidadeAtual = $('#quantidade-notificacoes').text();
        if (dados.quantidade) {
          $('#quantidade-notificacoes').text(dados.quantidade);
          $('#quantidade-notificacoes').show();
        } else {
          $('#quantidade-notificacoes').text('');
          $('#quantidade-notificacoes').hide();
        }
        if ($('.notificacoes').is(':visible') && quantidadeAtual !== $('#quantidade-notificacoes').text()) {
          $('.notificacoes').html('');
          api.carregarNotificacoes();
        } else if ($('.notificacoes').is(':hidden') && quantidadeAtual !== $('#quantidade-notificacoes').text()) {
          $('.notificacoes').html('');
        }
        if (!naoAtualizar) {
          return setTimeout(window.Notificacoes.api.atualizaContadorPeriodicamente, 30000);
        }
      },
      error: window.jqAjaxError
    });
  };

  api.fecharNotificaoes = function() {
    return $('#fechar-notificacoes').closest('li').removeClass('open');
  };

  api.linkDiretoNotificao = function(data) {
    if (data.EhAjax) {
      return $.ajax({
        url: data.Link,
        success: function(html) {
          return $(data.UpdateTarget).html(html);
        }
      });
    } else {
      return window.location.href = data.Link;
    }
  };

  return api;

})();

$(function() {
  return window.Notificacoes.api.atualizaContadorPeriodicamente();
});
