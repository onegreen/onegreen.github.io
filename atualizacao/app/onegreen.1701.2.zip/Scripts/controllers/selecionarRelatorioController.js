﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.selecionarRelatorioController = (function() {
  function selecionarRelatorioController(contexto) {
    var $idUnidade;
    this.contexto = contexto;
    this.selecionarRelatorio = bind(this.selecionarRelatorio, this);
    this.desabilitarCampos = bind(this.desabilitarCampos, this);
    this.carregarRelatorio = bind(this.carregarRelatorio, this);
    this.carregarComboDeUnidades = bind(this.carregarComboDeUnidades, this);
    this.loadCombos = bind(this.loadCombos, this);
    $(this.contexto).window();
    $idUnidade = null;
    this.loadCombos();
    $('#btnSelecionarRelatorio', this.contexto).on('click', (function(_this) {
      return function() {
        return _this.selecionarRelatorio();
      };
    })(this));
  }

  selecionarRelatorioController.prototype.loadCombos = function() {
    return this.carregarComboDeUnidades();
  };

  selecionarRelatorioController.prototype.carregarComboDeUnidades = function() {
    var onSelectUnidade;
    onSelectUnidade = (function(_this) {
      return function() {
        return _this.carregarRelatorio();
      };
    })(this);
    return setCombo(this.contexto, "#SiglaDaUnidade", onSelectUnidade);
  };

  selecionarRelatorioController.prototype.carregarRelatorio = function() {
    return $as.PainelUnificado.CarregarRelatorios.get({
      idUnidade: $('#IdDaUnidade', this.contexto).val()
    }).success((function(_this) {
      return function(data) {
        return $('#selecaoDeRelatorio-container').html(data);
      };
    })(this));
  };

  selecionarRelatorioController.prototype.desabilitarCampos = function() {
    $("#SiglaDaUnidade", this.contexto).val('');
    $("#IdDaUnidade", this.contexto).val('');
    return $("#SiglaDaUnidade", this.contexto).data('autocompleter');
  };

  selecionarRelatorioController.prototype.selecionarRelatorio = function() {
    var idRelatorio;
    idRelatorio = $('[name=IdRelatorio]:checked', this.contexto).val();
    return $as.PainelUnificado.AplicarVisaoPainelDesempenho.post({
      IdRelatorio: idRelatorio
    }).success((function(_this) {
      return function(data) {
        $('#desempenho').html(data);
        return $('#close-modal-selecionarrelatorio').click();
      };
    })(this));
  };

  return selecionarRelatorioController;

})();
