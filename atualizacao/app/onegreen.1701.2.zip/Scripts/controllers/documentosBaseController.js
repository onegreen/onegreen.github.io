﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.documentosBaseController = (function() {
  function documentosBaseController(options) {
    var idAgregador, idDocumento;
    this.options = options;
    this.excluirDocumento = bind(this.excluirDocumento, this);
    this.recarregarDocumentos = bind(this.recarregarDocumentos, this);
    this.abrirModalEditarDocumento = bind(this.abrirModalEditarDocumento, this);
    this.abrirModalAdicionarDocumento = bind(this.abrirModalAdicionarDocumento, this);
    idAgregador = null;
    idDocumento = null;
  }

  documentosBaseController.prototype.criarDivNoBody = function(idDiv) {
    if ($('#' + idDiv).length === 0) {
      return $("body").append("<div id=" + idDiv + "></div>");
    }
  };

  documentosBaseController.prototype.abrirModalAdicionarDocumento = function(id) {
    this.criarDivNoBody('addDocumento-modal-container');
    debugger;
    return $.get(this.options.adicionarDocumentoUrl, {
      idAgregador: id,
      updateTargetId: 'addDocumento-modal-container'
    }, (function(_this) {
      return function(data) {
        return $("#addDocumento-modal-container").html(data);
      };
    })(this));
  };

  documentosBaseController.prototype.abrirModalEditarDocumento = function(id) {
    this.criarDivNoBody('addDocumento-modal-container');
    return $.get(this.options.editarDocumentoUrl, {
      id: id,
      updateTargetId: "addDocumento-modal-container"
    }, (function(_this) {
      return function(data) {
        return $("#addDocumento-modal-container").html(data);
      };
    })(this));
  };

  documentosBaseController.prototype.recarregarDocumentos = function(id, updateTargetId) {
    return $.get(this.options.recarregarDocumentoUrl, {
      id: id
    }, (function(_this) {
      return function(data) {
        var qtdDoc;
        if ($('#Agregador-' + id).find('.listaDocumentos').length === 0) {
          $('#Agregador-' + id).parent().html(data);
        } else {
          $('#Agregador-' + id).find('.listaDocumentos').html($(data).find('.listaDocumentos').html());
        }
        if (window.CallbackDeAdicaoDeDocumento) {
          qtdDoc = $('#AgregadorCompleto-' + id + ' .accordion-group').length;
          if (qtdDoc < 2 && window.CallbackDeAdicaoDeDocumento) {
            return window.CallbackDeAdicaoDeDocumento();
          }
        }
      };
    })(this));
  };

  documentosBaseController.prototype.apagarDocumento = function(idAgregador, idDocumento) {
    return Confirmacao.mostrar(false, (function(_this) {
      return function() {
        return _this.excluirDocumento(idDocumento);
      };
    })(this));
  };

  documentosBaseController.prototype.excluirDocumento = function(idDoDocumento) {
    return $.ajax({
      type: "POST",
      url: this.options.excluirDocumentoUrl,
      data: {
        idAgregador: this.options.id,
        idDocumento: idDoDocumento,
        updateTargetId: "AgregadorUpdate-" + this.options.Id
      }
    });
  };

  documentosBaseController.prototype.habilitarDesabilitarBotaoAdicionar = function(existeArquivo) {
    if (existeArquivo) {
      return $("#BotaoAdicionarDocumento").attr("disabled", "disabled");
    } else {
      return $("#BotaoAdicionarDocumento").removeAttr("disabled");
    }
  };

  documentosBaseController.AtualizarQuantidadeDocumentos = function() {
    var idDoIndicador, labelDocs;
    labelDocs = $("#documentos-indicador");
    if (labelDocs.length > 0) {
      idDoIndicador = labelDocs.first().closest(".js-container-listagem-documentos").children("a").data('idindicador');
      return $as.Documentos.DocumentosVinculados.QuantidadeDeDocumentosDoIndicador.get({
        idDoIndicador: idDoIndicador
      }).success((function(_this) {
        return function(data) {
          var label;
          label = $("#documentos-indicador").first();
          if (data > 0) {
            label.removeClass("none");
            return label.text(data);
          } else {
            return label.addClass("none");
          }
        };
      })(this));
    }
  };

  return documentosBaseController;

})();
