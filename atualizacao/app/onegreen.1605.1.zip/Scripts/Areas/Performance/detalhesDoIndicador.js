﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

this.detalhesDoIndicador = (function(superClass) {
  extend(detalhesDoIndicador, superClass);

  function detalhesDoIndicador(view1, opcoes, resource) {
    this.view = view1;
    this.opcoes = opcoes;
    this.resource = resource;
    this.aoExcluirModeloPersonalizado = bind(this.aoExcluirModeloPersonalizado, this);
    this.carregarModelosParaSelecao = bind(this.carregarModelosParaSelecao, this);
    this.marcarModeloComoFavorito = bind(this.marcarModeloComoFavorito, this);
    this.carregarModelo = bind(this.carregarModelo, this);
    this.reload = bind(this.reload, this);
    this.adicionarValoresGlobaisDoModeloDeGrafico = bind(this.adicionarValoresGlobaisDoModeloDeGrafico, this);
    this.carregarGrafico = bind(this.carregarGrafico, this);
    this.configurarPopover = bind(this.configurarPopover, this);
    this.setarContadores = bind(this.setarContadores, this);
    this.fecharDetalhes = bind(this.fecharDetalhes, this);
    this.aoAlterarPlanoDeAcao = bind(this.aoAlterarPlanoDeAcao, this);
    this.mudarDataDoProfile = bind(this.mudarDataDoProfile, this);
    this.mudarParaProximaData = bind(this.mudarParaProximaData, this);
    this.mudarParaDataAnterior = bind(this.mudarParaDataAnterior, this);
    this.configurarDatePicker = bind(this.configurarDatePicker, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.carregarIndicadorNaoVirtual = bind(this.carregarIndicadorNaoVirtual, this);
    this.carregarTela = bind(this.carregarTela, this);
    this.$view = $(this.view);
    this.carregarTela();
    this.carregarGrafico(this.get('#graficos-container'));
  }

  detalhesDoIndicador.prototype.carregarTela = function() {
    var modal;
    modal = new modalLateral(this.$view.parent());
    this.fechar = $("#js-fecharDetalhes", this.$view);
    this.frequencia = this.get('#Frequencia').val();
    this.ocorrencia = this.get('#Ocorrencia').val();
    this.startDate = this.get('#startDate').val();
    this.endDate = this.get('#endDate').val();
    this.idIndicador = this.get("#IdDoIndicador").val();
    this.initialDate = new Date(this.get('#initialDate').val());
    this.configurarBinds();
    this.carregarIndicadorNaoVirtual();
    window.redimensionarModalLateral();
    Atividades.api.boot();
    return $("[rel=tooltip]", this.$view).tooltip();
  };

  detalhesDoIndicador.prototype.carregarIndicadorNaoVirtual = function() {
    if (this.opcoes.Virtual) {
      return;
    }
    this.quantidadeDeTarefas = $("#tarefas-tab-content #contadorTarefas", this.$view).val();
    this.quantidadeDeComentarios = $("#comentarios-tab-content #contadorDeComentarios", this.$view).val();
    this.quantidadeDeSolucoesDeProblemas = $("#solucoes-tab-content #contadorDeSolucoes", this.$view).val();
    this.setarContadores(this.$view);
    this.configurarPopover(this.$view);
    return AjaxTab.BindTabs(this.$view);
  };

  detalhesDoIndicador.prototype.configurarBinds = function() {
    this.fechar.unbind('click').click(this.fecharDetalhes);
    this.get("#data-anterior").unbind('click').click(this.mudarParaDataAnterior);
    this.get("#data-proximo").unbind('click').click(this.mudarParaProximaData);
    return this.configurarDatePicker();
  };

  detalhesDoIndicador.prototype.configurarDatePicker = function() {
    return this.get("#date-picker-detalhes-do-indicador").unbind('click').click((function(_this) {
      return function() {
        var endDate, idElementToClick, idElementToValue, idElemetToClickContainer, initialDate, minViewMode, onChangeFunction, showWeeks, startDate;
        onChangeFunction = function() {
          switch (_this.frequencia) {
            case "Diaria":
            case "3":
              return _this.mudarDataDoProfile('DiaDaOcorrencia');
            case "Semanal":
            case "2":
              return _this.mudarDataDoProfile('SemanaDaOcorrencia');
            case "Mensal":
            case "1":
              return _this.mudarDataDoProfile('MesDaOcorrencia');
          }
        };
        DatePickerCustom.setDatePickerCustom(idElementToClick = 'date-picker-detalhes-do-indicador', idElemetToClickContainer = 'data-detalhes-do-indicador-container', idElementToValue = 'Ocorrencia', onChangeFunction = onChangeFunction, initialDate = _this.ocorrencia, startDate = _this.startDate, endDate = _this.endDate, showWeeks = _this.frequencia === "Semanal" ? true : false, minViewMode = _this.frequencia === "Mensal" ? 1 : 0);
        return $('#date-smart-picker', '#modal-smart-picker').datepicker('setDaysOfWeekDisabled', []);
      };
    })(this));
  };

  detalhesDoIndicador.prototype.mudarParaDataAnterior = function() {
    switch (this.frequencia) {
      case "Diaria":
      case "3":
        return this.mudarDataDoProfile('DiaAnterior');
      case "Semanal":
      case "2":
        return this.mudarDataDoProfile('SemanaAnterior');
      case "Mensal":
      case "1":
        return this.mudarDataDoProfile('MesAnterior');
    }
  };

  detalhesDoIndicador.prototype.mudarParaProximaData = function() {
    switch (this.frequencia) {
      case "Diaria":
      case "3":
        return this.mudarDataDoProfile('ProximoDia');
      case "Semanal":
      case "2":
        return this.mudarDataDoProfile('ProximaSemana');
      case "Mensal":
      case "1":
        return this.mudarDataDoProfile('ProximoMes');
    }
  };

  detalhesDoIndicador.prototype.mudarDataDoProfile = function(action) {
    var parametros;
    parametros = {
      IdDoIndicador: this.opcoes.IdDoIndicador,
      IdDoIndicadorBase: this.opcoes.IdDoIndicadorBase,
      IdDoItem1: this.opcoes.IdDoItem1,
      IdDoItem2: this.opcoes.IdDoItem2,
      IdDoItem3: this.opcoes.IdDoItem3,
      IdDoItem4: this.opcoes.IdDoItem4,
      IdDoItem5: this.opcoes.IdDoItem5,
      IdDoItem6: this.opcoes.IdDoItem6,
      Frequencia: this.frequencia,
      Ocorrencia: this.get('#Ocorrencia').val(),
      IdDaUnidade: this.opcoes.IdDaUnidade,
      IdDoPlanoDeGestao: this.opcoes.IdDoPlanoDeGestao
    };
    return $as.Performance.DetalhesDoIndicador[action].get(parametros).done((function(_this) {
      return function(data) {
        var modeloAtual;
        modeloAtual = _this.get('#IdModelo').val();
        _this.$view.replaceWith(data);
        _this.$view = $(_this.view);
        _this.carregarTela();
        _this.carregarModelo(modeloAtual);
        return swIntercom('Mudou a data no profile', {
          frequencia: _this.frequencia,
          ocorrencia: parametros.ocorrencia
        });
      };
    })(this));
  };

  detalhesDoIndicador.prototype.aoAlterarPlanoDeAcao = function() {
    detalhesDoIndicador.marcarComoAlterado();
    return Results.api.mostarMensagemParaCarregarSeNecessario(this.resource, detalhesDoIndicador);
  };

  detalhesDoIndicador.prototype.fecharDetalhes = function() {
    this.fechar.data("bs.tooltip").hide();
    this.$view.hide();
    window.cleanContext($("#detalhesDoIndicador-modal"));
    return Results.api.mostarMensagemParaCarregarSeNecessario(this.resource, detalhesDoIndicador);
  };

  detalhesDoIndicador.houveAlteracao = false;

  detalhesDoIndicador.marcarComoAlterado = function() {
    return this.houveAlteracao = true;
  };

  detalhesDoIndicador.prototype.setarContadores = function(view) {
    $("#js-contadorTarefas", view).text(this.quantidadeDeTarefas);
    $("#js-contadorComentarios", view).text(this.quantidadeDeComentarios);
    return $("#js-contadorSolucoes", view).text(this.quantidadeDeSolucoesDeProblemas);
  };

  detalhesDoIndicador.prototype.configurarPopover = function(view) {
    return view.off('click').on("click", "#exibir-informacoes", (function(_this) {
      return function(event) {
        var $el, evt, idDoIndicador, popoverAberto;
        popoverAberto = $("#popoverDetalhesIndicador").closest('.popover');
        evt = event || window.event;
        $el = $(evt.currentTarget);
        if (popoverAberto.length > 0 && popoverAberto.css('display') !== 'none') {
          $el.popover('destroy');
          return popoverAberto.remove();
        } else {
          $el.popover('destroy');
          popoverAberto.remove();
          idDoIndicador = $("#IdDoIndicador", view).val();
          return $as.Performance.Indicadores.ObterPopoverDeInformacoes.get({
            idDoIndicador: idDoIndicador
          }).success(function(data) {
            var $data, callPopover, content;
            $data = $(data);
            content = $data.find("#detalhes-indicador-content").html();
            callPopover = function() {
              $el.popover({
                trigger: 'manual',
                html: true,
                title: null,
                content: content,
                placement: "left|bottom",
                notShowTitle: true
              });
              return $el.popover('show');
            };
            setTimeout(callPopover, 200);
          });
        }
      };
    })(this));
  };

  detalhesDoIndicador.prototype.carregarGrafico = function(container) {
    this.grafico = new GraficoDeIndicador(container);
    this.grafico.setBase(this.idIndicador, this.opcoes.IdDoIndicadorBase, this.opcoes.IdDoItem1, this.opcoes.IdDoItem2, this.opcoes.IdDoItem3, this.opcoes.IdDoItem4, this.opcoes.IdDoItem5, this.opcoes.IdDoItem6, this.get('#Frequencia').val(), this.get('#IdModeloFavorito').val(), 'Apurado', null, this.get('#Ocorrencia').val(), this.get('#Ordem').val(), this.opcoes.Virtual, true, this.opcoes.IdDoPlanoDeGestao, this.opcoes.IdDaUnidade);
    this.grafico.renderWithControls();
    return this.grafico.setTitle();
  };

  detalhesDoIndicador.prototype.adicionarValoresGlobaisDoModeloDeGrafico = function(idDoModelo, formaDeVisualizacao) {
    window.IdModeloDeGraficoAtual = idDoModelo;
    return window.FormaVizualizacaoModeloDeGraficoAtual = formaDeVisualizacao;
  };

  detalhesDoIndicador.aoAdicionarSolucaoDeProblema = function() {
    var container, tela;
    tela = detalhesDoIndicador.$view || '#detalhesDoIndicador-modal';
    container = $("#solucoes-tab-content", tela);
    return container.load(container.data('url'), function() {
      detalhesDoIndicador.marcarComoAlterado();
      return $("#js-contadorSolucoes", tela).text($("#solucoes-tab-content #contadorDeSolucoes", tela).val());
    });
  };

  detalhesDoIndicador.prototype.reload = function() {
    var abaAberta, parametros;
    parametros = {
      IdIndicador: this.opcoes.IdDoIndicador,
      IdIndicadorBase: this.opcoes.IdDoIndicadorBase,
      Dimensao1: this.opcoes.IdDoItem1,
      Dimensao2: this.opcoes.IdDoItem2,
      Dimensao3: this.opcoes.IdDoItem3,
      Dimensao4: this.opcoes.IdDoItem4,
      Dimensao5: this.opcoes.IdDoItem5,
      Dimensao6: this.opcoes.IdDoItem6,
      Frequencia: this.frequencia,
      IdUnidade: this.opcoes.IdDaUnidade,
      IdDoPlanoDeGestao: this.opcoes.IdDoPlanoDeGestao,
      NumeroDoMes: this.opcoes.NumeroDoMes
    };
    abaAberta = this.$view.find('#js-tabList').find('li.active').data('name');
    return Results.api.exibirDetalhesDoIndicador(parametros, this.opcoes.MesSemanaDia, abaAberta);
  };

  detalhesDoIndicador.prototype.carregarModelo = function(idModelo) {
    var formaDeVisualizacaoAtual, idIndicador, tipoDeDesdobramentoAtual;
    idIndicador = this.get('#IdIndicador').val() || this.opcoes.IdDoIndicador;
    formaDeVisualizacaoAtual = this.grafico.base.formaDeVisualizacao;
    tipoDeDesdobramentoAtual = this.grafico.base.tipoDeDesdobramento;
    this.grafico = new GraficoDeIndicador(this.get('#graficos-container'));
    this.grafico.setBase(idIndicador, this.opcoes.IdDoIndicadorBase, this.opcoes.IdDoItem1, this.opcoes.IdDoItem2, this.opcoes.IdDoItem3, this.opcoes.IdDoItem4, this.opcoes.IdDoItem5, this.opcoes.IdDoItem6, this.get('#Frequencia').val(), idModelo, formaDeVisualizacaoAtual, tipoDeDesdobramentoAtual, this.get('#Ocorrencia').val(), this.get('#Ordem').val(), this.opcoes.Virtual, true, this.opcoes.IdDoPlanoDeGestao, this.opcoes.IdDaUnidade);
    this.grafico.renderWithControls();
    return this.grafico.setTitle();
  };

  detalhesDoIndicador.prototype.marcarModeloComoFavorito = function(elemento) {
    var containerModelos, parametros;
    containerModelos = $(elemento).closest('#gafico-container-acoes');
    parametros = {
      idIndicador: containerModelos.find('#IdIndicador').val(),
      idModelo: containerModelos.find('#IdModelo').val()
    };
    return $as.Performance.FarolDeIndicadores.MarcaModeloComoFavorito.post(parametros).done((function(_this) {
      return function(data) {
        var container, favoritoDetalhes, favoritoZoom, iconeFavorito;
        if (data.success) {
          container = $(elemento).parent();
          iconeFavorito = container.find('i');
          iconeFavorito.toggleClass('fa-star-o').toggleClass('fa-star');
          favoritoZoom = container.closest('.js-modelo-favorito');
          favoritoDetalhes = _this.get('.js-modelo-favorito');
          if (favoritoZoom.data('idmodelo') === favoritoDetalhes.data('idmodelo')) {
            if (iconeFavorito.hasClass('fa-star')) {
              favoritoDetalhes.find('input').attr('checked', 'checked');
            } else {
              favoritoDetalhes.find('input').removeAttr('checked');
            }
            favoritoDetalhes.find('i').attr('class', iconeFavorito.attr('class'));
          } else {
            favoritoDetalhes.find('i').removeClass('fa-star').addClass('fa-star-o');
            favoritoDetalhes.find('input').removeAttr('checked');
          }
          _this.carregarModelosParaSelecao();
          if ($(elemento).is(":checked")) {
            container.attr('data-original-title', _this.resource.RemoverFavorito);
            return swIntercom('Marcou gráfico como favorito');
          } else {
            container.attr('data-original-title', _this.resource.MarcarComoFavorito);
            return swIntercom('Desmarcou gráfico como favorito');
          }
        }
      };
    })(this));
  };

  detalhesDoIndicador.prototype.carregarModelosParaSelecao = function() {
    var parametros;
    parametros = {
      idDoIndicador: this.get('#IdIndicador').val(),
      frequencia: this.frequencia,
      formaDeVisualizacao: this.get('#FormaDeVisualizacao').val()
    };
    return $as.Performance.FarolDeIndicadores.ModelosDeGraficosParaSelecao.get(parametros).done((function(_this) {
      return function(data) {
        var modelosContainer;
        modelosContainer = $('.js-modelos-container');
        return modelosContainer.each(function(index, elemento) {
          var $elemento, modeloSelecionado;
          $elemento = $(elemento);
          modeloSelecionado = $elemento.find('[data-nomemodelo]').text();
          $elemento.html(data);
          $elemento.find('[data-nomemodelo]').text(modeloSelecionado);
          return _this.grafico.aoCarregarViewComControles();
        });
      };
    })(this));
  };

  detalhesDoIndicador.prototype.aoExcluirModeloPersonalizado = function(idExcluido) {
    var modeloAtual, modeloFavorito, zoomAberto;
    modeloFavorito = this.get('#IdModeloFavorito').val();
    modeloAtual = this.get('#IdModelo').val();
    if (modeloAtual === idExcluido) {
      zoomAberto = this.grafico.zoom && $('#facebox').is(':visible');
      this.carregarModelo(modeloFavorito);
      if (zoomAberto) {
        return this.grafico.zoomNoGrafico();
      }
    } else {
      return this.carregarModelosParaSelecao();
    }
  };

  return detalhesDoIndicador;

})(window.baseController);

this.comentarioDoIndicador = (function() {
  function comentarioDoIndicador(view1, opcoes) {
    this.view = view1;
    this.opcoes = opcoes;
    this.dimensionarListagem = bind(this.dimensionarListagem, this);
    this.changeDatePickerDate = bind(this.changeDatePickerDate, this);
    this.eventoChangeDatePickerDate = bind(this.eventoChangeDatePickerDate, this);
    this.datePicker = bind(this.datePicker, this);
    this.resetarCampoComentario = bind(this.resetarCampoComentario, this);
    this.recarregarComentarios = bind(this.recarregarComentarios, this);
    this.salvarComentario = bind(this.salvarComentario, this);
    this.esconderContainerEnvioComentario = bind(this.esconderContainerEnvioComentario, this);
    this.configurarComentario = bind(this.configurarComentario, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.$view = $(this.view);
    this.comentario = $("#DescricaoComentario", this.$view);
    this.envioComentarioContainer = $("#envio-comentario-container", this.$view);
    this.minimizarEnvioComentario = $("#minimizar-envio-container", this.$view);
    this.dataDeReferencia = $("#dataDeReferencia", this.$view);
    this.idDoIndicador = $("#IdDoIndicador", this.$view).val();
    this.comentariosContainer = $("#comentariosDoIndicador", this.$view);
    this.btnComentar = $("#btnComentar", this.$view);
    this.inputComentario = $('#inputComentario', this.$view);
    this.containerDescricao = $("#container-descricao", this.$view);
    this.validacaoErros = $('#validacao-erros', this.$view);
    this.comentariosTabContainer = this.$view.find('#comentarios-tab-content');
    this.ocorrencia = this.$view.find('#Ocorrencia').val();
    this.frequencia = this.$view.find('#Frequencia').val();
    this.startDate = this.$view.find('#startDate').val();
    this.endDate = this.$view.find('#endDate').val();
    this.initialDate = new Date(this.$view.find('#initialDate').val());
    $("[rel=tooltip]", this.$view).tooltip();
    this.configurarBinds();
    setTimeout((function(_this) {
      return function() {
        return _this.dimensionarListagem();
      };
    })(this), 0);
  }

  comentarioDoIndicador.prototype.configurarBinds = function() {
    this.minimizarEnvioComentario.unbind('click').click(this.esconderContainerEnvioComentario);
    this.comentario.unbind('keyup').keyup(this.configurarComentario).unbind('resize').resize(this.dimensionarListagem);
    this.btnComentar.unbind('click').click(this.salvarComentario);
    this.datePicker();
  };

  comentarioDoIndicador.prototype.configurarComentario = function() {
    if (this.comentario.val() !== '' && this.envioComentarioContainer.hasClass('js-hide')) {
      this.envioComentarioContainer.fadeIn(400, this.dimensionarListagem);
      return this.envioComentarioContainer.removeClass('js-hide');
    } else {
      return this.dimensionarListagem();
    }
  };

  comentarioDoIndicador.prototype.esconderContainerEnvioComentario = function() {
    this.envioComentarioContainer.fadeOut(400, this.dimensionarListagem);
    return this.envioComentarioContainer.addClass('js-hide');
  };

  comentarioDoIndicador.prototype.salvarComentario = function() {
    if (this.comentario.val() !== '') {
      return $as.Performance.Comentarios.Adicionar.post({
        idDoIndicador: this.idDoIndicador,
        ocorrencia: this.ocorrencia,
        Texto: this.inputComentario.val(),
        DataDeReferencia: this.dataDeReferencia.val(),
        frequencia: this.frequencia
      }).done((function(_this) {
        return function(data) {
          if (data.success) {
            _this.recarregarComentarios();
            $("#DescricaoComentario").data('mentionsInput').reset();
            detalhesDoIndicador.marcarComoAlterado();
            return swIntercom('Comentou um indicador');
          } else {
            _this.containerDescricao.addClass('error');
            $('ul', _this.validacaoErros).html("<li>" + data.data.mensagem + "</li>");
            return _this.validacaoErros.show();
          }
        };
      })(this));
    }
  };

  comentarioDoIndicador.prototype.recarregarComentarios = function() {
    return $as.Performance.Comentarios.ComentariosPorIndicador.get({
      idDoIndicador: this.idDoIndicador,
      ocorrencia: this.ocorrencia
    }).done((function(_this) {
      return function(data) {
        var quantidadeDeComentarios;
        _this.comentariosContainer.html(data);
        _this.resetarCampoComentario();
        quantidadeDeComentarios = $("#comentarios-tab-content #contadorDeComentarios", _this.$view).val();
        $("#js-contadorComentarios", _this.$view).text(quantidadeDeComentarios);
        $("[rel=tooltip]", _this.$view).tooltip();
        return redimensionarModalLateral();
      };
    })(this));
  };

  comentarioDoIndicador.prototype.resetarCampoComentario = function() {
    this.esconderContainerEnvioComentario();
    this.comentario.val('');
    this.dataDeReferencia.val('');
    this.containerDescricao.removeClass('error');
    this.validacaoErros.hide();
    return $('ul', this.validacaoErros).html('');
  };

  comentarioDoIndicador.prototype.datePicker = function() {
    var selecao;
    selecao = $('#btnDataDoComentario', '#comentar-container').datepicker({
      startDate: this.startDate,
      endDate: this.endDate,
      changeMonth: true,
      changeYear: false,
      showButtonPanel: true,
      autoclose: true,
      minViewMode: 0
    });
    selecao.datepicker("setDate", this.initialDate);
    selecao.off('changeDate').on('changeDate', this.eventoChangeDatePickerDate);
    return this.changeDatePickerDate(this.ocorrencia);
  };

  comentarioDoIndicador.prototype.eventoChangeDatePickerDate = function(ev) {
    var componenteDatePicker;
    componenteDatePicker = $('#btnDataDoComentario', '#comentar-container').data('datepicker');
    return this.changeDatePickerDate(componenteDatePicker.getFormattedDate());
  };

  comentarioDoIndicador.prototype.changeDatePickerDate = function(texto) {
    this.ocorrencia = texto;
    $('#textoDataDoComentario', '#comentar-container').text(texto);
    $('#dataDeReferencia', '#comentar-container').val(texto);
    return $('.datepicker').hide();
  };

  comentarioDoIndicador.prototype.dimensionarListagem = function() {};

  return comentarioDoIndicador;

})();
