﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.operacaoNoSistemaPorUsuarioController = (function() {
  function operacaoNoSistemaPorUsuarioController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.reload = bind(this.reload, this);
    this.loadComboRegrasDoSistema = bind(this.loadComboRegrasDoSistema, this);
    this.aoSelecionarRegra = bind(this.aoSelecionarRegra, this);
    this.loadCreateEdit = bind(this.loadCreateEdit, this);
  }

  operacaoNoSistemaPorUsuarioController.prototype.loadCreateEdit = function() {
    $(this.contexto).window();
    return this.loadComboRegrasDoSistema();
  };

  operacaoNoSistemaPorUsuarioController.prototype.aoSelecionarRegra = function() {
    return $as.API.OperacoesNoSistema.ObterOpcoesDaOperacaoNoSistemaPorUsuario.get({
      id: $("#RegraDoSistema_Id").val()
    }).success((function(_this) {
      return function(data) {
        return $("#container-opcoes-da-operacao").html(data);
      };
    })(this));
  };

  operacaoNoSistemaPorUsuarioController.prototype.loadComboRegrasDoSistema = function() {
    return setCombo(this.contexto, "#RegraDoSistema_Nome", this.aoSelecionarRegra);
  };

  operacaoNoSistemaPorUsuarioController.prototype.reload = function() {
    return $as.Manutencao.OperacoesNoSistemaPorUsuario.Index.get({
      idDoPai: this.options.idDoPai
    }).success((function(_this) {
      return function(data) {
        $('#OperacoesNoSistemaPorUsuario-container').html(data);
        return $(_this.contexto).window('hide');
      };
    })(this));
  };

  return operacaoNoSistemaPorUsuarioController;

})();
