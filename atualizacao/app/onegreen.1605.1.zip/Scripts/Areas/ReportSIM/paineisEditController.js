﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.paineisEditController = (function(superClass) {
  extend(paineisEditController, superClass);

  function paineisEditController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.recarregarSIMPart = bind(this.recarregarSIMPart, this);
    this.reload = bind(this.reload, this);
    this.salvar = bind(this.salvar, this);
    this.trocarTemplate = bind(this.trocarTemplate, this);
    this.selecionarTemplate = bind(this.selecionarTemplate, this);
    this.selecionarTemplateEvent = bind(this.selecionarTemplateEvent, this);
    this.ativarEventosSelecaoTemplate = bind(this.ativarEventosSelecaoTemplate, this);
    this.carregarSelecaoTemplates = bind(this.carregarSelecaoTemplates, this);
    this.excluirItem = bind(this.excluirItem, this);
    this.tentarExcluirItem = bind(this.tentarExcluirItem, this);
    this.adicionarIframe = bind(this.adicionarIframe, this);
    this.adicionarCartao = bind(this.adicionarCartao, this);
    this.adicionarGrafico = bind(this.adicionarGrafico, this);
    this.tamanhoMinimoProTemplate = bind(this.tamanhoMinimoProTemplate, this);
    this.adicionarNoticia = bind(this.adicionarNoticia, this);
    this.getTelaCriacao = bind(this.getTelaCriacao, this);
    this.obterReferenciaNoTemplate = bind(this.obterReferenciaNoTemplate, this);
    this.salvarBackground = bind(this.salvarBackground, this);
    this.excluirBackground = bind(this.excluirBackground, this);
    this.cliqueDoBackground = bind(this.cliqueDoBackground, this);
    this.bloquearInsercaoNaMascara = bind(this.bloquearInsercaoNaMascara, this);
    this.adicionar = bind(this.adicionar, this);
    this.localizarElementos = bind(this.localizarElementos, this);
    this.complementoTelaDeCriacao = bind(this.complementoTelaDeCriacao, this);
    this.adicionarPaginaDeCriacaoNoContainer = bind(this.adicionarPaginaDeCriacaoNoContainer, this);
    this.containerDoItemNoTemplate = bind(this.containerDoItemNoTemplate, this);
    this.getItemContainer = bind(this.getItemContainer, this);
    this.onDrop = bind(this.onDrop, this);
    this.configurarDragAndDrog = bind(this.configurarDragAndDrog, this);
    this.resizeScreen = bind(this.resizeScreen, this);
    this.configurarBackground = bind(this.configurarBackground, this);
    this.ativarEventosPainel = bind(this.ativarEventosPainel, this);
    this.bloquearBotaoDeComponente = bind(this.bloquearBotaoDeComponente, this);
    this.desbloquearBotaoDeComponente = bind(this.desbloquearBotaoDeComponente, this);
    this.encontrarMaiorTamanhoDisponivel = bind(this.encontrarMaiorTamanhoDisponivel, this);
    this.bloquearItensInviaveis = bind(this.bloquearItensInviaveis, this);
    this.load = bind(this.load, this);
    paineisEditController.__super__.constructor.call(this, this.view, this.model);
    this.RaizDaRequisicao = $as.ReportSIM.Paineis;
  }

  paineisEditController.prototype.load = function() {
    paineisEditController.__super__.load.apply(this, arguments);
    this.configurarBackground();
    this.configurarDragAndDrog();
    this.ativarEventosPainel();
    if (this.get('#Template_Id').length === 0) {
      this.carregarSelecaoTemplates();
    }
    DashboardsUtil.iniciarAcompanhamentoDaJanela(this.view);
    return this.get('.js-botoes-edicao').show();
  };

  paineisEditController.prototype.bloquearItensInviaveis = function() {
    var botao, i, len, maximoDisponivel, minimo, quantidadeDeEspacos, ref, results;
    maximoDisponivel = this.encontrarMaiorTamanhoDisponivel();
    quantidadeDeEspacos = this.get('.js-ContainerItemVazio').length;
    ref = this.botoesAdicionar;
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      botao = ref[i];
      botao = $(botao);
      minimo = botao.data('minimo');
      if (minimo && minimo > maximoDisponivel || quantidadeDeEspacos <= 0) {
        results.push(this.bloquearBotaoDeComponente(botao));
      } else {
        results.push(this.desbloquearBotaoDeComponente(botao));
      }
    }
    return results;
  };

  paineisEditController.prototype.encontrarMaiorTamanhoDisponivel = function() {
    var container, i, len, maior, ref, tamanho;
    maior = 0;
    ref = this.get('.js-ContainerItemVazio');
    for (i = 0, len = ref.length; i < len; i++) {
      container = ref[i];
      tamanho = $(container).data('tamanho');
      if (maior < tamanho) {
        maior = tamanho;
      }
    }
    return maior;
  };

  paineisEditController.prototype.desbloquearBotaoDeComponente = function(botao) {
    botao.removeClass('c-cinza-escuro');
    return botao.unbind('click').click(this.adicionar);
  };

  paineisEditController.prototype.bloquearBotaoDeComponente = function(botao, quantidadeDeEspacos) {
    botao.addClass('c-cinza-escuro');
    return botao.unbind('click');
  };

  paineisEditController.prototype.ativarEventosPainel = function() {
    this.inputNome.change(this.salvar);
    this.botaoSelecionarTemplate.unbind('click').click(this.carregarSelecaoTemplates);
    this.botaoSelecionarBackground.unbind('click').click(this.cliqueDoBackground);
    this.botaoExcluirBackground.unbind('click').click(this.excluirBackground);
    this.botaoImagemDeFundo.on('change', this.salvarBackground);
    this.get(".js-remover-item-painel").unbind("click").bind("click", this.tentarExcluirItem);
    return this.bloquearItensInviaveis();
  };

  paineisEditController.prototype.configurarBackground = function() {
    var url;
    if ($('#url-background').data('file')) {
      url = DashboardsUtil.buildBackgrounUrl($('#url-background').val());
    }
    this.resizeScreen();
    return $(window).unbind('resize').resize(this.resizeScreen);
  };

  paineisEditController.prototype.resizeScreen = function() {
    return $('#painel-template').height($(window).height() - 110);
  };

  paineisEditController.prototype.configurarDragAndDrog = function() {
    $(".js-painel-container").draggable({
      revert: "invalid"
    });
    return $(".js-ContainerItemVazio, .js-painel-container").droppable({
      drop: this.onDrop
    });
  };

  paineisEditController.prototype.onDrop = function(event, ui) {
    var parametros;
    parametros = {
      idDoPainel: this.modelo.Id,
      referenciaDoador: $(ui.draggable).data('referencianotemplate'),
      referenciaReceptor: $(event.target).data('referencianotemplate')
    };
    return $as.ReportSIM.Paineis.TrocarPosicaoDosItens.post(parametros).done((function(_this) {
      return function() {
        return _this.reload();
      };
    })(this));
  };

  paineisEditController.prototype.getItemContainer = function(event) {
    return $(event.delegateTarget).closest(".painel-item-container");
  };

  paineisEditController.prototype.containerDoItemNoTemplate = function(event) {
    var container, referencia;
    referencia = this.obterReferenciaNoTemplate(event);
    return container = "#containerItem_" + referencia;
  };

  paineisEditController.prototype.adicionarPaginaDeCriacaoNoContainer = function(event, html) {
    return this.get(this.containerDoItemNoTemplate(event)).html(html);
  };

  paineisEditController.prototype.complementoTelaDeCriacao = function(event) {
    return this.sairDaEdicao();
  };

  paineisEditController.prototype.localizarElementos = function() {
    paineisEditController.__super__.localizarElementos.apply(this, arguments);
    this.ContainerDeItens = this.get('.js-ContainerDeItemSimPart');
    this.painelTemplateContainer = this.get('#painel-template');
    this.inputNome = this.get('#Nome');
    this.botaoSelecionarTemplate = this.get('#botao-selecionar-templates');
    this.botaoSelecionarBackground = this.get('#botao-selecionar-background');
    this.botaoExcluirBackground = this.get('#botao-excluir-background');
    this.botaoImagemDeFundo = this.get('#imagemDeFundo');
    this.containerTemplates = this.get('#container-templates-para-selecao');
    return this.botaoSubmitPainel = this.get('#submit-painel');
  };

  paineisEditController.prototype.adicionar = function(event) {
    var i, len, mascara, ref, results, tamanhoMinimo;
    paineisEditController.__super__.adicionar.apply(this, arguments);
    tamanhoMinimo = $(event.delegateTarget).data('minimo');
    ref = this.mascaras;
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      mascara = ref[i];
      mascara = $(mascara);
      if (mascara.data('tamanho') < tamanhoMinimo) {
        results.push(this.bloquearInsercaoNaMascara(mascara));
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  paineisEditController.prototype.bloquearInsercaoNaMascara = function(mascara) {
    mascara.unbind('click');
    return this.get(".js-TextoInserirModulo span", mascara).html(Resource.EsteContainerEMenorQueONecessario);
  };

  paineisEditController.prototype.cliqueDoBackground = function() {
    return this.botaoImagemDeFundo.click();
  };

  paineisEditController.prototype.excluirBackground = function() {
    return $as.ReportSIM.Paineis.RemoverBackground.post({
      id: this.modelo.Id
    }).done((function(_this) {
      return function(html) {
        _this.reload();
        $('body').css('background', "");
        return _this.botaoExcluirBackground.hide();
      };
    })(this));
  };

  paineisEditController.prototype.salvarBackground = function() {
    var form;
    form = FileUpload.getFormData($('#FormUploadPainel'));
    return $as.ReportSIM.Paineis.Upload.postFormData(form).done((function(_this) {
      return function(data) {
        return window.reload();
      };
    })(this));
  };

  paineisEditController.prototype.obterReferenciaNoTemplate = function(event) {
    return $(event.delegateTarget).data('referencianotemplate');
  };

  paineisEditController.prototype.getTelaCriacao = function(event) {
    switch (this.nomeSIMPartAdicionando) {
      case "indicador-cartao":
        this.adicionarCartao(event);
        break;
      case "indicador-grafico":
        this.adicionarGrafico(event);
        break;
      case "listagem-noticias":
        this.adicionarNoticia(event);
        break;
      case "indicador-iframe":
        this.adicionarIframe(event);
    }
    return this.get('.js-botoes-edicao').show();
  };

  paineisEditController.prototype.adicionarNoticia = function(event) {
    return $as.ReportSIM.Paineis.AdicionarNoticias.post({
      idDoPainel: this.modelo.Id,
      referenciaNoTemplate: this.obterReferenciaNoTemplate(event)
    }).done((function(_this) {
      return function(html) {
        return _this.reload();
      };
    })(this));
  };

  paineisEditController.prototype.tamanhoMinimoProTemplate = function() {
    if ($('.container-noticia').length) {
      return 4;
    } else {
      return 0;
    }
  };

  paineisEditController.prototype.adicionarGrafico = function(event) {
    var graficosDeIndicador;
    graficosDeIndicador = new graficosDeIndicadorPainelController($("#painel-template"), {
      Id: 0
    }, {
      Id: 0,
      SeletorContexto: "#painel-template",
      referenciaNoTemplate: this.obterReferenciaNoTemplate(event)
    });
    return graficosDeIndicador.mostrarModalDeEdicao();
  };

  paineisEditController.prototype.adicionarCartao = function(event) {
    var cardsDeIndicador;
    cardsDeIndicador = new cardsDeIndicadorPainelController($("#painel-template"), {
      Id: 0
    }, {
      Id: 0,
      SeletorContexto: "#painel-template",
      referenciaNoTemplate: this.obterReferenciaNoTemplate(event)
    });
    return cardsDeIndicador.mostrarModalDeEdicao();
  };

  paineisEditController.prototype.adicionarIframe = function(event) {
    var iframe;
    iframe = new iframeController($("#painel-template"), {
      Id: 0
    }, {
      Id: 0,
      SeletorContexto: "#painel-template",
      referenciaNoTemplate: this.obterReferenciaNoTemplate(event)
    });
    return iframe.mostrarModalDeEdicao();
  };

  paineisEditController.prototype.tentarExcluirItem = function(event) {
    return Confirmacao.mostrar(Resource.DesejaRealmenteExcluirEsteRegistro, (function(_this) {
      return function() {
        return _this.excluirItem(event);
      };
    })(this));
  };

  paineisEditController.prototype.excluirItem = function(event) {
    return this.RaizDaRequisicao.ExcluirItem.post({
      idItem: $(event.delegateTarget).closest('.js-ItemNoPainel').data('iditem'),
      idDoPainel: this.modelo.Id
    }).done((function(_this) {
      return function(data) {
        _this.painelTemplateContainer.html(data);
        return _this.load();
      };
    })(this));
  };

  paineisEditController.prototype.carregarSelecaoTemplates = function() {
    return $as.ReportSIM.TemplatesDePainel.SelecaoDeTemplates.get({
      quantidadeDeItens: this.get('.js-ContainerDeItemSimPart').length,
      tamanhoMinimoItem: this.tamanhoMinimoProTemplate()
    }).done((function(_this) {
      return function(html) {
        var idSelecionado;
        _this.containerTemplates.html(html);
        _this.ativarEventosSelecaoTemplate();
        $("[title]").tooltip();
        $('#templatedepainel-modal', _this.containerTemplates).window();
        if (_this.get('#Template_Id').val()) {
          idSelecionado = _this.get('#Template_Id').val();
          return _this.selecionarTemplate($("[data-id=" + idSelecionado + "]", _this.containerTemplates));
        }
      };
    })(this));
  };

  paineisEditController.prototype.ativarEventosSelecaoTemplate = function() {
    $('#botao-alterar-template', this.containerTemplates).unbind('click').click(this.trocarTemplate);
    $('.js-templateParaSelecao').unbind('click').click(this.selecionarTemplateEvent);
    return $($('.js-templateParaSelecao')[0]).addClass('template-selecionado');
  };

  paineisEditController.prototype.selecionarTemplateEvent = function(event) {
    return this.selecionarTemplate($(event.delegateTarget));
  };

  paineisEditController.prototype.selecionarTemplate = function(element) {
    $('.js-templateParaSelecao', this.containerTemplates).removeClass('template-selecionado');
    return element.addClass('template-selecionado');
  };

  paineisEditController.prototype.trocarTemplate = function(idTemplate) {
    var templateSelecionado;
    templateSelecionado = $('.js-templateParaSelecao.template-selecionado', this.containerTemplates);
    if (templateSelecionado.length) {
      idTemplate = templateSelecionado.data('id');
      $('#templatedepainel-modal', this.containerTemplates).window('hide');
      this.painelTemplateContainer.fadeOut();
      return $as.ReportSIM.Paineis.TrocarTemplate.get({
        id: this.modelo.Id,
        idDoTemplate: idTemplate
      }).done((function(_this) {
        return function(html) {
          return window.reload();
        };
      })(this));
    }
  };

  paineisEditController.prototype.salvar = function() {
    return $as.ReportSIM.Paineis.Salvar.post({
      id: $('#idDoPainel').val(),
      nome: this.inputNome.val()
    }).done((function(_this) {
      return function(html) {
        return _this.get('#validation-container').html(html);
      };
    })(this));
  };

  paineisEditController.prototype.reload = function() {
    return $as.ReportSIM.Paineis.RecarregarTemplate.get({
      idDoPainel: this.modelo.Id
    }).done((function(_this) {
      return function(html) {
        _this.painelTemplateContainer.html(html);
        return _this.load();
      };
    })(this));
  };

  paineisEditController.prototype.recarregarSIMPart = function(ret) {
    return this.reload();
  };

  return paineisEditController;

})(window.dashboardEditBaseController);
