﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.RelatoriosGerenciaisController = (function() {
  function RelatoriosGerenciaisController(opcoes, recursos) {
    this.opcoes = opcoes;
    this.recursos = recursos;
    this.configurarDatePickers = bind(this.configurarDatePickers, this);
    this.submitRelatorio = bind(this.submitRelatorio, this);
    this.LoadComboUnidadeGerencial = bind(this.LoadComboUnidadeGerencial, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.LoadComboUnidadeGerencial();
    this.configurarBinds();
    this.configurarDatePickers();
  }

  RelatoriosGerenciaisController.prototype.configurarBinds = function() {
    $("[rel=tooltip]").tooltip();
    return $('.js-relatorio', this.opcoes.Contexto).unbind('click').click(this.submitRelatorio);
  };

  RelatoriosGerenciaisController.prototype.LoadComboUnidadeGerencial = function() {
    var comboUnidadeGerencial;
    comboUnidadeGerencial = $('#UnidadeGerencialNome', this.opcoes.Contexto);
    comboUnidadeGerencial.autocompleter(this.opcoes.UrlUnidadesGerenciais, {
      loadOnDemand: true,
      elementToClick: "#tela-relatorios #UnidadeGerencialNomeBtn",
      keyElement: "#tela-relatorios #UnidadeGerencial"
    });
    return comboUnidadeGerencial.data("autocompleter").setOpcaoPadrao({
      Key: "",
      Value: "(" + this.recursos.Todas + ")"
    });
  };

  RelatoriosGerenciaisController.prototype.submitRelatorio = function(event) {
    var dados, divRelatorio;
    divRelatorio = $(event.delegateTarget);
    $('#Relatorio', this.opcoes.Contexto).val(divRelatorio.data("tipo"));
    dados = $(this.opcoes.Contexto).find(":input").serialize();
    return $as.Onegreen.RelatoriosGerenciais.RetornarRelatorio.get(dados).success((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  RelatoriosGerenciaisController.prototype.configurarDatePickers = function() {
    $('.date-picker', this.opcoes.Contexto).datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      autoclose: true,
      language: Globalize.culture($("html").attr("lang")).name
    });
    $("#DataInicio", this.opcoes.Contexto).change((function(_this) {
      return function() {
        var startDate;
        $("#DataFim", _this.opcoes.Contexto).datepicker('setStartDate');
        if ($("#DataInicio").val().trim() !== "") {
          if ($("#DataFim", _this.opcoes.Contexto).val() === '') {
            $("#DataFim", _this.opcoes.Contexto).val($("#DataInicio", _this.opcoes.Contexto).val());
          }
          startDate = $("#DataInicio", _this.opcoes.Contexto).data('datepicker').getFormattedDate();
          $("#DataFim", _this.opcoes.Contexto).datepicker('setStartDate', startDate);
          return $("#DataFim", _this.opcoes.Contexto).datepicker('show');
        }
      };
    })(this));
    $("#DataFim", this.opcoes.Contexto).change((function(_this) {
      return function() {
        var endDate;
        $("#DataInicio", _this.opcoes.Contexto).datepicker('setEndDate');
        if ($("#DataFim").val().trim() !== "") {
          if ($("#DataInicio", _this.opcoes.Contexto).val() === '') {
            $("#DataInicio", _this.opcoes.Contexto).val($("#DataFim", _this.opcoes.Contexto).val());
          }
          endDate = $("#DataFim", _this.opcoes.Contexto).data('datepicker').getFormattedDate();
          return $("#DataInicio", _this.opcoes.Contexto).datepicker('setEndDate', endDate);
        }
      };
    })(this));
  };

  return RelatoriosGerenciaisController;

})();
