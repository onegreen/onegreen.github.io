Array.prototype.insertAt = function (index, item) {
  this.splice(index, 0, item);
};
String.prototype.insertAt = function (index, item) {
    return this.substr(0, index) + item + this.substr(index);
};
$.fn.extend({
    insertAtCaret: function (myValue) {
        return this.each(function (i) {
            if (document.selection) {
                //For browsers like Internet Explorer
                this.focus();
                var sel = document.selection.createRange();
                sel.text = myValue;
                this.focus();
            }
            else if (this.selectionStart || this.selectionStart == '0') {
                //For browsers like Firefox and Webkit based
                var startPos = this.selectionStart;
                var endPos = this.selectionEnd;
                var scrollTop = this.scrollTop;
                this.value = this.value.substring(0, startPos) + myValue + this.value.substring(endPos, this.value.length);
                this.focus();
                this.selectionStart = startPos + myValue.length;
                this.selectionEnd = startPos + myValue.length;
                this.scrollTop = scrollTop;
            } else {
                this.value += myValue;
                this.focus();
            }
        });
    }
});

$.fn.getCursorPosition = function () {
    var el = $(this).get(0);
    var pos = 0;
    if ('selectionStart' in el) {
        pos = el.selectionStart;
    } else if ('selection' in document) {
        el.focus();
        var Sel = document.selection.createRange();
        var SelLength = document.selection.createRange().text.length;
        Sel.moveStart('character', -el.value.length);
        pos = Sel.text.length - SelLength;
    }
    return pos;
}

$.fn.setCursorPosition = function (pos) {
    if ($(this).get(0).setSelectionRange) {
        $(this).get(0).setSelectionRange(pos, pos);
    } else if ($(this).get(0).createTextRange) {
        var range = $(this).get(0).createTextRange();
        range.collapse(true);
        range.moveEnd('character', pos);
        range.moveStart('character', pos);
        range.select();
    }
}

window.MentionContext = function () {
    this.MentionsInputs = new Array();
    this.PorIndice = function (indice) {
        return this.MentionsInputs[indice];
    };
    this.SelectItemOn = function (item, indice) {
        return this.MentionsInputs[indice].selectMention(item);
    };
    this.ProcessKeyDown = function (event, indice) {
        return this.MentionsInputs[indice].KeyDown(event, indice);
    };
    this.ProcessKeyPress = function (event, indice) {
        return this.MentionsInputs[indice].keyPress(event, indice);
    };
}

window.MentionContext = new MentionContext();

function Mention(seletor, options) {
    this.Indice;
    this.element;
    this.background;
    this.container;
    this.mensioning = false;
    var KEY = { BACKSPACE: 8, TAB: 9, RETURN: 13, ESC: 27, LEFT: 37, UP: 38, RIGHT: 39, DOWN: 40, COMMA: 188, SPACE: 32, HOME: 36, END: 35 };
    var TYPES = { TEXT: 1, MENSION: 2 };
    var MentionsTypes = { Participante: { name: "Participante", keyCode: 190 }, Assunto: { name: "Assunto", keyCode: 50 }, Acao: { name: "Acao", keyCode: 187} };
    this.avaliableMentions = [ MentionsTypes.Participante, MentionsTypes.Assunto]
    this.actualMentionSource = [
                        { type: MentionsTypes.Acao, text: "Fazer Mention Input " },
                        { type: MentionsTypes.Participante, text: "Glauber Almeida" },
                        { type: MentionsTypes.Acao, text: "Finalizar Codigo" },
                        { type: MentionsTypes.Assunto, text: "Necessidades da Empresa" },
                        { type: MentionsTypes.Assunto, text: "Melhorias para adequa��o" },
                   ];

    this.branchs = [
       { type: TYPES.TEXT, value: "A n�vel organizacional, a complexidade dos estudos efetuados exige a precis�o " },
       { type: TYPES.MENSION, value: { type: MentionsTypes.Assunto, text: "lembrar" } },
       { type: TYPES.TEXT, value: " e a defini��o do investimento em reciclagem t�cnica. " },
       { type: TYPES.MENSION, value: { type: MentionsTypes.Participante, text: "obstaculiza"} },
       { type: TYPES.TEXT, value: " " },
       { type: TYPES.MENSION, value: { type: MentionsTypes.Assunto, text: "determina��o" } },
       { type: TYPES.TEXT, value: " Caros amigos, o entendimento das metas propostas oferece uma."},
   ];

       this._InsertOnBranchAt = function (index, position, value) {
           if (this.branchs[index].type == TYPES.TEXT)
               this.branchs[index].value = this.branchs[index].value.toString().insertAt(position, value);
           else 
               this.branchs[index].value.text = this.branchs[index].value.text.toString().insertAt(position, value);

           this._AtualizarBranchs();
       };

      this._AtualizarBranchs = function () {
          var pos = 0;
          for (i = 0; i < this.branchs.length; i++) {
              var branch = this.branchs[i];
              branch.start = pos;
              if (branch.type == TYPES.TEXT)
                  pos += branch.value.length
              else
                  pos += branch.value.text.length
          }
      };

      this._PositionOnBranchByCaret = function (branch, caret) {
          return caret - branch.start;
      };
      this._BranchPositionByCaret = function (caret) {
          var i = 0;
          for (i = 0; i < this.branchs.length - 1; i++) {
              if (this.branchs[i].start <= caret && this.branchs[i + 1].start > caret)
                  return i;
          }
          return i;
      };

    this._Atualizar = function () {
        var valorInput = "";
        var valorBack = "";

        for (i = 0; i < this.branchs.length; i++) {
            var branch = this.branchs[i].value;
            if (this.branchs[i].type == TYPES.TEXT) {
                valorInput = valorInput + branch;
                valorBack = valorBack + branch;
            }
            else {

                valorInput = valorInput + branch.text;
                valorBack = valorBack + "<span class='mention" + branch.type.name + "'>" + branch.text +"</span>"
            }

        }
        this.element.val(valorInput);
        this.background.html(valorBack);
    };

    this._CarregarVariaveis = function () {
        this.element = $(seletor);
        this.container = this.element.parent();

        this.element.css("background-color", "transparent");
        this.element.css("z-index", "2");
        this.element.css("position", "absolute");
        this.element.css("resize", "none")
        //To Test
        //this.element.val("Nunca � demais lembrar o peso e o significado destes problemas, uma vez que a competitividade nas transa��es comerciais nos obriga � an�lise do sistema de forma��o de quadros que corresponde �s necessidades. Por outro lado, o novo modelo estrutural aqui preconizado talvez venha a ressaltar a relatividade das diretrizes de desenvolvimento para o futuro. Assim mesmo, a cont�nua expans�o de nossa atividade apresenta tend�ncias no sentido de aprovar a manuten��o do investimento em reciclagem t�cnica. Evidentemente, o aumento do di�logo entre os diferentes setores produtivos obstaculiza a aprecia��o da import�ncia das posturas dos �rg�os dirigentes com rela��o �s suas atribui��es. Percebemos, cada vez mais, que a mobilidade dos capitais internacionais garante a contribui��o de um grupo importante na determina��o das condi��es inegavelmente apropriadas. Do mesmo modo, a consulta aos diversos militantes assume importantes posi��es no estabelecimento dos n�veis de motiva��o departamental. Todavia, a estrutura atual da organiza��o exige a precis�o e a defini��o das regras de conduta normativas.");

    };

    this._builtBackGround = function () {
        this._BuildOrSelectBackground();
        this.background.html(builtBackGroundHTML(this.element, this.branchs));
    };

    this._BuildOrSelectBackground = function () {
        this.background = $(".mentionBackGround", this.element.parent())
        if (!this.background.length) {
            var htmlBackGround = '<div class="mentionBackGround"></div>';
            $(this.element.parent()).append(htmlBackGround);
            this.background = $(".mentionBackGround", this.element.parent())
            this.background.height(this.element.height());
            this.background.width(this.element.width());
            this.background.css("z-index", this.element.css("z-index") - 1);
            this.background.css("padding", "5px");
            this.background.css("position", "absolute");
            this.background.css("color", "transparent");
        }
    };

    function builtBackGroundHTML(element, mentions) {
        
        var html = element.val();
        for (i = 0; i < mentions.length; i++) {
            var mention = mentions[i];
            html = html.replace(mention.val, "<span class='mention" + mention.type.name + "'>" + mention.val + "</span>");
        }
        return html;
    };

    this._LigarRastreadorDeTeclas = function () {
        
        var indice = this.Indice;

        this.element.keydown(function (event) {
            return MentionContext.ProcessKeyDown(event, indice);
        });
        this.element.keypress(function (event) {
            return MentionContext.ProcessKeyPress(event, indice);
            
        });

    };

    this.KeyDown = function () {
        for (i = 0; i < this.avaliableMentions.length; i++) {
            if (event.keyCode == this.avaliableMentions[i].keyCode) {
                this.mensioning = true;

                this._builtDropDown();
                return false;
            }
            else {
                return this.takekeyAction(event);
                break;
            }
        }
    };

    this.keyPress = function (event) {
        var caret = this.element.getCursorPosition();
        var indice = this._BranchPositionByCaret(caret);
        var branch = this.branchs[indice];
        var branchPos = this._PositionOnBranchByCaret(branch, caret);
        this._InsertOnBranchAt(indice, branchPos, String.fromCharCode(event.which));
        this._Atualizar();
        this.element.setCursorPosition(caret + 1);
        return false;
    };

    this.takekeyAction = function (event) {
        var classAtivo = "ativo";
        var lista = $(".listaMentions", this.container);
        var ativo = $("li." + classAtivo, lista);
        var proximo = ativo.next();
        var previo = ativo.prev();
        var indice = this.Indice;
        var key = event.keyCode;
        switch (key) {
            case KEY.UP:
            case KEY.DOWN:
                if (lista.length) {
                    TransferClass(ativo, key == KEY.DOWN ? proximo : previo, classAtivo);
                }
                return true;
            case KEY.TAB:
                if (lista.length) {
                    this.selectMention(ativo);
                }
                return true;               
        }
    };

    this._builtDropDown = function () {
        var lista = $(".listaMentions", this.container);
        
        if (!lista.length) {

            this.container.append(this._ActualSourHtml());

            lista = $(".listaMentions", this.container);

            var itens = $("li", lista);
            itens.first().addClass("ativo");

            itens.mouseover(function () {
                $("li", $(this).parent()).removeClass("ativo");
                $(this).addClass("ativo");
            });

            itens.click(function () {
                MentionContext.SelectItemOn($(this), 0);

            });
        }
    };

    this._ActualSourHtml = function () {
        var mentions = this.actualMentionSource;
        var html = '<ul class="listaMentions">';

        for (i = 0; i < mentions.length; i++) {
            html = html + '<li drop-indice=' + i + '>' + mentions[i].text + '</li>';
        }

        html = html + '</ul>';
        return html;
    };

    this.selectMention = function (item) {

        var lista = $(".listaMentions", this.container);
        lista.remove();
        this.mensioning = false;
        var indiceMention = item.attr("drop-indice");
        var mention = this.actualMentionSource[indiceMention];
        this.branchs[this.branchs.length] = { type: TYPES.MENSION, value: mention };

        this._Atualizar();

    };

    function TransferClass(de, para,css)
    {
        if (para.length) {
            de.removeClass(css);
            para.addClass(css);
        }
    };

    this._LigarUpdateBackground = function () {

        var background = this.background;
        var mentions = this.branchs;
        var element = this.element;
        this.element.keyup(function (event) {
            background.html(builtBackGroundHTML(element, mentions));
        });
        this.element.change(function (event) {
            console.log($(this).text());
        })

    };

    this._builtMentions = function () {
        this.Indice = MentionContext.MentionsInputs.length
        this._CarregarVariaveis();
        this._builtBackGround();
        this._LigarRastreadorDeTeclas();
        this._AtualizarBranchs();
        // this._LigarUpdateBackground();
        MentionContext.MentionsInputs[this.Indice] = this;
        this._Atualizar();
    };

    this._builtMentions();
}