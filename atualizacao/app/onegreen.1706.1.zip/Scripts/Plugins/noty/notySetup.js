﻿/******** NOTY ****************/

/*******************

EXEMPLO

var btns = [
                { addClass: 'btn btn-warning', text: 'Ok', onClick: function($noty) { $noty.close(); }},
                { addClass: 'btn', text: 'Cancel', onClick: function($noty) { $noty.close(); }}
            ];
showBottomNoty('texto', 2000, btns)

****************/

function showBottomNoty(text, timeout, buttons) {
    window.currentNoty = window.noty({
        text: text, layout: 'bottom',
        timeout: (timeout == null ? 4000 : timeout),
        dismissQueue: true,
        maxVisible: 1,
        buttons: (buttons == null ? false : buttons)
    });

    return window.currentNoty;
}
/*************************/