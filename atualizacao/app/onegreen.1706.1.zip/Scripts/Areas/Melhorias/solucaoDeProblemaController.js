﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.solucaoDeProblemaController = (function() {
  function solucaoDeProblemaController(options, resources) {
    this.options = options;
    this.resources = resources;
    this.baixarApresentacao = bind(this.baixarApresentacao, this);
    this.criarApresentacao = bind(this.criarApresentacao, this);
    this.aoAbrirPlanoDeAcao = bind(this.aoAbrirPlanoDeAcao, this);
    this.configurarExibicaoDeGruposResponsaveis = bind(this.configurarExibicaoDeGruposResponsaveis, this);
    this.verificarAvancoDoFluxoMedianteExecucaoDaAcao = bind(this.verificarAvancoDoFluxoMedianteExecucaoDaAcao, this);
    this.configurarInvestimentoFinanceiro = bind(this.configurarInvestimentoFinanceiro, this);
    this.configurarGanhoFinanceiro = bind(this.configurarGanhoFinanceiro, this);
    this.configurarProgressoInvestimentoFinanceiro = bind(this.configurarProgressoInvestimentoFinanceiro, this);
    this.configurarProgressoGanhoFinanceiro = bind(this.configurarProgressoGanhoFinanceiro, this);
    this.configurarPercentualDeConclusao = bind(this.configurarPercentualDeConclusao, this);
    this.CallPreExecucaoDoFluxo = bind(this.CallPreExecucaoDoFluxo, this);
    this.carregarComboAreaDeResultado = bind(this.carregarComboAreaDeResultado, this);
    this.carregarComboClassificacao = bind(this.carregarComboClassificacao, this);
    this.carregarComboMetodo = bind(this.carregarComboMetodo, this);
    this.carregarComboOrigem = bind(this.carregarComboOrigem, this);
    this.carregarComboUnidadeGerencial = bind(this.carregarComboUnidadeGerencial, this);
    this.diffEntreEstadoAtualComSnapshot = bind(this.diffEntreEstadoAtualComSnapshot, this);
    this.gruposResponsaveisPorAprovacaoEVerificacao = bind(this.gruposResponsaveisPorAprovacaoEVerificacao, this);
    this.salvarDadoSimForm = bind(this.salvarDadoSimForm, this);
    this.bindAlteracoesASeremSalvas = bind(this.bindAlteracoesASeremSalvas, this);
    this.exibirCamposComplementares = bind(this.exibirCamposComplementares, this);
    this.tratarParametros = bind(this.tratarParametros, this);
    this.carregarSolucoesDeProblema = bind(this.carregarSolucoesDeProblema, this);
    this.configurarMarcacaoMenuLateral = bind(this.configurarMarcacaoMenuLateral, this);
    this.configurarAncorasNoMenu = bind(this.configurarAncorasNoMenu, this);
    this.reload = bind(this.reload, this);
    this.setDatePicker = bind(this.setDatePicker, this);
    this.reloadPercentualDeConclusao = bind(this.reloadPercentualDeConclusao, this);
    this.bloquearCamposEdicao = bind(this.bloquearCamposEdicao, this);
    this.loadFunctions = bind(this.loadFunctions, this);
    this.contexto = "#janelaProjeto";
    this.loadFunctions();
  }

  solucaoDeProblemaController.prototype.loadFunctions = function() {
    $("body").scrollTop(0);
    $('.voltar-topo').on('click', function() {
      return $("html, body").animate({
        scrollTop: 0
      }, 800);
    });
    $('[rel=popover]').popover({
      trigger: 'manual',
      html: true
    }).click(function(e) {
      return $(this).popover('show');
    });
    this.carregarComboUnidadeGerencial();
    this.carregarComboOrigem();
    this.carregarComboClassificacao();
    this.carregarComboAreaDeResultado();
    $("input[alt=decimal]").setMask();
    $("[rel=tooltip]").tooltip();
    $("#ComentarioDoRecurso").TextAreaExpander(20);
    $("#ComentarioDoFarolDeQualidade").TextAreaExpander(20);
    this.setDatePicker("#EncerramentoPrevisto");
    this.setDatePicker("#Encerramento");
    this.setDatePicker("#Abertura");
    this.configurarAncorasNoMenu();
    this.configurarMarcacaoMenuLateral();
    ConfigurarImpressaoFerramentaComunicacao();
    this.bindAlteracoesASeremSalvas();
    window.RecarregarFluxoDoMeuPainel = void 0;
    window.CallbackDaExecucaoDoFluxo = this.reload;
    window.CallPreExecucaoDoFluxo = this.CallPreExecucaoDoFluxo;
    this.configurarProgressoGanhoFinanceiro();
    this.configurarProgressoInvestimentoFinanceiro();
    this.configurarGanhoFinanceiro();
    this.configurarInvestimentoFinanceiro();
    window.MarcarMenuSuperior("#lnkSolucoesDeProblemas");
    this.configurarExibicaoDeGruposResponsaveis();
    $('.js-avancar-fluxo').bind('atualizar', this.aoAbrirPlanoDeAcao);
    $(Atividades.api).bind('mostrarExigenciaDeNotificao', this.atualizarEncerramentoPrevisto);
    if (this.options.AbrirComentarios) {
      return setTimeout($('#lnkComentarios').click(), 200);
    }
  };

  solucaoDeProblemaController.prototype.atualizarEncerramentoPrevisto = function(event, data) {
    var spanFimPrevisto, spanStatusFimPrevisto;
    if (data.Event === 'AtualizarEncerramentoPrevisto') {
      spanFimPrevisto = $('#span-fim-previsto');
      spanStatusFimPrevisto = $('#span-status-fim-previsto');
      if (spanFimPrevisto) {
        spanFimPrevisto.html(data.EncerramentoPrevisto);
        return spanStatusFimPrevisto.html(data.StatusEncerramento);
      }
    }
  };

  solucaoDeProblemaController.prototype.bloquearCamposEdicao = function() {
    $("#ClassificacaoAplicada_Descricao").data("autocompleter").disable();
    $("#ClassificacaoAplicada_Descricao").addClass("c-cinza");
    return $("#ClassificacaoAplicada_Descricao").addClass("readonly");
  };

  solucaoDeProblemaController.prototype.reloadPercentualDeConclusao = function() {
    return $as.Melhorias.SolucoesDeProblemas.PercentualDeConclusao.get({
      id: this.options.Id
    }).success((function(_this) {
      return function(data) {
        return _this.configurarPercentualDeConclusao(data);
      };
    })(this));
  };

  solucaoDeProblemaController.prototype.setDatePicker = function(input) {
    return $(input).datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      autoclose: true
    });
  };

  solucaoDeProblemaController.prototype.reload = function() {
    return $as.Melhorias.SolucoesDeProblemas.Edit.get({
      id: this.options.Id
    }).success((function(_this) {
      return function(data) {
        return $("#main").html(data);
      };
    })(this));
  };

  solucaoDeProblemaController.reloadSolucaoDeProblemas = function(id) {
    return $as.Melhorias.SolucoesDeProblemas.CabecalhoSolucaoDeProblema.get({
      id: id
    }).success(function(data) {
      return $("#js-info-cabecalho").html(data);
    });
  };

  solucaoDeProblemaController.prototype.configurarAncorasNoMenu = function() {
    var $menuOpcoes;
    $menuOpcoes = $(".js-menuOpcoes");
    return $(".js-link-ferramenta a.js-link-tag-a", $menuOpcoes).each((function(_this) {
      return function(index, array) {
        var ancora, offsetTarget;
        ancora = $($(".js-link-ferramenta a.js-link-tag-a", $menuOpcoes)[index]);
        offsetTarget = $(ancora.attr("href")).offset();
        if (!(ancora.attr('href') === void 0)) {
          return ancora.click(function() {
            if (offsetTarget != null) {
              $("html, body").animate({
                scrollTop: offsetTarget.top - 170
              }, 800);
              $("li", $menuOpcoes).removeClass("active");
              return ancora.parent().addClass("active");
            }
          });
        }
      };
    })(this));
  };

  solucaoDeProblemaController.prototype.configurarMarcacaoMenuLateral = function() {
    var $menuOpcoes, lis;
    $menuOpcoes = $(".js-menuOpcoes");
    lis = $('> li:not(.js-acoes)', $menuOpcoes);
    return $('> a', lis).click(function(event) {
      lis.removeClass('active');
      return $(event.delegateTarget).parent().addClass('active');
    });
  };

  solucaoDeProblemaController.prototype.carregarSolucoesDeProblema = function() {
    if (window.FecharSolucaoDeProblema) {
      return window.FecharSolucaoDeProblema();
    } else {
      return $as.Melhorias.SolucoesDeProblemas.IndexFiltroAvancadoSolucaoDeProblema.get({
        ignorarFiltro: true
      }).success((function(_this) {
        return function(data) {
          return $("#main").html(data);
        };
      })(this));
    }
  };

  solucaoDeProblemaController.prototype.tratarParametros = function(parametros) {
    return parametros;
  };

  solucaoDeProblemaController.prototype.exibirCamposComplementares = function() {
    if ($("#ClassificacaoAplicada_Id").val() !== "") {
      return $as.Melhorias.SolucoesDeProblemas.CarregarCamposComplementares.get({
        idDaSolucaoDeProblema: this.options.Id,
        idDaClassificacao: $("#ClassificacaoAplicada_Id").val()
      }).success((function(_this) {
        return function(data) {
          return $("#divCamposComplementares").html(data);
        };
      })(this));
    }
  };

  solucaoDeProblemaController.prototype.bindAlteracoesASeremSalvas = function() {
    $("input", "#informacoes-container").change(this.salvarDadoSimForm);
    $("textarea", "#informacoes-container").change(this.salvarDadoSimForm);
    $("input", "div[data-simform]").change(this.salvarDadoSimForm);
    return $("textarea", "div[data-simform]").change(this.salvarDadoSimForm);
  };

  solucaoDeProblemaController.prototype.salvarDadoSimForm = function() {
    var parametros;
    parametros = $(":input", "#solucaodeproblema-container").serialize();
    parametros = this.tratarParametros(parametros);
    return $as.Melhorias.SolucoesDeProblemas.SalvarDadosSimForm.post(parametros).success((function(_this) {
      return function(data) {
        return window.solucaoDeProblemaController.reloadSolucaoDeProblemas(_this.options.Id);
      };
    })(this));
  };

  solucaoDeProblemaController.prototype.gruposResponsaveisPorAprovacaoEVerificacao = function() {
    return $as.Melhorias.SolucoesDeProblemas.GruposResponsaveisPorAprovacaoEVerificacao.get({
      idDaSolucaoDePoblemas: this.options.Id
    }).success((function(_this) {
      return function(data) {
        return window.GetDiv("grupos-responsaveis-modal-container").html(data);
      };
    })(this));
  };

  solucaoDeProblemaController.prototype.diffEntreEstadoAtualComSnapshot = function(idDaExecucao) {
    return $as.Melhorias.SolucoesDeProblemas.DiffEntreEstadoAtualComSnapshot.get({
      idDaSolucaoDeProblema: this.options.Id,
      idDaExecucao: idDaExecucao
    }).success((function(_this) {
      return function(data) {
        return window.GetDiv("snapshot-modal-container").html(data);
      };
    })(this));
  };

  solucaoDeProblemaController.prototype.carregarComboUnidadeGerencial = function() {
    return setCombo(this.contexto, "#Unidade_SiglaAtual");
  };

  solucaoDeProblemaController.prototype.carregarComboOrigem = function() {
    return setCombo(this.contexto, "#Origem_Nome");
  };

  solucaoDeProblemaController.prototype.carregarComboMetodo = function() {
    var funcao, parametros;
    funcao = (function(_this) {
      return function(input) {
        return _this.exibirCamposComplementares();
      };
    })(this);
    parametros = {
      idDaClassificacao: $("#ClassificacaoAplicada_Id").val()
    };
    return setCombo(this.contexto, "#Metodo_Nome", funcao, parametros);
  };

  solucaoDeProblemaController.prototype.carregarComboClassificacao = function() {
    var funcao;
    funcao = (function(_this) {
      return function(input) {
        $("#Metodo_Id").val("");
        $("#Metodo_Nome").val("");
        return _this.carregarComboMetodo();
      };
    })(this);
    return setCombo(this.contexto, "#ClassificacaoAplicada_Descricao", funcao);
  };

  solucaoDeProblemaController.prototype.carregarComboAreaDeResultado = function() {
    return setCombo(this.contexto, "#AreaDeResultados_Nome");
  };

  solucaoDeProblemaController.prototype.CallPreExecucaoDoFluxo = function(callBack) {
    var parametros;
    parametros = $(":input", "#solucaodeproblema-container").serialize();
    parametros = this.tratarParametros(parametros);
    return $as.Melhorias.SolucoesDeProblemas.SalvarDadosSimForm.post(parametros).success((function(_this) {
      return function(data) {
        if (data.success === true) {
          return callBack();
        }
      };
    })(this));
  };

  solucaoDeProblemaController.prototype.configurarPercentualDeConclusao = function(percentualDeConclusao) {
    var barraContainer, previsto, realizado, status;
    status = percentualDeConclusao.Previsto > percentualDeConclusao.Realizado ? 'bg-atrasada' : 'bg-no-prazo';
    barraContainer = $('.js-barra-de-progresso');
    realizado = $('.progresso-realizado', barraContainer);
    previsto = $('.progresso-previsto', barraContainer);
    realizado.css('width', percentualDeConclusao.Realizado + "%").removeClass('bg-atrasada bg-no-prazo').addClass(status);
    return previsto.cs('left', percentualDeConclusao.Previsto + "%");
  };

  solucaoDeProblemaController.prototype.configurarProgressoGanhoFinanceiro = function() {
    return setTimeout((function(_this) {
      return function() {
        var ganho;
        ganho = $("#progresso-ganho");
        return ganho.width(ganho.attr("data-width"));
      };
    })(this), 500);
  };

  solucaoDeProblemaController.prototype.configurarProgressoInvestimentoFinanceiro = function() {
    return setTimeout((function(_this) {
      return function() {
        var invest;
        invest = $("#progresso-investimento");
        return invest.width(invest.attr("data-width"));
      };
    })(this), 500);
  };

  solucaoDeProblemaController.prototype.configurarGanhoFinanceiro = function() {
    return $("#GanhoFinanceiro, #GanhoFinanceiroPrevisto").change((function(_this) {
      return function() {
        return $as.Melhorias.SolucoesDeProblemas.Financeiro.get($(".js-divFinanceiro input").serialize()).success(function(data) {
          var html;
          html = $("#ganho-container", $(data)).html();
          $("#ganho-container", "#financeiro-container").html(html);
          _this.configurarProgressoGanhoFinanceiro();
          return _this.configurarGanhoFinanceiro();
        });
      };
    })(this));
  };

  solucaoDeProblemaController.prototype.configurarInvestimentoFinanceiro = function() {
    return $("#Investimento, #InvestimentoPrevisto").change((function(_this) {
      return function() {
        return $as.Melhorias.SolucoesDeProblemas.Financeiro.get($(".js-divFinanceiro input").serialize()).success(function(data) {
          var html;
          html = $("#investimento-container", $(data)).html();
          $("#investimento-container", "#financeiro-container").html(html);
          _this.configurarProgressoInvestimentoFinanceiro();
          return _this.configurarInvestimentoFinanceiro();
        });
      };
    })(this));
  };

  solucaoDeProblemaController.prototype.verificarAvancoDoFluxoMedianteExecucaoDaAcao = function(event, elemento, idDaAtividade, idPlanoDeAcao) {
    return $as.Melhorias.SolucoesDeProblemas.VerificarAvancoDoFluxoMedianteExecucaoDaAcao.post({
      idDaSolucao: this.options.Id,
      idDaAtividade: idDaAtividade
    }).done((function(_this) {
      return function(data) {
        if (data.data.recarregar) {
          _this.reload();
          return showBottomNoty(data.data.mensagem);
        }
      };
    })(this));
  };

  solucaoDeProblemaController.prototype.configurarExibicaoDeGruposResponsaveis = function() {
    if ($("#gruposResponsaveis").length > 0) {
      return $("ul", "[data-id-entidade=" + this.options.Id + "]").append($("#gruposResponsaveis"));
    }
  };

  solucaoDeProblemaController.prototype.aoAbrirPlanoDeAcao = function(evento, container) {
    return $(container).off('atualizar', '[data-atividade]', this.verificarAvancoDoFluxoMedianteExecucaoDaAcao).on('atualizar', '[data-atividade]', this.verificarAvancoDoFluxoMedianteExecucaoDaAcao);
  };

  solucaoDeProblemaController.prototype.criarApresentacao = function() {
    var contexto;
    contexto = $($('.js-solucao-apresentacao'), $('#criarapresentacaoapartirdeumasolucaodeprolema-modal'));
    apresentacaoDeSolucoesController.setInputNames(contexto);
    return $as.Melhorias.ApresentacoesDeSolucaoDeProblema.CriarApresentacaoAPartirDeUmaSolucaoDeProlema.post($("#criarapresentacaoapartirdeumasolucaodeprolema-modal input").serialize()).success((function(_this) {
      return function(data) {
        $("#main").html(data);
        return $("#close-modal-criarapresentacaoapartirdeumasolucaodeprolema").click();
      };
    })(this));
  };

  solucaoDeProblemaController.prototype.baixarApresentacao = function() {
    var contexto;
    contexto = $($('.js-solucao-apresentacao'), $('#criarapresentacaoapartirdeumasolucaodeprolema-modal'));
    apresentacaoDeSolucoesController.setInputNames(contexto);
    $("#criarapresentacaoapartirdeumasolucaodeprolema-modal form").submit();
    return showBottomNoty(this.resources.ODownloadDaApresentacaoSeIniciaraEmAlgunsInstantes);
  };

  solucaoDeProblemaController.alterarUnidade = function(idDaUnidade) {
    return $.ajax({
      type: 'POST',
      url: $as.Melhorias.SolucoesDeProblemas.MudarUnidadeGerencial.url,
      data: {
        idDaUnidade: idDaUnidade
      },
      global: false,
      success: function(data) {
        return window.reload();
      }
    });
  };

  solucaoDeProblemaController.editar = function(id) {
    return $as.Melhorias.SolucoesDeProblemas.EditarSolucaoDeProblema.get({
      id: id
    }).done(function(html) {
      return $('#addSolucaoDeProblema-modal-container').html(html);
    });
  };

  return solucaoDeProblemaController;

})();
