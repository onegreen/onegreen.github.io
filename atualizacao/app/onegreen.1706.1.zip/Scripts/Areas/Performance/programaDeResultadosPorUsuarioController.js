﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.programaDeResultadosPorUsuarioController = (function() {
  function programaDeResultadosPorUsuarioController(view, opcoes) {
    this.view = view;
    this.opcoes = opcoes;
    this.carregarComboDeUnidades = bind(this.carregarComboDeUnidades, this);
    this.salvarProgramaDeResultadosPorUsuario = bind(this.salvarProgramaDeResultadosPorUsuario, this);
    this.changeDatePickerDate = bind(this.changeDatePickerDate, this);
    this.eventoChangeDatePickerDate = bind(this.eventoChangeDatePickerDate, this);
    this.datepicker = bind(this.datepicker, this);
    this.programaDeResultadoExcluido = bind(this.programaDeResultadoExcluido, this);
    this.fecharProgramaDeResultadosPorUsuario = bind(this.fecharProgramaDeResultadosPorUsuario, this);
    this.$view = $(this.view);
    $(this.$view).window();
    window.recarregarFarol = true;
    this.botaoFechar = $('.js-fecharProgramaDeResultados', this.$view);
    this.botaoFechar.click(this.fecharProgramaDeResultadosPorUsuario);
    this.carregarComboDeUnidades();
    this.datepicker();
    this.programaDeResultadosPorUsuarioForm = $('#programaDeResultadosPorUsuario-form', this.view);
    $(this.view).find('[rel=tooltip]').tooltip();
  }

  programaDeResultadosPorUsuarioController.prototype.fecharProgramaDeResultadosPorUsuario = function() {
    this.botaoFechar.tooltip('toggle');
    this.$view.empty();
    if (window.recarregarFarol) {
      return window.reload();
    }
  };

  programaDeResultadosPorUsuarioController.prototype.programaDeResultadoExcluido = function() {
    window.recarregarFarol = true;
    return this.fecharProgramaDeResultadosPorUsuario();
  };

  programaDeResultadosPorUsuarioController.prototype.datepicker = function() {
    var dataDeFim, dataDeInicio, idioma, mesFim, mesInicio, meses;
    dataDeInicio = $('#btnDataDeInicio', this.view).datepicker({
      startDate: new Date(this.opcoes.ano, 0, 1),
      endDate: new Date(this.opcoes.ano, 11, 31),
      changeMonth: true,
      changeYear: false,
      showButtonPanel: true,
      autoclose: true,
      minViewMode: 1,
      startView: 1
    });
    dataDeFim = $('#btnDataDeFim', this.view).datepicker({
      startDate: new Date(this.opcoes.ano, 0, 1),
      endDate: new Date(this.opcoes.ano, 11, 31),
      changeMonth: true,
      changeYear: false,
      showButtonPanel: true,
      autoclose: true,
      minViewMode: 1,
      startView: 1
    });
    idioma = dataDeInicio.data('datepicker').language;
    meses = $.fn.datepicker.dates[idioma].months;
    mesInicio = meses[this.opcoes.mesDeInicio];
    mesFim = meses[this.opcoes.mesDeFim];
    $("#dataDeInicioLabel", this.view).text(mesInicio);
    $("#dataDeFimLabel", this.view).text(mesFim);
    dataDeInicio.off('changeDate').on('changeDate', this.eventoChangeDatePickerDate);
    return dataDeFim.off('changeDate').on('changeDate', this.eventoChangeDatePickerDate);
  };

  programaDeResultadosPorUsuarioController.prototype.eventoChangeDatePickerDate = function(ev) {
    var botao, hidden, label, lng, month, months, newDate;
    botao = $(ev.currentTarget);
    lng = botao.data('datepicker').language;
    newDate = new Date(ev.date);
    newDate.setDate(newDate.getDate() + 1);
    label = botao.data('label');
    hidden = botao.data('hidden');
    months = $.fn.datepicker.dates[lng].months;
    month = months[newDate.getMonth()];
    return this.changeDatePickerDate(month, label, hidden, newDate.toLocaleDateString(lng));
  };

  programaDeResultadosPorUsuarioController.prototype.changeDatePickerDate = function(texto, label, hidden, valor) {
    $("#" + label, this.view).text(texto);
    $("#" + hidden, this.view).val(valor);
    $('.datepicker').hide();
    return this.salvarProgramaDeResultadosPorUsuario();
  };

  programaDeResultadosPorUsuarioController.prototype.salvarProgramaDeResultadosPorUsuario = function() {
    return $as.Performance.ProgramasDeResultadosPorUsuario.SalvarProgramaDeResultadosPorUsuario.post(this.programaDeResultadosPorUsuarioForm.serialize()).done((function(_this) {
      return function(data) {
        _this.$view.html(data);
        return window.recarregarFarol = true;
      };
    })(this));
  };

  programaDeResultadosPorUsuarioController.prototype.carregarComboDeUnidades = function() {
    return setCombo('#programaDeResultadosPorUsuario-container', '#UnidadeGerencial_SiglaAtual', this.salvarProgramaDeResultadosPorUsuario);
  };

  return programaDeResultadosPorUsuarioController;

})();
