﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.itemApresentacaoDePainelController = (function(superClass) {
  extend(itemApresentacaoDePainelController, superClass);

  function itemApresentacaoDePainelController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.ativarEventos = bind(this.ativarEventos, this);
    this.moverParaBaixo = bind(this.moverParaBaixo, this);
    this.moverParaCima = bind(this.moverParaCima, this);
    this.loadIndex = bind(this.loadIndex, this);
    itemApresentacaoDePainelController.__super__.constructor.call(this, this.view, this.model);
    this.loadIndex();
  }

  itemApresentacaoDePainelController.prototype.loadIndex = function() {
    this.ativarEventos();
    return $("[rel=tooltip]").tooltip();
  };

  itemApresentacaoDePainelController.prototype.moverParaCima = function(element) {
    return $as.ReportSIM.ItensDaApresentacaoDePainel.MoverParaCima.post({
      id: $(element).attr('data-id')
    }).done((function(_this) {
      return function(html) {
        return _this.get('#itensdaapresentacaodepainel-container').html(html);
      };
    })(this));
  };

  itemApresentacaoDePainelController.prototype.moverParaBaixo = function(element) {
    return $as.ReportSIM.ItensDaApresentacaoDePainel.MoverParaBaixo.post({
      id: $(element).attr('data-id')
    }).done((function(_this) {
      return function(html) {
        return _this.get('#itensdaapresentacaodepainel-container').html(html);
      };
    })(this));
  };

  itemApresentacaoDePainelController.prototype.ativarEventos = function() {
    var primeiro, ultimo;
    this.get('.js-MoverParaCima').unbind('click').click((function(_this) {
      return function(event) {
        return _this.moverParaCima($(event.delegateTarget));
      };
    })(this));
    this.get('.js-MoverParaBaixo').unbind('click').click((function(_this) {
      return function(event) {
        return _this.moverParaBaixo($(event.delegateTarget));
      };
    })(this));
    primeiro = this.get('.js-MoverParaCima').first();
    ultimo = this.get('.js-MoverParaBaixo').last();
    primeiro.addClass('disabled');
    ultimo.addClass('disabled');
    primeiro.unbind('click');
    return ultimo.unbind('click');
  };

  return itemApresentacaoDePainelController;

})(window.baseController);
