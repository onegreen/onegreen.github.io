﻿(function() {
  "use strict";

  /*WINDOW CLASS DEFINITION
  *=======================
   */
  var Window, backdrop, escape, hideModal, hideWithTransition, removeBackdrop, setFocus;

  window.WindowZIndex = 7000;

  Window = function(content, options) {
    var elementId, maxHeight;
    this.options = options;
    this.$element = $(content).delegate('[data-dismiss="' + $(content).attr("id") + '"]', 'click.dismiss.window', $.proxy(this.hide, this)).css({
      'overflow': 'hidden'
    });
    if (this.$element.hasClass('modal-fullscreen')) {
      window.WindowZIndex = window.WindowZIndex < 9000 ? 9000 : window.WindowZIndex;
    }
    if (options.width !== null) {
      this.$element.find('.modal-dialog').css('width', options.width);
    }
    if (options.height !== null) {
      this.$element.find('.modal-body').css('height', options.height);
    }
    if (options.minheight !== null) {
      this.$element.find('.modal-body').css('min-height', options.minheight);
    }
    $('.modal-body', this.$element).css({
      'max-height': '500px',
      'padding-top': '9px',
      'overflow': 'auto'
    });
    maxHeight = $(window).height() - 20;
    if (this.$element.height() > maxHeight) {
      elementId = "#" + this.$element.attr('id');
      setTimeout(function() {
        var headerHeight, maxHeightModal;
        headerHeight = $(elementId).find('.modal-header')[0].scrollHeight;
        $(".modal-dialog", elementId).css('max-height', maxHeight - $(".modal-header", elementId).height() + "px");
        maxHeightModal = maxHeight - $(".modal-header", elementId).height();
        $(".modal-content", elementId).css('max-height', maxHeightModal + "px");
        return $(".modal-body", elementId).css('max-height', maxHeightModal - 80 - headerHeight + "px");
      }, 5);
    }
  };

  Window.prototype = {
    constructor: Window,
    toggle: function() {
      return this[!this.isShown ? 'show' : 'hide']();
    },
    show: function() {
      var that, varInnerHeight;
      that = this;
      if (this.isShown) {
        return;
      }
      $('html').addClass('modal-open');
      this.isShown = true;
      varInnerHeight = ($.browser.msie && (parseInt($.browser.version, 10) <= 8 || top !== self) ? document.documentElement.clientHeight : window.innerHeight) + 40;
      this.$element[0].style.cssText += ';z-index:' + ++WindowZIndex + '!important';
      this.$element.trigger('show');
      escape.call(this);
      backdrop.call(this, function() {
        var transition;
        transition = $.support.transition && that.$element.hasClass('fade');
        !that.$element.parent().length && that.$element.apprendTo(document.body);
        that.$element.show();
        if (transition) {
          that.$element[0].offsetWidth;
        }
        that.$element.addClass('in');
        if (transition) {
          that.$element.one($.support.transition.end, function() {
            that.$element.trigger('shown');
          });
        } else {
          that.$element.trigger('shown');
        }
      });
      setFocus(that.$element);
      this.$element.css('padding-top', ((varInnerHeight / 2) - (this.$element.heigth / 2)) + 20);
    },
    hide: function(e) {
      var that;
      e && e.preventDefault();
      if (!this.isShown) {
        return;
      }
      that = this;
      this.isShown = false;
      window.WindowZIndex = --window.WindowZIndex;
      $('html').removeClass('modal-open');
      escape.call(this);
      this.$element.trigger('hide').removeClass('in');
      if ($.support.transition && this.$element.hasClass('fade')) {
        hideWithTransition.call(this);
      } else {
        hideModal.call(this);
      }
    }
  };

  hideWithTransition = function() {
    var that, timeout;
    that = this;
    timeout = setTimeout(function() {
      that.$element.off($.support.transition.end);
      hideModal.call(that);
    }, 500);
    this.$element.one($.support.transition.end, function() {
      clearTimeout(timeout);
      hideModal.call(that);
    });
  };

  hideModal = function(that) {
    this.$element.hide().trigger('hidden');
    backdrop.call(this);
  };

  backdrop = function(callback) {
    var animate, doAnimate, that;
    that = this;
    animate = this.$element.hasClass('fade') ? 'fade' : '';
    if (this.isShown && this.options.backdrop) {
      doAnimate = $.support.transition && animate;
      this.$backdrop = $('<div class="modal-backdrop ' + animate + '" style="z-index:' + (WindowZIndex - 1) + ' !important" />').appendTo(document.body);
      if (this.options.backdrop !== 'static') {
        this.$backdrop.click($.proxy(this.hide, this));
      }
      if (doAnimate) {
        this.$backdrop[0].offsetWidth;
      }
      this.$backdrop.addClass('in');
      if (doAnimate) {
        this.$backdrop.one($.support.transition.end, callback);
      } else {
        callback();
      }
    } else if (!this.isShow && this.$backdrop) {
      this.$backdrop.removeClass('in');
      if ($.support.transition && this.$element.hasClass('fade')) {
        this.$backdrop.one($.support.transition.end, $.proxy(removeBackdrop, this));
      } else {
        removeBackdrop.call(this);
      }
    } else if (callback) {
      callback();
    }
  };

  removeBackdrop = function() {
    this.$backdrop.remove();
    this.$backdrop = null;
  };

  escape = function() {
    var that;
    that = this;
    if (this.isShown && this.options.keyboard) {
      $(document).on('keyup.dismiss.window', function(e) {
        e.wich === 27 && that.hide();
      });
    } else if (!this.isShown) {
      $(document).off('keyup.dismiss.window');
    }
  };

  setFocus = function($el) {
    setTimeout(function() {
      $("input[type=text]:first:not(.noFocus)", $el).focus();
    }, 5);
  };


  /* WINDOW PLUGIN DEFINITION
  =========================
   */

  $.fn.window = function(option) {
    return this.each(function() {
      var $this, data, options;
      $this = $(this);
      data = $this.data('modal');
      options = $.extend({}, $.fn.window.defaults, $this.data(), typeof option === 'object' && option);
      if (!data) {
        $this.data('modal', (data = new Window(this, options)));
      }
      if (typeof option === 'string') {
        data[option]();
      } else if (options.show) {
        data.show();
      }
    });
  };

  $.fn.window.defaults = {
    backdrop: false,
    keyboard: false,
    show: true,
    width: null,
    height: null,
    minheight: null
  };

  $.fn.window.Constructor = Window;


  /* WINDOW DATA-API 
  =================
   */

  $(function() {
    $('body').on('click.window.data-api', '[data-toggle="modal"]', function(e) {
      var $target, $this, href, option;
      $this = $(this);
      $target = $($this.attr('data-target') || (href = $this.attr('href' && href.replace(/.*(?=#[^\s]+$)/, ''))));
      if (option = $target.data('window')) {
        'toggle';
      } else {
        $.extend({}, $target.data(), $this.data());
      }
      e.preventDefault();
      $target.window(option);
    });
  });

}).call(this);
