﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.AdicionarSolucaoDeProblema = (function() {
  function AdicionarSolucaoDeProblema(contexto, urlRedirect) {
    this.contexto = contexto;
    this.urlRedirect = urlRedirect;
    this.configurarPlanoDeMetas = bind(this.configurarPlanoDeMetas, this);
    this.redirecionar = bind(this.redirecionar, this);
    this.configurarComboClassificacao = bind(this.configurarComboClassificacao, this);
    this.configurarComboMetodo = bind(this.configurarComboMetodo, this);
    this.carregarTela = bind(this.carregarTela, this);
    this.comboMetodo;
    this.comboUnidade;
    this.comboOrigem;
    this.comboAreaDeResultado;
    this.comboClassificacao;
    this.carregarTela();
    this.configurarPlanoDeMetas();
  }

  AdicionarSolucaoDeProblema.prototype.carregarTela = function() {
    var func;
    this.comboUnidade = setCombo(this.contexto, "#Unidade_SiglaAtual");
    func = (function(_this) {
      return function() {
        return $as.Melhorias.Origens.ObterPermiteMensuracao.get({
          idDaOrigem: $(_this.contexto).find('#Origem_Id').val()
        }).done(function(data) {
          if (data.permite) {
            return $(_this.contexto).find('#complmento-container').removeClass('none');
          } else {
            return $(_this.contexto).find('#complmento-container').addClass('none');
          }
        });
      };
    })(this);
    this.comboOrigem = setCombo(this.contexto, "#Origem_Nome", func);
    this.comboAreaDeResultado = setCombo(this.contexto, "#AreaDeResultados_Nome");
    $("[rel=tooltip]", this.contexto).tooltip();
    return this.configurarComboClassificacao();
  };

  AdicionarSolucaoDeProblema.prototype.configurarComboMetodo = function(naoLimpar) {
    var parametros;
    if (!naoLimpar && this.comboMetodo) {
      this.comboMetodo.reset();
    }
    parametros = {
      idDaClassificacao: this.comboClassificacao.value
    };
    return this.comboMetodo = setCombo(this.contexto, "#Metodo_Nome", null, parametros);
  };

  AdicionarSolucaoDeProblema.prototype.configurarComboClassificacao = function() {
    this.comboClassificacao = setCombo(this.contexto, "#ClassificacaoAplicada_Descricao", (function(_this) {
      return function() {
        return _this.configurarComboMetodo(false);
      };
    })(this));
    if (this.comboClassificacao !== null && this.comboClassificacao.value() !== "") {
      return this.configurarComboMetodo(true);
    }
  };

  AdicionarSolucaoDeProblema.prototype.redirecionar = function(data) {
    var url;
    url = this.urlRedirect || $as.Melhorias.SolucoesDeProblemas.Edit.url;
    url = url + '/' + data.data.idDaSolucao;
    return window.location = url;
  };

  AdicionarSolucaoDeProblema.prototype.configurarPlanoDeMetas = function() {
    return $('#exibirPlanoDeMetas input', this.contexto).change((function(_this) {
      return function(event) {
        if ($( this ).val() === 'True') {
          return $('#IndicadorRelacionadoParaAdicao_Frequencia, #IndicadorRelacionadoParaAdicao_Ocorrencia', _this.contexto).attr('disabled', 'disabled');
        } else {
          return $('#IndicadorRelacionadoParaAdicao_Frequencia, #IndicadorRelacionadoParaAdicao_Ocorrencia', _this.contexto).removeAttr('disabled', 'disabled');
        }
      };
    })(this));
  };

  return AdicionarSolucaoDeProblema;

})();
