﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.ferramentaCincoPorquesController = (function() {
  function ferramentaCincoPorquesController(options) {
    this.options = options;
    this.ExibirTodos = bind(this.ExibirTodos, this);
    this.ResumirPorques = bind(this.ResumirPorques, this);
    this.ResizeFerramenta = bind(this.ResizeFerramenta, this);
    this.ConfigurarScroll = bind(this.ConfigurarScroll, this);
    this.AtivarDesativarMes = bind(this.AtivarDesativarMes, this);
    this.exibirProblemasExcluidos = bind(this.exibirProblemasExcluidos, this);
    this.esconderProblemasExcluidos = bind(this.esconderProblemasExcluidos, this);
    this.resumir = bind(this.resumir, this);
    this.recarregarCincoPorques = bind(this.recarregarCincoPorques, this);
    this.contexto = "#" + this.options.contexto;
    this.recursoResumir = resourceJsonCommom.Resumir;
    this.recursoExibirCompleto = resourceJsonCommom.ExibirCompleto;
    $("[rel=tooltip]").tooltip();
    this.ConfigurarScroll();
    $(window).resize((function(_this) {
      return function() {
        return _this.ResizeFerramenta();
      };
    })(this));
    setTimeout(this.ResizeFerramenta, 0);
  }

  ferramentaCincoPorquesController.prototype.recarregarCincoPorques = function(exibirExcluidos) {
    return $as.Melhorias.CincoPorques.VisualizarCincoPorques.get({
      id: this.options.idCincoPorques,
      idDaFerramenta: this.options.idDaFerramenta,
      exibirExcluidos: exibirExcluidos
    }).success((function(_this) {
      return function(data) {
        return $(_this.contexto).parent().html(data);
      };
    })(this));
  };

  ferramentaCincoPorquesController.prototype.resumir = function() {
    $('.inactive', this.contexto).toggle();
    $('.resumo', this.contexto).toggle();
    if ($('#resumirBotaoCincoPorques', this.contexto).text() === this.recursoResumir) {
      return this.ResumirPorques();
    } else {
      return this.ExibirTodos();
    }
  };

  ferramentaCincoPorquesController.prototype.esconderProblemasExcluidos = function() {
    return this.recarregarCincoPorques(false);
  };

  ferramentaCincoPorquesController.prototype.exibirProblemasExcluidos = function() {
    return this.recarregarCincoPorques(true);
  };

  ferramentaCincoPorquesController.prototype.AtivarDesativarMes = function(botao, mes) {
    if ($(botao).hasClass('btn-warning')) {
      $('#inputmes' + mes).remove();
    } else {
      $(botao).after('<input id=inputmes' + mes + ' type=hidden value=' + mes + ' name=meses />');
    }
    return $(botao).toggleClass("btn-warning");
  };

  ferramentaCincoPorquesController.prototype.ConfigurarScroll = function() {
    return $(".js-container-porque", this.contexto).slimScrollHorizontal({
      railVisible: true,
      alwaysVisible: false,
      disableFadeOut: true,
      height: "auto",
      width: "auto",
      wheelStep: 20,
      allowPageScroll: false
    });
  };

  ferramentaCincoPorquesController.prototype.ResizeFerramenta = function() {
    var mes, widthBox, widthMes;
    mes = $(".mes-indicador:first", this.contexto);
    widthMes = mes.outerWidth() + parseInt(mes.css("margin-right"));
    widthBox = $("#Box-Problema-Porque", this.contexto).outerWidth();
    return $(".problema-porque", this.contexto).width('' + (widthBox - widthMes - 1) + 'px');
  };

  ferramentaCincoPorquesController.prototype.ResumirPorques = function() {
    $('#resumirBotaoCincoPorques', this.contexto).text(this.recursoExibirCompleto);
    return $(".js-container-porque>div", this.contexto).width("450px");
  };

  ferramentaCincoPorquesController.prototype.ExibirTodos = function() {
    $('#resumirBotaoCincoPorques', this.contexto).text(this.recursoResumir);
    return $(".js-container-porque", this.contexto).map(function() {
      var count;
      count = $(".box-porque", $(".js-porque", $(this))).length;
      return $(".js-porque", $(this)).width(count * 210 + 280);
    });
  };

  return ferramentaCincoPorquesController;

})();
