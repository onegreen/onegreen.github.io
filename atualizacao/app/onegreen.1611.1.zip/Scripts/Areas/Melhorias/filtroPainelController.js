﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.Melhorias || (this.Melhorias = {});

window.Melhorias.filtroPainelController = (function() {
  function filtroPainelController(options, func) {
    this.options = options;
    this.configurarAplicarFiltro = bind(this.configurarAplicarFiltro, this);
    this.defineFiltros = bind(this.defineFiltros, this);
    this.defineFiltros(func);
  }

  filtroPainelController.prototype.defineFiltros = function(func) {
    var filtroPainel;
    filtroPainel = window.FiltroMeuPainel;
    $.ajax({
      url: this.options.UrlFiltroDefault,
      async: false,
      success: function(filtro) {
        return window.FiltroMeuPainel = {
          IdUnidadeGerencial: filtro.IdUnidadeGerencial,
          UnidadeGerencialNome: filtro.UnidadeGerencialNome,
          IdDoPlanoDeGestao: filtro.IdDoPlanoDeGestao,
          PlanoDeGestaoNome: filtro.NomeDoPlanoDeGestaoOuAtual,
          IdOrigem: filtro.IdOrigem,
          OrigemNome: filtro.OrigemNome,
          Descricao: filtro.Descricao,
          Coluna: filtro.ColunaOrdenacao,
          Ordem: filtro.TipoOrdenacao,
          IncluirSubordinadas: filtro.IncluirSubordinadas,
          ExibirCancelados: filtro.ExibirCancelados,
          StatusSolucao: filtro.StatusSolucao,
          StatusAtividade: filtro.StatusAtividade,
          IdUsuario: filtro.IdUsuario,
          TipoDaSolucaoDeProblemas: filtro.TipoDaSolucaoDeProblemas
        };
      }
    });
    this.configurarAplicarFiltro();
    return func();
  };

  filtroPainelController.prototype.configurarAplicarFiltro = function() {
    return $("#AplicarFiltro").click(this.options.aplicarFiltro);
  };

  return filtroPainelController;

})();
