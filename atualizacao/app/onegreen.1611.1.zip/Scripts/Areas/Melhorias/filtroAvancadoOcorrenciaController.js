﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.FiltroAvancadoOcorrenciaController = (function(superClass) {
  extend(FiltroAvancadoOcorrenciaController, superClass);

  function FiltroAvancadoOcorrenciaController(opcoes, recursos) {
    this.opcoes = opcoes;
    this.recursos = recursos;
    this.SalvarFiltro = bind(this.SalvarFiltro, this);
    this.ExcluirFiltro = bind(this.ExcluirFiltro, this);
    this.CarregarFiltroAvancado = bind(this.CarregarFiltroAvancado, this);
    FiltroAvancadoOcorrenciaController.__super__.constructor.call(this, this.opcoes, this.recursos);
  }

  FiltroAvancadoOcorrenciaController.prototype.CarregarFiltroAvancado = function(idFiltro) {
    return $as.Melhorias.FiltroAvancadoDeOcorrencias.CarregarFiltroAvancado.get({
      id: idFiltro
    }).success((function(_this) {
      return function(data) {
        $("#form-filtro-avancado").parent().html(data);
        _this.ConfigurarExibirFiltro();
        return $("#btnFiltroAvancado").click();
      };
    })(this));
  };

  FiltroAvancadoOcorrenciaController.prototype.ExcluirFiltro = function() {
    return $as.Melhorias.FiltroAvancadoDeOcorrencias.ExcluirFiltro.get({
      id: $("#IdFiltroAvancado").val()
    }).success((function(_this) {
      return function(data) {
        $("#form-filtro-avancado").parent().html(data);
        _this.ConfigurarExibirFiltro();
        return $("#filtro-aplicado").click();
      };
    })(this));
  };

  FiltroAvancadoOcorrenciaController.prototype.SalvarFiltro = function() {
    return $as.Melhorias.FiltroAvancadoDeOcorrencias.CreateEditBuscaAvancada.post($("form#form-filtro-avancado").serialize()).success((function(_this) {
      return function(data) {
        return window.GetDiv("buscaAvancada-modal-container").html(data);
      };
    })(this));
  };

  FiltroAvancadoOcorrenciaController.prototype.LoadComboEtapas = function() {
    var $combo, $divCombo, EtapasViewModel, _this, onSelect;
    _this = this;
    EtapasViewModel = {
      Etapas: ko.observableArray(this.opcoes.EtapasSelecionadas),
      removeItem: function(etapa) {
        return this.Etapas.remove(etapa);
      },
      removeAll: function() {
        var array;
        array = this.Etapas.slice(0);
        this.Etapas.removeAll(array);
        return _this.LoadComboEtapas();
      }
    };
    window.EtapasViewModel = EtapasViewModel;
    ko.applyBindings(EtapasViewModel, $('#etapas_itens')[0]);
    $combo = $("#EtapasComboOcorrencia", this.opcoes.Contexto);
    $divCombo = $combo.parents("div.autocompleter");
    onSelect = function(jsonItem) {
      if (jsonItem.Id === 0) {
        EtapasViewModel.removeAll();
        $combo.val(jsonItem.Nome);
      }
    };
    return $combo.autocompleter($divCombo.attr("data-url"), {
      elementToClick: "#EtapasComboOcorrenciaBtn",
      multiSelectArray: EtapasViewModel.Etapas,
      multiSelectElement: "#etapas_itens",
      defaultOption: {
        Key: "0",
        Value: "(" + this.recursos.TodasNaoCanceladas + ")"
      },
      onSelected: function(input) {
        return onSelect(input);
      }
    });
  };

  return FiltroAvancadoOcorrenciaController;

})(window.FiltroAvancadoBaseDeSolucaoDeProblemaController);
