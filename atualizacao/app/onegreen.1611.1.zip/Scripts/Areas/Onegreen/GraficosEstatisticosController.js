﻿var GraficosEstatisticosController,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

GraficosEstatisticosController = (function() {
  function GraficosEstatisticosController(opcoes, recursos) {
    this.opcoes = opcoes;
    this.recursos = recursos;
    this.configurarVoltar = bind(this.configurarVoltar, this);
    this.configurarDatePickers = bind(this.configurarDatePickers, this);
    this.SubmitGrafico = bind(this.SubmitGrafico, this);
    this.LoadComboUnidadeGerencial = bind(this.LoadComboUnidadeGerencial, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.LoadComboUnidadeGerencial();
    this.configurarBinds();
    this.configurarDatePickers();
    this.configurarVoltar();
  }

  GraficosEstatisticosController.prototype.configurarBinds = function() {
    $("[rel=tooltip]").tooltip();
    return $('.js-grafico', this.opcoes.Contexto).unbind('click').click(this.SubmitGrafico);
  };

  GraficosEstatisticosController.prototype.LoadComboUnidadeGerencial = function() {
    var comboUnidadeGerencial;
    comboUnidadeGerencial = $('#UnidadeGerencialNome', this.opcoes.Contexto);
    comboUnidadeGerencial.autocompleter(this.opcoes.UrlUnidadesGerenciais, {
      loadOnDemand: true,
      elementToClick: "#tela-graficosestatisticos #UnidadeGerencialNomeBtn",
      keyElement: "#tela-graficosestatisticos #UnidadeGerencial"
    });
    return comboUnidadeGerencial.data("autocompleter").setOpcaoPadrao({
      Key: "",
      Value: "(" + this.recursos.Todas + ")"
    });
  };

  GraficosEstatisticosController.prototype.SubmitGrafico = function(event) {
    var dados, divGrafico;
    divGrafico = $(event.delegateTarget);
    $('#Grafico', this.opcoes.Contexto).val(divGrafico.data("tipo"));
    dados = $(this.opcoes.Contexto).find(":input").serialize();
    return $as.Onegreen.GraficosEstatisticos.RetornarGrafico.get(dados).success((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  GraficosEstatisticosController.prototype.configurarDatePickers = function() {
    $('.date-picker', this.opcoes.Contexto).datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      autoclose: true,
      language: Globalize.culture($("html").attr("lang")).name
    });
    $("#DataInicio", this.opcoes.Contexto).change((function(_this) {
      return function() {
        var startDate;
        $("#DataFim", _this.opcoes.Contexto).datepicker('setStartDate');
        if ($("#DataInicio").val().trim() !== "") {
          if ($("#DataFim", _this.opcoes.Contexto).val() === '') {
            $("#DataFim", _this.opcoes.Contexto).val($("#DataInicio", _this.opcoes.Contexto).val());
          }
          startDate = $("#DataInicio", _this.opcoes.Contexto).data('datepicker').getFormattedDate();
          $("#DataFim", _this.opcoes.Contexto).datepicker('setStartDate', startDate);
          return $("#DataFim", _this.opcoes.Contexto).datepicker('show');
        }
      };
    })(this));
    $("#DataFim", this.opcoes.Contexto).change((function(_this) {
      return function() {
        var endDate;
        $("#DataInicio", _this.opcoes.Contexto).datepicker('setEndDate');
        if ($("#DataFim").val().trim() !== "") {
          if ($("#DataInicio", _this.opcoes.Contexto).val() === '') {
            $("#DataInicio", _this.opcoes.Contexto).val($("#DataFim", _this.opcoes.Contexto).val());
          }
          endDate = $("#DataFim", _this.opcoes.Contexto).data('datepicker').getFormattedDate();
          return $("#DataInicio", _this.opcoes.Contexto).datepicker('setEndDate', endDate);
        }
      };
    })(this));
  };

  GraficosEstatisticosController.prototype.configurarVoltar = function() {
    return window.VoltarERecarregar = (function(_this) {
      return function() {
        return $as.Onegreen.GraficosEstatisticos.Index.post().success(function(data) {
          return $('#main').html(data);
        });
      };
    })(this);
  };

  return GraficosEstatisticosController;

})();
