﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.FiltroAvancadoRelatoriosGerenciaisController = (function(superClass) {
  extend(FiltroAvancadoRelatoriosGerenciaisController, superClass);

  function FiltroAvancadoRelatoriosGerenciaisController(opcoes, recursos) {
    this.opcoes = opcoes;
    this.recursos = recursos;
    this.submitRelatorio = bind(this.submitRelatorio, this);
    this.configurarComboRelatorios = bind(this.configurarComboRelatorios, this);
    FiltroAvancadoRelatoriosGerenciaisController.__super__.constructor.call(this, this.opcoes, this.recursos);
    this.configurarBinds();
    this.configurarComboRelatorios();
  }

  FiltroAvancadoRelatoriosGerenciaisController.prototype.configurarBinds = function() {
    $('#fecharFiltroRelatorios').on('click', (function(_this) {
      return function(e) {
        return $(_this.opcoes.Contexto).toggle();
      };
    })(this));
    $('#btnFiltroAvancado').on('click', (function(_this) {
      return function(e) {
        return $(_this.opcoes.Contexto).toggle();
      };
    })(this));
    return $('.js-relatorio', this.opcoes.Contexto).unbind('click').click(this.submitRelatorio);
  };

  FiltroAvancadoRelatoriosGerenciaisController.prototype.configurarComboRelatorios = function() {
    return setCombo(this.opcoes.Contexto, "#Relatorio_Nome");
  };

  FiltroAvancadoRelatoriosGerenciaisController.prototype.submitRelatorio = function() {
    var dados;
    dados = $(this.opcoes.Contexto).find(":input").serialize();
    return $as.Onegreen.RelatoriosGerenciais.RetornarRelatorio.get(dados).success((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  return FiltroAvancadoRelatoriosGerenciaisController;

})(window.FiltroAvancadoBaseController);
