﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

this.vincularUnidadesAoMapa = (function(superClass) {
  extend(vincularUnidadesAoMapa, superClass);

  function vincularUnidadesAoMapa(view, options) {
    this.view = view;
    this.options = options;
    this.aoRecarregarListagem = bind(this.aoRecarregarListagem, this);
    this.desbloquearOuBloquearBotaoAdicionar = bind(this.desbloquearOuBloquearBotaoAdicionar, this);
    this.selecionarUnidade = bind(this.selecionarUnidade, this);
    this.removerUnidade = bind(this.removerUnidade, this);
    this.solicitarRemoverUnidade = bind(this.solicitarRemoverUnidade, this);
    this.adicionarUnidade = bind(this.adicionarUnidade, this);
    this.eventos = bind(this.eventos, this);
    this.buscarElementos = bind(this.buscarElementos, this);
    $('#vincularunidades-modal').window({
      width: 850
    });
    setCombo("#vincularunidades-modal", "#UnidadeGerencial_SiglaAtual", this.selecionarUnidade);
    this.buscarElementos();
    this.eventos();
    $("[rel=tooltip]").tooltip();
    this.aoRecarregarListagem();
  }

  vincularUnidadesAoMapa.prototype.buscarElementos = function() {
    return this.botaoAdicionar = this.get('.js-adicionarUnidade');
  };

  vincularUnidadesAoMapa.prototype.eventos = function() {
    return this.botaoAdicionar.unbind('click').click(this.adicionarUnidade);
  };

  vincularUnidadesAoMapa.prototype.adicionarUnidade = function() {
    return $as.Performance.Mapas.AdicionarAcessoParaUnidade.post({
      id: this.options.Id,
      idUnidade: this.get('#UnidadeGerencial_Id').val(),
      incluirSubordinadas: this.get('#IncluirSubordinadas').is(':checked')
    }).done((function(_this) {
      return function(html) {
        _this.get('#unidades-acessam').html(html);
        return _this.aoRecarregarListagem();
      };
    })(this));
  };

  vincularUnidadesAoMapa.prototype.solicitarRemoverUnidade = function(event) {
    return Confirmacao.mostrar("", (function(_this) {
      return function() {
        return _this.removerUnidade($(event.delegateTarget));
      };
    })(this));
  };

  vincularUnidadesAoMapa.prototype.removerUnidade = function(target) {
    return $as.Performance.Mapas.RemoverAcessoDaUnidade.post({
      id: this.options.Id,
      idUnidade: target.data('unidade')
    }).done((function(_this) {
      return function(html) {
        _this.get('#unidades-acessam').html(html);
        return _this.aoRecarregarListagem();
      };
    })(this));
  };

  vincularUnidadesAoMapa.prototype.selecionarUnidade = function(input) {
    return this.desbloquearOuBloquearBotaoAdicionar();
  };

  vincularUnidadesAoMapa.prototype.desbloquearOuBloquearBotaoAdicionar = function() {
    if (this.get('#UnidadeGerencial_Id').val()) {
      return this.botaoAdicionar.removeAttr('disabled');
    }
  };

  vincularUnidadesAoMapa.prototype.aoRecarregarListagem = function() {
    $("[rel=tooltip]").tooltip();
    this.get('.js-removerUnidade').unbind('click').click(this.solicitarRemoverUnidade);
    return this.desbloquearOuBloquearBotaoAdicionar();
  };

  return vincularUnidadesAoMapa;

})(window.baseController);
