﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.desempenhoGraficoDeIndicadorController = (function() {
  function desempenhoGraficoDeIndicadorController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.reloadContainerDesempenho = bind(this.reloadContainerDesempenho, this);
    this.reloadCabecalho = bind(this.reloadCabecalho, this);
    this.normalizarDadosDaLinha = bind(this.normalizarDadosDaLinha, this);
    this.bindDetalhesDoIndicador = bind(this.bindDetalhesDoIndicador, this);
    this.resizeGraficos = bind(this.resizeGraficos, this);
    this.aoSalvar = bind(this.aoSalvar, this);
    this.reload = bind(this.reload, this);
    this.normalizarInformacoes = bind(this.normalizarInformacoes, this);
    this.carregarGrafico = bind(this.carregarGrafico, this);
    this.loadGraficos = bind(this.loadGraficos, this);
    this.graficos = [];
    this.loadGraficos();
    $(window).resize((function(_this) {
      return function() {
        return _this.resizeGraficos;
      };
    })(this));
  }

  desempenhoGraficoDeIndicadorController.prototype.loadGraficos = function() {
    return $('.js-graficodeindicador', this.contexto).each((function(_this) {
      return function() {
        return _this.carregarGrafico($( this ).data('desempenhoid'));
      };
    })(this));
  };

  desempenhoGraficoDeIndicadorController.prototype.carregarGrafico = function(id) {
    var $container, grafico, informacoes;
    $container = $("#grafico-" + id).find('.js-graficodeindicador');
    if ($container.data('carregado') === false) {
      $container.data('carregado', true);
      informacoes = this.normalizarInformacoes($container.data());
      grafico = new GraficoDeIndicador("#grafico-" + id + " .js-graficodeindicador");
      grafico.setBase(informacoes.IndicadorId, null, null, null, null, null, null, null, informacoes.Frequencia, informacoes.ModeloDeGraficoId, 'Apurado', informacoes.TipoDeDesdobramento, informacoes.Data, null, false, informacoes.Ocorrencia);
      grafico.renderWithoutControls();
      grafico.setTitle();
      this.graficos.push(grafico);
      return this.bindDetalhesDoIndicador($("#grafico-" + id));
    }
  };

  desempenhoGraficoDeIndicadorController.prototype.normalizarInformacoes = function(informacoes) {
    return {
      IndicadorId: informacoes.indicadorid,
      Frequencia: informacoes.frequencia,
      ModeloDeGraficoId: informacoes.modelodegraficoid,
      TipoDeDesdobramento: informacoes.tipodedesdobramento,
      Data: informacoes.ocorrencia,
      Ocorrencia: informacoes.ocorrencia
    };
  };

  desempenhoGraficoDeIndicadorController.prototype.reload = function() {
    return $as.PainelUnificado.CarregarDesempenho.get().success((function(_this) {
      return function(data) {
        return $("#desempenho").html(data).fadeIn().css("display", "");
      };
    })(this));
  };

  desempenhoGraficoDeIndicadorController.prototype.aoSalvar = function(data) {
    var $item, id;
    id = data.data;
    $item = $("#grafico-" + id);
    if ($item.length) {
      return $as.Performance.DesempenhoGraficoDeIndicador.ItemArvoreDesempenho.get({
        Id: id
      }).success((function(_this) {
        return function(html) {
          $item.html(html);
          _this.bindDetalhesDoIndicador($item);
          return _this.loadGraficos();
        };
      })(this));
    } else {
      return this.reloadContainerDesempenho();
    }
  };

  desempenhoGraficoDeIndicadorController.prototype.resizeGraficos = function() {
    var grafico, i, len, ref, results;
    ref = this.graficos;
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      grafico = ref[i];
      results.push(grafico.reflow());
    }
    return results;
  };

  desempenhoGraficoDeIndicadorController.prototype.bindDetalhesDoIndicador = function($contexto) {
    return $contexto.find('.js-exibir-detalhes-indicador').click((function(_this) {
      return function(e) {
        var dados, elemento;
        elemento = $(e.currentTarget);
        dados = elemento.data();
        dados = _this.normalizarDadosDaLinha(dados);
        return Results.api.exibirDetalhesPorIdDoIndicador(dados.IdIndicador, dados.Ocorrencia, dados.Frequencia);
      };
    })(this));
  };

  desempenhoGraficoDeIndicadorController.prototype.normalizarDadosDaLinha = function(dados) {
    return {
      IdIndicador: dados.idindicador,
      IdIndicadorBase: dados.idindicadorbase,
      IdUnidade: dados.idunidade,
      PossuiApenasReal: dados.possuiapenasreal,
      UnidadeDeMedida: dados.unidadedemedida,
      IdDoPlanoDeGestao: dados.iddoplanodegestao,
      NumeroDoMes: dados.numerodomes,
      MesSemanaDia: dados.messemanadia,
      Frequencia: this.options.Frequencia,
      Ocorrencia: dados.ocorrencia
    };
  };

  desempenhoGraficoDeIndicadorController.prototype.reloadCabecalho = function(data) {
    return $as.PainelUnificado.CabecalhoPainelDesempenho.get({
      IdRelatorioSelecionado: data.data
    }).success((function(_this) {
      return function(html) {
        $('#cabecalho-desempenho', _this.contexto).html(html);
        return $('[rel=tooltip]').tooltip();
      };
    })(this));
  };

  desempenhoGraficoDeIndicadorController.prototype.reloadContainerDesempenho = function() {
    var $IdRelatorioSelecionado;
    $IdRelatorioSelecionado = $('#IdRelatorioSelecionado', this.contexto).val();
    return $as.PainelUnificado.RecarregarContainerDesempenho.get({
      IdRelatorioSelecionado: $('#IdRelatorioSelecionado', this.contexto).val()
    }).success((function(_this) {
      return function(html) {
        $('#container-desempenho', _this.contexto).html(html);
        $('[rel=tooltip]').tooltip();
        if ($IdRelatorioSelecionado === '') {
          _this.loadGraficos();
          return _this.reloadCabecalho({
            data: null
          });
        }
      };
    })(this));
  };

  return desempenhoGraficoDeIndicadorController;

})();
