﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.adicionarIndicadoresPorProgramaController = (function() {
  function adicionarIndicadoresPorProgramaController(view, options) {
    this.view = view;
    this.options = options;
    this.reloadIndicadoresPorPrograma = bind(this.reloadIndicadoresPorPrograma, this);
    this.adicionarIndicadores = bind(this.adicionarIndicadores, this);
    this.filtrarIndicadores = bind(this.filtrarIndicadores, this);
    this.carregarComboDeAreasDeResultados = bind(this.carregarComboDeAreasDeResultados, this);
    this.carregarComboDeUnidades = bind(this.carregarComboDeUnidades, this);
    $(this.view).window({
      width: '750px',
      minheight: '400px'
    });
    this.carregarComboDeUnidades();
    this.carregarComboDeAreasDeResultados();
    this.$selecaoDeIndicadoresContainer = $('#selecaoDeIndicadores-container', this.view);
    this.botaoSalvar = $('#js-adicionarIndicadores', this.view);
    this.botaoSalvar.click(this.adicionarIndicadores);
    this.botaoFechar = $('#close-modal-adicionarindicadoresporprograma', this.view);
    this.$indicadoresPorProgramaContainer = $('#linhasDosIndicadores-container', '#box-programa-resultados');
    this.calcularSomaDosPesos = window.indicadoresPorProgramaDeResultadosController.calcularSomaDosPesos;
  }

  adicionarIndicadoresPorProgramaController.prototype.carregarComboDeUnidades = function() {
    return setCombo(this.view, '#UnidadeGerencial_SiglaAtual', this.filtrarIndicadores);
  };

  adicionarIndicadoresPorProgramaController.prototype.carregarComboDeAreasDeResultados = function() {
    return setCombo(this.view, '#AreaDeResultados_Nome', this.filtrarIndicadores, null, null, null, this.options.defaultOption);
  };

  adicionarIndicadoresPorProgramaController.prototype.filtrarIndicadores = function() {
    var idDaAreaDeResultados, idDaUnidade;
    idDaUnidade = $('#UnidadeGerencial_Id', this.view).val();
    idDaAreaDeResultados = $('#AreaDeResultados_Id', this.view).val();
    return $as.Performance.IndicadoresPorProgramasDeResultados.SelecaoDeIndicadoresPorAreaDeResultadosEUnidade.get({
      idDaUnidade: idDaUnidade,
      idDaAreaDeResultados: idDaAreaDeResultados
    }).done((function(_this) {
      return function(data) {
        return _this.$selecaoDeIndicadoresContainer.html(data);
      };
    })(this));
  };

  adicionarIndicadoresPorProgramaController.prototype.adicionarIndicadores = function() {
    return $as.Performance.IndicadoresPorProgramasDeResultados.AdicionarIndicadores.post($('#form-adicionarIndicadores').serialize()).done((function(_this) {
      return function(data) {
        var idDoPrograma;
        if (data.success) {
          idDoPrograma = _this.$indicadoresPorProgramaContainer.data('id');
          return _this.reloadIndicadoresPorPrograma(idDoPrograma);
        } else {
          return _this.$indicadoresPorProgramaContainer.html(data);
        }
      };
    })(this));
  };

  adicionarIndicadoresPorProgramaController.prototype.reloadIndicadoresPorPrograma = function(idDoProgramaPorUsuario) {
    return $as.Performance.IndicadoresPorProgramasDeResultados.IndicadoresPorPrograma.get({
      idDoProgramaPorUsuario: idDoProgramaPorUsuario
    }).done((function(_this) {
      return function(data) {
        return _this.$indicadoresPorProgramaContainer.html(data);
      };
    })(this));
  };

  return adicionarIndicadoresPorProgramaController;

})();
