﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.propriedadesDoIndicadorController = (function() {
  function propriedadesDoIndicadorController(view, options, resource) {
    var modal;
    this.view = view;
    this.options = options;
    this.resource = resource;
    this.alterarPrioridadeECasasDecimais = bind(this.alterarPrioridadeECasasDecimais, this);
    this.configurarSalvarQuandoObtemDados = bind(this.configurarSalvarQuandoObtemDados, this);
    this.salvar = bind(this.salvar, this);
    this.salvarTolerancia = bind(this.salvarTolerancia, this);
    this.configurarSalvar = bind(this.configurarSalvar, this);
    this.toggleTolerancia = bind(this.toggleTolerancia, this);
    this.manipularToleranciasPorSinalDeMelhor = bind(this.manipularToleranciasPorSinalDeMelhor, this);
    this.graficoDeTolerancia = bind(this.graficoDeTolerancia, this);
    this.exibirMensagemParaCarregarSeNecessario = bind(this.exibirMensagemParaCarregarSeNecessario, this);
    this.fecharPropriedades = bind(this.fecharPropriedades, this);
    this.atualizarValorPrecisao = bind(this.atualizarValorPrecisao, this);
    this.somarPrecisao = bind(this.somarPrecisao, this);
    this.atualizarGraficoDeTolerancia = bind(this.atualizarGraficoDeTolerancia, this);
    this.aoSalvarPropriedades = bind(this.aoSalvarPropriedades, this);
    this.ajustarTipoDeBenchmark = bind(this.ajustarTipoDeBenchmark, this);
    this.configurarTipoDeBenchmark = bind(this.configurarTipoDeBenchmark, this);
    this.ajustarFormaDeAcumulo = bind(this.ajustarFormaDeAcumulo, this);
    this.configurarFormaDeAcumulo = bind(this.configurarFormaDeAcumulo, this);
    this.ajustarTipoDeBenchMark = bind(this.ajustarTipoDeBenchMark, this);
    this.configurarTipoDeBenchMark = bind(this.configurarTipoDeBenchMark, this);
    this.configurarCampoValorBenchMark = bind(this.configurarCampoValorBenchMark, this);
    this.desabilitarCampos = bind(this.desabilitarCampos, this);
    this.elementoComFoco = null;
    this.$view = $(this.view);
    modal = new modalLateral(this.$view);
    WindowZIndex += 2;
    this.botaoFechar = $("#js-fecharPropriedades", this.$view);
    this.botaoFechar.click(this.fecharPropriedades);
    window.redimensionarModalLateral();
    $("[rel=tooltip]", this.view).tooltip();
    $(this.view).find("input[alt=percent]").setMask();
    $(this.view).find("input[alt=decimal]").setMask();
    if (this.options.podeAlterarOsDadosDoIndicador) {
      this.configurarTipoDeBenchmark();
      this.configurarFormaDeAcumulo();
      this.precisao = $("#CasasDecimais");
      this.precisaoMaxima = 9;
      this.precisaoMinima = 0;
      this.configurarControleDePrecisao();
      this.atualizarValorPrecisao(0, parseInt(this.precisao.val()));
      this.somarPrecisao(0, this.precisaoMaxima, true);
      this.configurarCampoValorBenchMark();
      this.configurarSalvar();
    } else {
      this.desabilitarCampos();
      if (this.options.obtemDados) {
        $('#Prioridade, #CasasDecimais, #IdDoIndicadorDoFarol', this.view).removeAttr('disabled');
        this.precisaoMaxima = 9;
        this.precisaoMinima = 0;
        this.precisao = $("#CasasDecimais");
        this.configurarControleDePrecisao();
        this.atualizarValorPrecisao(0, parseInt(this.precisao.val()));
        this.somarPrecisao(0, this.precisaoMaxima, true);
        this.configurarSalvarQuandoObtemDados();
      }
    }
    this.posicaoMelhor = $('#PosicaoMelhor', this.view).val();
    this.manipularToleranciasPorSinalDeMelhor(this.posicaoMelhor);
    this.graficoDeTolerancia();
  }

  propriedadesDoIndicadorController.prototype.desabilitarCampos = function() {
    var abaBenchMark, abaDetalhes;
    $('#opcoes-label', this.view).find('.btn').attr('disabled', 'disabled');
    abaDetalhes = $('#propriedadesDoIndicador-modal', this.view);
    abaDetalhes.find(':input').attr('disabled', 'disabled');
    abaDetalhes.find('.input-group-addon').removeClass('cursor-pointer');
    abaBenchMark = $('#collapseTwo', this.view);
    return abaBenchMark.find(':input').attr('disabled', 'disabled');
  };

  propriedadesDoIndicadorController.prototype.configurarCampoValorBenchMark = function() {
    var $campo;
    $campo = $('#ValorDeBenchMark', this.view);
    if ($campo.val() !== '') {
      $campo.val(window.FormatarNumero($campo.val(), this.precisao.val()));
    }
    return $campo.keypress(common.formatar.setarMascaraDecimal).change((function(_this) {
      return function() {
        return $campo.val(window.FormatarNumero($campo.val(), _this.precisao.val()));
      };
    })(this));
  };

  propriedadesDoIndicadorController.prototype.configurarTipoDeBenchMark = function() {
    return $('.autoSaveTipoBenchMark', this.view).click(this.ajustarTipoDeBenchMark);
  };

  propriedadesDoIndicadorController.prototype.ajustarTipoDeBenchMark = function(evento) {
    var botao, valor;
    botao = $(evento.currentTarget);
    valor = botao.attr("option");
    $('#TipoDeBenchmark', this.view).val(botao.attr("option"));
    return $('#labelTipoDeBenchMark', this.view).text(botao.text());
  };

  propriedadesDoIndicadorController.prototype.configurarFormaDeAcumulo = function() {
    return $('.autoSaveFormaDeAcumulo', this.view).click(this.ajustarFormaDeAcumulo);
  };

  propriedadesDoIndicadorController.prototype.ajustarFormaDeAcumulo = function(evento) {
    var botao, valor;
    botao = $(evento.currentTarget);
    valor = botao.attr("option");
    $('#AgrupamentoDeDimensoes', this.view).val(botao.attr("option"));
    $('#labelFormaDeAcumulo', this.view).text(botao.text());
    return this.salvar(false);
  };

  propriedadesDoIndicadorController.prototype.configurarTipoDeBenchmark = function() {
    return $('.js-tipoDeBenchmark', this.view).click(this.ajustarTipoDeBenchmark);
  };

  propriedadesDoIndicadorController.prototype.ajustarTipoDeBenchmark = function(evento) {
    var botao, valor;
    botao = $(evento.currentTarget);
    valor = botao.attr("option");
    $('#TipoDeBenchmark', this.view).val(botao.attr("option"));
    $('#labelTipoDeBenchMark', this.view).text(botao.text());
    return this.salvar(false);
  };

  propriedadesDoIndicadorController.aoDesativarIndicador = function(id) {
    propriedadesDoIndicadorController.marcarComoAlterado();
    return propriedadesDoIndicadorController.recarregar(id);
  };

  propriedadesDoIndicadorController.prototype.aoSalvarPropriedades = function(data, reload) {
    var $divValidacao;
    if (data.success) {
      propriedadesDoIndicadorController.marcarComoAlterado();
      if (reload) {
        return propriedadesDoIndicadorController.recarregar(data.data.id);
      } else {
        $divValidacao = $(this.view).find('#indicador-validation');
        if ($divValidacao.is(':visible')) {
          $('#indicador-validation').html('');
          $(this.view).find('.error').removeClass('error');
          return $(this.view).find('.input-validation-error').removeClass('input-validation-error');
        }
      }
    } else {
      return window.GetDiv('box-propriedade-indicador').html(data);
    }
  };

  propriedadesDoIndicadorController.recarregar = function(idDoIndicador) {
    return $as.Performance.Indicadores.Propriedades.get({
      idIndicador: idDoIndicador
    }).done(function(data) {
      return window.GetDiv('box-propriedade-indicador').html(data);
    });
  };

  propriedadesDoIndicadorController.prototype.atualizarGraficoDeTolerancia = function() {
    var formIndicador;
    formIndicador = $('#create-edit-indicador', this.view).serialize();
    return $as.Performance.Indicadores.AtualizarGraficoDeTolerancia.post(formIndicador).done((function(_this) {
      return function(data) {
        $('#graficoDeTolerancia-container').html(data);
        return _this.graficoDeTolerancia();
      };
    })(this));
  };

  propriedadesDoIndicadorController.prototype.configurarControleDePrecisao = function() {
    var controleDePrecisao;
    controleDePrecisao = $('#controleDePrecisao');
    $('.js-somar', controleDePrecisao).click((function(_this) {
      return function() {
        return _this.somarPrecisao(1, _this.precisaoMaxima);
      };
    })(this));
    return $('.js-subtrair', controleDePrecisao).click((function(_this) {
      return function() {
        return _this.somarPrecisao(-1, _this.precisaoMinima);
      };
    })(this));
  };

  propriedadesDoIndicadorController.prototype.somarPrecisao = function(mais, limite, naoSalvar) {
    var valorAtual;
    valorAtual = parseInt(this.precisao.val());
    if (valorAtual !== limite && !isNaN(valorAtual)) {
      this.atualizarValorPrecisao(mais, valorAtual);
      if (!naoSalvar) {
        if (this.options.obtemDados) {
          return this.alterarPrioridadeECasasDecimais();
        } else {
          return this.salvar(false);
        }
      }
    }
  };

  propriedadesDoIndicadorController.prototype.atualizarValorPrecisao = function(mais, valorAtual) {
    var qtd, txt;
    qtd = valorAtual + mais;
    if (qtd === 0) {
      txt = '###.##0';
    } else {
      txt = '###.##0,';
    }
    txt = txt + window.repeatString('0', qtd);
    this.precisao.val(qtd);
    return $('#QntQcasasDecimais').val(txt);
  };

  propriedadesDoIndicadorController.prototype.fecharPropriedades = function() {
    this.botaoFechar.tooltip('toggle');
    this.$view.empty();
    return Results.api.mostarMensagemParaCarregarSeNecessario(this.resource, propriedadesDoIndicadorController);
  };

  propriedadesDoIndicadorController.prototype.exibirMensagemParaCarregarSeNecessario = function() {
    return Results.api.mostarMensagemRecarregarFarol(this.resource);
  };

  propriedadesDoIndicadorController.houveAlteracao = false;

  propriedadesDoIndicadorController.marcarComoAlterado = function() {
    return this.houveAlteracao = true;
  };

  propriedadesDoIndicadorController.prototype.graficoDeTolerancia = function() {
    var grafico;
    grafico = new graficoDeToleranciaController(this.view, "#graficoDeTolerancia-container", "#PosicaoMelhor", "#ToleranciaAmarelaSuperior", "#ToleranciaAmarelaInferior", "#ToleranciaVerdeSuperior", "#ToleranciaVerdeInferior", "#ToleranciaAzul");
    return grafico.rederizarGrafico();
  };

  propriedadesDoIndicadorController.prototype.manipularToleranciasPorSinalDeMelhor = function(sinalDeMelhor) {
    switch (sinalDeMelhor) {
      case 'ParaCima':
        return this.toggleTolerancia(false);
      case 'ParaBaixo':
        return this.toggleTolerancia(false);
      case 'MelhorNoPonto':
        return this.toggleTolerancia(true);
      case 'Faixa':
        return this.toggleTolerancia(true);
    }
  };

  propriedadesDoIndicadorController.prototype.toggleTolerancia = function(exibirTolerancias) {
    if (exibirTolerancias) {
      $("#ToleranciaAzul").parent().hide();
      $("#ToleranciaAmarelaInferior").parent().show();
      $("#ToleranciaVerdeInferior").parent().show();
      $("#ToleranciaAmarelaSuperior").nextAll("label").show();
      return $("#ToleranciaVerdeSuperior").nextAll("label").show();
    } else {
      $("#ToleranciaAzul").parent().show();
      $("#ToleranciaAmarelaInferior").parent().hide();
      $("#ToleranciaVerdeInferior").parent().hide();
      $("#ToleranciaAmarelaSuperior").nextAll("label").hide();
      return $("#ToleranciaVerdeSuperior").nextAll("label").hide();
    }
  };

  propriedadesDoIndicadorController.prototype.configurarSalvar = function() {
    $('#Prioridade', this.view).change((function(_this) {
      return function() {
        return _this.salvar(false);
      };
    })(this));
    $('#Ponderacao', this.view).change((function(_this) {
      return function() {
        return _this.salvar(false);
      };
    })(this));
    $('[name=PossuiApenasReal]', this.view).change((function(_this) {
      return function() {
        return _this.salvar(false);
      };
    })(this));
    $('#FrequenciasAplicaveis_Mensal', this.view).change((function(_this) {
      return function() {
        return _this.salvar(false);
      };
    })(this));
    $('#FrequenciasAplicaveis_Semanal', this.view).change((function(_this) {
      return function() {
        return _this.salvar(false);
      };
    })(this));
    $('#FrequenciasAplicaveis_Diaria', this.view).change((function(_this) {
      return function() {
        return _this.salvar(false);
      };
    })(this));
    $('[name=ComparacaoDaMeta]', this.view).change((function(_this) {
      return function() {
        return _this.salvar(false);
      };
    })(this));
    $('#CasasDecimais', this.view).change((function(_this) {
      return function() {
        return _this.salvar(false);
      };
    })(this));
    $('#ValorDeBenchMark', this.view).change((function(_this) {
      return function() {
        return _this.salvar(false);
      };
    })(this));
    $('#FonteDeBenchmark', this.view).change((function(_this) {
      return function() {
        return _this.salvar(false);
      };
    })(this));
    $('#ToleranciaAzul', this.view).change((function(_this) {
      return function() {
        return _this.salvarTolerancia(false);
      };
    })(this));
    $('#ToleranciaAmarelaInferior', this.view).change((function(_this) {
      return function() {
        return _this.salvarTolerancia(false);
      };
    })(this));
    $('#ToleranciaVerdeInferior', this.view).change((function(_this) {
      return function() {
        return _this.salvarTolerancia(false);
      };
    })(this));
    $('#ToleranciaAmarelaSuperior', this.view).change((function(_this) {
      return function() {
        return _this.salvarTolerancia(false);
      };
    })(this));
    $('#ToleranciaVerdeSuperior', this.view).change((function(_this) {
      return function() {
        return _this.salvarTolerancia(false);
      };
    })(this));
    $('#formas-de-acumulo', this.view).change((function(_this) {
      return function() {
        return _this.salvar(false);
      };
    })(this));
    return this.configurarFormaDeAcumulo();
  };

  propriedadesDoIndicadorController.prototype.salvarTolerancia = function() {
    this.salvar(false);
    return this.atualizarGraficoDeTolerancia();
  };

  propriedadesDoIndicadorController.prototype.salvar = function(reload) {
    return $as.Performance.Indicadores.Propriedades.post($('#create-edit-indicador').serialize()).done((function(_this) {
      return function(data) {
        return _this.aoSalvarPropriedades(data, reload);
      };
    })(this));
  };

  propriedadesDoIndicadorController.prototype.configurarSalvarQuandoObtemDados = function() {
    return $('#Prioridade, #CasasDecimais', this.view).change(this.alterarPrioridadeECasasDecimais);
  };

  propriedadesDoIndicadorController.prototype.alterarPrioridadeECasasDecimais = function() {
    var dados;
    dados = $('#Prioridade, #CasasDecimais, #IdDoIndicadorDoFarol', this.view).serialize();
    return $as.Performance.Indicadores.AlterarPrioridadeECasasDecimais.post(dados).done((function(_this) {
      return function(data) {
        var $divValidacao, erro, i, len, lista, ref;
        $divValidacao = $(_this.view).find('#indicador-validation');
        if (data.error) {
          $divValidacao.empty();
          $divValidacao.append('<div><ul></ul></div>');
          lista = $divValidacao.find('ul');
          ref = data.data;
          for (i = 0, len = ref.length; i < len; i++) {
            erro = ref[i];
            $('#' + erro.nome).parent().addClass('error');
            lista.append("<li data-field-name='" + erro.nome + "' data-field-id='" + erro.nome + "'>" + erro.erro + "</li>");
          }
          return $divValidacao.addClass('validation-summary-errors');
        } else {
          $divValidacao.removeClass('validation-summary-errors').find('ul').remove();
          return $('.error').removeClass('error');
        }
      };
    })(this));
  };

  return propriedadesDoIndicadorController;

})();
