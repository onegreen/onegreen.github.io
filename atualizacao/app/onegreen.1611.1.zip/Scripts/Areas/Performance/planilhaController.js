﻿var ValorDoIndicador,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.planilhaController = (function() {
  function planilhaController(options, resource) {
    this.options = options;
    this.resource = resource;
    this.normalizarDadosDaLinha = bind(this.normalizarDadosDaLinha, this);
    this.abrirArvoreDesdobramento = bind(this.abrirArvoreDesdobramento, this);
    this.fecharMenuDoIndicador = bind(this.fecharMenuDoIndicador, this);
    this.carregarMenuIndicador = bind(this.carregarMenuIndicador, this);
    this.ativarMenuIndicador = bind(this.ativarMenuIndicador, this);
    this.numeroAletorio = bind(this.numeroAletorio, this);
    this.preencherAutomaticamenteAPlanilhaComValoresAleatorios = bind(this.preencherAutomaticamenteAPlanilhaComValoresAleatorios, this);
    this.comutarFrequencia = bind(this.comutarFrequencia, this);
    this.desselecionarCelula = bind(this.desselecionarCelula, this);
    this.solicitarSalvamento = bind(this.solicitarSalvamento, this);
    this.alterarFiltro = bind(this.alterarFiltro, this);
    this.recarrecarPlanilha = bind(this.recarrecarPlanilha, this);
    this.colarDados = bind(this.colarDados, this);
    this.autoCompletar = bind(this.autoCompletar, this);
    this.limparLinha = bind(this.limparLinha, this);
    this.construirIndicador = bind(this.construirIndicador, this);
    this.agruparValores = bind(this.agruparValores, this);
    this.salvarValores = bind(this.salvarValores, this);
    this.salvarPlanilha = bind(this.salvarPlanilha, this);
    this.criarValorPelaCelula = bind(this.criarValorPelaCelula, this);
    this.criarValorDoIndicador = bind(this.criarValorDoIndicador, this);
    this.obterIdCelulaEditada = bind(this.obterIdCelulaEditada, this);
    this.refazerEdicao = bind(this.refazerEdicao, this);
    this.desfazerEdicao = bind(this.desfazerEdicao, this);
    this.decrementarNumeroDaAcao = bind(this.decrementarNumeroDaAcao, this);
    this.incrementarNumeroDaAcao = bind(this.incrementarNumeroDaAcao, this);
    this.verificaTeclasParaEdicao = bind(this.verificaTeclasParaEdicao, this);
    this.limparFarolMeta = bind(this.limparFarolMeta, this);
    this.configurarEdicaoPlanilha = bind(this.configurarEdicaoPlanilha, this);
    this.templateDosBotoesDeAcaoDaPlanilha = bind(this.templateDosBotoesDeAcaoDaPlanilha, this);
    this.deslocarEmXY = bind(this.deslocarEmXY, this);
    this.destruirToolTipBloqueio = bind(this.destruirToolTipBloqueio, this);
    this.configurarTooltipBloqueio = bind(this.configurarTooltipBloqueio, this);
    this.destacarSelecao = bind(this.destacarSelecao, this);
    this.marcarCelula = bind(this.marcarCelula, this);
    this.celulaJaEstaMarcada = bind(this.celulaJaEstaMarcada, this);
    this.selecionarCelula = bind(this.selecionarCelula, this);
    this.entrarNaCelula = bind(this.entrarNaCelula, this);
    this.editarCelula = bind(this.editarCelula, this);
    this.atualizarCelulaSelecionada = bind(this.atualizarCelulaSelecionada, this);
    this.exibirDetalhesDoIndicador = bind(this.exibirDetalhesDoIndicador, this);
    this.eventoExibirDetalhesDoIndicador = bind(this.eventoExibirDetalhesDoIndicador, this);
    this.pegarCelula = bind(this.pegarCelula, this);
    this.resetarCampoFlutuante = bind(this.resetarCampoFlutuante, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.scrollPlanilha = bind(this.scrollPlanilha, this);
    this.configurarScrollPlanilha = bind(this.configurarScrollPlanilha, this);
    this.reduzirAgrupadores = bind(this.reduzirAgrupadores, this);
    this.redimensionarPlanilha = bind(this.redimensionarPlanilha, this);
    this.getRange = bind(this.getRange, this);
    this.setarMascaraDecimal = bind(this.setarMascaraDecimal, this);
    this.marcarCelulaInicial = bind(this.marcarCelulaInicial, this);
    this.configurarFiltroDeIndicador = bind(this.configurarFiltroDeIndicador, this);
    this.DecimalFormatRegex = this.resource.DecimalFormatRegex;
    this.PlanilhaDireita = $('#planilhaDireita', this.options.Contexto);
    this.PlanilhaEsquerda = $("#planilhaEsquerda", this.options.Contexto);
    this.CampoFixoValorDoIndicador = $("#ValorDoIndicadorFixo", this.options.Contexto);
    this.CampoFlutuanteValorDoIndicador = $("#ValorDoIndicadorFlutuante", this.options.Contexto);
    this.CabecalhoDaTabela = $("#js-cabecalho", this.options.Contexto);
    this.Agrupadores = $(".planilha-agrupador", this.options.Contexto);
    this.FuncoesDaPlanilha = $("#funcoesDaPlanilha", this.options.Contexto);
    this.Header = $("header");
    this.ClassesFarol = "meta-azul meta-verde meta-amarela meta-vermelha meta-neutra";
    this.NumeroDoMes = $('#NumeroDoMes', "#containerFiltroAvancadoIndicador").val();
    this.teclasNoASCIIFirefox = ["Right", "Left", "Backspace", "Del", "ArrowRight", "ArrowLeft", "Backspace", "Delete"];
    this.NumeroDaAcao = 0;
    this.Campos = {
      0: 'Nenhum',
      1: 'Realizado',
      2: 'Meta',
      3: 'MetaInferior',
      4: 'MetaSuperior',
      5: 'Ritmo'
    };
    this.exibindoSolicitacaoDeSalvamento = false;
    this.TemplateDosBotoesDeAcaoDaPlanilha = this.templateDosBotoesDeAcaoDaPlanilha();
    this.CelulaSelecionada;
    this.CelulaSelecionadaAnterior;
    if (window.ValoresDoIndicador === void 0) {
      window.ValoresDoIndicador = [];
    }
    if (window.ValoresDoIndicadorDesfeitos === void 0) {
      window.ValoresDoIndicadorDesfeitos = [];
    }
    this.valorAntigo = '';
    this.proximoValorAntigo;
    this.editando;
    this.escapando = false;
    this.usouTeclado = false;
    this.desfazendoOuRefazendo = false;
    this.valorDoIndicadorAlterado;
    this.MesSemanaDia = this.options.FiltroAvancado.MesSemanaDia;
    this.configurarScrollPlanilha();
    this.redimensionarPlanilha();
    this.configurarBinds();
    this.configurarEdicaoPlanilha();
    this.ativarMenuIndicador();
    this.configurarFiltroDeIndicador();
    $(window).resize((function(_this) {
      return function() {
        return _this.redimensionarPlanilha();
      };
    })(this));
    window.MarcarMenuSuperior("#lnkPlanilhaDeIndicador");
    $("[alt='signed-decimal']").keypress((function(_this) {
      return function(e) {
        return _this.setarMascaraDecimal(e);
      };
    })(this));
    $("[rel='tooltip']").tooltip();
    this.marcarCelulaInicial();
    window.filtroUGEPlanoDeGestao.configurar('#filtro-ug-topo', window.planilhaController.alterarUnidade, window.planilhaController.alterarPlanoDeGestao);
    window.filtroAvancadoDeIndicadoresController.origem = Results.api.Origem.Planilha;
    Results.api.verificarSeExisteConsolidacaoDoUsuarioEmAndamento();
  }

  planilhaController.prototype.configurarFiltroDeIndicador = function() {
    return window.FiltroAvancadoDeIndicador = this.options.FiltroAvancado;
  };

  planilhaController.prototype.marcarCelulaInicial = function() {
    var celula, coluna, index, linha, width;
    if (window.PlanilhaDeIndicadores.ManterPosicao) {
      if (window.PlanilhaDeIndicadores.LinhaSelecionada > -1 && window.PlanilhaDeIndicadores.CelulaSelecionada > -1) {
        linha = $("tr", this.PlanilhaDireita)[window.PlanilhaDeIndicadores.LinhaSelecionada];
        celula = $(linha).find("td")[window.PlanilhaDeIndicadores.CelulaSelecionada];
        this.CelulaSelecionada = $(celula);
        this.marcarCelula(this.CelulaSelecionada);
      }
      if (window.PlanilhaDeIndicadores.ScrollLeft > -1 && window.PlanilhaDeIndicadores.ScrollTop > -1) {
        this.PlanilhaDireita.scrollLeft(window.PlanilhaDeIndicadores.ScrollLeft);
        this.PlanilhaDireita.scrollTop(window.PlanilhaDeIndicadores.ScrollTop);
      }
    }
    if (!this.CelulaSelecionada) {
      coluna = $("#js-cabecalho li.selecionado");
      index = coluna.index();
      width = coluna.outerWidth();
      this.PlanilhaDireita.scrollLeft((index - 2) * width);
    }
    return window.PlanilhaDeIndicadores.ManterPosicao = true;
  };

  planilhaController.prototype.setarMascaraDecimal = function(e) {
    var keycode, target;
    target = e.target || e.srcElement;
    keycode = e.charCode || e.keyCode;
    if (this.teclasNoASCIIFirefox.contains(e.originalEvent.key)) {
      return true;
    } else {
      return window.VerificarValor(target, keycode);
    }
  };

  planilhaController.prototype.getRange = function(input) {
    var pos, range;
    if (!$.browser.msie) {
      return {
        start: input.selectionStart,
        end: input.selectionEnd
      };
    }
    pos = {
      start: 0,
      end: 0
    };
    range = document.selection.createRange();
    pos.start = 0 - range.duplicate().moveStart('character', -100000);
    pos.end = pos.start + range.text.length;
    return pos;
  };

  planilhaController.prototype.redimensionarPlanilha = function() {
    var altura, heightOuMax, offset;
    this.reduzirAgrupadores();
    heightOuMax = "height";
    offset = this.PlanilhaEsquerda.offset();
    if (offset) {
      altura = $(window).innerHeight() - (offset.top + this.Agrupadores.height() + 20);
      this.PlanilhaEsquerda.css(heightOuMax, altura);
      return this.PlanilhaDireita.css(heightOuMax, altura);
    }
  };

  planilhaController.prototype.reduzirAgrupadores = function() {
    var results;
    $("#agrupamento-de-indicadores").removeClass("none");
    results = [];
    while (this.Agrupadores.height() > 30) {
      results.push($('.js-btnAreaDeResultado div').find('.btn-agrupador').last().remove());
    }
    return results;
  };

  planilhaController.prototype.configurarScrollPlanilha = function() {
    var mousewheelevt, onScroll, planilhaDireita;
    if (!/Firefox/i.test(navigator.userAgent)) {
      this.PlanilhaEsquerda.scroll((function(_this) {
        return function(data) {
          return _this.scrollPlanilha(data, _this.PlanilhaDireita, false);
        };
      })(this));
    }
    this.PlanilhaDireita.scroll((function(_this) {
      return function(data) {
        return _this.scrollPlanilha(data, _this.PlanilhaEsquerda, true);
      };
    })(this));
    mousewheelevt = /Firefox/i.test(navigator.userAgent) ? "DOMMouseScroll" : "mousewheel";
    planilhaDireita = this.PlanilhaDireita;
    onScroll = function(e) {
      var scroll;
      scroll = planilhaDireita.scrollTop() + (-e.wheelDelta || e.detail * 40);
      return planilhaDireita.scrollTop(scroll);
    };
    if (this.PlanilhaDireita.length > 0) {
      if (document.attachEvent) {
        return this.PlanilhaEsquerda[0].attachEvent("on" + mousewheelevt, function(e) {
          return onScroll(e);
        });
      } else if (document.addEventListener) {
        return this.PlanilhaEsquerda[0].addEventListener(mousewheelevt, function(e) {
          return onScroll(e);
        }, false);
      }
    }
  };

  planilhaController.prototype.scrollPlanilha = function(data, planilha, scrollCabecalho) {
    planilha.scrollTop(data.target.scrollTop);
    if (scrollCabecalho) {
      $(".planilha-mensal", this.options.Contexto).scrollLeft(data.target.scrollLeft);
    }
    window.PlanilhaDeIndicadores.ScrollLeft = data.target.scrollLeft;
    return window.PlanilhaDeIndicadores.ScrollTop = data.target.scrollTop;
  };

  planilhaController.prototype.configurarBinds = function() {
    $(".js-btnAreaDeResultado button, .js-btnAreaDeResultado a", this.options.Contexto).click((function(_this) {
      return function() {
        var parametros;
        parametros = {
          idDaAreaDeResultados: $( this ).data("areaderesultado"),
          nomeDaAreaDeResultado: $( this ).text()
        };
        return _this.alterarFiltro('MudarAreaDeResultados', parametros, window.reload);
      };
    })(this));
    $("a", this.CabecalhoDaTabela).click((function(_this) {
      return function() {
        _this.MesSemanaDia = $( this ).data("messemanadia");
        return $as.Performance.FiltroDeIndicadores.MudarOcorrencia.post({
          ocorrencia: _this.MesSemanaDia
        }).done(function(data) {
          return _this.recarrecarPlanilha();
        });
      };
    })(this));
    $("a.mudarmes", $("#comutador-mes")).click((function(_this) {
      return function() {
        return $as.Performance.FiltroDeIndicadores.MudarMes.post({
          mes: $( this ).data("mes")
        }).done(function(data) {
          return window.reload();
        });
      };
    })(this));
    $('.js-exibir-detalhes-indicador-mensal', this.options.Contexto).unbind('click').click(this.eventoExibirDetalhesDoIndicador);
    return $("#cabecalho-esquerdo .js-comutador-frequencia li", this.options.Contexto).unbind('click').click(this.comutarFrequencia);
  };

  planilhaController.prototype.resetarCampoFlutuante = function() {
    return this.CampoFlutuanteValorDoIndicador.offset({
      top: 0,
      left: 0
    });
  };

  planilhaController.prototype.pegarCelula = function(evento) {
    var $elemento;
    window.filtroUGEPlanoDeGestao.toggleFiltroUGPlages(false);
    $("#navbar-conteudo #login").removeClass('open');
    if (evento.srcElement) {
      evento.cancelBubble = true;
      $elemento = $(evento.srcElement);
    } else if (evento.target) {
      evento.stopPropagation();
      $elemento = $(evento.target);
    }
    if ($elemento.is("div") || $elemento.is("span")) {
      return $elemento.closest("td");
    } else if ($elemento.is("td")) {
      return $elemento;
    } else if ($elemento.is("i")) {
      Results.api.exibirDetalhesPorIdDoIndicadorComMesSemanaDia($elemento.data('idindicador'), $elemento.closest('td').attr('oco'), this.options.FiltroAvancado.Frequencia);
      return $elemento.closest("td");
    }
  };

  planilhaController.prototype.eventoExibirDetalhesDoIndicador = function(event) {
    var dados;
    dados = $(event.delegateTarget).closest('.js-indicador-planilha').data();
    return this.exibirDetalhesDoIndicador(this.normalizarDadosDaLinha(dados), this.MesSemanaDia);
  };

  planilhaController.prototype.exibirDetalhesDoIndicador = function(informacoes, mesSemanaDia) {
    return Results.api.exibirDetalhesDoIndicador(informacoes, mesSemanaDia);
  };

  planilhaController.prototype.atualizarCelulaSelecionada = function(celula) {
    if (this.CelulaSelecionada !== void 0) {
      this.CelulaSelecionada.removeClass("borda-selecionada");
    }
    this.CelulaSelecionadaAnterior = this.CelulaSelecionada || $(celula);
    this.CelulaSelecionada = $(celula);
    return this.proximoValorAntigo = $("span", this.CelulaSelecionada).text();
  };

  planilhaController.prototype.editarCelula = function(evento) {
    this.atualizarCelulaSelecionada(this.pegarCelula(evento));
    return this.entrarNaCelula();
  };

  planilhaController.prototype.entrarNaCelula = function(celula) {
    if (!(celula === void 0 || celula.length === 0)) {
      this.atualizarCelulaSelecionada(celula);
    }
    if (this.CelulaSelecionada !== void 0) {
      if (this.CelulaSelecionada.data('bloqueado')) {
        return this.CelulaSelecionada.addClass("borda-selecionada");
      } else {
        this.destruirToolTipBloqueio();
        $("td.borda-selecionada", this.PlanilhaDireita).removeClass("borda-selecionada");
        this.CelulaSelecionada.addClass("borda-selecionada");
        this.proximoValorAntigo = $("span", this.CelulaSelecionada).text();
        this.CampoFlutuanteValorDoIndicador.val(this.proximoValorAntigo);
        this.CampoFlutuanteValorDoIndicador.css({
          width: this.CelulaSelecionada.width() - 8,
          height: this.CelulaSelecionada.height() - 8,
          display: "block"
        });
        this.CampoFlutuanteValorDoIndicador.offset({
          top: this.CelulaSelecionada.offset().top + 5,
          left: this.CelulaSelecionada.offset().left + 4
        }).focus().select();
        return this.editando = true;
      }
    }
  };

  planilhaController.prototype.selecionarCelula = function(evento) {
    var celula;
    this.usouTeclado = false;
    celula = this.pegarCelula(evento);
    if (this.CelulaSelecionada !== void 0 && this.celulaJaEstaMarcada(celula)) {
      return this.entrarNaCelula(this.CelulaSelecionada);
    } else {
      return this.marcarCelula(celula);
    }
  };

  planilhaController.prototype.celulaJaEstaMarcada = function(celula) {
    var linha, linhaSelecionada;
    if (celula !== void 0) {
      linha = celula.parent();
      linhaSelecionada = this.CelulaSelecionada.parent();
      return celula.index() === this.CelulaSelecionada.index() && linha.index() === linhaSelecionada.index();
    }
  };

  planilhaController.prototype.marcarCelula = function(celula) {
    if (!(celula === void 0 || celula.length === 0)) {
      this.atualizarCelulaSelecionada(celula);
    }
    if (this.CelulaSelecionada !== void 0) {
      if (this.CelulaSelecionada.data('bloqueado')) {
        return this.CelulaSelecionada.addClass("borda-selecionada");
      } else {
        this.destruirToolTipBloqueio();
        this.CelulaSelecionada.addClass("borda-selecionada");
        window.PlanilhaDeIndicadores.CelulaSelecionada = this.CelulaSelecionada.index();
        setTimeout((function(_this) {
          return function() {
            return _this.CampoFixoValorDoIndicador.focus();
          };
        })(this), 0);
        this.destacarSelecao();
        if (this.editando) {
          this.resetarCampoFlutuante();
        }
        return this.editando = false;
      }
    }
  };

  planilhaController.prototype.destacarSelecao = function() {
    var $linhasDasPlanilhasASerDestacada, colunaDoCabecalhoASerDestacada, idAco, idAcoSelecionado;
    idAco = this.CelulaSelecionada.parent().attr("idaco");
    window.PlanilhaDeIndicadores.LinhaSelecionada = this.CelulaSelecionada.parent().index();
    idAcoSelecionado = $("tr.bg-prateado:first").attr("idaco");
    colunaDoCabecalhoASerDestacada = this.CelulaSelecionada.index();
    if (idAco !== idAcoSelecionado) {
      $("tr.bg-prateado", this.options.Contexto).removeClass("bg-prateado");
      $linhasDasPlanilhasASerDestacada = $("tr[idaco=" + idAco + "]");
      $linhasDasPlanilhasASerDestacada.addClass("bg-prateado");
    }
    $("li.bg-prateado", this.CabecalhoDaTabela).removeClass("bg-prateado");
    return $($("li", this.CabecalhoDaTabela)[colunaDoCabecalhoASerDestacada]).addClass("bg-prateado");
  };

  planilhaController.prototype.configurarTooltipBloqueio = function() {
    var mensagem;
    this.destruirToolTipBloqueio();
    mensagem = this.CelulaSelecionada.data('mensagem');
    this.CelulaSelecionada.addClass("borda-selecionada");
    this.CelulaSelecionada.attr('rel', 'bloqueioTooltip');
    return this.CelulaSelecionada.tooltip({
      title: mensagem,
      trigger: 'manual'
    }).tooltip('show');
  };

  planilhaController.prototype.destruirToolTipBloqueio = function() {
    var celulaToolTip;
    celulaToolTip = $('[rel=bloqueioTooltip]', $('#planilhaDireita'));
    if (celulaToolTip !== void 0) {
      celulaToolTip.tooltip('destroy');
      return celulaToolTip.removeAttr('rel');
    }
  };

  planilhaController.prototype.deslocarEmXY = function(celula, deslocamento) {
    var alturaDaCelula, celulaEstaNoIntervaloHorizontalPermitido, celulaEstaNoIntervaloVerticalPermitido, indexHorizontalDaCelula, indexVerticalDaCelula, larguraDaCelula, posicaoDoPrimeiroIndexHorizontalVisivelNaTabela, posicaoDoPrimeiroIndexVerticalVisivelNaTabela, posicaoDoUltimoIndexHorizontalVisivelNaTabela, posicaoDoUltimoIndexVerticalVisivelNaTabela, posicaoHorizontalDaCelulaNaTabela, posicaoVerticalDaCelulaNaTabela, scrollParaBaixo, scrollParaCima, scrollParaDireita, scrollParaEsquerda;
    if (!(celula === void 0 || celula.length === 0)) {
      alturaDaCelula = $(celula).outerHeight();
      larguraDaCelula = $(celula).outerWidth();
      indexVerticalDaCelula = $(celula).parent().index() + 1;
      indexHorizontalDaCelula = $(celula).index() + 1;
      posicaoVerticalDaCelulaNaTabela = alturaDaCelula * indexVerticalDaCelula;
      posicaoHorizontalDaCelulaNaTabela = larguraDaCelula * indexHorizontalDaCelula;
      posicaoDoPrimeiroIndexVerticalVisivelNaTabela = this.PlanilhaDireita.scrollTop() + alturaDaCelula;
      posicaoDoUltimoIndexVerticalVisivelNaTabela = this.PlanilhaDireita.scrollTop() + this.PlanilhaDireita.height();
      posicaoDoPrimeiroIndexHorizontalVisivelNaTabela = this.PlanilhaDireita.scrollLeft() + larguraDaCelula;
      posicaoDoUltimoIndexHorizontalVisivelNaTabela = this.PlanilhaDireita.scrollLeft() + this.PlanilhaDireita.width();
      celulaEstaNoIntervaloHorizontalPermitido = posicaoDoPrimeiroIndexHorizontalVisivelNaTabela < posicaoHorizontalDaCelulaNaTabela && posicaoHorizontalDaCelulaNaTabela < posicaoDoUltimoIndexHorizontalVisivelNaTabela;
      celulaEstaNoIntervaloVerticalPermitido = posicaoDoPrimeiroIndexVerticalVisivelNaTabela < posicaoVerticalDaCelulaNaTabela && posicaoVerticalDaCelulaNaTabela < posicaoDoUltimoIndexVerticalVisivelNaTabela;
      scrollParaDireita = indexHorizontalDaCelula * larguraDaCelula - (this.PlanilhaDireita.width() - 24);
      scrollParaEsquerda = posicaoHorizontalDaCelulaNaTabela - larguraDaCelula;
      scrollParaCima = posicaoVerticalDaCelulaNaTabela - alturaDaCelula;
      scrollParaBaixo = indexVerticalDaCelula * alturaDaCelula - (this.PlanilhaDireita.height() - 20);
      switch (deslocamento) {
        case planilhaController.Deslocamento.ParaDireita:
          if (!celulaEstaNoIntervaloHorizontalPermitido) {
            this.PlanilhaDireita.scrollLeft(scrollParaDireita);
          }
          if (!celulaEstaNoIntervaloVerticalPermitido) {
            return this.PlanilhaDireita.scrollTop(scrollParaCima);
          }
          break;
        case planilhaController.Deslocamento.ParaEsquerda:
          if (!celulaEstaNoIntervaloHorizontalPermitido) {
            this.PlanilhaDireita.scrollLeft(scrollParaEsquerda);
          }
          if (!celulaEstaNoIntervaloVerticalPermitido) {
            return this.PlanilhaDireita.scrollTop(scrollParaCima);
          }
          break;
        case planilhaController.Deslocamento.ParaBaixo:
          if (!celulaEstaNoIntervaloVerticalPermitido) {
            this.PlanilhaDireita.scrollTop(scrollParaBaixo);
          }
          if (!celulaEstaNoIntervaloHorizontalPermitido) {
            return this.PlanilhaDireita.scrollLeft(scrollParaEsquerda);
          }
          break;
        case planilhaController.Deslocamento.ParaCima:
          if (!celulaEstaNoIntervaloVerticalPermitido) {
            this.PlanilhaDireita.scrollTop(scrollParaCima);
          }
          if (!celulaEstaNoIntervaloHorizontalPermitido) {
            return this.PlanilhaDireita.scrollLeft(scrollParaEsquerda);
          }
      }
    }
  };

  planilhaController.prototype.templateDosBotoesDeAcaoDaPlanilha = function() {
    var template;
    template = "<div id='acoesDaPlanilha' class='btn-group absolute zero-all direita'>" + "	<button type='button' class='btn btn-xs btn-planilha dropdown-toggle absolute w100 zero-all fn direita' data-toggle='dropdown'><span class='mlm caret'></span></button>" + "	<ul class='dropdown-menu pull-right mrs' role='menu'>" + "		<li><a class='cursor-pointer' onclick='window.PlanilhaController.limparLinha(this);'>" + this.resource.Limpar + "</a></li>" + "		<li id='autocompletar'><a class='cursor-pointer' onclick='window.PlanilhaController.autoCompletar(this);'>" + this.resource.AutoCompletar + "</a></li>" + "	</ul>" + "</div>";
    return template;
  };

  planilhaController.prototype.configurarEdicaoPlanilha = function() {
    var html;
    html = this.TemplateDosBotoesDeAcaoDaPlanilha;
    $("th.js-tituloDaLinha", this.PlanilhaEsquerda).hover(function() {
      if ($(this).data("exibir-opcoes")) {
        $("div", this).append(html);
        if ($(this).hasClass("js-real")) {
          return $("#acoesDaPlanilha #autocompletar").hide();
        }
      }
    }, function() {
      return $("#acoesDaPlanilha").remove();
    });
    this.CampoFlutuanteValorDoIndicador.keydown((function(_this) {
      return function(event) {
        var celula, deslocamento, keyCode, linha;
        if (_this.CelulaSelecionada.length > 0) {
          keyCode = event.keyCode || event.which;
          if ((keyCode === window.KeyCodes.z || keyCode === window.KeyCodes.y) && event.ctrlKey) {
            return false;
          } else {
            switch (keyCode) {
              case window.KeyCodes.Escape:
                _this.escapando = true;
                _this.CampoFlutuanteValorDoIndicador.val(_this.proximoValorAntigo);
                _this.marcarCelula(_this.CelulaSelecionada);
                break;
              case window.KeyCodes.Tab:
              case window.KeyCodes.Enter:
                _this.escapando = false;
                event.preventDefault();
                _this.usouTeclado = true;
                $("span", _this.CelulaSelecionada).text(_this.CampoFlutuanteValorDoIndicador.val());
                _this.valorAntigo = _this.proximoValorAntigo;
                if (event.shiftKey) {
                  celula = _this.CelulaSelecionada.prev();
                  deslocamento = planilhaController.Deslocamento.ParaEsquerda;
                  if (celula.length === 0) {
                    deslocamento = planilhaController.Deslocamento.ParaCima;
                    linha = _this.CelulaSelecionada.parent().prev();
                    if (linha.length > 0) {
                      celula = linha.find("td:last");
                    }
                  }
                  _this.marcarCelula(celula);
                  _this.deslocarEmXY(celula, deslocamento);
                } else {
                  celula = _this.CelulaSelecionada.next();
                  deslocamento = planilhaController.Deslocamento.ParaDireita;
                  if (celula.length === 0) {
                    deslocamento = planilhaController.Deslocamento.ParaBaixo;
                    linha = _this.CelulaSelecionada.parent().next();
                    if (linha.length > 0) {
                      celula = linha.find("td:first");
                    } else {
                      celula = $('tr td:first', _this.PlanilhaDireita);
                    }
                  }
                  _this.marcarCelula(celula);
                  _this.deslocarEmXY(celula, deslocamento);
                }
                break;
              default:
                _this.escapando = false;
                return true;
            }
          }
          return _this.resetarCampoFlutuante();
        }
      };
    })(this)).change((function(_this) {
      return function(event) {
        var celula, novoValor, precisao, valor, valorAntigo;
        if (_this.desfazendoOuRefazendo) {
          return;
        }
        celula = _this.usouTeclado ? _this.CelulaSelecionadaAnterior || _this.CelulaSelecionada : _this.CelulaSelecionada;
        precisao = celula.parent().attr("prc");
        valor = window.FormatarNumero(_this.CampoFlutuanteValorDoIndicador.val(), precisao);
        valorAntigo = _this.usouTeclado ? _this.valorAntigo : _this.proximoValorAntigo;
        if ((valor === '' || !isNaN(parseInt(valor))) && valor !== valorAntigo && !_this.escapando) {
          novoValor = _this.criarValorDoIndicador(celula, valor);
          if (novoValor !== void 0) {
            _this.limparFarolMeta($("span", celula), valor);
            $("span", celula).text(valor);
            window.ValoresDoIndicador.push(novoValor);
            window.ValoresDoIndicadorDesfeitos = [];
            return _this.solicitarSalvamento(_this.resource.AconteceramAlgumasModificacoesQueAindaNaoForamSalvas);
          }
        }
      };
    })(this)).keypress(this.setarMascaraDecimal);
    this.CampoFixoValorDoIndicador.keydown((function(_this) {
      return function(event) {
        var celula, deslocamento, index, indexLinha, keyCode, linha, maxIndex, maxIndexLinhas;
        if (_this.CelulaSelecionada.length > 0) {
          keyCode = event.keyCode || event.which;
          if (keyCode === window.KeyCodes.z && event.ctrlKey) {
            _this.desfazerEdicao();
          } else if (keyCode === window.KeyCodes.y && event.ctrlKey) {
            _this.refazerEdicao();
          } else {
            _this.usouTeclado = false;
            _this.desfazendoOuRefazendo = false;
            switch (event.keyCode || event.which) {
              case window.KeyCodes.ArrowDown:
                celula = _this.CelulaSelecionada.parent().next().find("td")[_this.CelulaSelecionada.index()];
                _this.marcarCelula(celula);
                return _this.deslocarEmXY(celula, planilhaController.Deslocamento.ParaBaixo);
              case window.KeyCodes.ArrowUp:
                celula = _this.CelulaSelecionada.parent().prev().find("td")[_this.CelulaSelecionada.index()];
                _this.marcarCelula(celula);
                return _this.deslocarEmXY(celula, planilhaController.Deslocamento.ParaCima);
              case window.KeyCodes.ArrowRight:
                celula = _this.CelulaSelecionada.next();
                _this.marcarCelula(celula);
                return _this.deslocarEmXY(celula, planilhaController.Deslocamento.ParaDireita);
              case window.KeyCodes.ArrowLeft:
                celula = _this.CelulaSelecionada.prev();
                _this.marcarCelula(celula);
                return _this.deslocarEmXY(celula, planilhaController.Deslocamento.ParaEsquerda);
              case window.KeyCodes.F2:
              case window.KeyCodes.Backspace:
              case window.KeyCodes.Delete:
                return _this.entrarNaCelula();
              case window.KeyCodes.PageDown:
                maxIndexLinhas = $("#planilhaDireita table tr").length - 1;
                indexLinha = _this.CelulaSelecionada.parent().index();
                index = maxIndexLinhas < indexLinha + 15 ? maxIndexLinhas : indexLinha + 15;
                celula = $($("tbody", _this.PlanilhaDireita).children()[index]).find("td")[_this.CelulaSelecionada.index()];
                _this.marcarCelula(celula);
                return _this.deslocarEmXY(celula, planilhaController.Deslocamento.ParaBaixo);
              case window.KeyCodes.PageUp:
                indexLinha = _this.CelulaSelecionada.parent().index();
                index = indexLinha - 15 < 0 ? 0 : indexLinha - 15;
                celula = $($("tbody", _this.PlanilhaDireita).children()[index]).find("td")[_this.CelulaSelecionada.index()];
                _this.marcarCelula(celula);
                return _this.deslocarEmXY(celula, planilhaController.Deslocamento.ParaBaixo);
              case window.KeyCodes.End:
                maxIndex = _this.CelulaSelecionada.parent().find("td").length - 1;
                celula = _this.CelulaSelecionada.parent().find("td")[maxIndex];
                _this.marcarCelula(celula);
                return _this.deslocarEmXY(celula, planilhaController.Deslocamento.ParaDireita);
              case window.KeyCodes.Home:
                celula = _this.CelulaSelecionada.parent().find("td:first");
                _this.marcarCelula(celula);
                return _this.deslocarEmXY(celula, planilhaController.Deslocamento.ParaDireita);
              case window.KeyCodes.Tab:
              case window.KeyCodes.Enter:
                event.preventDefault();
                if (event.shiftKey) {
                  celula = _this.CelulaSelecionada.prev();
                  deslocamento = planilhaController.Deslocamento.ParaEsquerda;
                  if (celula.length === 0) {
                    deslocamento = planilhaController.Deslocamento.ParaCima;
                    linha = _this.CelulaSelecionada.parent().prev();
                    if (linha.length > 0) {
                      celula = linha.find("td:last");
                    }
                  }
                  _this.marcarCelula(celula);
                  return _this.deslocarEmXY(celula, deslocamento);
                } else {
                  celula = _this.CelulaSelecionada.next();
                  deslocamento = planilhaController.Deslocamento.ParaDireita;
                  if (celula.length === 0) {
                    deslocamento = planilhaController.Deslocamento.ParaBaixo;
                    linha = _this.CelulaSelecionada.parent().next();
                    if (linha.length > 0) {
                      celula = linha.find("td:first");
                    } else {
                      celula = $('tr td:first', _this.PlanilhaDireita);
                    }
                  }
                  _this.marcarCelula(celula);
                  return _this.deslocarEmXY(celula, deslocamento);
                }
                break;
              default:
                if (_this.verificaTeclasParaEdicao(event)) {
                  _this.entrarNaCelula();
                }
            }
          }
        }
      };
    })(this)).on("paste", this.colarDados);
  };

  planilhaController.prototype.limparFarolMeta = function(spanSelecionado, valor) {
    if (valor === '') {
      return spanSelecionado.parent().removeClass(this.ClassesFarol);
    }
  };

  planilhaController.prototype.verificaTeclasParaEdicao = function(event) {
    if (![48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 108, 109, 110, 173, 188, 189, 190, 194].contains(event.which)) {
      return false;
    }
    return true;
  };

  planilhaController.prototype.incrementarNumeroDaAcao = function() {
    return this.NumeroDaAcao++;
  };

  planilhaController.prototype.decrementarNumeroDaAcao = function() {
    return this.NumeroDaAcao--;
  };

  planilhaController.prototype.desfazerEdicao = function() {
    var celula, i, j, numeroDaAcaoDesfeita, ref, valorDoIndicador;
    if (window.ValoresDoIndicador.length === 0) {
      return;
    }
    numeroDaAcaoDesfeita = window.ValoresDoIndicador[window.ValoresDoIndicador.length - 1].NumeroDaAcao;
    for (i = j = ref = window.ValoresDoIndicador.length - 1; ref <= 0 ? j <= 0 : j >= 0; i = ref <= 0 ? ++j : --j) {
      valorDoIndicador = window.ValoresDoIndicador[i];
      if (valorDoIndicador.NumeroDaAcao === numeroDaAcaoDesfeita) {
        this.desfazendoOuRefazendo = true;
        window.ValoresDoIndicadorDesfeitos.push(valorDoIndicador);
        window.ValoresDoIndicador.remove(i);
        celula = $(this.obterIdCelulaEditada(valorDoIndicador.IdDoIndicador, valorDoIndicador.CampoAlterado, valorDoIndicador.Ocorrencia));
        $("span", celula).text(valorDoIndicador.ValorAntigo);
        this.marcarCelula(celula);
      }
    }
  };

  planilhaController.prototype.refazerEdicao = function() {
    var celula, i, j, numeroDaAcaoRefeita, ref, valorDoIndicador;
    if (window.ValoresDoIndicadorDesfeitos.length === 0) {
      return;
    }
    numeroDaAcaoRefeita = window.ValoresDoIndicadorDesfeitos[window.ValoresDoIndicadorDesfeitos.length - 1].NumeroDaAcao;
    for (i = j = ref = window.ValoresDoIndicadorDesfeitos.length - 1; ref <= 0 ? j <= 0 : j >= 0; i = ref <= 0 ? ++j : --j) {
      valorDoIndicador = window.ValoresDoIndicadorDesfeitos[i];
      if (valorDoIndicador.NumeroDaAcao === numeroDaAcaoRefeita) {
        this.desfazendoOuRefazendo = true;
        window.ValoresDoIndicador.push(valorDoIndicador);
        window.ValoresDoIndicadorDesfeitos.remove(i);
        celula = $(this.obterIdCelulaEditada(valorDoIndicador.IdDoIndicador, valorDoIndicador.CampoAlterado, valorDoIndicador.Ocorrencia));
        $("span", celula).text(valorDoIndicador.ValorNovo);
        this.marcarCelula(celula);
      }
    }
  };

  planilhaController.prototype.obterIdCelulaEditada = function(idIndicador, campo, ocorrencia) {
    return "#" + idIndicador + "-" + this.Campos[campo] + "-" + ocorrencia;
  };

  planilhaController.prototype.criarValorDoIndicador = function($celula, valorNovo) {
    var precisao, revisao, valor;
    if ($celula === null || $celula === void 0) {
      $celula = this.CelulaSelecionadaAnterior || this.CelulaSelecionada;
    }
    if (valorNovo === null || valorNovo === void 0) {
      valorNovo = this.CampoFlutuanteValorDoIndicador.val();
    }
    this.valorAntigo = $("span", $celula).text();
    revisao = $celula.attr("rev");
    precisao = $celula.parent().attr("prc");
    if (revisao === null || revisao === void 0 || revisao === '') {
      revisao = 0;
    } else {
      revisao = parseInt(revisao) + 1;
    }
    this.incrementarNumeroDaAcao();
    $celula.attr("rev", revisao);
    valor = new ValorDoIndicador();
    valor.IdDoIndicador = $celula.parent().attr("idaco");
    valor.IdDoValorDoIndicador = $celula.attr("idvalaco");
    valor.Ocorrencia = $celula.attr("oco");
    valor.Frequencia = this.options.FiltroAvancado.Frequencia;
    valor.FormaDeVisualizacao = this.options.FiltroAvancado.FormaDeVisualizacao;
    valor.CampoAlterado = $celula.parent().attr("campo");
    valor.ValorAntigo = this.valorAntigo;
    valor.ValorNovo = window.FormatarNumero(valorNovo, precisao);
    valor.Revisao = revisao;
    valor.IdDoPlanoDeGestao = this.options.FiltroAvancado.IdDoPlanoDeGestao;
    valor.NumeroDoMes = this.NumeroDoMes;
    valor.NumeroDaAcao = this.NumeroDaAcao;
    valor.ObtemDados = $celula.parent().attr("obtdad");
    valor.Precisao = precisao;
    return valor;
  };

  planilhaController.prototype.criarValorPelaCelula = function($celula, valorNovo) {
    var valor;
    valor = new ValorDoIndicador();
    valor.IdDoIndicador = $celula.parent().attr("idaco");
    valor.IdDoValorDoIndicador = $celula.attr("idvalaco");
    valor.Ocorrencia = $celula.attr("oco");
    valor.Frequencia = this.options.FiltroAvancado.Frequencia;
    valor.FormaDeVisualizacao = this.options.FiltroAvancado.FormaDeVisualizacao;
    valor.CampoAlterado = $celula.parent().attr("campo");
    valor.ValorAntigo = 0;
    valor.ValorNovo = valorNovo;
    valor.Revisao = 1;
    valor.IdDoPlanoDeGestao = this.options.FiltroAvancado.IdDoPlanoDeGestao;
    valor.NumeroDoMes = this.NumeroDoMes;
    valor.ObtemDados = $celula.parent().attr("obtdad");
    return valor;
  };

  planilhaController.prototype.salvarPlanilha = function() {
    return this.salvarValores(window.ValoresDoIndicador);
  };

  planilhaController.prototype.salvarValores = function(valores) {
    var parametros;
    parametros = {
      plano: this.options.FiltroAvancado.IdDoPlanoDeGestao,
      visualizacao: this.options.FiltroAvancado.FormaDeVisualizacao,
      frequencia: this.options.FiltroAvancado.Frequencia,
      mes: this.NumeroDoMes,
      indicadores: this.agruparValores(valores)
    };
    return $as.Performance.PlanilhaDeIndicadores.SalvarPlanilha.postJson(JSON.stringify(parametros)).success((function(_this) {
      return function(data) {
        window.ValoresDoIndicador = [];
        window.ValoresDoIndicadorDesfeitos = [];
        return _this.recarrecarPlanilha();
      };
    })(this));
  };

  planilhaController.prototype.agruparValores = function(valores) {
    var indicador, indicadores, j, len, valor;
    if (valores) {
      indicadores = new Array();
      for (j = 0, len = valores.length; j < len; j++) {
        valor = valores[j];
        indicador = this.construirIndicador(indicadores, valor.IdDoIndicador, valor.CampoAlterado);
        indicador.valores.push({
          id: valor.IdDoValorDoIndicador,
          oco: valor.Ocorrencia,
          val: valor.ValorNovo,
          obtdad: valor.ObtemDados
        });
      }
    }
    return indicadores;
  };

  planilhaController.prototype.construirIndicador = function(lista, id, campo) {
    var item, j, len;
    for (j = 0, len = lista.length; j < len; j++) {
      item = lista[j];
      if (item.indicador === id && item.campo === campo) {
        return item;
      }
    }
    item = {
      indicador: id,
      campo: campo,
      valores: new Array()
    };
    lista.push(item);
    return item;
  };

  planilhaController.prototype.limparLinha = function(el) {
    var $celulas, $linha, celula, indexDaLinha, j, len, limparCelula, results;
    indexDaLinha = $(el).parents("tr").index();
    $linha = $("tr", this.PlanilhaDireita)[indexDaLinha];
    $celulas = $("td[data-bloqueado='false']", $linha);
    limparCelula = (function(_this) {
      return function($celula) {
        $("div[class^='meta-']", $celula).removeClass(_this.ClassesFarol);
        _this.valorAntigo = $("span", $celula).text();
        if (_this.valorAntigo !== '') {
          _this.decrementarNumeroDaAcao();
          window.ValoresDoIndicador.push(_this.criarValorDoIndicador($celula, ''));
          _this.solicitarSalvamento(_this.resource.AconteceramAlgumasModificacoesQueAindaNaoForamSalvas);
          return $("span", $celula).text('');
        }
      };
    })(this);
    results = [];
    for (j = 0, len = $celulas.length; j < len; j++) {
      celula = $celulas[j];
      results.push(limparCelula($(celula)));
    }
    return results;
  };

  planilhaController.prototype.autoCompletar = function(el) {
    var $celInterna, $celulas, $linha, celula, indexDaLinha, indiceFinal, indiceInicial, j, len, precisao, valorFinal, valorInicial, valores;
    valorInicial = 0;
    valorFinal = 0;
    indiceInicial = 0;
    indexDaLinha = $(el).parents("tr").index();
    $linha = $("tr", this.PlanilhaDireita)[indexDaLinha];
    $celulas = $("td[data-bloqueado='false']", $linha);
    indiceFinal = $celulas.length - 1;
    precisao = $($celulas[0]).parent().attr("prc");
    valores = [];
    for (j = 0, len = $celulas.length; j < len; j++) {
      celula = $celulas[j];
      $celInterna = $("span", $(celula));
      valores[$(celula).index()] = $celInterna.text();
    }
    return $as.Performance.PlanilhaDeIndicadores.CalcularProgressao.postJson(JSON.stringify(valores)).done((function(_this) {
      return function(data) {
        var k, len1, results, valor;
        results = [];
        for (k = 0, len1 = $celulas.length; k < len1; k++) {
          celula = $celulas[k];
          valor = data[$(celula).index()];
          if (valor !== null && valor !== 'null') {
            valor = window.FormatarNumero(valor, precisao);
            $celInterna = $("span", $(celula));
            _this.valorAntigo = $celInterna.text();
            if (_this.valorAntigo !== valor) {
              window.ValoresDoIndicador.push(_this.criarValorDoIndicador($(celula), valor));
              _this.decrementarNumeroDaAcao();
              _this.solicitarSalvamento(_this.resource.AconteceramAlgumasModificacoesQueAindaNaoForamSalvas);
              results.push($celInterna.text(valor));
            } else {
              results.push(void 0);
            }
          } else {
            results.push(void 0);
          }
        }
        return results;
      };
    })(this));
  };

  planilhaController.prototype.colarDados = function(e) {
    var $linha, indexInicio;
    $linha = this.CelulaSelecionada.parent();
    indexInicio = this.CelulaSelecionada.index();
    $as.Performance.PlanilhaDeIndicadores.NormalizarValores.post({
      texto: e.clipboardText
    }).done((function(_this) {
      return function(data) {
        var i, j, len, possuiValor, setarValor, valor, valoresParaColar;
        possuiValor = false;
        valoresParaColar = data.data[0];
        setarValor = function(index, valor) {
          var $celInterna, $celula, precisao;
          if (valor !== null && valor !== 'null') {
            possuiValor = true;
            $celula = $($("td", $linha)[indexInicio + index]);
            precisao = $celula.parent().attr("prc");
            valor = window.FormatarNumero(valor, precisao);
            if ($celula.length > 0) {
              $celInterna = $("span", $celula);
              _this.valorAntigo = $celInterna.text();
              if (_this.valorAntigo !== valor) {
                window.ValoresDoIndicador.push(_this.criarValorDoIndicador($celula, valor));
                if (valoresParaColar.length > 1 && index < (valoresParaColar.length - 1)) {
                  _this.decrementarNumeroDaAcao();
                }
                _this.solicitarSalvamento(_this.resource.AconteceramAlgumasModificacoesQueAindaNaoForamSalvas);
                return $celInterna.text(valor);
              }
            }
          }
        };
        for (i = j = 0, len = valoresParaColar.length; j < len; i = ++j) {
          valor = valoresParaColar[i];
          setarValor(i, valor);
        }
        if (possuiValor) {
          return window.ValoresDoIndicadorDesfeitos = [];
        }
      };
    })(this));
    return this.CampoFixoValorDoIndicador.val('');
  };

  planilhaController.prototype.recarrecarPlanilha = function() {
    return $.ajax({
      type: 'GET',
      url: $as.Performance.PlanilhaDeIndicadores.Index.url,
      success: function(data) {
        var j, key, len, ref, results, valor;
        $("#main").html(data);
        if (window.ValoresDoIndicador !== void 0 && window.ValoresDoIndicador.length > 0) {
          ref = window.ValoresDoIndicador;
          results = [];
          for (j = 0, len = ref.length; j < len; j++) {
            key = ref[j];
            valor = window.FormatarNumero(key.ValorNovo, key.Precisao);
            results.push($("span", "#" + key.IdDoIndicador + "-" + key.CampoAlterado + "-" + key.Ocorrencia).text(valor));
          }
          return results;
        }
      }
    });
  };

  planilhaController.prototype.alterarFiltro = function(action, parametros, callback) {
    return $.ajax({
      type: 'POST',
      url: $as.Performance.FiltroDeIndicadores[action].url,
      data: parametros,
      global: false,
      success: function() {
        return callback();
      }
    });
  };

  planilhaController.prototype.solicitarSalvamento = function(mensagem) {
    var btns;
    btns = [
      {
        addClass: 'btn btn-warning',
        text: this.resource.Salvar,
        onClick: (function(_this) {
          return function($noty) {
            $noty.close($noty);
            return _this.salvarPlanilha();
          };
        })(this)
      }
    ];
    if (!this.exibindoSolicitacaoDeSalvamento) {
      showBottomNoty(mensagem, 15000, btns);
      return this.exibindoSolicitacaoDeSalvamento = true;
    }
  };

  planilhaController.Deslocamento = {
    ParaCima: 1,
    ParaBaixo: 2,
    ParaEsquerda: 3,
    ParaDireita: 4
  };

  planilhaController.releaseSomeMemory = function() {
    if (typeof CollectGarbage === "function") {
      return CollectGarbage();
    }
  };

  planilhaController.prototype.desselecionarCelula = function() {
    if (this.CelulaSelecionada !== void 0) {
      this.CelulaSelecionada.removeClass("borda-selecionada");
    }
    this.resetarCampoFlutuante();
    return $("tr.bg-prateado", this.options.Contexto).removeClass("bg-prateado");
  };

  planilhaController.alterarUnidade = function(idDaUnidade) {
    return $.ajax({
      type: 'POST',
      url: $as.Performance.FiltroDeIndicadores.MudarUnidadeGerencial.url,
      data: {
        idDaUnidade: idDaUnidade
      },
      global: false,
      success: function(data) {
        return window.reload();
      }
    });
  };

  planilhaController.alterarPlanoDeGestao = function(idDoPlanoDeGestao) {
    return $.ajax({
      type: 'POST',
      url: $as.Performance.FiltroDeIndicadores.MudarPlanoDeGestao.url,
      data: {
        idDoPlanoDeGestao: idDoPlanoDeGestao
      },
      global: false,
      success: function(data) {
        return window.reload();
      }
    });
  };

  planilhaController.prototype.comutarFrequencia = function(event) {
    var $elemento, formaDeVisualizacao, frequencia;
    $elemento = $(event.delegateTarget);
    frequencia = $elemento.data('frequencia');
    formaDeVisualizacao = $elemento.data('visualizacao');
    return $.ajax({
      type: 'POST',
      url: $as.Performance.FiltroDeIndicadores.MudarFrequencia.url,
      data: {
        frequencia: frequencia,
        formaDeVisualizacao: formaDeVisualizacao
      },
      global: false,
      success: function(data) {
        return window.reload();
      }
    });
  };

  planilhaController.prototype.preencherAutomaticamenteAPlanilhaComValoresAleatorios = function(skip, take) {
    var contador, div, fator, fatorA, fatorB, ideAcoAtual, indicadorAlterado, j, k, len, len1, ref, ref1, td, tr, valor;
    this.CampoFlutuanteValorDoIndicador = $('#ValorDoIndicadorFlutuante');
    contador = 0;
    ideAcoAtual = 0;
    ref = $('tr', '#planilhaDireita');
    for (j = 0, len = ref.length; j < len; j++) {
      tr = ref[j];
      tr = $(tr);
      indicadorAlterado = ideAcoAtual !== tr.attr('idaco');
      if (indicadorAlterado) {
        contador++;
        ideAcoAtual = tr.attr('idaco');
        fator = this.numeroAletorio(4, 1);
        fatorA = Math.pow(100, fator);
        fatorB = Math.pow(50, fator);
      }
      if (contador > take) {
        break;
      }
      if (contador >= skip + 1) {
        ref1 = $('.indicador-conteudo', tr);
        for (k = 0, len1 = ref1.length; k < len1; k++) {
          div = ref1[k];
          td = $(div).parent();
          valor = this.numeroAletorio(fatorA, fatorB);
          window.ValoresDoIndicador.push(this.criarValorPelaCelula($(td), valor));
        }
      }
    }
    return this.solicitarSalvamento(this.resource.AconteceramAlgumasModificacoesQueAindaNaoForamSalvas);
  };

  planilhaController.prototype.numeroAletorio = function(max, min) {
    return Math.floor(Math.random() * (max - min)) + min;
  };

  planilhaController.prototype.ativarMenuIndicador = function() {
    return $('.js-menu-indicador').unbind('click').click(this.carregarMenuIndicador);
  };

  planilhaController.prototype.carregarMenuIndicador = function(event) {
    var $menu, $menuIndicador, alturaDoBrowser, alturaMenu, botao, idIndicador, left, obtemDados, offset, templateHtml, templateMenu, top;
    botao = $(event.delegateTarget);
    idIndicador = botao.data('idindicador');
    obtemDados = botao.data('obtemdadosdeoutroindicador');
    templateMenu = $('#menu-template');
    templateMenu.find('#compartilhar-indicador').toggle(!obtemDados);
    templateHtml = $('#menu-template').html();
    $menuIndicador = $('#menu-indicador');
    if ($menuIndicador.data('indicador') !== idIndicador) {
      $menuIndicador.data('indicador', idIndicador);
      $menuIndicador.html(templateHtml.replace(/valorIdIndicador/g, idIndicador));
      if (this.options.FiltroAvancado.Frequencia === 1) {
        $menuIndicador.find('.js-arvoreDesdobramento', botao).data('idindicador', idIndicador);
        $menuIndicador.find('.js-arvoreDesdobramento', botao).click(this.abrirArvoreDesdobramento);
      } else {
        $menuIndicador.find('#arvoreDesdobramento').hide();
      }
      $menuIndicador.find('a').click(this.fecharMenuDoIndicador);
      offset = botao.offset();
      left = offset.left;
      top = offset.top;
      $menu = $menuIndicador.find('.js-listagem-menu-indicador');
      alturaDoBrowser = $('#planilhaEsquerda').height() - 50;
      alturaMenu = ($menu.find('li').length + 1) * 15;
      if (alturaMenu + top > alturaDoBrowser) {
        top = top - alturaMenu * 2 + 30;
      }
      $menu.addClass('absolute').css('top', top).css('left', left);
      $menuIndicador.addClass('open');
      return $menuIndicador.mouseleave((function(_this) {
        return function() {
          return _this.fecharMenuDoIndicador($menuIndicador);
        };
      })(this));
    } else {
      return this.fecharMenuDoIndicador();
    }
  };

  planilhaController.prototype.fecharMenuDoIndicador = function($menuIndicador) {
    $menuIndicador = $('#menu-indicador');
    $menuIndicador.removeClass('open');
    $menuIndicador.find('.js-listagem-menu-indicador').remove();
    return $menuIndicador.data('indicador', '');
  };

  planilhaController.prototype.abrirArvoreDesdobramento = function(event) {
    var botao;
    botao = $(event.currentTarget);
    return $as.Performance.ArvoreDeDesdobramentos.Index.post({
      idIndicador: botao.data('idindicador')
    }).done((function(_this) {
      return function(html) {
        return $('#main').html(html);
      };
    })(this));
  };

  planilhaController.prototype.normalizarDadosDaLinha = function(dados) {
    return {
      Dimensao1: dados.dimensao1,
      Dimensao2: dados.dimensao2,
      Dimensao3: dados.dimensao3,
      Dimensao4: dados.dimensao4,
      Dimensao5: dados.dimensao5,
      Dimensao6: dados.dimensao6,
      IdIndicador: dados.idindicador,
      IdIndicadorBase: dados.idindicadorbase,
      IdUnidade: dados.idunidade,
      IdUnidadeRelacionada: dados.idunidaderelacionada,
      IdDoPlanoDeGestao: dados.iddoplanodegestao,
      FormaDeVisualizacao: dados.formadevisualizacao,
      Frequencia: this.options.FiltroAvancado.Frequencia,
      NumeroDoMes: this.NumeroDoMes
    };
  };

  return planilhaController;

})();

ValorDoIndicador = function() {
  this.IdDoIndicador;
  this.IdDoValorDoIndicador;
  this.Frequencia;
  this.Ocorrencia;
  this.FormaDeVisualizacao;
  this.CampoAlterado;
  this.ValorAntigo;
  this.ValorNovo;
  this.Revisao;
  this.IdDoPlanoDeGestao;
  this.NumeroDoMes;
  this.NumeroDaAcao;
};
