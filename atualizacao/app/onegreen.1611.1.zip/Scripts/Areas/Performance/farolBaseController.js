﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.farolBaseController = (function() {
  function farolBaseController(options, esconderFilgroUg) {
    this.options = options;
    this.normalizarDadosDaLinha = bind(this.normalizarDadosDaLinha, this);
    this.carregarFarolTendencia = bind(this.carregarFarolTendencia, this);
    this.carregarFarolAcumulado = bind(this.carregarFarolAcumulado, this);
    this.configurarGraficos = bind(this.configurarGraficos, this);
    this.marcarColunasDoMesSelecionado = bind(this.marcarColunasDoMesSelecionado, this);
    this.colorirLinhas = bind(this.colorirLinhas, this);
    this.selecionarLinha = bind(this.selecionarLinha, this);
    this.selecionarLinhaEColuna = bind(this.selecionarLinhaEColuna, this);
    this.fecharMenuDoIndicador = bind(this.fecharMenuDoIndicador, this);
    this.abrirArvoreDesdobramento = bind(this.abrirArvoreDesdobramento, this);
    this.carregarMenuIndicador = bind(this.carregarMenuIndicador, this);
    this.apresentarPercentual = bind(this.apresentarPercentual, this);
    this.ativarMenuIndicador = bind(this.ativarMenuIndicador, this);
    this.exibirDetalhesDoIndicador = bind(this.exibirDetalhesDoIndicador, this);
    this.configurarBindDetalhesIndicador = bind(this.configurarBindDetalhesIndicador, this);
    this.mudarMes = bind(this.mudarMes, this);
    this.loadIndexGeral = bind(this.loadIndexGeral, this);
    if (esconderFilgroUg) {
      $('#filtro-ug-geral').hide();
      $('#separador-filtro-ug-geral').hide();
      $('#link-adicionar').hide();
      $('#link-filtro-avancado').hide();
    }
    this.options.mesSelecionado = this.options.MesSelecionado;
    $("[ rel='tooltip']").tooltip();
    this.loadIndexGeral();
  }

  farolBaseController.prototype.loadIndexGeral = function() {
    if (this.options.Frequencia === 'Diaria') {
      this.configurarComutadorDeOcorrenciaDiario();
      $('[data-toggle="popover"]').popover();
      $('#ContextoDaTabelaFarol').find('.js-tabela-farol').find('tr').unbind('click').click(this.selecionarLinha);
      $('#arvoreDesdobramento').hide();
    } else if (this.options.Frequencia === 'Semanal') {
      this.configurarComutadorDeOcorrenciaSemanal();
      $('.popover-percentual-js').popover();
      $('#ContextoDaTabelaFarol').find('.js-tabela-farol').find('tr').unbind('click').click(this.selecionarLinha);
      $('#arvoreDesdobramento').hide();
    } else {
      $('#ContextoDaTabelaFarol').find('.js-tabela-farol').find('.mes-' + this.options.mesSelecionado).addClass('selecionado');
      $('.js-cabecalho-farol').unbind('click').click(this.mudarMes);
      $('#ContextoDaTabelaFarol').find('.js-tabela-farol').find('tr').unbind('click').click(this.selecionarLinha);
      $(".js-cabecalho-acumulado").unbind('click').click(this.carregarFarolAcumulado);
      $(".js-cabecalho-tendencia").unbind('click').click(this.carregarFarolTendencia);
      this.configurarGraficos($('#ContextoDaTabelaFarol'));
    }
    this.configurarBindDetalhesIndicador($('#ContextoDaTabelaFarol'));
    return this.ativarMenuIndicador();
  };

  farolBaseController.prototype.mudarMes = function(event) {
    this.farolAcumulado = false;
    this.farolTendencia = false;
    this.options.mesSelecionado = $(event.delegateTarget).data("mes");
    $('#TabelaCabecalhoFarol').find('.selecionado').removeClass('selecionado');
    $('#TabelaCabecalhoFarol').find('.mes-' + this.options.mesSelecionado).addClass('selecionado');
    $('#ContextoDaTabelaFarol').find('.js-tabela-farol').find('.selecionado').removeClass('selecionado');
    $('#ContextoDaTabelaFarol').find('.js-tabela-farol').find('.mes-' + this.options.mesSelecionado).addClass('selecionado');
    $('#' + this.linhaSelecionada).addClass('selecionado');
    return this.obterValoresMes(event);
  };

  farolBaseController.prototype.configurarBindDetalhesIndicador = function(seletorContexto) {
    return seletorContexto.find('.js-exibir-detalhes-indicador-mensal').unbind('click').click(this.exibirDetalhesDoIndicador);
  };

  farolBaseController.prototype.exibirDetalhesDoIndicador = function(event) {
    var $el, abaDeDetalhesPadrao, informacoes, linhaSelecionada, mesSemanaDia;
    $el = $(event.delegateTarget);
    linhaSelecionada = $el.closest('.js-farol');
    informacoes = this.normalizarDadosDaLinha(linhaSelecionada.data());
    abaDeDetalhesPadrao = $el.data('abapadrao');
    mesSemanaDia = $el.data('messemanadia') || this.options.mesSelecionado;
    return Results.api.exibirDetalhesDoIndicador(informacoes, mesSemanaDia, abaDeDetalhesPadrao);
  };

  farolBaseController.prototype.ativarMenuIndicador = function() {
    $('.js-menu-indicador').unbind('click').click(this.carregarMenuIndicador);
    if (this.options.Frequencia !== 'Mensal') {
      return $('.popover-percentual-js').unbind('click').click(this.apresentarPercentual);
    }
  };

  farolBaseController.prototype.apresentarPercentual = function(event) {
    var $botao, template;
    popover.close();
    $('.popover-percentual-js').parent().addClass('mostrar');
    $botao = $(event.delegateTarget);
    $botao.parent().removeClass('mostrar');
    template = $.parseHTML($('#tabela-popover-percentuais').html());
    $(template).find('.pa').html($botao.data('pa'));
    $(template).find('.paa').html($botao.data('paa'));
    $(template).find('.pat').html($botao.data('pat'));
    $(template).find('.vp').html($botao.data('vp'));
    $(template).find('.vpa').html($botao.data('vpa'));
    $(template).find('.vpt').html($botao.data('vpt'));
    popover.target = $botao.parent();
    popover.titulo = this.resource.Percentuais;
    popover.conteudo = $(template);
    popover.placement = 'left';
    popover.closeCallBack = function() {
      return $('.popover-percentual-js').parent().addClass('mostrar');
    };
    return popover.show('500');
  };

  farolBaseController.prototype.carregarMenuIndicador = function(event) {
    var $menu, $menuIndicador, alturaDoBrowser, alturaMenu, botao, htmlTemplate, idIndicador, left, obtemDados, offset, templateMenu, top;
    botao = $(event.delegateTarget);
    idIndicador = botao.data('idindicador');
    obtemDados = botao.closest('.js-farol').data('obtemdados');
    templateMenu = $('#menu-template');
    htmlTemplate = $('#menu-template').html();
    $menuIndicador = $('#menu-indicador');
    if ($menuIndicador.data('indicador') !== idIndicador || idIndicador === "") {
      $menuIndicador.data('indicador', idIndicador);
      $menuIndicador.html(htmlTemplate.replace(/valorIdIndicador/g, idIndicador));
      $menuIndicador.find('.js-arvoreDesdobramento', botao).data('info', botao.closest('.js-farol').data());
      $menuIndicador.find('.js-arvoreDesdobramento', botao).click(this.abrirArvoreDesdobramento);
      $menuIndicador.find('a').click(this.fecharMenuDoIndicador);
      $menu = $menuIndicador.find('.js-listagem-menu-indicador');
      offset = botao.offset();
      left = offset.left;
      top = offset.top;
      alturaDoBrowser = $("#farol-indicadores").height() + 120;
      alturaMenu = $menu.height();
      if (alturaMenu + top > alturaDoBrowser && alturaDoBrowser > window.innerHeight) {
        top = top - alturaMenu + botao.height();
      }
      $menu.addClass('absolute').css('top', top).css('left', left);
      $menuIndicador.addClass('open');
      $menuIndicador.mouseleave((function(_this) {
        return function() {
          return _this.fecharMenuDoIndicador($menuIndicador);
        };
      })(this));
      $menuIndicador.find('li').show();
      if (this.options.Frequencia !== 'Mensal' || !botao.data('desdobra')) {
        $menuIndicador.find('#arvoreDesdobramento').hide();
      }
      if (botao.data('indicadorvirtual') && this.options.Frequencia === 'Mensal') {
        $menuIndicador.find('li').hide();
        $menuIndicador.find('#arvoreDesdobramento').show();
      }
      if (obtemDados) {
        return $menuIndicador.find('#compartilhar-indicador').hide();
      }
    } else {
      return this.fecharMenuDoIndicador();
    }
  };

  farolBaseController.prototype.abrirArvoreDesdobramento = function(event) {
    var botao;
    botao = $(event.currentTarget);
    return $as.Performance.ArvoreDeDesdobramentos.Index.post(botao.data('info')).done((function(_this) {
      return function(html) {
        return $('#main').html(html);
      };
    })(this));
  };

  farolBaseController.prototype.fecharMenuDoIndicador = function($menuIndicador) {
    $menuIndicador = $('#menu-indicador');
    $menuIndicador.removeClass('open');
    $menuIndicador.find('.js-listagem-menu-indicador').remove();
    return $menuIndicador.data('indicador', '');
  };

  farolBaseController.prototype.selecionarLinhaEColuna = function(event) {
    $('#TabelaCabecalhoFarol').find('.selecionado').removeClass('selecionado');
    $('#TabelaCabecalhoFarol').find('.mes-' + this.options.mesSelecionado).addClass('selecionado');
    $('#ContextoDaTabelaFarol').find('.js-tabela-farol').find('.selecionado').removeClass('selecionado');
    $('#ContextoDaTabelaFarol').find('.js-tabela-farol').find('.mes-' + this.options.mesSelecionado).addClass('selecionado');
    return $('#' + this.linhaSelecionada).addClass('selecionado');
  };

  farolBaseController.prototype.selecionarLinha = function(event) {
    var identificadorDaLinha;
    if (this.linhaSelecionada) {
      $('[data-identificadordalinha=' + this.linhaSelecionada + ']').removeClass('selecionado');
    }
    this.linhaSelecionada = $(event.delegateTarget).data('identificadordalinha');
    identificadorDaLinha = $(event.delegateTarget).data('identificadordalinha');
    return this.colorirLinhas(identificadorDaLinha);
  };

  farolBaseController.prototype.colorirLinhas = function(identificadorDaLinha) {
    var linhas;
    linhas = $("[data-identificadordalinha=" + identificadorDaLinha + "]");
    return linhas.addClass('selecionado');
  };

  farolBaseController.prototype.marcarColunasDoMesSelecionado = function() {
    return $('#ContextoDaTabelaFarol').find('.js-tabela-farol').find('.mes-' + this.options.mesSelecionado).addClass('selecionado');
  };

  farolBaseController.prototype.configurarGraficos = function($ctx) {
    var chart, divs, i, j, ref, results, serie;
    window.defaultTheme.setBackGround();
    divs = $ctx.find('.js-grafico-acompanhamento-real');
    this.graficos = this.graficos || new Array();
    results = [];
    for (i = j = 0, ref = divs.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
      serie = $(divs[i]).find('.valores').val();
      $(divs[i]).height($(divs[i]).parent().height());
      chart = new Highcharts.Chart({
        chart: {
          colors: ['#7cb5ec'],
          renderTo: $(divs[i]).attr('id'),
          backgroundColor: null,
          plotBackgroundColor: null,
          spacingBottom: 1,
          spacingTop: 1,
          spacingLeft: 15,
          spacingRight: 10,
          background: null
        },
        title: {
          text: null
        },
        xAxis: {
          lineWidth: 0,
          tickWidth: 0,
          gridLineWidth: 0,
          labels: {
            enabled: false
          }
        },
        yAxis: {
          gridLineWidth: 0,
          lineWidth: 0,
          tickWidth: 1,
          tickColor: null,
          tickWidth: 0,
          title: {
            text: null
          },
          labels: {
            enabled: false
          }
        },
        tooltip: {
          enabled: false
        },
        credits: false,
        plotOptions: {
          series: {
            states: {
              hover: {
                enabled: false
              }
            }
          }
        },
        series: [
          {
            data: eval(serie),
            showInLegend: false,
            type: 'spline',
            lineWidth: 2,
            marker: {
              enabled: true,
              symbol: 'circle',
              radius: 3
            }
          }
        ]
      });
      results.push(this.graficos.push(chart));
    }
    return results;
  };

  farolBaseController.prototype.carregarFarolAcumulado = function() {
    this.farolAcumulado = true;
    this.farolTendencia = false;
    $('#TabelaCabecalhoFarol').find('.js-cabecalho-tendencia').removeClass('selecionado');
    $('#TabelaCabecalhoFarol').find('.js-cabecalho-acumulado').addClass('selecionado');
    $('#ContextoDaTabelaFarol .js-tabela-farol').find('td.selecionado').removeClass('selecionado');
    $('#ContextoDaTabelaFarol .js-tabela-farol').find('.js-farol-acumulado').addClass('selecionado');
    return this.recarregarFarolMensal();
  };

  farolBaseController.prototype.carregarFarolTendencia = function() {
    this.farolTendencia = true;
    this.farolAcumulado = false;
    $('#TabelaCabecalhoFarol').find('.js-cabecalho-acumulado').removeClass('selecionado');
    $('#TabelaCabecalhoFarol').find('.js-cabecalho-tendencia').addClass('selecionado');
    $('#ContextoDaTabelaFarol .js-tabela-farol').find('td.selecionado').removeClass('selecionado');
    $('#ContextoDaTabelaFarol .js-tabela-farol').find('.js-farol-ritmo').addClass('selecionado');
    return this.recarregarFarolMensal();
  };

  farolBaseController.prototype.normalizarDadosDaLinha = function(dados) {
    return {
      Dimensao1: dados.dimensao1,
      Dimensao2: dados.dimensao2,
      Dimensao3: dados.dimensao3,
      Dimensao4: dados.dimensao4,
      Dimensao5: dados.dimensao5,
      Dimensao6: dados.dimensao6,
      GuidPai: dados.guidpai,
      Hierarquia: dados.hierarquia,
      IdentificadorDaLinha: dados.identificadordalinha,
      IdIndicador: dados.idindicador,
      IdIndicadorBase: dados.idindicadorbase,
      IdUnidade: dados.idunidade,
      IdUnidadeRelacionada: dados.idunidaderelacionada,
      IdIndicadorDeOrigem: dados.idindicadordeorigem,
      PossuiApenasReal: dados.possuiapenasreal,
      Referencia: dados.referencia,
      SiglaDoTipoDeIndicador: dados.sigladotipodeindicador,
      SinalMelhor: dados.sinalmelhor,
      TipoDeDesdobramento: dados.tipodedesdobramento,
      UnidadeDeMedida: dados.unidadedemedida,
      IdDoPlanoDeGestao: dados.iddoplanodegestao,
      FormaDeVisualizacao: dados.formadevisualizacao,
      Frequencia: this.options.Frequencia,
      NumeroDoMes: this.options.NumeroDoMes
    };
  };

  return farolBaseController;

})();
