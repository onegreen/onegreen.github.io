﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.relatoriosDasAvaliacoesDeDesempenhoController = (function() {
  function relatoriosDasAvaliacoesDeDesempenhoController(contexto, resources) {
    this.contexto = contexto;
    this.resources = resources;
    this.relatorioDePlanosDeAcao = bind(this.relatorioDePlanosDeAcao, this);
    this.alterarPlanoDeGestao = bind(this.alterarPlanoDeGestao, this);
    this.habilitarDesabilitarRelatorio = bind(this.habilitarDesabilitarRelatorio, this);
    this.aoAplicarFiltro = bind(this.aoAplicarFiltro, this);
    this.aplicarFiltro = bind(this.aplicarFiltro, this);
    this.validarFiltro = bind(this.validarFiltro, this);
    this.configurarCsv = bind(this.configurarCsv, this);
    this.aoSelecionarRelatorio = bind(this.aoSelecionarRelatorio, this);
    this.loadComboRelatoriosDisponiveis = bind(this.loadComboRelatoriosDisponiveis, this);
    this.aoSelecionarCicloDeAvaliacao = bind(this.aoSelecionarCicloDeAvaliacao, this);
    this.loadComboCicloDeAvaliacao = bind(this.loadComboCicloDeAvaliacao, this);
    this.loadComboUnidade = bind(this.loadComboUnidade, this);
    this.loadComboPlanoDeGestao = bind(this.loadComboPlanoDeGestao, this);
    this.aoSelecionarPlanoDeGestao = bind(this.aoSelecionarPlanoDeGestao, this);
    this.loadComboPlanoDeGestao();
    this.loadComboUnidade();
    this.loadComboCicloDeAvaliacao();
    this.habilitarDesabilitarRelatorio();
    window.filtroUGEPlanoDeGestao.configurar('#filtro-ug-topo', null, this.alterarPlanoDeGestao);
    $("#filtro-ug-topo").show();
    $('#link-adicionar').hide();
    $('#link-filtro-avancado').hide();
    $('#filtro-ug-geral').hide();
    $('#separador-filtro-ug-geral').hide();
    $('#btnAplicarFiltro', this.contexto).click(this.validarFiltro);
  }

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.aoSelecionarPlanoDeGestao = function(input) {
    $("#UnidadeGerencialNome", this.contexto).val('');
    $("#IdDaUnidadeGerencial", this.contexto).val('');
    $("#UnidadeGerencialNome", this.contexto).removeAttr('disabled');
    $("#UnidadeGerencialNomeBtn", this.contexto).removeAttr('disabled');
    $("#CicloNome", this.contexto).val('');
    $("#IdDoCiclo", this.contexto).val('');
    $("#CicloNome", this.contexto).removeAttr('disabled');
    $("#CicloNome", this.contexto).removeAttr('disabled');
    $("#selecionar-um-relatorio", this.contexto).attr('disabled', 'disabled');
    $("#nome-do-relatorio", this.contexto).html(this.resources.SelecioneUmRelatorio);
    $("#TipoDeRelatorio", this.contexto).val('');
    $("#apenas-avaliacoes-pendentes", this.contexto).hide();
    $("#exportar-analitico", this.contexto).hide();
    this.loadComboUnidade(input.val());
    return this.loadComboCicloDeAvaliacao(input.val());
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.loadComboPlanoDeGestao = function() {
    $("#PlanoDeGestaoNome", this.contexto).on("change", (function(_this) {
      return function(event) {
        if ($(event.delegateTarget).val().trim() === "") {
          $("#UnidadeGerencialNome", _this.contexto).val('');
          $("#IdDaUnidadeGerencial", _this.contexto).val('');
          $("#UnidadeGerencialNome", _this.contexto).attr('disabled', 'disabled');
          $("#UnidadeGerencialNomeBtn", _this.contexto).attr('disabled', 'disabled');
          $("#CicloNome", _this.contexto).val('');
          $("#IdDoCiclo", _this.contexto).val('');
          $("#CicloNome", _this.contexto).attr('disabled', 'disabled');
          $("#CicloNome", _this.contexto).attr('disabled', 'disabled');
          $("#selecionar-um-relatorio", _this.contexto).attr('disabled', 'disabled');
          $("#nome-do-relatorio", _this.contexto).html(_this.resources.SelecioneUmRelatorio);
          $("#TipoDeRelatorio", _this.contexto).val('');
          $("#apenas-avaliacoes-pendentes", _this.contexto).hide();
          return $("#exportar-analitico", _this.contexto).hide();
        }
      };
    })(this));
    return setCombo(this.contexto, "#PlanoDeGestaoNome", this.aoSelecionarPlanoDeGestao);
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.loadComboUnidade = function(idDoPlanoDeGestao) {
    var parametros;
    if (!idDoPlanoDeGestao) {
      idDoPlanoDeGestao = $("#IdDoPlanoDeGestao", this.contexto).val();
    }
    parametros = {
      idDoPlanoDeGestao: idDoPlanoDeGestao
    };
    return setCombo(this.contexto, "#UnidadeGerencialNome", null, parametros);
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.loadComboCicloDeAvaliacao = function(idDoPlanoDeGestao) {
    var parametros;
    $("#CicloNome", this.contexto).on("change", (function(_this) {
      return function(event) {
        if ($(event.delegateTarget).val().trim() === "") {
          $("#selecionar-um-relatorio", _this.contexto).attr('disabled', 'disabled');
          $("#nome-do-relatorio", _this.contexto).html(_this.resources.SelecioneUmRelatorio);
          $("#TipoDeRelatorio", _this.contexto).val('');
          $("#apenas-avaliacoes-pendentes", _this.contexto).hide();
          return $("#exportar-analitico", _this.contexto).hide();
        }
      };
    })(this));
    if (!idDoPlanoDeGestao) {
      idDoPlanoDeGestao = $("#IdDoPlanoDeGestao", this.contexto).val();
    }
    parametros = {
      idDoPlanoDeGestao: idDoPlanoDeGestao
    };
    return setCombo(this.contexto, "#CicloNome", this.aoSelecionarCicloDeAvaliacao, parametros);
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.aoSelecionarCicloDeAvaliacao = function(input) {
    $("#selecionar-um-relatorio", this.contexto).removeAttr('disabled');
    $("#apenas-avaliacoes-pendentes", this.contexto).hide();
    $("#exportar-analitico", this.contexto).hide();
    $("#nome-do-relatorio", this.contexto).html(this.resources.SelecioneUmRelatorio);
    $("#TipoDeRelatorio", this.contexto).val('');
    return this.loadComboRelatoriosDisponiveis(input.val());
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.loadComboRelatoriosDisponiveis = function(idDoCiclo) {
    var $listaDeRelatoriosDisponiveis;
    $listaDeRelatoriosDisponiveis = $("#lista-de-relatorios-disponiveis", this.contexto);
    $listaDeRelatoriosDisponiveis.html('');
    return $as.Performance.AvaliacoesDeDesempenho.AutoCompleteDeRelatoriosDisponiveis.get({
      idDoCiclo: idDoCiclo
    }).success((function(_this) {
      return function(data) {
        var i, j, ref;
        for (i = j = 0, ref = data.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
          $listaDeRelatoriosDisponiveis.append("<li class='cursor-pointer' value='" + data[i].Key + "'> <a> " + data[i].Value + " </a> </li>");
        }
        setDropDown(_this.contexto, '#TipoDeRelatorioDeAvaliacaoDesempenho-dropdown');
        return _this.aoSelecionarRelatorio();
      };
    })(this));
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.aoSelecionarRelatorio = function() {
    return $("#lista-de-relatorios-disponiveis li", this.contexto).on("click", (function(_this) {
      return function(event) {
        var btn, relatorio;
        relatorio = $("#TipoDeRelatorio", _this.contexto).val();
        _this.configurarCsv();
        btn = $('#btnAplicarFiltro');
        if (relatorio === '4') {
          btn.text(btn.data('textoexportar'));
        } else {
          btn.text(btn.data('textoaplicarfiltro'));
        }
        if (relatorio === '1') {
          $("#apenas-avaliacoes-pendentes", _this.contexto).show();
          return $("#exportar-analitico", _this.contexto).show();
        } else {
          $("#apenas-avaliacoes-pendentes", _this.contexto).hide();
          return $("#exportar-analitico", _this.contexto).hide();
        }
      };
    })(this));
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.configurarCsv = function() {
    return $('#gerarCsvAvaliacao', this.contexto).click((function(_this) {
      return function() {
        $('#RetornarCsv', _this.contexto).val('true');
        return $('#btnGerarCsv', _this.contexto).click();
      };
    })(this));
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.configurarCsvAcompanhamento = function() {
    $('#gerarCsvAvaliacao', this.contexto).hide();
    $('#gerarCsvAvaliacaoAcompanhamento', this.contexto).show();
    $('#acompanhamentoAnalitico', this.contexto).click((function(_this) {
      return function() {
        $('#RetornarCsv', _this.contexto).val('true');
        $('#ExportarAnalitico', _this.contexto).val('true');
        return $('#btnGerarCsv', _this.contexto).click();
      };
    })(this));
    return $('#acompanhamentoSintetico', this.contexto).click((function(_this) {
      return function() {
        $('#RetornarCsv', _this.contexto).val('true');
        $('#ExportarAnalitico', _this.contexto).val('false');
        return $('#btnGerarCsv', _this.contexto).click();
      };
    })(this));
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.validarFiltro = function() {
    var form;
    form = $('#formRelatorioAvaliacao', this.contexto);
    return $as.Performance.RelatoriosDasAvaliacoesDeDesempenho.ValidarFiltro.post(form.serialize()).done((function(_this) {
      return function(data) {
        if (data.success) {
          return _this.aplicarFiltro();
        } else {
          return $('#filtroRelatorioAvaliacao', _this.contexto).html(data);
        }
      };
    })(this));
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.aplicarFiltro = function() {
    var form, relatorio;
    relatorio = $("#TipoDeRelatorio", this.contexto).val();
    if (relatorio === '4') {
      this.limparErros();
      $('#RetornarCsv', this.contexto).val('true');
      return $('#btnGerarCsv', this.contexto).click();
    } else {
      $('#RetornarCsv', this.contexto).val('false');
      form = $('#formRelatorioAvaliacao', this.contexto);
      return $as.Performance.RelatoriosDasAvaliacoesDeDesempenho.AplicarFiltro.post(form.serialize()).done((function(_this) {
        return function(data) {
          $('#container-relatorios', _this.contexto).html(data);
          return _this.aoAplicarFiltro();
        };
      })(this));
    }
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.aoAplicarFiltro = function() {
    var relatorio;
    this.limparErros();
    $('#gerarCsvAvaliacao', this.contexto).show();
    relatorio = $("#TipoDeRelatorio", this.contexto).val();
    if (relatorio === '1') {
      return this.configurarCsvAcompanhamento();
    } else {
      $('#gerarCsvAvaliacao', this.contexto).show();
      return $('#gerarCsvAvaliacaoAcompanhamento', this.contexto).hide();
    }
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.limparErros = function() {
    $('.validation-summary-errors').hide();
    $('#filtroRelatorioAvaliacao').find('.error').removeClass('error');
    return $('#filtroRelatorioAvaliacao').find('.input-validation-error').removeClass('input-validation-error');
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.habilitarDesabilitarRelatorio = function() {
    if ($("#IdDoCiclo", this.contexto).val() === '0') {
      return $("#selecionar-um-relatorio", this.contexto).attr('disabled', 'disabled');
    } else {
      return this.loadComboRelatoriosDisponiveis($("#IdDoCiclo", this.contexto).val());
    }
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.alterarPlanoDeGestao = function(idDoPlanoDeGestao) {
    return $as.Performance.FiltroDeIndicadores.MudarPlanoDeGestao.post({
      idDoPlanoDeGestao: idDoPlanoDeGestao
    }, {
      global: false
    }).done(function(data) {
      swIntercom('Mudou de plano de gestão pela Avaliação de Desempenho');
      return window.reload();
    });
  };

  relatoriosDasAvaliacoesDeDesempenhoController.prototype.relatorioDePlanosDeAcao = function() {
    var parameters;
    parameters = this.obterParametros();
    return $as.Performance.AvaliacoesDeDesempenho.RelatorioDePlanosDeAcaoIndividuais.get(parameters).done((function(_this) {
      return function(data) {
        _this.$contexto.find("#ExibirRelatorioPlanosDeAcao").val("true");
        return _this.$contexto.find("#colaboradores-container").html(data);
      };
    })(this));
  };

  return relatoriosDasAvaliacoesDeDesempenhoController;

})();
