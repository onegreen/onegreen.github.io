﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.selecionarDestinatarios = (function(superClass) {
  extend(selecionarDestinatarios, superClass);

  function selecionarDestinatarios(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.loadComboDeUsuarios = bind(this.loadComboDeUsuarios, this);
    this.loadComboListaDeDistribuicao = bind(this.loadComboListaDeDistribuicao, this);
    selecionarDestinatarios.__super__.constructor.call(this, this.contexto);
    this.loadComboListaDeDistribuicao();
    this.loadComboDeUsuarios();
    this.get('#btn-Enviar').click((function(_this) {
      return function(e) {
        return _this.get('#btn-Cancelar').click();
      };
    })(this));
  }

  selecionarDestinatarios.prototype.loadComboListaDeDistribuicao = function() {
    var $combo, $divCombo, listasDeDistribuicaoViewModel;
    listasDeDistribuicaoViewModel = {
      ListasDistribuicao: ko.observableArray(this.options.listasSelecionadas),
      removeLista: function(item) {
        return this.ListasDistribuicao.remove(item);
      }
    };
    window.listasDeDistribuicaoViewModel = listasDeDistribuicaoViewModel;
    ko.applyBindings(listasDeDistribuicaoViewModel, $('#listasDeDistribuicao_itens')[0]);
    $combo = this.get("#ListasDeDistribuicaoCombo");
    $divCombo = $combo.parents("div.autocompleter");
    return $combo.autocompleter($divCombo.attr("data-url"), {
      elementToClick: "#ListasDeDistribuicaoComboBtn",
      multiSelectArray: listasDeDistribuicaoViewModel.ListasDistribuicao,
      multiSelectElement: "#listasDeDistribuicao_itens"
    });
  };

  selecionarDestinatarios.prototype.loadComboDeUsuarios = function() {
    var comboDeUsuarios, containerUsuarios, itens, opcoesCombo, usuarioViewModel;
    containerUsuarios = this.get('#container-usuarios');
    comboDeUsuarios = $("#UsuariosCombo", containerUsuarios);
    itens = $("#usuarios_itens", containerUsuarios);
    usuarioViewModel = {
      usuarios: ko.observableArray(this.options.usuariosSelecionados),
      removeUsuario: function(usuario) {
        return this.usuarios.remove(usuario);
      }
    };
    window.usuarioViewModel = usuarioViewModel;
    ko.applyBindings(usuarioViewModel, itens[0]);
    opcoesCombo = {
      elementToClick: $("#UsuariosComboBtn", containerUsuarios),
      multiSelectArray: usuarioViewModel.usuarios,
      multiSelectElement: itens
    };
    return comboDeUsuarios.autocompleter(containerUsuarios.attr("data-url"), opcoesCombo);
  };

  return selecionarDestinatarios;

})(window.baseController);
