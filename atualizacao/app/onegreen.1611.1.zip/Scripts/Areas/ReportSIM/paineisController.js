﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.paineisController = (function(superClass) {
  extend(paineisController, superClass);

  function paineisController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.excluir = bind(this.excluir, this);
    this.loadIndex = bind(this.loadIndex, this);
    paineisController.__super__.constructor.call(this, this.view, this.model);
    this.loadIndex();
  }

  paineisController.prototype.loadIndex = function() {
    return this.get('.js-ExcluirPainel').unbind('click').click((function(_this) {
      return function(event) {
        return Confirmacao.mostrar("", function() {
          return _this.excluir($(event.delegateTarget));
        });
      };
    })(this));
  };

  paineisController.prototype.excluir = function(element) {
    return $as.ReportSIM.Paineis.Excluir.post({
      idDoPainel: $(element).attr('data-id')
    }).done((function(_this) {
      return function(data) {
        return $(element).closest('tr').remove();
      };
    })(this));
  };

  return paineisController;

})(window.baseController);
