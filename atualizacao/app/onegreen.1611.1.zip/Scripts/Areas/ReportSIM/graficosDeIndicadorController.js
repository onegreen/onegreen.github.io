﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.graficosDeIndicadorController = (function(superClass) {
  extend(graficosDeIndicadorController, superClass);

  function graficosDeIndicadorController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.alterarTamanhos = bind(this.alterarTamanhos, this);
    this.atualizarOrdem = bind(this.atualizarOrdem, this);
    this.mostrarModalDeEdicao = bind(this.mostrarModalDeEdicao, this);
    graficosDeIndicadorController.__super__.constructor.call(this, this.view, this.model, this.options);
    this.ReferenciaLista = "Graficos";
    this.get(".js-SeletorDeTamanho").click(this.alterarTamanhos);
    this.tamanho = this.get("#MostradorDoTamanho").attr("tamanho");
    this.get(".js-NaoVisivelNaEdicaoDoItem").fadeOut();
  }

  graficosDeIndicadorController.prototype.mostrarModalDeEdicao = function() {
    var ordem;
    ordem = $("#Item_" + this.options.IdDoItem).find('.js-ItemDeIndicador').length;
    console.log(this.view);
    return $as.ReportSIM.Relatorios.AdicionarGrafico.get({
      idDoSIMPart: this.get('#Id').val(),
      idDoItem: this.options.IdDoItem,
      ordem: ordem
    }).done((function(_this) {
      return function(html) {
        return $("#main-modal").html(html);
      };
    })(this));
  };

  graficosDeIndicadorController.prototype.atualizarOrdem = function() {
    var i, idDoItem, idDosItens, len, ref;
    graficosDeIndicadorController.__super__.atualizarOrdem.apply(this, arguments);
    idDosItens = [];
    ref = $(".js-IdDoGraficoDeIndicador", this.ItensContainer);
    for (i = 0, len = ref.length; i < len; i++) {
      idDoItem = ref[i];
      idDosItens.push(idDoItem.value);
    }
    return $as.ReportSIM.Relatorios.AlterarOrdemDosItensDoSIMPart.post({
      idDoSIMPart: this.get('#Id').val(),
      itens: idDosItens
    });
  };

  graficosDeIndicadorController.prototype.alterarTamanhos = function(event) {
    this.tamanho = $(event.delegateTarget).attr("tamanho");
    return $as.ReportSIM.Relatorios.AlterarTamanho.post({
      idItem: this.options.IdDoItem,
      tamanhoDosGraficos: this.tamanho
    }).done((function(_this) {
      return function(html) {
        return _this.view.html(html);
      };
    })(this));
  };

  return graficosDeIndicadorController;

})(window.SIMPartsDeIndicador);
