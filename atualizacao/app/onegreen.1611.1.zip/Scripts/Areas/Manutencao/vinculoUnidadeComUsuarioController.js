﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.vinculoUnidadeComUsuarioController = (function() {
  function vinculoUnidadeComUsuarioController(contexto) {
    this.contexto = contexto;
    this.reload = bind(this.reload, this);
    this.carregarUnidadeComUsuario = bind(this.carregarUnidadeComUsuario, this);
    this.carregarComboUsuariosDaEmpresa = bind(this.carregarComboUsuariosDaEmpresa, this);
    redimensionarModalLateral();
    this.carregarComboUsuariosDaEmpresa();
    $(this.contexto).css('z-index', ++window.WindowZIndex);
    $('#btn-Fechar').click(function() {
      --window.WindowZIndex;
      return $('#vinculoUnidadeComUsuario-modal-container').empty();
    });
    $("[rel=tooltip]").tooltip();
  }

  vinculoUnidadeComUsuarioController.prototype.carregarComboUsuariosDaEmpresa = function() {
    setCombo(this.contexto, '#Usuario_Nome', this.carregarUnidadeComUsuario);
    return $('#Usuario_Nome', this.contexto).focus();
  };

  vinculoUnidadeComUsuarioController.prototype.carregarUnidadeComUsuario = function() {
    return $as.Manutencao.UnidadeGerencial.ListarUnidadesParaVinculoComUsuario.get({
      idUsuario: $('#Usuario_Id').val()
    }).done((function(_this) {
      return function(data) {
        $('#unidadesDoUsuario-container').html(data);
      };
    })(this));
  };

  vinculoUnidadeComUsuarioController.prototype.reload = function() {
    return this.carregarUnidadeComUsuario();
  };

  return vinculoUnidadeComUsuarioController;

})();
