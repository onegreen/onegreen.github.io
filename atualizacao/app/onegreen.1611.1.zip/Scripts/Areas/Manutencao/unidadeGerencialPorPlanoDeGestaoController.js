﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.unidadeGerencialPorPlanoDeGestaoController = (function() {
  function unidadeGerencialPorPlanoDeGestaoController(options) {
    this.options = options;
    this.configurarComboPlanoDeGestao = bind(this.configurarComboPlanoDeGestao, this);
    this.ocultarSubordinadas = bind(this.ocultarSubordinadas, this);
    this.exibirSubordinadas = bind(this.exibirSubordinadas, this);
    this.exibirOcultarSubordinadas = bind(this.exibirOcultarSubordinadas, this);
    this.marcaDesmarcaElementoParaExclusao = bind(this.marcaDesmarcaElementoParaExclusao, this);
    this.reload = bind(this.reload, this);
    this.configurarComboPlanoDeGestao();
    $("#CamposProcurarUnidades").keyup(function() {
      var element, itens, k, len, results, valorPesquisa, verificarElementos, verificarFilhos;
      valorPesquisa = $.trim($(this).val().toLowerCase());
      itens = $(".filtravel", "#listagem-unidades");
      verificarFilhos = function(element) {
        var contem, filho;
        filho = $(filhos[j]);
        return contem = contem || (filho.text().toLowerCase().indexOf(valorPesquisa) !== -1);
      };
      verificarElementos = function(element) {
        var child, contem, filhos, k, len;
        contem = false;
        contem = contem || (element.text().toLowerCase().indexOf(valorPesquisa) !== -1);
        filhos = $(".observarNoFiltro", element);
        for (k = 0, len = filhos.length; k < len; k++) {
          child = filhos[k];
          verificarFilhos(child);
        }
        if (contem) {
          return element.css("display", "block");
        } else {
          return element.css("display", "none");
        }
      };
      results = [];
      for (k = 0, len = itens.length; k < len; k++) {
        element = itens[k];
        results.push(vericarElementos(element));
      }
      return results;
    });
  }

  unidadeGerencialPorPlanoDeGestaoController.prototype.reload = function(callback) {
    return $.ajax({
      type: 'POST',
      url: this.options.internalIndex,
      data: {
        idDoPlanoDeGestao: $("#IdPlanoDeGestao").val() ? $("#IdPlanoDeGestao").val() : this.options.planoDoFiltroAvancado
      },
      success: function(html) {
        $('#main').html(html);
        console.log(callback);
        if (callback !== void 0) {
          return callback();
        }
      }
    });
  };

  unidadeGerencialPorPlanoDeGestaoController.prototype.marcaDesmarcaElementoParaExclusao = function(elemento) {
    $(elemento).toggleClass('selecionado');
    if ($(".selecionado").length > 0) {
      return $("#excluir-selecionados-unidadegerencialporplanodegestao").removeAttr('disabled');
    } else {
      return $("#excluir-selecionados-unidadegerencialporplanodegestao").attr('disabled', 'disabled');
    }
  };

  unidadeGerencialPorPlanoDeGestaoController.prototype.exibirOcultarSubordinadas = function(el, idDaUnidade, idPlanoDeGestao) {
    var elemento;
    elemento = $(el);
    if (elemento.hasClass("fa-plus-square")) {
      return this.exibirSubordinadas(elemento, idDaUnidade, idPlanoDeGestao);
    } else {
      return this.ocultarSubordinadas(elemento, idDaUnidade, idPlanoDeGestao);
    }
  };

  unidadeGerencialPorPlanoDeGestaoController.prototype.exibirSubordinadas = function(elemento, idDaUnidade, idPlanoDeGestao) {
    return $.ajax({
      type: "GET",
      url: this.options.internalIndex,
      data: {
        idDaUnidadeGerencial: idDaUnidade,
        idDoPlanoDeGestao: idPlanoDeGestao
      },
      success: (function(_this) {
        return function(html) {
          var item, nivel;
          nivel = parseInt(elemento.parent().parent().data('nivel')) + 1;
          item = $($.parseHTML(html)).find('tr').attr('data-nivel', nivel);
          item.find('td').addClass("espacamento-hierarquia-0").addClass("espacamento-hierarquia-" + nivel);
          elemento.parent().parent().after(item);
          return elemento.removeClass("fa-plus-square").addClass("fa-minus-square");
        };
      })(this)
    });
  };

  unidadeGerencialPorPlanoDeGestaoController.prototype.ocultarSubordinadas = function(elemento, idDaUnidade) {
    if (idDaUnidade !== void 0) {
      $("[data-pai='" + idDaUnidade + "']").each((function(_this) {
        return function(i, e) {
          var idUnidade;
          idUnidade = $(e).data('idunidade');
          _this.ocultarSubordinadas($(e), idUnidade);
          elemento.find('i').removeClass("fa-minus-square").addClass("fa-plus-square");
          return $(e).remove();
        };
      })(this));
    }
    return elemento.removeClass("fa-minus-square").addClass("fa-plus-square");
  };

  unidadeGerencialPorPlanoDeGestaoController.prototype.configurarComboPlanoDeGestao = function() {
    return $('#PlanoDeGestaoNome').autocompleter(this.options.autoCompleterPlanoDeGestao, {
      loadOnDemand: false,
      elementToClick: "#PlanoDeGestaoNomeBtn",
      keyElement: "#IdPlanoDeGestao",
      defaultOption: {
        Key: '',
        Value: this.options.resource.Nenhum
      },
      onSelected: (function(_this) {
        return function(valueInput) {
          return $.ajax({
            type: "GET",
            url: _this.options.internalIndex,
            data: {
              idDoPlanoDeGestao: $("#IdPlanoDeGestao").val()
            },
            success: function(data) {
              $("#menuPlanosDeGestao li").removeClass("active");
              $("#" + $("#IdPlanoDeGestao").val()).parent().addClass("active");
              return $("#listagem-unidades").html($("#listagem-unidades", data).html());
            }
          });
        };
      })(this)
    });
  };

  return unidadeGerencialPorPlanoDeGestaoController;

})();
