﻿$(document).ready(function() {
  var globalScore, runGame, setScore;
  globalScore = 0;
  runGame = function() {
    $('.svg-target.target-wrong').unbind('click');
    $('.svg-target.target-ok').unbind('click');
    $('.svg-target.target-wrong').bind('click', function() {
      $(this).removeClass('target-wrong');
      $(this).parent().addClass('clicked clicked-wrong');
      $('#gswWheel').removeClass('running').addClass('game-over');
      setScore('Game Over!!!');
    });
    $('.svg-target.target-ok').bind('click', function() {
      globalScore++;
      setScore(globalScore);
      $(this).unbind('click');
      if (globalScore === 7) {
        $('#gswWheel').removeClass('running').addClass('game-won');
        setScore('You Won!!!');
      }
      $(this).parent().addClass('clicked clicked-ok');
    });
  };
  setScore = function(points) {
    globalScore = points;
    $('#counterShootingWheel').text(points);
  };
  $('.waiting-start .nic-game').click(function() {
    $('#noInternetConnection').removeClass('waiting-start');
  });
  $('#runGameShootingWheel').click(function() {
    $('#gswWheel').toggleClass('running');
    $('#gswWheel').find('.gsw-wheel-item').toggleClass('active');
    $(this).hide();
    $('#counterShootingWheel').show();
    $('#resetGameShootingWheel').removeAttr('disabled');
    setScore(0);
    runGame();
  });
  $('#resetGameShootingWheel').click(function() {
    if ($('#gswWheel').hasClass('game-over') || $('#gswWheel').hasClass('game-won')) {
      $('#gswWheel').toggleClass('running').removeClass('game-over game-won');
    }
    $('#gswWheel').find('.gsw-wheel-item').addClass('active').removeClass('clicked clicked-wrong clicked-ok');
    setScore(0);
    runGame();
  });
  $('#removeGameShootingWheel').click(function() {
    $('#gswWheel').removeClass('running');
    $('.game-shooting-wheel').addClass('game-closed');
    $('#restoreGameShootingWheel').show();
    $('#gswWheel').find('.gsw-wheel-item').removeClass('active').removeClass('clicked clicked-wrong clicked-ok');
    $('#resetGameShootingWheel').attr('disabled', 'disabled');
    setScore(0);
  });
  $('#restoreGameShootingWheel').click(function() {
    $('.game-shooting-wheel').removeClass('game-closed');
    $('#counterShootingWheel').hide();
    $('#runGameShootingWheel').show();
    $('#gswWheel').removeClass('game-over game-won');
    $(this).hide();
  });
  $('#nic-tentar-agora').on('click', function() {
    Notificacoes.api.atualizaContadorPeriodicamente(null, null, false);
  });
  window.noInternet = {
    show: function() {
      var noInternetEl;
      if (!noInternet.counting) {
        noInternetEl = $("#noInternetConnection");
        window.drawSpinner('#nic-spinner', 2, 8, 850, $('.navbar, #navbar-conteudo, .painel-simples-control').css('background-color'));
        noInternetEl.fadeIn(200);
        noInternet.count = 20;
        noInternet.countdown();
      }
    },
    hide: function() {
      var noInternetEl;
      noInternetEl = $("#noInternetConnection");
      noInternetEl.stop().fadeOut(200);
      window.stopSpinner('#nic-spinner');
      noInternet.count = 0;
      noInternet.counting = false;
    },
    count: 20,
    counting: false,
    countdown: function() {
      var nicCountdownEl;
      nicCountdownEl = $("#nic-countdown", "#noInternetConnection");
      setTimeout(function() {
        noInternet.counting = true;
        noInternet.count -= 1;
        nicCountdownEl.text(noInternet.count + " s");
        if (noInternet.count <= 0) {
          noInternet.count = 20;
          noInternet.counting = false;
          nicCountdownEl.text("...");
          Notificacoes.api.atualizaContadorPeriodicamente(null, null, false);
        } else {
          noInternet.countdown();
        }
      }, 1000);
    }
  };
});
