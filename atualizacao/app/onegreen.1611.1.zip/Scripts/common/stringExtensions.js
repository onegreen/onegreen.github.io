﻿var slice = [].slice;

String.format = function() {
  var args, stringToFormat;
  stringToFormat = arguments[0], args = 2 <= arguments.length ? slice.call(arguments, 1) : [];
  return stringToFormat.format(args);
};

String.prototype.format = function() {
  var argument, formatedString, i, len;
  for (i = 0, len = arguments.length; i < len; i++) {
    argument = arguments[i];
    formatedString = this.replace(new RegExp("\\{" + _i + "\\}", "gm"), argument);
  }
  return formatedString;
};

if (!String.prototype.trim) {
  String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g, '');
  };
}

window.IsJsonString = function(value) {
  try {
    JSON.parse(value);
  } catch (_error) {
    return false;
  }
  return true;
};

String.isJsonString = function(value) {
  return IsJsonString(value);
};

String.prototype.isJsonString = function() {
  return IsJsonString(this);
};
