﻿window.modalConfirm = function(msg, fn, fnCancel) {
  $(".modal-body", "#confirm-modal-container").html("<p>" + msg + "</p>");
  $("#confirmar-acao", "#confirm-modal-container").unbind('click').click(fn);
  if (fnCancel !== void 0 && fnCancel !== null) {
    $("#negar-acao", "#confirm-modal-container").unbind('click').click(fnCancel);
  }
  return $("#confirm-modal-container").window();
};
