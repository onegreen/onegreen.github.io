﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.LicenciamentoAmbiental || (this.LicenciamentoAmbiental = {});

window.LicenciamentoAmbiental.porteDoLicenciamentoController = (function() {
  function porteDoLicenciamentoController(container) {
    this.container = container;
    this.alterarItem = bind(this.alterarItem, this);
    this.adicionarItem = bind(this.adicionarItem, this);
  }

  porteDoLicenciamentoController.prototype.adicionarItem = function($item) {
    return $as.Onegreen.PorteDoLicenciamento.AdicionarPorte.post($item.parent().find(":input").serialize()).success((function(_this) {
      return function(data) {
        if (data.key !== void 0) {
          $("#divError").html('');
          $(data.key).addClass('error');
          return $("#divError").append("<ul><li>" + data.value + "</li></ul>");
        } else {
          return $(_this.container).html(data);
        }
      };
    })(this));
  };

  porteDoLicenciamentoController.prototype.alterarItem = function($item) {
    return $as.Onegreen.PorteDoLicenciamento.AlterarPorte.post($item.parent().find(":input").serialize()).success((function(_this) {
      return function(data) {
        if (data.key !== void 0) {
          $("#divError").html('');
          $(data.key).addClass('error');
          return $("#divError").append("<ul><li>" + data.value + "</li></ul>");
        } else {
          return $(_this.container).html(data);
        }
      };
    })(this));
  };

  return porteDoLicenciamentoController;

})();
