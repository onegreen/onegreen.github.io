﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.configuracoesDeFluxoController = (function() {
  configuracoesDeFluxoController.configurandoPrazos = false;

  function configuracoesDeFluxoController(contexto1, recursos) {
    this.contexto = contexto1;
    this.recursos = recursos;
    this.alterarConfiguracaoPorGrupoDeUsuarioParaTodasAsOrigens = bind(this.alterarConfiguracaoPorGrupoDeUsuarioParaTodasAsOrigens, this);
    this.alterarConfiguracaoPorGrupoDeUsuario = bind(this.alterarConfiguracaoPorGrupoDeUsuario, this);
    this.alterarConfiguracaoPorUnidadeParaTodasAsOrigens = bind(this.alterarConfiguracaoPorUnidadeParaTodasAsOrigens, this);
    this.alterarConfiguracaoPorUnidade = bind(this.alterarConfiguracaoPorUnidade, this);
    this.copiarConfiguracoesPorGrupoDeUsuario = bind(this.copiarConfiguracoesPorGrupoDeUsuario, this);
    this.copiarConfiguracoesPorUnidadeGerencial = bind(this.copiarConfiguracoesPorUnidadeGerencial, this);
    this.confirmarAplicacaoDeConfiguracoesEmSubordinadas = bind(this.confirmarAplicacaoDeConfiguracoesEmSubordinadas, this);
    this.aplicarConfiguracoesEmSubordinadas = bind(this.aplicarConfiguracoesEmSubordinadas, this);
    this.copiarConfiguracoesGrupo = bind(this.copiarConfiguracoesGrupo, this);
    this.copiarConfiguracoesUnidade = bind(this.copiarConfiguracoesUnidade, this);
    this.selecionarTipo = bind(this.selecionarTipo, this);
    setCombo(this.contexto, "#GrupoDoUsuarioNome", configuracoesDeFluxoController.carregarConfiguracoesDeFluxoPorGrupoDeUsuario);
    setCombo(this.contexto, "#UnidadeGerencialNome", configuracoesDeFluxoController.carregarConfiguracoesDeFluxoPorUnidade);
    $(".js-selecaoDeTipo", this.contexto).click(this.selecionarTipo);
    $("[rel=tooltip]", $(this.contexto)).tooltip();
    $('input[placeholder]', $(this.contexto)).placeholder();
  }

  configuracoesDeFluxoController.carregarConfiguracoesDeFluxoPorUnidade = function(contexto) {
    if ($("#IdUnidadeGerencial").val().length > 0) {
      return $as.Melhorias.ConfiguracoesDeFluxo.ConfiguracoesDoFluxo.get({
        idDaUnidadeGerencial: $("#IdUnidadeGerencial").val()
      }).success(function(data) {
        $("#configuracoesdefluxo-container").html(data);
        $("#btnAplicarSubordinadas").show();
        $("[rel=tooltip]", $(contexto || configuracoesDeFluxoController.contexto)).tooltip();
        return $('input[placeholder]').placeholder();
      });
    } else {
      return $("#configuracoesdefluxo-container").html("");
    }
  };

  configuracoesDeFluxoController.carregarConfiguracoesDeFluxoPorGrupoDeUsuario = function() {
    if ($("#IdDoGrupoDoUsuario").val().length > 0) {
      return $as.Melhorias.ConfiguracoesDeFluxo.ConfiguracoesDoFluxo.get({
        idDoGrupoDeUsuario: $("#IdDoGrupoDoUsuario").val()
      }).success(function(data) {
        $("#configuracoesdefluxo-container").html(data);
        $("#btnAplicarSubordinadas").hide();
        return $('input[placeholder]').placeholder();
      });
    } else {
      return $("#configuracoesdefluxo-container").html("");
    }
  };

  configuracoesDeFluxoController.concluirCopiaFluxo = function() {
    $("#formCopiarConfiguracoes").submit();
    $('#modalConfirmarCopia-close').click();
  };

  configuracoesDeFluxoController.prototype.selecionarTipo = function(evento) {
    var $element, $pai;
    $element = $(evento.currentTarget);
    $pai = $element.parent();
    $(".js-selecaoDeTipo", $pai).removeClass("btn-warning");
    $(".js-selecaoDeTipo", $pai).addClass("btn-default");
    $element.addClass("btn-warning");
    $(".js-Titulos").hide();
    $("#" + $element.attr('id-titulo')).show();
    $(".autocompleter", $pai).addClass("none");
    $("#" + $element.attr("for"), $pai).removeClass("none");
    if ($element.attr("id") === "BotaoTipoUnidade") {
      return configuracoesDeFluxoController.carregarConfiguracoesDeFluxoPorUnidade();
    } else {
      return configuracoesDeFluxoController.carregarConfiguracoesDeFluxoPorGrupoDeUsuario();
    }
  };

  configuracoesDeFluxoController.prototype.preencheComboDeGrupos = function() {
    return $as.API.GruposDeUsuario.RetornarCombo.get().success((function(_this) {
      return function(data) {
        $("#IdDoGrupoDoUsuario").val(data[0].Key);
        return $("#GrupoDoUsuarioNome").val(data[0].Value);
      };
    })(this));
  };

  configuracoesDeFluxoController.prototype.preencheComboDeUnidades = function() {
    return $as.API.UnidadeGerencial.RetornarComboUnidadesPorPlanoDeGestao.get().success((function(_this) {
      return function(data) {
        $("#IdUnidadeGerencial").val(data[0].Key);
        return $("#UnidadeGerencialNome").val(data[0].Value);
      };
    })(this));
  };

  configuracoesDeFluxoController.prototype.copiarConfiguracoesUnidade = function() {
    return $as.Melhorias.ConfiguracoesDeFluxo.CopiarConfiguracoesDeUmaUnidade.get({
      idDaUnidadeDeDestino: $("#IdUnidadeGerencial").val()
    }).success((function(_this) {
      return function(data) {
        $("#modalCopiarConfiguracoes").html(data);
        return configuracoesDeFluxoController.configurarModalCopiaFLuxo();
      };
    })(this));
  };

  configuracoesDeFluxoController.prototype.copiarConfiguracoesGrupo = function() {
    return $as.Melhorias.ConfiguracoesDeFluxo.CopiarConfiguracoesDeUmGrupo.get({
      idDoGrupoDeDestino: $("#IdDoGrupoDoUsuario").val()
    }).success((function(_this) {
      return function(data) {
        $("#modalCopiarConfiguracoes").html(data);
        return configuracoesDeFluxoController.configurarModalCopiaFLuxo();
      };
    })(this));
  };

  configuracoesDeFluxoController.configurarModalCopiaFLuxo = function() {
    $("#copiarconfiguracoesdefluxo-modal").window({
      width: '650px'
    });
    setCombo("#copiarconfiguracoesdefluxo-modal", "#GrupoDoUsuarioDeOrigemNome", function() {
      return $("#btnCopiarConfiguracaoesDeFluxo").removeAttr('disabled');
    });
    return setCombo("#copiarconfiguracoesdefluxo-modal", "#UnidadeGerencialDeOrigemNome", function() {
      return $("#btnCopiarConfiguracaoesDeFluxo").removeAttr('disabled');
    });
  };

  configuracoesDeFluxoController.prototype.aplicarConfiguracoesEmSubordinadas = function() {
    if ($("#AplicarSubordinadas").hasClass("btn-warning")) {
      return this.confirmarAplicacaoDeConfiguracoesEmSubordinadas();
    } else {
      return $as.Melhorias.ConfiguracoesDeFluxo.AplicarConfiguracoesEmSubordinadas.get({
        idDaUnidadeGerencial: $("#IdUnidadeGerencial").val()
      }).success((function(_this) {
        return function(data) {
          $("#modalAplicarConfiguracoesEmSubordinadas").html(data);
          return $("#aplicarconfiguracoesemsubordinadas-modal").window();
        };
      })(this));
    }
  };

  configuracoesDeFluxoController.prototype.confirmarAplicacaoDeConfiguracoesEmSubordinadas = function() {
    return $as.Melhorias.ConfiguracoesDeFluxo.ConfirmarAplicacaoDeConfiguracoesEmSubordinadas.post({
      idDaUnidadeGerencial: $("#IdUnidadeGerencial").val()
    }).success((function(_this) {
      return function(data) {
        configuracoesDeFluxoController.reload();
        return $('#close-modal-aplicarconfiguracoesemsubordinadas').click();
      };
    })(this));
  };

  configuracoesDeFluxoController.prototype.copiarConfiguracoesPorUnidadeGerencial = function() {
    return $("#formCopiarConfiguracoes").submit();
  };

  configuracoesDeFluxoController.prototype.copiarConfiguracoesPorGrupoDeUsuario = function() {
    return $("#formCopiarConfiguracoes").submit();
  };

  configuracoesDeFluxoController.prototype.alterarConfiguracaoPorUnidade = function(idDaConfiguracao, idDoMetodo, idDaOrigem, idDaUnidadeGerencial, idDaAtividade) {
    return $as.Melhorias.ConfiguracoesDeFluxo.AlterarConfiguracaoPorUnidade.post({
      idDaConfiguracao: idDaConfiguracao,
      idDoMetodo: idDoMetodo,
      idDaOrigem: idDaOrigem,
      idDaUnidadeGerencial: idDaUnidadeGerencial,
      idDaAtividade: idDaAtividade
    }).success((function(_this) {
      return function(data) {
        return configuracoesDeFluxoController.reload();
      };
    })(this));
  };

  configuracoesDeFluxoController.prototype.alterarConfiguracaoPorUnidadeParaTodasAsOrigens = function(remover, idDoMetodo, idDaUnidadeGerencial, idDaAtividade) {
    return $as.Melhorias.ConfiguracoesDeFluxo.AlterarConfiguracaoPorUnidadeParaTodasAsOrigens.post({
      remover: remover,
      idDoMetodo: idDoMetodo,
      idDaUnidadeGerencial: idDaUnidadeGerencial,
      idDaAtividade: idDaAtividade
    }).success((function(_this) {
      return function(data) {
        return configuracoesDeFluxoController.reload();
      };
    })(this));
  };

  configuracoesDeFluxoController.prototype.alterarConfiguracaoPorGrupoDeUsuario = function(idDaConfiguracao, idDoMetodo, idDaOrigem, idDoGrupo, idDaAtividade) {
    return $as.Melhorias.ConfiguracoesDeFluxo.AlterarConfiguracaoPorGrupoDeUsuario.post({
      idDaConfiguracao: idDaConfiguracao,
      idDoMetodo: idDoMetodo,
      idDaOrigem: idDaOrigem,
      idDoGrupo: idDoGrupo,
      idDaAtividade: idDaAtividade
    }).success((function(_this) {
      return function(data) {
        return configuracoesDeFluxoController.reload();
      };
    })(this));
  };

  configuracoesDeFluxoController.prototype.alterarConfiguracaoPorGrupoDeUsuarioParaTodasAsOrigens = function(remover, idDoMetodo, idDoGrupo, idDaAtividade) {
    return $as.Melhorias.ConfiguracoesDeFluxo.AlterarConfiguracaoPorGrupoDeUsuarioParaTodasAsOrigens.post({
      remover: remover,
      idDoMetodo: idDoMetodo,
      idDoGrupo: idDoGrupo,
      idDaAtividade: idDaAtividade
    }).success((function(_this) {
      return function(data) {
        return configuracoesDeFluxoController.reload();
      };
    })(this));
  };

  configuracoesDeFluxoController.reload = function() {
    $('#close-modal-copiarconfiguracoesdefluxo, #close-modal-aplicarconfiguracoesemsubordinadas').click();
    if (configuracoesDeFluxoController.configurandoPrazos && window.ConfiguracoesDePrazo) {
      return window.ConfiguracoesDePrazo.carregarConfiguracoesDePrazoPorUnidade($("#IdUnidadeGerencial"));
    } else {
      if ($("#BotaoTipoUnidade").hasClass("btn-warning")) {
        return configuracoesDeFluxoController.carregarConfiguracoesDeFluxoPorUnidade();
      } else {
        return configuracoesDeFluxoController.carregarConfiguracoesDeFluxoPorGrupoDeUsuario();
      }
    }
  };

  return configuracoesDeFluxoController;

})();

configuracoesDeFluxoController.configuracoesDePrazo = (function(superClass) {
  extend(configuracoesDePrazo, superClass);

  function configuracoesDePrazo(contexto1, recursos) {
    this.contexto = contexto1;
    this.recursos = recursos;
    this.setarMascaraDecimal = bind(this.setarMascaraDecimal, this);
    this.salvarPrazo = bind(this.salvarPrazo, this);
    this.carregarConfiguracoesDePrazoPorUnidade = bind(this.carregarConfiguracoesDePrazoPorUnidade, this);
    this.configurarChenge = bind(this.configurarChenge, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    configuracoesDePrazo.__super__.constructor.call(this, this.contexto);
    configuracoesDeFluxoController.configurandoPrazos = true;
    this.teclasNoASCIIFirefox = ["Right", "Left", "Backspace", "Del", "Tab"];
    this.configuracoesDeFluxo = new configuracoesDeFluxoController(this.contexto);
    setCombo(this.contexto, "#UnidadeGerencialNome", this.carregarConfiguracoesDePrazoPorUnidade);
    $("[rel=tooltip]", $(this.contexto)).tooltip();
    this.configurarBinds();
    this.configurarChenge();
  }

  configuracoesDePrazo.prototype.configurarBinds = function() {
    $("input[type=text]:not([disabled])", "#configuracoesdeprazo-container").unbind('keypress').bind('keypress', this.setarMascaraDecimal);
    $("#AplicarSubordinadas:not([disabled])", "#configuracoesdeprazo-container").unbind('click').bind('click', this.aplicarConfiguracoesEmSubordinadas);
    return $("#btnCopiarConfiguracoesUnidade:not(disabled)", "#configuracoesdeprazo-container").unbind('click').bind('click', this.copiarConfiguracoesUnidade);
  };

  configuracoesDePrazo.prototype.configurarChenge = function() {
    return $("input[type=text]:not([disabled])", "#configuracoesdeprazo-container").unbind("change").bind("change", this.salvarPrazo);
  };

  configuracoesDePrazo.prototype.carregarConfiguracoesDePrazoPorUnidade = function(input) {
    var idUnidade;
    idUnidade = $(input).val();
    if (idUnidade !== '') {
      return $as.Melhorias.ConfiguracoesDeFluxo.ConfiguracoesDePrazo.get({
        idDaUnidade: idUnidade
      }).success((function(_this) {
        return function(data) {
          $("#configuracoesdeprazo-container", _this.contexto).html(data);
          _this.configurarBinds();
          _this.configurarChenge();
          return $('input[placeholder]', _this.contexto).placeholder();
        };
      })(this));
    }
  };

  configuracoesDePrazo.prototype.salvarPrazo = function(e) {
    var dados, idUnidade, input;
    input = $(e.currentTarget);
    if (isNaN(parseInt(input.val()))) {
      input.val(0);
    } else {
      input.val(parseInt(input.val()));
    }
    idUnidade = $("#IdUnidadeGerencial", "#indexConfiguracoesDePrazo").val();
    if (idUnidade !== '') {
      dados = input.data();
      dados.idDaUnidadeGerencial = idUnidade;
      dados.PrazoParaExecucao = input.val();
      return $as.Melhorias.ConfiguracoesDeFluxo.AlterarPrazo.post(dados).success((function(_this) {
        return function(data) {
          if (!data.inseriuOuDeletou) {
            return input.val('0');
          } else {
            input.data("iddaconfiguracao", data.idDaConfiguracao);
            return input.val(data.prazo);
          }
        };
      })(this));
    }
  };

  configuracoesDePrazo.prototype.setarMascaraDecimal = function(e) {
    var keycode, target;
    target = e.target || e.srcElement;
    keycode = e.charCode || e.keyCode;
    if (this.teclasNoASCIIFirefox.contains(e.originalEvent.key)) {
      return true;
    } else {
      return window.VerificarValor(target, keycode, true, true);
    }
  };

  return configuracoesDePrazo;

})(window.configuracoesDeFluxoController);
