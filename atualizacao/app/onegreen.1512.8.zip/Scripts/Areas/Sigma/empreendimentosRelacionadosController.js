﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.EmpreendimentosRelacionadosController = (function() {
  function EmpreendimentosRelacionadosController(options) {
    this.options = options;
    this.recarregar = bind(this.recarregar, this);
    this.vincularProjeto = bind(this.vincularProjeto, this);
    this.adicionarProjeto = bind(this.adicionarProjeto, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.configurarBinds();
  }

  EmpreendimentosRelacionadosController.prototype.configurarBinds = function() {
    $('#adicionar-novo-subprojeto').on('click', this.adicionarProjeto);
    return $('#vincular-projeto').on('click', this.vincularProjeto);
  };

  EmpreendimentosRelacionadosController.prototype.adicionarProjeto = function(event) {
    return window.GetDiv('main').load(this.options.UrlAdicionarSubprojeto);
  };

  EmpreendimentosRelacionadosController.prototype.vincularProjeto = function(event) {
    return $as.Sigma.Empreendimentos.VincularProjetos.get({
      idDoProjetoPai: this.options.IdDoProjeto
    }).success((function(_this) {
      return function(data) {
        window.GetDiv('vincularprojetos-modal-container').html(data);
        $('#vincularprojetos-modal').window();
        return $('#vincular-projeto-modal', '#vincularprojetos-modal').attr("disabled", "disabled");
      };
    })(this));
  };

  EmpreendimentosRelacionadosController.prototype.recarregar = function() {
    return $as.Sigma.Empreendimentos.ListarEmpreendimentosRelacionados.get({
      idDoEmpreendimento: this.options.IdDoProjeto
    }).success((function(_this) {
      return function(data) {
        $('#empreendimentosrelacionados-container').html(data);
        return $('#vincularprojetos-modal').window('hide');
      };
    })(this));
  };

  return EmpreendimentosRelacionadosController;

})();
