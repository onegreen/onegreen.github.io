﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.meuPainelController = (function(superClass) {
  extend(meuPainelController, superClass);

  function meuPainelController(options, recursos) {
    this.options = options;
    this.recursos = recursos;
    this.carregarTela = bind(this.carregarTela, this);
    this.configurarReprogramacoesToggle = bind(this.configurarReprogramacoesToggle, this);
    this.atualizarFiltro = bind(this.atualizarFiltro, this);
    this.configurarVoltar = bind(this.configurarVoltar, this);
    this.carregarReprogramacoesPendentes = bind(this.carregarReprogramacoesPendentes, this);
    this.loadSolicitacoes = bind(this.loadSolicitacoes, this);
    this.carregarModalStatusCondicionantes = bind(this.carregarModalStatusCondicionantes, this);
    this.carregarModalStatusAcoes = bind(this.carregarModalStatusAcoes, this);
    this.loadTarefas = bind(this.loadTarefas, this);
    this.loadFluxoEmpreendimento = bind(this.loadFluxoEmpreendimento, this);
    this.loadComboUsuarios = bind(this.loadComboUsuarios, this);
    meuPainelController.__super__.constructor.call(this, this.options, this.recursos);
    this.ajaxLoader = '<div class="center"><img alt="" src="' + this.options.imgGraph + '"/></div>';
    this.atualizarFiltro();
    if (this.options.setComboUsuarios) {
      this.loadComboUsuarios();
    }
    this.carregarTela();
    this.configurarVoltar();
    $("[rel=tooltip]").tooltip();
  }

  meuPainelController.prototype.loadComboUsuarios = function() {
    return $('#NomeDoUsuario').autocompleter(this.options.urlComboUsuarios, {
      loadOnDemand: false,
      elementToClick: "#NomeDoUsuarioBtn",
      keyElement: "#IdDoUsuario"
    });
  };

  meuPainelController.prototype.loadFluxoEmpreendimento = function() {
    $('#fluxo-empreendimento-container').html(this.ajaxLoader);
    return $as.Sigma.Empreendimentos.FluxoEmpreendimento.get({
      idUnidade: FiltroPainel.IdUnidadeGerencial,
      incluirSubordinadas: FiltroPainel.IncluirSubordinadas,
      idUsuario: FiltroPainel.IdDoUsuario
    }).success((function(_this) {
      return function(data) {
        $('#fluxo-empreendimento-container').html(data);
        return $("[rel=tooltip]").tooltip();
      };
    })(this));
  };

  meuPainelController.prototype.loadTarefas = function() {
    $('#tarefas-grafico-container, #tarefas-tabela-container').html(this.ajaxLoader);
    return $as.Sigma.AtividadesDaLicenca.TarefasPeloResponsavel.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#tarefas-tabela-container").html($(data).filter("#tabela-tarefas"));
        $("[rel=tooltip]").tooltip();
        $("[rel=popover]").popover({
          placement: "top"
        });
        $("[id^=Percentual].btn-warning").prevAll().addClass("btn-warning");
        return setTimeout(function() {
          return Atividades.api.boot();
        }, 500);
      };
    })(this));
  };

  meuPainelController.prototype.carregarModalStatusAcoes = function(status) {
    window.FiltroPainel.StatusAtividade = status;
    return $as.Sigma.AtividadesDaLicenca.ListaAcoesDoUsuarioPorStatus.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        return window.GetDiv('status-acoes-container').html(data);
      };
    })(this));
  };

  meuPainelController.prototype.carregarModalStatusCondicionantes = function(status) {
    window.FiltroPainel.StatusAtividade = status;
    return $as.Sigma.AtividadesDaLicenca.ListaCondicionantesDoUsuarioPorStatus.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        return window.GetDiv('status-acoes-container').html(data);
      };
    })(this));
  };

  meuPainelController.prototype.loadSolicitacoes = function() {
    $('#solicitacoesLicenciamento-container').html(this.ajaxLoader);
    return $as.Sigma.SolicitacoesDeLicenciamento.ListarPeloResponsavel.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#solicitacoesLicenciamento-container").html(data);
        $("[rel=tooltip]").tooltip();
        return $("[rel=popover]").popover({
          placement: "top"
        });
      };
    })(this));
  };

  meuPainelController.prototype.carregarReprogramacoesPendentes = function() {
    return $as.Atividades.Atividades.CarregarReprogramacoesPendentes.get().success((function(_this) {
      return function(data) {
        return $("#reprogramacoesPendentes").html(data);
      };
    })(this));
  };

  meuPainelController.prototype.configurarVoltar = function() {
    return window.VoltarERecarregar = (function(_this) {
      return function() {
        return $as.Sigma.Painel.Index.post().success(function(data) {
          return $('#main').html(data);
        });
      };
    })(this);
  };

  meuPainelController.prototype.atualizarFiltro = function() {
    $("#IdDoUsuario").val(this.options.idDoUsuario);
    return window.FiltroPainel = {
      IdUnidadeGerencial: "",
      NomeUnidadeGerencial: '(' + this.recursos.Todas + ')',
      IdDoUsuario: this.options.idDoUsuario,
      IncluirSubordinadas: true
    };
  };

  meuPainelController.prototype.configurarReprogramacoesToggle = function(evento) {
    $(evento.currentTarget).hasClass("btn-warning");
    this.reprogramacoesToggle.removeClass("btn-warning");
    $(evento.currentTarget).addClass("btn-warning");
    return $("#reprogramacoes-pendentes-container, #reprogramacoes-solicitadas-container").toggle();
  };

  meuPainelController.prototype.carregarTela = function() {
    this.defineFiltro();
    this.loadFunctions();
    this.loadFluxoEmpreendimento();
    this.loadTarefas();
    this.loadSolicitacoes();
    this.reprogramacoesToggle = $(".js-reprogramacoes-toggle");
    this.reprogramacoesToggle.click(this.configurarReprogramacoesToggle);
    $("#lnkMeuPainel").addClass("active");
    return this.carregarReprogramacoesPendentes();
  };

  return meuPainelController;

})(window.painelBaseController);
