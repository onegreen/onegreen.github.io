﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.painelResumoController = (function(superClass) {
  extend(painelResumoController, superClass);

  function painelResumoController(options, recursos) {
    this.options = options;
    this.recursos = recursos;
    this.atualizarFiltro = bind(this.atualizarFiltro, this);
    this.loadEstudos = bind(this.loadEstudos, this);
    this.carregarTela = bind(this.carregarTela, this);
    painelResumoController.__super__.constructor.call(this, this.options, this.recursos);
    this.ajaxLoader = '<div class="center"><img alt="" src="' + this.options.imgGraph + '"/></div>';
    this.atualizarFiltro();
    this.configuraAplicarFiltro();
    this.carregarTela();
    $("[rel=tooltip]").tooltip();
    this.configurarVoltar();
  }

  painelResumoController.prototype.carregarTela = function() {
    this.defineFiltro();
    this.loadEstudos();
    this.loadFunctions();
    return $("#lnkResumo").addClass("active");
  };

  painelResumoController.prototype.loadEstudos = function() {
    $('#estudos-container').html(this.ajaxLoader);
    return $as.Sigma.EstudosDaLicenca.EstudosNaoConcretizados.get(window.FiltroMeuPainel).success((function(_this) {
      return function(data) {
        $("#estudos-container").html(data);
        return $("[rel=popover]").popover({
          placement: "top"
        });
      };
    })(this));
  };

  painelResumoController.prototype.atualizarFiltro = function() {
    return window.FiltroPainel = {
      IdUnidadeGerencial: "",
      NomeUnidadeGerencial: '(' + this.recursos.Todas + ')',
      IdDoUsuario: this.options.idDoUsuario,
      IncluirSubordinadas: true
    };
  };

  window.Estudo = {
    reload: function() {
      return painelResumoController.loadEstudos();
    }
  };

  painelResumoController.configurarVoltar = function() {
    return window.VoltarERecarregar = function() {
      return $as.Sigma.PainelResumo.Index.post().success(function(data) {
        return $('#main').html(data);
      });
    };
  };

  return painelResumoController;

})(window.painelBaseController);
