﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.RelatorioController = (function() {
  function RelatorioController(opcoes) {
    this.opcoes = opcoes;
    this.configurarBinds = bind(this.configurarBinds, this);
    this.configurarBinds();
  }

  RelatorioController.prototype.configurarBinds = function() {
    var dados, url;
    $("[rel=tooltip]").tooltip();
    $('#filtro-aplicado').on('click', (function(_this) {
      return function(e) {
        return $('#containerFiltroAvancado').toggle();
      };
    })(this));
    url = this.opcoes.UrlPDF + '?' + (dados = $('#containerFiltroAvancado').find(":input").serialize());
    $('#GerarPDF').attr('href', url);
    url = this.opcoes.UrlCSV + '?' + (dados = $('#containerFiltroAvancado').find(":input").serialize());
    $('#GerarCSV').attr('href', url);
    return $('#voltarRelatorio').on('click', (function(_this) {
      return function(e) {
        return _this.voltarERecarregar();
      };
    })(this));
  };

  return RelatorioController;

})();
