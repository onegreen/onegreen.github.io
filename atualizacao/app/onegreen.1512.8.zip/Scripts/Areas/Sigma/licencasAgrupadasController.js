﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.LicencasAgrupadasController = (function() {
  function LicencasAgrupadasController(options) {
    this.options = options;
    this.recarregar = bind(this.recarregar, this);
    this.vincularLicencas = bind(this.vincularLicencas, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.configurarBinds();
  }

  LicencasAgrupadasController.prototype.configurarBinds = function() {
    return $('#vincular-licencas').on('click', this.vincularLicencas);
  };

  LicencasAgrupadasController.prototype.vincularLicencas = function(event) {
    return $as.Sigma.LicencasAmbientais.VincularLicencas.get({
      idDoEmpreendimento: this.options.idDoEmpreendimento,
      idDaLicencaAmbiental: this.options.idDaLicenca
    }).success((function(_this) {
      return function(data) {
        window.GetDiv('vincularlicencas-modal-container').html(data);
        $('#vincularlicencas-modal').window();
        return $('#vincular-licenca-modal', '#vincularlicencas-modal').attr("disabled", "disabled");
      };
    })(this));
  };

  LicencasAgrupadasController.prototype.recarregar = function() {
    return $as.Sigma.LicencasAmbientais.RetornarLicencasAgrupadas.get({
      idDoEmpreendimento: this.options.idDoEmpreendimento,
      idDaLicencaAmbiental: this.options.idDaLicenca
    }).success((function(_this) {
      return function(data) {
        $('#licencasagrupadas-container').html(data);
        return $('#vincularlicencas-modal').window('hide');
      };
    })(this));
  };

  return LicencasAgrupadasController;

})();
