﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.painelBaseController = (function() {
  function painelBaseController(options, recursos) {
    this.options = options;
    this.recursos = recursos;
    this.marcarPercentualDeConclusaoToggle = bind(this.marcarPercentualDeConclusaoToggle, this);
    this.loadLicencas = bind(this.loadLicencas, this);
    this.loadEmpreendimentos = bind(this.loadEmpreendimentos, this);
    this.loadMarcosDeProjeto = bind(this.loadMarcosDeProjeto, this);
    this.loadCondicionantes = bind(this.loadCondicionantes, this);
    this.funcaoCallBack = bind(this.funcaoCallBack, this);
    this.reload = bind(this.reload, this);
    this.configuraLinkVoltarDaLicenca = bind(this.configuraLinkVoltarDaLicenca, this);
    this.loadComboUnidadeGerencial = bind(this.loadComboUnidadeGerencial, this);
    this.defineFiltro = bind(this.defineFiltro, this);
    this.configuraAplicarFiltro = bind(this.configuraAplicarFiltro, this);
    this.preencherFiltro = bind(this.preencherFiltro, this);
    this.loadFunctions = bind(this.loadFunctions, this);
  }

  painelBaseController.prototype.loadFunctions = function() {
    $("#menuSuperior li").removeClass("active");
    $("footer").removeClass("footerPS");
    this.loadComboUnidadeGerencial();
    this.loadCondicionantes();
    this.loadMarcosDeProjeto();
    this.loadLicencas();
    this.loadEmpreendimentos();
    window.LicencaAmbiental = {};
    return window.FiltroAvancadoEmpreendimento = null;
  };

  painelBaseController.prototype.preencherFiltro = function() {
    $("#IdUnidadeGerencial").val(window.FiltroPainel.IdUnidadeGerencial);
    $("#UnidadeGerencialNome").val(window.FiltroPainel.NomeUnidadeGerencial);
    if (window.FiltroPainel.IncluirSubordinadas) {
      return $("#IncluirSubordinadas").attr("checked", "checked");
    } else {
      return $("#IncluirSubordinadas").removeAttr("checked");
    }
  };

  painelBaseController.prototype.configuraAplicarFiltro = function() {
    return $("#AplicarFiltro").click((function(_this) {
      return function(e) {
        e.preventDefault();
        _this.defineFiltro();
        return _this.carregarTela();
      };
    })(this));
  };

  painelBaseController.prototype.defineFiltro = function() {
    var UnidadeGerencialNome;
    window.FiltroPainel.IdDoUsuario = $("#IdDoUsuario").val();
    UnidadeGerencialNome = $("#UnidadeGerencialNome").val();
    window.FiltroPainel.IdUnidadeGerencial = $("#IdUnidadeGerencial").val();
    if (!(window.FiltroPainel.IdUnidadeGerencial > 0)) {
      UnidadeGerencialNome = '(' + this.recursos.Todas + ')';
    }
    window.FiltroPainel.NomeUnidadeGerencial = UnidadeGerencialNome;
    return window.FiltroPainel.IncluirSubordinadas = $("#IncluirSubordinadas").attr("checked") !== void 0;
  };

  painelBaseController.prototype.loadComboUnidadeGerencial = function() {
    this.preencherFiltro();
    return $('#UnidadeGerencialNome').autocompleter(this.options.urlComboUnidadeGerencial, {
      loadOnDemand: false,
      elementToClick: "#UnidadeGerencialNomeBtn",
      keyElement: "#IdUnidadeGerencial",
      defaultOption: {
        Key: "",
        Value: '(' + this.recursos.Todas + ')'
      }
    });
  };

  painelBaseController.prototype.configuraLinkVoltarDaLicenca = function() {
    var link;
    link = "<li class='divider'></li><li class='voltar'><a href='' onclick='VoltarERecarregar();return false;'>(" + this.recursos.Voltar + ")<i class='fa swicon-seta fr'></i></a></li>";
    return $(link).appendTo("#linksVoltar");
  };

  painelBaseController.prototype.reload = function() {
    return eval(atividadePainel.callback);
  };

  painelBaseController.prototype.funcaoCallBack = function() {
    return this.reload();
  };

  painelBaseController.prototype.loadCondicionantes = function() {
    $('#condicionantes-grafico-container, #condicionantes-tabela-container').html(this.ajaxLoader);
    return $as.Sigma.AtividadesDaLicenca.CondicionantesPeloResponsavel.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#condicionantes-tabela-container").html($(data).filter("#tabela-condicionantes"));
        $("[rel=tooltip]").tooltip();
        $("[rel=popover]").popover({
          placement: "top"
        });
        $("[id^=Percentual].btn-warning").prevAll().addClass("btn-warning");
        return setTimeout(function() {
          return Atividades.api.boot();
        }, 500);
      };
    })(this));
  };

  painelBaseController.prototype.loadMarcosDeProjeto = function() {
    $('#acoes-grafico-container, #acoes-tabela-container').html(this.ajaxLoader);
    return $as.Sigma.AtividadesDoEmpreendimento.AcoesPeloResponsavel.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#acoes-tabela-container").html($(data).filter("#tabela-acoes"));
        $("[rel=tooltip]").tooltip();
        $("[rel=popover]").popover({
          placement: "top"
        });
        $("[id^=Percentual].btn-warning").prevAll().addClass("btn-warning");
        return setTimeout(function() {
          return Atividades.api.boot();
        }, 500);
      };
    })(this));
  };

  painelBaseController.prototype.loadEmpreendimentos = function() {
    $('#empreendimentos-grafico-container, #empreendimentos-tabela-container').html(this.ajaxLoader);
    return $as.Sigma.Empreendimentos.EmpreendimentosPeloResponsavel.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#empreendimentos-grafico-container").html($(data).filter("#grafico-empreendimentos"));
        $("#empreendimentos-tabela-container").html($(data).filter("#tabela-empreendimentos"));
        return $("[rel=tooltip]").tooltip();
      };
    })(this));
  };

  painelBaseController.prototype.loadLicencas = function() {
    $('#licencas-grafico-container, #licencas-tabela-container').html(this.ajaxLoader);
    return $as.Sigma.LicencasAmbientais.LicencasPorEnvolvidos.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#licencas-grafico-container").html($(data).filter("#grafico-licencas"));
        $("#licencas-tabela-container").html($(data).filter("#tabela-licencas"));
        $("[rel=tooltip]").tooltip();
        $("[rel=popover]").popover({
          placement: "top"
        });
        return _this.configuraLinkVoltarDaLicenca();
      };
    })(this));
  };

  painelBaseController.prototype.marcarPercentualDeConclusaoToggle = function(element) {
    var $percentualAtual;
    $percentualAtual = $(element);
    $percentualAtual.nextAll($('#PercentualDeConclusaoToggle')).removeClass("btn-warning");
    $percentualAtual.prevAll($('#PercentualDeConclusaoToggle')).addClass("btn-warning");
    return $percentualAtual.addClass("btn-warning");
  };

  return painelBaseController;

})();
