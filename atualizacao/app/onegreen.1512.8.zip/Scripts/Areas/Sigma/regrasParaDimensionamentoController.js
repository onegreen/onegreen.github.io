﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.regrasParaDimensionamentoController = (function() {
  function regrasParaDimensionamentoController() {
    this.AtualizarSelecoes = bind(this.AtualizarSelecoes, this);
    this.SalvarDimensionamentoOpcoes = bind(this.SalvarDimensionamentoOpcoes, this);
    this.SalvarValoresDoDimensionamento = bind(this.SalvarValoresDoDimensionamento, this);
    this.CarregarPortesPorAtividade = bind(this.CarregarPortesPorAtividade, this);
    this.CarregarDimensionamentosPorPorte = bind(this.CarregarDimensionamentosPorPorte, this);
    this.AlterarComparacao = bind(this.AlterarComparacao, this);
    var a;
    a = 0;
  }

  regrasParaDimensionamentoController.prototype.ComparacaoAte = function(idDoAtributo) {
    $("#entre-" + idDoAtributo).hide();
    $("#e-" + idDoAtributo).hide();
    $("#valorMaximo-" + idDoAtributo).show();
    $("#valorMinimo-" + idDoAtributo).hide();
    return $("#valorMinimo-" + idDoAtributo).val("0");
  };

  regrasParaDimensionamentoController.prototype.ComparacaoMaiorQue = function(idDoAtributo) {
    $("#entre-" + idDoAtributo).hide();
    $("#e-" + idDoAtributo).hide();
    $("#valorMinimo-" + idDoAtributo).show();
    $("#valorMaximo-" + idDoAtributo).hide();
    return $("#valorMaximo-" + idDoAtributo).val("9999");
  };

  regrasParaDimensionamentoController.prototype.ComparacaoEntreValores = function(idDoAtributo) {
    $("#entre-" + idDoAtributo).show();
    $("#e-" + idDoAtributo).show();
    $("#valorMinimo-" + idDoAtributo).show();
    return $("#valorMaximo-" + idDoAtributo).show();
  };

  regrasParaDimensionamentoController.prototype.ComparacaoIgual = function(idDoAtributo) {
    $("#entre-" + idDoAtributo).hide();
    $("#e-" + idDoAtributo).hide();
    $("#valorMinimo-" + idDoAtributo).hide();
    return $("#valorMaximo-" + idDoAtributo).show();
  };

  regrasParaDimensionamentoController.prototype.AlterarComparacao = function(tipoComparacao, idDoAtributo) {
    if (tipoComparacao === "MaiorQue") {
      this.ComparacaoMaiorQue(idDoAtributo);
    }
    if (tipoComparacao === "Ate") {
      this.ComparacaoAte(idDoAtributo);
    }
    if (tipoComparacao === "EntreValores") {
      this.ComparacaoEntreValores(idDoAtributo);
    }
    if (tipoComparacao === "Igual") {
      return this.ComparacaoIgual(idDoAtributo);
    }
  };

  regrasParaDimensionamentoController.prototype.AdicionarNovoAtributo = function(idDoPorte, idDaAtividade) {
    return $as.Sigma.AtividadesParaRegularizacao.AdicionarNovoAtributo.get({
      idDoPorte: idDoPorte,
      idDaAtividade: idDaAtividade
    }).success((function(_this) {
      return function(data) {
        return $("#modal-container-novoAtributo").html(data);
      };
    })(this));
  };

  regrasParaDimensionamentoController.prototype.CarregarDimensionamentosPorPorte = function(idDoPorte, idDaAtividade) {
    return $as.Sigma.AtividadesParaRegularizacao.CarregarDimensionamentosPorPorte.get({
      idDoPorte: idDoPorte,
      idDaAtividade: idDaAtividade
    }).success((function(_this) {
      return function(data) {
        $("#dimensionamentosPorte-" + idDoPorte).html(data);
        _this.AtualizarSelecoes();
        return $(".close", "#modal-container-novoAtributo").click();
      };
    })(this));
  };

  regrasParaDimensionamentoController.prototype.CarregarPortesPorAtividade = function(idDaAtividade) {
    return $as.Sigma.AtividadesParaRegularizacao.CarregarPortesPorAtividade.get({
      idDaAtividade: idDaAtividade
    }).success((function(_this) {
      return function(data) {
        $("#portesPorAtividade").html(data);
        _this.AtualizarSelecoes();
        return $(".close", "#modal-container-novoAtributo").click();
      };
    })(this));
  };

  regrasParaDimensionamentoController.prototype.SalvarValoresDoDimensionamento = function(idDoPorte, idDaAtividade, $elemento, idDoDimensionamento) {
    var dados;
    dados = $elemento.parent().parent().find(":input").serialize();
    return $as.Sigma.AtividadesParaRegularizacao.SalvarValoresDoDimensionamento.post(dados).success((function(_this) {
      return function(data) {
        $("#dimensionamentosPorte-" + idDoPorte).html(data);
        _this.AtualizarSelecoes();
        return _this.ProximoInput($elemento, idDoDimensionamento);
      };
    })(this));
  };

  regrasParaDimensionamentoController.prototype.SalvarDimensionamentoOpcoes = function(idDoPorte, idDaAtividade, $elemento, idDoDimensionamento) {
    var dados;
    dados = $elemento.parent().parent().find(":input").serialize();
    return $as.Sigma.AtividadesParaRegularizacao.SalvarDimensionamentoOpcoes.post(dados).success((function(_this) {
      return function(data) {
        $("#dimensionamentosPorte-" + idDoPorte).html(data);
        _this.AtualizarSelecoes();
        return _this.ProximoInput($elemento, idDoDimensionamento);
      };
    })(this));
  };

  regrasParaDimensionamentoController.prototype.MoverDimensionamentoParaCima = function(idDoPorte, idDoDimensionamento) {
    return $as.Sigma.AtividadesParaRegularizacao.MoverDimensionamentoParaCima.get({
      idDoPorte: idDoPorte,
      idDoDimensionamento: idDoDimensionamento
    }).success((function(_this) {
      return function(data) {
        $("#dimensionamentosPorte-" + idDoPorte).html(data);
        return _this.AtualizarSelecoes();
      };
    })(this));
  };

  regrasParaDimensionamentoController.prototype.MoverDimensionamentoParaBaixo = function(idDoPorte, idDoDimensionamento) {
    return $as.Sigma.AtividadesParaRegularizacao.MoverDimensionamentoParaBaixo.get({
      idDoPorte: idDoPorte,
      idDoDimensionamento: idDoDimensionamento
    }).success((function(_this) {
      return function(data) {
        $("#dimensionamentosPorte-" + idDoPorte).html(data);
        return _this.AtualizarSelecoes();
      };
    })(this));
  };

  regrasParaDimensionamentoController.prototype.ProximoInput = function(elemento, idDoDimensionamento) {
    var inputs, numeroProximoInput, proximoInput;
    inputs = $(".wanted", "tabela-" + idDoDimensionamento);
    numeroProximoInput = $(elemento, "tabela-" + idDoDimensionamento).attr("tabindex") + 1;
    proximoInput = $("#tabela-" + idDoDimensionamento).find("[tabindex=" + numeroProximoInput + "]");
    return proximoInput.focus();
  };

  regrasParaDimensionamentoController.prototype.MudarElemento = function(elemento) {
    return $(elemento).change();
  };

  regrasParaDimensionamentoController.prototype.AtualizarSelecoes = function() {
    var elemento, elementos, i, len;
    elementos = $(".comparacao-atributo");
    for (i = 0, len = elementos.length; i < len; i++) {
      elemento = elementos[i];
      this.MudarElemento(elemento);
    }
  };

  regrasParaDimensionamentoController.prototype.ExclusaoAtributo = function() {
    return $(".close", "#modal-container-novoAtributo").click();
  };

  return regrasParaDimensionamentoController;

})();
