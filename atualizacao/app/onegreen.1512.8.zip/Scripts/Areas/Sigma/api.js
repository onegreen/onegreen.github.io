﻿this.Sigma || (this.Sigma = {});

Sigma.api = (function() {
  function api() {}

  api.desmarcaMenu = function() {
    return $("#menuSuperior li").removeClass("active");
  };

  return api;

})();
