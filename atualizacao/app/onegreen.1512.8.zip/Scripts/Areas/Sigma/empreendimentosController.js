﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.EmpreendimentosController = (function() {
  function EmpreendimentosController(opcoes) {
    this.opcoes = opcoes;
    this.excluirProjeto = bind(this.excluirProjeto, this);
    this.confirmacaoDeExclusaoProjeto = bind(this.confirmacaoDeExclusaoProjeto, this);
    this.loadTab = bind(this.loadTab, this);
    this.configurarBind = bind(this.configurarBind, this);
    this.configurarBind();
    $('.close').click();
  }

  EmpreendimentosController.prototype.configurarBind = function() {
    $("[rel=tooltip]").tooltip();
    $('a[data-toggle="tab"]', this.opcoes.Contexto).on('shown.bs.tab', this.loadTab);
    $('.js-excluir-projeto', this.opcoes.Contexto).on('click', this.confirmacaoDeExclusaoProjeto);
    return $('.dropdown-hover').hover((function() {
      return $(this).addClass('open');
    }), function() {
      return $(this).removeClass('open');
    });
  };

  EmpreendimentosController.prototype.loadTab = function(event) {
    if (!$(event.target).data('carregado')) {
      $($(event.target).attr('href')).load($(event.target).data('url'));
      return $(event.target).data('carregado', true);
    }
  };

  EmpreendimentosController.prototype.confirmacaoDeExclusaoProjeto = function(event) {
    return window.modalConfirm($(event.delegateTarget).data("ajax-confirm"), this.excluirProjeto);
  };

  EmpreendimentosController.prototype.excluirProjeto = function() {
    return $as.Sigma.Empreendimentos.Delete.post({
      id: this.opcoes.idDoProjeto
    }).success((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  return EmpreendimentosController;

})();
