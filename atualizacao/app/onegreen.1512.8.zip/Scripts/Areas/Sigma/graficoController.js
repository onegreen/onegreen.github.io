﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.GraficoController = (function() {
  function GraficoController(opcoes) {
    this.opcoes = opcoes;
    this.exibirLicenciamentosPorEtapa = bind(this.exibirLicenciamentosPorEtapa, this);
    this.exibirProcessos = bind(this.exibirProcessos, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.configurarBinds();
  }

  GraficoController.prototype.configurarBinds = function() {
    var dados, url;
    $("[rel=tooltip]").tooltip();
    $('#filtro-aplicado').on('click', (function(_this) {
      return function(e) {
        return $('#containerFiltroAvancado').toggle();
      };
    })(this));
    url = this.opcoes.UrlPDF + '?' + (dados = $('#containerFiltroAvancado').find(":input").serialize());
    $('#GerarPDF').attr('href', url);
    url = this.opcoes.UrlPDF + '?ImprimirDetalhes=true&' + (dados = $('#containerFiltroAvancado').find(":input").serialize());
    $('#GerarPDFDetalhes').attr('href', url);
    return $('#voltarRelatorio').on('click', (function(_this) {
      return function(e) {
        return _this.voltarERecarregar();
      };
    })(this));
  };

  GraficoController.prototype.exibirProcessos = function(tipo) {
    var dados;
    $("#tipoDetalhe", "#containerFiltroAvancado").val(tipo);
    dados = $('#containerFiltroAvancado').find(":input").serialize();
    return $as.Sigma.GraficosEstatisticos.RetornarProcessosPorStatus.get(dados).success((function(_this) {
      return function(data) {
        window.GetDiv('statusprocessos-modal-container').html(data);
        return $('#statusdosprocessos-modal').window();
      };
    })(this));
  };

  GraficoController.prototype.exibirLicenciamentosPorEtapa = function(tipo) {
    var dados;
    $("#tipoDetalhe", "#containerFiltroAvancado").val(tipo);
    dados = $('#containerFiltroAvancado').find(":input").serialize();
    return $as.Sigma.GraficosEstatisticos.RetornarLicenciamentosPorEtapa.get(dados).success((function(_this) {
      return function(data) {
        window.GetDiv('etapaslicenciamento-modal-container').html(data);
        return $('#etapasdoslicenciamento-modal').window();
      };
    })(this));
  };

  return GraficoController;

})();
