﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.solicitacoesDeLicenciamentoController = (function(superClass) {
  extend(solicitacoesDeLicenciamentoController, superClass);

  function solicitacoesDeLicenciamentoController(view, modelo, opcoes) {
    this.view = view;
    this.modelo = modelo;
    this.opcoes = opcoes;
    this.carregarTela = bind(this.carregarTela, this);
    this.comboDNPMs = bind(this.comboDNPMs, this);
    this.comboAtividades = bind(this.comboAtividades, this);
    this.comboTipoDeEmpreendimento = bind(this.comboTipoDeEmpreendimento, this);
    this.comboLegislacoesAmbientais = bind(this.comboLegislacoesAmbientais, this);
    this.comboEnderecos = bind(this.comboEnderecos, this);
    this.limparComboTipologia = bind(this.limparComboTipologia, this);
    this.camposDependentesTipologia = bind(this.camposDependentesTipologia, this);
    this.camposDependentesLegislacao = bind(this.camposDependentesLegislacao, this);
    this.reload = bind(this.reload, this);
    this.toggleBotaoCanceladas = bind(this.toggleBotaoCanceladas, this);
    this.load = bind(this.load, this);
    this.contexto = "#main";
    if (this.opcoes === void 0 || this.opcoes === null) {
      solicitacoesDeLicenciamentoController.__super__.constructor.call(this, this.view);
      this.load();
    } else {
      this.carregarTela();
    }
    $('#Descricao').focus();
  }

  solicitacoesDeLicenciamentoController.prototype.load = function() {
    this.exibirCanceladasControl = this.get("#exibir-solicitacoes-canceladas");
    this.exibirCanceladasControl.click(this.toggleBotaoCanceladas);
    this.tableContainer = this.get("#tabela-solicitacoes-container");
    this.textSearchInput = this.get("#Filtro-SolicitacoesDeLicenciamento");
    this.searchInput = this.get("#div-input-pesquisar").append("<input id='exibirCanceladas' name='exibirCanceladas' type='hidden' value='false' />");
    return this.get("#exibirCanceladas").val(this.exibirCanceladasControl.hasClass("btn-primary"));
  };

  solicitacoesDeLicenciamentoController.prototype.toggleBotaoCanceladas = function(event) {
    this.exibirCanceladasControl.toggleClass('btn-primary').toggleClass('active');
    this.get("#exibirCanceladas").val(this.exibirCanceladasControl.hasClass("btn-primary"));
    return this.reload();
  };

  solicitacoesDeLicenciamentoController.prototype.reload = function() {
    return $as.Sigma.SolicitacoesDeLicenciamento.RetornarSolicitacoes.get({
      exibirCanceladas: this.exibirCanceladasControl.hasClass("btn-primary"),
      filtro: this.textSearchInput.val()
    }).done((function(_this) {
      return function(html) {
        return _this.tableContainer.html(html);
      };
    })(this));
  };

  solicitacoesDeLicenciamentoController.prototype.camposDependentesLegislacao = function() {
    var legislacaoSelecionada;
    legislacaoSelecionada = $("#LegislacaoAmbiental_Id").val() !== null && $("#LegislacaoAmbiental_Id").val() !== 0 && $("#LegislacaoAmbiental_Id").val() !== void 0 && $("#LegislacaoAmbiental_Id").val() !== "";
    if (legislacaoSelecionada) {
      this.comboTipoDeEmpreendimento();
    }
    $("#TipoDeEmpreendimento_Nome").data('autocompleter').disableElseEnable(!legislacaoSelecionada);
    return this.limparComboTipologia();
  };

  solicitacoesDeLicenciamentoController.prototype.camposDependentesTipologia = function() {
    var tipoEmpreendimentoSelecionado;
    tipoEmpreendimentoSelecionado = $("#TipoDeEmpreendimento_Id").val() !== null && $("#TipoDeEmpreendimento_Id").val() !== 0 && $("#TipoDeEmpreendimento_Id").val() !== void 0 && $("#TipoDeEmpreendimento_Id").val() !== "";
    if (tipoEmpreendimentoSelecionado) {
      this.comboAtividades();
    }
    return $("#AtividadesParaRegularizacaoCombo").data('autocompleter').disableElseEnable(!tipoEmpreendimentoSelecionado);
  };

  solicitacoesDeLicenciamentoController.prototype.limparComboTipologia = function() {
    $("#TipoDeEmpreendimento_Id").val('');
    $("#TipoDeEmpreendimento_Nome").val('');
    return $("#AtividadesParaRegularizacaoCombo").data('autocompleter').disableElseEnable(true);
  };

  solicitacoesDeLicenciamentoController.prototype.comboEnderecos = function() {
    return setCombo(this.contexto, "#Endereco_NomeFantasia");
  };

  solicitacoesDeLicenciamentoController.prototype.comboLegislacoesAmbientais = function() {
    return setCombo(this.contexto, "#LegislacaoAmbiental_Nome", this.camposDependentesLegislacao);
  };

  solicitacoesDeLicenciamentoController.prototype.comboTipoDeEmpreendimento = function() {
    var parametros;
    parametros = {
      ideLegislacao: $("#LegislacaoAmbiental_Id").val()
    };
    return setCombo(this.contexto, "#TipoDeEmpreendimento_Nome", this.camposDependentesTipologia, parametros);
  };

  solicitacoesDeLicenciamentoController.prototype.comboAtividades = function() {
    var $combo, $divCombo, atividadesViewModel;
    $.loadTemplate(this.opcoes.TemplateAtividades, 'atividadesParaRegularizacaoTemplate');
    atividadesViewModel = {
      atividades: ko.observableArray(this.opcoes.AtividadesSelecionadas),
      removeAtividade: function(atividade) {
        return this.atividades.remove(atividade);
      }
    };
    window.atividadesViewModel = atividadesViewModel;
    ko.applyBindings(atividadesViewModel, $('#atividadesParaRegularizacao_itens')[0]);
    $combo = $("#AtividadesParaRegularizacaoCombo");
    $divCombo = $combo.closest('[data-url]');
    return $combo.autocompleter($divCombo.data('url'), {
      elementToClick: "#AtividadesParaRegularizacaoComboBtn",
      multiSelectArray: atividadesViewModel.atividades,
      multiSelectElement: "#atividadesParaRegularizacao_itens",
      keyName: "idsAtividadesParaRegularizacao",
      parameters: {
        idTipoEmpreendimento: $("#TipoDeEmpreendimento_Id").val()
      },
      multiSelectDescriptionName: "Descricao"
    });
  };

  solicitacoesDeLicenciamentoController.prototype.comboDNPMs = function() {
    var $combo, $divCombo, dnpmsViewModel;
    $.loadTemplate(this.opcoes.TemplateDNPMs, 'dnpmsTemplate');
    dnpmsViewModel = {
      dnpms: ko.observableArray(this.opcoes.DNPMsSelecionados),
      removeDNPM: function(dnpm) {
        return this.dnpms.remove(dnpm);
      }
    };
    window.dnpmsViewModel = dnpmsViewModel;
    ko.applyBindings(dnpmsViewModel, $('#dnpms_itens')[0]);
    $combo = $("#DNPMsCombo");
    $divCombo = $combo.closest('[data-url]');
    return $combo.autocompleter($divCombo.data('url'), {
      elementToClick: "#DNPMsComboBtn",
      multiSelectArray: dnpmsViewModel.dnpms,
      multiSelectElement: "#dnpms_itens",
      keyName: "idsDnpms",
      abrirParaCima: true,
      multiSelectDescriptionName: "Descricao"
    });
  };

  solicitacoesDeLicenciamentoController.prototype.comboUsuarios = function() {
    var $combo, $divCombo, usuariosViewModel;
    $.loadTemplate(this.opcoes.TemplateUsuarios, 'usuariosTemplate');
    usuariosViewModel = {
      usuarios: ko.observableArray(this.opcoes.UsuariosSelecionados),
      removeUsuario: function(usuario) {
        return this.usuarios.remove(usuario);
      }
    };
    window.usuariosViewModel = usuariosViewModel;
    ko.applyBindings(usuariosViewModel, $('#usuarios_itens')[0]);
    $combo = $("#UsuariosCombo");
    $divCombo = $combo.closest('[data-url]');
    return $combo.autocompleter($divCombo.data('url'), {
      elementToClick: "#UsuariosComboBtn",
      multiSelectArray: usuariosViewModel.usuarios,
      multiSelectElement: "#usuarios_itens",
      keyName: "idsUsuarios",
      abrirParaCima: true,
      multiSelectDescriptionName: "Nome"
    });
  };

  solicitacoesDeLicenciamentoController.prototype.camposData = function() {
    $("#DataInicioImplantacao").datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true
    });
    return $("#DataInicioOperacao").datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true
    });
  };

  solicitacoesDeLicenciamentoController.prototype.carregarTela = function() {
    $("li", $("#lnkSolicitacoes").parents("ul")).removeClass("active");
    $("#lnkSolicitacoes").parent().addClass("active");
    this.comboEnderecos();
    if (this.opcoes.onegreenSimplificado === 'False') {
      this.comboLegislacoesAmbientais();
      this.comboTipoDeEmpreendimento();
      this.comboAtividades();
      this.camposDependentesLegislacao();
      this.camposDependentesTipologia();
    }
    this.camposData();
    this.comboDNPMs();
    this.comboUsuarios();
    $("body").scrollTop(0);
    $("#DescricaoOutrasAtividades, #CoordenadasPracasDeSondagem").TextAreaExpander(28);
    $("footer").removeClass("footerPS");
    $('#AgregadorDaSolicitacao', "#solicitacao-container").val($("#idDoAgregador", "#solicitacao-container").val());
  };

  solicitacoesDeLicenciamentoController.prototype.cancelarSolicitacao = function() {
    return window.CallbackDaExecucaoDoFluxo = null;
  };

  return solicitacoesDeLicenciamentoController;

})(window.baseController);
