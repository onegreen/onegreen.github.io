﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.filtroAvancadoDeAgendamentosController = (function() {
  filtroAvancadoDeAgendamentosController.origem;

  function filtroAvancadoDeAgendamentosController(opcoes1, recursos) {
    this.opcoes = opcoes1;
    this.recursos = recursos;
    this.carregarFiltroAvancado = bind(this.carregarFiltroAvancado, this);
    this.alterarCores = bind(this.alterarCores, this);
    this.alterarTipoDaAgenda = bind(this.alterarTipoDaAgenda, this);
    this.setarFiltroPadrao = bind(this.setarFiltroPadrao, this);
    this.loadComboTags = bind(this.loadComboTags, this);
    this.loadComboUnidadeGerencial = bind(this.loadComboUnidadeGerencial, this);
    this.loadBuscaTextual = bind(this.loadBuscaTextual, this);
    this.bindsDaListagem = bind(this.bindsDaListagem, this);
    this.binds = bind(this.binds, this);
    this.contexto = "#containerFiltroAvancadoAgendamento";
    this.binds();
    this.loadComboUnidadeGerencial();
    this.loadComboTags();
    this.loadBuscaTextual();
  }

  filtroAvancadoDeAgendamentosController.prototype.binds = function() {
    $("#btnLimpar", this.contexto).unbind('click').click(this.setarFiltroPadrao);
    $("#fecharFiltroAvancado", this.contexto).unbind('click').click((function(_this) {
      return function() {
        $('#BuscaTextual').val('');
        return _this.fecharFiltro();
      };
    })(this));
    $("#menuFiltroAvancado").unbind('click').click(function() {
      var func;
      $("#containerFiltroAvancadoAgendamento").closest('li').addClass("open");
      func = (function(_this) {
        return function() {
          return $('#BuscaTextual').focus();
        };
      })(this);
      return setTimeout(func, 200);
    });
    $('.js-toggle-busca').unbind('click').click(function() {
      return $('.js-busca').toggleClass('none');
    });
    $('#filtro-tipo-agenda', this.contexto).find('input').unbind('change').change((function(_this) {
      return function() {
        return $('#filtro-ug', _this.contexto).toggleClass('none', $( this ).val() === 'MinhaAgenda');
      };
    })(this));
    return this.bindsDaListagem();
  };

  filtroAvancadoDeAgendamentosController.prototype.fecharFiltro = function() {
    return $("#containerFiltroAvancadoAgendamento").closest('li').removeClass("open");
  };

  filtroAvancadoDeAgendamentosController.prototype.bindsDaListagem = function() {
    $('.js-tipoDaAgenda').unbind('click').click(this.alterarTipoDaAgenda);
    return $('.js-cor-reuniao').unbind('change').change(this.alterarCores);
  };

  filtroAvancadoDeAgendamentosController.prototype.loadBuscaTextual = function() {
    var opcoes;
    opcoes = {
      loadOnDemand: true,
      elementToClick: "#BuscaTextualBtn",
      keyElement: "#UrlBusca",
      dataType: "html",
      setInputTextValue: false,
      selectOnTypeArrow: false,
      container: 'body',
      onSelected: (function(_this) {
        return function(input) {
          _this.fecharFiltro();
          $('ul.autocomplete').hide();
          if (input.val().length) {
            return $('#main').load(input.val());
          } else {
            return $as.Agenda.Agendamentos.BuscaTextualVerTodas.get({
              termo: $('#BuscaTextual').val()
            }).done(function(data) {
              return $('#main').html(data);
            });
          }
        };
      })(this)
    };
    return $('#BuscaTextual').autocompleter($as.Agenda.Agendamentos.BuscaTextual.url, opcoes);
  };

  filtroAvancadoDeAgendamentosController.prototype.loadComboUnidadeGerencial = function() {
    var opcoes;
    opcoes = {
      contextId: this.contexto,
      elementId: "#UnidadeGerencialNome",
      container: 'body',
      defaultOption: {
        Key: "-1",
        Value: this.recursos.Todas
      }
    };
    return setComboJSON(opcoes);
  };

  filtroAvancadoDeAgendamentosController.prototype.loadComboTags = function() {
    var opcoes, parametros;
    parametros = {
      tipoDoObjeto: 'PortalSIM.Domain.Agenda.Agendamento'
    };
    opcoes = {
      contextId: this.contexto,
      elementId: "#NomeDaTag",
      container: 'body',
      parameters: parametros,
      defaultOption: {
        Key: "0",
        Value: this.recursos.Todas
      }
    };
    return setComboJSON(opcoes);
  };

  filtroAvancadoDeAgendamentosController.prototype.setarFiltroPadrao = function() {
    return $as.Agenda.FiltroDeAgendamentos.LimparFiltro.get().success(function(filtro) {
      $("#containerFiltroAvancadoAgendamento").html(filtro);
      $("#containerFiltroAvancadoAgendamento").closest("li.dropdown").addClass("open");
      return $('.js-busca').toggleClass('none');
    });
  };

  filtroAvancadoDeAgendamentosController.prototype.alterarTipoDaAgenda = function(e) {
    var tipoDaAgenda;
    tipoDaAgenda = $(e.currentTarget).data('tipo');
    this.fecharFiltro();
    return $as.Agenda.FiltroDeAgendamentos.AlterarTipoDaAgenda.post({
      tipoDaAgenda: tipoDaAgenda
    }).done((function(_this) {
      return function(data) {
        if (data.success) {
          return $as.Agenda.Agendamentos.Index.get().done(function(data) {
            $('#main').html(data);
            _this.carregarFiltroAvancado();
            return _this.binds();
          });
        }
      };
    })(this));
  };

  filtroAvancadoDeAgendamentosController.prototype.alterarCores = function(e) {
    var enviar;
    this.fecharFiltro();
    enviar = (function(_this) {
      return function() {
        var cores;
        cores = $('.js-cor-reuniao:checked').serialize();
        return $as.Agenda.FiltroDeAgendamentos.AlterarCores.post(cores).done(function(data) {
          if (data.success) {
            return $as.Agenda.Agendamentos.Index.get().done(function(data) {
              $('#main').html(data);
              return _this.bindsDaListagem();
            });
          }
        });
      };
    })(this);
    if (this.timeOut) {
      clearTimeout(this.timeOut);
    }
    return this.timeOut = setTimeout(enviar, 800);
  };

  filtroAvancadoDeAgendamentosController.prototype.carregarFiltroAvancado = function() {
    return $as.Agenda.FiltroDeAgendamentos.Index.get().done((function(_this) {
      return function(data) {
        return $("#containerFiltroAvancadoAgendamento").html(data);
      };
    })(this));
  };

  return filtroAvancadoDeAgendamentosController;

})();
