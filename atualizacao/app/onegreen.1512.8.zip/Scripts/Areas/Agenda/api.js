﻿window.Agenda || (window.Agenda = {});

Agenda.api = (function() {
  function api() {}

  api.iniciarAgendamento = function(id, acaoFeitaDaListagem) {
    return $as.Agenda.Agendamentos.Iniciar.get({
      id: id,
      AcaoFeitaDaListagem: acaoFeitaDaListagem
    }).done(function(data) {
      return window.GetDiv('iniciaragendamento-modal-container').html(data);
    });
  };

  api.finalizarAgendamento = function(id, acaoFeitaDaListagem) {
    return $as.Agenda.Agendamentos.Finalizar.get({
      id: id,
      AcaoFeitaDaListagem: acaoFeitaDaListagem
    }).done(function(data) {
      return window.GetDiv('finalizaragendamento-modal-container').html(data);
    });
  };

  api.listar = function() {
    return $as.Agenda.Agendamentos.Index.get().done(function(data) {
      $('#main').html(data);
      if (window.FiltroAvancadoDeAgendamentosController) {
        return window.FiltroAvancadoDeAgendamentosController.bindsDaListagem();
      }
    });
  };

  return api;

})();
