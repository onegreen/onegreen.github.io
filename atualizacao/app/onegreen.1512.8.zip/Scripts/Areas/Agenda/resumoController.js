﻿this.Agenda || (this.Agenda = {});

window.Agenda.resumoController = (function() {
  function resumoController(container, filtro) {
    this.container = container;
    this.filtro = filtro;
    $(this.container).data("controller", this);
  }

  resumoController.carregarGrafico = function(resources) {
    $(".showGrafico", "#tableTarefa").click(function() {
      var categories, options, series;
      options = $(this).data("options");
      categories = [resources.Planejadas, resources.EmExecucao, resources.Finalizada];
      series = [
        {
          name: resources.NoPrazo,
          data: [
            {
              y: options.planejadas.noPrazo
            }, {
              y: options.emExecucao.noPrazo
            }, {
              y: options.finalizada.noPrazo
            }
          ],
          color: "#7cbc29",
          type: "column",
          yAxis: 1
        }, {
          name: resources.Atrasada,
          color: "#e31b23",
          data: [
            {
              y: options.planejadas.atrasadas
            }, {
              y: options.emExecucao.atrasadas
            }, {
              y: options.finalizada.atrasadas
            }
          ],
          type: "column",
          yAxis: 1
        }
      ];
      window.Agenda.resumoController.criarHighcharts(options, categories, series, "#modalPercentual", "percent", "%");
      window.Agenda.resumoController.criarHighcharts(options, categories, series, "#modalQuantidade", "column", "Quantidade");
      return $("#modalGraficos").window({
        width: 650
      });
    });
    return $("input[name=\"rdoTipoGrafico\"]", "#modalGraficos").change(function() {
      return $(".modalGraficosTarefa").toggle(1000);
    });
  };

  resumoController.criarHighcharts = function(options, categories, series, idModal, stacking, resorce) {
    var config;
    config = ModelosDeGrafico.api.getConfig({
      categories: categories,
      showGriX: 1,
      showGriY: 1,
      nomeEixoY1: '',
      nomeEixoY2: '',
      titulo: options.titulo,
      bgColor: 'default',
      unit: '',
      stacking: stacking,
      type: 'column',
      legendaAbaixo: ''
    });
    return ModelosDeGrafico.api.build(idModal, config, series);
  };

  return resumoController;

})();
