﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.agendaController = (function(superClass) {
  extend(agendaController, superClass);

  function agendaController(view, options, resource) {
    this.view = view;
    this.options = options;
    this.resource = resource;
    this.VerificaLimiteExcedido = bind(this.VerificaLimiteExcedido, this);
    this.NotificarAtaAprovada = bind(this.NotificarAtaAprovada, this);
    this.VerificarPendenciaDeAprovacao = bind(this.VerificarPendenciaDeAprovacao, this);
    this.SolicitarAprovacaoAosPresentes = bind(this.SolicitarAprovacaoAosPresentes, this);
    this.EnviarAtaAosPresentes = bind(this.EnviarAtaAosPresentes, this);
    this.NaoEnviarAAta = bind(this.NaoEnviarAAta, this);
    this.VerificarNecessidadeDeEnvio = bind(this.VerificarNecessidadeDeEnvio, this);
    this.VerificarNecessidadeDeConvocacao = bind(this.VerificarNecessidadeDeConvocacao, this);
    this.AlterarStatusDoConvite = bind(this.AlterarStatusDoConvite, this);
    this.VerificarConvite = bind(this.VerificarConvite, this);
    this.VerificarNotificacoes = bind(this.VerificarNotificacoes, this);
    this.convocarPendentes = bind(this.convocarPendentes, this);
    this.convocarTodos = bind(this.convocarTodos, this);
    this.salvarAgendamento = bind(this.salvarAgendamento, this);
    this.BindAlteracoesASeremSalvas = bind(this.BindAlteracoesASeremSalvas, this);
    this.RetornarDataFimPrevisto = bind(this.RetornarDataFimPrevisto, this);
    this.RecarregarPagina = bind(this.RecarregarPagina, this);
    this.ConfigurarAncorasNoMenu = bind(this.ConfigurarAncorasNoMenu, this);
    this.DesabilitarCampos = bind(this.DesabilitarCampos, this);
    this.fechar = bind(this.fechar, this);
    this.setDayWeek = bind(this.setDayWeek, this);
    this.setObservacao = bind(this.setObservacao, this);
    this.ConfiguraCampos = bind(this.ConfiguraCampos, this);
    this.bindActions = bind(this.bindActions, this);
    agendaController.__super__.constructor.call(this, this.view, null);
    this.currentNoty = null;
    this.contexto = "#container-agenda";
    this.enviarConvocacao = true;
    this.mensagemConvocaoSendoExibida = false;
    this.DesabilitarCampos();
    this.ConfigurarAncorasNoMenu();
    this.BindAlteracoesASeremSalvas();
    this.ConfiguraCampos();
    this.VerificarNotificacoes();
    this.VerificaLimiteExcedido();
    if (this.options.AbrirComentarios) {
      setTimeout($('#lnkComentarios').click(), 200);
    }
  }

  agendaController.prototype.bindActions = function() {
    $("#btnIniciar", "#agenda-cabecalho").click(this.iniciarAgendamento);
    $("#btnFinalizar", "#agenda-cabecalho").click(this.finalizarAgendamento);
    return $("#btnCancelar", "#agenda-cabecalho").click(this.cancelarAgendamento);
  };

  agendaController.prototype.ConfiguraCampos = function() {
    $(document).scrollTop(0);
    (this.get('input')).placeholder;
    (this.get('[rel=tooltip]')).tooltip;
    (this.get('[rel=popover]')).popover;
    (this.get('#DataInicioPrevista_Date')).datepicker({
      todayBtn: 'linked',
      autoclose: true,
      todayHighlight: true
    });
    (this.get('#DataInicioPrevista_Date')).on('changeDate', this.setDayWeek);
    (this.get('#ObservacaoFake')).change(this.setObservacao);
    (this.get('#ObservacaoFake')).TextAreaExpander(40);
    if (this.options.ECorporativo && this.options.PodeRealizarQualquerAcao) {
      setCombo(this.contexto, '#UnidadeGerencial_SiglaAtual', this.salvarAgendamento);
    }
    if (this.options.PodeRealizarQualquerAcao) {
      return (this.get('#Descricao')).focus();
    }
  };

  agendaController.prototype.setObservacao = function() {
    (this.get('#Observacao')).val((this.get('#ObservacaoFake')).val());
    return this.salvarAgendamento();
  };

  agendaController.prototype.setDayWeek = function(e) {
    var diaAtual;
    diaAtual = e.date.getDay();
    if (diaAtual === 6) {
      return (this.get('#descDiaSemana')).text(Globalize.culture($('html').attr('lang')).calendar.days.names[0]);
    } else {
      return (this.get('#descDiaSemana')).text(Globalize.culture($('html').attr('lang')).calendar.days.names[diaAtual + 1]);
    }
  };

  agendaController.prototype.fechar = function() {
    if (this.currentNoty) {
      this.currentNoty.close();
    }
    if (typeof FecharAgendamentoERetornar !== "undefined" && FecharAgendamentoERetornar !== null) {
      return FecharAgendamentoERetornar();
    } else {
      return Agenda.api.listar();
    }
  };

  agendaController.prototype.DesabilitarCampos = function() {
    if (!this.options.PodeRealizarQualquerAcao) {
      (this.get('input:not(#tarefas-container input):not(.addTag):not(#novoParticipante-container input)')).prop('disabled', true);
      (this.get('textarea:not(#tarefas-container input)')).prop('disabled', true);
      (this.get('#Observacao')).prop('disabled', true);
      (this.get('#Confidencial-Sim')).parent().parent().addClass('cursor-not-allowed');
      return (this.get('#Confidencial-Nao')).parent().parent().addClass('cursor-not-allowed');
    }
  };

  agendaController.prototype.ConfigurarAncorasNoMenu = function() {
    return (this.get('#ulMenuOpcoes li a:not(.notOpcao)')).click(function() {
      var ancora, offsetTarget;
      ancora = $(this);
      offsetTarget = $(ancora.attr('href')).offset();
      if (offsetTarget) {
        $('html, body').animate({
          scrollTop: offsetTarget.top - 140
        }, 1000);
        $('#ulMenuOpcoes li').removeClass("active");
        return ancora.parent().addClass("active");
      }
    });
  };

  agendaController.prototype.RecarregarPagina = function() {
    return $as.Agenda.Agendamentos.Edit.get({
      id: this.options.Id
    }).done((function(_this) {
      return function(data) {
        return $("#main").html(data);
      };
    })(this));
  };

  agendaController.prototype.RetornarDataFimPrevisto = function() {
    var dataIni, datainicioPrevisto, horaIni;
    dataIni = (this.get('#DataInicioPrevista_Date')).val();
    horaIni = (this.get('#DataInicioPrevista')).val();
    if (dataIni.length >= 5 && horaIni.length >= 5) {
      datainicioPrevisto = dataIni + ' ' + horaIni;
      return $as.Agenda.Agendamentos.RetornarDataFimPrevisto.get({
        datainicioPrevisto: datainicioPrevisto
      }).done((function(_this) {
        return function(retn) {
          (_this.get('#DataTerminoPrevista_Date')).val(retn.data);
          (_this.get('#DataTerminoPrevista')).val(retn.hora);
          return _this.salvarAgendamento();
        };
      })(this));
    } else {
      return this.salvarAgendamento();
    }
  };

  agendaController.prototype.BindAlteracoesASeremSalvas = function() {
    return $('input:not(.js-combo):not(.addTag)', '#formAgendamento').change(this.salvarAgendamento);
  };

  agendaController.prototype.salvarAgendamento = function() {
    if (this.options.PodeRealizarQualquerAcao) {
      return $as.Agenda.Agendamentos.Edit.post((this.get('#formAgendamento')).serialize()).done((function(_this) {
        return function(data) {
          if (data && $(data).filter('div').length) {
            (_this.get('#dvErros')).html(data);
            return IndicadorDeErro.adicionarErroNosCampos($('li', data));
          } else {
            (_this.get('#dvErros')).empty();
            return IndicadorDeErro.removerErroDosCampos();
          }
        };
      })(this));
    }
  };

  agendaController.prototype.convocarTodos = function() {
    $('.selecionado', '#EnviarParaOsPendentes').removeClass('selecionado');
    $(".box-lista-usuario").click();
    $("#EnviarConvitesParaSelecionados").click();
    return $(".box-lista-usuario").click();
  };

  agendaController.prototype.convocarPendentes = function() {
    $('.selecionado', '#EnviarParaOsPendentes').removeClass('selecionado');
    $(".convite-pendente").click();
    $("#EnviarConvitesParaSelecionados").click();
    return $(".convite-pendente").click();
  };

  agendaController.prototype.VerificarNotificacoes = function() {
    if (this.options.StatusAgendada) {
      this.VerificarConvite();
      return this.VerificarNecessidadeDeConvocacao();
    } else {
      if (this.options.StatusFinalizada) {
        this.VerificarNecessidadeDeEnvio();
      }
      return this.VerificarPendenciaDeAprovacao();
    }
  };

  agendaController.prototype.VerificarConvite = function() {
    return $as.Agenda.Participantes.ObterIdParaAlterarStatusDoConvite.get({
      idDoAgendamento: this.options.Id,
      idDoUsuario: this.options.IdUsuarioAtual
    }).done((function(_this) {
      return function(idp) {
        var btns;
        if (idp > 0) {
          btns = [
            {
              addClass: 'btn btn-primary',
              text: _this.resource.Confirmar,
              onClick: function($noty) {
                $noty.close();
                return _this.AlterarStatusDoConvite(idp, 'ConviteAceito');
              }
            }, {
              addClass: 'btn btn-default',
              text: _this.resource.Recusar,
              onClick: function($noty) {
                $noty.close();
                return _this.AlterarStatusDoConvite(idp, 'ConviteRecusado');
              }
            }
          ];
          return _this.currentNoty = showBottomNoty(_this.resource.VoceAindaNaoConfirmouSuaPresencaParaEstaReuniao, 15000, btns);
        }
      };
    })(this));
  };

  agendaController.prototype.AlterarStatusDoConvite = function(idDoParticipante, status) {
    return $as.Agenda.Participantes.AlterarStatusDoConvite.get({
      idDoParticipante: idDoParticipante,
      status: status
    }).done((function(_this) {
      return function(msg) {
        _this.currentNoty = showBottomNoty(msg, 4000, null);
        return window.participantesController.ReloadParticipantes();
      };
    })(this));
  };

  agendaController.prototype.VerificarNecessidadeDeConvocacao = function() {
    if (!this.enviarConvocacao || this.mensagemConvocaoSendoExibida) {
      return;
    }
    if (this.options.CriadaPeloUsuarioAtual) {
      return $as.Agenda.Agendamentos.ExisteNecessidadeDeConvocacao.get({
        id: this.options.Id
      }).done((function(_this) {
        return function(response) {
          var btns;
          if (response.existeNecessidadeDeConvocacao) {
            btns = [
              {
                addClass: 'btn btn-primary',
                text: _this.resource.EnviarParaTodos,
                onClick: function($noty) {
                  $noty.close();
                  _this.convocarTodos();
                  return _this.mensagemConvocaoSendoExibida = false;
                }
              }, {
                addClass: 'btn btn-default',
                text: _this.resource.EnviarParaOsPendentes,
                onClick: function($noty) {
                  $noty.close();
                  _this.convocarPendentes();
                  return _this.mensagemConvocaoSendoExibida = false;
                }
              }, {
                addClass: 'btn btn-default',
                text: _this.resource.AgoraNao,
                onClick: function($noty) {
                  $noty.close();
                  _this.enviarConvocacao = false;
                  return _this.mensagemConvocaoSendoExibida = false;
                }
              }
            ];
            _this.mensagemConvocaoSendoExibida = true;
            return _this.currentNoty = showBottomNoty(_this.resource.DesejaEnviarAConvocacaoPorEmailAosParticipantes, 15000, btns);
          }
        };
      })(this));
    }
  };

  agendaController.prototype.VerificarNecessidadeDeEnvio = function() {
    var btns;
    if (this.options.PodeRealizarQualquerAcao && this.options.NecessarioEnviarAta) {
      btns = [
        {
          addClass: 'btn btn-primary',
          text: this.resource.Sim,
          onClick: (function(_this) {
            return function($noty) {
              $noty.close();
              return _this.EnviarAtaAosPresentes();
            };
          })(this)
        }, {
          addClass: 'btn btn-default',
          text: this.resource.SimComAprovacao,
          onClick: (function(_this) {
            return function($noty) {
              $noty.close();
              return _this.SolicitarAprovacaoAosPresentes();
            };
          })(this)
        }, {
          addClass: 'btn btn-default',
          text: this.resource.Nao,
          onClick: (function(_this) {
            return function($noty) {
              $noty.close();
              return _this.NaoEnviarAAta();
            };
          })(this)
        }
      ];
      return this.currentNoty = showBottomNoty(this.resource.DesejaEnviarAAtaAosPresentes, 15000, btns);
    }
  };

  agendaController.prototype.NaoEnviarAAta = function() {
    return $as.Agenda.Agendamentos.NaoEnviarAta.get({
      idDoAgendamento: this.options.Id
    }).done((function(_this) {
      return function(msg) {
        return _this.currentNoty = showBottomNoty(msg, 4000, null);
      };
    })(this));
  };

  agendaController.prototype.EnviarAtaAosPresentes = function() {
    return $as.Agenda.Agendamentos.EnviarAtaAosPresentes.get({
      idDoAgendamento: this.options.Id
    }).done((function(_this) {
      return function(msg) {
        return _this.currentNoty = showBottomNoty(msg, 4000, null);
      };
    })(this));
  };

  agendaController.prototype.SolicitarAprovacaoAosPresentes = function() {
    return $as.Agenda.Agendamentos.SolicitarAprovacaoAosPresentes.get({
      idDoAgendamento: this.options.Id
    }).done((function(_this) {
      return function(msg) {
        return _this.currentNoty = showBottomNoty(msg, 4000, null);
      };
    })(this));
  };

  agendaController.prototype.VerificarPendenciaDeAprovacao = function() {
    if (this.options.NecessarioEnviarAta) {
      return;
    }
    return $as.Agenda.Agendamentos.ExistePendenciaDeAprovacao.get({
      id: this.options.Id
    }).done((function(_this) {
      return function(response) {
        var btns;
        if (response.existePendencia) {
          btns = [
            {
              addClass: 'btn btn-primary',
              text: _this.resource.AprovarAta,
              onClick: function($noty) {
                $noty.close();
                return $as.Agenda.Agendamentos.Avaliar.get({
                  idDoParticipante: response.idDoParticipante,
                  aprovado: true
                }).done(function(data) {
                  return $('#avaliar-ata-container').html(data);
                });
              }
            }, {
              addClass: 'btn btn-default',
              text: _this.resource.ReprovarAta,
              onClick: function($noty) {
                $noty.close();
                return $as.Agenda.Agendamentos.Avaliar.get({
                  idDoParticipante: response.idDoParticipante,
                  aprovado: false
                }).done(function(data) {
                  return $('#avaliar-ata-container').html(data);
                });
              }
            }
          ];
          return _this.currentNoty = showBottomNoty(_this.resource.AAvaliacaoDestaAtaAindaEstaPendente, 15000, btns);
        }
      };
    })(this));
  };

  agendaController.prototype.NotificarAtaAprovada = function(msg) {
    this.currentNoty = showBottomNoty(msg, 4000);
    return window.participantesController.ReloadParticipantes();
  };

  agendaController.prototype.VerificaLimiteExcedido = function() {
    if (this.options.LimiteDeReunioesExcedidoNoMes && this.options.LimiteDeReunioesExcedidoNoMes !== '') {
      return this.currentNoty = showBottomNoty(this.options.LimiteDeReunioesExcedidoNoMes);
    }
  };

  return agendaController;

})(window.baseController);
