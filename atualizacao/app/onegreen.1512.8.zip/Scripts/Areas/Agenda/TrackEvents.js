﻿this.Events || (this.Events = {});

$(function() {
  return Events.Track.BindActions();
});

Events.Track = (function() {
  function Track() {}

  Track.NotifyEvent = function(category, type, item, value) {
    return setTimeout(function() {
      if (window._gaq != null) {
        return window._gaq.push(['_trackEvent', category, type, item, value]);
      }
    }, 5);
  };

  Track.BindEvent = function(selector, category, type, item) {
    return $('body').on('click', selector, function() {
      return Track.NotifyEvent(category, type, item);
    });
  };

  Track.BindActions = function() {
    Track.BindEvent('#EntrarNaConta', 'Site', 'Modal', 'Entrar do Topo');
    Track.BindEvent('#BotaoCadastrarNovaConta', 'Site', 'Modal', 'Acesse nossa vers�o gratuita');
    Track.BindEvent('#esqueciASenha', 'Site', 'Modal', 'Esqueci a Senha');
    Track.BindEvent('#EntrarPeloSite', 'Site', 'Form', 'Login');
    Track.BindEvent('#btnCadastrar', 'Site', 'Form', 'Cadastrar');
    Track.BindEvent('#facebookModal', 'Site', 'Form', 'Facebook Modal');
    Track.BindEvent('#googleModal', 'Site', 'Form', 'Google Modal');
    Track.BindEvent('#linkedinModal', 'Site', 'Form', 'Linkedin Modal');
    Track.BindEvent('#facebookTopo', 'Site', 'Form', 'Facebook Topo');
    Track.BindEvent('#googleTopo', 'Site', 'Form', 'Google Topo');
    Track.BindEvent('#linkedinTopo', 'Site', 'Form', 'Linkedin Topo');
    Track.BindEvent('#lnkAgenda', 'Topo', 'Page', 'Agenda');
    Track.BindEvent('#lnkMeuPainel', 'Topo', 'Page', 'Meu Painel');
    Track.BindEvent('#lnkFeedBack', 'Topo', 'Modal', 'Feedback');
    Track.BindEvent('#infoMeuUsuario', 'Topo', 'Popover', 'Meu Usu�rio');
    Track.BindEvent('#icoManutencao', 'Topo', 'Manutencao', 'Engrenagem');
    Track.BindEvent('#tipoAgendamentoManutencao', 'Topo', 'Manutencao', 'Tipo de Agendamento');
    Track.BindEvent('#redefinirSenha', 'Topo', 'Meu Usu�rio', 'Alterar Senha');
    Track.BindEvent('#editarPerfil', 'Topo', 'Meu Usu�rio', 'Editar Perfil');
    Track.BindEvent('#lnkLogoff', 'Topo', 'Meu Usu�rio', 'Sair');
    Track.BindEvent('#Criar-Agendamento', 'Listagem', 'Adicionar', 'Principal');
    Track.BindEvent('#CriarAgendamentoHoje', 'Listagem', 'Adicionar', 'Hoje');
    Track.BindEvent('.AddPorTipo', 'Listagem', 'Adicionar', 'Por tipo');
    Track.BindEvent('#avancarMes', 'Listagem', 'Calend�rio', 'Avan�ar M�s');
    Track.BindEvent('#retrocederMes', 'Listagem', 'Calend�rio', 'Retroceder M�s');
    Track.BindEvent('.EditAgendamento', 'Listagem', 'Editar', 'Agendamento');
    Track.BindEvent('#TarefasEmAtraso', 'MeuPainel', 'accordion', 'Tarefas em atraso');
    Track.BindEvent('#TarefasEmAndamento', 'MeuPainel', 'accordion', 'Tarefas Em Execu��o');
    Track.BindEvent('#MostrarMais15Dias', 'MeuPainel', 'Desdobrar', 'Mais 15 dias');
    Track.BindEvent('.filtroMeuPainel', 'MeuPainel', 'Filtro', 'Responsabilidade');
    Track.BindEvent('#exportarIcs', 'CreateEdit', 'Exportar', 'ics');
    Track.BindEvent('#btnPendenciasDaReuniaoAnterior', 'CreateEdit', 'Lateral', 'Ver pnd�ncias anteriores');
    Track.BindEvent('#btnCancelar', 'CreateEdit', 'Lateral', 'Cancelar Agendamento');
    Track.BindEvent('.visualizarTarefasDoAssunto', 'CreateEdit', 'Assunto', 'Visualizar Tarefas (check)');
    Track.BindEvent('.adicionarTarefasDoAssunto', 'CreateEdit', 'Assunto', 'Adicionar Tarefas (+)');
    Track.BindEvent('#btnFechar', 'CreateEdit', 'Topo', 'Voltar');
    return Track.BindEvent('.js-AdicionarTarefaSimples', 'CreateEdit', 'Tarefas', 'Adicionar');
  };

  return Track;

})();
