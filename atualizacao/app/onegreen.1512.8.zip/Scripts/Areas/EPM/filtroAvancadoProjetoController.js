﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.FiltroAvancadoProjetoController = (function() {
  function FiltroAvancadoProjetoController(opcoes, recursos) {
    this.opcoes = opcoes;
    this.recursos = recursos;
    this.loadComboFiltroAvancado = bind(this.loadComboFiltroAvancado, this);
    this.loadComboFasesDoProjeto = bind(this.loadComboFasesDoProjeto, this);
    this.loadComboOrigem = bind(this.loadComboOrigem, this);
    this.loadComboUnidadeGerencial = bind(this.loadComboUnidadeGerencial, this);
    this.carregarFiltroAvancado = bind(this.carregarFiltroAvancado, this);
    this.configurarScroll = bind(this.configurarScroll, this);
    this.excluirFiltro = bind(this.excluirFiltro, this);
    this.salvarFiltro = bind(this.salvarFiltro, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.contexto = "#containerFiltroAvancado";
    this.configurarBinds();
    this.configurarExibirFiltro();
    this.loadComboUnidadeGerencial();
    this.loadComboOrigem();
    this.loadComboFasesDoProjeto();
    this.loadComboFiltroAvancado();
    $("#fecharFiltroAvancado").bind('click', (function(_this) {
      return function(e) {
        return $(_this.contexto).toggle();
      };
    })(this));
  }

  FiltroAvancadoProjetoController.prototype.configurarBinds = function() {
    $('#btnSalvarFiltro').bind('click', (function(_this) {
      return function(e) {
        return _this.salvarFiltro();
      };
    })(this));
    return $('#btnExcluirFiltro').bind('click', (function(_this) {
      return function(e) {
        return $("#excluir-filtro-confirm").modal("show");
      };
    })(this));
  };

  FiltroAvancadoProjetoController.prototype.salvarFiltro = function() {
    return $as.EPM.Projetos.CreateEditBuscaAvancada.post($("form#form-filtro-avancado").serialize()).success((function(_this) {
      return function(data) {
        return window.GetDiv("buscaAvancada-modal-container").html(data);
      };
    })(this));
  };

  FiltroAvancadoProjetoController.prototype.excluirFiltro = function() {
    return $as.EPM.Projetos.ExcluirFiltro.get({
      id: $("#IdFiltroAvancado").val()
    }).success((function(_this) {
      return function(data) {
        $("#form-filtro-avancado").parent().html(data);
        _this.configurarExibirFiltro();
        return $("#filtro-aplicado").click();
      };
    })(this));
  };

  FiltroAvancadoProjetoController.prototype.configurarScroll = function() {
    return $("#divScroll-filtro-avancado").slimScroll({
      railVisible: true,
      height: "auto",
      wheelStep: 1,
      allowPageScroll: true
    });
  };

  FiltroAvancadoProjetoController.prototype.configurarExibirFiltro = function() {
    return $("#filtro-aplicado, #btnFiltroAvancado").on('click', (function(_this) {
      return function(e) {
        return $(_this.contexto).toggle();
      };
    })(this));
  };

  FiltroAvancadoProjetoController.prototype.carregarFiltroAvancado = function(idFiltro) {
    return $as.EPM.Projetos.CarregarFiltroAvancado.get({
      id: idFiltro
    }).success((function(_this) {
      return function(data) {
        $("#form-filtro-avancado").parent().html(data);
        _this.configurarExibirFiltro();
        return $("#filtro-aplicado").click();
      };
    })(this));
  };

  FiltroAvancadoProjetoController.prototype.loadComboUnidadeGerencial = function() {
    var $combo, $divCombo;
    $combo = $(this.contexto + " #UnidadeGerencialNome");
    $divCombo = $combo.parents("div.autocompleter");
    return $combo.autocompleter($divCombo.attr("data-url"), {
      loadOnDemand: true,
      elementToClick: this.contexto + " #UnidadeGerencialNomeBtn",
      keyElement: this.contexto + " #IdUnidadeGerencial",
      defaultOption: {
        Key: "",
        Value: "(" + this.recursos.Todas + ")"
      },
      onSelected: (function(_this) {
        return function(valueInput) {
          FiltroFarolDeProjeto.IdUnidadeGerencial = $(valueInput).val();
          return FiltroFarolDeProjeto.UnidadeGerencialNome = $(_this.contexto + " #UnidadeGerencialNome").val();
        };
      })(this)
    });
  };

  FiltroAvancadoProjetoController.prototype.loadComboOrigem = function() {
    var $combo, $divCombo, ListaDeOrigensViewModel;
    $.loadTemplate(this.opcoes.TemplateOrigens, 'origensTemplate');
    ListaDeOrigensViewModel = {
      ListaDeOrigens: ko.observableArray(this.opcoes.OrigensSelecionadas),
      removeOrigem: function(origem) {
        return this.origens.remove(origem);
      }
    };
    window.ListaDeOrigensViewModel = ListaDeOrigensViewModel;
    ko.applyBindings(ListaDeOrigensViewModel, $('#origens_itens')[0]);
    $combo = $("#OrigensCombo");
    $divCombo = $combo.parents("div.autocompleter");
    return $combo.autocompleter($divCombo.attr("data-url"), {
      elementToClick: "#OrigensComboBtn",
      multiSelectArray: ListaDeOrigensViewModel.ListaDeOrigens,
      multiSelectElement: "#origens_itens"
    });
  };

  FiltroAvancadoProjetoController.prototype.loadComboFasesDoProjeto = function() {
    var $combo, $divCombo, fasesViewModel;
    $.loadTemplate(this.opcoes.TemplateFases, 'fasesTemplate');
    fasesViewModel = {
      fases: ko.observableArray(this.opcoes.FasesSelecionadas),
      removeFase: function(fase) {
        return this.fases.remove(status);
      }
    };
    window.fasesViewModel = fasesViewModel;
    ko.applyBindings(fasesViewModel, $('#fases_itens')[0]);
    $combo = $("#FaseCombo");
    $divCombo = $combo.parents("div.autocompleter");
    return $combo.autocompleter($divCombo.attr("data-url"), {
      elementToClick: "#FaseComboBtn",
      multiSelectArray: fasesViewModel.fases,
      multiSelectElement: "#fases_itens"
    });
  };

  FiltroAvancadoProjetoController.prototype.loadComboFiltroAvancado = function() {
    var $combo, $divCombo;
    $combo = $("#FiltroAvancadoNome");
    $divCombo = $combo.parents("div.autocompleter");
    return $combo.autocompleter($divCombo.attr("data-url"), {
      loadOnDemand: false,
      elementToClick: "#FiltroAvancadoNomeBtn",
      keyElement: "#IdFiltroAvancado",
      onSelected: (function(_this) {
        return function(valueInput) {
          FiltroFarolDeProjeto.IdFiltroAvancado = $(valueInput).val();
          FiltroFarolDeProjeto.FiltroAvancadoNome = $('#FiltroAvancadoNome').val();
          return _this.carregarFiltroAvancado($(valueInput).val());
        };
      })(this)
    });
  };

  return FiltroAvancadoProjetoController;

})();
