﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.modeloDeImportacaoDeExcelController = (function(superClass) {
  extend(modeloDeImportacaoDeExcelController, superClass);

  function modeloDeImportacaoDeExcelController(contexto, options, resource) {
    this.contexto = contexto;
    this.options = options;
    this.resource = resource;
    this.atualizarLabels = bind(this.atualizarLabels, this);
    this.excluir = bind(this.excluir, this);
    this.excluirModelo = bind(this.excluirModelo, this);
    this.exbirCampoPorTipoDeImportacao = bind(this.exbirCampoPorTipoDeImportacao, this);
    this.verificarQuantidadeDeAbas = bind(this.verificarQuantidadeDeAbas, this);
    this.voltar = bind(this.voltar, this);
    this.proximo = bind(this.proximo, this);
    this.esconderExibirBtnProximoVoltarSalvar = bind(this.esconderExibirBtnProximoVoltarSalvar, this);
    this.obterPassoCorrente = bind(this.obterPassoCorrente, this);
    this.cancelarModalCreateEdit = bind(this.cancelarModalCreateEdit, this);
    this.encerrarModalCreateEdit = bind(this.encerrarModalCreateEdit, this);
    this.esconderLoadCarregamento = bind(this.esconderLoadCarregamento, this);
    $(this.contextoExtracaoDoExcel).hide();
    this.mostrarEsconderArquivo(false);
    $('#BotaoSalvar--0-0', this.contexto).hide();
    this.contextoExtracaoDoExcel = '#importacao-excel-modal';
    this.esconderLoadCarregamento();
    $('#close-modal-createedit-importacao-excel').on('click', this.cancelarModalCreateEdit);
    if ($('.validation-summary-errors', this.contexto).length >= 1) {
      this.proximo();
    }
    if (this.options.Frequencia === 'Diaria') {
      this.configurarDatePickerFarolDiario('DataDosValores');
    } else if (this.options.Frequencia === 'Mensal') {
      this.configurarDatePickerFarolMensal('DataDosValores');
    } else {
      this.configurarDatePickerFarolSemana('DataDosValores');
    }
    this.contextoImportacao = '#importacao-excel-modal';
    this.atualizarLabels();
  }

  modeloDeImportacaoDeExcelController.prototype.esconderLoadCarregamento = function() {
    $('[data-passo="final"]').hide();
    return $('[data-passo="inicial"]').show();
  };

  modeloDeImportacaoDeExcelController.prototype.encerrarModalCreateEdit = function() {
    $(this.contextoExtracaoDoExcel).show();
    return $(this.contexto).hide();
  };

  modeloDeImportacaoDeExcelController.prototype.cancelarModalCreateEdit = function() {
    $(this.contextoExtracaoDoExcel).show();
    if ($('[data-novo].active', this.contextoExtracaoDoExcel).data('novo') === true) {
      $('#btnProximo', this.contextoExtracaoDoExcel).show();
      $('#btnExcluirModelo', this.contexto).hide();
    } else {
      $('#BotaoSalvar--0-0', this.contextoExtracaoDoExcel).show();
      $('#btnEditarModelo', this.contextoExtracaoDoExcel).show();
    }
    $('#BotaoCancelar--0-0', this.contextoExtracaoDoExcel).show();
    $(this.contexto).hide();
    return this.mostrarEsconderArquivo();
  };

  modeloDeImportacaoDeExcelController.prototype.obterPassoCorrente = function() {
    return parseInt($('[data-passo]:visible', this.contexto).data('passo'));
  };

  modeloDeImportacaoDeExcelController.prototype.esconderExibirBtnProximoVoltarSalvar = function() {
    var passo;
    passo = this.obterPassoCorrente();
    if (passo === 2) {
      $('#btnProximo', this.contexto).hide();
      $('#btnVoltar', this.contexto).show();
      $('#BotaoSalvar--0-0', this.contexto).show();
      if ($('[data-novo].active', this.contextoExtracaoDoExcel).data('novo') === false) {
        return $('#btnExcluirModelo', this.contexto).show();
      }
    } else if (passo === 1) {
      $('#btnVoltar', this.contexto).hide();
      $('#btnProximo', this.contexto).show();
      $('#BotaoSalvar--0-0', this.contexto).hide();
      return $('#btnExcluirModelo', this.contexto).hide();
    }
  };

  modeloDeImportacaoDeExcelController.prototype.proximo = function() {
    var passo;
    passo = this.obterPassoCorrente();
    this.avancarOuRetornar($("[data-passo=" + passo + "]"), $("[data-passo=" + (passo + 1) + "]"));
    this.esconderExibirBtnProximoVoltarSalvar();
    return this.exbirCampoPorTipoDeImportacao();
  };

  modeloDeImportacaoDeExcelController.prototype.voltar = function() {
    var passo;
    this.removerValidacao();
    passo = this.obterPassoCorrente();
    this.avancarOuRetornar($("[data-passo=" + passo + "]"), $("[data-passo=" + (passo - 1) + "]"));
    this.esconderExibirBtnProximoVoltarSalvar();
    return this.exbirCampoPorTipoDeImportacao();
  };

  modeloDeImportacaoDeExcelController.prototype.escolherTipoImportacao = function() {
    var tipoImportacao;
    tipoImportacao = $( this ).eq(0).attr('for');
    $('#box-TipoImportacao input', this.contexto).removeAttr('checked');
    return $("#" + tipoImportacao).attr({
      'checked': 'checked'
    });
  };

  modeloDeImportacaoDeExcelController.prototype.verificarQuantidadeDeAbas = function() {
    var NomeDoArquivo;
    NomeDoArquivo = $('#FileName').val();
    return $as.Performance.ExtracoesDoExcel.RetornarQuantidadeDeAbas.get({
      nomeDoArquivo: NomeDoArquivo
    }).done((function(_this) {
      return function(data) {
        var $select, i, selectedValue;
        if (data.length > 1) {
          $select = $('#AbaDaPlanilha');
          selectedValue = $select.val();
          $('#cmpAbaDaPlanilha').show();
          $('#AbaDaPlanilha option', '#cmpAbaDaPlanilha').remove();
          i = 0;
          while (i < data.length) {
            $('<option>').val(i).text(data[i]).appendTo($select);
            i++;
          }
          return $select.val(selectedValue);
        }
      };
    })(this));
  };

  modeloDeImportacaoDeExcelController.prototype.setDropDownColunaDoIndicador = function() {
    return setDropDown(this.contexto, '#ColunaDeImportacaoDoIndicador-dropdown', this.atualizarLabels);
  };

  modeloDeImportacaoDeExcelController.prototype.exbirCampoPorTipoDeImportacao = function() {
    var FormaDeImportacao, passo;
    $('[data-passo="2"] div[id]').hide();
    passo = this.obterPassoCorrente();
    FormaDeImportacao = $('[name=FormaDeImportacao]:checked').val();
    if (passo === 2) {
      this.verificarQuantidadeDeAbas();
      this.setDropDownColunaDoIndicador();
      $('#ColunaDeImportacaoDoIndicador-dropdown').show();
      switch (FormaDeImportacao) {
        case 'DataPorColuna':
          break;
        case 'DataPorLinha':
          return $('#cmpColunaDaData').show();
        case 'SemData':
          return $('#cmpDataDosValores').show();
      }
    }
  };

  modeloDeImportacaoDeExcelController.prototype.excluirModelo = function() {
    this.mostrarEsconderArquivo(false);
    return window.modalConfirm(this.resource.DesejaExcluirEsteRegistro, this.excluir);
  };

  modeloDeImportacaoDeExcelController.prototype.excluir = function() {
    var idModelo;
    idModelo = $('#ModeloDeImportacaoDeExcel_Id').val();
    return $as.Performance.ModeloDeImportacaoDeExcel.DeletarModelo.post({
      id: idModelo
    }).done((function(_this) {
      return function() {
        _this.cancelarModalCreateEdit();
        $('#ModeloDeImportacaoDeExcel_Id', _this.contextoImportacao).val('');
        return $('#ModeloDeImportacaoDeExcel_Nome', _this.contextoImportacao).val('');
      };
    })(this));
  };

  modeloDeImportacaoDeExcelController.prototype.atualizarLabels = function() {
    var tipo;
    tipo = parseInt($('#ColunaDeImportacaoDoIndicador', this.contexto).val());
    if (tipo === 0) {
      return this.atualizarLabelsParaId();
    } else if (tipo === 1) {
      return this.atualizaLabelsParaCodigoDeInterface();
    } else {
      return this.atualizarLabelsParaNome();
    }
  };

  modeloDeImportacaoDeExcelController.prototype.atualizarLabelsParaId = function() {
    $('#labelLinhaInicial', this.contexto).text(this.resource.InformeALinhaOuIdDoPrimeiroIndicador);
    return $('#labelLinhaFinal', this.contexto).text(this.resource.InformeALinhaOuIdDoUltimoIndicador);
  };

  modeloDeImportacaoDeExcelController.prototype.atualizaLabelsParaCodigoDeInterface = function() {
    $('#labelLinhaInicial', this.contexto).text(this.resource.InformeALinhaOuCodigoDaInterfaceDoPrimeiroIndicador);
    return $('#labelLinhaFinal', this.contexto).text(this.resource.InformeALinhaOuCodigoDaInterfaceDoUltimoIndicador);
  };

  modeloDeImportacaoDeExcelController.prototype.atualizarLabelsParaNome = function() {
    $('#labelLinhaInicial', this.contexto).text(this.resource.InformeALinhaOuNomeDoPrimeiroIndicador);
    return $('#labelLinhaFinal', this.contexto).text(this.resource.InformeALinhaOuNomeDoUltimoIndicador);
  };

  return modeloDeImportacaoDeExcelController;

})(window.extracoesDoExcelController);
