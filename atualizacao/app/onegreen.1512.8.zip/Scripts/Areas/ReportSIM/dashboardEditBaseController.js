﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.dashboardEditBaseController = (function(superClass) {
  extend(dashboardEditBaseController, superClass);

  function dashboardEditBaseController(view, modelo) {
    this.view = view;
    this.modelo = modelo;
    this.recarregarSIMPart = bind(this.recarregarSIMPart, this);
    this.getOrdemItens = bind(this.getOrdemItens, this);
    this.postNovaOrdem = bind(this.postNovaOrdem, this);
    this.desmarcarItensComoEditando = bind(this.desmarcarItensComoEditando, this);
    this.marcarItensComoEditando = bind(this.marcarItensComoEditando, this);
    this.configuracoesTelaNota = bind(this.configuracoesTelaNota, this);
    this.mostrarS = bind(this.mostrarS, this);
    this.esconderS = bind(this.esconderS, this);
    this.mostrar = bind(this.mostrar, this);
    this.esconder = bind(this.esconder, this);
    this.complementoTelaDeCriacao = bind(this.complementoTelaDeCriacao, this);
    this.adicionarPaginaDeCriacaoNoContainer = bind(this.adicionarPaginaDeCriacaoNoContainer, this);
    this.alterarModoDeAcesso = bind(this.alterarModoDeAcesso, this);
    this.getItemContainer = bind(this.getItemContainer, this);
    this.trocarTextoMascaras = bind(this.trocarTextoMascaras, this);
    this.cancelarCriacaoDoItem = bind(this.cancelarCriacaoDoItem, this);
    this.toggleConfiguracao = bind(this.toggleConfiguracao, this);
    this.sairDaEdicao = bind(this.sairDaEdicao, this);
    this.entrarEmEdicaoComTexto = bind(this.entrarEmEdicaoComTexto, this);
    this.entrarEmEdicao = bind(this.entrarEmEdicao, this);
    this.mascaraDoItem = bind(this.mascaraDoItem, this);
    this.excluirSIMPart = bind(this.excluirSIMPart, this);
    this.cancelarEdicaoDoItem = bind(this.cancelarEdicaoDoItem, this);
    this.getTelaEdicao = bind(this.getTelaEdicao, this);
    this.getTelaCriacao = bind(this.getTelaCriacao, this);
    this.removerHtmlSimpart = bind(this.removerHtmlSimpart, this);
    this.submeterAlteracao = bind(this.submeterAlteracao, this);
    this.iniciarEdicaoDeItem = bind(this.iniciarEdicaoDeItem, this);
    this.aoSelecionarLugar = bind(this.aoSelecionarLugar, this);
    this.cancelarAoClicarForaDaSelecao = bind(this.cancelarAoClicarForaDaSelecao, this);
    this.adicionar = bind(this.adicionar, this);
    this.ativarEventos = bind(this.ativarEventos, this);
    this.desativarEnventos = bind(this.desativarEnventos, this);
    this.localizarElementos = bind(this.localizarElementos, this);
    this.load = bind(this.load, this);
    dashboardEditBaseController.__super__.constructor.call(this, this.view);
    $('#filtro-ug-topo').hide();
    this.load();
  }

  dashboardEditBaseController.prototype.load = function() {
    this.localizarElementos();
    this.botoesAdicionar.click(this.adicionar);
    return this.ativarEventos();
  };

  dashboardEditBaseController.prototype.localizarElementos = function() {
    this.mascaras = this.get(".js-MascaraInserir");
    this.TextosDeInsercao = this.get(".js-TextoInserirModulo span");
    this.botoesAdicionar = this.get(".js-AdicionarSIMPart");
    this.containerConfiguracao;
    this.containerEdicao;
    return this.contexto = $("#main");
  };

  dashboardEditBaseController.prototype.desativarEnventos = function() {
    this.get(".js-RemoverSIMPart").unbind("click");
    this.get(".js-EditarSIMPart").unbind("click");
    return this.get(".js-AlterarModoDeAcesso input").unbind("click");
  };

  dashboardEditBaseController.prototype.ativarEventos = function() {
    this.desativarEnventos();
    this.get(".js-RemoverSIMPart").unbind('click').click((function(_this) {
      return function(event) {
        return Confirmacao.mostrar(window.Resource.DesejaRealmenteExcluirEsteRegistro, function() {
          return _this.excluirSIMPart(event);
        });
      };
    })(this));
    this.get(".js-EditarSIMPart").unbind('click').click(this.iniciarEdicaoDeItem);
    this.get(".js-AlterarModoDeAcesso input").unbind('click').click(this.alterarModoDeAcesso);
    this.get('.js-ToggleConfiguracao').unbind('click').click(this.toggleConfiguracao);
    return this.get("[title]").tooltip();
  };

  dashboardEditBaseController.prototype.adicionar = function(event) {
    event.stopPropagation();
    this.entrarEmEdicao();
    this.trocarTextoMascaras($(event.delegateTarget).attr("MensagemInsercao"));
    this.nomeSIMPartAdicionando = $(event.delegateTarget).attr("simpart");
    this.mostrar(this.TextosDeInsercao);
    this.mascaras.unbind('click').click(this.aoSelecionarLugar);
    return this.contexto.unbind('click').click(this.cancelarAoClicarForaDaSelecao);
  };

  dashboardEditBaseController.prototype.cancelarAoClicarForaDaSelecao = function() {
    this.sairDaEdicao();
    return this.contexto.unbind('click');
  };

  dashboardEditBaseController.prototype.aoSelecionarLugar = function(event) {
    event.stopPropagation();
    this.mascaras.unbind("click");
    this.contexto.unbind("click");
    this.entrarEmEdicao();
    this.getTelaCriacao(event);
    return this.sairDaEdicao();
  };

  dashboardEditBaseController.prototype.iniciarEdicaoDeItem = function(event) {
    var container, idItem;
    this.entrarEmEdicao();
    container = this.getItemContainer(event);
    idItem = container.attr("idItem");
    return this.getTelaEdicao(idItem, container);
  };

  dashboardEditBaseController.prototype.submeterAlteracao = function() {
    this.sairDaEdicao();
    this.ativarEventos();
    return this.localizarElementos();
  };

  dashboardEditBaseController.prototype.removerHtmlSimpart = function(event) {
    var item;
    item = this.getItemContainer(event);
    item.remove();
    return $(".tooltip").hide();
  };

  dashboardEditBaseController.prototype.getTelaCriacao = function(event) {
    return this.RaizDaRequisicao.CriarItem.get({
      nomeSIMPart: this.nomeSIMPartAdicionando,
      idDoRelatorio: this.modelo.Id
    }).done((function(_this) {
      return function(html) {
        var idDoItem, tela;
        idDoItem = parseFloat($(html).find("#idDoItem").val());
        tela = "<section class='js-ContainerItem' id='Item_" + idDoItem + "' idItem='" + idDoItem + "' style='height:100%'>";
        tela += html;
        tela += '</section>';
        _this.adicionarPaginaDeCriacaoNoContainer(event, tela);
        _this.get(".js-CancelarEdicao").unbind('click').click(idDoItem === 0 ? _this.cancelarCriacaoDoItem : _this.cancelarEdicaoDoItem);
        _this.get(".js-IdDoPai").val(_this.modelo.Id);
        _this.complementoTelaDeCriacao(event);
        if (idDoItem !== 0) {
          return _this.postNovaOrdem();
        }
      };
    })(this));
  };

  dashboardEditBaseController.prototype.getTelaEdicao = function(idItem, container) {
    return this.RaizDaRequisicao.EditarItem.get({
      idItem: idItem
    }).done((function(_this) {
      return function(html) {
        container.html(html);
        return _this.get(".js-CancelarEdicao").unbind('click').click(_this.cancelarEdicaoDoItem);
      };
    })(this));
  };

  dashboardEditBaseController.prototype.cancelarEdicaoDoItem = function(event) {
    var container, idItem;
    container = this.getItemContainer(event);
    idItem = container.attr("idItem");
    return this.RaizDaRequisicao.DisplayItemNaEdicao.get({
      idItem: idItem
    }).done((function(_this) {
      return function(html) {
        container.html(html);
        _this.sairDaEdicao();
        _this.ativarEventos();
        return _this.localizarElementos();
      };
    })(this));
  };

  dashboardEditBaseController.prototype.excluirSIMPart = function(event) {
    var idItem;
    idItem = this.getItemContainer(event).attr("idItem");
    return this.RaizDaRequisicao.ExcluirItem.post({
      idItem: idItem
    }).done((function(_this) {
      return function(html) {
        _this.sairDaEdicao();
        _this.removerHtmlSimpart(event);
        return _this.complementoExcluirSIMPart();
      };
    })(this));
  };

  dashboardEditBaseController.prototype.mascaraDoItem = function(event) {
    return $('.js-MascaraInserir', this.getItemContainer(event));
  };

  dashboardEditBaseController.prototype.entrarEmEdicao = function() {
    var idDoItem;
    this.esconder(this.TextosDeInsercao);
    this.mostrar(this.mascaras);
    this.esconder(this.botoesAdicionar);
    this.esconder(this.get('.js-NaoMostrarEmEdicao'));
    this.get(".js-IdDoPai").val(this.modelo.Id);
    this.marcarItensComoEditando();
    idDoItem = parseFloat(this.get(".js-CancelarEdicao").closest('.js-ContainerItem').attr('iditem'));
    return this.get(".js-CancelarEdicao").unbind('click').click(idDoItem === 0 ? this.cancelarCriacaoDoItem : this.cancelarEdicaoDoItem);
  };

  dashboardEditBaseController.prototype.entrarEmEdicaoComTexto = function() {
    this.entrarEmEdicao();
    this.mostrar(this.TextosDeInsercao);
    return this.marcarItensComoEditando();
  };

  dashboardEditBaseController.prototype.sairDaEdicao = function() {
    if (this.objetoMovimentando) {
      this.mostrar(this.objetoMovimentando);
    }
    this.mostrar(this.get('.js-NaoMostrarNaEdicao'));
    this.esconder(this.TextosDeInsercao);
    this.esconder(this.mascaras);
    this.mostrar(this.botoesAdicionar);
    this.mostrar(this.get('.js-NaoMostrarEmEdicao'));
    this.mascaras.unbind("click");
    return this.desmarcarItensComoEditando();
  };

  dashboardEditBaseController.prototype.toggleConfiguracao = function() {
    this.containerConfiguracao.slideToggle();
    return this.containerEdicao.slideToggle();
  };

  dashboardEditBaseController.prototype.cancelarCriacaoDoItem = function(event) {
    this.removerHtmlSimpart(event);
    return this.sairDaEdicao();
  };

  dashboardEditBaseController.prototype.trocarTextoMascaras = function(texto) {
    return this.TextosDeInsercao.html(texto);
  };

  dashboardEditBaseController.prototype.getItemContainer = function(event) {
    return $(event.delegateTarget).closest(".js-ContainerItem");
  };

  dashboardEditBaseController.prototype.alterarModoDeAcesso = function(event) {
    return this.RaizDaRequisicao.AlterarModoDeAcesso.post({
      id: this.modelo.Id,
      modoDeAcesso: $(event.delegateTarget).val()
    });
  };

  dashboardEditBaseController.prototype.adicionarPaginaDeCriacaoNoContainer = function(event, html) {
    return this.getItemContainer(event).before(html);
  };

  dashboardEditBaseController.prototype.complementoTelaDeCriacao = function(event) {};

  dashboardEditBaseController.prototype.esconder = function(elemento) {
    return elemento.fadeOut();
  };

  dashboardEditBaseController.prototype.mostrar = function(elemento) {
    return elemento.fadeIn();
  };

  dashboardEditBaseController.prototype.esconderS = function(elemento, callBack) {
    return elemento.slideUp(200, callBack);
  };

  dashboardEditBaseController.prototype.mostrarS = function(elemento) {
    return elemento.slideDown(200);
  };

  dashboardEditBaseController.prototype.configuracoesTelaNota = function() {
    return this.get(".js-Expandir").TextAreaExpander(40);
  };

  dashboardEditBaseController.prototype.marcarItensComoEditando = function() {
    return $(this.view).addClass("pagina-em-edicao");
  };

  dashboardEditBaseController.prototype.desmarcarItensComoEditando = function() {
    return $(this.view).removeClass("pagina-em-edicao");
  };

  dashboardEditBaseController.loadGraficos = function() {
    return $('.js-graficodeindicador', dashboardEditBaseController.view).each(function() {
      return dashboardEditBaseController.carregarGrafico($( this ).data('id', false));
    });
  };

  dashboardEditBaseController.carregarGrafico = function(id, naoExibirControles) {
    var $container, grafico, informacoes;
    $container = $("#grafico-" + id).find('.js-graficodeindicador');
    if ($container.data('carregado') === false) {
      $container.data('carregado', true);
      informacoes = dashboardEditBaseController.normalizarInformacoes($container.data());
      grafico = new GraficoDeIndicador("#grafico-" + id + " .js-graficodeindicador");
      grafico.setBase(informacoes.IndicadorId, null, null, null, null, null, null, null, informacoes.Frequencia, informacoes.ModeloDeGraficoId, 'Apurado', informacoes.TipoDeDesdobramento, informacoes.Data, null, false, informacoes.Ocorrencia, informacoes.IdDoPlanoDeGestao, informacoes.IdDaUnidade);
      grafico.renderWithoutControls();
      if (naoExibirControles) {
        grafico.removerTodosControles();
      }
      grafico.setTitle();
      return dashboardEditBaseController.bindDetalheIndicador(id);
    }
  };

  dashboardEditBaseController.bindDetalheIndicador = function(id) {
    var contexto;
    contexto = $("#grafico-" + id);
    if (id) {
      return $('.js-exibir-detalhes-indicador', contexto).on('click', function(e) {
        var dados, elemento;
        elemento = $(e.currentTarget);
        dados = elemento.data();
        dados = dashboardEditBaseController.normalizarInformacoes(dados);
        return Results.api.exibirDetalhesPorIdDoIndicador(dados.IndicadorId, dados.Ocorrencia, dados.Frequencia);
      });
    }
  };

  dashboardEditBaseController.normalizarInformacoes = function(informacoes) {
    return {
      IndicadorId: informacoes.indicadorid,
      Frequencia: informacoes.frequencia,
      ModeloDeGraficoId: informacoes.modelodegraficoid,
      TipoDeDesdobramento: informacoes.tipodedesdobramento,
      Data: informacoes.ocorrencia,
      Ocorrencia: informacoes.ocorrencia,
      IdDoPlanoDeGestao: informacoes.iddoplanodegestao,
      IdDaUnidade: informacoes.idunidade
    };
  };

  dashboardEditBaseController.prototype.postNovaOrdem = function() {
    return this.RaizDaRequisicao.AlterarOrdemDosItens.post({
      id: this.modelo.Id,
      itens: this.getOrdemItens()
    });
  };

  dashboardEditBaseController.prototype.getOrdemItens = function() {
    var i, item, itensOrdens, len, ordem, ref;
    ordem = 0;
    itensOrdens = new Array();
    ref = this.get('.js-ContainerItem');
    for (i = 0, len = ref.length; i < len; i++) {
      item = ref[i];
      if ($(item).attr("idItem") !== '-1' && $(item).attr("idItem") !== '') {
        itensOrdens[ordem] = $(item).attr("idItem");
        ordem++;
      }
    }
    return itensOrdens;
  };

  dashboardEditBaseController.prototype.recarregarSIMPart = function(ret) {
    return window.reload();
  };

  return dashboardEditBaseController;

})(window.baseController);
