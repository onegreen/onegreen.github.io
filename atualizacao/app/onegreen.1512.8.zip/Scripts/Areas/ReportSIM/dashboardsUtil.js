﻿window.DashboardsUtil = (function() {
  function DashboardsUtil() {}

  DashboardsUtil.getUrlPart = function(info, element) {
    var dataInfo;
    dataInfo = element.data(info);
    return info + "=" + dataInfo + "&";
  };

  DashboardsUtil.iniciarAcompanhamentoDeTela = function(element, url) {
    $('header').hide();
    $('body').addClass('bg-Painel');
    url = DashboardsUtil.buildBackgrounUrl(url);
    return DashboardsUtil.iniciarAcompanhamentoDaJanela(element);
  };

  DashboardsUtil.buildBackgrounUrl = function(url) {
    url += "&altura=" + ($(window).height()) + "&largura=" + ($(window).width());
    return $('body').css('background-image', "url('" + url + "')");
  };

  DashboardsUtil.iniciarAcompanhamentoDaJanela = function(element) {
    $(window).resize(function() {
      return DashboardsUtil.acompanharAlturaDoDispositivo(element);
    });
    return DashboardsUtil.acompanharAlturaDoDispositivo(element);
  };

  DashboardsUtil.acompanharAlturaDoDispositivo = function(element) {
    element.height($(window).height() - 70);
    return DashboardsUtil.hackIECartao();
  };

  DashboardsUtil.hackIECartao = function() {
    var cartao, i, len, ref, results;
    ref = $('.cartao-indicador');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      cartao = ref[i];
      cartao = $(cartao);
      if (cartao.height() <= 160) {
        results.push(cartao.addClass('card-ie'));
      } else {
        results.push(cartao.removeClass('card-ie'));
      }
    }
    return results;
  };

  DashboardsUtil.configurarNoticias = function(id) {
    var contador, i, len, noticia, quantidade, ref, results;
    ref = $('.js-noticia-pagina-' + id);
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      noticia = ref[i];
      noticia = $(noticia);
      quantidade = $('[data-indice]', noticia).length;
      contador = 0;
      $("[data-indice=0]", noticia).show();
      results.push(setInterval(function() {
        var antigo;
        antigo = contador;
        if (contador >= quantidade - 1) {
          contador = -1;
        }
        contador++;
        $("[data-indice=" + antigo + "]", noticia).hide();
        return $("[data-indice=" + contador + "]", noticia).show('slow');
      }, 6000));
    }
    return results;
  };

  DashboardsUtil.alterarUnidade = function(idDaUnidade) {
    return $as.ReportSIM.FiltroDashboards.MudarUnidadeGerencial.post({
      idDaUnidade: idDaUnidade
    }, {
      global: false
    }).done(function(data) {
      if (!window.reloadDashboards) {
        window.reloadDashboards = window.reload;
      }
      return window.reloadDashboards();
    });
  };

  DashboardsUtil.alterarPlanoDeGestao = function(idDoPlanoDeGestao) {
    return $as.ReportSIM.FiltroDashboards.MudarPlanoDeGestao.post({
      idDoPlanoDeGestao: idDoPlanoDeGestao
    }, {
      global: false
    }).done(function(data) {
      if (!window.reloadDashboards) {
        window.reloadDashboards = window.reload;
      }
      return window.reloadDashboards();
    });
  };

  DashboardsUtil.DefinirReloadParaPaginaPrincipalDaUg = function() {
    return window.reloadDashboards = function() {
      return window.location = $('#lnkPagina').attr('href');
    };
  };

  return DashboardsUtil;

})();
