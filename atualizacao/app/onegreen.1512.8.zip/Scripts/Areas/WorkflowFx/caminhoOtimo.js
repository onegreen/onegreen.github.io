﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.WorkflowFx || (this.WorkflowFx = {});

WorkflowFx.caminhoOtimo = (function() {
  function caminhoOtimo(options) {
    this.options = options;
    this.obterPopoverAcaoAtual = bind(this.obterPopoverAcaoAtual, this);
    this.obterPopoverExecutado = bind(this.obterPopoverExecutado, this);
    this.obterPopoverProximaAcao = bind(this.obterPopoverProximaAcao, this);
    $("[rel=tooltip]").tooltip({
      placement: "bottom"
    });
  }

  caminhoOtimo.prototype.obterPopoverProximaAcao = function(target, idExecucao, titulo) {
    popover.hide();
    if (popover.target !== target) {
      popover.target = target;
      popover.titulo = titulo;
      popover.conteudo = this.options.mensagemBloqueado;
      popover.placement = 'top';
      return popover.show();
    } else {
      return popover.target = '';
    }
  };

  caminhoOtimo.prototype.obterPopoverExecutado = function(target, idDaAtividade, idDaEntidade, tipoDaEntidade, titulo) {
    popover.hide();
    if (popover.target !== target) {
      return $.ajax({
        type: "Get",
        async: false,
        url: CompleteHostAdress + "WorkflowFx/WorkflowEngine/DetalheDaExecucao",
        data: {
          idDaAtividade: idDaAtividade,
          idDaEntidade: idDaEntidade,
          tipoDaEntidade: tipoDaEntidade
        },
        success: (function(_this) {
          return function(data) {
            popover.target = target;
            popover.titulo = titulo;
            popover.conteudo = data;
            popover.placement = 'top';
            return setTimeout(function() {
              return popover.show();
            }, 50);
          };
        })(this)
      });
    } else {
      return popover.target = '';
    }
  };

  caminhoOtimo.prototype.obterPopoverAcaoAtual = function(target, idDaAtividade, titulo, idDaEntidade, tipoDaEntidade) {
    popover.hide();
    if (popover.target !== target) {
      $.ajax({
        type: "Get",
        async: false,
        url: CompleteHostAdress + "WorkflowFx/WorkflowEngine/EstadoAtualAtividade",
        data: {
          idDaAtividade: idDaAtividade,
          idDaEntidade: idDaEntidade,
          tipoDaEntidade: tipoDaEntidade
        },
        success: (function(_this) {
          return function(data) {
            popover.target = target;
            popover.titulo = titulo;
            popover.conteudo = data;
            popover.placement = 'top';
            return setTimeout(function() {
              return popover.show();
            }, 50);
          };
        })(this)
      });
      return $("[rel=popover]").popover({
        placement: "bottom"
      });
    } else {
      return popover.target = '';
    }
  };

  caminhoOtimo.reload = function(idDaAtividade, idDaEntidade, tipoDaEntidade, formaDeExibicao, exibirAtividadeInicial) {
    return $as.WorkflowFx.WorkflowEngine.CaminhoOtimo.get({
      idDaEntidade: idDaEntidade,
      tipoDaEntidade: tipoDaEntidade,
      formaDeExibicao: formaDeExibicao,
      exibirAtividadeInicial: exibirAtividadeInicial
    }).success(function(data) {
      return $("#workflow-status-container-" + tipoDaEntidade + '-' + idDaEntidade).replaceWith(data);
    });
  };

  return caminhoOtimo;

})();
