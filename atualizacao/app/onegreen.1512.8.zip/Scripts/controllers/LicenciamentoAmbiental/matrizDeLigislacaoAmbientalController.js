﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.LicenciamentoAmbiental || (this.LicenciamentoAmbiental = {});

window.LicenciamentoAmbiental.matrizDeLigislacaoAmbientalController = (function() {
  function matrizDeLigislacaoAmbientalController(options) {
    this.options = options;
    this.desvincularClassificacoes = bind(this.desvincularClassificacoes, this);
    this.desvincularClassificacoesConfirm = bind(this.desvincularClassificacoesConfirm, this);
    this.vincularClassificacoes = bind(this.vincularClassificacoes, this);
    this.vincularClassificacoesConfirm = bind(this.vincularClassificacoesConfirm, this);
    this.habilitarDesabilitarAcoes = bind(this.habilitarDesabilitarAcoes, this);
    this.habilitarSelecaoNaTabela = bind(this.habilitarSelecaoNaTabela, this);
    this.loadComboClassificacaoDoLicenciamentoAmbiental = bind(this.loadComboClassificacaoDoLicenciamentoAmbiental, this);
    this.configurarPopoverLicenciamentosSugeridos = bind(this.configurarPopoverLicenciamentosSugeridos, this);
    this.loadComboClassificacaoDoLicenciamentoAmbiental();
    this.habilitarSelecaoNaTabela();
    this.vincularClassificacoesConfirm();
    this.desvincularClassificacoesConfirm();
    this.habilitarDesabilitarAcoes();
    this.configurarPopoverLicenciamentosSugeridos();
    $("tr td:not(.notOpacity)", $("#tb-matriz-classificacao")).css("cursor", "pointer").click(this.habilitarDesabilitarAcoes);
  }

  matrizDeLigislacaoAmbientalController.prototype.configurarPopoverLicenciamentosSugeridos = function() {
    return $("body").on("click", "#tb-matriz-classificacao tbody> tr td:not(.notOpacity) i", (function(_this) {
      return function(event) {
        var $el, evt, idDaClassificacao, tag, urlLicenciamentosSugeridos;
        evt = event || window.event;
        tag = evt.target.tagName || evt.srcElement.tagName;
        if (tag === 'A') {
          return;
        }
        $el = $(event.currentTarget);
        idDaClassificacao = $el.data("classificacao");
        urlLicenciamentosSugeridos = $el.parents("tbody").data("url-licenciamentos-sugeridos");
        if (urlLicenciamentosSugeridos) {
          return $.get(urlLicenciamentosSugeridos, {
            idDaClassificacao: idDaClassificacao
          }).done(function(data) {
            var $data, callPopover, content, title;
            $data = $(data);
            title = $data.find("#licenciamentos-sugeridos-title").html();
            content = $data.find("#licenciamentos-sugeridos-content").html();
            callPopover = function() {
              $el.popover({
                trigger: 'manual',
                html: true,
                title: title + '<span class="fr cursor-pointer" onclick="popover.close($(this))">x</span>',
                content: content,
                placement: 'top'
              });
              $el.popover('show');
            };
            setTimeout(callPopover, 200);
          });
        }
      };
    })(this));
  };

  matrizDeLigislacaoAmbientalController.prototype.loadComboClassificacaoDoLicenciamentoAmbiental = function() {
    return $('#ClassificacaoDoLicenciamentoAmbientalNome').autocompleter(this.options.UrlClassificacaoDoLicenciamentoAmbiental, {
      loadOnDemand: false,
      elementToClick: "#ClassificacaoDoLicenciamentoAmbientalNomeBtn",
      keyElement: "#IdClassificacaoDoLicenciamentoAmbiental",
      onSelected: (function(_this) {
        return function(valueInput) {
          if ($("tr td:not(.notOpacity).selecionado", $("#tb-matriz-classificacao")).length !== 0) {
            return $("#vincular-selecionados-matrizDeLegislacao").removeAttr("disabled");
          }
        };
      })(this)
    });
  };

  matrizDeLigislacaoAmbientalController.prototype.habilitarSelecaoNaTabela = function() {
    return $("tr td:not(.notOpacity)", $("#tb-matriz-classificacao")).css("cursor", "pointer").click(function(event) {
      var evt, tag;
      evt = event || window.event;
      tag = evt.target.tagName || evt.srcElement.tagName;
      if (tag === 'I') {
        return;
      }
      if ($(this).hasClass("selecionado")) {
        return $(this).removeClass("selecionado");
      } else {
        return $(this).addClass("selecionado");
      }
    });
  };

  matrizDeLigislacaoAmbientalController.prototype.habilitarDesabilitarAcoes = function() {
    if ($("tr td:not(.notOpacity).selecionado", $("#tb-matriz-classificacao")).length === 0) {
      $("#ClassificacaoDoLicenciamentoAmbientalNomeBtn").attr("disabled", "disabled");
      $("#vincular-selecionados-matrizDeLegislacao").attr("disabled", "disabled");
      return $("#desvincular-selecionados-matrizDeLegislacao").attr("disabled", "disabled");
    } else {
      $("#ClassificacaoDoLicenciamentoAmbientalNomeBtn").removeAttr("disabled");
      if ($("#ClassificacaoDoLicenciamentoAmbientalNome").val() !== "") {
        $("#vincular-selecionados-matrizDeLegislacao").removeAttr("disabled");
      }
      return $("#desvincular-selecionados-matrizDeLegislacao").removeAttr("disabled");
    }
  };

  matrizDeLigislacaoAmbientalController.prototype.vincularClassificacoesConfirm = function() {
    return $("#vincular-selecionados-matrizDeLegislacao").click((function(_this) {
      return function() {
        if ($($("tr td:not(.notOpacity).selecionado", $("#tb-matriz-classificacao"))).find("i").length !== 0) {
          return window.modalConfirm(_this.options.MensagemParaConfirmarVinculo, _this.vincularClassificacoes);
        } else {
          return _this.vincularClassificacoes();
        }
      };
    })(this));
  };

  matrizDeLigislacaoAmbientalController.prototype.vincularClassificacoes = function() {
    var json, potencialPoluidor;
    potencialPoluidor = new Array();
    $("tr td:not(.notOpacity).selecionado", $("#tb-matriz-classificacao")).each(function() {
      return potencialPoluidor.push({
        IdDoItemDaMatriz: $(this).attr("data-ItemMatriz"),
        PotencialPoluidor: $(this).attr("data-potencialpoluidor"),
        Porte: $(this).attr("data-Porte")
      });
    });
    json = JSON.stringify({
      matrizDeLegislacaoViewModel: potencialPoluidor,
      idDaClassificacao: $("#IdClassificacaoDoLicenciamentoAmbiental").val()
    });
    return $as.Sigma.LegislacoesAmbientais.VincularClassificacao.postJson(json).success((function(_this) {
      return function(data) {
        return $("#matrizDeClassificacao").html(data);
      };
    })(this));
  };

  matrizDeLigislacaoAmbientalController.prototype.desvincularClassificacoesConfirm = function() {
    return $("#desvincular-selecionados-matrizDeLegislacao").click((function(_this) {
      return function() {
        return window.modalConfirm(_this.options.MensagemParaConfirmarDesvinculo, _this.desvincularClassificacoes);
      };
    })(this));
  };

  matrizDeLigislacaoAmbientalController.prototype.desvincularClassificacoes = function() {
    var idsDoItemDaMatriz, json;
    idsDoItemDaMatriz = new Array();
    $("tr td:not(.notOpacity).selecionado", $("#tb-matriz-classificacao")).each(function() {
      if ($(this).attr("data-ItemMatriz") !== "") {
        return idsDoItemDaMatriz.push($(this).attr("data-ItemMatriz"));
      }
    });
    json = JSON.stringify({
      idDaLegislacao: this.options.IdDaLegislacao,
      idsDoItemDaMatriz: idsDoItemDaMatriz
    });
    return $as.Sigma.LegislacoesAmbientais.DesvincularClassificacao.postJson(json).success((function(_this) {
      return function(data) {
        return $("#matrizDeClassificacao").html(data);
      };
    })(this));
  };

  return matrizDeLigislacaoAmbientalController;

})();
