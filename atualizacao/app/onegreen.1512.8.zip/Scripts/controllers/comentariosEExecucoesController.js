﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.comentariosEExecucoesController = (function() {
  function comentariosEExecucoesController(options1) {
    this.options = options1;
    this.cancelarComentarioOuExecucao = bind(this.cancelarComentarioOuExecucao, this);
    this.habilitaDatas = bind(this.habilitaDatas, this);
    this.desabilitaDatas = bind(this.desabilitaDatas, this);
    this.obterDataDeExecucao = bind(this.obterDataDeExecucao, this);
    this.obterDataProximaExecucao = bind(this.obterDataProximaExecucao, this);
    this.obterDataProximaExecucaoAposHoje = bind(this.obterDataProximaExecucaoAposHoje, this);
    this.configuraFormasDeExecucao = bind(this.configuraFormasDeExecucao, this);
    this.executarEConcluir = bind(this.executarEConcluir, this);
    this.confirmarExecutarEConcluir = bind(this.confirmarExecutarEConcluir, this);
    $('form', '#realizar-modal').on('submit', function() {});
  }

  comentariosEExecucoesController.prototype.confirmarExecutarEConcluir = function() {
    return window.modalConfirm(this.options.resourceConfirmarExecutarEConcluir, this.executarEConcluir);
  };

  comentariosEExecucoesController.prototype.executarEConcluir = function() {
    $("#formaDeExecucao").val(this.options.formaExecutarEConcluir);
    $("#executar").val(this.options.formaExecutarEConcluir);
    $('#close-modal-realizar').click();
    return $("#realizar-modal form").submit();
  };

  comentariosEExecucoesController.prototype.configuraFormasDeExecucao = function() {
    $("#formasDeExecucao input[type='radio']").click((function(_this) {
      return function(e) {
        if ($(e.currentTarget).attr("id") === "executarAsAnteriores") {
          _this.desabilitaDatas();
          _this.desabilitaBotao("BotaoExecutarEConcluir");
        } else if ($(e.currentTarget).attr("id") === "executar") {
          _this.habilitaBotao("BotaoExecutarEConcluir");
          _this.habilitaDatas();
          _this.obterDataProximaExecucao();
          _this.obterDataDeExecucao();
        } else {
          _this.habilitaDatas();
          _this.habilitaBotao("BotaoExecutarEConcluir");
          _this.obterDataProximaExecucaoAposHoje();
        }
      };
    })(this));
  };

  comentariosEExecucoesController.prototype.obterDataProximaExecucaoAposHoje = function() {
    return $.get(options.obterDataProximaExecucaoAposDataCorrenteUrl, {
      idAtividade: $("#IdAtividade").val()
    }, (function(_this) {
      return function(data) {
        return $("#DataDaProximaExecucao").val(data);
      };
    })(this));
  };

  comentariosEExecucoesController.prototype.obterDataProximaExecucao = function() {
    return $("#DataDaProximaExecucao").val(this.options.dataDaProximaExecucao);
  };

  comentariosEExecucoesController.prototype.obterDataDeExecucao = function() {
    return $("#DataExecucao").val(this.options.dateDeExecucao);
  };

  comentariosEExecucoesController.prototype.desabilitaDatas = function() {
    $("#DataExecucao").attr("disabled", "disabled").val(this.options.resourceAuto).parent().find("label.btn").attr("data-original-title", this.options.dataSeraDefinidaAutomaticamente);
    $("#DataDaProximaExecucao").attr("disabled", "disabled").val(this.options.resourceAuto).parent().find("label.btn").attr("data-original-title", this.options.dataSeraDefinidaAutomaticamente);
  };

  comentariosEExecucoesController.prototype.habilitaDatas = function() {
    var dataProxima;
    $("#DataExecucao").removeAttr("disabled").val(this.options.dataDeHoje).parent().find("label.btn").removeAttr("data-original-title");
    dataProxima = $("#DataDaProximaExecucao");
    dataProxima.removeAttr("disabled").parent().find("label.btn").removeAttr("data-original-title");
    if (dataProxima.val() === this.options.resourceAuto) {
      return dataProxima.val("");
    }
  };

  comentariosEExecucoesController.prototype.habilitaBotao = function(idBotao) {
    return $("#" + idBotao).show();
  };

  comentariosEExecucoesController.prototype.desabilitaBotao = function(idBotao) {
    return $("#" + idBotao).hide();
  };

  comentariosEExecucoesController.prototype.cancelarComentarioOuExecucao = function(idComentarioOuExecucao, idAgregador) {
    if (idComentarioOuExecucao === 0) {
      return $.post(this.options.cancelarComentarioOuExecucaoUrl, {
        idAgredador: idAgregador
      });
    }
  };

  return comentariosEExecucoesController;

})();
