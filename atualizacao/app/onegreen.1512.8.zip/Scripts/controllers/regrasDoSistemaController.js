﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.regrasDoSistemaController = (function() {
  var parameters;

  regrasDoSistemaController.currentModulo = "";

  parameters = {};

  function regrasDoSistemaController(options) {
    this.options = options;
    this.permitirNegarAcessoATodosOsMenusPorGrupoDeUsuario = bind(this.permitirNegarAcessoATodosOsMenusPorGrupoDeUsuario, this);
    this.alterarAcessoDoGrupoDeUsuarioAoMenu = bind(this.alterarAcessoDoGrupoDeUsuarioAoMenu, this);
    this.onLoadIndexPorModulo = bind(this.onLoadIndexPorModulo, this);
    this.exibirOcultarSubordinadas = bind(this.exibirOcultarSubordinadas, this);
    this.exibirSubordinadas = bind(this.exibirSubordinadas, this);
    this.ocultarSubordinadas = bind(this.ocultarSubordinadas, this);
    this.permitirNegarEmTodasAsUnidades = bind(this.permitirNegarEmTodasAsUnidades, this);
    this.vincularUnidadeGerencial = bind(this.vincularUnidadeGerencial, this);
    this.desvincularUnidadesSelecionadas = bind(this.desvincularUnidadesSelecionadas, this);
    this.loadComboUnidadesGerenciais = bind(this.loadComboUnidadesGerenciais, this);
    this.loadComboGrupoDeUsuarios = bind(this.loadComboGrupoDeUsuarios, this);
    this.loadComboUsuarios = bind(this.loadComboUsuarios, this);
    this.preencheComboDeGrupos = bind(this.preencheComboDeGrupos, this);
    this.excluirUnidadesSelecionadas = bind(this.excluirUnidadesSelecionadas, this);
    this.alterarRegraGeralDoGrupoDeUsuario = bind(this.alterarRegraGeralDoGrupoDeUsuario, this);
    this.alterarRegraGeralDoUsuario = bind(this.alterarRegraGeralDoUsuario, this);
    this.alterarRegraDoGrupoDeUsuario = bind(this.alterarRegraDoGrupoDeUsuario, this);
    this.alterarRegraDoUsuario = bind(this.alterarRegraDoUsuario, this);
    this.alterarModulo = bind(this.alterarModulo, this);
    this.configuraSelecaoDeTipo = bind(this.configuraSelecaoDeTipo, this);
    this.carregarRegras = bind(this.carregarRegras, this);
    this.carregarRegrasGerais = bind(this.carregarRegrasGerais, this);
    this.carregarManutencao = bind(this.carregarManutencao, this);
    this.loadComboUsuarios();
    this.loadComboGrupoDeUsuarios();
    this.configuraSelecaoDeTipo();
    this.preencheComboDeGrupos();
    this.loadComboUnidadesGerenciais();
    if ($("#BotaoTipoUsuario").hasClass("btn-warning")) {
      parameters = {
        idDoUsuario: $("#IdDoUsuario").val(),
        idDoModulo: regrasDoSistemaController.currentModulo
      };
      $("#tabManutencao").hide();
      $("#divComboGrupoDoUsuario").hide();
      $("#divComboUsuario").show();
    } else if ($("#BotaoTipoGrupo").hasClass("btn-warning")) {
      parameters = {
        idDoGrupoDeUsuario: $("#IdDoGrupoDoUsuario").val(),
        idDoModulo: regrasDoSistemaController.currentModulo
      };
      $("#tabManutencao").show();
      $("#divComboUsuario").hide();
      $("#divComboGrupoDoUsuario").show();
    }
    if ($("#tabConfiguracaoDoFluxoDeAprovacao").hasClass("active")) {
      parameters = {
        idDaUnidaDeGerencial: $("#IdUnidadeGerencial").val()
      };
    }
    $("#btnVincularUnidades").hide();
    $("#btnDesvincularUnidades").hide();
    $("a[data-moduloId]").click(this.alterarModulo);
    $("#btnVincularUnidades").click(this.vincularUnidadeGerencial);
    $("#btnDesvincularUnidades").click(this.excluirUnidadesSelecionadas);
  }

  regrasDoSistemaController.prototype.carregarManutencao = function() {
    return $.ajax({
      type: "GET",
      url: this.options.urlCarregarManutencao,
      data: parameters,
      success: function(data) {
        return $("#regrasPorModulo").html(data);
      }
    });
  };

  regrasDoSistemaController.prototype.carregarRegrasGerais = function() {
    return $.ajax({
      type: "GET",
      url: this.options.urlCarregarRegrasGerais,
      data: parameters,
      success: function(data) {
        return $("#regrasPorModulo").html(data);
      }
    });
  };

  regrasDoSistemaController.prototype.carregarRegras = function(idDoModulo) {
    parameters.idDoModulo = idDoModulo;
    if (idDoModulo === "") {
      return this.carregarRegrasGerais();
    } else {
      return $.ajax({
        type: "GET",
        url: this.options.urlCarregarRegras,
        data: parameters,
        success: (function(_this) {
          return function(data) {
            $("#regrasPorModulo").html(data);
            return $("i[data-idunidade]").click(_this.exibirOcultarSubordinadas);
          };
        })(this)
      });
    }
  };

  regrasDoSistemaController.prototype.configuraSelecaoDeTipo = function() {
    $("#BotaoTipoUsuario").on("click", (function(_this) {
      return function(e) {
        $("#divTipoPesquisa a").removeClass("btn-warning");
        $("#BotaoTipoUsuario").addClass("btn-warning");
        $("#tabManutencao").hide();
        $("#divComboGrupoDoUsuario").hide();
        $("#divComboUsuario").show();
        parameters = {
          idDoUsuario: $("#IdDoUsuario").val(),
          idDoModulo: regrasDoSistemaController.currentModulo
        };
        return _this.carregarRegras(regrasDoSistemaController.currentModulo);
      };
    })(this));
    return $("#BotaoTipoGrupo").on("click", (function(_this) {
      return function(e) {
        $("#divTipoPesquisa a").removeClass("btn-warning");
        $("#BotaoTipoGrupo").addClass("btn-warning");
        $("#divComboUsuario").hide();
        $("#divComboGrupoDoUsuario").show();
        $("#tabManutencao").show();
        parameters = {
          idDoGrupoDeUsuario: $("#IdDoGrupoDoUsuario").val(),
          idDoModulo: regrasDoSistemaController.currentModulo
        };
        return _this.carregarRegras(regrasDoSistemaController.currentModulo);
      };
    })(this));
  };

  regrasDoSistemaController.prototype.alterarModulo = function(event) {
    var eManutencao, elemento, ref, tipoDoModulo;
    elemento = $(event.target);
    tipoDoModulo = elemento.attr("data-tipoModulo");
    eManutencao = (ref = tipoDoModulo === "manutencao") != null ? ref : {
      "true": false
    };
    regrasDoSistemaController.currentModulo = elemento.attr("data-moduloId");
    if (!elemento.parent().hasClass("active") && !eManutencao) {
      this.carregarRegras(regrasDoSistemaController.currentModulo, eManutencao);
    } else if (!elemento.parent().hasClass("active") && eManutencao) {
      this.carregarManutencao();
    }
    if (regrasDoSistemaController.currentModulo === "") {
      $("#btnVincularUnidades").hide();
      return $("#btnDesvincularUnidades").hide();
    } else {
      return $("#btnVincularUnidades").show();
    }
  };

  regrasDoSistemaController.prototype.alterarRegraDoUsuario = function(element, evento, idDaRegra, idDaUnidade) {
    evento.cancelBubble = true;
    return $.ajax({
      type: "GET",
      url: this.options.urlAlterarRegraDoUsuario,
      data: {
        idDaRegra: idDaRegra,
        idDoUsuario: $("#IdDoUsuario").val(),
        idDaUnidade: idDaUnidade
      },
      success: (function(_this) {
        return function(data) {
          return _this.carregarRegras(regrasDoSistemaController.currentModulo);
        };
      })(this)
    });
  };

  regrasDoSistemaController.prototype.alterarRegraDoGrupoDeUsuario = function(element, evento, idDaRegra, idDaUnidade) {
    evento.cancelBubble = true;
    return $.ajax({
      type: "GET",
      url: this.options.urlAlterarRegraDoGrupoDeUsuario,
      data: {
        idDaRegra: idDaRegra,
        idDoGrupoDeUsuario: $("#IdDoGrupoDoUsuario").val(),
        idDaUnidade: idDaUnidade
      },
      success: (function(_this) {
        return function(data) {
          return _this.carregarRegras(regrasDoSistemaController.currentModulo);
        };
      })(this)
    });
  };

  regrasDoSistemaController.prototype.alterarRegraGeralDoUsuario = function(idDaRegra, idDoUsuario) {
    return $.ajax({
      type: "GET",
      url: this.options.urlAlterarRegraGeralDoUsuario,
      data: {
        idDaRegra: idDaRegra,
        idDoUsuario: idDoUsuario
      },
      success: function(data) {
        return $("#regrasPorModulo").html(data);
      }
    });
  };

  regrasDoSistemaController.prototype.alterarRegraGeralDoGrupoDeUsuario = function(idDaRegra, idDoGrupoDeUsuario) {
    return $.ajax({
      type: "GET",
      url: this.options.urlAlterarRegraGeralDoGrupoDeUsuario,
      data: {
        idDaRegra: idDaRegra,
        idDoGrupoDeUsuario: idDoGrupoDeUsuario
      },
      success: function(data) {
        return $("#regrasPorModulo").html(data);
      }
    });
  };

  regrasDoSistemaController.prototype.excluirUnidadesSelecionadas = function(event) {
    return window.modalConfirm($(event.target).attr("data-ajax-confirm"), this.desvincularUnidadesSelecionadas);
  };

  regrasDoSistemaController.prototype.preencheComboDeGrupos = function() {
    return $.ajax({
      type: "GET",
      url: this.options.urlLoadComboGrupoDeUsuarios,
      success: function(data) {
        if ($("#GrupoDoUsuarioNome").val() === "") {
          $("#IdDoGrupoDoUsuario").val(data[0].Key);
          return $("#GrupoDoUsuarioNome").val(data[0].Value);
        }
      }
    });
  };

  regrasDoSistemaController.prototype.loadComboUsuarios = function() {
    return $('#UsuarioNome').autocompleter(this.options.urlLoadComboUsuarios, {
      loadOnDemand: true,
      elementToClick: "#UsuarioNomeBtn",
      keyElement: "#IdDoUsuario",
      onSelected: (function(_this) {
        return function(valueInput) {
          parameters = {
            idDoUsuario: $("#IdDoUsuario").val(),
            idDoModulo: regrasDoSistemaController.currentModulo
          };
          return _this.carregarRegras(regrasDoSistemaController.currentModulo);
        };
      })(this)
    });
  };

  regrasDoSistemaController.prototype.loadComboGrupoDeUsuarios = function() {
    return $('#GrupoDoUsuarioNome').autocompleter(this.options.urlLoadComboGrupoDeUsuarios, {
      loadOnDemand: true,
      elementToClick: "#GrupoDoUsuarioNomeBtn",
      keyElement: "#IdDoGrupoDoUsuario",
      onSelected: (function(_this) {
        return function(valueInput) {
          parameters = {
            idDoGrupoDeUsuario: $("#IdDoGrupoDoUsuario").val(),
            idDoModulo: regrasDoSistemaController.currentModulo
          };
          if ($("#tabManutencao").hasClass("active")) {
            return _this.carregarManutencao();
          } else {
            return _this.carregarRegras(regrasDoSistemaController.currentModulo);
          }
        };
      })(this)
    });
  };

  regrasDoSistemaController.prototype.loadComboUnidadesGerenciais = function() {
    return $('#UnidadeGerencialNome').autocompleter(this.options.urlLoadComboUnidadesGerenciais, {
      loadOnDemand: false,
      elementToClick: "#UnidadeGerencialNomeBtn",
      keyElement: "#IdUnidadeGerencial",
      parameters: {
        idDoPlanoDeGestao: '1110000000014'
      },
      onSelected: (function(_this) {
        return function(valueInput) {
          return _this.carregarConfiguracoesDoFluxoDeAprovacao();
        };
      })(this)
    });
  };

  regrasDoSistemaController.prototype.desvincularUnidadesSelecionadas = function() {
    idDoUsuario;
    idDoGrupo;
    var idDoGrupo, idDoUsuario;
    if ($("#BotaoTipoUsuario").hasClass("btn-warning")) {
      idDoUsuario = $("#IdDoUsuario", "#contextoDasRegras").val();
    } else if ($("#BotaoTipoGrupo").hasClass("btn-warning")) {
      idDoGrupo = $("#IdDoGrupoDoUsuario", "#contextoDasRegras").val();
    }
    return $.ajax({
      type: "POST",
      url: this.options.urlDesvincularUnidadesSelecionadas + $('[name=ids]', '.linhaUnidade.selecionado').serialize(),
      data: {
        idDoUsuario: idDoUsuario,
        idDoGrupoDeUsuario: idDoGrupo,
        idDoModulo: regrasDoSistemaController.currentModulo
      },
      success: function(html) {
        return $("#regrasPorModulo").html(html);
      }
    });
  };

  regrasDoSistemaController.prototype.vincularUnidadeGerencial = function() {
    return $.ajax({
      type: "POST",
      url: this.options.urlVincularUnidadeGerencial,
      success: function(html) {
        return $("#modalVincularUnidadeGerencial").html(html);
      }
    });
  };

  regrasDoSistemaController.prototype.permitirNegarEmTodasAsUnidades = function(idDaRegra, idDoModulo, permissao, idDoUsuario, idDoGrrupoDeUsuario, idDaUnidadeSuperior) {
    return $.ajax({
      type: "GET",
      url: this.options.urlPermitirNegarEmTodasAsUnidades,
      data: {
        idDaRegra: idDaRegra,
        idDoModulo: idDoModulo,
        permissao: permissao,
        idDoUsuario: idDoUsuario,
        idDoGrupoDeUsuario: idDoGrrupoDeUsuario,
        idDaUnidadeSuperior: idDaUnidadeSuperior
      },
      success: function(data) {
        return $("#regrasPorModulo").html(data);
      }
    });
  };

  regrasDoSistemaController.prototype.realcarRegra = function() {
    return $(".realcaRegra").on("mouseover", function(e) {
      var idDaRegra;
      idDaRegra = $(this).attr("forregra");
      return $("#regra-" + idDaRegra).css("background-color", "#EEE");
    }).on("mouseout", function(e) {
      var idDaRegra;
      idDaRegra = $(this).attr("forregra");
      return $("#regra-" + idDaRegra).css("background-color", "");
    });
  };

  regrasDoSistemaController.prototype.ocultarSubordinadas = function(elemento, idDaUnidade) {
    if (idDaUnidade !== void 0) {
      $("[data-pai='" + idDaUnidade + "']").each((function(_this) {
        return function(i, e) {
          var idUnidade;
          $(e).addClass('none');
          idUnidade = $(e).data('idunidade');
          return _this.ocultarSubordinadas($(e), idUnidade);
        };
      })(this));
      return elemento.find('i').removeClass("fa-minus-square").addClass("fa-plus-square");
    }
  };

  regrasDoSistemaController.prototype.exibirSubordinadas = function(elemento, idDaUnidade) {
    idDaUnidade = elemento.data('idunidade');
    $("[data-pai='" + idDaUnidade + "']").removeClass('none');
    return elemento.removeClass("fa-plus-square").addClass("fa-minus-square");
  };

  regrasDoSistemaController.prototype.exibirOcultarSubordinadas = function(event) {
    var elemento, idDaUnidade;
    elemento = $(event.target);
    idDaUnidade = elemento.data('idunidade');
    if (elemento.hasClass("fa-plus-square")) {
      this.exibirSubordinadas(elemento, idDaUnidade);
    } else {
      this.ocultarSubordinadas(elemento.parent().parent(), idDaUnidade);
    }
    return event.cancelBubble = true;
  };

  regrasDoSistemaController.prototype.setToolTip = function() {
    return $('.seta-botao').tooltip();
  };

  regrasDoSistemaController.prototype.onLoadIndexPorModulo = function() {
    this.realcarRegra();
    this.setToolTip();
    $("#btnDesvincularUnidades").hide();
    $("#btnVincularUnidades").show();
    return $(".linhaUnidade:not(.cabecalho)").click(function() {
      $(this).toggleClass("selecionado");
      $(this).parent().toggleClass("selecionado");
      if ($(".selecionado").length > 0) {
        $("#btnDesvincularUnidades").show();
        return $("#btnVincularUnidades").hide();
      } else {
        $("#btnDesvincularUnidades").hide();
        return $("#btnVincularUnidades").show();
      }
    });
  };

  regrasDoSistemaController.prototype.alterarAcessoDoGrupoDeUsuarioAoMenu = function(idDoMenuDoSistema, idDoGrupoDeUsuario) {
    return $.ajax({
      type: "GET",
      url: this.options.urlAlterarAcessoDoGrupoDeUsuarioAoMenu,
      data: {
        idDoMenuDoSistema: idDoMenuDoSistema,
        idDoGrupoDeUsuario: idDoGrupoDeUsuario
      },
      success: function(html) {
        return $("#regrasPorModulo").html(html);
      }
    });
  };

  regrasDoSistemaController.prototype.permitirNegarAcessoATodosOsMenusPorGrupoDeUsuario = function(permitirAcesso) {
    return $.ajax({
      type: "GET",
      url: this.options.urlPermitirNegarAcessoATodosOsMenusPorGrupoDeUsuario,
      data: {
        idDoGrupoDeUsuario: $("#IdDoGrupoDoUsuario").val(),
        permitirAcesso: permitirAcesso
      },
      success: function(html) {
        return $("#regrasPorModulo").html(html);
      }
    });
  };

  return regrasDoSistemaController;

})();
