﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.uploadDeImagemController = (function() {
  function uploadDeImagemController(container, options) {
    this.container = container;
    this.options = options;
    this.aoDeletar = bind(this.aoDeletar, this);
    this.recarregaImagemUpload = bind(this.recarregaImagemUpload, this);
    this.uploadDeImagem = bind(this.uploadDeImagem, this);
  }

  uploadDeImagemController.prototype.uploadDeImagem = function() {
    $("#UploadFoto", this.container).click((function(_this) {
      return function() {
        var idDoIframe;
        idDoIframe = document.getElementById("iframeUploadImagem");
        return idDoIframe.contentWindow.document.getElementById("SelecaoArquivo").click();
      };
    })(this));
    $("#DeleteFoto", this.container).click((function(_this) {
      return function() {
        return $.ajax({
          url: _this.options.urlDeleteFoto,
          data: {
            id: _this.options.Id,
            pasta: _this.options.Pasta
          },
          success: function(data) {
            return _this.aoDeletar();
          }
        });
      };
    })(this));
    return $('#btnFechar', this.container).click((function(_this) {
      return function() {
        if (_this.options.IdDaEntidade === 0) {
          return $.ajax({
            url: _this.options.urlDeleteFotosTemporarias,
            data: {
              id: _this.options.Id,
              pasta: _this.options.Pasta,
              somenteTemporaria: false
            }
          });
        }
      };
    })(this));
  };

  uploadDeImagemController.prototype.recarregaImagemUpload = function() {
    return $('.imagemUpload').attr('src', this.options.urlFotoTemporaria);
  };

  uploadDeImagemController.prototype.aoDeletar = function() {
    $('#container-imagem', this.container).html('<img id="imagemUpload" class="imagemUpload" src=""/>');
    $('#ImageFileName', this.container).val('');
    $('#divProgress', this.container).hide();
    $('#UploadFoto', this.container).html(this.options.labelAdicionarImg);
    $('#DeleteFoto', this.container).hide();
    return $('#UploadFoto', this.container).focus();
  };

  return uploadDeImagemController;

})();
