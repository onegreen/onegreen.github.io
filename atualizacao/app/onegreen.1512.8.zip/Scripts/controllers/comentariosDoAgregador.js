﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.comentariosDoAgregador = (function() {
  function comentariosDoAgregador(view, idDoAgregador, opcoes) {
    this.view = view;
    this.idDoAgregador = idDoAgregador;
    this.opcoes = opcoes;
    this.atualizarContagem = bind(this.atualizarContagem, this);
    this.dimensionarListagem = bind(this.dimensionarListagem, this);
    this.changeDatePickerDate = bind(this.changeDatePickerDate, this);
    this.eventoChangeDatePickerDate = bind(this.eventoChangeDatePickerDate, this);
    this.datePicker = bind(this.datePicker, this);
    this.resetarCampoComentario = bind(this.resetarCampoComentario, this);
    this.recarregarComentarios = bind(this.recarregarComentarios, this);
    this.msgDeValidacao = bind(this.msgDeValidacao, this);
    this.salvarComentario = bind(this.salvarComentario, this);
    this.esconderContainerEnvioComentario = bind(this.esconderContainerEnvioComentario, this);
    this.configurarComentario = bind(this.configurarComentario, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.$view = $(this.view);
    this.comentario = $(this.opcoes.idComentario, this.$view);
    this.envioComentarioContainer = $("#envio-comentario-container", this.$view);
    this.minimizarEnvioComentario = $("#minimizar-envio-container", this.$view);
    this.dataDeReferencia = $("#dataDeReferencia", this.$view);
    this.idDoIndicador = $("#IdDoIndicador", this.$view).val();
    this.comentariosContainer = $("#listaDeComentarios", this.$view);
    this.btnComentar = $("#btnComentar", this.$view);
    this.inputComentario = this.opcoes.ativarMentions ? $('#inputComentario', this.$view) : this.comentario;
    if (!this.opcoes.ativarMentions) {
      this.inputComentario.TextAreaExpander(40, 180);
    }
    this.containerDescricao = $("#container-descricao", this.$view);
    this.validacaoErros = $('#validacao-erros', this.$view);
    this.comentariosTabContainer = this.$view.find('#comentarios-tab-content');
    this.ocorrencia = this.$view.find('#Ocorrencia').val();
    this.frequencia = this.$view.find('#Frequencia').val();
    this.startDate = this.$view.find('#startDate').val();
    this.endDate = this.$view.find('#endDate').val();
    this.initialDate = new Date(this.$view.find('#initialDate').val());
    $("[rel=tooltip]", this.$view).tooltip();
    this.configurarBinds();
    setTimeout((function(_this) {
      return function() {
        return _this.dimensionarListagem();
      };
    })(this), 0);
  }

  comentariosDoAgregador.prototype.configurarBinds = function() {
    if (!this.opcoes.fullscreen) {
      this.minimizarEnvioComentario.unbind('click').click(this.esconderContainerEnvioComentario);
    }
    this.comentario.unbind('keyup').keyup(this.configurarComentario).unbind('resize').resize(this.dimensionarListagem);
    this.btnComentar.unbind('click').click(this.salvarComentario);
    this.datePicker();
  };

  comentariosDoAgregador.prototype.configurarComentario = function() {
    if (this.comentario.val() !== '' && this.envioComentarioContainer.hasClass('js-hide')) {
      this.envioComentarioContainer.fadeIn(400, this.dimensionarListagem);
      return this.envioComentarioContainer.removeClass('js-hide');
    } else {
      return this.dimensionarListagem();
    }
  };

  comentariosDoAgregador.prototype.esconderContainerEnvioComentario = function() {
    this.envioComentarioContainer.fadeOut(400, this.dimensionarListagem);
    return this.envioComentarioContainer.addClass('js-hide');
  };

  comentariosDoAgregador.prototype.salvarComentario = function() {
    if (this.comentario.val() !== '' && this.comentario.val().length <= 1000) {
      this.msgDeValidacao(false);
      return $as.Comentarios.AgregadorDeComentarios.Adicionar.post({
        idDoAgregador: this.idDoAgregador,
        Texto: this.inputComentario.val(),
        DataDeReferencia: this.dataDeReferencia.val()
      }).done((function(_this) {
        return function(data) {
          if (data.success) {
            _this.recarregarComentarios();
            if (_this.opcoes.ativarMentions) {
              $("#DescricaoComentario").data('mentionsInput').reset();
            }
            if (!_this.opcoes.ativarMentions) {
              _this.inputComentario.height(40);
            }
            return detalhesDoIndicador.marcarComoAlterado();
          } else {
            _this.containerDescricao.addClass('error');
            $('ul', _this.validacaoErros).html("<li>" + data.data.mensagem + "</li>");
            return _this.validacaoErros.show();
          }
        };
      })(this));
    } else {
      return this.msgDeValidacao(true);
    }
  };

  comentariosDoAgregador.prototype.msgDeValidacao = function(exibir) {
    if (exibir) {
      $(this.view).find('#container-descricao').addClass('error');
      $(this.view).find('#validacao-erros').show();
      $(this.view).find('#validacao-erros ul li').remove();
      return $(this.view).find('#validacao-erros ul').append("<li>" + this.opcoes.msgValidacao + "</li>");
    } else {
      $(this.view).find('#container-descricao').removeClass('error');
      return $(this.view).find('#validacao-erros').hide();
    }
  };

  comentariosDoAgregador.prototype.recarregarComentarios = function() {
    return $as.Comentarios.AgregadorDeComentarios.ListaDeComentarios.get({
      idDoAgregador: this.idDoAgregador
    }).done((function(_this) {
      return function(data) {
        var quantidadeDeComentarios;
        _this.comentariosContainer.html(data);
        _this.resetarCampoComentario();
        quantidadeDeComentarios = $("#comentarios-tab-content #contadorDeComentarios", _this.$view).val();
        $("#js-contadorComentarios", _this.$view).text(quantidadeDeComentarios);
        $("[rel=tooltip]", _this.$view).tooltip();
        return _this.atualizarContagem();
      };
    })(this));
  };

  comentariosDoAgregador.prototype.resetarCampoComentario = function() {
    if (!this.opcoes.fullscreen) {
      this.esconderContainerEnvioComentario();
    }
    this.comentario.val('').focus();
    this.dataDeReferencia.val('');
    this.containerDescricao.removeClass('error');
    this.validacaoErros.hide();
    return $('ul', this.validacaoErros).html('');
  };

  comentariosDoAgregador.prototype.datePicker = function() {
    var selecao;
    selecao = $('#btnDataDoComentario', '#comentar-container').datepicker({
      startDate: this.startDate,
      endDate: this.endDate,
      changeMonth: true,
      changeYear: false,
      showButtonPanel: true,
      autoclose: true,
      minViewMode: 0
    });
    selecao.datepicker("setDate", this.initialDate);
    selecao.off('changeDate').on('changeDate', this.eventoChangeDatePickerDate);
    return this.changeDatePickerDate(this.ocorrencia);
  };

  comentariosDoAgregador.prototype.eventoChangeDatePickerDate = function(ev) {
    var componenteDatePicker;
    componenteDatePicker = $('#btnDataDoComentario', '#comentar-container').data('datepicker');
    return this.changeDatePickerDate(componenteDatePicker.getFormattedDate());
  };

  comentariosDoAgregador.prototype.changeDatePickerDate = function(texto) {
    this.ocorrencia = texto;
    $('#textoDataDoComentario', '#comentar-container').text(texto);
    $('#dataDeReferencia', '#comentar-container').val(texto);
    return $('.datepicker').hide();
  };

  comentariosDoAgregador.prototype.dimensionarListagem = function() {};

  comentariosDoAgregador.prototype.atualizarContagem = function() {
    return $as.Comentarios.AgregadorDeComentarios.AtualizarContador.get({
      idDoAgregador: this.idDoAgregador
    }).done((function(_this) {
      return function(data) {
        return $(".contador-de-comentario-" + _this.idDoAgregador).text(data);
      };
    })(this));
  };

  return comentariosDoAgregador;

})();
