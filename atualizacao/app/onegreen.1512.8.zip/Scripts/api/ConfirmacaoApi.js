﻿var Confirmacao;

Confirmacao = (function() {
  function Confirmacao() {}

  Confirmacao.modal = null;

  Confirmacao.corpo = null;

  Confirmacao.botaoConfirmar = null;

  Confirmacao.botaoCancelar = null;

  Confirmacao.aoConfirmar = null;

  Confirmacao.aoCancelar = null;

  Confirmacao.boot = function() {
    Confirmacao.modal = $('#modal-confirmacao');
    Confirmacao.corpo = $('#corpo-confirmacao', Confirmacao.modal);
    Confirmacao.botaoConfirmar = $('#aceitar-confirmacao', Confirmacao.modal);
    Confirmacao.botaoCancelar = $('#cancelar-confirmacao', Confirmacao.modal);
  };

  Confirmacao.configurarModal = function(mensagem, textoConfirmar, textoCancelar) {
    if (mensagem) {
      Confirmacao.corpo.html(mensagem);
    }
    if (textoConfirmar) {
      Confirmacao.botaoConfirmar.text(textoConfirmar);
    }
    if (textoCancelar) {
      return Confirmacao.botaoCancelar.text(textoCancelar);
    }
  };

  Confirmacao.ativarEventos = function() {
    Confirmacao.botaoConfirmar.unbind('click').bind('click', Confirmacao.confirmar);
    return Confirmacao.botaoCancelar.unbind('click').bind('click', Confirmacao.cancelar);
  };

  Confirmacao.mostrar = function(mensagem, aoConfirmar, aoCancelar, textoConfirmar, textoCancelar) {
    Confirmacao.configurarModal(mensagem, textoConfirmar, textoCancelar);
    Confirmacao.aoConfirmar = aoConfirmar;
    Confirmacao.aoCancelar = aoCancelar;
    Confirmacao.ativarEventos();
    Confirmacao.modal.window();
  };

  Confirmacao.cancelar = function() {
    if (Confirmacao.aoCancelar) {
      return Confirmacao.aoCancelar();
    }
  };

  Confirmacao.confirmar = function() {
    return Confirmacao.aoConfirmar();
  };

  return Confirmacao;

})();

$(function() {
  return Confirmacao.boot();
});
