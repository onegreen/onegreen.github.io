﻿
function analiseDePareto(options) {

    this.load = function () {
        this.teclasNoASCIIFirefox = ["Right", "Left", "Backspace", "Del", "Tab"]

        $(".TextExpander").TextAreaExpander(20);
        $("#novoItem", "#tabelaItens-" + options.idDaAnaliseDePareto).focus();
        $(".nivelAbaixo").tooltip();

        $("input[alt=decimalUnsigned]").keypress((function (_this) {
            return function (e) {
                return _this.setarMascaraDecimal(e);
            };
        })(this));

        this.TamanhoDoGrafico();
    }

    this.ValidarCampoDescricao = function ($item) {
        var campoDescricao;
        var campoValor;

        if ($item.hasClass("valor")) {
            campoDescricao = $($item).parents("tr").find("td:first input");
            campoValor = $item;
        }
        else {
            campoDescricao = $item;
            campoValor = $($item).parents("tr").find("input#Valor");
        }

        if (campoDescricao.val().trim() == "") {
            setFoco(campoDescricao);
            campoDescricao.attr("placeholder", resourceJsonCommom.DigiteUmaDescricao);
            campoDescricao.parent().addClass("control-group error");
            return false;
        }
        else if (campoValor.val() == "0,00")
            return false;
        else
            return true;
    }
        
    this.loadConfiguracao = function () {

        $('#configurarpareto-modal').window();

        this.DefinirOpacidadeInicialTabela();
        this.DefinirCliqueTabela();
        this.SelecionarNivel(options.cor);

        $tabela.find("input").hide();
        $tabela.find("td").addClass('center');

        if ($("#BarrasColoridas-Sim").attr("checked") == "checked") {
            this.DesmarcarCores();
        }
    }

    this.ZoomGraficoDePareto = function () {
        $("#grafico-pareto-modal").window({ width: 700 });
    }

    this.TamanhoDoGrafico = function TamanhoDoGrafico() {
        var largura = $(window).width();
        var larguraDiv = $("#divItensDaAnaliseDePareto").width();

        $("#graficoDePareto").fadeIn({ width: larguraDiv - 360, opacity: 1 }, 1000);

        if (largura <= 1024) {
            $("#graficoDePareto").fadeIn({ width: larguraDiv - 360, opacity: 1 }, 1000);
        }
        else {
            $("#graficoDePareto").fadeIn({ width: 600, opacity: 1 }, 1000);
        }
    }

    this.SalvarItemDaAnaliseDePareto = function ($item) {
        if (this.ValidarCampoDescricao($item)) {
            $.ajax({
                type: 'POST',
                url: options.SalvarItemDaAnaliseDePareto,
                data: $item.parent().parent().find(":input").serialize(),   
                success: function (data) {                    
                    $("#tabelaItens-" + options.idDaAnaliseDePareto).parent().parent().parent().html(data);
                }
            });
        }
        return false;
    }

    this.AdicionarNivel = function (idDoItem) {
        $.ajax({
            type: 'GET',
            url: options.AdicionarNivel,
            data: { idDoItemDaAnaliseDePareto: idDoItem },
            success: function (data) {
                $("#tabelaItens-" + options.idDaAnaliseDePareto).parent().parent().parent().html(data);
            }
        });
    }

    this.AcessarNivelAbaixo = function (idDaAnaliseDePareto) {
        $.ajax({
            type: 'GET',
            url: options.AcessarNivelAbaixo,
            data: { idDoPai: idDaAnaliseDePareto },
            success: function (data) {
                $("#tabelaItens-" + options.idDaAnaliseDePareto).parent().parent().parent().html(data);
            }
        });

        return false;
    }

    this.VoltarUmNivel = function (idDaAnaliseDePareto) {
        $.ajax({
            type: 'GET',
            url: options.VoltarUmNivel,
            data: { idDaAnaliseDePareto: idDaAnaliseDePareto },
            success: function (data) {
                $("#tabelaItens-" + options.idDaAnaliseDePareto).parent().parent().parent().html(data);
            }
        });
    }

    this.VoltarTodosOsNiveis = function (idDaAnaliseDePareto) {
        $.ajax({
            type: 'GET',
            url: options.VoltarTodosOsNiveis,
            data: { idDaAnaliseDePareto: idDaAnaliseDePareto },
            success: function (data) {
                $("#tabelaItens-" + options.idDaAnaliseDePareto).parent().parent().parent().html(data);
            }
        });
    }

    this.ConfigurarPareto = function (idDaAnaliseDePareto) {
        $.get(options.ConfigurarPareto, { idDaAnaliseDePareto: idDaAnaliseDePareto }, function (data) {
            window.GetDiv("configurar-pareto-modal-container").html(data);
        });
    }






    this.MouveOverInicialDaTabela = function () {
        $("#tb-cor tr td:not(.notOpacity)", contexto).unbind('mouseenter');
        $("#tb-cor tr td:not(.notOpacity)", contexto).unbind('mouseleave');
    }

    this.DefinirOpacidadeInicialTabela = function () {

        $("#tb-cor tr td:not(.notOpacity)", contexto).mouseenter(function () {
            $(this).addClass("tdActive");

        }).mouseleave(function () {
            $(this).removeClass("tdActive");
            $("tr td:not(.notOpacity)", $tabela).css({ opacity: 1 });
        });
    }

    this.DefinirOpacidadeTabelaSelecionada = function () {

        $("tr td:not(.notOpacity):not(.corSelecionada)", $tabela).mouseenter(function () {
            $(this).css({ opacity: 1 });
        }).mouseleave(function () {

        });
    }

    this.SelectTd = function ($tdz) {

        var f1 = this.MouveOverInicialDaTabela;
        var f2 = this.DefinirOpacidadeTabelaSelecionada;

        $tdz.addClass('corSelecionada');

        $currentLabel = $tdz.find("label");

        $(':radio', $currentLabel).attr('checked', 'checked');

        $currentColor = $(':radio', $currentLabel).val();

        $currentLabel.css("font-weight", "bold");
        $currentLabel.prepend('<i class="fa fa-check"></i>');

        /*f1();
        f2();*/

        $("tr td.corSelecionada", $tabela).css({ opacity: 1 });
    }

    this.DefinirCliqueTabela = function () {

        var funcao = this.SelectTd;

        $("tr td:not(.notOpacity)", $tabela).css("cursor", "pointer")
        .click(function (event) {
            event.stopPropagation();
            if ($currentLabel != null) {
                $currentLabel.css("font-weight", "normal");
                $currentLabel.parent().removeClass('corSelecionada');

                $('input[radio]', $currentLabel).removeAttr('checked');

                $("i", $currentLabel).remove();


            }

            if ($("#BarrasColoridas-Sim").attr("checked") == "checked") {
                $("#BarrasColoridas-Sim").removeAttr("checked");
                $("#BarrasColoridas-Nao").click();
            }
            funcao($(this));
        });
    }

    this.SelecionarNivel = function (nivel) {
        var $td = $("tr td[data-nivel='" + nivel + "']", $tabela);
        this.SelectTd($td);
    }

    this.SalvarConfiguracao = function () {
        $.ajax({
            type: 'POST',
            url: options.SalvarConfiguracao,
            data: { idDaAnaliseDePareto: options.idDaAnaliseDePareto, corDasBarras: $currentColor, barrasColoridas: ($("#BarrasColoridas-Sim").attr("checked") == "checked") },
            success: function (data) {
                $("#tabelaItens-" + options.idDaAnaliseDePareto).parent().parent().parent().html(data);
                $("#close-modal-configurarpareto").click();
            }
        });
    }

    this.DesmarcarCores = function () {
        $currentLabel.find("i").hide();
    }

    this.MarcarCores = function () {
        $currentLabel.find("i").show();
    }

    this.setarMascaraDecimal = function (e) {
        var target = e.target || e.srcElement;
        var keycode = e.charCode || e.keyCode;
        var unsigned = true;

        if (keycode == 13) {
            $(target).blur();
            return false;
        }
        else {

            if (this.teclasNoASCIIFirefox.contains(e.originalEvent.key))
                return true;
            else
                return window.VerificarValor(target, keycode, unsigned)
        }
    }
}