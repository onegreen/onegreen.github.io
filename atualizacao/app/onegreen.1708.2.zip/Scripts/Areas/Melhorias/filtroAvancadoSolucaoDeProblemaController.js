﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.FiltroAvancadoSolucaoDeProblemaController = (function(superClass) {
  extend(FiltroAvancadoSolucaoDeProblemaController, superClass);

  function FiltroAvancadoSolucaoDeProblemaController(opcoes, recursos) {
    this.opcoes = opcoes;
    this.recursos = recursos;
    this.LimparValidacao = bind(this.LimparValidacao, this);
    this.ValidarUnidadeGerencial = bind(this.ValidarUnidadeGerencial, this);
    this.SalvarFiltro = bind(this.SalvarFiltro, this);
    this.AplicarFiltro = bind(this.AplicarFiltro, this);
    this.ExcluirFiltro = bind(this.ExcluirFiltro, this);
    this.CarregarFiltroAvancado = bind(this.CarregarFiltroAvancado, this);
    this.LoadComboRequisitos = bind(this.LoadComboRequisitos, this);
    this.ConfigurarAdicionarCampo = bind(this.ConfigurarAdicionarCampo, this);
    FiltroAvancadoSolucaoDeProblemaController.__super__.constructor.call(this, this.opcoes, this.recursos);
    this.LoadComboClassificacao();
    this.LoadComboMetodos();
    this.LoadComboSolucaoSuperior();
    this.LoadComboNorma();
    this.ConfigurarAdicionarCampo();
    this.LoadComboAreasDeResultado();
    this.LoadComboRequisitos();
    this.LoadComboElaboradores();
    this.VerificarBotaoAdicionarCampo();
    $('#AplicarFiltro', this.opcoes.Contexto).on('click', (function(_this) {
      return function() {
        return _this.AplicarFiltro();
      };
    })(this));
  }

  FiltroAvancadoSolucaoDeProblemaController.prototype.ConfigurarAdicionarCampo = function() {
    return $("#btnAdicionarCampo li").bind("click", (function(_this) {
      return function(e) {
        var $div, $el, api, campoId, valor, valorTotal;
        $el = $(e.currentTarget);
        campoId = $el.attr("campoid");
        valor = $el.attr("value");
        valorTotal = $("#CamposSelecionados").val();
        $("#CamposSelecionados").val(parseInt(valorTotal) + valor);
        $div = $("div[campoid=" + campoId + "]");
        if ($("div[campoid]:last").attr("campoid") !== $div.attr("campoid")) {
          $("div[campoid]:last").after($div);
        }
        $div.toggleClass("none");
        $el.addClass('none');
        _this.VerificarBotaoAdicionarCampo();
        api = $("#divScroll-filtro-avancado").data().jsp;
        api.reinitialise();
        return api.scrollToBottom();
      };
    })(this));
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.VerificarBotaoAdicionarCampo = function() {
    var quantidadeDeOpcoes, quantidadeDeOpcoesAdicionadas;
    quantidadeDeOpcoes = $('#btnAdicionarCampo li').length;
    quantidadeDeOpcoesAdicionadas = $('#btnAdicionarCampo li.none').length;
    if (quantidadeDeOpcoes === quantidadeDeOpcoesAdicionadas) {
      return $('#btnAdicionarCampo').hide();
    }
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.LoadComboSolucaoSuperior = function() {
    setCombo(this.opcoes.Contexto, "#NomeDaSolucaoSuperior");
    return this.SetOpcaoPadraoCombo("#NomeDaSolucaoSuperior", {
      Key: "",
      Value: "(" + this.recursos.Nenhuma + ")"
    });
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.LoadComboNorma = function() {
    var onSelect;
    onSelect = (function(_this) {
      return function() {
        if (window.RequisitosViewModel) {
          return window.RequisitosViewModel.removeAll();
        }
      };
    })(this);
    setCombo(this.opcoes.Contexto, "#NomeDaNorma", onSelect);
    return this.SetOpcaoPadraoCombo("#NomeDaNorma", {
      Key: "",
      Value: "(" + this.recursos.Nenhuma + ")"
    });
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.LoadComboRequisitos = function() {
    var $combo, $divCombo, RequisitosViewModel, onSelect;
    if (window.RequisitosViewModel) {
      window.RequisitosViewModel.removeAll();
    }
    RequisitosViewModel = {
      Requisitos: ko.observableArray(this.opcoes.RequisitosSelecionados),
      removeItem: function(requisito) {
        return this.Requisitos.remove(requisito);
      },
      removeAll: function() {
        return this.Requisitos.removeAll();
      }
    };
    window.RequisitosViewModel = RequisitosViewModel;
    ko.applyBindings(RequisitosViewModel, $('#requisitos_itens')[0]);
    $combo = $("#RequisitosCombo");
    onSelect = (function(_this) {
      return function() {
        var apiScroll;
        apiScroll = $("#divScroll-filtro-avancado").data().jsp;
        apiScroll.reinitialise();
        return apiScroll.scrollToBottom();
      };
    })(this);
    $divCombo = $combo.parents("div.autocompleter");
    onSelect = (function(_this) {
      return function() {
        var apiScroll;
        apiScroll = $("#divScroll-filtro-avancado").data().jsp;
        apiScroll.reinitialise();
        return apiScroll.scrollToBottom();
      };
    })(this);
    return $combo.autocompleter($divCombo.attr("data-url"), {
      parameters: {
        idDaNorma: function() {
          return $("#IdDaNorma").val();
        }
      },
      elementToClick: "#RequisitosComboBtn",
      multiSelectArray: RequisitosViewModel.Requisitos,
      multiSelectElement: "#requisitos_itens",
      onSelected: function() {
        return onSelect();
      }
    });
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.LoadComboClassificacao = function() {
    var select;
    select = (function(_this) {
      return function() {
        if (window.MetodosViewModel) {
          return window.MetodosViewModel.removeAll();
        }
      };
    })(this);
    return setCombo(this.opcoes.Contexto, "#ClassificacaoNome", select);
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.LoadComboElaboradores = function() {
    var $combo, $divCombo, ListaDeElaboradoresViewModel, onSelect;
    ListaDeElaboradoresViewModel = {
      ListaDeElaboradores: ko.observableArray(this.opcoes.ElaboradoresSelecionados),
      removeItem: function(elaborador) {
        return this.ListaDeElaboradores.remove(elaborador);
      }
    };
    window.ListaDeElaboradoresViewModel = ListaDeElaboradoresViewModel;
    ko.applyBindings(ListaDeElaboradoresViewModel, $('#elaboradores_itens')[0]);
    $combo = $("#ElaboradoresCombo");
    $divCombo = $combo.parents("div.autocompleter");
    onSelect = (function(_this) {
      return function() {
        var apiScroll;
        apiScroll = $("#divScroll-filtro-avancado").data().jsp;
        apiScroll.reinitialise();
        return apiScroll.scrollToBottom();
      };
    })(this);
    return $combo.autocompleter($divCombo.attr("data-url"), {
      elementToClick: "#ElaboradoresComboBtn",
      multiSelectArray: ListaDeElaboradoresViewModel.ListaDeElaboradores,
      multiSelectElement: "#elaboradores_itens",
      onSelected: function() {
        return onSelect();
      }
    });
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.LoadComboAreasDeResultado = function() {
    var $combo, $divCombo, AreasDeResultadoViewModel, onSelect;
    AreasDeResultadoViewModel = {
      AreasDeResultado: ko.observableArray(this.opcoes.AreasDeResultadoSelecionadas),
      removeItem: function(area) {
        return this.AreasDeResultado.remove(area);
      }
    };
    window.AreasDeResultadoViewModel = AreasDeResultadoViewModel;
    ko.applyBindings(AreasDeResultadoViewModel, $('#areasderesultado_itens')[0]);
    $combo = $("#AreaDeResultadoCombo");
    $divCombo = $combo.parents("div.autocompleter");
    onSelect = (function(_this) {
      return function() {
        var apiScroll;
        apiScroll = $("#divScroll-filtro-avancado").data().jsp;
        apiScroll.reinitialise();
        return apiScroll.scrollToBottom();
      };
    })(this);
    return $combo.autocompleter($divCombo.attr("data-url"), {
      elementToClick: "#AreaDeResultadoComboBtn",
      multiSelectArray: AreasDeResultadoViewModel.AreasDeResultado,
      multiSelectElement: "#areasderesultado_itens",
      onSelected: function() {
        return onSelect();
      }
    });
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.LoadComboMetodos = function() {
    var $combo, $divCombo, MetodosViewModel, onSelect;
    if (window.MetodosViewModel) {
      window.MetodosViewModel.removeAll();
    }
    MetodosViewModel = {
      Metodos: ko.observableArray(this.opcoes.MetodosSelecionados),
      removeItem: function(metodo) {
        return this.Metodos.remove(metodo);
      },
      removeAll: function() {
        return this.Metodos.removeAll();
      }
    };
    window.MetodosViewModel = MetodosViewModel;
    ko.applyBindings(MetodosViewModel, $('#metodos_itens')[0]);
    $combo = $("#MetodosCombo", this.opcoes.Contexto);
    $divCombo = $combo.parents("div.autocompleter");
    onSelect = (function(_this) {
      return function() {
        var apiScroll;
        apiScroll = $("#divScroll-filtro-avancado").data().jsp;
        apiScroll.reinitialise();
        return apiScroll.scrollToBottom();
      };
    })(this);
    return $combo.autocompleter($divCombo.attr("data-url"), {
      elementToClick: "#MetodosComboBtn",
      multiSelectArray: MetodosViewModel.Metodos,
      multiSelectElement: "#metodos_itens",
      parameters: {
        idDaClassificacao: function() {
          return $("#IdDaClassificacao").val();
        }
      },
      onSelected: function() {
        return onSelect();
      }
    });
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.CarregarFiltroAvancado = function(idFiltro) {
    return $as.Melhorias.SolucoesDeProblemas.CarregarFiltroAvancado.get({
      id: idFiltro
    }).success((function(_this) {
      return function(data) {
        $("#filtroAvancadoSolucaoDeProblemaInterno").replaceWith(data);
        _this.ConfigurarExibirFiltro();
        return $("#btnFiltroAvancado").click();
      };
    })(this));
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.ExcluirFiltro = function() {
    return $as.Melhorias.SolucoesDeProblemas.ExcluirFiltro.get({
      id: $("#IdFiltroAvancado").val()
    }).success((function(_this) {
      return function(data) {
        $("#form-filtro-avancado").parent().html(data);
        _this.ConfigurarExibirFiltro();
        return $("#filtro-aplicado").click();
      };
    })(this));
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.AplicarFiltro = function() {
    var validacaoUG, valido;
    this.LimparValidacao();
    validacaoUG = this.ValidarUnidadeGerencial();
    valido = validacaoUG;
    if (valido) {
      return $('#form-filtro-avancado').submit();
    }
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.SalvarFiltro = function() {
    var validacaoUG;
    this.LimparValidacao();
    validacaoUG = this.ValidarUnidadeGerencial();
    if (validacaoUG) {
      return $as.Melhorias.SolucoesDeProblemas.CreateEditBuscaAvancada.post($("form#form-filtro-avancado").serialize()).success((function(_this) {
        return function(data) {
          return window.GetDiv("buscaAvancada-modal-container").html(data);
        };
      })(this));
    }
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.ValidarUnidadeGerencial = function() {
    var $input, item;
    $input = $('#IdUnidadeGerencial', this.opcoes.Contexto);
    if ($input.val() === '') {
      $input.parents('.form-group').addClass('error');
      item = "<li>" + this.opcoes.MsgValidacaoUG + "</li>";
      $('.validation-summary-errors').show().find('ul').append(item);
      return false;
    }
    return true;
  };

  FiltroAvancadoSolucaoDeProblemaController.prototype.LimparValidacao = function() {
    $('.validation-summary-errors').hide().find('ul').html('');
    return $('.form-group', this.opcoes.Contexto).removeClass('error');
  };

  return FiltroAvancadoSolucaoDeProblemaController;

})(window.FiltroAvancadoBaseDeSolucaoDeProblemaController);
