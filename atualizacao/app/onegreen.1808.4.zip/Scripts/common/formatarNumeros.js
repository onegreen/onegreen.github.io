﻿this.common || (this.common = {});

common.formatar = (function() {
  function formatar() {}

  formatar.setarMascaraDecimal = function(e) {
    var keycode, target, teclasNoASCIIFirefox;
    teclasNoASCIIFirefox = ["Right", "Left", "Backspace", "Del"];
    target = e.target || e.srcElement;
    keycode = e.charCode || e.keyCode;
    if (teclasNoASCIIFirefox.contains(e.originalEvent.key)) {
      return true;
    } else {
      return window.VerificarValor(target, keycode);
    }
  };

  return formatar;

})();
