﻿$.fn.sortableTable = function(opcoes) {
  var $this, options;
  $.fn.dataTable.moment('DD/MM/YYYY');
  if (opcoes === void 0) {
    opcoes = [];
  }
  $this = $(this);
  options = {
    "paging": false,
    "info": false,
    "searching": false,
    "columnDefs": []
  };
  if ($this.hasClass('table-checkbox')) {
    options.order = [1, 'asc'];
    options.columnDefs.push({
      "targets": 0,
      "sortable": false
    });
  }
  if (opcoes.ignorarColuna !== void 0) {
    options.columnDefs.push(opcoes.ignorarColuna);
  }
  return $this.DataTable(options);
};
