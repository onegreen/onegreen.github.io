﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.ConfiguracaoInicialDeUnidade = (function(superClass) {
  extend(ConfiguracaoInicialDeUnidade, superClass);

  function ConfiguracaoInicialDeUnidade(view, recursos) {
    this.view = view;
    this.recursos = recursos;
    this.aoSalvar = bind(this.aoSalvar, this);
    this.setarNames = bind(this.setarNames, this);
    this.normalizarInputs = bind(this.normalizarInputs, this);
    this.normalizar = bind(this.normalizar, this);
    this.indexarInputs = bind(this.indexarInputs, this);
    this.novoItem = bind(this.novoItem, this);
    this.focus = bind(this.focus, this);
    this.binds = bind(this.binds, this);
    this.adicionarNovoItem = bind(this.adicionarNovoItem, this);
    this.inicializar = bind(this.inicializar, this);
    ConfiguracaoInicialDeUnidade.__super__.constructor.call(this, this.view, null);
    this.btnProximo = this.get('#btn-proximo');
    this.indexarInputs();
    this.binds();
    this.normalizar();
    setTimeout(this.inicializar, 0);
  }

  ConfiguracaoInicialDeUnidade.prototype.inicializar = function() {
    var inputs, linha, primeiroInput;
    inputs = this.get('input[type=text]');
    primeiroInput = $(inputs[0]);
    if (inputs.length === 1) {
      linha = primeiroInput.closest('li');
      return this.adicionarNovoItem(linha);
    } else {
      return primeiroInput.focus();
    }
  };

  ConfiguracaoInicialDeUnidade.prototype.adicionarNovoItem = function(linha) {
    var novoItem;
    novoItem = this.novoItem(linha.children('.js-idsuperior').val());
    linha.after(novoItem);
    this.binds();
    this.indexarInputs();
    this.normalizar();
    return $('input', novoItem).focus();
  };

  ConfiguracaoInicialDeUnidade.prototype.binds = function() {
    $(this.view).on('hide.bs.modal', (function(_this) {
      return function() {
        return _this.get('[rel=tooltip]').tooltip('hide');
      };
    })(this));
    return this.get('input[type=text]').unbind('keydown').bind("keydown", (function(_this) {
      return function(event) {
        var index, input, keyCode, linha, pai, podeExcluir;
        keyCode = event.keyCode || event.which;
        input = $( this );
        podeExcluir = input.data('podeexcluir');
        linha = input.closest('li');
        switch (keyCode) {
          case window.KeyCodes.Tab:
            event.preventDefault();
            _this.movendoHierarquia = true;
            if (event.shiftKey) {
              pai = $(linha).parent().parent();
              if (pai.is('li')) {
                $(pai).after($(linha));
              }
            } else {
              pai = linha.prev('li');
              if (pai.length) {
                $('ul:first', pai).append(linha);
              }
            }
            _this.indexarInputs();
            _this.normalizar();
            setTimeout(function() {
              return input.focus();
            }, 50);
            _this.movendoHierarquia = false;
            break;
          case window.KeyCodes.Enter:
            event.preventDefault();
            return _this.adicionarNovoItem(linha);
          case window.KeyCodes.ArrowUp:
            event.preventDefault();
            index = parseInt(input.attr('data-index')) - 1;
            return _this.focus(index);
          case window.KeyCodes.ArrowDown:
            event.preventDefault();
            index = parseInt(input.attr('data-index')) + 1;
            return _this.focus(index);
          case window.KeyCodes.Backspace:
            if ($.trim(input.val()) === '' && podeExcluir) {
              event.preventDefault();
              index = parseInt(input.attr('data-index')) - 1;
              linha.remove();
              _this.indexarInputs();
              _this.normalizar();
              return _this.focus(index);
            }
        }
      };
    })(this)).blur((function(_this) {
      return function(event) {
        var input, podeExcluir;
        if (_this.movendoHierarquia) {
          return;
        }
        input = $( this );
        podeExcluir = input.data('podeexcluir');
        if (podeExcluir) {
          if ($.trim(input.val()) === '') {
            input.closest('li').remove();
            _this.indexarInputs();
            _this.normalizar();
          }
        } else {
          if ($.trim(input.val()) === '') {
            input.tooltip('show');
          } else {
            input.tooltip('hide');
          }
        }
        _this.get('input[type=text]').each(function(index, elemento) {
          if ($.trim($(elemento).val()) === '') {
            _this.btnProximo.attr('disabled', 'disabled');
            return false;
          }
          return _this.btnProximo.removeAttr('disabled');
        });
      };
    })(this)).focus((function(_this) {
      return function(event) {
        _this.get('.selecionado').removeClass('selecionado');
        return $( this ).closest('li').addClass('selecionado');
      };
    })(this)).change((function(_this) {
      return function(event) {};
    })(this));
  };

  ConfiguracaoInicialDeUnidade.prototype.focus = function(index) {
    return $('[data-index=' + index + ']').focus();
  };

  ConfiguracaoInicialDeUnidade.prototype.novoItem = function(idSuperior) {
    var novoItem;
    novoItem = '<li><i class="fa fa-circle"></i><input type="hidden" class="js-idunidade"> <input type="hidden" value="' + idSuperior + '" class="js-idsuperior"> <input type="text" maxlength="50" class="js-sigla" data-podeexcluir="true" > <ul></ul></li>';
    return $(novoItem);
  };

  ConfiguracaoInicialDeUnidade.prototype.indexarInputs = function() {
    return this.get('input[type=text]').each((function(_this) {
      return function(index, elemento) {
        $(elemento).attr('data-index', index);
        $(elemento).closest('li').removeClass('li-odd');
        if (index % 2 === 0) {
          return $(elemento).closest('li').addClass('li-odd');
        }
      };
    })(this));
  };

  ConfiguracaoInicialDeUnidade.prototype.normalizar = function() {
    return this.get('#arvore-unidades').children().each((function(_this) {
      return function(index, elemento) {
        var name;
        name = 'unidades[' + index + ']';
        _this.setarNames(elemento, name, "");
        return _this.normalizarInputs($(elemento).children('ul'), name, $(elemento).children('.js-idunidade').val());
      };
    })(this));
  };

  ConfiguracaoInicialDeUnidade.prototype.normalizarInputs = function(elementos, name, idSuperior) {
    return elementos.children('li').each((function(_this) {
      return function(index, elemento) {
        var name2;
        name2 = name + '.Subordinadas[' + index + ']';
        _this.setarNames(elemento, name2, idSuperior);
        return _this.normalizarInputs($(elemento).children('ul'), name2, $(elemento).children('.js-idunidade').val());
      };
    })(this));
  };

  ConfiguracaoInicialDeUnidade.prototype.setarNames = function(elemento, name, idSuperior) {
    $(elemento).children('.js-idunidade').attr('name', name + '.IdDaUnidade');
    $(elemento).children('.js-idsuperior').attr('name', name + '.IdDaUnidadeSuperior').val(idSuperior);
    return $(elemento).children('.js-sigla').attr('name', name + '.SiglaDaUnidade');
  };

  ConfiguracaoInicialDeUnidade.prototype.aoSalvar = function(data) {
    return $as.Manutencao.Usuarios.ConfiguracaoInicial.get().done((function(_this) {
      return function(data) {
        return window.GetDiv('box-wizard-unidade').html(data);
      };
    })(this));
  };

  return ConfiguracaoInicialDeUnidade;

})(window.baseController);
