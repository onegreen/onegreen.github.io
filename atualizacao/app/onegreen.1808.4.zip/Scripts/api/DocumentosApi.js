﻿this.Documentos || (this.Documentos = {});

Documentos.api = (function() {
  var campoDescricaoGD, campoLinkGD, containerGD, multiSelectGD, seletorGD;

  function api() {}

  containerGD = void 0;

  seletorGD = void 0;

  multiSelectGD = void 0;

  campoDescricaoGD = void 0;

  campoLinkGD = void 0;

  api.criarDocumentosPeloGoogleDrive = function(seletor) {
    seletorGD = seletor;
    multiSelectGD = true;
    return $(seletorGD).click(function() {
      return api.loadGoogleDriveScripts(true);
    });
  };

  api.criarDocumentosPeloSkyDrive = function(seletor) {
    seletorGD = seletor;
    multiSelectGD = true;
    return $(seletorGD).click(function() {
      return api.loadSkyDriveScripts();
    });
  };

  api.criarDocumentosPeloDropBox = function(seletor) {
    return $(seletor).click(function() {
      var options;
      options = {
        success: function(files) {
          return $.ajax({
            type: "POST",
            url: DocumentosOptions.adicionarDocumentoDoDropBoxUrl,
            contentType: "application/json",
            data: JSON.stringify(files),
            success: function(data) {
              return data;
            }
          });
        },
        cancel: function() {},
        multiselect: true
      };
      return Dropbox.choose(options);
    });
  };

  api.selecionarDocumentoPeloDropBox = function(seletor, campoDescricao, campoLink, container) {
    return $(seletor, container).click(function() {
      var options;
      $("#tipo-link", "#modal-adicionar-documento").click();
      options = {
        success: function(files) {
          var file;
          file = files[0];
          $(campoDescricao, container).val(file.name);
          return $(campoLink, container).val(file.link);
        },
        cancel: function() {}
      };
      return Dropbox.choose(options);
    });
  };

  api.selecionarDocumentoPeloGoogleDrive = function(seletor, campoDescricao, campoLink, container) {
    containerGD = container;
    seletorGD = seletor;
    multiSelectGD = false;
    campoDescricaoGD = campoDescricao;
    campoLinkGD = campoLink;
    return $(seletor, container).click((function(_this) {
      return function() {
        $("#tipo-link", "#modal-adicionar-documento").click;
        return _this.loadGoogleDriveScripts(false);
      };
    })(this));
  };

  api.loadGoogleDriveScripts = function(multiSelect) {
    api.multiSelectGD = multiSelect;
    return authInGoogle(api.openPicker);
  };

  api.openPicker = function() {
    if (api.multiSelectGD) {
      google.load("picker", "1", {
        "callback": api.createPickerWithMultiSelect
      });
    } else {
      google.load("picker", "1", {
        "callback": api.createPickerWithoutMultiSelect
      });
    }
    return $('#loading').fadeOut();
  };

  api.createPickerWithMultiSelect = function() {
    var picker;
    picker = new google.picker.PickerBuilder().enableFeature(google.picker.Feature.MULTISELECT_ENABLED).setOAuthToken(window.googleOauthToken).addView(new google.picker.View(google.picker.ViewId.DOCS)).setCallback(api.pickerCallBackWithMultiSelect).build();
    return picker.setVisible(true);
  };

  api.createPickerWithoutMultiSelect = function() {
    var picker;
    picker = new google.picker.PickerBuilder().setOAuthToken(window.googleOauthToken).addView(new google.picker.View(google.picker.ViewId.DOCS)).addView(new google.picker.DocsUploadView()).setCallback(api.pickerCallBackWithoutMultiSelect).build();
    return picker.setVisible(true);
  };

  api.pickerCallBackWithMultiSelect = function(data) {
    if (data.action === google.picker.Action.PICKED) {
      return $.ajax({
        type: "POST",
        url: DocumentosOptions.adicionarDocumentoDoGoogleDriveUrl,
        contentType: "application/json",
        data: JSON.stringify(data.docs),
        success: function(data) {
          return data;
        }
      });
    }
  };

  api.pickerCallBackWithoutMultiSelect = function(data) {
    var file;
    if (data.action === google.picker.Action.PICKED) {
      file = data.docs[0];
      $(campoDescricaoGD, containerGD).val(file.name);
      return $(campoLinkGD, containerGD).val(file.url);
    }
  };

  api.selecionarDocumentoPeloSkyDrive = function(seletor, campoDescricao, campoLink, container) {
    containerGD = container;
    seletorGD = seletor;
    multiSelectGD = false;
    campoDescricaoGD = campoDescricao;
    campoLinkGD = campoLink;
    return $(seletor, container).click(function() {
      $("#tipo-link", "#modal-adicionar-documento").click;
      return api.loadSkyDriveScripts();
    });
  };

  api.loadSkyDriveScripts = function() {
    WL.init({
      client_id: DocumentosOptions.client_id,
      redirect_uri: DocumentosOptions.redirect_uri,
      scope: "wl.signin",
      response_type: "token"
    });
    return WL.login({
      "scope": "wl.skydrive wl.signin"
    }).then((function(response) {
      if (multiSelectGD) {
        api.wlCallbackWithMultiSelect();
      } else {
        api.wlCallbackWithoutMultiSelect();
      }
      return function(response) {};
    }));
  };

  api.wlCallbackWithMultiSelect = function() {
    return WL.filedialog({
      mode: "open",
      select: "multi"
    }).then(function(response) {
      var files;
      files = response.data.files;
      if (files == null) {
        files = response.data.folders;
      }
      return $.ajax({
        type: "POST",
        url: DocumentosOptions.adicionarDocumentoDoSkyDriveUrl,
        contentType: "application/json",
        data: JSON.stringify(files),
        success: function(data) {
          return data;
        }
      });
    }, function(errorResponse) {});
  };

  api.wlCallbackWithoutMultiSelect = function(data) {
    return WL.filedialog({
      mode: "open",
      select: "single"
    }).then(function(response) {
      var file;
      file = response.data.files;
      if (file == null) {
        file = response.data.folders;
      }
      file = file[0];
      $(campoDescricaoGD, containerGD).val(file.name);
      return $(campoLinkGD, containerGD).val(file.link);
    }, function(errorResponse) {});
  };

  return api;

})();
