﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.filtroAvancadoDeSolicitacoesDeLicenciamentoController = (function() {
  function filtroAvancadoDeSolicitacoesDeLicenciamentoController(options) {
    this.options = options;
    this.configurarDatePickers = bind(this.configurarDatePickers, this);
    this.loadComboEndereco = bind(this.loadComboEndereco, this);
    this.loadComboRequisitante = bind(this.loadComboRequisitante, this);
    this.configurarFiltro = bind(this.configurarFiltro, this);
    this.configurarFiltro();
    this.loadComboRequisitante();
    this.loadComboEndereco();
    this.configurarDatePickers();
  }

  filtroAvancadoDeSolicitacoesDeLicenciamentoController.prototype.configurarFiltro = function() {
    $("#filtro-avancado-de-solicitacoes").on('click', (function(_this) {
      return function() {
        return $("#filtro-avancado-de-solicitacoes-container").toggle();
      };
    })(this));
    return $("#fechar-filtro", this.options.contexto).on('click', (function(_this) {
      return function() {
        return $("#filtro-avancado-de-solicitacoes-container").toggle();
      };
    })(this));
  };

  filtroAvancadoDeSolicitacoesDeLicenciamentoController.prototype.loadComboRequisitante = function() {
    return setCombo(this.options.contexto, "#RequisitanteNome");
  };

  filtroAvancadoDeSolicitacoesDeLicenciamentoController.prototype.loadComboEndereco = function() {
    return setCombo(this.options.contexto, "#EnderecoNome");
  };

  filtroAvancadoDeSolicitacoesDeLicenciamentoController.prototype.configurarDatePickers = function() {
    return $('.date-picker', this.options.contexto).datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      autoclose: true,
      language: Globalize.culture($("html").attr("lang")).name
    });
  };

  return filtroAvancadoDeSolicitacoesDeLicenciamentoController;

})();
