﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.notasSIMPartController = (function(superClass) {
  extend(notasSIMPartController, superClass);

  function notasSIMPartController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.atualizarReferencia = bind(this.atualizarReferencia, this);
    this.removerNameEmNovaNota = bind(this.removerNameEmNovaNota, this);
    this.excluirNota = bind(this.excluirNota, this);
    this.adcionarNota = bind(this.adcionarNota, this);
    this.ativarEventos = bind(this.ativarEventos, this);
    this.descobrirElementos = bind(this.descobrirElementos, this);
    this.descobrirElementos();
    this.ativarEventos();
    this.atualizarReferencia();
    this.removerNameEmNovaNota();
    $(this.view).closest("form").attr("action", this.options.FormURL);
  }

  notasSIMPartController.prototype.descobrirElementos = function() {
    this.containerNotas = this.get('#ContainerNotas');
    this.containerNovaNota = this.get('#ContainerNovaNota');
    return this.botaoAdicionar = this.get('#BotaoAdicionarNota');
  };

  notasSIMPartController.prototype.ativarEventos = function() {
    return this.botaoAdicionar.unbind('click').click(this.adcionarNota);
  };

  notasSIMPartController.prototype.adcionarNota = function() {
    this.containerNotas.append(this.containerNovaNota.html());
    this.atualizarReferencia();
    return BindDatePickers();
  };

  notasSIMPartController.prototype.excluirNota = function() {};

  notasSIMPartController.prototype.removerNameEmNovaNota = function() {
    return $('input', this.containerNovaNota).attr('Name', '');
  };

  notasSIMPartController.prototype.atualizarReferencia = function() {
    var i, indice, input, inputs, j, len, len1, nome, nota, notas, results;
    notas = $('.js-Nota', this.containerNotas);
    inputs = $('input', notas);
    indice = 0;
    results = [];
    for (i = 0, len = notas.length; i < len; i++) {
      nota = notas[i];
      inputs = $('.js-InputNota', nota);
      for (j = 0, len1 = inputs.length; j < len1; j++) {
        input = inputs[j];
        nome = $(input).attr('vinculo');
        $(input).attr('name', "Notas[" + indice + "]." + nome);
      }
      results.push(indice++);
    }
    return results;
  };

  return notasSIMPartController;

})(window.baseController);
