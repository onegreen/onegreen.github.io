﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.SIMPartsDeIndicador = (function(superClass) {
  extend(SIMPartsDeIndicador, superClass);

  function SIMPartsDeIndicador(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.definirBloqueioDeCombo = bind(this.definirBloqueioDeCombo, this);
    this.construirJSONItem = bind(this.construirJSONItem, this);
    this.resolverRelacionamentosNosCards = bind(this.resolverRelacionamentosNosCards, this);
    this.definirBloqueios = bind(this.definirBloqueios, this);
    this.ativarOrdenacao = bind(this.ativarOrdenacao, this);
    this.habilitarBotoesAdicao = bind(this.habilitarBotoesAdicao, this);
    this.desabilitarBotoesAdicao = bind(this.desabilitarBotoesAdicao, this);
    this.obterNomeDaFrequencia = bind(this.obterNomeDaFrequencia, this);
    this.obterLimiteFrequencia = bind(this.obterLimiteFrequencia, this);
    this.verificarLimitesDeAtraso = bind(this.verificarLimitesDeAtraso, this);
    this.EPossivelGerarPreviewPara = bind(this.EPossivelGerarPreviewPara, this);
    this.getFormaDeVisualizacao = bind(this.getFormaDeVisualizacao, this);
    this.adicionarEFecharModal = bind(this.adicionarEFecharModal, this);
    this.fecharModal = bind(this.fecharModal, this);
    this.aoAlterarContianer = bind(this.aoAlterarContianer, this);
    this.atualizarPreviewDaDescricao = bind(this.atualizarPreviewDaDescricao, this);
    this.configurarEdicaoDoCartao = bind(this.configurarEdicaoDoCartao, this);
    this.ativarEventosModal = bind(this.ativarEventosModal, this);
    this.removerCartao = bind(this.removerCartao, this);
    this.ativarEventos = bind(this.ativarEventos, this);
    this.podeAdicionar = bind(this.podeAdicionar, this);
    this.atualizarBotaoAdicionar = bind(this.atualizarBotaoAdicionar, this);
    this.encontrarElementos = bind(this.encontrarElementos, this);
    this.carregarComboFrequencia = bind(this.carregarComboFrequencia, this);
    this.carregarComboUnidadeGerencial = bind(this.carregarComboUnidadeGerencial, this);
    this.carregarComboIndicador = bind(this.carregarComboIndicador, this);
    this.ativarCombos = bind(this.ativarCombos, this);
    this.updateIdentificacaoDoIndicador = bind(this.updateIdentificacaoDoIndicador, this);
    this.atualizarOrdem = bind(this.atualizarOrdem, this);
    this.aoSelecionarFrequencia = bind(this.aoSelecionarFrequencia, this);
    this.aoSelecionarIndicador = bind(this.aoSelecionarIndicador, this);
    this.resetarIndicador = bind(this.resetarIndicador, this);
    this.aoSelecionarUnidade = bind(this.aoSelecionarUnidade, this);
    this.abrirModal = bind(this.abrirModal, this);
    this.mostrarModalDeEdicao = bind(this.mostrarModalDeEdicao, this);
    this.load = bind(this.load, this);
    SIMPartsDeIndicador.__super__.constructor.call(this, this.view);
    this.load();
  }

  SIMPartsDeIndicador.prototype.load = function() {
    this.encontrarElementos();
    this.ativarOrdenacao();
    this.updateIdentificacaoDoIndicador();
    this.ativarEventos();
    this.resolverRelacionamentosNosCards();
    $(this.view).closest("form").attr("action", this.options.FormURL);
    this.get('.js-BotoesDoCartao').removeClass("hide").addClass("mostrar");
    this.get('#indicativos-comentarios-planodeacao').hide();
    if (this.get(".js-ItemDeIndicador").length === 0) {
      this.mostrarModalDeEdicao();
    }
    return this.definirBloqueios();
  };

  SIMPartsDeIndicador.prototype.mostrarModalDeEdicao = function() {
    return $as.ReportSIM.SIMParts.CreateCartaoDeIndicador.get().done((function(_this) {
      return function(html) {
        _this.abrirModal(html);
        return _this.ativarEventosModal(_this.adicionarEFecharModal);
      };
    })(this));
  };

  SIMPartsDeIndicador.prototype.abrirModal = function(html) {
    this.get("#modalDeEdicao").html(html);
    $(".modal", this.get("#modalDeEdicao")).window({
      width: 780,
      height: 470
    });
    this.encontrarElementos();
    this.ativarCombos();
    return this.Ordem = $('.js-OrdemItemDeIndicador', this.get("#PreviewDoCartao")).val();
  };

  SIMPartsDeIndicador.prototype.aoSelecionarUnidade = function() {
    this.resetarIndicador();
    this.IdFrequencia = 0;
    this.InputFrequencia.data('autocompleter').reset();
    this.carregarComboFrequencia();
    return this.definirBloqueios();
  };

  SIMPartsDeIndicador.prototype.resetarIndicador = function() {
    this.get("#DetalhesDoCartao").html('');
    this.IdIndicador = 0;
    this.InputIndicador.data('autocompleter').reset();
    return this.carregarComboIndicador();
  };

  SIMPartsDeIndicador.prototype.aoSelecionarIndicador = function() {
    this.IdFrequencia = 0;
    this.InputFrequencia.data('autocompleter').reset();
    this.carregarComboFrequencia();
    this.definirBloqueios();
    this.updateIdentificacaoDoIndicador();
    return this.get("#DetalhesDoCartao").html('');
  };

  SIMPartsDeIndicador.prototype.aoSelecionarFrequencia = function() {
    this.updateIdentificacaoDoIndicador();
    return this.construirPreview();
  };

  SIMPartsDeIndicador.prototype.atualizarOrdem = function() {
    var card, i, j, len, ref, results;
    i = 0;
    ref = $(".js-ItemDeIndicador", this.ItensContainer);
    results = [];
    for (j = 0, len = ref.length; j < len; j++) {
      card = ref[j];
      $(".js-OrdemItemDeIndicador", card).val(i);
      results.push(i++);
    }
    return results;
  };

  SIMPartsDeIndicador.prototype.updateIdentificacaoDoIndicador = function() {
    this.IdUnidade = this.get("#UnidadeGerencial_Id").val();
    this.IdIndicador = this.get("#Indicador_Id").val();
    this.IdFrequencia = this.get("#Frequencia_Id").val();
    return this.atualizarBotaoAdicionar();
  };

  SIMPartsDeIndicador.prototype.ativarCombos = function() {
    this.carregarComboUnidadeGerencial();
    this.carregarComboIndicador();
    this.carregarComboFrequencia();
    return this.definirBloqueios();
  };

  SIMPartsDeIndicador.prototype.carregarComboIndicador = function() {
    return Results.api.setComboIndicador(this.options.SeletorContexto, '#Indicador_Nome', this.aoSelecionarIndicador, {
      idUnidadeGerencial: (function(_this) {
        return function() {
          return _this.IdUnidade;
        };
      })(this)
    });
  };

  SIMPartsDeIndicador.prototype.carregarComboUnidadeGerencial = function() {
    return setCombo(this.options.SeletorContexto, '#UnidadeGerencial_Nome', this.aoSelecionarUnidade);
  };

  SIMPartsDeIndicador.prototype.carregarComboFrequencia = function() {
    return setCombo(this.options.SeletorContexto, '#Frequencia_Nome', this.aoSelecionarFrequencia, {
      idIndicador: (function(_this) {
        return function() {
          return _this.IdIndicador;
        };
      })(this)
    });
  };

  SIMPartsDeIndicador.prototype.encontrarElementos = function() {
    this.BotaoAdicionar = this.get("#AdicionarCardDoIndicador");
    this.BotaoAdicionarEFechar = this.get("#AdicionarCardDoIndicadorEFechar");
    this.InputDescricao = this.get("#DescricaoDoCartaoDoIndicador");
    this.ItensContainer = this.get("#CardsDeIndicadorContainer");
    this.InputUnidade = this.get("#UnidadeGerencial_Nome");
    this.InputIndicador = this.get("#Indicador_Nome");
    this.InputFrequencia = this.get("#Frequencia_Nome");
    return this.ContainerDoPreview = this.get("#DetalhesDoCartao");
  };

  SIMPartsDeIndicador.prototype.atualizarBotaoAdicionar = function() {
    this.BotaoAdicionar.attr("disabled", "disabled");
    this.BotaoAdicionarEFechar.attr("disabled", "disabled");
    if (this.podeAdicionar()) {
      this.BotaoAdicionar.removeAttr("disabled");
      return this.BotaoAdicionarEFechar.removeAttr("disabled");
    }
  };

  SIMPartsDeIndicador.prototype.podeAdicionar = function() {
    return this.IdUnidade && this.IdIndicador && this.IdFrequencia;
  };

  SIMPartsDeIndicador.prototype.ativarEventos = function() {
    this.get("#BotaoAdicionar").unbind("click").bind("click", (function(_this) {
      return function() {
        return _this.mostrarModalDeEdicao();
      };
    })(this));
    this.get(".js-RemoverCartao").unbind("click").bind("click", this.removerCartao);
    this.get(".js-EditarCartao").unbind("click").bind("click", this.editarCartao);
    return this.get("[title]").tooltip();
  };

  SIMPartsDeIndicador.prototype.removerCartao = function(event) {
    $(event.delegateTarget).closest('.js-ItemDeIndicador').remove();
    this.resolverRelacionamentosNosCards();
    return $(".tooltip").hide();
  };

  SIMPartsDeIndicador.prototype.ativarEventosModal = function(funcaoDeAlteracao) {
    $(".js-painel-container").draggable("destroy");
    this.BotaoAdicionar.unbind("click").bind("click", funcaoDeAlteracao);
    this.BotaoAdicionarEFechar.unbind("click").bind("click", (function(_this) {
      return function() {
        return _this.adicionar(false);
      };
    })(this));
    this.get("#FecharTelaEdicaoDeCards").unbind('click').click(this.fecharModal);
    $(".modal-header .close", this.get("#modalDeEdicao")).bind('click', this.fecharModal);
    this.get("#FormaDeVisualizacaoApurado").unbind("click").bind("click", this.construirPreview);
    return this.get("#FormaDeVisualizacaoAcumulado").unbind("click").bind("click", this.construirPreview);
  };

  SIMPartsDeIndicador.prototype.configurarEdicaoDoCartao = function() {
    $("#DescricaoDoCartaoDoIndicador", this.ContainerDoPreview).keyup(this.atualizarPreviewDaDescricao);
    $("#Atraso", this.ContainerDoPreview).change(this.construirPreview);
    this.get("#MostrarData-Sim").change(this.construirPreview);
    this.get("#MostrarData-Nao").change(this.construirPreview);
    return this.get("[title]").tooltip();
  };

  SIMPartsDeIndicador.prototype.atualizarPreviewDaDescricao = function(event) {
    var descricaoPadraoContainer, descricaoPersonalizadaContainer, valor;
    valor = $(event.delegateTarget).val();
    descricaoPersonalizadaContainer = $("#DescricaoPersonalizada", this.ContainerDoPreview);
    descricaoPadraoContainer = $("#DescricaoPadrao", this.ContainerDoPreview);
    $(".js-DescricaoPersonalizada", descricaoPersonalizadaContainer).html(valor);
    $(".js-NomeDoCartao", this.ContainerDoPreview).val(valor);
    if (valor.length) {
      descricaoPadraoContainer.hide();
      return descricaoPersonalizadaContainer.show();
    } else {
      descricaoPadraoContainer.show();
      return descricaoPersonalizadaContainer.hide();
    }
  };

  SIMPartsDeIndicador.prototype.aoAlterarContianer = function() {
    this.get(".js-NaoVisivelNaEdicaoDoItem").fadeOut();
    this.resolverRelacionamentosNosCards();
    this.ativarOrdenacao();
    this.atualizarOrdem();
    this.ativarEventos();
    this.get('.js-BotoesDoCartao').removeClass("hide").addClass("mostrar");
    return this.get('#indicativos-comentarios-planodeacao').hide();
  };

  SIMPartsDeIndicador.prototype.fecharModal = function() {
    this.get("#close-modal-simpartdeindicador").unbind('click').click();
    return $(".js-painel-container").draggable({
      revert: "invalid"
    });
  };

  SIMPartsDeIndicador.prototype.adicionarEFecharModal = function() {
    this.adicionar();
    return this.fecharModal();
  };

  SIMPartsDeIndicador.prototype.getFormaDeVisualizacao = function() {
    if (this.get("#FormaDeVisualizacaoApurado").is(":checked")) {
      return 1;
    }
    return 2;
  };

  SIMPartsDeIndicador.prototype.EPossivelGerarPreviewPara = function(indicador) {
    return indicador.frequencia !== void 0 && indicador.frequencia !== "0" && indicador.frequencia !== "" && indicador.idIndicador !== void 0 && indicador.idIndicador !== "0" && indicador.idIndicador !== "" && this.verificarLimitesDeAtraso(indicador.atraso, indicador.frequencia);
  };

  SIMPartsDeIndicador.prototype.verificarLimitesDeAtraso = function(atraso, frequencia) {
    var limite, mensagem;
    if (isNaN(atraso) || atraso.lenght === 0) {
      return false;
    }
    limite = this.obterLimiteFrequencia(frequencia);
    atraso = parseInt(atraso);
    this.get('#Atraso').val(parseInt(atraso));
    if (parseFloat(atraso) % 1 !== 0) {
      mensagem = '<ul><li>' + String.format(Resource.OValorInformadoParaOCampoXNaoEValido, Resource.DataRelativa) + '</li></ul>';
      this.get('#error-summary').html(mensagem);
      this.get('#Atraso').val(0);
      return false;
    }
    if (atraso < 0) {
      mensagem = '<ul><li>' + String.format(Resource.OCampoXDeveSerMaiorQueZero, Resource.DataRelativa) + '</li></ul>';
      this.get('#error-summary').html(mensagem);
      this.get('#Atraso').val(0);
      return false;
    } else if (atraso > limite) {
      mensagem = '<ul><li>' + String.format(Resource.OAtrasoMaximoPermitidoEDeX, limite + ' ' + this.obterNomeDaFrequencia(frequencia)) + '</li></ul>';
      this.get('#error-summary').html(mensagem);
      this.get('#Atraso').val(limite);
      return false;
    } else {
      this.get('#Atraso').val(atraso);
      return true;
    }
  };

  SIMPartsDeIndicador.prototype.obterLimiteFrequencia = function(frequencia) {
    var limiteAtual;
    limiteAtual = 4;
    switch (frequencia) {
      case "1":
        limiteAtual = limiteAtual * 12;
        break;
      case "2":
        limiteAtual = limiteAtual * 52;
        break;
      case "3":
        limiteAtual = limiteAtual * 365;
        break;
      default:
        limiteAtual = limiteAtual * 365;
    }
    return limiteAtual;
  };

  SIMPartsDeIndicador.prototype.obterNomeDaFrequencia = function(frequencia) {
    switch (frequencia) {
      case "1":
        frequencia = Resource.Meses;
        break;
      case "2":
        frequencia = Resource.Semanas;
        break;
      case "3":
        frequencia = Resource.Dias;
        break;
      default:
        frequencia = Resource.Indefinido;
    }
    return frequencia;
  };

  SIMPartsDeIndicador.prototype.desabilitarBotoesAdicao = function() {
    this.get('#AdicionarCardDoIndicador').attr('disabled', 'disabled');
    return this.get('#AdicionarCardDoIndicadorEFechar').attr('disabled', 'disabled');
  };

  SIMPartsDeIndicador.prototype.habilitarBotoesAdicao = function() {
    this.get('#AdicionarCardDoIndicador').removeAttr('disabled');
    return this.get('#AdicionarCardDoIndicadorEFechar').removeAttr('disabled');
  };

  SIMPartsDeIndicador.prototype.ativarOrdenacao = function() {
    if (this.ItensContainer) {
      this.ItensContainer.sortable({
        update: this.atualizarOrdem,
        opacity: 0.7,
        revert: 400,
        tolerance: "pointer"
      });
      return this.ItensContainer.disableSelection();
    }
  };

  SIMPartsDeIndicador.prototype.definirBloqueios = function() {
    this.updateIdentificacaoDoIndicador();
    this.definirBloqueioDeCombo(this.InputIndicador, !this.IdUnidade);
    return this.definirBloqueioDeCombo(this.InputFrequencia, !this.IdIndicador);
  };

  SIMPartsDeIndicador.prototype.resolverRelacionamentosNosCards = function() {
    var campo, i, item, j, k, len, len1, ref, ref1, results;
    i = 0;
    ref = $(".js-ItemDeIndicador", this.ItensContainer);
    results = [];
    for (j = 0, len = ref.length; j < len; j++) {
      item = ref[j];
      ref1 = $("[type=hidden]", item);
      for (k = 0, len1 = ref1.length; k < len1; k++) {
        campo = ref1[k];
        $(campo).attr("name", (this.ReferenciaLista + "[" + i + "].") + $(campo).attr("vinculo"));
      }
      results.push(i++);
    }
    return results;
  };

  SIMPartsDeIndicador.prototype.construirJSONItem = function() {
    var atraso, indicador, ordem;
    ordem = -1;
    atraso = parseInt($("#Atraso", this.ContainerDoPreview).val());
    if (this.Ordem) {
      ordem = this.Ordem;
    }
    if (isNaN(atraso) || atraso === void 0 || atraso.lenght === 0 || atraso === "") {
      atraso = 0;
    }
    indicador = {
      nome: this.InputDescricao.val(),
      idIndicador: this.IdIndicador,
      frequencia: this.IdFrequencia,
      atraso: atraso,
      nome: $("#DescricaoDoCartaoDoIndicador", this.ContainerDoPreview).val(),
      ordem: ordem,
      mostrarData: this.get("#MostrarData-Sim").is(":checked"),
      formaDeVisualizacao: this.getFormaDeVisualizacao()
    };
    return indicador;
  };

  SIMPartsDeIndicador.prototype.definirBloqueioDeCombo = function(input, bloquear) {
    if (input.data('autocompleter')) {
      return input.data('autocompleter').disableElseEnable(bloquear);
    }
  };

  return SIMPartsDeIndicador;

})(window.baseController);
