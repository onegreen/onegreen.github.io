﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.documentosVinculados = (function() {
  function documentosVinculados(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.vinculoDeLink = bind(this.vinculoDeLink, this);
    this.vinculoDeArquivo = bind(this.vinculoDeArquivo, this);
    this.tabArquivo = $('#tabArquivo', this.contexto);
    this.tabLink = $('#tabLink', this.contexto);
    this.tipoDeVinculo = $('#TipoVinculoDocumento', this.contexto);
    this.tabArquivo.click(this.vinculoDeArquivo);
    this.tabLink.click(this.vinculoDeLink);
    setTimeout(function() {
      return $('#modal-adicionar-documento').window({
        width: '700px'
      });
    }, 5);
    $('#modal-adicionar-documento').css('z-index', WindowZIndex++);
  }

  documentosVinculados.prototype.vinculoDeArquivo = function() {
    return this.tipoDeVinculo.val(this.options.ehArquivo);
  };

  documentosVinculados.prototype.vinculoDeLink = function() {
    return this.tipoDeVinculo.val(this.options.ehLink);
  };

  return documentosVinculados;

})();
