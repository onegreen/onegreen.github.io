﻿if (!sb_windowTools) { var sb_windowTools = new Object(); };

sb_windowTools = {
    scrollBarPadding: 17, // padding to assume for scroll bars

    // EXAMPLE METHODS
    // center an element in the viewport
    centerElementOnScreen: function (element) {
        var pageDimensions = this.updateDimensions();
        element.style.top = ((this.pageDimensions.verticalOffsetTop() + this.pageDimensions.windowHeight() / 2) - (this.scrollBarPadding + element.offsetHeight / 2)) + 'px';
        element.style.left = ((this.pageDimensions.windowWidth() / 2) - (this.scrollBarPadding + element.offsetWidth / 2)) + 'px';
        element.style.position = 'fixed';
    },

    // INFORMATION GETTERS
    // load the page size, view port position and vertical scroll offset
    updateDimensions: function () {
        this.updatePageSize();
        this.updateWindowSize();
        this.updateScrollOffset();
    },

    // load page size information
    updatePageSize: function () {
        // document dimensions
        var viewportWidth, viewportHeight;
        if (window.innerHeight && window.scrollMaxY) {
            viewportWidth = document.body.scrollWidth;
            viewportHeight = window.innerHeight + window.scrollMaxY;
        } else if (document.body.scrollHeight > document.body.offsetHeight) {
            // all but explorer mac
            viewportWidth = document.body.scrollWidth;
            viewportHeight = document.body.scrollHeight;
        } else {
            // explorer mac...would also work in explorer 6 strict, mozilla and safari
            viewportWidth = document.body.offsetWidth;
            viewportHeight = document.body.offsetHeight;
        };
        this.pageSize = {
            viewportWidth: viewportWidth,
            viewportHeight: viewportHeight
        };
    },

    // load window size information
    updateWindowSize: function () {
        // view port dimensions
        var windowWidth, windowHeight;
        if (self.innerHeight) {
            // all except explorer
            windowWidth = self.innerWidth;
            windowHeight = self.innerHeight;
        } else if (document.documentElement && document.documentElement.clientHeight) {
            // explorer 6 strict mode
            windowWidth = document.documentElement.clientWidth;
            windowHeight = document.documentElement.clientHeight;
        } else if (document.body) {
            // other explorers
            windowWidth = document.body.clientWidth;
            windowHeight = document.body.clientHeight;
        };
        this.windowSize = {
            windowWidth: windowWidth,
            windowHeight: windowHeight
        };
    },

    // load scroll offset information
    updateScrollOffset: function () {
        // viewport vertical scroll offset
        var horizontalOffset, verticalOffsetTop, verticalOffsetBottom;
        if (self.pageYOffset) {
            horizontalOffset = self.pageXOffset;
            verticalOffsetTop = self.pageYOffset;
            verticalOffsetBottom = self.pageYOffset - self.innerHeight;
        } else if (document.documentElement && document.documentElement.scrollBottom && document.documentElement.scrollTop) {
            // Explorer 6 Strict
            horizontalOffset = document.documentElement.scrollLeft;
            verticalOffsetBottom = document.documentElement.scrollBottom;
            verticalOffsetTop = document.documentElement.scrollTop;
        } else if (document.body) {
            // all other Explorers
            horizontalOffset = document.body.scrollLeft;
            verticalOffsetBottom = document.body.scrollBottom;
            verticalOffsetTop = document.body.scrollTop;
        };
        this.scrollOffset = {
            horizontalOffset: horizontalOffset,
            verticalOffsetBottom: verticalOffsetBottom,
            verticalOffsetTop: verticalOffsetTop
        };
    },

    // INFORMATION CONTAINERS
    // raw data containers
    pageSize: {},
    windowSize: {},
    scrollOffset: {},

    // combined dimensions object with bounding logic
    pageDimensions: {
        pageWidth: function () {
            return sb_windowTools.pageSize.viewportWidth > sb_windowTools.windowSize.windowWidth ?
                sb_windowTools.pageSize.viewportWidth :
                sb_windowTools.windowSize.windowWidth;
        },
        pageHeight: function () {
            return sb_windowTools.pageSize.viewportHeight > sb_windowTools.windowSize.windowHeight ?
                sb_windowTools.pageSize.viewportHeight :
                sb_windowTools.windowSize.windowHeight;
        },
        windowWidth: function () {
            return sb_windowTools.windowSize.windowWidth;
        },
        windowHeight: function () {
            return sb_windowTools.windowSize.windowHeight;
        },
        horizontalOffset: function () {
            return sb_windowTools.scrollOffset.horizontalOffset;
        },
        verticalOffsetTop: function () {
            return sb_windowTools.scrollOffset.verticalOffsetTop;
        },
        verticalOffsetBottom: function () {
            return sb_windowTools.scrollOffset.verticalOffsetBottom;
        }
    }
};

window.onscroll = function () {
    sb_windowTools.updateScrollOffset();

    /*if (sb_windowTools.pageDimensions.verticalOffsetTop() > 140) {
        if ($('nav').css('position') != 'fixed') {
            $('nav').hide();
            $('nav').css({ top: 0, left:204, position: 'fixed' });
            $('nav').fadeIn();
        }
    }
    else
        $('nav').css({ top: 0, left:0, position: 'relative' });*/
    /*if (externCaller)
    $('#modal').css({ top: (sb_windowTools.pageDimensions.verticalOffsetTop() + (sb_windowTools.pageDimensions.windowHeight() / 2)) - $('#modal').outerHeight() / 2 + 'px' }); //.animate({ top: (sb_windowTools.pageDimensions.verticalOffsetTop() + (sb_windowTools.pageDimensions.windowHeight() / 2)) - $('#modal').outerHeight() / 2 + 'px' }, { duration: 500, queue: false });*/
};

jQuery.fn.center = function () {
    this.css("position", "absolute");
    this.css("top", Math.max(0, (($(window).height() - $(this).outerHeight()) / 2) +
                                                $(window).scrollTop()) + "px");
    this.css("left", Math.max(0, (($(window).width() - $(this).outerWidth()) / 2) +
                                                $(window).scrollLeft()) + "px");
    return this;
}