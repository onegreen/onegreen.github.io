﻿window.SetPopoverDoUsuarioLogado = function() {
  return $(".infoMeuUsuario").click(function() {
    var $el, data, idDoUsuario, placement;
    $el = $(".infoMeuUsuario");
    if ($el.attr('data-status') === 'closed') {
      placement = $el.attr('placement');
      idDoUsuario = $el.data('id');
      data = $('#popover-usuario');
      popover.target = $el;
      popover.titulo = $('#title', data).html();
      popover.conteudo = $('#content', data).html();
      popover.placement = placement;
      popover.closeCallBack = function() {
        return $(".infoMeuUsuario").attr('data-status', 'closed');
      };
      $el.attr('data-status', 'opened');
      popover.show('1000');
    } else {
      $el.attr('data-status', 'closed');
      popover.hide('1000');
    }
    return false;
  });
};

window.popoverUsuario = {
  on: function(contexto) {
    contexto = contexto ? contexto : '';
    $('span.usuario, a.usuario', contexto).unbind('click');
    $('span.usuario, a.usuario', contexto).click(function() {
      return popoverUsuario.mostrarEsconder($(this));
    });
  },
  mostrarEsconder: function($el, url) {
    var idUsuario, popoverExiste, seletorPopover;
    idUsuario = $el.data('idusuario');
    if (idUsuario == null) {
      idUsuario = $el.attr('id');
    }
    seletorPopover = '#popoverUsuario-' + idUsuario;
    popoverExiste = $(seletorPopover).is(":visible");
    $el.attr('show', true);
    if (popoverExiste) {
      popover.close($(seletorPopover));
    } else {
      popoverUsuario.mostrar($el, url);
    }
    return false;
  },
  mostrar: function(target, url) {
    var idDoUsuario, placement;
    if (url == null) {
      url = CompleteHostAdress + "/API/Usuarios/DetalheDoUsuario";
    }
    if (!target.attr('noHideOthers')) {
      $('.popover').remove();
    }
    placement = target.attr('placement');
    idDoUsuario = target.data('idusuario');
    if (idDoUsuario == null) {
      idDoUsuario = target.attr('id');
    }
    if (popover.target !== target) {
      $.ajax({
        type: "Get",
        async: false,
        global: false,
        url: url,
        data: {
          idDoUsuario: idDoUsuario
        },
        success: function(data) {
          popover.target = target;
          popover.titulo = $('#title', data).html();
          popover.conteudo = $('#content', data).html();
          return popover.placement = placement;
        }
      });
      $('.popover').show();
      popover.show();
    } else {
      popover.target = '';
    }
  }
};
