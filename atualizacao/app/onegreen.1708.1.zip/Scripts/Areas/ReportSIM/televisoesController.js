﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.televisoesController = (function() {
  function televisoesController(contexto1, resources) {
    this.contexto = contexto1;
    this.resources = resources;
    this.cancelar = bind(this.cancelar, this);
    this.salvarApresentacao = bind(this.salvarApresentacao, this);
    this.informarCodigo = bind(this.informarCodigo, this);
    this.salvarEIrParaSelecaoDeApresentacao = bind(this.salvarEIrParaSelecaoDeApresentacao, this);
    window.MarcarMenuSuperior("#lnkTelevisoes");
    this.containerPassos = $('#add-tv-container', this.contexto);
    this.containerTelevisoes = $('#televisoes-container');
    this.btnAdicionarTv = $('#js-add-tv', this.contexto);
    this.btnAdicionarTv.click(this.informarCodigo);
    window.tvsOnline = $.connection.tvsOnlineHub;
    tvsOnline.client.tvconectada = (function(_this) {
      return function(codigo) {
        $("#tv-status-" + codigo).removeClass('sc-off').addClass('sc-on');
        return $("#tv-status-" + codigo).find('.sc-text').text(_this.resources.TVLigada);
      };
    })(this);
    tvsOnline.client.tvdesconectada = (function(_this) {
      return function(codigo) {
        $("#tv-status-" + codigo).removeClass('sc-on').addClass('sc-off');
        return $("#tv-status-" + codigo).find('.sc-text').text(_this.resources.TVDesligada);
      };
    })(this);
    $.connection.hub.start().done(function() {
      var i, j, len, results, tv, tvCode, tvs;
      tvs = $('.js-tv-status');
      results = [];
      for (i = j = 0, len = tvs.length; j < len; i = ++j) {
        tv = tvs[i];
        tvCode = $(tv).data('codigo');
        results.push(window.tvsOnline.server.join(tvCode));
      }
      return results;
    });
  }

  televisoesController.prototype.salvarEIrParaSelecaoDeApresentacao = function() {
    return $as.ReportSIM.Televisoes.CreateEdit.post(this.containerPassos.find('input').serialize()).done((function(_this) {
      return function(data) {
        return _this.containerPassos.html(data);
      };
    })(this));
  };

  televisoesController.prototype.informarCodigo = function() {
    return $as.ReportSIM.Televisoes.InformarCodigo.get().done((function(_this) {
      return function(data) {
        _this.containerPassos.html(data);
        return setTimeout((function() {
          return $('#Codigo', this.contexto).focus();
        }), 1);
      };
    })(this));
  };

  televisoesController.prototype.postarCodigo = function() {
    var codigo;
    codigo = $('#Codigo', this.contexto).val();
    return $as.ReportSIM.Televisoes.PostarCodigo.post({
      codigo: codigo
    }).done((function(_this) {
      return function(data) {
        _this.containerPassos.html(data);
        return setTimeout((function() {
          return $('.add-tv', this.contexto).addClass('active');
        }), 1);
      };
    })(this));
  };

  televisoesController.prototype.postarNome = function() {
    return $as.ReportSIM.Televisoes.PostarNome.post(this.containerPassos.find('input').serialize()).done((function(_this) {
      return function(data) {
        _this.containerPassos.html(data);
        return setTimeout((function() {
          return $('.add-tv', this.contexto).addClass('active');
        }), 1);
      };
    })(this));
  };

  televisoesController.prototype.salvarApresentacao = function(e) {
    var container, idDaApresentacao, idDaTv;
    idDaTv = e.parent().closest('.js-apresentacao-tv').find('#Id').val();
    idDaApresentacao = $('#Apresentacao_Id', this.contexto).val();
    container = $("#tv-container-" + idDaTv);
    return $as.ReportSIM.Televisoes.SalvarApresentacao.post({
      idDaTv: idDaTv,
      idDaApresentacao: idDaApresentacao
    }).done((function(_this) {
      return function(data) {
        if (data.success) {
          return _this.recarregarTvs();
        }
      };
    })(this));
  };

  televisoesController.prototype.selecionarApresentacao = function(id) {
    var container;
    container = $("#tv-container-" + id);
    return $as.ReportSIM.Televisoes.SelecionarApresentacao.get({
      idDaTv: id
    }).done((function(_this) {
      return function(data) {
        container.html(data);
        return setTimeout((function() {
          return $('.add-tv', this.contexto).addClass('active');
        }), 1);
      };
    })(this));
  };

  televisoesController.prototype.configurarComboApresentacoes = function() {
    return setCombo(this.contexto, '#Apresentacao_Nome', this.salvarApresentacao);
  };

  televisoesController.prototype.configurarComboUG = function(id) {
    var contexto;
    contexto = "#tv-container-" + id;
    return setCombo(contexto, '#UnidadeGerencial_SiglaAtual');
  };

  televisoesController.prototype.editarTelevisao = function(id) {
    var container;
    container = $("#tv-container-" + id);
    return $as.ReportSIM.Televisoes.EditarTelevisao.get({
      idDaTv: id
    }).done((function(_this) {
      return function(data) {
        container.html(data);
        return setTimeout((function() {
          return $('.add-tv', this.contexto).addClass('active');
        }), 1);
      };
    })(this));
  };

  televisoesController.prototype.salvarTelevisao = function(id) {
    var container;
    container = $("#tv-container-" + id);
    return $as.ReportSIM.Televisoes.SalvarTelevisao.post(container.find('input').serialize()).done((function(_this) {
      return function(data) {
        container.html(data);
        return setTimeout((function() {
          return $('.add-tv', this.contexto).addClass('active');
        }), 1);
      };
    })(this));
  };

  televisoesController.prototype.cancelar = function(id) {
    var container;
    if (id) {
      container = $("#tv-container-" + id);
      return $as.ReportSIM.Televisoes.Televisao.get({
        idDaTv: id
      }).done((function(_this) {
        return function(data) {
          container.html(data);
          return setTimeout((function() {
            return $('.add-tv', this.contexto).addClass('active');
          }), 1);
        };
      })(this));
    } else {
      return this.recarregarTvs();
    }
  };

  televisoesController.prototype.recarregarTvs = function() {
    return $as.ReportSIM.Televisoes.RecarregarTelevisoes.get().done((function(_this) {
      return function(data) {
        return _this.containerTelevisoes.html(data);
      };
    })(this));
  };

  return televisoesController;

})();
