﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.tvHubController = (function() {
  function tvHubController(options) {
    this.options = options;
    this.executarApresentacao = bind(this.executarApresentacao, this);
    this.iniciarApresentacao = bind(this.iniciarApresentacao, this);
    $('body').attr('data-ignore-browser', true);
    $.connection.hub.logging = true;
    window.tv = $.connection.tVHub;
    tv.client.tvConfigurada = (function(_this) {
      return function(name, nomeDoUsuario) {
        $("#tvName").text(name);
        return _this.salvarAutenticacao(nomeDoUsuario);
      };
    })(this);
    tv.client.reiniciarTv = (function(_this) {
      return function() {
        return window.location = _this.options.urlReiniciarTv;
      };
    })(this);
    tv.client.iniciarApresentacao = (function(_this) {
      return function(idDaApresentacao) {
        var url;
        url = _this.options.urlIniciarApresentacao + '?idDaApresentacao=' + idDaApresentacao;
        return window.location = url;
      };
    })(this);
    $.connection.hub.start();
    if (this.options.iniciarApresentacao) {
      this.iniciarApresentacao();
    }
  }

  tvHubController.prototype.salvarAutenticacao = function(nomeDoUsuario) {
    var urlAutenticar;
    urlAutenticar = this.options.urlAutenticacao;
    return $.ajax({
      url: urlAutenticar,
      data: {
        userName: nomeDoUsuario
      },
      type: 'POST',
      success: function(data) {
        if (data.success) {
          return $('#Login').val(data.login);
        }
      }
    });
  };

  tvHubController.prototype.autenticarTv = function(func) {
    var login, urlAutenticar;
    login = $('#Login').val();
    urlAutenticar = this.options.urlAutenticacao + ("?userName=" + login);
    return $.ajax({
      url: urlAutenticar,
      type: 'POST',
      success: function() {
        if (func) {
          return func();
        }
      }
    });
  };

  tvHubController.prototype.iniciarApresentacao = function() {
    return this.autenticarTv(this.executarApresentacao);
  };

  tvHubController.prototype.executarApresentacao = function() {
    return $.ajax({
      url: this.options.urlObterApresentacao,
      data: {
        codigo: $('#Codigo', '#tv-container').val()
      },
      type: 'POST',
      success: function(data) {
        if (data.data.possuiApresentacao) {
          return window.tv.client.iniciarApresentacao(data.data.idDaApresentacao);
        }
      }
    });
  };

  return tvHubController;

})();
