﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.itensDoBrainstormingController = (function() {
  function itensDoBrainstormingController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.confirmarExclusaoDoBrainstorming = bind(this.confirmarExclusaoDoBrainstorming, this);
    this.reloadExlcuirItemDoBrainstorming = bind(this.reloadExlcuirItemDoBrainstorming, this);
    this.reloadBotaoMatrizesAtivas = bind(this.reloadBotaoMatrizesAtivas, this);
    this.reloadItensDoBrainstorming = bind(this.reloadItensDoBrainstorming, this);
    this.salvarItemDoBrainstorming = bind(this.salvarItemDoBrainstorming, this);
    this.validarCampoDescricao = bind(this.validarCampoDescricao, this);
    this.aoCarregar = bind(this.aoCarregar, this);
    this.aoCarregar();
  }

  itensDoBrainstormingController.prototype.aoCarregar = function() {
    $(".TextExpander", this.contexto).TextAreaExpander(20, 70);
    $('.js-placeholder', this.contexto).placeholder();
    $("#novoItem-" + this.options.idDoPai).focus();
    $("[rel=tooltip]").tooltip();
    return $('[alt=integer_4]', this.contexto).setMask();
  };

  itensDoBrainstormingController.prototype.validarCampoDescricao = function($item) {
    if ($item.val().trim() === "") {
      setFoco($item);
      $item.attr("placeholder", resourceJsonCommom.DigiteUmaDescricao);
      $item.next(".validationMessage").show();
      $item.parent().addClass("error");
      return false;
    } else {
      return true;
    }
  };

  itensDoBrainstormingController.prototype.salvarItemDoBrainstorming = function($item, recarregar) {
    var $descricao, idDoItem, idDoPai, parametros;
    idDoItem = $item.data('item');
    parametros = $item.parent().parent().find(":input").serialize();
    if (idDoItem === 0) {
      idDoPai = $('#IdDoPai', '#item-0').val();
      $descricao = $("#novoItem-" + idDoPai, "#item-0");
    } else {
      $descricao = $("#" + idDoItem, "#item-" + idDoItem);
    }
    if (this.validarCampoDescricao($descricao)) {
      return $as.ItensDoBrainstorming.SalvarItemDoBrainstorming.post(parametros).success((function(_this) {
        return function(data) {
          if (recarregar) {
            return _this.reloadItensDoBrainstorming(_this.options.idDoPai);
          } else {
            return $("textarea", $("#" + idDoItem).closest(".item-brainstorn").next()).focus();
          }
        };
      })(this));
    }
  };

  itensDoBrainstormingController.prototype.reloadItensDoBrainstorming = function(idDoBrainstorming) {
    return $as.ItensDoBrainstorming.Index.get({
      idDoPai: idDoBrainstorming
    }).success((function(_this) {
      return function(data) {
        $("#divItensDoBrainstorming-" + idDoBrainstorming).parent().html(data);
        return _this.reloadBotaoMatrizesAtivas(idDoBrainstorming);
      };
    })(this));
  };

  itensDoBrainstormingController.prototype.reloadBotaoMatrizesAtivas = function(idDoBrainstorming) {
    return $as.MatrizDePriorizacao.DropDownDeMatrizesAtivas.get({
      idDoBrainstorming: idDoBrainstorming
    }).success((function(_this) {
      return function(data) {
        return $("#DropDownDeMatrizesAtivas-" + idDoBrainstorming).html(data);
      };
    })(this));
  };

  itensDoBrainstormingController.prototype.reloadExlcuirItemDoBrainstorming = function(idDoPai) {
    return this.reloadItensDoBrainstorming(idDoPai);
  };

  itensDoBrainstormingController.prototype.confirmarExclusaoDoBrainstorming = function(idDoBrainstorming) {
    return $("#removerItem-" + idDoBrainstorming).click();
  };

  return itensDoBrainstormingController;

})();
