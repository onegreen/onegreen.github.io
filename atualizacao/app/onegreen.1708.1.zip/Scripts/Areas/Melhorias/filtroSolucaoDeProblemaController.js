﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.filtroSolucaoDeProblemaController = (function() {
  function filtroSolucaoDeProblemaController(options, func) {
    this.options = options;
    this.configurarAplicarFiltro = bind(this.configurarAplicarFiltro, this);
    this.defineFiltros = bind(this.defineFiltros, this);
    if (this.options !== null) {
      this.defineFiltros(func);
    }
  }

  filtroSolucaoDeProblemaController.prototype.defineFiltros = function(func) {
    var filtroSolucao;
    filtroSolucao = window.FiltroSolucao;
    if (filtroSolucao === void 0) {
      $.ajax({
        url: this.options.UrlFiltroDefault,
        async: false,
        success: function(filtro) {
          return window.FiltroSolucao = {
            IdUnidadeGerencial: filtro.UnidadeGerencial,
            UnidadeGerencialNome: filtro.UnidadeGerencialNome,
            IdOrigem: filtro.IdOrigem,
            OrigemNome: filtro.OrigemNome,
            Descricao: filtro.Descricao,
            Coluna: filtro.ColunaOrdenacao,
            Ordem: filtro.TipoOrdenacao,
            IncluirSubordinadas: filtro.IncluirSubordinadas,
            ExibirCancelados: filtro.ExibirCancelados,
            Status: filtro.Status,
            StatusAtividade: filtro.StatusAtividade,
            IdDoUsuario: filtro.IdDoUsuario,
            TipoDaSolucaoDeProblemas: filtro.TipoDaSolucaoDeProblemas
          };
        }
      });
    }
    this.configurarAplicarFiltro();
    func();
    return {
      defineFiltroVazio: (function(_this) {
        return function(filtro) {
          if (filtro === void 0) {
            return filtro = {
              IdUnidadeGerencial: null,
              UnidadeGerencialNome: '',
              IdOrigem: null,
              OrigemNome: '',
              Descricao: '',
              Coluna: '',
              Ordem: '',
              IncluirSubordinadas: false,
              ExibirCancelados: false,
              Status: '',
              StatusAtividade: '',
              IdDoUsuario: null,
              TipoDaSolucaoDeProblemas: 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
            };
          }
        };
      })(this)
    };
  };

  filtroSolucaoDeProblemaController.prototype.configurarAplicarFiltro = function() {
    return $("#AplicarFiltro").click(this.options.aplicarFiltro);
  };

  return filtroSolucaoDeProblemaController;

})();
