﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.metodosController = (function() {
  function metodosController(opcoes) {
    this.opcoes = opcoes;
  }

  return metodosController;

})();

window.metodosController.configuracoesDoMetodo = (function(superClass) {
  extend(configuracoesDoMetodo, superClass);

  function configuracoesDoMetodo(opcoes) {
    this.opcoes = opcoes;
    this.configurarFluxo = bind(this.configurarFluxo, this);
    this.configurarFerramentasAutomaticas = bind(this.configurarFerramentasAutomaticas, this);
    this.configurarFerramentasDisponiveis = bind(this.configurarFerramentasDisponiveis, this);
    this.configurarCores = bind(this.configurarCores, this);
    this.carregarMetodo = bind(this.carregarMetodo, this);
    this.configurarComboMetodos = bind(this.configurarComboMetodos, this);
    this.carregarConfiguracoes = bind(this.carregarConfiguracoes, this);
    configuracoesDoMetodo.__super__.constructor.call(this, this.opcoes);
    this.configurarComboMetodos();
    this.carregarConfiguracoes();
  }

  configuracoesDoMetodo.prototype.carregarConfiguracoes = function() {
    this.configurarCores();
    this.configurarFerramentasDisponiveis();
    this.configurarFerramentasAutomaticas();
    return this.configurarFluxo();
  };

  configuracoesDoMetodo.prototype.configurarComboMetodos = function() {
    var onSelect;
    onSelect = (function(_this) {
      return function(input) {
        return _this.carregarMetodo(input.val());
      };
    })(this);
    return setCombo(this.opcoes.Contexto, "#MetodoNome", onSelect);
  };

  configuracoesDoMetodo.prototype.carregarMetodo = function(idDoMetodo) {
    return $as.Melhorias.Metodos.ConfiguracoesDoMetodo.get({
      id: idDoMetodo
    }).success((function(_this) {
      return function(data) {
        return $("#configuracao-por-metodo").html(data);
      };
    })(this));
  };

  configuracoesDoMetodo.prototype.configurarCores = function() {
    return $("td", "#corDoMetodo-container").click(function(e) {
      var $elemento, $radio, idDoMetodo;
      e.stopPropagation();
      $elemento = $(e.currentTarget);
      $radio = $("input[type=radio]", $elemento);
      $("input[type=radio]:checked", "#corDoMetodo-container").prev("i").remove();
      $radio.attr("checked", "checked");
      $("label", $elemento).prepend('<i class="fa fa-check"></i>');
      idDoMetodo = function() {
        return $("#IdDoMetodo").val();
      };
      return $as.Melhorias.Metodos.AlterarCor.post({
        id: idDoMetodo(),
        cor: $radio.val()
      }).success(function(data) {});
    });
  };

  configuracoesDoMetodo.prototype.configurarFerramentasDisponiveis = function() {
    return $("input:checkbox", ".js-ferramentas-disponiveis-container").change(function(e) {
      var $elemento, idDoMetodo;
      $elemento = $(e.currentTarget);
      idDoMetodo = function() {
        return $("#IdDoMetodo").val();
      };
      return $as.Melhorias.Metodos.AlterarFerramentasDisponiveis.post({
        idDoMetodo: idDoMetodo(),
        ordemDoPasso: $elemento.attr("data-passo-ordem"),
        adicionar: $elemento.attr("checked") !== void 0,
        valor: $elemento.val()
      }).success(function(data) {});
    });
  };

  configuracoesDoMetodo.prototype.configurarFerramentasAutomaticas = function() {
    return $("input:checkbox", ".js-ferramentas-automaticas-container").change(function(e) {
      var $elemento, idDoMetodo;
      $elemento = $(e.currentTarget);
      idDoMetodo = function() {
        return $("#IdDoMetodo").val();
      };
      return $as.Melhorias.Metodos.AlterarFerramentasAutomaticas.post({
        idDoMetodo: idDoMetodo(),
        ordemDoPasso: $elemento.attr("data-passo-ordem"),
        adicionar: $elemento.attr("checked") !== void 0,
        valor: $elemento.val()
      }).success(function(data) {});
    });
  };

  configuracoesDoMetodo.prototype.configurarFluxo = function() {
    return $("#configuracao-fluxo input[type=radio]").change(function(e) {
      var idDoMetodo;
      idDoMetodo = function() {
        return $("#IdDoMetodo").val();
      };
      return $as.Melhorias.Metodos.AlterarConfiguracaoDeFluxo.post({
        id: idDoMetodo(),
        ativar: $(e.currentTarget).val()
      }).success(function(data) {});
    });
  };

  return configuracoesDoMetodo;

})(window.metodosController);
