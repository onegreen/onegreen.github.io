﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.pgpController = (function() {
  function pgpController(options, func) {
    this.options = options;
    this.defineFiltros = bind(this.defineFiltros, this);
    this.defineFiltros(func);
  }

  pgpController.prototype.defineFiltros = function(func) {
    var filtroFarol;
    filtroFarol = window.FiltroFarolDeProjeto;
    if (filtroFarol === void 0) {
      $.ajax({
        url: this.options.UrlFiltroDefault,
        async: false,
        success: function(filtro) {
          return window.FiltroFarolDeProjeto = {
            IdUnidadeGerencial: filtro.IdUnidadeGerencial,
            UnidadeGerencialNome: filtro.UnidadeGerencialNome,
            IdOrigem: filtro.IdOrigem,
            OrigemNome: filtro.OrigemNome,
            Descricao: filtro.Descricao,
            Coluna: filtro.ColunaOrdenacao,
            Ordem: filtro.TipoOrdenacao,
            IncluirSubordinadas: filtro.IncluirSubordinadas,
            ExibirCancelados: filtro.ExibirCancelados,
            StatusDoProjeto: filtro.StatusDoProjeto
          };
        }
      });
    }
    return func();
  };

  return pgpController;

})();
