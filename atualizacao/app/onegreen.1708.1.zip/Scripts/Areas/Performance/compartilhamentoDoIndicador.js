﻿this.compartilhamentoDoIndicador = (function() {
  function compartilhamentoDoIndicador(resource) {
    this.resource = resource;
  }

  compartilhamentoDoIndicador.prototype.notificarCompartilhamento = function(idDoIndicador) {
    var nomeDaUnidade;
    nomeDaUnidade = $('#UnidadeGerencial_SiglaAtual', '#compartilhar-modal').val();
    showBottomNoty(this.resource.OIndicadorFoiCompartilhadoNaUnidadeGerencial + " " + nomeDaUnidade + ".");
    return compartilhamentoDoIndicador.reloadCompartilhamento(idDoIndicador);
  };

  compartilhamentoDoIndicador.reloadCompartilhamento = function(idDoIndicador) {
    return $as.Performance.Indicadores.IndicadoresCompartilhados.get({
      idDoIndicador: idDoIndicador
    }).success(function(data) {
      return $('#compartilhamento-container', '#compartilhamento-panel').html(data);
    });
  };

  return compartilhamentoDoIndicador;

})();
