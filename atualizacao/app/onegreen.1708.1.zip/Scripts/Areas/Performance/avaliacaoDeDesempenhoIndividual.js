﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.AvaliacaoDeDesempenhoIndividual = (function(superClass) {
  extend(AvaliacaoDeDesempenhoIndividual, superClass);

  function AvaliacaoDeDesempenhoIndividual(view, opcoes) {
    this.view = view;
    this.opcoes = opcoes;
    this.atualizarGaugeDoPlanoDeAcao = bind(this.atualizarGaugeDoPlanoDeAcao, this);
    this.obterParametroPorNome = bind(this.obterParametroPorNome, this);
    this.abrirAbaAoIniciar = bind(this.abrirAbaAoIniciar, this);
    this.mudarCiclo = bind(this.mudarCiclo, this);
    this.recarregar = bind(this.recarregar, this);
    this.aoExecutarFluxo = bind(this.aoExecutarFluxo, this);
    this.avaliar = bind(this.avaliar, this);
    this.binds = bind(this.binds, this);
    AvaliacaoDeDesempenhoIndividual.__super__.constructor.call(this, this.view);
    this.tabelaAvaliacao = this.get('.js-tabela-avaliacao');
    this.notaTotal = this.get('#spanNotaTotal');
    this.abrirAbaAoIniciar();
    this.binds();
    window.CallbackDaExecucaoDoFluxo = this.aoExecutarFluxo;
    $('#filtro-ug-geral').hide();
    $('#separador-filtro-ug-geral').hide();
    $('#link-adicionar').hide();
    $('#link-filtro-avancado').hide();
    if (this.opcoes.aba) {
      $("#" + this.opcoes.aba).click();
    }
  }

  AvaliacaoDeDesempenhoIndividual.prototype.binds = function() {
    this.tabelaAvaliacao.find('input[type=radio]').on('change', (function(_this) {
      return function(e) {
        var idDaResposta, idDoItem;
        idDoItem = $( this ).data('iddoitem');
        idDaResposta = $( this ).val();
        return _this.avaliar(idDoItem, idDaResposta);
      };
    })(this));
    return this.get('.js-ciclo-avaliacao').click((function(_this) {
      return function() {
        var id;
        id = $( this ).data('id');
        return _this.mudarCiclo(id);
      };
    })(this));
  };

  AvaliacaoDeDesempenhoIndividual.prototype.avaliar = function(idDoItem, idDaResposta) {
    return $as.Performance.ItensDaAvaliacaoDeDesempenho.Avaliar.post({
      idDoItem: idDoItem,
      idDaResposta: idDaResposta
    }).done((function(_this) {
      return function(data) {
        _this.notaTotal.text(data.data.NotaTotal);
        return WorkflowFx.api.reloadEstadoAtual(_this.opcoes.idDaAvaliacao, 'PortalSIM.Domain.Performance.AvaliacaoDeDesempenho', 'AvaliacaoDeDesempenho');
      };
    })(this));
  };

  AvaliacaoDeDesempenhoIndividual.prototype.aoExecutarFluxo = function() {
    return this.recarregar();
  };

  AvaliacaoDeDesempenhoIndividual.prototype.recarregar = function() {
    return $as.Performance.AvaliacoesDeDesempenho.AvaliacaoIndividual.post({
      idDoUsuario: this.opcoes.idDoUsuario,
      idDoCiclo: this.opcoes.idDoCiclo
    }).done((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  AvaliacaoDeDesempenhoIndividual.prototype.mudarCiclo = function(idDoCiclo) {
    this.opcoes.idDoCiclo = idDoCiclo;
    return this.recarregar();
  };

  AvaliacaoDeDesempenhoIndividual.prototype.abrirAbaAoIniciar = function() {
    var id;
    id = this.obterParametroPorNome('aba');
    id = id.toString();
    if (id !== "") {
      return $("[href='#" + id + "']").click();
    }
  };

  AvaliacaoDeDesempenhoIndividual.prototype.obterParametroPorNome = function(nome) {
    var regex, results;
    nome = nome.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    regex = new RegExp("[\\?&]" + nome + "=([^&#]*)");
    results = regex.exec(location.search);
    if (results === null) {
      return "";
    } else {
      return decodeURIComponent(results[1].replace(/\+/g, " "));
    }
  };

  AvaliacaoDeDesempenhoIndividual.prototype.atualizarGaugeDoPlanoDeAcao = function(idDaAvaliacao) {
    return $as.Performance.AvaliacoesDeDesempenho.AtualizarGaugeDoPlanoDeAcao.get({
      idDaAvaliacao: idDaAvaliacao
    }).success((function(_this) {
      return function(data) {
        if (data.Realizado < data.Previsto) {
          $("#container-percentual").removeClass("bg-no-prazo");
          $("#container-percentual").addClass("bg-atrasada");
        } else {
          $("#container-percentual").removeClass("bg-atrasada");
          $("#container-percentual").addClass("bg-no-prazo");
        }
        $("#percentual-realizado").html(data.Realizado.toFixed(0) + "%");
        return $("#percentual-previsto").html(data.Previsto.toFixed(0) + "%");
      };
    })(this));
  };

  return AvaliacaoDeDesempenhoIndividual;

})(window.baseController);
