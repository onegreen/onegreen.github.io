﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.copiarConfiguracaoDoProgramaDeResultadoController = (function() {
  function copiarConfiguracaoDoProgramaDeResultadoController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.desabilitarSelecionarDesmarcarTodos = bind(this.desabilitarSelecionarDesmarcarTodos, this);
    this.bindCheckUsuario = bind(this.bindCheckUsuario, this);
    this.bindMarcarEhDescarmarUsuario = bind(this.bindMarcarEhDescarmarUsuario, this);
    this.filtrarUsuario = bind(this.filtrarUsuario, this);
    this.loadComboUnidade = bind(this.loadComboUnidade, this);
    $(this.contexto).window();
    this.selecionarTodos = $('.js-incluir-todos-usuario', this.contexto);
    this.desmarcarTodos = $('.js-desmarcar-todos-usuario', this.contexto);
    this.containerUsuario = $('#selecaoDeUsuario-container', this.contexto);
    this.loadComboUnidade();
    this.bindMarcarEhDescarmarUsuario();
    this.bindCheckUsuario();
  }

  copiarConfiguracaoDoProgramaDeResultadoController.prototype.loadComboUnidade = function() {
    return setCombo(this.contexto, '#UnidadeGerencial_SiglaAtual', this.filtrarUsuario, null, null, null, this.options.defaultOption);
  };

  copiarConfiguracaoDoProgramaDeResultadoController.prototype.filtrarUsuario = function() {
    var idDaUnidade;
    idDaUnidade = $('#UnidadeGerencial_Id', this.contexto).val();
    return $as.Performance.ProgramasDeResultadosPorUsuario.SelecaoDeUsuarioPorUnidadeGerencial.get({
      idDaUnidade: idDaUnidade
    }).done((function(_this) {
      return function(data) {
        _this.containerUsuario.html(data);
        _this.desabilitarSelecionarDesmarcarTodos();
        return _this.bindCheckUsuario();
      };
    })(this));
  };

  copiarConfiguracaoDoProgramaDeResultadoController.prototype.bindMarcarEhDescarmarUsuario = function() {
    this.desmarcarTodos.on('click', (function(_this) {
      return function() {
        _this.containerUsuario.find('input:checked').click();
        _this.selecionarTodos.show();
        return _this.desmarcarTodos.hide();
      };
    })(this));
    return this.selecionarTodos.on('click', (function(_this) {
      return function() {
        _this.containerUsuario.find('input').not(':checked').click();
        _this.desmarcarTodos.show();
        return _this.selecionarTodos.hide();
      };
    })(this));
  };

  copiarConfiguracaoDoProgramaDeResultadoController.prototype.bindCheckUsuario = function() {
    return this.containerUsuario.find('input').on('change', (function(_this) {
      return function() {
        if (_this.containerUsuario.find('input:checked').length === _this.containerUsuario.find('input').length) {
          _this.desmarcarTodos.show();
          return _this.selecionarTodos.hide();
        } else {
          _this.selecionarTodos.show();
          return _this.desmarcarTodos.hide();
        }
      };
    })(this));
  };

  copiarConfiguracaoDoProgramaDeResultadoController.prototype.desabilitarSelecionarDesmarcarTodos = function() {
    if (this.containerUsuario.find('label').length > 0) {
      this.selecionarTodos.show();
      return this.desmarcarTodos.hide();
    } else {
      this.selecionarTodos.hide();
      return this.desmarcarTodos.hide();
    }
  };

  return copiarConfiguracaoDoProgramaDeResultadoController;

})();
