﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.criarDimensoes = (function() {
  function criarDimensoes(view, options) {
    this.view = view;
    this.options = options;
    this.get = bind(this.get, this);
    this.aoAtualizarArvore = bind(this.aoAtualizarArvore, this);
    this.voltarParaAdicaoDoIndicador = bind(this.voltarParaAdicaoDoIndicador, this);
    this.limparArvore = bind(this.limparArvore, this);
    this.alterarFormaDeAcumulo = bind(this.alterarFormaDeAcumulo, this);
    this.criarIndicadores = bind(this.criarIndicadores, this);
    this.mostrarOuEsconderNos = bind(this.mostrarOuEsconderNos, this);
    this.eventosPreview = bind(this.eventosPreview, this);
    this.gerarNamesNaArvore = bind(this.gerarNamesNaArvore, this);
    this.removerNoDaArvore = bind(this.removerNoDaArvore, this);
    this.montarArvore = bind(this.montarArvore, this);
    this.fecharModal = bind(this.fecharModal, this);
    this.eventos = bind(this.eventos, this);
    $(this.view).window({
      width: '980px'
    });
    this.contexto = $('#criacao-de-dimencao-context');
    this.previewContainer = this.get('#preview-dimensao');
    this.get('#btn-criarindicadores').hide();
    this.eventos();
    this.loadDropDownFormaDeAcumulo();
  }

  criarDimensoes.prototype.eventos = function() {
    this.get('#AgrupamentoDeDimensoes-dropdown li').click(this.alterarFormaDeAcumulo);
    this.get('#btn-limpar-arvore').click(this.limparArvore);
    this.get('#btn-preview-arvore').click(this.montarArvore);
    this.get('#btn-criarindicadores').click(this.criarIndicadores);
    this.get('#btn-voltar').click(this.voltarParaAdicaoDoIndicador);
    return this.get('#btn-fechar').click(this.fecharModal);
  };

  criarDimensoes.prototype.fecharModal = function() {
    this.get('#close-modal-criardimensao').click();
    return window.IndicadoresController.toggleBotaoConfigurarDimensoes(true);
  };

  criarDimensoes.prototype.montarArvore = function() {
    var dimensoes;
    dimensoes = this.get('#selecionar-dimensoes-container, #preview-dimensao').find(':input[type=hidden]').serialize();
    return $as.Performance.Indicadores.MontarArvore.post(dimensoes).done((function(_this) {
      return function(data) {
        _this.previewContainer.html(data);
        _this.eventosPreview();
        _this.get('#btn-preview-arvore').hide();
        _this.get('#btn-limpar-arvore').show();
        _this.get('#lnkLimparArvore').show();
        _this.get('#btn-criarindicadores').show();
        return _this.aoAtualizarArvore();
      };
    })(this));
  };

  criarDimensoes.prototype.removerNoDaArvore = function(event) {
    var filhos, pai, target;
    target = $(event.delegateTarget);
    pai = target.closest('ul');
    filhos = $('li', pai).length;
    if (filhos === 1) {
      pai.closest('.js-combinacao').addClass('indicador-folha');
    }
    target.closest('li').remove();
    return this.aoAtualizarArvore();
  };

  criarDimensoes.prototype.gerarNamesNaArvore = function() {
    var i, indice, input, item, j, len, len1, ref, ref1, referencia, results;
    indice = 0;
    ref = $('.js-item-arvore', this.previewContainer);
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      item = ref[i];
      item = $(item);
      ref1 = $('input', item);
      for (j = 0, len1 = ref1.length; j < len1; j++) {
        input = ref1[j];
        input = $(input);
        referencia = input.data('referencia');
        input.attr('name', "CombinacoesSelecionadas[" + indice + "]." + referencia);
      }
      results.push(indice++);
    }
    return results;
  };

  criarDimensoes.prototype.eventosPreview = function() {
    $('.js-remove', this.previewContainer).click(this.removerNoDaArvore);
    return $('.js-show-hide', this.previewContainer).click(this.mostrarOuEsconderNos);
  };

  criarDimensoes.prototype.mostrarOuEsconderNos = function(event) {
    var target;
    target = $(event.delegateTarget);
    if (target.hasClass('fa-minus-square')) {
      return target.removeClass('fa-minus-square').addClass('fa-plus-square').closest('div').next().hide();
    } else {
      return target.addClass('fa-minus-square').removeClass('fa-plus-square').closest('div').next().show();
    }
  };

  criarDimensoes.prototype.criarIndicadores = function() {
    var indicadores;
    indicadores = this.get('#selecionar-dimensoes-container, #preview-dimensao').find(':input[type=hidden]').serialize();
    return $as.Performance.Indicadores.CriarDimensoes.post(indicadores).done((function(_this) {
      return function(data) {
        if (!data.success) {
          $("#main-modal").html(data);
        } else {
          window.farolController.recarregarFarol();
        }
        return _this.fecharModal();
      };
    })(this));
  };

  criarDimensoes.prototype.alterarFormaDeAcumulo = function(event) {
    var target;
    target = $(event.delegateTarget);
    this.limparArvore();
    return $('.js-forma-acumulo-selecionada').val(target.attr('value'));
  };

  criarDimensoes.prototype.limparArvore = function(event) {
    if (event) {
      $(event.delegateTarget).hide();
    }
    this.previewContainer.html('');
    this.get('#lnkLimparArvore').hide();
    this.get('#btn-limpar-arvore').hide();
    this.get('#btn-criarindicadores').hide();
    this.get('#itens-selecionados-container').html('');
    return this.get('#btn-preview-arvore').show();
  };

  criarDimensoes.prototype.voltarParaAdicaoDoIndicador = function() {
    return $as.Performance.Indicadores.VoltarParaAdicaoDoIndicador.get($('#informacoes-indicador input', '#selecionar-dimensoes-container').serialize()).success((function(_this) {
      return function(data) {
        $('#box-createEdit-indicador').html(data);
        return _this.fecharModal();
      };
    })(this));
  };

  criarDimensoes.prototype.aoAtualizarArvore = function() {
    var quantidade;
    quantidade = $('li', this.previewContainer).length;
    $('#quantidade-indicadores-criar').html(quantidade);
    if (quantidade > this.options.maximoDeSimultaneos) {
      $('#quantidade-maxima-de-indicadores').show();
      $('#btn-criarindicadores').attr('disabled', 'disabled');
    } else {
      $('#quantidade-maxima-de-indicadores').hide();
      $('#btn-criarindicadores').removeAttr('disabled');
    }
    return this.gerarNamesNaArvore();
  };

  criarDimensoes.prototype.loadDropDownFormaDeAcumulo = function() {
    return setDropDown('#selecionar-dimensoes-container', '#AgrupamentoDeDimensoes-dropdown');
  };

  criarDimensoes.prototype.get = function(seletor) {
    return $(seletor, this.contexto);
  };

  return criarDimensoes;

})();
