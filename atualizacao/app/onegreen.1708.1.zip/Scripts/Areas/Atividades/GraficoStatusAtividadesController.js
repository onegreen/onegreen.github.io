﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.Atividades || (this.Atividades = {});

Atividades.GraficoStatusAtividadesController = (function() {
  function GraficoStatusAtividadesController(container, filtro) {
    this.container = container;
    this.filtro = filtro;
    this.reload = bind(this.reload, this);
    $(this.container).data("controller", this);
  }

  GraficoStatusAtividadesController.prototype.reload = function() {
    return $as.Atividades.Atividades.FiltrarPeloResponsavel.get({
      format: 'Grafico'
    }, JSON.stringify(this.filtro)).done((function(_this) {
      return function(data) {
        return $(_this.container).html(data);
      };
    })(this));
  };

  return GraficoStatusAtividadesController;

})();
