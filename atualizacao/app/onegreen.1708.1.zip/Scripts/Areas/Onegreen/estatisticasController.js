﻿window.estatisticasController = (function() {
  function estatisticasController() {}

  estatisticasController.configurarVoltar = function() {
    return window.VoltarERecarregar = function() {
      return $as.Onegreen.Estatisticas.Index.post().success(function(data) {
        return $('#main').html(data);
      });
    };
  };

  return estatisticasController;

})();
