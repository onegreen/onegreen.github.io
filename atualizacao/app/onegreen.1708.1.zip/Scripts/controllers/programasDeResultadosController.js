﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.programasDeResultadosController = (function() {
  function programasDeResultadosController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.aoSelecionarUmaFormaDeConfiguracao = bind(this.aoSelecionarUmaFormaDeConfiguracao, this);
    this.setChangeFormaDeConfiguracao = bind(this.setChangeFormaDeConfiguracao, this);
    this.aoSelecionarUmaFormaDeCalculo = bind(this.aoSelecionarUmaFormaDeCalculo, this);
    $(this.contexto).window({
      minheight: '320px'
    });
    this.loadDropDownFormaDeCalculo();
    this.loadAutoCompleteFormaDeConfiguracao();
    this.setChangeFormaDeConfiguracao();
    window.programasDeResultadosController.exibirItensDoProgramaDeResultadosPorFormaDeCalculo(this.options.FormaDeCalculoDeRemuneracaoVariavel);
    this.botaoFechar = $('#close-modal-programaderesultados', this.contexto);
    this.botaoFechar.click(this.reload);
  }

  programasDeResultadosController.prototype.aoSelecionarUmaFormaDeCalculo = function(elemento) {
    var formaDeCalculo;
    formaDeCalculo = $(elemento.delegateTarget).val();
    return window.programasDeResultadosController.exibirItensDoProgramaDeResultadosPorFormaDeCalculo(formaDeCalculo);
  };

  programasDeResultadosController.exibirItensDoProgramaDeResultadosPorFormaDeCalculo = function(formaDeCalculo) {
    switch (formaDeCalculo) {
      case 3:
        return $("#ItensDoProgramaDeResultados-container").hide();
      case 0:
      case 1:
        $("#ItensDoProgramaDeResultados-container").show();
        $("#percentual-de-atingimento-header", "#ItensDoProgramaDeResultados-container").hide();
        $(".js-percentual-de-atingimento-linha", "#ItensDoProgramaDeResultados-container").hide();
        $("#forma-de-calculo-header", "#ItensDoProgramaDeResultados-container").hide();
        $(".js-forma-de-calculo-linha", "#ItensDoProgramaDeResultados-container").hide();
        $("#coluna-header", "#ItensDoProgramaDeResultados-container").show();
        return $(".js-coluna-linha", "#ItensDoProgramaDeResultados-container").show();
      case 2:
        $("#ItensDoProgramaDeResultados-container").show();
        $("#percentual-de-atingimento-header", "#ItensDoProgramaDeResultados-container").show();
        $(".js-percentual-de-atingimento-linha", "#ItensDoProgramaDeResultados-container").show();
        $("#forma-de-calculo-header", "#ItensDoProgramaDeResultados-container").show();
        $(".js-forma-de-calculo-linha", "#ItensDoProgramaDeResultados-container").show();
        $("#coluna-header", "#ItensDoProgramaDeResultados-container").hide();
        return $(".js-coluna-linha", "#ItensDoProgramaDeResultados-container").hide();
    }
  };

  programasDeResultadosController.prototype.loadDropDownFormaDeCalculo = function() {
    return setDropDown(this.contexto, '#FormaDeCalculoDeRemuneracaoVariavel-dropdown', this.aoSelecionarUmaFormaDeCalculo);
  };

  programasDeResultadosController.prototype.loadAutoCompleteFormaDeConfiguracao = function() {
    return setCombo(this.contexto, '#GrupoDeUsuario_Nome');
  };

  programasDeResultadosController.prototype.setChangeFormaDeConfiguracao = function() {
    return $(this.contexto).find("input[name=FormaDeContratacao]:radio").change(this.aoSelecionarUmaFormaDeConfiguracao);
  };

  programasDeResultadosController.prototype.aoSelecionarUmaFormaDeConfiguracao = function() {
    var grupoDeUsuario;
    grupoDeUsuario = $(this.contexto).find("#grupo-de-usuario-container");
    if ($("#FormaDeContratacao-ContratacaoPorGrupo").attr("checked")) {
      return grupoDeUsuario.show();
    } else {
      return grupoDeUsuario.hide();
    }
  };

  return programasDeResultadosController;

})();
