﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.ConexoesController = (function(superClass) {
  extend(ConexoesController, superClass);

  function ConexoesController(view, options) {
    this.view = view;
    this.options = options;
    this.AdicionarConexao = bind(this.AdicionarConexao, this);
    this.SalvarConexaoVirtual = bind(this.SalvarConexaoVirtual, this);
    this.SalvarConexaoDeUsuarioExistente = bind(this.SalvarConexaoDeUsuarioExistente, this);
    this.limparCampos = bind(this.limparCampos, this);
    ConexoesController.__super__.constructor.call(this, this.view, null);
    $('[rel=tooltip]').tooltip();
    $("li", $("#lnkConexoes").parents("ul")).removeClass("active");
    $("#lnkConexoes").parent().addClass("active");
  }

  ConexoesController.prototype.exibirCampoNome = function() {
    $('#Email', '#NovoUsuario').animate({
      top: '4px'
    }, 500);
    $('#Nome', '#NovoUsuario').animate({
      top: '8px'
    }, 500);
    return $('#Nome', '#NovoUsuario').attr('style', '').focus();
  };

  ConexoesController.prototype.limparCampos = function() {
    return $('#lnkConexoes a').click();
  };

  ConexoesController.prototype.SalvarConexaoDeUsuarioExistente = function() {
    return $as.ConexoesDoUsuario.Create.post({
      idDoUsuario: $('#IdDoUsuario', '#NovoUsuario').val()
    }).done((function(_this) {
      return function() {
        $('#Email', '#NovoUsuario').focus();
        return _this.limparCampos();
      };
    })(this));
  };

  ConexoesController.prototype.SalvarConexaoVirtual = function() {
    return $as.ConexoesDoUsuario.CreatePorNomeEEmail.post({
      nome: $('#Nome', '#NovoUsuario').val(),
      email: $('#Email', '#NovoUsuario').val()
    }).done((function(_this) {
      return function() {
        $('#Email', '#NovoUsuario').focus();
        return _this.limparCampos();
      };
    })(this)).error((function(_this) {
      return function() {};
    })(this));
  };

  ConexoesController.prototype.AdicionarConexao = function() {
    var eVirtual;
    eVirtual = $('#EVirtual', '#NovoUsuario').val();
    if ((eVirtual != null) && eVirtual !== '') {
      return this.SalvarConexaoVirtual();
    } else {
      return $.get(this.options.UrlInformacoesPorEmail, {
        emailDoUsuario: (this.get('#Email')).val()
      }, (function(_this) {
        return function(usuario) {
          if (usuario && usuario.Id) {
            $('#IdDoUsuario', '#NovoUsuario').val(usuario.Id);
            return _this.SalvarConexaoDeUsuarioExistente();
          } else {
            $('#EVirtual', '#NovoUsuario').val(true);
            return _this.exibirCampoNome();
          }
        };
      })(this));
    }
  };

  return ConexoesController;

})(window.baseController);
