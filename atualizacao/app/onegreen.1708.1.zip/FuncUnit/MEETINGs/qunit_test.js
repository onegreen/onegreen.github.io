﻿F.speed = 100;

logar = function () {
    F('#UserName', 0).type('sw');
    F('#Password', 0).type('0000');
    F('#EntrarPeloSite', 0).click();
};

module('MEETINGs', {
    setup: function () {
        //logar();
	}
});

test('Deve criar uma reunião.', function() {
	F('#Criar-Agendamento', 0).click();
	F('#formReuniao', 0).visible('Modal para criar a reunião deve aparecer.');
	F('#Descricao', 0).type('Oba, eu sou uma nova reunião');
	F('#UnidadeGerencial_SiglaAtual', 0).type('CADAM');
	F.wait(200, function () {
	    F('#UnidadeGerencial_SiglaAtual', 0).type('[tab]');
	    F('#DescricoesAssuntosParaAdicao', 0).type('Assunto 1\r\n');
	    F('#DescricoesAssuntosParaAdicao', 0).type('Assunto 2\r\n');
	    F('#BotaoSalvar--0-0', 0).click();

	    F('#agenda-container', 0).visible('Agendamento cadastrado deve aparecer.');
	});
	//F('#lnkAgenda').click();
});