﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.adicionarModeloDeGraficoController = (function(superClass) {
  extend(adicionarModeloDeGraficoController, superClass);

  function adicionarModeloDeGraficoController() {
    this.aoAdicionarPersonalizado = bind(this.aoAdicionarPersonalizado, this);
    this.aoAdicionar = bind(this.aoAdicionar, this);
    $('[for=Tipo-Periodo]').attr('disabled', 'disabled');
  }

  adicionarModeloDeGraficoController.prototype.Redirecionar = function(idDoModelo) {
    if (window.detalesDoIndicador != null) {
      window.detalesDoIndicador.carregarModelo(idDoModelo);
    }
    return $as.Manutencao.ModelosDeGrafico.Edit.get({
      id: idDoModelo
    }).done((function(_this) {
      return function(retn) {
        return $('#main').html(retn);
      };
    })(this));
  };

  adicionarModeloDeGraficoController.prototype.SalvarModelo = function() {
    return $as.Manutencao.ModelosDeGrafico.Create.post($('#formNovoModelo').serialize()).done((function(_this) {
      return function(res) {
        if (res.success) {
          return _this.Redirecionar(res.data.id);
        } else {
          return $('#modal-container').html(res);
        }
      };
    })(this));
  };

  adicionarModeloDeGraficoController.prototype.aoAdicionar = function(res) {
    return this.Redirecionar(res.data.id);
  };

  adicionarModeloDeGraficoController.prototype.aoAdicionarPersonalizado = function(res) {
    return $as.Manutencao.ModelosDeGrafico.CreateEditModal.get({
      id: res.data.id
    }).done((function(_this) {
      return function(data) {
        if (window.detalesDoIndicador != null) {
          window.detalesDoIndicador.carregarModelo(res.data.id);
        }
        return window.GetDiv('edit-modelo-personalizado').html(data);
      };
    })(this));
  };

  adicionarModeloDeGraficoController.aoExcluir = function(res) {
    if (res.data.personalizado) {
      return this.reloadPersonalizados;
    }
  };

  adicionarModeloDeGraficoController.reloadPersonalizados = function() {
    return window.detalesDoIndicador.reload();
  };

  return adicionarModeloDeGraficoController;

})(window.baseController);
