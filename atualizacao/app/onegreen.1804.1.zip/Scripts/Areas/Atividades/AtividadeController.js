﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.Atividades || (this.Atividades = {});

Atividades.AtividadeController = (function() {
  function AtividadeController(contexto, resource, options) {
    this.contexto = contexto;
    this.resource = resource;
    this.options = options;
    this.configurarCabecalho = bind(this.configurarCabecalho, this);
    this.configurarMostrarDetalhesDeEventos = bind(this.configurarMostrarDetalhesDeEventos, this);
    this.exibirPopoverListagemReduzida = bind(this.exibirPopoverListagemReduzida, this);
    this.esconderContainerEnvioComentario = bind(this.esconderContainerEnvioComentario, this);
    this.configurarComentario = bind(this.configurarComentario, this);
    this.resetarCampoComentario = bind(this.resetarCampoComentario, this);
    this.criarComentarioDoDocumento = bind(this.criarComentarioDoDocumento, this);
    this.postarFormulario = bind(this.postarFormulario, this);
    this.salvar = bind(this.salvar, this);
    this.configurarSalvar = bind(this.configurarSalvar, this);
    this.inserirComentario = bind(this.inserirComentario, this);
    this.atualizarTransferenciaDeResponsabilidade = bind(this.atualizarTransferenciaDeResponsabilidade, this);
    this.recarregarAssinantes = bind(this.recarregarAssinantes, this);
    this.recarregarResponsavel = bind(this.recarregarResponsavel, this);
    this.ajustarMenuDeAviso = bind(this.ajustarMenuDeAviso, this);
    this.atualizarCampoDeAvisoDaExecucao = bind(this.atualizarCampoDeAvisoDaExecucao, this);
    this.ajustarMenuDePeridiocidade = bind(this.ajustarMenuDePeridiocidade, this);
    this.marcarDesmarcarBotaoAcaoPrivada = bind(this.marcarDesmarcarBotaoAcaoPrivada, this);
    this.abrirModalHistoricoLembretesEnviados = bind(this.abrirModalHistoricoLembretesEnviados, this);
    this.enviarLembreteExecucao = bind(this.enviarLembreteExecucao, this);
    this.confirmacaoEnviarLembreteExecucao = bind(this.confirmacaoEnviarLembreteExecucao, this);
    this.marcarDesmarcarBotaoRemoverDosRelatoriosEGraficos = bind(this.marcarDesmarcarBotaoRemoverDosRelatoriosEGraficos, this);
    this.marcarDesmarcarBotaoAcaoCritica = bind(this.marcarDesmarcarBotaoAcaoCritica, this);
    this.marcarDesmarcarBotaoMilestone = bind(this.marcarDesmarcarBotaoMilestone, this);
    this.recarregarHistorico = bind(this.recarregarHistorico, this);
    this.fecharAtividade = bind(this.fecharAtividade, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.configurarTextAreaExpander = bind(this.configurarTextAreaExpander, this);
    this.configurarMentions = bind(this.configurarMentions, this);
    this.removerTagAtividade = bind(this.removerTagAtividade, this);
    this.adicionarTagAtividade = bind(this.adicionarTagAtividade, this);
    this.configurarTagsAtividade = bind(this.configurarTagsAtividade, this);
    this.configurarExibicao = bind(this.configurarExibicao, this);
    this.$contexto = $(this.contexto);
    this.configurarExibicao();
    this.btnRemoverDosRelatoriosEGraficos = $("#btn-removerdosrelatoriosegraficos", this.contexto);
    this.btnLembrete = $('#btn-lembrete', this.contexto);
    this.btnVerHistoricoLembretesEnviados = $('#btn-verHistoricoLembretesEnviados', this.contexto);
    this.btnAcaoCritica = $("#btn-acaocritica", this.contexto);
    this.btnAcaoPrivada = $("#btn-acaoprivada", this.contexto);
    this.btnMilestone = $("#btn-milestone", this.contexto);
    this.btnSalvar = $("#btnSalvar", this.contexto);
    this.descricaoMention = $('#DescricaoMention', this.contexto);
    this.divDataAvisoDeExecucao = $("#DataAvisoDeExecucao", this.contexto);
    this.envioComentarioContainer = $("#envio-comentario-container", this.contexto);
    this.fechar = $("#btn-Fechar-Atividade-" + this.id);
    this.historicoAtividade = $("#HistoricoAtividade-" + this.id, this.contexto);
    this.inputAcaoCritica = $('#AcaoCritica', this.contexto);
    this.inputRemoverDosRelatoriosEGraficos = $('#RemoverDosRelatoriosEGraficos', this.contexto);
    this.inputAcaoPublica = $('#AcaoPublica', this.contexto);
    this.inputComentario = $("#inputComentarioTarefa", this.contexto);
    this.inputDataAvisoDeExecucao = $("#DataDoAvisoDeExecucao", this.contexto);
    this.inputMilestone = $('#Milestone', this.contexto);
    this.configurarMentions();
    this.configurarTextAreaExpander();
    this.configurarBinds();
    this.atualizarCampoDeAvisoDaExecucao();
    this.calcularNumeroDeDocumentosEmEventos();
    this.configurarComentario();
    this.configurarSalvar();
    this.configurarCabecalho();
    this.configurarTagsAtividade();
    Atividades.api.boot();
  }

  AtividadeController.prototype.configurarExibicao = function() {
    var $parent, modal;
    if (!this.$contexto.hasClass('js-FullScreen')) {
      modal = new modalLateral(this.$contexto.parent());
      $parent = this.$contexto.parent();
    }
    modal = new modalLateral($parent);
    this.id = this.$contexto.data('id');
    this.$contexto.data("controller", this);
    $(window).scroll((function(_this) {
      return function() {
        return $('.popover').remove();
      };
    })(this));
    return $('[rel=tooltip]', this.contexto).tooltip();
  };

  AtividadeController.prototype.configurarTagsAtividade = function() {
    return $as.Onegreen.Tags.RetornarTags.get().success((function(_this) {
      return function(data) {
        return $('#agregadorDeTags', _this.contexto).tagit({
          availableTags: data,
          tagListUl: $('#tagsListUl', _this.contexto),
          afterTagAdded: _this.adicionarTagAtividade,
          afterTagRemoved: _this.removerTagAtividade
        });
      };
    })(this));
  };

  AtividadeController.prototype.adicionarTagAtividade = function(event, ui) {
    return $as.Atividades.Atividades.AdicionarTagAtividade.post({
      id: this.id,
      nomeTag: ui.tagLabel
    });
  };

  AtividadeController.prototype.removerTagAtividade = function(event, ui) {
    return $as.Atividades.Atividades.RemoverTagAtividade.post({
      id: this.id,
      nomeTag: ui.tagLabel
    });
  };

  AtividadeController.prototype.configurarMentions = function() {
    return $('#DescricaoMention', this.contexto).userMentions('#inputComentarioTarefa', this.options.urlMentions);
  };

  AtividadeController.prototype.configurarTextAreaExpander = function() {
    $(".TextExpanderForDescricao", this.contexto).TextAreaExpander(40, 120);
    return $(".TextExpanderForCommonInput", this.contexto).TextAreaExpander(25, 380);
  };

  AtividadeController.prototype.configurarBinds = function() {
    $('.js-buscar-informacoes-atividade-modal', this.contexto).on('click', this.exibirPopoverListagemReduzida);
    $("#minimizar-envio-container", this.contexto).on('click', this.esconderContainerEnvioComentario);
    $("#opcoesAvisoDeExecucao a", this.contexto).on('click', this.ajustarMenuDeAviso);
    $("#opcoesPeriodicidade a", this.contexto).on('click', this.ajustarMenuDePeridiocidade);
    $("#btnComentar", this.contexto).on('click', this.inserirComentario);
    $("#tab-detalhe", this.contexto).on('shown.bs.tab', this.configurarTextAreaExpander);
    this.fechar.on('click', this.fecharAtividade);
    this.btnMilestone.on('click', this.marcarDesmarcarBotaoMilestone);
    this.btnAcaoCritica.on('click', this.marcarDesmarcarBotaoAcaoCritica);
    this.btnRemoverDosRelatoriosEGraficos.on('click', this.marcarDesmarcarBotaoRemoverDosRelatoriosEGraficos);
    this.btnLembrete.on('click', this.confirmacaoEnviarLembreteExecucao);
    this.btnVerHistoricoLembretesEnviados.on('click', this.abrirModalHistoricoLembretesEnviados);
    this.btnAcaoPrivada.on('click', this.marcarDesmarcarBotaoAcaoPrivada);
    return window.definirMascaraDecimal($("#QuantoPrevisto, #QuantoRealizado", this.contexto), 2);
  };

  AtividadeController.prototype.fecharAtividade = function() {
    $(".popover").remove();
    this.$contexto.hide();
    $('#box-create-edit-atividade').html('');
    return --window.WindowZIndex;
  };

  AtividadeController.prototype.recarregarHistorico = function(tipoDeFiltro) {
    if (tipoDeFiltro == null) {
      tipoDeFiltro = null;
    }
    return $as.Atividades.Atividades.ListarHistorico.get({
      idAtividade: this.id,
      tipoEvento: tipoDeFiltro
    }).done((function(_this) {
      return function(data) {
        _this.historicoAtividade.html(data);
        return _this.calcularNumeroDeDocumentosEmEventos();
      };
    })(this));
  };

  AtividadeController.prototype.marcarDesmarcarBotaoMilestone = function(evento) {
    if (this.btnMilestone.hasClass("link-desativado")) {
      return;
    }
    if (!this.btnMilestone.hasClass("btn-warning")) {
      this.btnMilestone.addClass('btn-warning');
      this.inputMilestone.val(true);
    } else {
      this.btnMilestone.removeClass('btn-warning');
      this.inputMilestone.val(false);
    }
    return this.salvar(Atividades.api.atualizarLogsDaTarefa);
  };

  AtividadeController.prototype.marcarDesmarcarBotaoAcaoCritica = function(evento) {
    if (this.btnAcaoCritica.hasClass("link-desativado")) {
      return;
    }
    if (!this.btnAcaoCritica.hasClass("btn-warning")) {
      this.btnAcaoCritica.addClass('btn-warning');
      this.inputAcaoCritica.val(true);
    } else {
      this.btnAcaoCritica.removeClass('btn-warning');
      this.inputAcaoCritica.val(false);
    }
    return this.salvar(Atividades.api.atualizarLogsDaTarefa);
  };

  AtividadeController.prototype.marcarDesmarcarBotaoRemoverDosRelatoriosEGraficos = function(evento) {
    if (this.btnRemoverDosRelatoriosEGraficos.hasClass("link-desativado")) {
      return;
    }
    if (!this.btnRemoverDosRelatoriosEGraficos.hasClass("btn-warning")) {
      this.btnRemoverDosRelatoriosEGraficos.addClass('btn-warning');
      this.inputRemoverDosRelatoriosEGraficos.val(true);
    } else {
      this.btnRemoverDosRelatoriosEGraficos.removeClass('btn-warning');
      this.inputRemoverDosRelatoriosEGraficos.val(false);
    }
    return this.salvar(Atividades.api.atualizarLogsDaTarefa);
  };

  AtividadeController.prototype.confirmacaoEnviarLembreteExecucao = function(evento) {
    return $as.Atividades.Atividades.ConfirmacaoEnviarLembreteExecucaoModal.get().success((function(_this) {
      return function(data) {
        return $("#main-modal").html(data);
      };
    })(this));
  };

  AtividadeController.prototype.enviarLembreteExecucao = function(mensagem) {
    return $as.Atividades.Atividades.EnviarEmailLembreteExecucao.post({
      idDaAtividade: this.id,
      mensagem: mensagem
    });
  };

  AtividadeController.prototype.abrirModalHistoricoLembretesEnviados = function() {
    return $as.Atividades.Atividades.VisualizarHistoricoLembretesEnviados.get({
      idDaAtividade: this.id
    }).success((function(_this) {
      return function(data) {
        return $("#main-modal").html(data);
      };
    })(this));
  };

  AtividadeController.prototype.marcarDesmarcarBotaoAcaoPrivada = function(evento) {
    var iconeAcaoPrivada;
    if (this.btnAcaoPrivada.hasClass("link-desativado")) {
      return;
    }
    iconeAcaoPrivada = this.btnAcaoPrivada.children();
    if (!this.btnAcaoPrivada.hasClass("btn-warning")) {
      this.btnAcaoPrivada.addClass('btn-warning');
      this.btnAcaoPrivada.attr('data-original-title', this.resource.AcaoPrivada);
      iconeAcaoPrivada.removeClass('fa fa-unlock');
      iconeAcaoPrivada.addClass('fa fa-lock');
      this.inputAcaoPublica.val(false);
    } else {
      this.btnAcaoPrivada.removeClass('btn-warning');
      this.btnAcaoPrivada.attr('data-original-title', this.resource.AcaoPublica);
      this.inputAcaoPublica.val(true);
      iconeAcaoPrivada.removeClass('fa fa-lock');
      iconeAcaoPrivada.addClass('fa fa-unlock');
    }
    $('[rel=tooltip]', this.contexto).tooltip();
    return this.salvar(Atividades.api.atualizarLogsDaTarefa);
  };

  AtividadeController.prototype.ajustarMenuDePeridiocidade = function(evento) {
    var botao;
    botao = $(evento.currentTarget);
    $('#Periodicidade').val(botao.attr("option"));
    $('#labelPeriodicidade').text(botao.text());
    return this.salvar(Atividades.api.notificarMudanca);
  };

  AtividadeController.prototype.atualizarCampoDeAvisoDaExecucao = function() {
    var option, text;
    option = $('#AvisoDeExecucao', this.contexto).val();
    text = $("[option=" + option + "]", this.contexto).text();
    $("#TextoDoAvisoDeExecucaoSelecionado", this.contexto).text(text);
    if (option === "NaData") {
      this.divDataAvisoDeExecucao.show();
      return this.inputDataAvisoDeExecucao.focus();
    }
  };

  AtividadeController.prototype.ajustarMenuDeAviso = function(evento) {
    var botao, option;
    botao = $(evento.currentTarget);
    option = botao.attr("option");
    $('#AvisoDeExecucao').val(option);
    if (option === "NaData") {
      this.divDataAvisoDeExecucao.show();
      this.inputDataAvisoDeExecucao.focus();
    } else {
      this.divDataAvisoDeExecucao.hide();
      this.inputDataAvisoDeExecucao.val('');
      this.salvar(Atividades.api.atualizarLogsDaTarefa);
    }
    return this.atualizarCampoDeAvisoDaExecucao();
  };

  AtividadeController.prototype.recarregarResponsavel = function() {
    return $as.Atividades.Atividades.ObterNomeDoResponsavel.get({
      idDaAtividade: this.id
    }).done((function(_this) {
      return function(data) {
        $('label.js-nomeresponsavel', _this.contexto).text(data.NomeDoResponsavel);
        return $('#emaildoresponsavel', _this.contexto).hide();
      };
    })(this));
  };

  AtividadeController.prototype.recarregarAssinantes = function() {
    return $as.Atividades.Assinaturas.AssinaturasPorTarefa.get({
      idDaTarefa: this.id
    }).done((function(_this) {
      return function(data) {
        return $("#container-assinaturas-" + _this.id).html(data);
      };
    })(this));
  };

  AtividadeController.prototype.atualizarTransferenciaDeResponsabilidade = function() {
    this.recarregarResponsavel();
    this.recarregarHistorico();
    this.recarregarAssinantes();
    this.fechar.unbind('click');
    return this.fechar.click((function(_this) {
      return function() {
        Atividades.api.notificarMudanca(_this.id);
        return _this.fecharAtividade();
      };
    })(this));
  };

  AtividadeController.prototype.inserirComentario = function() {
    if (this.inputComentario.val()) {
      return $as.Atividades.Comentarios.InserirComentario.post({
        idDaAtividade: this.id,
        comentario: this.inputComentario.val()
      }).done((function(_this) {
        return function(data) {
          if (data.success) {
            _this.resetarCampoComentario();
            _this.inputComentario.val('');
            swIntercom('Comentou uma tarefa');
            return Atividades.api.notificarMudanca(_this.id);
          } else {
            return window.modalAlert(data.data.mensagem, null);
          }
        };
      })(this));
    }
  };

  AtividadeController.prototype.calcularNumeroDeDocumentosEmEventos = function() {
    if (this.id) {
      return Atividades.api.calcularNumeroDeDocumentosEmEventos(this.id);
    }
  };

  AtividadeController.prototype.configurarSalvar = function() {
    var atualizarLogs;
    atualizarLogs = Atividades.api.atualizarLogsDaTarefa;
    $("#Prazo", this.contexto).change((function(_this) {
      return function() {
        return _this.salvar(atualizarLogs);
      };
    })(this));
    $("#Causa", this.contexto).change((function(_this) {
      return function() {
        return _this.salvar(atualizarLogs);
      };
    })(this));
    $("#Como", this.contexto).change((function(_this) {
      return function() {
        return _this.salvar(atualizarLogs);
      };
    })(this));
    $("#FimPrevisto", this.contexto).change((function(_this) {
      return function() {
        return _this.salvar(atualizarLogs);
      };
    })(this));
    $("#InicioPrevisto", this.contexto).change((function(_this) {
      return function() {
        return _this.salvar(atualizarLogs);
      };
    })(this));
    $("#Onde", this.contexto).change((function(_this) {
      return function() {
        return _this.salvar(atualizarLogs);
      };
    })(this));
    $("#OQue", this.contexto).change((function(_this) {
      return function() {
        return _this.salvar(atualizarLogs);
      };
    })(this));
    $("#Porque", this.contexto).change((function(_this) {
      return function() {
        return _this.salvar(atualizarLogs);
      };
    })(this));
    $("#Quanto", this.contexto).change((function(_this) {
      return function() {
        return _this.salvar(atualizarLogs);
      };
    })(this));
    $("#QuantoPrevisto", this.contexto).change((function(_this) {
      return function() {
        return _this.salvar(atualizarLogs);
      };
    })(this));
    $("#QuantoRealizado", this.contexto).change((function(_this) {
      return function() {
        return _this.salvar(atualizarLogs);
      };
    })(this));
    return this.inputDataAvisoDeExecucao.change((function(_this) {
      return function() {
        return _this.salvar(atualizarLogs);
      };
    })(this));
  };

  AtividadeController.prototype.salvar = function(funcao) {
    if (this.options.permitirSalvarSobDemanda) {
      return this.postarFormulario(funcao);
    } else {
      return this.btnSalvar.addClass("btn-success");
    }
  };

  AtividadeController.prototype.postarFormulario = function(funcao) {
    return $as.Atividades.Atividades.CreateEdit.post($(":input:not(.notPost)", this.contexto).serialize()).done((function(_this) {
      return function(data) {
        var $data, errors;
        if (data.success) {
          $('#validation-errors').empty();
          swIntercom('Editou uma tarefa');
          return funcao(_this.id);
        } else {
          $data = $(data);
          errors = $("[class=validation-summary-errors]", $data).html();
          return $('#validation-errors').html(errors);
        }
      };
    })(this));
  };

  AtividadeController.prototype.criarComentarioDoDocumento = function(idDoAgregador) {
    return $as.Atividades.Atividades.AdicionarComentarioDoDocumento.post({
      idDoAgregador: idDoAgregador,
      idDaAtividade: this.id
    }).done((function(_this) {
      return function(data) {
        return Atividades.api.notificarMudanca(_this.id);
      };
    })(this));
  };

  AtividadeController.prototype.resetarCampoComentario = function() {
    this.esconderContainerEnvioComentario();
    this.descricaoMention.height(18);
    this.descricaoMention.data('mentionsInput').reset();
    this.descricaoMention.val('');
    return this.descricaoMention.height(18);
  };

  AtividadeController.prototype.configurarComentario = function() {
    return this.descricaoMention.keypress((function(_this) {
      return function() {
        if (_this.descricaoMention.val() === '' || _this.envioComentarioContainer.hasClass('js-hide')) {
          _this.envioComentarioContainer.fadeIn(400);
          return _this.envioComentarioContainer.removeClass('js-hide');
        }
      };
    })(this));
  };

  AtividadeController.prototype.esconderContainerEnvioComentario = function() {
    this.envioComentarioContainer.fadeOut(400);
    return this.envioComentarioContainer.addClass('js-hide');
  };

  AtividadeController.prototype.exibirPopoverListagemReduzida = function(event) {
    var $el, evt, placement, tag, urlDetalhesAtividade;
    event.preventDefault();
    evt = event || window.event;
    tag = evt.target.tagName || evt.srcElement.tagName;
    if (tag === 'A') {
      return;
    }
    $(".popover").remove();
    $el = $(evt.currentTarget);
    placement = 'left';
    if ($el.closest('[data-placement-popover]').data("placement-popover")) {
      placement = $el.closest('[data-placement-popover]').data("placement-popover");
    }
    urlDetalhesAtividade = $el.data("url-detalhes-atividade");
    if (urlDetalhesAtividade) {
      return $.get(urlDetalhesAtividade).done((function(_this) {
        return function(data) {
          var $data, callPopover, content, template, title;
          $data = $(data);
          title = $data.find("#detalhes-atividade-title").html();
          title += '<span class="fr cursor-pointer" onclick="popover.close($(this))"><i class="fa fa-times fa-1"></i></span>';
          template = "<div class='popover' role='tooltip'> <div class='arrow'></div> <h3 class='popover-title-atividade'>" + title + "</h3> <div class='popover-content'></div> </div>";
          content = $data.find("#detalhes-atividade-content").html();
          callPopover = function() {
            $el.popover({
              trigger: 'manual',
              html: true,
              template: template,
              content: content,
              placement: placement
            });
            $el.popover('show');
          };
          setTimeout(callPopover, 200);
        };
      })(this));
    }
  };

  AtividadeController.prototype.configurarMostrarDetalhesDeEventos = function() {
    var timeFade;
    timeFade = 300;
    return $('.js-ver-detalhes', this.view).unbind('click').click((function(_this) {
      return function(evento) {
        var containerDetalhes, linkDetalhes;
        linkDetalhes = $(evento.currentTarget);
        containerDetalhes = $("#container-detalhes-" + (linkDetalhes.data('id')));
        if (containerDetalhes.hasClass('js-hide')) {
          containerDetalhes.removeClass('js-hide');
          containerDetalhes.fadeIn(timeFade);
          return linkDetalhes.text(linkDetalhes.data('text-hide'));
        } else {
          containerDetalhes.addClass('js-hide');
          containerDetalhes.fadeOut(timeFade);
          linkDetalhes.html(_this.resource.VerDetalhes);
          return linkDetalhes.text(linkDetalhes.data('text-show'));
        }
      };
    })(this));
  };

  AtividadeController.prototype.executarAoRecarregarReferencias = function() {
    return this.configurarMostrarDetalhesDeEventos();
  };

  AtividadeController.prototype.configurarCabecalho = function() {
    return $('.show-drop-trigger').click(function(e) {
      var $elemento;
      $elemento = $(e.delegateTarget);
      $elemento.parent().toggleClass('active');
      if ($elemento.parent().hasClass('active') || $elemento.parent().hasClass('open')) {
        $elemento.next().click();
      }
      return e.stopPropagation();
    });
  };

  return AtividadeController;

})();
