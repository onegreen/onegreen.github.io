﻿this.Onegreen || (this.Onegreen = {});

Onegreen.api = (function() {
  function api() {}

  api.desmarcaMenu = function() {
    return $("#menuSuperior li").removeClass("active");
  };

  api.fecharMegaMenu = function() {
    return $("#megaMenu").removeClass("open");
  };

  return api;

})();
