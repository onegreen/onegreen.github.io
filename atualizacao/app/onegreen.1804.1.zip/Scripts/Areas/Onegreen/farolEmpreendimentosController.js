﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.FarolEmpreendimentosController = (function() {
  function FarolEmpreendimentosController(opcoes) {
    this.opcoes = opcoes;
    this.configurarPopoverDeInformacoes = bind(this.configurarPopoverDeInformacoes, this);
    this.carregarLicecasProjetosFilhosComAlerta = bind(this.carregarLicecasProjetosFilhosComAlerta, this);
    this.carregarLicencasPorTipo = bind(this.carregarLicencasPorTipo, this);
    this.esconderAgrupamento = bind(this.esconderAgrupamento, this);
    this.identarDesdobramento = bind(this.identarDesdobramento, this);
    this.carregarAgrupamento = bind(this.carregarAgrupamento, this);
    this.toggleAgrupamento = bind(this.toggleAgrupamento, this);
    this.bindDesdobramento = bind(this.bindDesdobramento, this);
    this.configurarBind = bind(this.configurarBind, this);
    this.configurarBind();
  }

  FarolEmpreendimentosController.prototype.configurarBind = function() {
    this.bindDesdobramento($(this.opcoes.Contexto));
    return this.configurarPopoverDeInformacoes();
  };

  FarolEmpreendimentosController.prototype.bindDesdobramento = function(contexto) {
    contexto.find('.js-agrupamento').on('click', this.toggleAgrupamento);
    contexto.find('.js-tipo-licenca').on('click', this.carregarLicencasPorTipo);
    contexto.find('.js-alerta').on('click', this.carregarLicecasProjetosFilhosComAlerta);
    return $("[rel=tooltip]").tooltip();
  };

  FarolEmpreendimentosController.prototype.toggleAgrupamento = function(event) {
    var $element, $icone, $table;
    $element = $(event.delegateTarget);
    $icone = $("i", $element);
    $table = $element.closest('table');
    if ($icone.hasClass('fa-plus-square')) {
      $icone.removeClass('fa-plus-square');
      $icone.addClass('fa-minus-square');
      return this.carregarAgrupamento($icone.closest('tr'));
    } else {
      $icone.removeClass('fa-minus-square');
      $icone.addClass('fa-plus-square');
      return this.esconderAgrupamento($icone.closest('tr'));
    }
  };

  FarolEmpreendimentosController.prototype.carregarAgrupamento = function(linha) {
    console.log('teste');
    return $as.Onegreen.Empreendimentos.RetornarAgrupamento.get({
      idDoProjeto: linha.data('idprojeto'),
      hierarquia: linha.data('hierarquia'),
      exibirCanceladas: this.opcoes.ExibirCanceladas
    }).done((function(_this) {
      return function(html) {
        var tabela;
        html = $($.parseHTML(html));
        tabela = linha.closest("table");
        _this.identarDesdobramento(html, linha.data('hierarquia') + 1);
        linha.after(html);
        return _this.bindDesdobramento(html);
      };
    })(this));
  };

  FarolEmpreendimentosController.prototype.identarDesdobramento = function(contexto, hierarquia) {
    var margin;
    margin = 30 * hierarquia;
    return $('.js-nome-projeto', contexto).css('margin-left', margin + "px");
  };

  FarolEmpreendimentosController.prototype.esconderAgrupamento = function(linha) {
    var hierarquiaLinha, linhaAux, results;
    hierarquiaLinha = linha.data('hierarquia');
    linha = linha.next('tr');
    results = [];
    while (linha.data('hierarquia') > hierarquiaLinha) {
      linhaAux = linha;
      linha = linhaAux.next('tr');
      results.push(linhaAux.remove());
    }
    return results;
  };

  FarolEmpreendimentosController.prototype.carregarLicencasPorTipo = function(event) {
    var $divFarois, idDoProjeto, idDoTipoDeLicenca;
    $divFarois = $(event.target).closest('[data-empreendimento]');
    idDoProjeto = $divFarois.data('empreendimento');
    idDoTipoDeLicenca = $(event.target).data('tipo-licenca');
    return $as.Onegreen.LicencasAmbientais.RetornarLicencasDoProjetoPorTipo.get({
      idDoProjeto: idDoProjeto,
      idDoTipoDeLicenca: idDoTipoDeLicenca
    }).success((function(_this) {
      return function(data) {
        window.GetDiv('popoverlicencas-modal-container').html(data);
        return $('#popoverlicencas-modal').window();
      };
    })(this));
  };

  FarolEmpreendimentosController.prototype.carregarLicecasProjetosFilhosComAlerta = function(event) {
    var $divFarois, idDoProjeto;
    $divFarois = $(event.target).closest('[data-empreendimento]');
    idDoProjeto = $divFarois.data('empreendimento');
    return $as.Onegreen.LicencasAmbientais.RetornarLicencasDoProjetoEFilhosComAlerta.get({
      idDoProjeto: idDoProjeto
    }).success((function(_this) {
      return function(data) {
        window.GetDiv('popoverlicencas-modal-container').html(data);
        return $('#popoverlicencas-modal').window();
      };
    })(this));
  };

  FarolEmpreendimentosController.prototype.configurarPopoverDeInformacoes = function() {
    return $('#exibir-legenda').on('click', (function(_this) {
      return function() {
        if (!$('#tabela-informacoes-de-legenda').data('exibido')) {
          $('#tabela-informacoes-de-legenda').stop().animate({
            right: '15px'
          });
          return $('#tabela-informacoes-de-legenda').data('exibido', true);
        } else {
          $('#tabela-informacoes-de-legenda').stop().animate({
            right: '-400px'
          });
          return $('#tabela-informacoes-de-legenda').data('exibido', false);
        }
      };
    })(this));
  };

  return FarolEmpreendimentosController;

})();
