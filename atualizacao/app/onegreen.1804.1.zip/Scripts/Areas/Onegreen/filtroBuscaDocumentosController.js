﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.filtroBuscaDocumentosController = (function() {
  function filtroBuscaDocumentosController(options) {
    this.options = options;
    this.limparCampo = bind(this.limparCampo, this);
    this.configurarCamposDependentes = bind(this.configurarCamposDependentes, this);
    this.limparComboLicencas = bind(this.limparComboLicencas, this);
    this.camposDependentesLicencaAmbiental = bind(this.camposDependentesLicencaAmbiental, this);
    this.habilitarEnter = bind(this.habilitarEnter, this);
    this.SubmitFiltro = bind(this.SubmitFiltro, this);
    this.marcarTodosOsPlanosDeAcao = bind(this.marcarTodosOsPlanosDeAcao, this);
    this.desmarcarTodosOsPlanosdeAcao = bind(this.desmarcarTodosOsPlanosdeAcao, this);
    this.configurarFiltro = bind(this.configurarFiltro, this);
    this.loadComboLicencasAmbientais = bind(this.loadComboLicencasAmbientais, this);
    this.loadComboNomeProjeto = bind(this.loadComboNomeProjeto, this);
    this.loadComboUnidadeGerencial = bind(this.loadComboUnidadeGerencial, this);
    this.loadComboTiposDeDocumento = bind(this.loadComboTiposDeDocumento, this);
    this.configurarFiltro();
    this.loadComboUnidadeGerencial();
    this.loadComboNomeProjeto();
    this.loadComboTiposDeDocumento();
    this.loadComboLicencasAmbientais();
    this.desmarcarTodosOsPlanosdeAcao();
    this.marcarTodosOsPlanosDeAcao();
    this.habilitarEnter();
    this.configurarCamposDependentes();
    $('.aplicarFiltro').unbind('click').click(this.SubmitFiltro);
    $('#LimparFiltro', this.options.contexto).unbind('click').click(this.limparCampo);
  }

  filtroBuscaDocumentosController.prototype.loadComboTiposDeDocumento = function() {
    return setCombo(this.options.contexto, "#TipoDeDocumentoNome");
  };

  filtroBuscaDocumentosController.prototype.loadComboUnidadeGerencial = function() {
    return setCombo(this.options.contexto, "#UnidadeGerencialNome");
  };

  filtroBuscaDocumentosController.prototype.loadComboNomeProjeto = function() {
    return setCombo(this.options.contexto, '#EmpreendimentoNome', this.camposDependentesLicencaAmbiental);
  };

  filtroBuscaDocumentosController.prototype.loadComboLicencasAmbientais = function() {
    var parametros;
    parametros = {
      idDoEmpreendimento: $('#Empreendimento').val()
    };
    return setCombo(this.options.contexto, '#LicencaAmbientalNome', null, parametros);
  };

  filtroBuscaDocumentosController.prototype.configurarFiltro = function() {
    $("#filtro-busca-documento").on('click', (function(_this) {
      return function() {
        return $("#filtro-busca-documento-container").toggle();
      };
    })(this));
    return $("#fechar-filtro", this.options.contexto).on('click', (function(_this) {
      return function() {
        return $("#filtro-busca-documento-container").toggle();
      };
    })(this));
  };

  filtroBuscaDocumentosController.prototype.desmarcarTodosOsPlanosdeAcao = function() {
    return $("#desmarcar-todos").on('click', (function(_this) {
      return function() {
        return $("input", "#container-selecao-de-planos-de-acao").prop("checked", false);
      };
    })(this));
  };

  filtroBuscaDocumentosController.prototype.marcarTodosOsPlanosDeAcao = function() {
    return $("#marcar-todos").on('click', (function(_this) {
      return function() {
        return $("input", "#container-selecao-de-planos-de-acao").prop("checked", true);
      };
    })(this));
  };

  filtroBuscaDocumentosController.prototype.SubmitFiltro = function() {
    var dados;
    dados = $('#main').find(":input").serialize();
    return $as.Onegreen.BuscarDocumentos.Filtro.get(dados).success((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  filtroBuscaDocumentosController.prototype.habilitarEnter = function() {
    return $('#NomeDesc').keypress((function(_this) {
      return function(event) {
        if (event.keyCode === 13) {
          return _this.SubmitFiltro();
        }
      };
    })(this));
  };

  filtroBuscaDocumentosController.prototype.camposDependentesLicencaAmbiental = function() {
    var empreendimentoSelecionado;
    empreendimentoSelecionado = $('#Empreendimento').val() !== null && $('#Empreendimento').val() !== 0 && $('#Empreendimento').val() !== void 0 && $('#Empreendimento').val() !== '';
    if (empreendimentoSelecionado) {
      this.loadComboLicencasAmbientais();
      this.limparComboLicencas();
    } else {
      this.limparComboLicencas();
    }
    return $('#LicencaAmbientalNome').data('autocompleter').disableElseEnable(!empreendimentoSelecionado);
  };

  filtroBuscaDocumentosController.prototype.limparComboLicencas = function() {
    $('#LicencaAmbiental').val('');
    return $('#LicencaAmbientalNome').val('');
  };

  filtroBuscaDocumentosController.prototype.configurarCamposDependentes = function() {
    var empreendimentoSelecionado, licencaSelecionada;
    empreendimentoSelecionado = $('#Empreendimento').val() !== null && $('#Empreendimento').val() !== 0 && $('#Empreendimento').val() !== void 0 && $('#Empreendimento').val() !== '';
    licencaSelecionada = $('#LicencaAmbiental').val() !== null && $('#LicencaAmbiental').val() !== 0 && $('#LicencaAmbiental').val() !== void 0 && $('#LicencaAmbiental').val() !== '';
    if (!licencaSelecionada && !empreendimentoSelecionado) {
      this.limparComboLicencas();
      return $('#LicencaAmbientalNome').data('autocompleter').disableElseEnable(!licencaSelecionada);
    }
  };

  filtroBuscaDocumentosController.prototype.limparCampo = function() {
    $('#Empreendimento').val('');
    $('#EmpreendimentoNome').val('');
    $('#TipoDeDocumento').val('');
    $('#TipoDeDocumentoNome').val('');
    $('#UnidadeGerencial').val('');
    $('#UnidadeGerencialNome').val('');
    return this.camposDependentesLicencaAmbiental();
  };

  return filtroBuscaDocumentosController;

})();
