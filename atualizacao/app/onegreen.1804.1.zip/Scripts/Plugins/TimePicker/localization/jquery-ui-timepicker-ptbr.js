/* Spanish translation for the jQuery Timepicker Addon */
/* Written by Ianaré Sévi */
(function($) {
    $.timepicker.regional['ptbr'] = {
		timeOnlyTitle: 'Selecionar uma Hora',
		timeText: 'Hora',
		hourText: 'Horas',
		minuteText: 'Minutos',
		secondText: 'Segundos',
		timezoneText: 'Fuso Horário',
		currentText: 'Agora',
		closeText: 'Fechar',
		timeFormat: 'hh:mm',
		ampm: false
	};
$.timepicker.setDefaults($.timepicker.regional['ptbr']);
})(jQuery);
