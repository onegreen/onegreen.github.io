﻿$(function() {
  $('body').on('focus', '[data-tag]', function() {
    var $el, context, createIfNotExists, functionOnSelect, id, inputId, tagsContainer;
    $el = $(this);
    if (!$el.data('tag-loaded')) {
      $el.data('tag-loaded', 'loaded');
      id = $el.attr('data-tag');
      context = '#tags-' + id;
      inputId = '#tagName-' + id;
      createIfNotExists = true;
      tagsContainer = '#tags-container-' + id;
      functionOnSelect = function(e) {
        return window.adicionarTag(e.val(), $(context).attr('data-tag-tipoobjeto'), $(context).attr('data-tag-idobjeto'), tagsContainer, inputId);
      };
      $('#btn-add-tag-' + id).click(function() {
        return window.adicionarTag($(inputId).val(), $(context).attr('data-tag-tipoobjeto'), $(context).attr('data-tag-idobjeto'), tagsContainer, inputId);
      });
      setCombo(context, inputId, functionOnSelect, null, createIfNotExists);
      return $(inputId, context).data('autocompleter').options.selectOnTypeArrow = false;
    }
  });
  return window.adicionarTag = function(idDaTag, tipoDoObjeto, idDoObjeto, container, inputId) {
    return $as.Tags.Adicionar.post({
      idDaTag: idDaTag,
      nomeTag: $(inputId).val(),
      idDoObjeto: idDoObjeto,
      tipoDoObjeto: tipoDoObjeto
    }).done(function(data) {
      $(container).html(data);
      $(inputId).val('');
      return $(inputId).tooltip('show');
    });
  };
});
