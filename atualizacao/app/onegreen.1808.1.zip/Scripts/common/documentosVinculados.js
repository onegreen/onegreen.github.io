﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.documentosVinculados = (function() {
  var campoDescricaoGD, campoLinkGD, containerGD, multiSelectGD, seletorGD;

  function documentosVinculados(contexto, options1) {
    this.contexto = contexto;
    this.options = options1;
    this.wlCallbackWithoutMultiSelect = bind(this.wlCallbackWithoutMultiSelect, this);
    this.wlCallbackWithMultiSelect = bind(this.wlCallbackWithMultiSelect, this);
    this.loadSkyDriveScripts = bind(this.loadSkyDriveScripts, this);
    this.selecionarDocumentoPeloSkyDrive = bind(this.selecionarDocumentoPeloSkyDrive, this);
    this.pickerCallBackWithMultiSelect = bind(this.pickerCallBackWithMultiSelect, this);
    this.createPickerWithoutMultiSelect = bind(this.createPickerWithoutMultiSelect, this);
    this.createPickerWithMultiSelect = bind(this.createPickerWithMultiSelect, this);
    this.openPicker = bind(this.openPicker, this);
    this.loadGoogleDriveScripts = bind(this.loadGoogleDriveScripts, this);
    this.criarDocumentosPeloDropBox = bind(this.criarDocumentosPeloDropBox, this);
    this.criarDocumentosPeloSkyDrive = bind(this.criarDocumentosPeloSkyDrive, this);
    this.criarDocumentosPeloGoogleDrive = bind(this.criarDocumentosPeloGoogleDrive, this);
    this.vinculoDeLink = bind(this.vinculoDeLink, this);
    this.vinculoDeArquivo = bind(this.vinculoDeArquivo, this);
    this.tabArquivo = $('#tabArquivo', this.contexto);
    this.tabLink = $('#tabLink', this.contexto);
    this.tipoDeVinculo = $('#TipoVinculoDocumento', this.contexto);
    this.tabArquivo.click(this.vinculoDeArquivo);
    this.tabLink.click(this.vinculoDeLink);
    setTimeout(function() {
      return $('#modal-adicionar-documento').window({
        width: '700px'
      });
    }, 5);
    $('#modal-adicionar-documento').css('z-index', WindowZIndex++);
  }

  documentosVinculados.prototype.vinculoDeArquivo = function() {
    return this.tipoDeVinculo.val(this.options.ehArquivo);
  };

  documentosVinculados.prototype.vinculoDeLink = function() {
    return this.tipoDeVinculo.val(this.options.ehLink);
  };

  containerGD = void 0;

  seletorGD = void 0;

  multiSelectGD = void 0;

  campoDescricaoGD = void 0;

  campoLinkGD = void 0;

  documentosVinculados.prototype.criarDocumentosPeloGoogleDrive = function(seletor) {
    seletorGD = seletor;
    multiSelectGD = true;
    return $(seletorGD).click((function(_this) {
      return function() {
        return _this.loadGoogleDriveScripts(true);
      };
    })(this));
  };

  documentosVinculados.prototype.criarDocumentosPeloSkyDrive = function(seletor) {
    seletorGD = seletor;
    multiSelectGD = true;
    return $(seletorGD).click((function(_this) {
      return function() {
        return _this.loadSkyDriveScripts();
      };
    })(this));
  };

  documentosVinculados.prototype.criarDocumentosPeloDropBox = function(seletor) {
    return $(seletor).click((function(_this) {
      return function() {
        var options;
        options = {
          success: function(files) {
            return $.ajax({
              type: "POST",
              url: DocumentosOptions.adicionarDocumentoDoDropBoxUrl,
              contentType: "application/json",
              data: JSON.stringify(files),
              success: function(data) {
                return data;
              }
            });
          },
          cancel: function() {},
          multiselect: true
        };
        return Dropbox.choose(options);
      };
    })(this));
  };

  documentosVinculados.prototype.selecionarDocumentoPeloDropBox = function(seletor, campoDescricao, campoLink, container) {
    return $(seletor, container).click(function() {
      var options;
      $("#tipo-link", "#modal-adicionar-documento").click();
      options = {
        success: function(files) {
          var file;
          file = files[0];
          $(campoDescricao, container).val(file.name);
          return $(campoLink, container).val(file.link);
        },
        cancel: function() {}
      };
      return Dropbox.choose(options);
    });
  };

  documentosVinculados.prototype.selecionarDocumentoPeloGoogleDrive = function(seletor, campoDescricao, campoLink, container) {
    containerGD = container;
    seletorGD = seletor;
    multiSelectGD = false;
    campoDescricaoGD = campoDescricao;
    campoLinkGD = campoLink;
    return $(seletor, container).click((function(_this) {
      return function() {
        $("#tipo-link", "#modal-adicionar-documento").click;
        return _this.loadGoogleDriveScripts(false);
      };
    })(this));
  };

  documentosVinculados.prototype.loadGoogleDriveScripts = function(multiSelect) {
    this.multiSelectGD = multiSelect;
    return authInGoogle(this.openPicker);
  };

  documentosVinculados.prototype.openPicker = function() {
    if (this.multiSelectGD) {
      gapi.load("picker", {
        "callback": this.createPickerWithMultiSelect
      });
    } else {
      gapi.load("picker", {
        "callback": this.createPickerWithoutMultiSelect
      });
    }
    return $('#loading').fadeOut();
  };

  documentosVinculados.prototype.createPickerWithMultiSelect = function() {
    var picker;
    picker = new google.picker.PickerBuilder().enableFeature(google.picker.Feature.MULTISELECT_ENABLED).setOAuthToken(window.googleOauthToken).addView(new google.picker.View(google.picker.ViewId.DOCS)).setCallback(this.pickerCallBackWithMultiSelect).build();
    return picker.setVisible(true);
  };

  documentosVinculados.prototype.createPickerWithoutMultiSelect = function() {
    var picker;
    picker = new google.picker.PickerBuilder().setOAuthToken(window.googleOauthToken).addView(new google.picker.View(google.picker.ViewId.DOCS)).addView(new google.picker.DocsUploadView()).setCallback(this.pickerCallBackWithoutMultiSelect).build();
    return picker.setVisible(true);
  };

  documentosVinculados.prototype.pickerCallBackWithMultiSelect = function(data) {
    if (data.action === google.picker.Action.PICKED) {
      return $.ajax({
        type: "POST",
        url: DocumentosOptions.adicionarDocumentoDoGoogleDriveUrl,
        contentType: "application/json",
        data: JSON.stringify(data.docs),
        success: function(data) {
          return data;
        }
      });
    }
  };

  documentosVinculados.prototype.pickerCallBackWithoutMultiSelect = function(data) {
    var file;
    if (data.action === google.picker.Action.PICKED) {
      file = data.docs[0];
      $(campoDescricaoGD, containerGD).val(file.name);
      return $(campoLinkGD, containerGD).val(file.url);
    }
  };

  documentosVinculados.prototype.selecionarDocumentoPeloSkyDrive = function(seletor, campoDescricao, campoLink, container) {
    containerGD = container;
    seletorGD = seletor;
    multiSelectGD = false;
    campoDescricaoGD = campoDescricao;
    campoLinkGD = campoLink;
    return $(seletor, container).click((function(_this) {
      return function() {
        $("#tipo-link", "#modal-adicionar-documento").click;
        return _this.loadSkyDriveScripts();
      };
    })(this));
  };

  documentosVinculados.prototype.loadSkyDriveScripts = function() {
    WL.init({
      client_id: DocumentosOptions.client_id,
      redirect_uri: DocumentosOptions.redirect_uri,
      scope: "wl.signin",
      response_type: "token"
    });
    return WL.login({
      "scope": "wl.skydrive wl.signin"
    }).then(((function(_this) {
      return function(response) {
        if (multiSelectGD) {
          _this.wlCallbackWithMultiSelect();
        } else {
          _this.wlCallbackWithoutMultiSelect();
        }
        return function(response) {};
      };
    })(this)));
  };

  documentosVinculados.prototype.wlCallbackWithMultiSelect = function() {
    return WL.filedialog({
      mode: "open",
      select: "multi"
    }).then((function(_this) {
      return function(response) {
        var files;
        files = response.data.files;
        if (files == null) {
          files = response.data.folders;
        }
        return $.ajax({
          type: "POST",
          url: DocumentosOptions.adicionarDocumentoDoSkyDriveUrl,
          contentType: "application/json",
          data: JSON.stringify(files),
          success: function(data) {
            return data;
          }
        });
      };
    })(this), function(errorResponse) {});
  };

  documentosVinculados.prototype.wlCallbackWithoutMultiSelect = function(data) {
    return WL.filedialog({
      mode: "open",
      select: "single"
    }).then(function(response) {
      var file;
      file = response.data.files;
      if (file == null) {
        file = response.data.folders;
      }
      file = file[0];
      $(campoDescricaoGD, containerGD).val(file.name);
      return $(campoLinkGD, containerGD).val(file.link);
    }, function(errorResponse) {});
  };

  return documentosVinculados;

})();
