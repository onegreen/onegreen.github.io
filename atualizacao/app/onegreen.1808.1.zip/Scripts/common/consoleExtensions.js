﻿var alertFallback;

this.console || (this.console = {});

alertFallback = true;

if (!console.log) {
  if (alertFallback) {
    console.log = function(msg) {};
  } else {
    console.log = function() {};
  }
}
