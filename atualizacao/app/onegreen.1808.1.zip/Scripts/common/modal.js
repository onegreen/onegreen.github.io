﻿$(function() {
  return $(window).resize(function() {});
});

window.CalcularTamanhoDoRodapeDaModal = function(elemento) {
  var alturaDoRodape, elementosDoRodape, i, j, ref;
  elementosDoRodape = elemento.children();
  alturaDoRodape = 0;
  for (i = j = 0, ref = elementosDoRodape.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
    alturaDoRodape += $(elementosDoRodape[i]).height();
  }
  return alturaDoRodape;
};

window.reposicionarModal = function(idModal) {
  var alturaModal, alturaTela, modal;
  modal = $("#" + idModal);
  alturaTela = $(window).height();
  alturaModal = modal.height();
  return modal.css('margin-top', (alturaTela - alturaModal) / 2);
};

window.redimensionarModalLateral = function() {
  return $(window).resize();
};

window.posicionarModal = function() {
  $('#modal .close').click(function(event) {
    if (event.preventDefault) {
      event.preventDefault();
    } else {
      event.returnValue = false;
    }
    $(this).parents('#modal').fadeOut('fast');
    $('#modalShadow').hide();
  });
  $('#modal .executeClose').click(function(event) {
    $(this).parents('#modal').fadeOut('fast');
    $('#modalShadow').hide();
  });
  sb_windowTools.updateDimensions();
  $('#modalShadow').css({
    height: sb_windowTools.pageDimensions.pageHeight()
  });
  $('#modal').css({
    top: (sb_windowTools.pageDimensions.windowHeight() / 2) - $('#modal').outerHeight() / 2 + 'px',
    left: (sb_windowTools.pageDimensions.windowWidth() / 2) - $('#modal').outerWidth() / 2 + 'px'
  });
  $('#modalShadow').show();
  $('#modal').fadeIn('slow');
  $('.alerta a').focus();
};

this.modalLateral = (function() {
  function modalLateral(idModal) {
    $(idModal).css({
      'position': 'absolute',
      'z-index': ++WindowZIndex - 3000
    });
  }

  return modalLateral;

})();
