﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.ciclosDeAvaliacaoController = (function() {
  function ciclosDeAvaliacaoController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.aoAdicionarCiclo = bind(this.aoAdicionarCiclo, this);
    this.salvarERetornar = bind(this.salvarERetornar, this);
    this.salvarEAvancar = bind(this.salvarEAvancar, this);
    this.aoSelecionarAvaliacaoDeChefia = bind(this.aoSelecionarAvaliacaoDeChefia, this);
    this.aoSelecionarAvaliacaoNineBox = bind(this.aoSelecionarAvaliacaoNineBox, this);
    this.aoSelecionarEixoVertical = bind(this.aoSelecionarEixoVertical, this);
    this.setChangeRadio = bind(this.setChangeRadio, this);
    this.definirDatePicker = bind(this.definirDatePicker, this);
    this.setarMascaras = bind(this.setarMascaras, this);
    this.loadAutoComplete = bind(this.loadAutoComplete, this);
    this.bloquearCampos = bind(this.bloquearCampos, this);
    this.idDoCiclo = $(this.contexto).find('#Id').val();
    this.novoRegistro = this.idDoCiclo === 0;
    this.loadAutoComplete();
    this.setarMascaras();
    this.definirDatePicker();
    this.setChangeRadio();
    this.bloquearCampos();
    $(this.contexto).window();
    this.botaoSalvarEConfigurar = $(this.contexto).find('#btnSalvarEConfigurarNineBox');
    this.botaoFechar = $('#close-modal-ciclodeavaliacao', this.contexto);
    this.botaoFechar.click(this.reload);
  }

  ciclosDeAvaliacaoController.prototype.bloquearCampos = function() {
    if (this.options.Status !== 'EmElaboracao') {
      $(this.contexto).find(':input').not('.not-disabled').attr('disabled', 'disabled');
      $('#DataDeInicioDaAvaliacaoBtn').attr('disabled', 'disabled');
      $('#DataDeFimDaAvaliacaoBtn').attr('disabled', 'disabled');
      $('#avancar').removeAttr('disabled');
      $('#retornar').removeAttr('disabled');
      if (this.options.Status === 'EmAvaliacao') {
        $('#DataDeFimDaAvaliacao').removeAttr('disabled');
        $('#DataDeFimDaAvaliacaoBtn').removeAttr('disabled');
        return $('#btnSalvar').removeAttr('disabled');
      }
    }
  };

  ciclosDeAvaliacaoController.prototype.loadAutoComplete = function() {
    setCombo(this.contexto, '#MatrizDeAvaliacao_Nome');
    return setCombo(this.contexto, '#ProgramaDeResultados_Sigla');
  };

  ciclosDeAvaliacaoController.prototype.setarMascaras = function() {
    return $("input[alt=integer_4]", this.contexto).setMask({
      autoTab: false
    });
  };

  ciclosDeAvaliacaoController.prototype.definirDatePicker = function() {
    window.BindDatePickers();
    $("#DataDeInicioDaAvaliacao").data('datepicker').setStartDate(this.options.DataMinimaParaOInicioDaAvaliacao);
    $("#DataDeInicioDaAvaliacao").data('datepicker').setEndDate(this.options.DataLimiteParaOInicioDaAvaliacao);
    return $("#DataDeFimDaAvaliacao").data('datepicker').setEndDate(this.options.DataLimiteParaFimDaAvaliacao);
  };

  ciclosDeAvaliacaoController.prototype.setChangeRadio = function() {
    $(this.contexto).find("input[name=HaveraAvaliacaoNinebox]:radio").change(this.aoSelecionarAvaliacaoNineBox);
    $(this.contexto).find("input[name=AvaliacaoDeChefia]:radio").change(this.aoSelecionarAvaliacaoDeChefia);
    if (!this.novoRegistro) {
      return $(this.contexto).find("input[name=EixoVerticalDoNineBox]:radio").change(this.aoSelecionarEixoVertical);
    }
  };

  ciclosDeAvaliacaoController.prototype.aoSelecionarEixoVertical = function(event) {
    var $el;
    $el = $(event.currentTarget);
    return $as.Performance.CiclosDeAvaliacao.AlterarEixoVertical.post({
      id: this.idDoCiclo,
      eixo: $el.val()
    }).done((function(_this) {
      return function(data) {};
    })(this));
  };

  ciclosDeAvaliacaoController.prototype.aoSelecionarAvaliacaoNineBox = function() {
    var nineBoxChecked, nineBoxContainer;
    nineBoxChecked = $("#HaveraAvaliacaoNinebox-Sim").attr("checked");
    nineBoxContainer = $(this.contexto).find("#avaliacao-nineBox-container");
    if (nineBoxChecked) {
      nineBoxContainer.show();
      return this.botaoSalvarEConfigurar.show();
    } else {
      nineBoxContainer.hide();
      return this.botaoSalvarEConfigurar.hide();
    }
  };

  ciclosDeAvaliacaoController.prototype.aoSelecionarAvaliacaoDeChefia = function() {
    var avaliacaoDeChefia;
    avaliacaoDeChefia = $(this.contexto).find("#avaliacao-de-chefia-container, #avaliacao-nine-box");
    if ($("#AvaliacaoDeChefia-Sim").attr("checked")) {
      avaliacaoDeChefia.show();
      return this.aoSelecionarAvaliacaoNineBox();
    } else {
      avaliacaoDeChefia.hide();
      return this.botaoSalvarEConfigurar.hide();
    }
  };

  ciclosDeAvaliacaoController.prototype.salvarEAvancar = function(msg) {
    var fn;
    fn = (function(_this) {
      return function() {
        $(_this.contexto).find('#avancar').val('true');
        $(_this.contexto).find('#retornar').val('false');
        return _this.alterarStatusDoCiclo();
      };
    })(this);
    window.modalConfirm(msg, fn);
  };

  ciclosDeAvaliacaoController.prototype.salvarERetornar = function(msg) {
    var fn;
    fn = (function(_this) {
      return function() {
        $(_this.contexto).find('#retornar').val('true');
        $(_this.contexto).find('#avancar').val('false');
        return _this.alterarStatusDoCiclo();
      };
    })(this);
    window.modalConfirm(msg, fn);
  };

  ciclosDeAvaliacaoController.prototype.aoAdicionarCiclo = function(data) {
    if (data.data.configurarNineBox) {
      return $as.Performance.CiclosDeAvaliacao.Edit.get({
        id: data.data.idDoCiclo
      }).done((function(_this) {
        return function(html) {
          $(_this.contexto).replaceWith(html);
          return setTimeout(function() {
            return $as.Performance.FaixasDeAvaliacao.Configurar.get({
              idDoCiclo: data.data.idDoCiclo
            }).done(function(ninebox) {
              return window.GetDiv('FaixasDeAvaliacao-container').html(ninebox);
            });
          }, 100);
        };
      })(this));
    } else {
      return this.reload();
    }
  };

  ciclosDeAvaliacaoController.prototype.alterarStatusDoCiclo = function() {
    var parametros;
    parametros = {
      idDoCiclo: this.idDoCiclo,
      retornar: $(this.contexto).find('#retornar').val(),
      avancar: $(this.contexto).find('#avancar').val()
    };
    return $as.Performance.CiclosDeAvaliacao.AlterarStatusDoCiclo.post(parametros).done((function(_this) {
      return function(data) {
        if (data.success) {
          return _this.botaoFechar.click();
        }
      };
    })(this));
  };

  return ciclosDeAvaliacaoController;

})();
