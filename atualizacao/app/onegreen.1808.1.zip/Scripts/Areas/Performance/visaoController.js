﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

this.VisaoController = (function(superClass) {
  extend(VisaoController, superClass);

  function VisaoController(contexto, criacao, resource) {
    this.contexto = contexto;
    this.resource = resource;
    this.buscarIndicadorPaiMaisAcima = bind(this.buscarIndicadorPaiMaisAcima, this);
    this.aoEsconderDesdobramento = bind(this.aoEsconderDesdobramento, this);
    this.aoDesdobrarIndicador = bind(this.aoDesdobrarIndicador, this);
    this.aoExcluir = bind(this.aoExcluir, this);
    this.atualizarFiltroDaVisao = bind(this.atualizarFiltroDaVisao, this);
    this.salvar = bind(this.salvar, this);
    this.carregarMenuDeVisoes = bind(this.carregarMenuDeVisoes, this);
    this.aplicarVisao = bind(this.aplicarVisao, this);
    this.submitCriarNova = bind(this.submitCriarNova, this);
    this.criarNova = bind(this.criarNova, this);
    this.atualizarIndicadores = bind(this.atualizarIndicadores, this);
    this.adicionarAgrupamentoNaVisao = bind(this.adicionarAgrupamentoNaVisao, this);
    this.adicionarAreaDeResultadoNaVisao = bind(this.adicionarAreaDeResultadoNaVisao, this);
    this.removerAgrupamentoNaVisao = bind(this.removerAgrupamentoNaVisao, this);
    this.removerAreaDeResultadoNaVisao = bind(this.removerAreaDeResultadoNaVisao, this);
    this.adicionarIndicadorNaVisao = bind(this.adicionarIndicadorNaVisao, this);
    this.removerIndicadorNaVisao = bind(this.removerIndicadorNaVisao, this);
    this.desabilitarAdicaoDeIndicadoresNaVisao = bind(this.desabilitarAdicaoDeIndicadoresNaVisao, this);
    this.oProximoIndicadorEDesdobramento = bind(this.oProximoIndicadorEDesdobramento, this);
    this.pegarReferenciasRelacionadas = bind(this.pegarReferenciasRelacionadas, this);
    this.verificarSeOIndicadorJaEstaNaVisao = bind(this.verificarSeOIndicadorJaEstaNaVisao, this);
    this.verificarSeTodosOsIndicadoresDoAgrupamentoEstaoNaVisao = bind(this.verificarSeTodosOsIndicadoresDoAgrupamentoEstaoNaVisao, this);
    this.verificarSeTodosOsIndicadoresDaAreaEstaoNaVisao = bind(this.verificarSeTodosOsIndicadoresDaAreaEstaoNaVisao, this);
    this.determinarComandoDaLinha = bind(this.determinarComandoDaLinha, this);
    this.determinarComandoDoAgrupamento = bind(this.determinarComandoDoAgrupamento, this);
    this.determinarComandoDaArea = bind(this.determinarComandoDaArea, this);
    this.habilitarAdicaoDeIndicadoresNaVisao = bind(this.habilitarAdicaoDeIndicadoresNaVisao, this);
    this.atualizarReferenciasAdicionadas = bind(this.atualizarReferenciasAdicionadas, this);
    this.fechar = bind(this.fechar, this);
    this.aoAdicionar = bind(this.aoAdicionar, this);
    this.bindsEdicao = bind(this.bindsEdicao, this);
    this.bindsCreate = bind(this.bindsCreate, this);
    this.loadEdit = bind(this.loadEdit, this);
    this.loadCreate = bind(this.loadCreate, this);
    this.seletores = bind(this.seletores, this);
    VisaoController.__super__.constructor.call(this, this.contexto, null);
    this.idVisao = this.get('#Id').val();
    this.submitComEnter = true;
    this.menuVisoes = $('#menu-visoes');
    this.desabilitarAdicaoDeIndicadoresNaVisao();
    $('[rel="tooltip"]').tooltip();
    if (criacao) {
      this.loadCreate();
    } else {
      this.loadEdit();
    }
  }

  VisaoController.prototype.seletores = function() {
    this.seletorAdicionar = 'js-adicionar-indicador-visao';
    return this.seletorRemover = 'js-remover-indicador-visao';
  };

  VisaoController.prototype.loadCreate = function() {
    return this.bindsCreate();
  };

  VisaoController.prototype.loadEdit = function() {
    var modal;
    modal = new modalLateral($(this.contexto).parent());
    this.porFiltro = this.get('#PorFiltro').val() === 'True';
    this.containerIndicadores = this.get('#indicadores-visao');
    this.containerEdicao = this.get("#editar-visao-container");
    this.botaoFechar = this.get("#fechar-edicao-visao");
    this.atualizarReferenciasAdicionadas();
    if (!this.porFiltro) {
      this.habilitarAdicaoDeIndicadoresNaVisao();
    }
    return this.bindsEdicao();
  };

  VisaoController.prototype.bindsCreate = function() {
    this.get("#salvarPorFiltro, #salvarPorIndicadores").on("click", (function(_this) {
      return function(e) {
        e.preventDefault();
        return _this.criarNova( this );
      };
    })(this));
    return this.get('form').submit(this.submitCriarNova);
  };

  VisaoController.prototype.bindsEdicao = function() {
    this.botaoFechar.click(this.fechar);
    $(this.contexto).find("input").change(this.salvar);
    this.get('#atualizarFiltro').click(this.atualizarFiltroDaVisao);
    $('#farol-indicadores').on('aoDesdobrar', '.js-farol', this.aoDesdobrarIndicador).on('aoEsconderDesdobramento', '.js-farol', this.aoEsconderDesdobramento);
    this.get('.js-remover-indicador-edicao-visao').click(this.removerIndicadorNaVisao);
    return this.get('.js-remover-area-de-resultado-edicao-visao').click(this.removerAreaDeResultadoNaVisao);
  };

  VisaoController.prototype.aoAdicionar = function(data) {
    if (data.data.AbrirEdicao) {
      VisaoController.editar(data.data.id);
    } else {
      showBottomNoty(this.resource.VisaoAdicionadaComSucesso);
    }
    return this.carregarMenuDeVisoes();
  };

  VisaoController.prototype.fechar = function() {
    this.botaoFechar.data("bs.tooltip").hide();
    $("#editar-visao-container").remove();
    this.desabilitarAdicaoDeIndicadoresNaVisao();
    return this.aplicarVisao();
  };

  VisaoController.prototype.atualizarReferenciasAdicionadas = function() {
    var i, len, ref, referencia, results;
    this.referencias = new Array();
    ref = this.get('.js-referencia-adicionada');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      referencia = ref[i];
      results.push(this.referencias[$(referencia).val()] = true);
    }
    return results;
  };

  VisaoController.prototype.habilitarAdicaoDeIndicadoresNaVisao = function() {
    var agrupamento, areaDeResultado, farol, i, j, k, len, len1, len2, ref, ref1, ref2;
    this.desabilitarAdicaoDeIndicadoresNaVisao();
    ref = $('.js-agrupamento-area', '#farol-indicadores');
    for (i = 0, len = ref.length; i < len; i++) {
      areaDeResultado = ref[i];
      areaDeResultado = $(areaDeResultado);
      $('h4', areaDeResultado).append("<i class='fa fa-plus-circle  font18 mrs mls js-adicionar-area-de-resultado-visao cursor-pointer'></i>");
      $('h4', areaDeResultado).append("<i class='fa fa-minus-circle c-vermelho font18 mrs mls js-remover-area-de-resultado-visao cursor-pointer'></i>");
      ref1 = $('.js-farol[data-hierarquia=0] .js-nome-farol,.js-farol[class*=js-agrupamento-] .js-nome-farol', areaDeResultado);
      for (j = 0, len1 = ref1.length; j < len1; j++) {
        farol = ref1[j];
        farol = $(farol);
        farol.prepend("<i class='fa fa-plus-circle  font18 mrs fr js-adicionar-indicador-visao cursor-pointer'></i>");
        farol.prepend("<i class='fa fa-minus-circle c-vermelho font18 mrs fr js-remover-indicador-visao cursor-pointer'></i>");
        $('.js-menu-indicador', farol).hide();
        $('.js-adicionar-indicador-visao', farol).click(this.adicionarIndicadorNaVisao);
        $('.js-remover-indicador-visao', farol).click(this.removerIndicadorNaVisao);
        this.determinarComandoDaLinha(farol.closest('.js-farol'));
      }
      ref2 = $('[data-agruparpor]', areaDeResultado);
      for (k = 0, len2 = ref2.length; k < len2; k++) {
        agrupamento = ref2[k];
        $(agrupamento).find('td:eq(0)').append("<i class='fa fa-plus-circle  font18 mrs mls js-adicionar-agrupamento-visao cursor-pointer'></i>");
        $(agrupamento).find('td:eq(0)').append("<i class='fa fa-minus-circle c-vermelho font18 mrs mls js-remover-agrupamento-visao cursor-pointer'></i>");
      }
      $('.js-adicionar-area-de-resultado-visao', areaDeResultado).click(this.adicionarAreaDeResultadoNaVisao);
      $('.js-remover-area-de-resultado-visao', areaDeResultado).click(this.removerAreaDeResultadoNaVisao);
      $('.js-adicionar-agrupamento-visao', areaDeResultado).click(this.adicionarAgrupamentoNaVisao);
      $('.js-remover-agrupamento-visao', areaDeResultado).click(this.removerAgrupamentoNaVisao);
      this.determinarComandoDaArea(areaDeResultado);
    }
    return this.determinarComandoDoAgrupamento();
  };

  VisaoController.prototype.determinarComandoDaArea = function(areaDeResultado) {
    var esconder, mostrar;
    if (this.verificarSeTodosOsIndicadoresDaAreaEstaoNaVisao(areaDeResultado)) {
      mostrar = '.js-remover-area-de-resultado-visao';
      esconder = '.js-adicionar-area-de-resultado-visao';
    } else {
      mostrar = '.js-adicionar-area-de-resultado-visao';
      esconder = '.js-remover-area-de-resultado-visao';
    }
    $(mostrar, areaDeResultado).show();
    return $(esconder, areaDeResultado).hide();
  };

  VisaoController.prototype.determinarComandoDoAgrupamento = function() {
    var agrupamento, esconder, i, len, mostrar, nomeAgrupamento, ref, results;
    ref = $('[data-agruparpor]');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      agrupamento = ref[i];
      nomeAgrupamento = $(agrupamento).data('agruparpor');
      if (this.verificarSeTodosOsIndicadoresDoAgrupamentoEstaoNaVisao(nomeAgrupamento)) {
        mostrar = '.js-remover-agrupamento-visao';
        esconder = '.js-adicionar-agrupamento-visao';
      } else {
        mostrar = '.js-adicionar-agrupamento-visao';
        esconder = '.js-remover-agrupamento-visao';
      }
      $(mostrar, "[data-agruparpor=" + nomeAgrupamento + "]").show();
      results.push($(esconder, "[data-agruparpor=" + nomeAgrupamento + "]").hide());
    }
    return results;
  };

  VisaoController.prototype.determinarComandoDaLinha = function(linha) {
    var esconder, mostrar;
    if (this.verificarSeOIndicadorJaEstaNaVisao(linha)) {
      mostrar = '.js-remover-indicador-visao';
      esconder = '.js-adicionar-indicador-visao';
    } else {
      mostrar = '.js-adicionar-indicador-visao';
      esconder = '.js-remover-indicador-visao';
    }
    $(mostrar, linha).show();
    return $(esconder, linha).hide();
  };

  VisaoController.prototype.verificarSeTodosOsIndicadoresDaAreaEstaoNaVisao = function(areaDeResultado) {
    var farol, i, len, ref, visao;
    ref = $('.js-farol[data-hierarquia=0],.js-farol[class*=js-agrupamento-]', areaDeResultado);
    for (i = 0, len = ref.length; i < len; i++) {
      farol = ref[i];
      visao = this.verificarSeOIndicadorJaEstaNaVisao($(farol));
      if (!visao) {
        return false;
      }
    }
    return true;
  };

  VisaoController.prototype.verificarSeTodosOsIndicadoresDoAgrupamentoEstaoNaVisao = function(nomeAgrupamento) {
    var farol, i, len, ref, visao;
    ref = $(".js-agrupamento-" + nomeAgrupamento);
    for (i = 0, len = ref.length; i < len; i++) {
      farol = ref[i];
      visao = this.verificarSeOIndicadorJaEstaNaVisao($(farol));
      if (!visao) {
        return false;
      }
    }
    return true;
  };

  VisaoController.prototype.verificarSeOIndicadorJaEstaNaVisao = function(linha) {
    var farolNaVisao, referencia, referenciasFarol, referenciasVisao;
    referencia = linha.data('referencia');
    farolNaVisao = $("#indicadores-visao tr[data-referencia=" + referencia + "]");
    if (!farolNaVisao.length) {
      return false;
    }
    referenciasFarol = this.pegarReferenciasRelacionadas(linha);
    referenciasVisao = this.pegarReferenciasRelacionadas(farolNaVisao);
    return referenciasFarol === referenciasVisao;
  };

  VisaoController.prototype.pegarReferenciasRelacionadas = function(linha) {
    var referencias;
    referencias = linha.data('referencia').toString();
    return referencias;
  };

  VisaoController.prototype.oProximoIndicadorEDesdobramento = function(linha) {
    return linha.next('tr').data('hierarquia') > 0;
  };

  VisaoController.prototype.desabilitarAdicaoDeIndicadoresNaVisao = function() {
    $(".js-adicionar-indicador-visao, .js-remover-indicador-visao, .js-adicionar-area-de-resultado-visao, .js-remover-area-de-resultado-visao,.js-adicionar-agrupamento-visao, .js-remover-agrupamento-visao", "#farol-indicadores").remove();
    return $('.js-menu-indicador', "#farol-indicadores").show();
  };

  VisaoController.prototype.removerIndicadorNaVisao = function(event) {
    var botao, linhaDoFarol, referencia;
    botao = $(event.delegateTarget);
    referencia = botao.closest('.js-farol').data('referencia');
    linhaDoFarol = $("#farol-indicadores tr[data-referencia=" + referencia + "]");
    return $as.Performance.Visoes.RemoverFarolDaVisao.post({
      idVisao: this.idVisao,
      referencia: referencia
    }).done((function(_this) {
      return function(data) {
        if (data.success) {
          VisaoController.editar(data.data.idVisao);
        }
        return _this.atualizarIndicadores(linhaDoFarol);
      };
    })(this));
  };

  VisaoController.prototype.adicionarIndicadorNaVisao = function(event) {
    var botao, linhaSelecionada, parametros, visao;
    botao = $(event.delegateTarget);
    linhaSelecionada = botao.closest('.js-farol');
    visao = FarolController.retornarVisao(linhaSelecionada.attr('id'), FarolController.visao);
    if (!visao) {
      visao = FarolController.construirNovaVisao(linhaSelecionada);
    }
    parametros = {
      idVisao: this.idVisao,
      farol: visao
    };
    return $as.Performance.Visoes.AdicionarFarolAVisao.postJson(JSON.stringify(parametros)).done((function(_this) {
      return function(data) {
        if (data.success) {
          VisaoController.editar(data.data.idVisao);
        }
        return _this.atualizarIndicadores(linhaSelecionada);
      };
    })(this));
  };

  VisaoController.prototype.removerAreaDeResultadoNaVisao = function(event) {
    var areaDeResultado, botao, farois, farol, i, len, ref, referencia, referencias;
    botao = $(event.delegateTarget);
    areaDeResultado = botao.closest('.js-agrupamento-area');
    referencias = new Array();
    farois = new Array();
    ref = $('.js-farol[data-hierarquia=0],.js-farol[class*=js-agrupamento-] ', areaDeResultado);
    for (i = 0, len = ref.length; i < len; i++) {
      farol = ref[i];
      farol = $(farol);
      referencia = farol.data('referencia');
      referencias.push(referencia);
      farois.push($('.js-farol[data-referencia=' + referencia + ']', '#farol-indicadores'));
    }
    return $as.Performance.Visoes.RemoverAreaDeResultadoDaVisao.post({
      idVisao: this.idVisao,
      referencias: referencias
    }).done((function(_this) {
      return function(data) {
        var j, len1;
        if (data.success) {
          VisaoController.editar(data.data.idVisao);
        }
        for (j = 0, len1 = farois.length; j < len1; j++) {
          farol = farois[j];
          _this.atualizarIndicadores(farol);
        }
      };
    })(this));
  };

  VisaoController.prototype.removerAgrupamentoNaVisao = function(event) {
    var botao, farois, farol, i, len, nomeAgrupamento, ref, referencia, referencias;
    botao = $(event.delegateTarget);
    nomeAgrupamento = botao.closest('.js-farol').data('agruparpor');
    referencias = new Array();
    farois = new Array();
    ref = $(".js-agrupamento-" + nomeAgrupamento);
    for (i = 0, len = ref.length; i < len; i++) {
      farol = ref[i];
      farol = $(farol);
      referencia = farol.data('referencia');
      referencias.push(referencia);
      farois.push($('.js-farol[data-referencia=' + referencia + ']', '#farol-indicadores'));
    }
    return $as.Performance.Visoes.RemoverAreaDeResultadoDaVisao.post({
      idVisao: this.idVisao,
      referencias: referencias
    }).done((function(_this) {
      return function(data) {
        var j, len1;
        if (data.success) {
          VisaoController.editar(data.data.idVisao);
        }
        for (j = 0, len1 = farois.length; j < len1; j++) {
          farol = farois[j];
          _this.atualizarIndicadores(farol);
        }
      };
    })(this));
  };

  VisaoController.prototype.adicionarAreaDeResultadoNaVisao = function(event) {
    var areaDeResultado, botao, farois, farol, i, len, parametros, ref, visao, visoes;
    botao = $(event.delegateTarget);
    areaDeResultado = botao.closest('.js-agrupamento-area');
    visoes = new Array();
    farois = new Array();
    ref = $('.js-farol[data-hierarquia=0],.js-farol[class*=js-agrupamento-]', areaDeResultado);
    for (i = 0, len = ref.length; i < len; i++) {
      farol = ref[i];
      farol = $(farol);
      visao = FarolController.retornarVisao(farol.attr('id'), FarolController.visao);
      if (!visao) {
        visao = FarolController.construirNovaVisao(farol);
      }
      visoes.push(visao);
      farois.push(farol);
    }
    parametros = {
      idVisao: this.idVisao,
      visoesDoFarol: visoes
    };
    return $as.Performance.Visoes.AdicionarAreaDeResultadoAVisao.postJson(JSON.stringify(parametros)).done((function(_this) {
      return function(data) {
        var j, len1, results;
        if (data.success) {
          VisaoController.editar(data.data.idVisao);
        }
        results = [];
        for (j = 0, len1 = farois.length; j < len1; j++) {
          farol = farois[j];
          results.push(_this.atualizarIndicadores(farol));
        }
        return results;
      };
    })(this));
  };

  VisaoController.prototype.adicionarAgrupamentoNaVisao = function(event) {
    var botao, farois, farol, i, len, nomeAgrupamento, parametros, ref, visao, visoes;
    botao = $(event.delegateTarget);
    nomeAgrupamento = botao.closest('.js-farol').data('agruparpor');
    visoes = new Array();
    farois = new Array();
    ref = $(".js-agrupamento-" + nomeAgrupamento);
    for (i = 0, len = ref.length; i < len; i++) {
      farol = ref[i];
      farol = $(farol);
      visao = FarolController.retornarVisao(farol.attr('id'), FarolController.visao);
      if (!visao) {
        visao = FarolController.construirNovaVisao(farol);
      }
      visoes.push(visao);
      farois.push(farol);
    }
    parametros = {
      idVisao: this.idVisao,
      visoesDoFarol: visoes
    };
    return $as.Performance.Visoes.AdicionarAreaDeResultadoAVisao.postJson(JSON.stringify(parametros)).done((function(_this) {
      return function(data) {
        var j, len1, results;
        if (data.success) {
          VisaoController.editar(data.data.idVisao);
        }
        results = [];
        for (j = 0, len1 = farois.length; j < len1; j++) {
          farol = farois[j];
          results.push(_this.atualizarIndicadores(farol));
        }
        return results;
      };
    })(this));
  };

  VisaoController.prototype.atualizarIndicadores = function(linha) {
    this.atualizarReferenciasAdicionadas();
    this.determinarComandoDaLinha(linha);
    this.determinarComandoDaArea(linha.closest('.js-agrupamento-area'));
    return this.determinarComandoDoAgrupamento();
  };

  VisaoController.prototype.criarNova = function(button) {
    button = $(button);
    this.get("#Tipo").val(button.val());
    return this.get('form').submit();
  };

  VisaoController.prototype.submitCriarNova = function() {
    $(this.contexto).find('#close-modal-createvisao').click();
    if (this.get("#Tipo").val() === 'PorFiltro') {
      return this.get('#DesdobramentosSerializado').val(JSON.stringify(FarolController.visao));
    } else {
      return this.get('#DesdobramentosSerializado').val('');
    }
  };

  VisaoController.prototype.aplicarVisao = function() {
    return $as.Performance.FarolDeIndicadores.AplicarVisao.post({
      idDaVisao: this.idVisao
    }).success((function(_this) {
      return function(data) {
        return window.reload();
      };
    })(this));
  };

  VisaoController.prototype.carregarMenuDeVisoes = function() {
    var idDaVisaoAplicada;
    idDaVisaoAplicada = this.menuVisoes.data('id');
    return $as.Performance.Visoes.Visoes.get({
      idDaVisaoAplicada: idDaVisaoAplicada
    }).done((function(_this) {
      return function(data) {
        var html;
        html = $(data).html();
        _this.menuVisoes.html(html);
        return $('[rel="tooltip"]').tooltip();
      };
    })(this));
  };

  VisaoController.prototype.salvar = function() {
    var dados;
    dados = $(this.contexto).find('input').serialize();
    return $as.Performance.Visoes.Edit.post(dados).done((function(_this) {
      return function(data) {
        if (data.success) {
          VisaoController.editar(data.data.id);
          return _this.carregarMenuDeVisoes();
        } else {
          return $(_this.contexto).parent().html($(data));
        }
      };
    })(this));
  };

  VisaoController.editar = function(id) {
    return $as.Performance.Visoes.Edit.get({
      id: id
    }).done(function(html) {
      return window.GetDiv("box-editar-visao").html(html);
    });
  };

  VisaoController.prototype.atualizarFiltroDaVisao = function() {
    return $as.Performance.Visoes.AtualizarFiltro.post({
      id: this.idVisao,
      desdobramentos: JSON.stringify(FarolController.visao)
    }).done((function(_this) {
      return function(data) {
        if (data.success) {
          return VisaoController.editar(_this.idVisao);
        }
      };
    })(this));
  };

  VisaoController.prototype.aoExcluir = function(data) {
    $("#editar-visao-container").remove();
    if (data.success) {
      if (data.data.Recarregar) {
        return window.reload();
      } else {
        this.carregarMenuDeVisoes();
        return this.desabilitarAdicaoDeIndicadoresNaVisao();
      }
    }
  };

  VisaoController.prototype.aoDesdobrarIndicador = function(event, linha, desdobramentos) {
    var areaDeResultado;
    areaDeResultado = linha.closest('.js-agrupamento-area');
    this.determinarComandoDaLinha(this.buscarIndicadorPaiMaisAcima(linha));
    this.determinarComandoDaArea(areaDeResultado);
    if (desdobramentos) {
      return $(desdobramentos).find('.js-farol').bind('aoDesdobrar', this.aoDesdobrarIndicador).bind('aoEsconderDesdobramento', this.aoEsconderDesdobramento);
    }
  };

  VisaoController.prototype.aoEsconderDesdobramento = function(event, linha) {
    return this.aoDesdobrarIndicador(event, linha);
  };

  VisaoController.prototype.buscarIndicadorPaiMaisAcima = function(filho) {
    if (filho.data('hierarquia') === 0) {
      return filho;
    }
    while (filho.data('hierarquia') > 0) {
      filho = filho.prev('tr');
    }
    return filho;
  };

  return VisaoController;

})(window.baseController);
