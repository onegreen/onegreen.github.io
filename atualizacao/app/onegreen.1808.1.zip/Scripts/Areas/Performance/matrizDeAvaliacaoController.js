﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.matrizDeAvaliacaoController = (function() {
  function matrizDeAvaliacaoController(contexto, options, resource) {
    this.contexto = contexto;
    this.options = options;
    this.resource = resource;
    this.editarAgrupamento = bind(this.editarAgrupamento, this);
    this.exibirEditarAgrupamento = bind(this.exibirEditarAgrupamento, this);
    this.editarPergunta = bind(this.editarPergunta, this);
    this.adicionarPergunta = bind(this.adicionarPergunta, this);
    this.recarregarPerguntas = bind(this.recarregarPerguntas, this);
    this.adicionarNovoAgrupamento = bind(this.adicionarNovoAgrupamento, this);
    this.salvarPergunta = bind(this.salvarPergunta, this);
    this.marcarInputError = bind(this.marcarInputError, this);
    this.mover = bind(this.mover, this);
    this.moverRespostaParaBaixo = bind(this.moverRespostaParaBaixo, this);
    this.moverRespostaParaCima = bind(this.moverRespostaParaCima, this);
    this.recarregarResposta = bind(this.recarregarResposta, this);
    this.editarResposta = bind(this.editarResposta, this);
    this.adicionarResposta = bind(this.adicionarResposta, this);
    this.salvar = bind(this.salvar, this);
    this.fechar = bind(this.fechar, this);
    this.definirBinds = bind(this.definirBinds, this);
    this.$contexto = $(this.contexto);
    redimensionarModalLateral();
    $("[rel=tooltip]", this.$contexto).tooltip();
    this.$contexto.find('#Sigla').focus();
    this.definirBinds();
    if (!this.options.podeSerAlterda) {
      this.$contexto.find(':input').attr({
        'disabled': 'disabled'
      });
      this.$contexto.find('.js-acao').hide();
    }
  }

  matrizDeAvaliacaoController.prototype.definirBinds = function() {
    this.$contexto.find("#btn-Fechar").unbind('click').click(this.fechar);
    if (this.options.podeSerAlterda) {
      $('#form-matrizAvaliacao').find(":input").unbind('change').change(this.salvar);
    }
    $('.js-Peso').setMask({
      mask: '99',
      maxLength: 2
    });
    if (this.options.podeSerAlterda) {
      this.$contexto.find(".js-novo-agrupamento").unbind('change').change((function(_this) {
        return function() {
          return _this.adicionarNovoAgrupamento( this );
        };
      })(this));
    } else {
      this.$contexto.find(".js-novo-agrupamento").hide();
    }
    this.$contexto.find('#adicionar-grupo, #cancelar-grupo').unbind('click').click((function(_this) {
      return function() {
        _this.$contexto.find('#div-novo-grupo').toggleClass('none');
        _this.$contexto.find('#cancelar-grupo, #adicionar-grupo').toggleClass('none');
        _this.$contexto.find(".js-novo-agrupamento").focus();
        if ($( this ).attr('id') !== 'cancelar-grupo') {
          return _this.$contexto.find('.modalLateralConteudo').scrollTo('#cancelar-grupo');
        }
      };
    })(this));
    if (this.options.podeSerAlterda) {
      this.$contexto.find('.js-editar-agrupamento').unbind('click').click((function(_this) {
        return function() {
          return _this.exibirEditarAgrupamento( this );
        };
      })(this));
      return this.$contexto.find('.js-agrupamento').unbind('change').change((function(_this) {
        return function() {
          return _this.editarAgrupamento( this );
        };
      })(this));
    }
  };

  matrizDeAvaliacaoController.prototype.fechar = function() {
    this.$contexto.html("");
    return MatrizDeAvaliacao.reload();
  };

  matrizDeAvaliacaoController.prototype.salvar = function() {
    return $as.Performance.MatrizesDeAvaliacao.Edit.post($("#form-matrizAvaliacao").serialize()).done(function(data) {
      var $inputNome, $inputSigla;
      if (data.success) {
        $('.validation-summary-errors').removeClass('validation-summary-errors').addClass('validation-summary-valid').find('li').addClass('none');
        $inputNome = $('#Nome', this.$contexto);
        $inputSigla = $('#Sigla', this.$contexto);
        $inputNome.removeClass('input-validation-error');
        $inputNome.closest('.form-group.error').removeClass('error');
        $inputSigla.removeClass('input-validation-error');
        return $inputSigla.closest('.form-group.error').removeClass('error');
      } else {
        return $('#matrizDeAvaliacao-modal-container').html(data);
      }
    });
  };

  matrizDeAvaliacaoController.prototype.adicionarResposta = function() {
    var $resposta, $valor;
    $resposta = $('#novaResposta');
    $valor = $('#novoValor');
    if ($resposta.val() !== '' && $valor.val() !== '') {
      return $as.Performance.RespostasDaMatriz.Create.post({
        idDaMatriz: this.options.idDaMatriz,
        resposta: $resposta.val(),
        valor: $valor.val()
      }).done((function(_this) {
        return function(data) {
          if (data.success) {
            return _this.recarregarResposta('#novaResposta');
          } else {
            $('#validation').html(data);
            return _this.removerErroInput($resposta, $valor);
          }
        };
      })(this));
    } else {
      return this.setError($resposta, $valor);
    }
  };

  matrizDeAvaliacaoController.prototype.editarResposta = function($input) {
    var $container, $resposta, $valor;
    $container = $input.closest('.js-container-resposta');
    $resposta = $container.find('.js-Descricao');
    $valor = $container.find('.js-Peso');
    if ($resposta.val() !== '' && $valor.val() !== '') {
      return $as.Performance.RespostasDaMatriz.Edit.post({
        idDaMatriz: this.options.idDaMatriz,
        idDaResposta: $container.data('id'),
        resposta: $resposta.val(),
        valor: $valor.val()
      }).done((function(_this) {
        return function(data) {
          if (!data.success) {
            return $('#validation').html(data);
          } else {
            return _this.removerErroInput($resposta, $valor);
          }
        };
      })(this));
    } else {
      return this.setError($resposta, $valor);
    }
  };

  matrizDeAvaliacaoController.prototype.recarregarResposta = function(elSelector) {
    return $as.Performance.RespostasDaMatriz.Index.get({
      idDaMatriz: this.options.idDaMatriz
    }).done(function(html) {
      $('#respostas-container').html(html);
      if (elSelector) {
        return $(elSelector).focus();
      }
    });
  };

  matrizDeAvaliacaoController.prototype.moverRespostaParaCima = function(idDaResposta) {
    return this.mover(idDaResposta, true);
  };

  matrizDeAvaliacaoController.prototype.moverRespostaParaBaixo = function(idDaResposta) {
    return this.mover(idDaResposta, false);
  };

  matrizDeAvaliacaoController.prototype.mover = function(idDaResposta, paraCima) {
    return $as.Performance.RespostasDaMatriz.TrocarOrdem.post({
      idDaMatriz: this.options.idDaMatriz,
      paraCima: paraCima,
      idDaResposta: idDaResposta
    }).done(function(html) {
      $('#respostas-container').html(html);
      return $('.js-Peso').setMask({
        mask: '999',
        maxLength: 3
      });
    });
  };

  matrizDeAvaliacaoController.prototype.setError = function($resposta, $valor) {
    this.marcarInputError($resposta, $resposta.val() === '');
    this.marcarInputError($valor, $valor.val() === '');
    $('#validation-Perguntas').show();
    if ($resposta.val() === '') {
      $('#validation-Perguntas-pergunta').show();
    } else {
      $('#validation-Perguntas-pergunta').hide();
    }
    if ($valor.val() === '') {
      return $('#validation-Perguntas-valor').show();
    } else {
      return $('#validation-Perguntas-valor').hide();
    }
  };

  matrizDeAvaliacaoController.prototype.marcarInputError = function(input, erro) {
    return $(input).toggleClass('inputError', erro);
  };

  matrizDeAvaliacaoController.prototype.removerErroInput = function($resposta, $valor) {
    $resposta.removeClass('inputError');
    $valor.removeClass('inputError');
    $('#validation-Perguntas').hide();
    return $('#validation-Perguntas li').hide();
  };

  matrizDeAvaliacaoController.prototype.salvarPergunta = function(elemento, recarregar) {
    var agrupamento, container;
    container = $(elemento).closest('.js-container-pergunta');
    agrupamento = container.find('#agrupamento').val().replace(/\s/g, '');
    this.marcarInputError(elemento, $(elemento).val() === '');
    if ($(elemento).val() !== '') {
      $('#validation-perguntas').addClass('none');
      return $as.Performance.PerguntasDaMatriz.SalvarPergunta.post(container.find('input').serialize()).done((function(_this) {
        return function(data) {
          if (data.success) {
            if (recarregar) {
              return _this.recarregarPerguntas(agrupamento);
            }
          } else {
            return $('#validation-perguntas').html(data).removeClass('none');
          }
        };
      })(this));
    } else {
      return $('#validation-perguntas').removeClass('none');
    }
  };

  matrizDeAvaliacaoController.prototype.adicionarNovoAgrupamento = function(elemento) {
    var agrupamento, container;
    agrupamento = $(elemento).val();
    container = $(elemento).closest('#div-novo-grupo');
    return $as.Performance.PerguntasDaMatriz.AdicionarNovoGrupo.post({
      agrupamento: agrupamento,
      idDaMatriz: this.options.idDaMatriz
    }).done((function(_this) {
      return function(html) {
        $(elemento).val('');
        container.toggleClass('none');
        _this.$contexto.find('#cancelar-grupo, #adicionar-grupo').toggleClass('none');
        container.before(html);
        return setTimeout(function() {
          return $('#nova_pergunta_' + agrupamento.replace(/\s/g, '')).focus();
        }, 50);
      };
    })(this));
  };

  matrizDeAvaliacaoController.prototype.recarregarPerguntas = function(agrupamento) {
    return $as.Performance.PerguntasDaMatriz.Index.get({
      idDaMatriz: this.options.idDaMatriz
    }).done((function(_this) {
      return function(data) {
        _this.$contexto.find('#perguntas-container').html(data);
        if (agrupamento) {
          setTimeout(function() {
            return $('#nova_pergunta_' + agrupamento).focus();
          }, 50);
        }
        return _this.definirBinds();
      };
    })(this));
  };

  matrizDeAvaliacaoController.prototype.adicionarPergunta = function(elemento) {
    return this.salvarPergunta(elemento, true);
  };

  matrizDeAvaliacaoController.prototype.editarPergunta = function(elemento) {
    return this.salvarPergunta(elemento, false);
  };

  matrizDeAvaliacaoController.prototype.exibirEditarAgrupamento = function(elemento) {
    var container;
    container = $(elemento).closest('.js-agrupamento-container');
    container.find('.js-agrupamento, .js-colapse-agrupamento').toggleClass('none');
    return container.find('.js-agrupamento').focus();
  };

  matrizDeAvaliacaoController.prototype.editarAgrupamento = function(input) {
    var agrupamento, agrupamentoAtual, container, dados;
    container = $(input).closest('.js-agrupamento-container');
    agrupamentoAtual = container.find('.js-agrupamento-atual');
    agrupamento = $(input);
    this.marcarInputError($(input), agrupamento === '');
    if (agrupamento === '') {
      return;
    }
    dados = {
      idDaMatriz: this.options.idDaMatriz,
      agrupamento: agrupamentoAtual.val(),
      agrupamentoNovo: agrupamento.val()
    };
    return $as.Performance.PerguntasDaMatriz.EditarAgrupamento.post(dados).done((function(_this) {
      return function(data) {
        container.parent().replaceWith(data);
        return setTimeout(function() {
          return $('#nova_pergunta_' + dados.agrupamentoNovo.replace(/\s/g, '')).focus();
        }, 50);
      };
    })(this));
  };

  return matrizDeAvaliacaoController;

})();
