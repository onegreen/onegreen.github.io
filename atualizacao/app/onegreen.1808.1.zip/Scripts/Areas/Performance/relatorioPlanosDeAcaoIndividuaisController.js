﻿window.relatorioPlanosDeAcaoIndividuaisController = (function() {
  function relatorioPlanosDeAcaoIndividuaisController() {}

  relatorioPlanosDeAcaoIndividuaisController.recarregarRelatorio = function() {
    var parametros;
    parametros = {
      IdDoCiclo: $('#IdDoCiclo', '#formRelatorioPlanosDeAcaoCsv').val(),
      IdDaUnidadeGerencial: $('#IdDaUnidadeGerencial', '#formRelatorioPlanosDeAcaoCsv').val(),
      IncluirSubordinadas: $('#IncluirSubordinadas', '#formRelatorioPlanosDeAcaoCsv').val()
    };
    return $as.Performance.AvaliacoesDeDesempenho.RelatorioDePlanosDeAcaoIndividuaisFiltro.get(parametros).done((function(_this) {
      return function(data) {
        $('#close-modal-atividade', $('#atividade-modal')).click();
        return $("#relatorioAvaliacaoDeDesempenho-container").html(data);
      };
    })(this));
  };

  return relatorioPlanosDeAcaoIndividuaisController;

})();
