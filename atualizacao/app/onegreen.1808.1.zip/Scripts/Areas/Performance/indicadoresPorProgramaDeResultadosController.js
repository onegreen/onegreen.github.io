﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.indicadoresPorProgramaDeResultadosController = (function() {
  function indicadoresPorProgramaDeResultadosController(view) {
    this.view = view;
    this.reload = bind(this.reload, this);
    this.executarExclusaoDoIndicador = bind(this.executarExclusaoDoIndicador, this);
    this.excluirIndicador = bind(this.excluirIndicador, this);
    this.somarPesos = bind(this.somarPesos, this);
    this.salvarIndicador = bind(this.salvarIndicador, this);
    this.pesoAlterado = bind(this.pesoAlterado, this);
    this.setarMascaraDecimal = bind(this.setarMascaraDecimal, this);
    this.bindInputsPeso = bind(this.bindInputsPeso, this);
    this.$view = $(this.view);
    this.id = this.$view.data('id');
    window.recarregarFarol = false;
    this.bindInputsPeso();
    this.$view.find('.js-excluirIndicador').click(this.excluirIndicador);
  }

  indicadoresPorProgramaDeResultadosController.prototype.bindInputsPeso = function() {
    var $inputsPeso;
    $inputsPeso = this.$view.find('.js-PesoDoIndicador');
    $inputsPeso.change(this.pesoAlterado);
    $inputsPeso.keypress(this.setarMascaraDecimal);
    return $inputsPeso.click(function() {
      return $(this).select();
    });
  };

  indicadoresPorProgramaDeResultadosController.prototype.setarMascaraDecimal = function(e) {
    var keycode, target, teclasNoASCIIFirefox;
    target = e.target || e.srcElement;
    keycode = e.charCode || e.keyCode;
    teclasNoASCIIFirefox = ["Right", "Left", "Backspace", "Del", "ArrowRight", "ArrowLeft", "Backspace", "Delete", "Tab"];
    if (teclasNoASCIIFirefox.contains(e.originalEvent.key)) {
      return true;
    } else {
      return window.VerificarValor(target, keycode);
    }
  };

  indicadoresPorProgramaDeResultadosController.prototype.pesoAlterado = function(e) {
    var elemento;
    elemento = $(e.currentTarget);
    return this.salvarIndicador(elemento);
  };

  indicadoresPorProgramaDeResultadosController.prototype.salvarIndicador = function(elemento) {
    var idDoIndicador, peso;
    idDoIndicador = elemento.data('id');
    peso = elemento.val();
    return $as.Performance.IndicadoresPorProgramasDeResultados.SalvarIndicador.post({
      idDoIndicadorPorPrograma: idDoIndicador,
      pesoStr: peso
    }).done((function(_this) {
      return function(data) {
        var form, summary, summaryNovo;
        if (data.success) {
          window.recarregarFarol = true;
          $('#btnOKTermineiConfigurar').show();
          elemento.closest('tr').removeClass('error');
          if (elemento.closest('table').find('tr.error').length === 0) {
            _this.$view.find(".validation-summary-errors").remove();
          }
        } else {
          summaryNovo = $(data).find(".validation-summary-errors");
          form = _this.$view.find("#indicadores-form");
          summary = form.find(".validation-summary-errors");
          if (summary.length === 0) {
            form.prepend(summaryNovo);
          } else {
            summary.html(summaryNovo.html());
          }
          elemento.closest('tr').addClass('error');
          elemento.select();
          elemento.focus();
        }
        return _this.somarPesos();
      };
    })(this));
  };

  indicadoresPorProgramaDeResultadosController.prototype.somarPesos = function() {
    var container, label, mensagem, valorTotal;
    valorTotal = 0;
    this.$view.find('.js-PesoDoIndicador').each(function() {
      return valorTotal += window.parseFloatCulture($(this).val());
    });
    container = this.$view.find("#container-soma-dos-pesos");
    mensagem = this.$view.find("#mensagem-soma-dos-pesos");
    label = this.$view.find("#soma-dos-pesos");
    if (Math.round(valorTotal, 2) !== 100.00) {
      container.addClass("c-vermelho");
      container.removeClass("c-cinza");
      mensagem.show();
    } else {
      container.removeClass("c-vermelho");
      container.addClass("c-cinza");
      mensagem.hide();
    }
    if (isNaN(valorTotal)) {
      return label.text('');
    } else {
      return label.text(window.formatNumberCulture(valorTotal, 2));
    }
  };

  indicadoresPorProgramaDeResultadosController.prototype.excluirIndicador = function(evento) {
    this.indicadorParaExclusao = $(evento.currentTarget);
    return window.modalConfirm(this.indicadorParaExclusao.attr("data-ajax-confirm"), this.executarExclusaoDoIndicador);
  };

  indicadoresPorProgramaDeResultadosController.prototype.executarExclusaoDoIndicador = function() {
    var idDoIndicadorPorPrograma;
    idDoIndicadorPorPrograma = this.indicadorParaExclusao.data('id');
    return $as.Performance.IndicadoresPorProgramasDeResultados.ExcluirIndicador.post({
      idDoIndicadorPorPrograma: idDoIndicadorPorPrograma
    }).done((function(_this) {
      return function(data) {
        return _this.reload(_this.id);
      };
    })(this));
  };

  indicadoresPorProgramaDeResultadosController.prototype.reload = function(idDoProgramaPorUsuario) {
    return $as.Performance.IndicadoresPorProgramasDeResultados.IndicadoresPorPrograma.get({
      idDoProgramaPorUsuario: idDoProgramaPorUsuario
    }).done((function(_this) {
      return function(data) {
        _this.$view.html(data);
        return window.recarregarFarol = true;
      };
    })(this));
  };

  return indicadoresPorProgramaDeResultadosController;

})();
