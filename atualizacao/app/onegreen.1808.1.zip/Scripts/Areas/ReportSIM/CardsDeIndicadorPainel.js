﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.cardsDeIndicadorPainelController = (function(superClass) {
  extend(cardsDeIndicadorPainelController, superClass);

  function cardsDeIndicadorPainelController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.recarregarTemplate = bind(this.recarregarTemplate, this);
    this.reload = bind(this.reload, this);
    this.resolverRelacionamentosNosCards = bind(this.resolverRelacionamentosNosCards, this);
    this.ativarOrdenacao = bind(this.ativarOrdenacao, this);
    this.ativarEventosModal = bind(this.ativarEventosModal, this);
    this.encontrarElementos = bind(this.encontrarElementos, this);
    this.ativarEventos = bind(this.ativarEventos, this);
    this.parametrosComuns = bind(this.parametrosComuns, this);
    this.editar = bind(this.editar, this);
    this.adicionar = bind(this.adicionar, this);
    this.load = bind(this.load, this);
    cardsDeIndicadorPainelController.__super__.constructor.call(this, this.view, this.model, this.options);
  }

  cardsDeIndicadorPainelController.prototype.load = function() {
    this.encontrarElementos();
    this.ativarEventos();
    this.resolverRelacionamentosNosCards();
    $(this.view).closest("form").attr("action", this.options.FormURL);
    this.get('.js-BotoesDoCartao').removeClass("hide").addClass("mostrar");
    this.get('#indicativos-comentarios-planodeacao').hide();
    return this.definirBloqueios();
  };

  cardsDeIndicadorPainelController.prototype.adicionar = function() {
    var parametros;
    parametros = $('input:hidden', '#simpartdeindicador-modal').serialize() + this.parametrosComuns();
    return $as.ReportSIM.Paineis.CriarCardComSimPart.post(parametros).done((function(_this) {
      return function(html) {
        _this.painelTemplate.html(html);
        return _this.reload();
      };
    })(this));
  };

  cardsDeIndicadorPainelController.prototype.editar = function() {
    var parametros;
    parametros = $('input:hidden', '#simpartdeindicador-modal').serialize() + this.parametrosComuns();
    return $as.ReportSIM.Paineis.EditarCardComSimPart.post(parametros).done((function(_this) {
      return function(html) {
        _this.painelTemplate.html(html);
        return _this.reload();
      };
    })(this));
  };

  cardsDeIndicadorPainelController.prototype.parametrosComuns = function() {
    return '&idDoPainel=' + this.IdDoPainel.val() + '&referenciaNoTemplate=' + this.options.referenciaNoTemplate;
  };

  cardsDeIndicadorPainelController.prototype.ativarEventos = function() {
    cardsDeIndicadorPainelController.__super__.ativarEventos.apply(this, arguments);
    return this.get(".js-RemoverCartao").unbind("click").bind("click", window.edicaoDashboard.tentarExcluirItem);
  };

  cardsDeIndicadorPainelController.prototype.encontrarElementos = function() {
    cardsDeIndicadorPainelController.__super__.encontrarElementos.apply(this, arguments);
    this.IdDoPainel = $('#idDoPainel');
    return this.painelTemplate = $('#painel-template');
  };

  cardsDeIndicadorPainelController.prototype.ativarEventosModal = function(funcaoDeAlteracao) {
    cardsDeIndicadorPainelController.__super__.ativarEventosModal.call(this, funcaoDeAlteracao);
    return this.BotaoAdicionarEFechar.hide();
  };

  cardsDeIndicadorPainelController.prototype.ativarOrdenacao = function() {};

  cardsDeIndicadorPainelController.prototype.resolverRelacionamentosNosCards = function() {};

  cardsDeIndicadorPainelController.prototype.reload = function() {
    window.edicaoDashboard.load();
    return this.load();
  };

  cardsDeIndicadorPainelController.prototype.recarregarTemplate = function() {
    return $as.ReportSIM.Paineis.RecarregarTemplate.get({
      idDoPainel: this.IdDoPainel.val()
    }).done((function(_this) {
      return function(html) {
        _this.painelTemplate.html(html);
        return _this.reload();
      };
    })(this));
  };

  return cardsDeIndicadorPainelController;

})(window.cardsDeIndicadorController);
