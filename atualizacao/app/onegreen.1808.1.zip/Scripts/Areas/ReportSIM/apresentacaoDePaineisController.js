﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.apresentacaoDePaineisController = (function(superClass) {
  extend(apresentacaoDePaineisController, superClass);

  function apresentacaoDePaineisController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.avancar = bind(this.avancar, this);
    this.getItem = bind(this.getItem, this);
    this.carregarContainer = bind(this.carregarContainer, this);
    this.inicarContagemParaTransicao = bind(this.inicarContagemParaTransicao, this);
    this.iniciarApresentacao = bind(this.iniciarApresentacao, this);
    this.load = bind(this.load, this);
    this.carregarBackground = bind(this.carregarBackground, this);
    this.mostrarProximoContainer = bind(this.mostrarProximoContainer, this);
    this.localizarElementos = bind(this.localizarElementos, this);
    apresentacaoDePaineisController.__super__.constructor.call(this, this.view);
    this.localizarElementos();
    this.indiceAtual = 0;
    this.proximoItem = 1;
    this.load();
    $('#loading').css("visibility", "hidden");
  }

  apresentacaoDePaineisController.prototype.localizarElementos = function() {
    this.containerAtual = this.get('#container-painel-1');
    return this.proximoContainer = this.get('#container-painel-2');
  };

  apresentacaoDePaineisController.prototype.mostrarProximoContainer = function(item) {
    var swipe;
    swipe = this.containerAtual;
    this.containerAtual = this.proximoContainer;
    this.proximoContainer = swipe;
    this.proximoContainer.css('visibility', 'hidden');
    this.containerAtual.css({
      opacity: 0.0,
      visibility: "visible"
    }).animate({
      opacity: 1.0
    });
    return this.carregarBackground();
  };

  apresentacaoDePaineisController.prototype.carregarBackground = function() {
    var urlPainel;
    urlPainel = $('#url-background-painel', this.containerAtual).data('url');
    if (urlPainel) {
      if (urlPainel.indexOf("?") !== -1) {
        urlPainel += '&';
      } else {
        urlPainel += '?';
      }
      urlPainel += "altura=" + ($(window).height()) + "&largura=" + ($(window).width());
      return $('body').css({
        "background-image": "url('" + urlPainel + "')"
      }).animate({
        opacity: 1.0
      });
    } else {
      return $('body').css({
        "background-image": ""
      }).animate({
        opacity: 1.0
      });
    }
  };

  apresentacaoDePaineisController.prototype.load = function() {
    return $as.ReportSIM.ApresentacoesDePaineis.ApresentacaoJson.get({
      idDaApresentacao: this.options.Id
    }).done(this.iniciarApresentacao);
  };

  apresentacaoDePaineisController.prototype.iniciarApresentacao = function(apresentacao) {
    if (!apresentacao.Itens.length) {
      return false;
    }
    window.apresentacao = true;
    this.apresentacao = apresentacao;
    this.apenasUmPainel = this.apresentacao.Itens.length === 1;
    if (this.apenasUmPainel) {
      this.proximoContainer = this.containerAtual;
    }
    this.carregarContainer(this.getItem(0), this.proximoContainer, true);
    if (this.apenasUmPainel) {
      this.containerAtual.css({
        visibility: "visible"
      });
    }
    return this.avancar();
  };

  apresentacaoDePaineisController.prototype.inicarContagemParaTransicao = function(segundos) {
    return $("#BarraDeTransicaoAutomatica").animate({
      width: '100%'
    }, segundos, (function(_this) {
      return function() {
        $("#BarraDeTransicaoAutomatica").css("width", "0%");
        return _this.avancar();
      };
    })(this));
  };

  apresentacaoDePaineisController.prototype.carregarContainer = function(item, container, atualizarBackground) {
    return $as.ReportSIM.Paineis.MostrarPainel.get({
      id: item.Painel.Id
    }).done((function(_this) {
      return function(html) {
        window.Highcharts.charts = null;
        container.html(html);
        if (atualizarBackground) {
          return _this.carregarBackground();
        }
      };
    })(this));
  };

  apresentacaoDePaineisController.prototype.getItem = function(indice) {
    return this.apresentacao.Itens[indice];
  };

  apresentacaoDePaineisController.prototype.avancar = function() {
    var proximoIndice;
    proximoIndice = this.indiceAtual + 1;
    if (proximoIndice >= this.apresentacao.Itens.length) {
      proximoIndice = 0;
    }
    if (!this.apenasUmPainel) {
      this.mostrarProximoContainer(this.getItem(proximoIndice));
    }
    this.carregarContainer(this.getItem(proximoIndice), this.proximoContainer, this.apenasUmPainel);
    this.inicarContagemParaTransicao(this.getItem(this.indiceAtual).Segundos * 1000);
    return this.indiceAtual = proximoIndice;
  };

  return apresentacaoDePaineisController;

})(window.baseController);
