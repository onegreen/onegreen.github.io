﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.unidadeGerencialCreateEditController = (function() {
  function unidadeGerencialCreateEditController(options) {
    this.options = options;
    this.aoSalvar = bind(this.aoSalvar, this);
    this.loadFunctions = bind(this.loadFunctions, this);
    this.configurarMisssaoEVisao = bind(this.configurarMisssaoEVisao, this);
    this.carregarComboUnidadeSubordinada = bind(this.carregarComboUnidadeSubordinada, this);
    this.carregarComboEstado = bind(this.carregarComboEstado, this);
    this.carregarComboResponsavel = bind(this.carregarComboResponsavel, this);
    this.contexto = "#unidade-modal";
    this.loadFunctions();
    $("#btn-Fechar").click(function(e) {
      return $("#unidadegerencial-modal-container").html("");
    });
    $("#btn-salvar", "#unidade-modal").on("click", (function(_this) {
      return function(e) {
        return $("#form-unidade-gerencial", _this.contexto).submit();
      };
    })(this));
    $("#listaExercicios li").css("width", "110px");
    $("#Sigla").focus();
  }

  unidadeGerencialCreateEditController.prototype.carregarComboResponsavel = function() {
    return setCombo(this.contexto, '#UsuarioNome');
  };

  unidadeGerencialCreateEditController.prototype.carregarComboEstado = function() {
    return setCombo(this.contexto, '#EstadoSigla');
  };

  unidadeGerencialCreateEditController.prototype.carregarComboUnidadeSubordinada = function() {
    return setCombo(this.contexto, '#UnidadeSuperiorSigla', null, {
      idDaUnidadeSubordinada: this.options.idDaUnidadeGerencial
    });
  };

  unidadeGerencialCreateEditController.prototype.configurarMisssaoEVisao = function() {
    $("#missao-fora-do-form", this.contexto).val($("#Missao", this.contexto).val());
    $("#visao-fora-do-form", this.contexto).val($("#Visao", this.contexto).val());
    $("#missao-fora-do-form", this.contexto).change((function(_this) {
      return function() {
        return $("#Missao", _this.contexto).val($("#missao-fora-do-form", _this.contexto).val());
      };
    })(this));
    return $("#visao-fora-do-form", this.contexto).change((function(_this) {
      return function() {
        return $("#Visao", _this.contexto).val($("#visao-fora-do-form", _this.contexto).val());
      };
    })(this));
  };

  unidadeGerencialCreateEditController.prototype.loadFunctions = function() {
    setTimeout(redimensionarModalLateral, 0);
    this.carregarComboResponsavel();
    this.carregarComboUnidadeSubordinada();
    this.carregarComboEstado();
    return this.configurarMisssaoEVisao();
  };

  unidadeGerencialCreateEditController.prototype.aoSalvar = function(data) {
    var callback, idDaUnidadeGerencial;
    if (data.success) {
      if (data.novoRegistro) {
        callback = function() {
          return $as.Manutencao.UnidadeGerencial.Edit.get({
            idDaUnidade: data.idDaUnidade
          }).done(function(html) {
            return $('#unidadegerencial-modal-container').html(html);
          });
        };
        return window.UnidadeGerencial.reload(callback);
      } else {
        idDaUnidadeGerencial = $('#Id', this.contexto).val();
        $as.Manutencao.UnidadeGerencial.ItemListagem.get({
          id: idDaUnidadeGerencial
        }).done((function(_this) {
          return function(data) {
            var elemento, nivel;
            elemento = $("#unidade-" + idDaUnidadeGerencial);
            elemento.html(data);
            nivel = elemento.data('nivel');
            elemento.find('td').removeClass('espacamento-hierarquia-0');
            return elemento.find('td').addClass("espacamento-hierarquia-" + nivel);
          };
        })(this));
        return $('#unidadegerencial-modal-container').html(data.data);
      }
    } else {
      return $('#unidadegerencial-modal-container').html(data.data);
    }
  };

  return unidadeGerencialCreateEditController;

})();
