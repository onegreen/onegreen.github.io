﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.cropUpload = (function() {
  function cropUpload(options) {
    this.options = options;
    this.MostrarErro = bind(this.MostrarErro, this);
    this.showCoords = bind(this.showCoords, this);
    this.ativarJCrop = bind(this.ativarJCrop, this);
    this.submitCrop = bind(this.submitCrop, this);
    this.iniciarCrop = bind(this.iniciarCrop, this);
    this.recarregaIframeUpload = bind(this.recarregaIframeUpload, this);
    $('#modalErro').show();
    $("[rel='tooltip']").tooltip();
  }

  cropUpload.prototype.recarregaIframeUpload = function() {
    return $.ajax({
      type: 'GET',
      url: this.options.urlRecarregaIframeUpload,
      success: (function(_this) {
        return function(html) {
          $('#iframeUpload').html(html);
          return $('.fotoUsuario').attr('src', _this.options.urlfotoUsuario);
        };
      })(this)
    });
  };

  cropUpload.prototype.iniciarCrop = function() {
    var url;
    $("#modalSelecionaFoto").window({
      width: '520px'
    });
    url = this.options.urlIniciarCrop;
    $('#imagem_crop', "#modalSelecionaFoto").attr("src", url);
    $('#imagem_crop', "#modalSelecionaFoto").show();
    this.ativarJCrop();
    $('#FotoCroper', "#modalSelecionaFoto").show();
    return $('#loading').fadeOut();
  };

  cropUpload.prototype.submitCrop = function() {
    return $.post(this.options.urlSubmitCrop, $('#modalSelecionaFoto :input').serialize(), (function(_this) {
      return function(retorno) {
        _this.recarregaIframeUpload();
        return $('#loading').fadeOut();
      };
    })(this));
  };

  cropUpload.prototype.ativarJCrop = function() {
    return $('#imagem_crop', "#modalSelecionaFoto").Jcrop({
      bgColor: 'black',
      bgOpacity: .4,
      aspectRatio: 1,
      setSelect: [0, 0, 60, 60],
      onSelect: this.showCoords,
      onChange: this.showCoords
    }, function() {
      var jcrop;
      return jcrop = this;
    });
  };

  cropUpload.prototype.showCoords = function(c) {
    $("#x1").val(c.x);
    $("#x2").val(c.x2);
    $("#y1").val(c.y);
    $("#y2").val(c.y2);
    return $("#recortar").removeClass("hidden");
  };

  cropUpload.prototype.MostrarErro = function() {
    return this.recarregaIframeUpload();
  };

  return cropUpload;

})();
