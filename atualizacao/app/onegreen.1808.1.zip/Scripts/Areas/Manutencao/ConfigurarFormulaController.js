﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.configurarFormulaController = (function(superClass) {
  extend(configurarFormulaController, superClass);

  function configurarFormulaController(view, funcAlterarFormaDeCalculo, funcGerarTexto) {
    this.view = view;
    this.funcAlterarFormaDeCalculo = funcAlterarFormaDeCalculo;
    this.funcGerarTexto = funcGerarTexto;
    this.formulaMediaNaoNulos = bind(this.formulaMediaNaoNulos, this);
    this.formulaMediaDosItens = bind(this.formulaMediaDosItens, this);
    this.formulaSomaDosItens = bind(this.formulaSomaDosItens, this);
    this.alterarFormaDeCalculo = bind(this.alterarFormaDeCalculo, this);
    this.gerarTexto = bind(this.gerarTexto, this);
    this.appendItem = bind(this.appendItem, this);
    this.appendText = bind(this.appendText, this);
    this.limpar = bind(this.limpar, this);
    this.enableInput = bind(this.enableInput, this);
    this.disableInput = bind(this.disableInput, this);
    this.alterarFormaDeCalculo = bind(this.alterarFormaDeCalculo, this);
    configurarFormulaController.__super__.constructor.call(this, this.view, null);
    (this.get('.js-btn-append')).find('button').click((function(_this) {
      return function() {
        return _this.appendText($( this ).data('text'));
      };
    })(this));
    $(this.view).on({
      click: (function(_this) {
        return function(e) {
          return _this.appendItem(e.currentTarget);
        };
      })(this)
    }, '.js-append-item');
    (this.get('#btn-limpar')).click(this.limpar);
    (this.get('#btn-somaItens')).click(this.alterarFormaDeCalculo || this.funcAlterarFormaDeCalculo);
    (this.get('#btn-mediaItens')).click(this.alterarFormaDeCalculo || this.funcAlterarFormaDeCalculo);
    (this.get('#btn-mediaNaoNulos')).click(this.alterarFormaDeCalculo || this.funcAlterarFormaDeCalculo);
    this.inputFormula = this.get('#TextoDaFormula');
    this.inputForma = this.get('#FormaDeCalculo');
    if (this.inputForma.val() !== 'Formula') {
      this.disableInput();
    }
    $(this.view).window({
      width: '810px'
    });
  }

  configurarFormulaController.prototype.alterarFormaDeCalculo = function(e) {
    var $el, descricao, forma;
    $el = $(e.currentTarget);
    forma = $el.data('forma');
    descricao = $el.attr('title');
    this.limpar();
    this.inputForma.val('MediaDosItens');
    this.appendText(descricao);
    return this.disableInput();
  };

  configurarFormulaController.prototype.disableInput = function() {
    return this.inputFormula.attr('readonly', 'readonly');
  };

  configurarFormulaController.prototype.enableInput = function() {
    this.inputForma.val('Formula');
    return this.inputFormula.removeAttr('readonly');
  };

  configurarFormulaController.prototype.limpar = function() {
    this.inputFormula.val('');
    return this.enableInput();
  };

  configurarFormulaController.prototype.appendText = function(text) {
    var end, formula, start, sub1, sub2;
    formula = this.inputFormula.val();
    start = this.inputFormula[0].selectionStart;
    end = this.inputFormula[0].selectionEnd;
    if (start === end && end === formula.length) {
      formula = this.inputFormula.val() + (" " + text + " ");
    } else {
      sub1 = formula.substring(0, start);
      sub2 = formula.substring(end);
      formula = sub1 + (" " + text + " ") + sub2;
    }
    this.inputFormula.val(formula);
    this.inputFormula[0].setSelectionRange(start + text.length + 1, start + text.length + 1);
    return this.inputFormula.focus();
  };

  configurarFormulaController.prototype.appendItem = function(el) {
    if (this.inputForma.val() !== 'Formula') {
      this.limpar();
    }
    if (this.funcGerarTexto) {
      return this.appendText(this.funcGerarTexto(el));
    } else {
      return this.appendText(this.gerarTexto(el));
    }
  };

  configurarFormulaController.prototype.gerarTexto = function(el) {
    var $el, desc, id, ord;
    $el = $(el).closest('tr');
    id = $el.data('iditem');
    ord = $el.data('ord');
    desc = $el.data('desc');
    return "[Item " + ord + "]";
  };

  configurarFormulaController.prototype.alterarFormaDeCalculo = function(e) {
    var $el, descricao, forma;
    $el = $(e.currentTarget);
    forma = $el.data('forma');
    descricao;
    switch (forma) {
      case 'SomaDosItens':
        descricao = this.formulaSomaDosItens();
        break;
      case 'MediaDosItens':
        descricao = this.formulaMediaDosItens();
        break;
      case "MediaDosItensNaoNulos":
        descricao = this.formulaMediaNaoNulos();
    }
    return $('#TextoDaFormula', this.view).val(descricao);
  };

  configurarFormulaController.prototype.formulaSomaDosItens = function() {
    var formula;
    formula = '';
    $("#itens-da-formula-container tr.mostrar-hover", this.view).map((function(_this) {
      return function(index, item) {
        var descricaoItem;
        descricaoItem = '[Item ' + $(item).data('ord') + ']';
        if (index > 0) {
          descricaoItem = "+" + descricaoItem;
        }
        return formula += descricaoItem;
      };
    })(this));
    return formula;
  };

  configurarFormulaController.prototype.formulaMediaDosItens = function() {
    var count, formula;
    formula = '';
    count = $("#itens-da-formula-container tr.mostrar-hover", this.view).length;
    if (count > 0) {
      formula = '(' + this.formulaSomaDosItens() + ')' + ' / ' + count;
    }
    return formula;
  };

  configurarFormulaController.prototype.formulaMediaNaoNulos = function() {
    var count, formula;
    formula = '';
    count = $("#itens-da-formula-container tr.mostrar-hover", this.view).length;
    if (count > 0) {
      formula = '(' + this.formulaSomaDosItens() + ')' + ' / [NOT NULL ITENS]';
    }
    return formula;
  };

  return configurarFormulaController;

})(window.baseController);
