﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.gruposDeUsuarioDaUnidadeController = (function() {
  function gruposDeUsuarioDaUnidadeController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.reload = bind(this.reload, this);
    this.alterarPermissaoDeAlteracao = bind(this.alterarPermissaoDeAlteracao, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.loadComboGrupoDeUsuarios = bind(this.loadComboGrupoDeUsuarios, this);
    this.loadComboGrupoDeUsuarios();
    this.configurarBinds();
  }

  gruposDeUsuarioDaUnidadeController.prototype.loadComboGrupoDeUsuarios = function() {
    return setCombo(this.contexto, '#NomeDoGrupoDeUsuario');
  };

  gruposDeUsuarioDaUnidadeController.prototype.configurarBinds = function() {
    return $("input[type=checkbox]", "#listagem-grupo-de-usuarios-da-unidade").click(this.alterarPermissaoDeAlteracao);
  };

  gruposDeUsuarioDaUnidadeController.prototype.alterarPermissaoDeAlteracao = function(elemento) {
    var grupoDeUsuario;
    grupoDeUsuario = $(elemento.delegateTarget);
    return $as.Manutencao.GruposDeUsuarioDaUnidade.AlterarPermissaoDeAlteracao.post({
      idDoGrupoDeUsuario: grupoDeUsuario.data("grupo-de-usuario"),
      idDaUnidadeGerencial: this.options.idDaUnidadeGerencial
    }).success((function(_this) {
      return function(data) {
        return _this.reload();
      };
    })(this));
  };

  gruposDeUsuarioDaUnidadeController.prototype.reload = function() {
    return $as.Manutencao.GruposDeUsuarioDaUnidade.Reload.get({
      idDaUnidadeGerencial: this.options.idDaUnidadeGerencial
    }).success((function(_this) {
      return function(data) {
        $("#listagem-grupo-de-usuarios-da-unidade", _this.contexto).html(data);
        $("#NomeDoGrupoDeUsuario", _this.contexto).val("");
        $("#IdGrupoDeUsuario", _this.contexto).val("");
        $("#IncluirSubordinadas", _this.contexto).removeAttr("checked");
        $("#PodeAlterar", _this.contexto).removeAttr("checked");
        _this.loadComboGrupoDeUsuarios();
        return _this.configurarBinds();
      };
    })(this));
  };

  return gruposDeUsuarioDaUnidadeController;

})();
