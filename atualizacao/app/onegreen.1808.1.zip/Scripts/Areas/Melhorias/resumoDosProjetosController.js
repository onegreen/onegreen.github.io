﻿this.Melhorias || (this.Melhorias = {});

window.Melhorias.resumoDosProjetosController = (function() {
  function resumoDosProjetosController(container, filtro) {
    this.container = container;
    this.filtro = filtro;
    $(this.container).data("controller", this);
  }

  resumoDosProjetosController.carregarGrafico = function(resources) {
    $(".showGrafico", "#tabelaDeProjetos").click(function() {
      var categories, options, series, seriesPercentual;
      options = $(this).data("options");
      categories = [resources.NoPrazo, resources.Atrasadas, resources.Finalizadas];
      series = [
        {
          name: resources.NoPrazo,
          showInLegend: false,
          data: [
            {
              y: options.noPrazo.noPrazo,
              data: options.noPrazo.noPrazo,
              descricao: options.noPrazo.noPrazo,
              name: resources.NoPrazo
            }, {
              y: null
            }, {
              y: null
            }
          ],
          color: "#7cbc29",
          type: "column",
          yAxis: 1
        }, {
          name: resources.Atrasadas,
          showInLegend: false,
          color: "#e31b23",
          data: [
            {
              y: null
            }, {
              y: options.atrasadas.atrasadas,
              data: options.atrasadas.atrasadas,
              descricao: options.atrasadas.atrasadas,
              name: resources.Atrasadas
            }, {
              y: null
            }
          ],
          type: "column",
          yAxis: 1
        }, {
          name: resources.Finalizadas,
          showInLegend: false,
          color: "#666666",
          data: [
            {
              y: null
            }, {
              y: null
            }, {
              y: options.finalizadas.finalizadas,
              data: options.finalizadas.finalizadas,
              descricao: options.finalizadas.finalizadas,
              name: resources.Finalizadas
            }
          ],
          type: "column",
          yAxis: 1
        }
      ];
      seriesPercentual = [
        {
          name: resources.NoPrazo,
          data: [
            {
              y: options.noPrazo.noPrazo,
              descricao: options.noPrazo.noPrazo,
              name: resources.NoPrazo
            }
          ],
          yAxis: 1,
          color: "#7cbc29"
        }, {
          name: resources.Atrasadas,
          data: [
            {
              y: options.atrasadas.atrasadas,
              descricao: options.atrasadas.atrasadas,
              name: resources.Atrasadas
            }
          ],
          yAxis: 1,
          color: "#e31b23"
        }, {
          name: resources.Finalizadas,
          data: [
            {
              y: options.finalizadas.finalizadas,
              descricao: options.finalizadas.finalizadas,
              name: resources.Finalizadas
            }
          ],
          yAxis: 1,
          color: "#666666"
        }, {
          name: resources.Total,
          data: [
            {
              y: 0,
              descricao: '',
              name: resources.Total
            }
          ],
          showInLegend: false,
          yAxis: 1,
          color: "#FFF"
        }
      ];
      window.Melhorias.resumoDosProjetosController.criarHighcharts(options, categories, seriesPercentual, "#modalPercentual", "percent", "%");
      window.Melhorias.resumoDosProjetosController.criarHighcharts(options, categories, series, "#modalQuantidade", "column", "");
      $('#lblQuantidade').click();
      return $("#modalGraficos").window({
        width: 650
      });
    });
    return $("input[name=\"rdoTipoGrafico\"]", "#modalGraficos").change(function() {
      return $(".modalGraficosProjetos").toggle(1000);
    });
  };

  resumoDosProjetosController.criarHighcharts = function(options, categories, series, idModal, stacking, resource) {
    var config;
    config = ModelosDeGrafico.api.getConfig({
      categories: categories,
      showGriX: 1,
      showGriY: 1,
      nomeEixoY1: '',
      nomeEixoY2: '',
      titulo: options.titulo,
      bgColor: 'default',
      unit: resource,
      stacking: stacking,
      type: 'column',
      legendaAbaixo: '',
      tooltipNotShared: true
    });
    return ModelosDeGrafico.api.build(idModal, config, series);
  };

  return resumoDosProjetosController;

})();
