﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.FerramentaDeBrainstorming = (function() {
  function FerramentaDeBrainstorming(options, contexto) {
    this.options = options;
    this.contexto = contexto;
    this.fecharModal = bind(this.fecharModal, this);
    this.aoTentarFecharModal = bind(this.aoTentarFecharModal, this);
    this.mudarDeItem = bind(this.mudarDeItem, this);
    this.salvarOuCancelar = bind(this.salvarOuCancelar, this);
    this.aoClicarEmUmItem = bind(this.aoClicarEmUmItem, this);
    this.configurarEstiloDoItemSelecionado = bind(this.configurarEstiloDoItemSelecionado, this);
    this.configurarPontosDoItem = bind(this.configurarPontosDoItem, this);
    this.configurarCarousel = bind(this.configurarCarousel, this);
    this.configurarModal = bind(this.configurarModal, this);
    this.configurarModal();
    this.configurarCarousel();
    this.configurarSelecaoDeResposta();
    this.configurarPontosDoItem();
  }

  FerramentaDeBrainstorming.prototype.configurarModal = function() {
    $(this.contexto).window({
      width: 760
    });
    $(".modal-header", $("#alterarmatrizdoitem-modal")).addClass('custom-modal-header');
    return $("#close-modal-alterarmatrizdoitem").on('click', (function(_this) {
      return function(e) {
        return _this.aoTentarFecharModal(e);
      };
    })(this));
  };

  FerramentaDeBrainstorming.prototype.configurarCarousel = function() {
    this.configurarEstiloDoItemSelecionado();
    $("#itens-do-brainstorming .carousel-item", this.contexto).click((function(_this) {
      return function(elemento) {
        return _this.aoClicarEmUmItem(elemento);
      };
    })(this));
    $('#carouselPrev', this.contexto).click((function(_this) {
      return function() {
        return $('.carousel .carousel-item.active', _this.contexto).prev().click();
      };
    })(this));
    return $('#carouselNext', this.contexto).click((function(_this) {
      return function() {
        return $('.carousel .carousel-item.active', _this.contexto).next().click();
      };
    })(this));
  };

  FerramentaDeBrainstorming.prototype.configurarSelecaoDeResposta = function() {
    return $(".divResposta", this.contexto).click((function(_this) {
      return function(e) {
        var $elemento, valorTotalDoItem;
        $elemento = $(e.currentTarget);
        $(".divResposta", $elemento.parent()).removeClass("selecionado");
        $elemento.addClass("selecionado");
        valorTotalDoItem = _this.calcularValorTotalDoItem();
        return $("#valor-total-do-item", _this.contexto).html(valorTotalDoItem);
      };
    })(this));
  };

  FerramentaDeBrainstorming.prototype.configurarPontosDoItem = function() {
    var pontosDoItemAtual;
    pontosDoItemAtual = $("#ValorDoItem", "#perguntas-da-matriz-por-item").val();
    return $("#valor-total-do-item", this.contexto).html(pontosDoItemAtual);
  };

  FerramentaDeBrainstorming.prototype.configurarEstiloDoItemSelecionado = function() {
    var $itemQueEstavaSelecionado;
    $itemQueEstavaSelecionado = $("#itens-do-brainstorming .carousel-item.active", this.contexto);
    $itemQueEstavaSelecionado.next(".carousel-item").addClass('active-next');
    return $itemQueEstavaSelecionado.prev(".carousel-item").addClass('active-prev');
  };

  FerramentaDeBrainstorming.prototype.aoClicarEmUmItem = function(elemento) {
    var $elementoClicado;
    $elementoClicado = $(elemento.delegateTarget);
    return this.salvarOuCancelar($elementoClicado, false);
  };

  FerramentaDeBrainstorming.prototype.salvarOuCancelar = function($elementoClicado, fecharModal) {
    var $respostas, aoConfirmar, idDoItemASerSalvo;
    if (this.podeSalvar()) {
      idDoItemASerSalvo = $("#itens-do-brainstorming .carousel-item.active").data("id-do-item");
      this.salvarMatrizDoItem(idDoItemASerSalvo);
      if (fecharModal) {
        return this.fecharModal();
      } else {
        return this.mudarDeItem($elementoClicado);
      }
    } else {
      $respostas = $(".selecionado", this.contexto);
      if (fecharModal) {
        if ($respostas.length) {
          window.modalConfirm(this.options.confirmacaoParaCancelar, this.fecharModal);
        } else {
          this.fecharModal();
        }
      } else {
        aoConfirmar = (function(_this) {
          return function() {
            return _this.mudarDeItem($elementoClicado);
          };
        })(this);
        if ($respostas.length) {
          window.modalConfirm(this.options.confirmacaoParaCancelar, aoConfirmar);
        } else {
          this.mudarDeItem($elementoClicado);
        }
      }
      return $("#confirm-modal-container").zIndex(9999);
    }
  };

  FerramentaDeBrainstorming.prototype.mudarDeItem = function(elementoClicado) {
    var elementoAnterior, elementoPosterior, idDoItem;
    elementoAnterior = elementoClicado.prev('.carousel-item');
    elementoPosterior = elementoClicado.next('.carousel-item');
    idDoItem = elementoClicado.data("id-do-item");
    elementoClicado.removeClass('active-next').removeClass('active-prev').addClass('active').siblings('.carousel-item').removeClass('active');
    elementoAnterior.addClass('active-prev').removeClass('active-next').prevAll('.carousel-item').removeClass('active-prev').removeClass('active-next');
    elementoPosterior.addClass('active-next').removeClass('active-prev').nextAll('.carousel-item').removeClass('active-next').removeClass('active-prev');
    return this.mudarPerguntasDeAcordoComOItem(idDoItem);
  };

  FerramentaDeBrainstorming.prototype.mudarPerguntasDeAcordoComOItem = function(idDoItem) {
    return $as.ItensDoBrainstorming.CarregarPerguntasDoItem.get({
      idDoItem: idDoItem
    }).success((function(_this) {
      return function(data) {
        $("#perguntas-da-matriz-por-item", _this.contexto).html(data);
        _this.configurarSelecaoDeResposta();
        return _this.configurarPontosDoItem();
      };
    })(this));
  };

  FerramentaDeBrainstorming.prototype.salvarMatrizDoItem = function(idDoItem) {
    var idsDasRespostas, paramentros;
    idsDasRespostas = $(".divResposta.selecionado [type=hidden][name=idsDasRespostas]", this.contexto).serialize();
    paramentros = idsDasRespostas + "&idDoItemDeBrainstorming=" + idDoItem;
    return $as.ItensDoBrainstorming.AlterarRespostasDoItem.post(paramentros);
  };

  FerramentaDeBrainstorming.prototype.podeSalvar = function() {
    var $perguntas, $respostas;
    $perguntas = $(".divPergunta", this.contexto);
    $respostas = $(".selecionado", this.contexto);
    return $perguntas.length === $respostas.length;
  };

  FerramentaDeBrainstorming.prototype.aoTentarFecharModal = function(event) {
    var $item;
    event.stopPropagation();
    $item = $("#itens-do-brainstorming .carousel-item.active");
    return this.salvarOuCancelar($item, true);
  };

  FerramentaDeBrainstorming.prototype.fecharModal = function() {
    window.ItensDoBrainstormingController.reloadItensDoBrainstorming(this.options.idDoBrainstorming);
    $(this.contexto).hide();
    return $('.modal-open').removeClass('modal-open');
  };

  FerramentaDeBrainstorming.prototype.calcularValorTotalDoItem = function() {
    var i, j, len, len1, resposta, respostas, valorTotal;
    respostas = $(".selecionado > .valorResposta", this.contexto);
    valorTotal = null;
    if (this.options.operadorDaFormula === '+') {
      valorTotal = 0;
      for (i = 0, len = respostas.length; i < len; i++) {
        resposta = respostas[i];
        valorTotal = valorTotal + parseInt($(resposta).val());
      }
    } else {
      valorTotal = 1;
      for (j = 0, len1 = respostas.length; j < len1; j++) {
        resposta = respostas[j];
        valorTotal = valorTotal * parseInt($(resposta).val());
      }
    }
    if (respostas.length > 0) {
      return valorTotal;
    } else {
      return 0;
    }
  };

  return FerramentaDeBrainstorming;

})();
