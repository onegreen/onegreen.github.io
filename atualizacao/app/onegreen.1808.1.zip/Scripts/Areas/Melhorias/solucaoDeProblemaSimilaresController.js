﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.solucaoDeProblemaSimilaresController = (function() {
  function solucaoDeProblemaSimilaresController(contexto, idDaSolucaoDeProblema) {
    this.contexto = contexto;
    this.idDaSolucaoDeProblema = idDaSolucaoDeProblema;
    this.recarregarSolucuoesSimilares = bind(this.recarregarSolucuoesSimilares, this);
    this.carregarMais = bind(this.carregarMais, this);
    this.skip = 20;
    this.btnCarregarMais = $("#btnCarregarMais", this.contexto);
    $(this.contexto).window({
      width: "900px",
      height: "350px"
    });
    this.btnCarregarMais.click(this.carregarMais);
  }

  solucaoDeProblemaSimilaresController.prototype.carregarMais = function(e) {
    return $as.Melhorias.SolucaoDeProblemaSimilares.PesquisarSolucoesProblemasSimilares.get({
      idDaSolucaoDeProblema: this.idDaSolucaoDeProblema,
      skip: this.skip,
      take: 20
    }).done((function(_this) {
      return function(data) {
        var $html, $linhas;
        $html = jQuery.parseHTML(data);
        $linhas = $("tr", $html);
        $("table", _this.contexto).append($linhas);
        if ($linhas.length < 20) {
          _this.btnCarregarMais.hide();
        }
        return _this.skip += 20;
      };
    })(this));
  };

  solucaoDeProblemaSimilaresController.prototype.recarregarSolucuoesSimilares = function() {
    return $as.Melhorias.SolucaoDeProblemaSimilares.ListarSolucoesProblemasRelacionadas.get({
      idDaSolucaoDeProblema: this.idDaSolucaoDeProblema
    }).done((function(_this) {
      return function(data) {
        $("#dvListagemSolucaoDeProblemaSimilares").html(data);
        return $("#solucaoDeProblemaSimilares-container").show();
      };
    })(this));
  };

  return solucaoDeProblemaSimilaresController;

})();
