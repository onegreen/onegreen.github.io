﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.Melhorias || (this.Melhorias = {});

window.Melhorias.resumoDasTarefasController = (function() {
  function resumoDasTarefasController(container, filtro) {
    this.container = container;
    this.filtro = filtro;
    this.reload = bind(this.reload, this);
    $(this.container).data("controller", this);
  }

  resumoDasTarefasController.prototype.reload = function() {
    if (this.filtro.EhProjeto === false) {
      return $as.Melhorias.ResumoDasAcoes.IndexFiltroAvancado.get(this.filtro).done((function(_this) {
        return function(data) {
          return $(_this.container).html(data);
        };
      })(this));
    }
  };

  resumoDasTarefasController.carregarGrafico = function(resources) {
    $(".showGrafico", "#tableTarefa").click(function() {
      var categories, options, series;
      options = $(this).data("options");
      categories = [resources.Planejadas, resources.EmExecucao, resources.Finalizadas];
      series = [
        {
          name: resources.NoPrazo,
          data: [
            {
              y: options.planejadas.noPrazo,
              descricao: options.planejadas.noPrazo,
              name: resources.NoPrazo
            }, {
              y: options.emExecucao.noPrazo,
              descricao: options.emExecucao.noPrazo,
              name: resources.NoPrazo
            }, {
              y: options.finalizada.noPrazo,
              descricao: options.finalizada.noPrazo,
              name: resources.NoPrazo
            }
          ],
          color: "#7cbc29",
          type: "column",
          yAxis: 1
        }, {
          name: resources.Atrasadas,
          color: "#e31b23",
          data: [
            {
              y: options.planejadas.atrasadas,
              descricao: options.planejadas.atrasadas,
              name: resources.Atrasadas
            }, {
              y: options.emExecucao.atrasadas,
              descricao: options.emExecucao.atrasadas,
              name: resources.Atrasadas
            }, {
              y: options.finalizada.atrasadas,
              descricao: options.finalizada.atrasadas,
              name: resources.Atrasadas
            }
          ],
          type: "column",
          yAxis: 1
        }, {
          name: resources.Total,
          data: [
            {
              y: 0,
              descricao: '',
              name: resources.Planejadas
            }, {
              y: 0,
              descricao: '',
              name: resources.EmExecucao
            }, {
              y: 0,
              descricao: '',
              name: resources.Finalizadas
            }
          ],
          type: "column",
          showInLegend: false,
          yAxis: 1
        }
      ];
      window.Melhorias.resumoDasTarefasController.criarHighcharts(options, categories, series, "#modalPercentual", "percent", "%");
      window.Melhorias.resumoDasTarefasController.criarHighcharts(options, categories, series, "#modalQuantidade", "column", "Quantidade");
      return $("#modalGraficos").window({
        width: 650
      });
    });
    return $("input[name=\"rdoTipoGrafico\"]", "#modalGraficos").change(function() {
      return $(".modalGraficosTarefa").toggle(1000);
    });
  };

  resumoDasTarefasController.criarHighcharts = function(options, categories, series, idModal, stacking, resorce) {
    var config;
    config = ModelosDeGrafico.api.getConfig({
      categories: categories,
      showGriX: 1,
      showGriY: 1,
      nomeEixoY1: '',
      nomeEixoY2: '',
      titulo: options.titulo,
      bgColor: 'default',
      unit: '',
      stacking: stacking,
      type: 'column',
      legendaAbaixo: '',
      tooltipNotShared: true
    });
    return ModelosDeGrafico.api.build(idModal, config, series);
  };

  return resumoDasTarefasController;

})();
