﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.FerramentaDeCausaEEfeitoController = (function() {
  function FerramentaDeCausaEEfeitoController(parametros) {
    this.parametros = parametros;
    this.ToggleButtons = bind(this.ToggleButtons, this);
    this.PosicionarSpan = bind(this.PosicionarSpan, this);
    this.CarregarTesteDeHipotese = bind(this.CarregarTesteDeHipotese, this);
    this.RecarregarDiagrama = bind(this.RecarregarDiagrama, this);
    this.RecarregarCausaEEfeito = bind(this.RecarregarCausaEEfeito, this);
    this.AplicarZoom = bind(this.AplicarZoom, this);
    this.DeletarNivel = bind(this.DeletarNivel, this);
    this.EditarNivel = bind(this.EditarNivel, this);
    this.AdicionarNivel = bind(this.AdicionarNivel, this);
    this.ToggleCursor = bind(this.ToggleCursor, this);
    this.AlterarAba = bind(this.AlterarAba, this);
    this.SetarParametros = bind(this.SetarParametros, this);
    this.ResetarParametros = bind(this.ResetarParametros, this);
    this.AjustarParametros = bind(this.AjustarParametros, this);
    this.alturaInicial = null;
    this.exclusao = false;
    this.contexto = "#ferramenta-container-" + this.parametros.IdDaFerramenta;
    this.retanguloClicado;
    this.AjustarParametros();
    $("body").click((function(_this) {
      return function(e) {
        return $("#menu" + _this.parametros.IdDaFerramenta, _this.contexto).toggleClass("open", false);
      };
    })(this));
  }

  FerramentaDeCausaEEfeitoController.prototype.AjustarParametros = function() {
    if (this.parametros.Descricao === null) {
      this.parametros.Descricao = '';
    }
    if (this.parametros.Observacao === null) {
      this.parametros.Observacao = '';
    }
    this.parametros.testeDeHipotese = false;
    this.parametros.largura = $('#largura', this.contexto).val();
    this.parametros.altura = $('#altura', this.contexto).val();
    return this.parametrosInicial = $.extend({}, this.parametros);
  };

  FerramentaDeCausaEEfeitoController.prototype.ResetarParametros = function() {
    this.parametros.Nivel = 0;
    this.parametros.Ordem = 0;
    this.parametros.Pai = 0;
    this.parametros.Avo = 0;
    this.parametros.Bisavo = 0;
    this.parametros.Trisavo = 0;
    return this.parametros.Zoom = false;
  };

  FerramentaDeCausaEEfeitoController.prototype.SetarParametros = function(nivel, ordem, pai, avo, bisavo, trisavo, qtdFilhos, zoom, elemento, evento) {
    if (evento !== null) {
      if (evento.stopPropagation) {
        evento.stopPropagation();
      } else {
        evento.cancelBubble = true;
      }
    }
    this.parametros.Nivel = nivel;
    this.parametros.Ordem = ordem;
    this.parametros.Pai = pai;
    this.parametros.Avo = avo;
    this.parametros.Bisavo = bisavo;
    this.parametros.Trisavo = trisavo;
    this.parametros.QuantidadeFilhos = qtdFilhos;
    this.parametros.Zoom = zoom;
    this.parametros.largura = $('#largura', this.contexto).val();
    this.parametros.altura = $('#altura', this.contexto).val();
    if (zoom) {
      return this.AplicarZoom();
    } else if (elemento) {
      return this.PosicionarSpan(elemento);
    }
  };

  FerramentaDeCausaEEfeitoController.prototype.AlterarAba = function(elemento, testeDeHipotese) {
    if (!$(elemento).parent().hasClass("active")) {
      if (testeDeHipotese) {
        return this.CarregarTesteDeHipotese();
      } else {
        this.ResetarParametros();
        return this.RecarregarDiagrama();
      }
    }
  };

  FerramentaDeCausaEEfeitoController.prototype.ToggleCursor = function(cursor) {
    return $("#imagemCausaEEfeito" + this.parametros.IdDaFerramenta, this.contexto).css("cursor", cursor);
  };

  FerramentaDeCausaEEfeitoController.prototype.AdicionarNivel = function() {
    return $as.Melhorias.CausasEEfeitos.CriarNivel.get(this.parametros).success((function(_this) {
      return function(data) {
        return window.GetDiv("addCausa-modal-container").html(data);
      };
    })(this));
  };

  FerramentaDeCausaEEfeitoController.prototype.EditarNivel = function(testeDeHipotese) {
    if (testeDeHipotese) {
      this.parametros.testeDeHipotese = testeDeHipotese;
    }
    return $as.Melhorias.CausasEEfeitos.EditarNivel.get(this.parametros).success((function(_this) {
      return function(data) {
        return window.GetDiv("addCausa-modal-container").html(data);
      };
    })(this));
  };

  FerramentaDeCausaEEfeitoController.prototype.DeletarNivel = function() {
    this.exclusao = true;
    return $as.Melhorias.CausasEEfeitos.Delete.post(this.parametros);
  };

  FerramentaDeCausaEEfeitoController.prototype.AplicarZoom = function() {
    if (this.parametros.Nivel < 4) {
      this.parametros.Zoom = true;
      return this.RecarregarDiagrama();
    }
  };

  FerramentaDeCausaEEfeitoController.prototype.RecarregarCausaEEfeito = function(idDaFerramenta, testeDeHipotese) {
    if (testeDeHipotese) {
      return this.CarregarTesteDeHipotese();
    } else {
      return this.RecarregarDiagrama();
    }
  };

  FerramentaDeCausaEEfeitoController.prototype.RecarregarDiagrama = function() {
    if (!this.parametros.Zoom) {
      if (this.exclusao && this.parametros.Nivel === this.parametrosInicial.Nivel) {
        this.ResetarParametros();
      } else {
        this.parametros = $.extend({}, this.parametrosInicial);
      }
    }
    return $as.Melhorias.CausasEEfeitos.VisualizarCausaEEfeito.get(this.parametros).success((function(_this) {
      return function(data) {
        if (_this.alturaInicial === null) {
          _this.alturaInicial = $(_this.contexto).height();
        }
        $(_this.contexto).css("height", _this.alturaInicial);
        $(_this.contexto).html(data);
        return $(data).find('img').load(function() {
          return $(_this.contexto).css("height", "");
        });
      };
    })(this));
  };

  FerramentaDeCausaEEfeitoController.prototype.CarregarTesteDeHipotese = function() {
    return $as.Melhorias.CausasEEfeitos.CarregarTesteDeHipotese.get({
      idDaFerramenta: this.parametros.IdDaFerramenta,
      idDaSolucaoDeProblema: this.parametros.IdDaSolucaoDeProblema
    }).success((function(_this) {
      return function(data) {
        if (_this.alturaInicial === null) {
          _this.alturaInicial = $(_this.contexto).height();
        }
        $(_this.contexto).css("height", "");
        return $("#tabContent-" + _this.parametros.IdDaFerramenta, _this.contexto).html(data);
      };
    })(this));
  };

  FerramentaDeCausaEEfeitoController.prototype.PosicionarSpan = function(Objeto) {
    this.ToggleButtons();
    if (this.retanguloClicado === null) {
      this.retanguloClicado = Objeto;
    }
    this.Areas = new String();
    this.Areas = $("#" + Objeto, this.contexto).attr("coords").split(",");
    this.menu = $("#menu" + this.parametros.IdDaFerramenta, this.contexto);
    this.imagem = $("#imagemCausaEEfeito" + this.parametros.IdDaFerramenta, this.contexto)[0];
    this.left = parseInt(this.Areas[0]) + this.imagem.offsetLeft;
    this.top = parseInt(this.Areas[1]) + this.imagem.offsetTop;
    if (this.parametros.Nivel === this.parametrosInicial.Nivel) {
      this.left = this.left - parseInt($("ul", this.menu).width()) - 1;
    } else if (this.Areas[1] > this.imagem.height / 2) {
      this.top = this.top - (this.Areas[3] - this.Areas[1]) - parseInt($("ul", this.menu).height()) - 1;
    } else {
      this.top = this.top + (this.Areas[3] - this.Areas[1]) - 1;
    }
    this.menu.css("left", this.left).css("top", this.top).css("position", "absolute");
    if (this.retanguloClicado === Objeto) {
      this.menu.toggleClass("open");
    } else {
      this.menu.toggleClass("open", true);
    }
    return this.retanguloClicado = Objeto;
  };

  FerramentaDeCausaEEfeitoController.prototype.ToggleButtons = function() {
    $("#excluirItem, #adicionarItem, #editarItem, #zoom", this.contexto).show();
    if (this.parametros.Nivel === 0) {
      $("#excluirItem", this.contexto).hide();
    }
    if (this.parametros.QuantidadeFilhos === 6 || this.parametros.Nivel === 4) {
      $("#adicionarItem", this.contexto).hide();
    }
    if (this.parametros.Nivel === 4 || this.parametros.Nivel === 5 || this.parametros.Nivel === this.parametrosInicial.Nivel) {
      return $("#zoom", this.contexto).hide();
    }
  };

  return FerramentaDeCausaEEfeitoController;

})();
