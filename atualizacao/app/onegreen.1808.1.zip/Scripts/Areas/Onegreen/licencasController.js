(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  window.LicencasController = (function() {
    function LicencasController(opcoes, resource) {
      this.opcoes = opcoes;
      this.resource = resource;
      this.vincularLicencas = bind(this.vincularLicencas, this);
      this.tarefasReprogramadasSuccess = bind(this.tarefasReprogramadasSuccess, this);
      this.salvar = bind(this.salvar, this);
      this.salvarEAdicionarNovo = bind(this.salvarEAdicionarNovo, this);
      this.verificarReprogramacaoAtividades = bind(this.verificarReprogramacaoAtividades, this);
      this.verificarNotificacao = bind(this.verificarNotificacao, this);
      this.loadTab = bind(this.loadTab, this);
      this.configurarBind = bind(this.configurarBind, this);
      this.configurarBind();
    }

    LicencasController.prototype.configurarBind = function() {
      $("[rel=tooltip]").tooltip();
      return $('a[data-toggle="tab"]', this.opcoes.Contexto).on('shown.bs.tab', this.loadTab);
    };

    LicencasController.prototype.loadTab = function(event) {
      if (!$(event.target).data('carregado')) {
        $($(event.target).attr('href')).load($(event.target).data('url'));
        if ($(event.target).attr("id") !== "TabLicencaAmbiental") {
          return $(event.target).data('carregado', true);
        }
      }
    };

    LicencasController.prototype.verificarNotificacao = function() {
      var obtendoLicencaRevLO;
      obtendoLicencaRevLO = false;
      if (this.opcoes.obtencaoModel === '' && $("#DataObtencao").val() !== '' && $('#Tipo_Id').val() !== '') {
        return $as.Onegreen.LicencasAmbientais.TipoDeLicencaEhRevalidacaoDeLO.post({
          idTipoDeLicenca: $('#Tipo_Id').val()
        }).success((function(_this) {
          return function(data) {
            var btns;
            obtendoLicencaRevLO = data.success;
            if (obtendoLicencaRevLO) {
              if (_this.opcoes.novoRegistro !== 'True') {
                btns = [
                  {
                    addClass: 'btn btn-primary',
                    text: _this.resource.Sim,
                    onClick: function($noty) {
                      $noty.close();
                      $('.link-licencas-agrupadas').click();
                      return _this.vincularLicencas();
                    }
                  }, {
                    addClass: 'btn btn-default',
                    text: _this.resource.NaoSalvarLicenca,
                    onClick: function($noty) {
                      $noty.close();
                      return $('#form-createedit-licenca').submit();
                    }
                  }, {
                    addClass: 'btn btn-default',
                    text: _this.resource.Nao,
                    onClick: function($noty) {
                      return $noty.close();
                    }
                  }
                ];
                if (window.currentNoty === void 0 || window.currentNoty.closed) {
                  return showBottomNoty(_this.resource.VoceEstaObtendoUmaLicencaDoTipoRevalidacaoDeLicencaDeOperacaoGostariaDeAgruparOutrasLicencasAEsta, 15000, btns);
                }
              } else {
                btns = [
                  {
                    addClass: 'btn btn-primary ok',
                    text: _this.resource.OK,
                    onClick: function($noty) {
                      return $noty.close();
                    }
                  }
                ];
                if (window.currentNoty === void 0 || window.currentNoty.closed) {
                  return showBottomNoty(_this.resource.MensagemDeCriacaoDeRevLOJaObtidaInformandoPossibilidadeDeRelacionamentoDeLicencas, 10000, btns);
                }
              }
            } else {
              return _this.verificarReprogramacaoAtividades();
            }
          };
        })(this));
      } else {
        return this.verificarReprogramacaoAtividades();
      }
    };

    LicencasController.prototype.verificarReprogramacaoAtividades = function() {
      if (this.opcoes.reprogramarAtividades === 'True' && $("#ValidadeFoiAlterada").val() === '1' && $("#JustificativaDeReprogramacaoDaDataValidade").val() !== "" && $("#DataValidade").val() !== '') {
        return $as.Onegreen.LicencasAmbientais.PossuiAtividadesParaReprogramar.post({
          idDaLicencaAmbiental: this.opcoes.idDaLicenca,
          novaValidadeLicenca: $("#DataValidade").val()
        }).success((function(_this) {
          return function(data) {
            var btns, possuiAtividades;
            possuiAtividades = data.success;
            if (possuiAtividades) {
              btns = [
                {
                  addClass: 'btn btn-primary',
                  text: _this.resource.Sim,
                  onClick: function($noty) {
                    $noty.close();
                    return $as.Onegreen.LicencasAmbientais.RetornarAtvividadesReprogramacao.post({
                      idDaLicencaAmbiental: _this.opcoes.idDaLicenca,
                      novaValidadeLicenca: $("#DataValidade").val()
                    }).success(function(data) {
                      window.GetDiv('reprogramaratividades-modal-container').html(data);
                      $('#reprogramaratividades-modal').window();
                      $('#reprogramar-atividades-modal', '#reprogramaratividades-modal').attr("disabled", "disabled");
                      return setTimeout(function() {
                        return Atividades.api.boot();
                      }, 500);
                    });
                  }
                }, {
                  addClass: 'btn btn-default',
                  text: _this.resource.Nao,
                  onClick: function($noty) {
                    $noty.close();
                    return $('#form-createedit-licenca').submit();
                  }
                }
              ];
              if (window.currentNoty === void 0 || window.currentNoty.closed) {
                return showBottomNoty(_this.resource.VocêEstaModificandoAValidadeDaLicencaGostariaDeAjustarAsDatasDasAtividadesComMesmaData, 10000, btns);
              }
            } else {
              return $('#form-createedit-licenca').submit();
            }
          };
        })(this));
      } else {
        return $('#form-createedit-licenca').submit();
      }
    };

    LicencasController.prototype.salvarEAdicionarNovo = function() {
      $("#FormaDeSalvar").val(this.opcoes.salvarEAdicionarNovo);
      return this.verificarNotificacao();
    };

    LicencasController.prototype.salvar = function() {
      $("#FormaDeSalvar").val(this.opcoes.salvar);
      return this.verificarNotificacao();
    };

    LicencasController.prototype.tarefasReprogramadasSuccess = function() {
      $("#close-modal-reprogramaratividades").click();
      return $('#form-createedit-licenca').submit();
    };

    LicencasController.prototype.vincularLicencas = function() {
      return $as.Onegreen.LicencasAmbientais.VincularLicencas.get({
        idDoEmpreendimento: this.opcoes.idDoEmpreendimento,
        idDaLicencaAmbiental: this.opcoes.idDaLicenca
      }).success((function(_this) {
        return function(data) {
          window.GetDiv('vincularlicencas-modal-container').html(data);
          $('#vincularlicencas-modal').window();
          return $('#vincular-licenca-modal', '#vincularlicencas-modal').attr("disabled", "disabled");
        };
      })(this));
    };

    return LicencasController;

  })();

}).call(this);
