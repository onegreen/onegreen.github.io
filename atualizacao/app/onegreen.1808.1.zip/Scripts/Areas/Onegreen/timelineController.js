﻿var timelineController,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

timelineController = (function() {
  function timelineController(recursos) {
    this.recursos = recursos;
    this.configurarExibicaoDoBox = bind(this.configurarExibicaoDoBox, this);
    this.loadTarefasTimeline = bind(this.loadTarefasTimeline, this);
    $(".js-titulo-box-1").unbind("click").bind("click", (function(_this) {
      return function(event) {
        return $(event.delegateTarget).prev("i").click();
      };
    })(this));
    $(".js-toggle-box-1").unbind("click").bind("click", (function(_this) {
      return function(event) {
        return _this.configurarExibicaoDoBox(event, '1');
      };
    })(this));
    $(".js-titulo-box-2").unbind("click").bind("click", (function(_this) {
      return function(event) {
        return $(event.delegateTarget).prev("i").click();
      };
    })(this));
    $(".js-toggle-box-2").unbind("click").bind("click", (function(_this) {
      return function(event) {
        return _this.configurarExibicaoDoBox(event, '2');
      };
    })(this));
    $(".js-titulo-box-3").unbind("click").bind("click", (function(_this) {
      return function(event) {
        return $(event.delegateTarget).prev("i").click();
      };
    })(this));
    $(".js-toggle-box-3").unbind("click").bind("click", (function(_this) {
      return function(event) {
        return _this.configurarExibicaoDoBox(event, '3');
      };
    })(this));
    $(".js-titulo-box-4").unbind("click").bind("click", (function(_this) {
      return function(event) {
        return $(event.delegateTarget).prev("i").click();
      };
    })(this));
    $(".js-toggle-box-4").unbind("click").bind("click", (function(_this) {
      return function(event) {
        return _this.configurarExibicaoDoBox(event, '4');
      };
    })(this));
    $(".js-titulo-box-5").unbind("click").bind("click", (function(_this) {
      return function(event) {
        return $(event.delegateTarget).prev("i").click();
      };
    })(this));
    $(".js-toggle-box-5").unbind("click").bind("click", (function(_this) {
      return function(event) {
        return _this.configurarExibicaoDoBox(event, '5');
      };
    })(this));
  }

  timelineController.prototype.loadTarefasTimeline = function(context, idDoEmpreendimento, status) {
    return $as.Onegreen.AtividadesDaLicenca.TarefasDaTimeline.get({
      idDoEmpreendimento: idDoEmpreendimento,
      status: status
    }).success((function(_this) {
      return function(data) {
        $("#" + context + "-tabela-container").html(data);
        $("[rel=tooltip]").tooltip();
        $("[rel=popover]").popover({
          placement: "top"
        });
        $("[id^=Percentual].btn-warning").prevAll().addClass("btn-warning");
        return setTimeout(function() {
          return Atividades.api.boot();
        }, 500);
      };
    })(this));
  };

  timelineController.prototype.configurarExibicaoDoBox = function(event, contexto) {
    var conteudo, divPai, elemento;
    elemento = $(event.delegateTarget);
    conteudo = elemento.nextAll(".js-conteudo-box-" + contexto);
    divPai = $(elemento).parent("div");
    if (elemento.data("aberto")) {
      elemento.attr("title", this.recursos.Exibir);
      elemento.attr("data-original-title", this.recursos.Exibir);
      elemento.addClass("fa-rotate-90");
      elemento.addClass("mostrar");
      divPai.addClass("mostrar-hover");
      conteudo.hide();
      return elemento.data("aberto", false);
    } else {
      elemento.data("aberto", true);
      elemento.attr("title", this.recursos.Fechar);
      elemento.attr("data-original-title", this.recursos.Fechar);
      elemento.removeClass("fa-rotate-90");
      elemento.removeClass("mostrar");
      divPai.removeClass("mostrar-hover");
      if (!elemento.data("carregado")) {
        elemento.data("carregado", true);
        eval(elemento.data("funcao"));
      }
      return conteudo.show();
    }
  };

  return timelineController;

})();
