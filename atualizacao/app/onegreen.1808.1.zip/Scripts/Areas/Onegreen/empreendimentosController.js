(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  window.EmpreendimentosController = (function() {
    function EmpreendimentosController(opcoes) {
      this.opcoes = opcoes;
      this.salvar = bind(this.salvar, this);
      this.salvarEAvancarParaLicenciamento = bind(this.salvarEAvancarParaLicenciamento, this);
      this.voltarParaEmpreendimentos = bind(this.voltarParaEmpreendimentos, this);
      this.voltar = bind(this.voltar, this);
      this.carregarCamposDeData = bind(this.carregarCamposDeData, this);
      this.configurarComboTipoDeEmpreendimento = bind(this.configurarComboTipoDeEmpreendimento, this);
      this.configurarComboUnidadeGerencial = bind(this.configurarComboUnidadeGerencial, this);
      this.exibirEsconderCamposDependentesDaLegislacaoAmbiental = bind(this.exibirEsconderCamposDependentesDaLegislacaoAmbiental, this);
      this.configurarComboResponsavel = bind(this.configurarComboResponsavel, this);
      this.exibirEsconderUnidadeSuperior = bind(this.exibirEsconderUnidadeSuperior, this);
      this.configurarComboLegislacao = bind(this.configurarComboLegislacao, this);
      this.configurarComboMunicipios = bind(this.configurarComboMunicipios, this);
      this.configurarComboSolicitacaoDeLicenciamento = bind(this.configurarComboSolicitacaoDeLicenciamento, this);
      this.removerTagEmpreendimento = bind(this.removerTagEmpreendimento, this);
      this.adicionarTagEmpreendimento = bind(this.adicionarTagEmpreendimento, this);
      this.configurarTagsEmpreendimento = bind(this.configurarTagsEmpreendimento, this);
      this.definirClickTitulo = bind(this.definirClickTitulo, this);
      this.configurarExibirSolicitacaoDeLicenciamento = bind(this.configurarExibirSolicitacaoDeLicenciamento, this);
      this.exibirEsconderSolicitacaoDeLicenciamento = bind(this.exibirEsconderSolicitacaoDeLicenciamento, this);
      this.carregarTelaEmpreendimento = bind(this.carregarTelaEmpreendimento, this);
      this.excluirProjeto = bind(this.excluirProjeto, this);
      this.confirmacaoDeExclusaoProjeto = bind(this.confirmacaoDeExclusaoProjeto, this);
      this.loadTab = bind(this.loadTab, this);
      this.clickTab = bind(this.clickTab, this);
      this.configurarBind = bind(this.configurarBind, this);
      this.comboEnderecosEmpreendedor = bind(this.comboEnderecosEmpreendedor, this);
      this.comboEnderecosCorrespondencia = bind(this.comboEnderecosCorrespondencia, this);
      this.comboEnderecosEmpreendimento = bind(this.comboEnderecosEmpreendimento, this);
      this.clickTab();
      if (this.opcoes.podeCriarEAlterarProjeto || this.opcoes.novoRegistro) {
        this.configurarBind();
        this.comboEnderecosEmpreendimento();
        this.comboEnderecosCorrespondencia();
        this.comboEnderecosEmpreendedor();
        this.carregarTelaEmpreendimento();
      }
    }

    EmpreendimentosController.prototype.comboEnderecosEmpreendimento = function() {
      var $nomeFantasia, aoSelecionarEnderecoDoEmpreendimento;
      $nomeFantasia = $("#EnderecoEmpreendimentoNomeFantasia");
      aoSelecionarEnderecoDoEmpreendimento = (function(_this) {
        return function() {
          return $as.API.Enderecos.Descricao.get({
            id: $("#EnderecoEmpreendimento_Id").val()
          }).success(function(data) {
            return $("#EnderecoEmpreendimento_Descricao").html(data);
          });
        };
      })(this);
      setCombo(this.opcoes.Contexto, "#EnderecoEmpreendimentoNomeFantasia", aoSelecionarEnderecoDoEmpreendimento);
      if ($nomeFantasia.offset().top + $nomeFantasia.height() >= ($("#form-createedit-empreendimento").offset().top + $("#form-createedit-empreendimento").height() - 150)) {
        return $nomeFantasia.data("autocompleter").abrirPraCima(true);
      }
    };

    EmpreendimentosController.prototype.comboEnderecosCorrespondencia = function() {
      var $nomeFantasia, aoSelecionarEnderecoDoEmpreendimento;
      $nomeFantasia = $("#EnderecoCorrespondenciaNomeFantasia");
      aoSelecionarEnderecoDoEmpreendimento = (function(_this) {
        return function() {
          return $as.API.Enderecos.Descricao.get({
            id: $("#EnderecoCorrespondencia_Id").val()
          }).success(function(data) {
            return $("#EnderecoCorrespondencia_Descricao").html(data);
          });
        };
      })(this);
      setCombo(this.opcoes.Contexto, "#EnderecoCorrespondenciaNomeFantasia", aoSelecionarEnderecoDoEmpreendimento);
      if ($nomeFantasia.offset().top + $nomeFantasia.height() >= ($("#form-createedit-empreendimento").offset().top + $("#form-createedit-empreendimento").height() - 150)) {
        return $nomeFantasia.data("autocompleter").abrirPraCima(true);
      }
    };

    EmpreendimentosController.prototype.comboEnderecosEmpreendedor = function() {
      var $nomeFantasia, aoSelecionarEnderecoDoEmpreendedor;
      $nomeFantasia = $("#EnderecoEmpreendedorNomeFantasia");
      aoSelecionarEnderecoDoEmpreendedor = (function(_this) {
        return function() {
          return $as.API.Enderecos.Descricao.get({
            id: $("#EnderecoEmpreendedor_Id").val()
          }).success(function(data) {
            return $("#EnderecoEmpreendedor_Descricao").html(data);
          });
        };
      })(this);
      setCombo(this.opcoes.Contexto, "#EnderecoEmpreendedorNomeFantasia", aoSelecionarEnderecoDoEmpreendedor);
      if ($nomeFantasia.offset().top + $nomeFantasia.height() >= ($("#form-createedit-empreendimento").offset().top + $("#form-createedit-empreendimento").height() - 150)) {
        return $nomeFantasia.data("autocompleter").abrirPraCima(true);
      }
    };

    EmpreendimentosController.prototype.configurarBind = function() {
      $('.js-excluir-projeto', this.opcoes.Contexto).on('click', this.confirmacaoDeExclusaoProjeto);
      $("#editar-solicitacao", this.opcoes.Contexto).on('click', this.exibirEsconderSolicitacaoDeLicenciamento);
      $('#LegislacaoAmbiental_Nome', this.opcoes.Contexto).on('change', (function(_this) {
        return function() {
          return _this.exibirEsconderCamposDependentesDaLegislacaoAmbiental();
        };
      })(this));
      $('.dropdown-hover').hover((function() {
        return $(this).addClass('open');
      }), function() {
        return $(this).removeClass('open');
      });
      $("input[alt=date]").setMask();
      return window.MarcarMenuSuperior("#lnkEmpreendimentos");
    };

    EmpreendimentosController.prototype.clickTab = function() {
      $('.close').click();
      $("[rel=tooltip]").tooltip();
      return $('a[data-toggle="tab"]', this.opcoes.Contexto).on('shown.bs.tab', this.loadTab);
    };

    EmpreendimentosController.prototype.loadTab = function(event) {
      if (!$(event.target).data('carregado')) {
        $($(event.target).attr('href')).load($(event.target).data('url'));
        if (!($(event.target).attr("id") === "TabTimeline" || $(event.target).attr("id") === "TabCurvaS")) {
          return $(event.target).data('carregado', true);
        }
      }
    };

    EmpreendimentosController.prototype.confirmacaoDeExclusaoProjeto = function(event) {
      return window.modalConfirm($(event.delegateTarget).data("ajax-confirm"), this.excluirProjeto);
    };

    EmpreendimentosController.prototype.excluirProjeto = function() {
      return $as.Onegreen.Empreendimentos.Delete.post({
        id: this.opcoes.idDoProjeto
      }).success((function(_this) {
        return function(data) {
          return $('#main').html(data);
        };
      })(this));
    };

    EmpreendimentosController.prototype.carregarTelaEmpreendimento = function() {
      this.configurarComboUnidadeGerencial();
      this.configurarComboLegislacao();
      this.configurarComboTipoDeEmpreendimento();
      this.configurarComboMunicipios();
      this.configurarComboSolicitacaoDeLicenciamento();
      this.carregarCamposDeData();
      this.exibirEsconderCamposDependentesDaLegislacaoAmbiental();
      this.configurarComboResponsavel();
      this.exibirEsconderUnidadeSuperior();
      this.definirClickTitulo();
      this.configurarTagsEmpreendimento();
      return this.configurarExibirSolicitacaoDeLicenciamento();
    };

    EmpreendimentosController.prototype.exibirEsconderSolicitacaoDeLicenciamento = function() {
      $("#informacoes-solicitacao", this.opcoes.Contexto).hide(500);
      return $("#dvSolicitacaoDeLicenciamento", this.opcoes.Contexto).show(500);
    };

    EmpreendimentosController.prototype.configurarExibirSolicitacaoDeLicenciamento = function() {
      if (this.opcoes.novoRegistro || this.opcoes.idDaSolicitacao === 0) {
        return $("#dvSolicitacaoDeLicenciamento", this.opcoes.Contexto).show(0);
      } else {
        return $("#dvSolicitacaoDeLicenciamento", this.opcoes.Contexto).hide(0);
      }
    };

    EmpreendimentosController.prototype.definirClickTitulo = function() {
      return $("#tituloEmpreendimento").on('click', (function(_this) {
        return function() {
          return $(".tab-empreendimento a").click();
        };
      })(this));
    };

    EmpreendimentosController.prototype.configurarTagsEmpreendimento = function() {
      return $as.Onegreen.Tags.RetornarTags.get().success((function(_this) {
        return function(data) {
          return $('#agregadorDeTags', _this.opcoes.Contexto).tagit({
            availableTags: data,
            tagListUl: $('#tagsListUl', _this.opcoes.Contexto),
            afterTagAdded: _this.adicionarTagEmpreendimento,
            afterTagRemoved: _this.removerTagEmpreendimento
          });
        };
      })(this));
    };

    EmpreendimentosController.prototype.adicionarTagEmpreendimento = function(event, ui) {
      return $as.Onegreen.Empreendimentos.AdicionarTagEmpreendimento.post({
        id: this.opcoes.idDoProjeto,
        nomeTag: ui.tagLabel
      });
    };

    EmpreendimentosController.prototype.removerTagEmpreendimento = function(event, ui) {
      return $as.Onegreen.Empreendimentos.RemoverTagEmpreendimento.post({
        id: this.opcoes.idDoProjeto,
        nomeTag: ui.tagLabel
      });
    };

    EmpreendimentosController.prototype.configurarComboSolicitacaoDeLicenciamento = function() {
      return setCombo(this.opcoes.Contexto, "#SolicitacaoDeLicenciamento_Descricao");
    };

    EmpreendimentosController.prototype.configurarComboMunicipios = function() {
      var empreendimentoViewModel, jSonMunicipio;
      $.loadTemplate(this.opcoes.municipiosTemplate, 'municipiosTemplate');
      if (this.opcoes.possuiEstado) {
        jSonMunicipio = this.opcoes.jsonMunicipiosSemEstado;
      } else {
        jSonMunicipio = this.opcoes.jsonMunicipiosComEstado;
      }
      empreendimentoViewModel = {
        municipios: ko.observableArray(jSonMunicipio),
        Unidade_Superior_Sigla: ko.observable(''),
        removeMunicipio: function(municipio) {
          return this.municipios.remove(municipio);
        }
      };
      window.empreendimentoViewModel = empreendimentoViewModel;
      ko.applyBindings(empreendimentoViewModel);
      return $('#EmpreendimentoMunicipios').autocompleter(this.opcoes.urlAutocompleterMunicipio, {
        loadOnDemand: true,
        elementToClick: '#EmpreendimentoMunicipiosBtn',
        multiSelectArray: empreendimentoViewModel.municipios,
        multiSelectElement: '#municipios_itens',
        keyName: 'idsMunicipios',
        parameters: {
          ideLegislacao: function() {
            return $('#LegislacaoAmbiental_Id').val();
          }
        }
      });
    };

    EmpreendimentosController.prototype.configurarComboLegislacao = function() {
      var aoSelecionarLegislacao;
      aoSelecionarLegislacao = (function(_this) {
        return function(valueInput) {
          _this.exibirEsconderCamposDependentesDaLegislacaoAmbiental();
          _this.configurarComboTipoDeEmpreendimento();
          $('#Tipologia_Id').val('');
          $('#Tipologia_Descricao').val('');
          $('#municipios_itens').html("");
          return empreendimentoViewModel.municipios.removeAll();
        };
      })(this);
      return setCombo(this.opcoes.Contexto, "#LegislacaoAmbiental_Nome", aoSelecionarLegislacao);
    };

    EmpreendimentosController.prototype.exibirEsconderUnidadeSuperior = function() {
      if ($('#UnidadeGerencial_Id').val() !== "") {
        return $as.API.UnidadeGerencial.RetornarSiglaUnidadeSuperior.get({
          idUnidadeGerencial: $('#UnidadeGerencial_Id').val()
        }).success((function(_this) {
          return function(data) {
            if (data !== '') {
              empreendimentoViewModel.Unidade_Superior_Sigla(data);
              return $("#DivUnidadeSuperior").css("display", "");
            } else {
              return $("#DivUnidadeSuperior").css("display", "none");
            }
          };
        })(this));
      }
    };

    EmpreendimentosController.prototype.configurarComboResponsavel = function() {
      return setCombo(this.opcoes.Contexto, '#Responsavel_Nome');
    };

    EmpreendimentosController.prototype.exibirEsconderCamposDependentesDaLegislacaoAmbiental = function() {
      var legislacaoSelecionada;
      legislacaoSelecionada = $('#LegislacaoAmbiental_Id').val() === '';
      $('#Tipologia_Descricao').data('autocompleter').disableElseEnable(legislacaoSelecionada);
      return $('#EmpreendimentoMunicipios').data('autocompleter').disableElseEnable(legislacaoSelecionada);
    };

    EmpreendimentosController.prototype.configurarComboUnidadeGerencial = function() {
      var aoSelecionarUnidade;
      aoSelecionarUnidade = (function(_this) {
        return function() {
          return _this.exibirEsconderUnidadeSuperior();
        };
      })(this);
      return setCombo(this.opcoes.Contexto, '#UnidadeGerencialNome', aoSelecionarUnidade);
    };

    EmpreendimentosController.prototype.configurarComboTipoDeEmpreendimento = function() {
      var parametros;
      parametros = {
        ideLegislacao: (function(_this) {
          return function() {
            return $('#LegislacaoAmbiental_Id', _this.opcoes.Contexto).val();
          };
        })(this)
      };
      return setCombo(this.opcoes.Contexto, '#Tipologia_Descricao', null, parametros);
    };

    EmpreendimentosController.prototype.carregarCamposDeData = function() {
      $("#DataInicioImplantacao").datepicker({
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true
      });
      return $("#DataInicioOperacao").datepicker({
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true
      });
    };

    EmpreendimentosController.prototype.voltar = function() {
      if (window.VoltarERecarregar === void 0) {
        return $as.Onegreen.Empreendimentos.Index.post().success((function(_this) {
          return function(data) {
            return $('#main').html(data);
          };
        })(this));
      } else {
        return window.VoltarERecarregar();
      }
    };

    EmpreendimentosController.prototype.voltarParaEmpreendimentos = function() {
      var href;
      if (event.preventDefault) {
        event.preventDefault();
      }
      if (window.FiltroAvancadoEmpreendimento !== void 0) {
        return window.VoltarERecarregar();
      } else {
        href = $(el).attr("href");
        return $.get(href, {}, (function(_this) {
          return function(data) {
            return $("#main").html(data);
          };
        })(this));
      }
    };

    EmpreendimentosController.prototype.salvarEAvancarParaLicenciamento = function() {
      $('#CriarEmLicenciamento').val(true);
      return $('#form-createedit-empreendimento').submit();
    };

    EmpreendimentosController.prototype.salvar = function() {
      $('#CriarEmLicenciamento').val(false);
      return $('#form-createedit-empreendimento').submit();
    };

    EmpreendimentosController.aoMudarDeFaseNoFluxo = function() {
      var nomeDaFase;
      nomeDaFase = $("#nome-da-fase").val();
      $("#link-empreendimentos").click();
      if (nomeDaFase === "Elaboracao" || nomeDaFase === "Aprovacao") {
        $("#lnkLicencas", "#ulMenuOpcoes").attr("href", "#");
        $("#lnkLicencas", "#ulMenuOpcoes").addClass("disabled");
        $("#lnkLicencas", "#ulMenuOpcoes").attr("rel", "tooltip");
        return $("#lnkLicencas", "#ulMenuOpcoes").attr("data-original-title", window.getResource('ACriacaoDeLicencasEPermitidaSomenteParaProjetosAprovados'));
      } else {
        $("#lnkLicencas", "#ulMenuOpcoes").attr("href", "#licencasambientais-container");
        $("#lnkLicencas", "#ulMenuOpcoes").removeClass("disabled");
        $("#lnkLicencas", "#ulMenuOpcoes").removeAttr("rel");
        $("#lnkLicencas", "#ulMenuOpcoes").removeAttr("data-original-title");
        return $("#lnkLicencas", "#ulMenuOpcoes").data('carregado', false);
      }
    };

    return EmpreendimentosController;

  })();

}).call(this);
