﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.legislacoesAmbientaisController = (function() {
  function legislacoesAmbientaisController(options) {
    this.options = options;
    this.esconderMostrarPopover = bind(this.esconderMostrarPopover, this);
    this.configurarPopoverMatriz = bind(this.configurarPopoverMatriz, this);
    this.onClickCancelar = bind(this.onClickCancelar, this);
    this.submit = bind(this.submit, this);
    this.carregaMatriz = bind(this.carregaMatriz, this);
    setCombo("#main", "#Estado_Sigla");
    this.configurarPopoverMatriz();
    this.esconderMostrarPopover();
    $("#tabLegislacao li a[href=#matrizDeClassificacao]").click(this.carregaMatriz);
    $('#Nome').focus();
  }

  legislacoesAmbientaisController.prototype.carregaMatriz = function() {
    return $as.Onegreen.LegislacoesAmbientais.MatrizDeLegislacaoAmbiental.get({
      idDaLegislacao: this.options.idDaLegislacao
    }).success((function(_this) {
      return function(data) {
        return $("#matrizDeClassificacao").html(data);
      };
    })(this));
  };

  legislacoesAmbientaisController.prototype.submit = function() {
    return $("#formLegislacao").submit();
  };

  $('#tabLegislacao a').click(function(e) {
    e.preventDefault();
    return $(legislacoesAmbientaisController).tab('show');
  });

  legislacoesAmbientaisController.prototype.onClickCancelar = function() {
    return $as.Onegreen.LegislacoesAmbientais.Index.get().success((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  legislacoesAmbientaisController.prototype.configurarPopoverMatriz = function() {
    $("#iconeMatriz").popover();
    $("#matriz").change((function(_this) {
      return function() {
        return _this.esconderMostrarPopover();
      };
    })(this));
    $("#geral").change((function(_this) {
      return function() {
        return _this.esconderMostrarPopover();
      };
    })(this));
    return $as.Onegreen.LegislacoesAmbientais.MatrizPadraoLegislacaoAmbiental.get().success((function(_this) {
      return function(data) {
        return $("#iconeMatriz").attr("data-content", data);
      };
    })(this));
  };

  legislacoesAmbientaisController.prototype.esconderMostrarPopover = function() {
    if ($("#matriz").attr('checked') === 'checked') {
      $("#iconeMatriz").show();
      $("#iconeMatriz").popover();
    }
    if ($("#geral").attr('checked') === 'checked') {
      return $("#iconeMatriz").hide();
    }
  };

  return legislacoesAmbientaisController;

})();
