﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.filtroBuscarEstudosController = (function() {
  function filtroBuscarEstudosController(options) {
    this.options = options;
    this.configurarDatePickers = bind(this.configurarDatePickers, this);
    this.limparCampo = bind(this.limparCampo, this);
    this.configurarCamposDependentes = bind(this.configurarCamposDependentes, this);
    this.limparComboContrato = bind(this.limparComboContrato, this);
    this.limparComboLicencas = bind(this.limparComboLicencas, this);
    this.camposDependentesEmpresaResponsavel = bind(this.camposDependentesEmpresaResponsavel, this);
    this.camposDependentesEmpreendimento = bind(this.camposDependentesEmpreendimento, this);
    this.loadComboContrato = bind(this.loadComboContrato, this);
    this.loadComboEmpresaResponsavel = bind(this.loadComboEmpresaResponsavel, this);
    this.loadTipoEstudo = bind(this.loadTipoEstudo, this);
    this.loadComboNomeProjeto = bind(this.loadComboNomeProjeto, this);
    this.loadComboLicencasAmbientais = bind(this.loadComboLicencasAmbientais, this);
    this.submitFiltro = bind(this.submitFiltro, this);
    this.habilitarEnter = bind(this.habilitarEnter, this);
    this.configurarFiltro = bind(this.configurarFiltro, this);
    this.configurarFiltro();
    this.habilitarEnter();
    this.loadComboLicencasAmbientais();
    this.loadComboContrato();
    this.loadComboNomeProjeto();
    this.loadComboEmpresaResponsavel();
    this.loadTipoEstudo();
    this.configurarDatePickers();
    this.configurarCamposDependentes();
    $('.aplicarFiltro').unbind('click').click(this.submitFiltro);
    $('#limparFiltro', this.options.contexto).unbind('click').click(this.limparCampo);
  }

  filtroBuscarEstudosController.prototype.configurarFiltro = function() {
    $('#filtro-buscar-estudos').on('click', (function(_this) {
      return function() {
        return $('#filtro-buscar-estudos-container').toggle();
      };
    })(this));
    return $('#fechar-filtro').on('click', (function(_this) {
      return function() {
        return $('#filtro-buscar-estudos-container').toggle();
      };
    })(this));
  };

  filtroBuscarEstudosController.prototype.habilitarEnter = function() {
    return $('#NomeEstudo').keypress((function(_this) {
      return function(event) {
        if (event.keyCode === 13) {
          return _this.submitFiltro();
        }
      };
    })(this));
  };

  filtroBuscarEstudosController.prototype.submitFiltro = function() {
    var dados;
    dados = $('#main').find(":input").serialize();
    return $as.Onegreen.BuscarEstudos.Filtro.get(dados).success((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  filtroBuscarEstudosController.prototype.loadComboLicencasAmbientais = function() {
    var parametros;
    parametros = {
      idDoEmpreendimento: $('#Empreendimento').val()
    };
    return setCombo(this.options.contexto, '#LicencaAmbientalNome', null, parametros);
  };

  filtroBuscarEstudosController.prototype.loadComboNomeProjeto = function() {
    return setCombo(this.options.contexto, '#EmpreendimentoNome', this.camposDependentesEmpreendimento);
  };

  filtroBuscarEstudosController.prototype.loadTipoEstudo = function() {
    return setCombo(this.options.contexto, '#TipoEstudoNome');
  };

  filtroBuscarEstudosController.prototype.loadComboEmpresaResponsavel = function() {
    return setCombo(this.options.contexto, '#EmpresaResponsavelNome', this.camposDependentesEmpresaResponsavel);
  };

  filtroBuscarEstudosController.prototype.loadComboContrato = function() {
    var parametros;
    parametros = {
      idEmpresa: $('#EmpresaResponsavel').val()
    };
    return setCombo(this.options.contexto, '#ContratoNome', null, parametros);
  };

  filtroBuscarEstudosController.prototype.camposDependentesEmpreendimento = function() {
    var empreendimentoSelecionado;
    empreendimentoSelecionado = $('#Empreendimento').val() !== null && $('#Empreendimento').val() !== 0 && $('#Empreendimento').val() !== void 0 && $('#Empreendimento').val() !== '';
    if (empreendimentoSelecionado) {
      this.loadComboLicencasAmbientais();
      this.limparComboLicencas();
    } else {
      this.limparComboLicencas();
    }
    return $('#LicencaAmbientalNome').data('autocompleter').disableElseEnable(!empreendimentoSelecionado);
  };

  filtroBuscarEstudosController.prototype.camposDependentesEmpresaResponsavel = function() {
    var empresaResponsavelSelecionada;
    empresaResponsavelSelecionada = $('#EmpresaResponsavel').val() !== null && $('#EmpresaResponsavel').val() !== 0 && $('#EmpresaResponsavel').val() !== void 0 && $('#EmpresaResponsavel').val() !== '';
    if (empresaResponsavelSelecionada) {
      this.loadComboContrato();
      this.limparComboContrato();
    } else {
      this.limparComboContrato();
    }
    return $('#ContratoNome').data('autocompleter').disableElseEnable(!empresaResponsavelSelecionada);
  };

  filtroBuscarEstudosController.prototype.limparComboLicencas = function() {
    $('#LicencaAmbiental').val('');
    return $('#LicencaAmbientalNome').val('');
  };

  filtroBuscarEstudosController.prototype.limparComboContrato = function() {
    $('#Contrato').val('');
    return $('#ContratoNome').val('');
  };

  filtroBuscarEstudosController.prototype.configurarCamposDependentes = function() {
    var contratoSelecionado, empreendimentoSelecionado, empresaResponsavelSelecionada, licencaSelecionada;
    empreendimentoSelecionado = $('#Empreendimento').val() !== null && $('#Empreendimento').val() !== 0 && $('#Empreendimento').val() !== void 0 && $('#Empreendimento').val() !== '';
    licencaSelecionada = $('#LicencaAmbiental').val() !== null && $('#LicencaAmbiental').val() !== 0 && $('#LicencaAmbiental').val() !== void 0 && $('#LicencaAmbiental').val() !== '';
    if (!licencaSelecionada && !empreendimentoSelecionado) {
      this.limparComboLicencas();
      $('#LicencaAmbientalNome').data('autocompleter').disableElseEnable(!licencaSelecionada);
    }
    empresaResponsavelSelecionada = $('#EmpresaResponsavel').val() !== null && $('#EmpresaResponsavel').val() !== 0 && $('#EmpresaResponsavel').val() !== void 0 && $('#EmpresaResponsavel').val() !== '';
    contratoSelecionado = $('#Contrato').val() !== null && $('#Contrato').val() !== 0 && $('#Contrato').val() !== void 0 && $('#Contrato').val() !== '';
    if (!contratoSelecionado && !empresaResponsavelSelecionada) {
      this.limparComboContrato();
      return $('#ContratoNome').data('autocompleter').disableElseEnable(!contratoSelecionado);
    }
  };

  filtroBuscarEstudosController.prototype.limparCampo = function() {
    $('#Empreendimento').val('');
    $('#EmpreendimentoNome').val('');
    $('#TipoEstudo').val('');
    $('#TipoEstudoNome').val('');
    $('#UnidadeGerencial').val('');
    $('#UnidadeGerencialNome').val('');
    $('#EmpresaResponsavel').val('');
    $('#EmpresaResponsavelNome').val('');
    $('#Contrato').val('');
    $('#ContratoNome').val('');
    this.camposDependentesEmpreendimento();
    return this.camposDependentesEmpresaResponsavel();
  };

  filtroBuscarEstudosController.prototype.configurarDatePickers = function() {
    return $('.date-picker', this.options.contexto).datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      autoclose: true,
      language: Globalize.culture($("html").attr("lang")).name
    });
  };

  return filtroBuscarEstudosController;

})();
