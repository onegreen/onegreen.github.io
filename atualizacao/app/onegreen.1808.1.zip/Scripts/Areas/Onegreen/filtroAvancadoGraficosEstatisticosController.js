﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.FiltroAvancadoGraficosEstatisticosController = (function(superClass) {
  extend(FiltroAvancadoGraficosEstatisticosController, superClass);

  function FiltroAvancadoGraficosEstatisticosController(opcoes, recursos) {
    this.opcoes = opcoes;
    this.recursos = recursos;
    this.exibirEsconderDataDeInicio = bind(this.exibirEsconderDataDeInicio, this);
    this.marcarTodosFarois = bind(this.marcarTodosFarois, this);
    this.desmarcarTodosFarois = bind(this.desmarcarTodosFarois, this);
    this.esconderFiltros = bind(this.esconderFiltros, this);
    this.SubmitGrafico = bind(this.SubmitGrafico, this);
    this.configurarComboTarefas = bind(this.configurarComboTarefas, this);
    this.configurarComboGraficos = bind(this.configurarComboGraficos, this);
    FiltroAvancadoGraficosEstatisticosController.__super__.constructor.call(this, this.opcoes, this.recursos);
    this.configurarComboGraficos();
    this.configurarComboTarefas();
    this.configurarBinds();
    this.esconderFiltros();
    this.desmarcarTodosFarois();
    this.marcarTodosFarois();
    this.exibirEsconderDataDeInicio();
  }

  FiltroAvancadoGraficosEstatisticosController.prototype.configurarBinds = function() {
    $('#fecharFiltroGraficos').on('click', (function(_this) {
      return function(e) {
        return $(_this.opcoes.Contexto).toggle();
      };
    })(this));
    $('#btnFiltroAvancado').on('click', (function(_this) {
      return function(e) {
        return $(_this.opcoes.Contexto).toggle();
      };
    })(this));
    return $('.js-grafico', this.opcoes.Contexto).unbind('click').click(this.SubmitGrafico);
  };

  FiltroAvancadoGraficosEstatisticosController.prototype.configurarComboGraficos = function() {
    return setCombo(this.opcoes.Contexto, "#Grafico_Nome", this.exibirEsconderDataDeInicio);
  };

  FiltroAvancadoGraficosEstatisticosController.prototype.configurarComboTarefas = function() {
    return setCombo(this.opcoes.Contexto, "#StatusDaTarefa_Nome");
  };

  FiltroAvancadoGraficosEstatisticosController.prototype.SubmitGrafico = function() {
    var dados;
    dados = $(this.opcoes.Contexto).find(":input").serialize();
    return $as.Onegreen.GraficosEstatisticos.RetornarGrafico.get(dados).success((function(_this) {
      return function(data) {
        if (data.error) {
          $('.validation-summary-errors', _this.opcoes.Contexto).remove();
          $('#filtro-avancado-graficos', _this.opcoes.Contexto).prepend(data.responseText);
          return $(_this.opcoes.Contexto).scrollTop(0);
        } else {
          return $("#main").html(data);
        }
      };
    })(this));
  };

  FiltroAvancadoGraficosEstatisticosController.prototype.esconderFiltros = function() {
    return $('#filtrobase-licenca', this.opcoes.Contexto).hide();
  };

  FiltroAvancadoGraficosEstatisticosController.prototype.desmarcarTodosFarois = function() {
    return $('#desmarcar-todos').on('click', (function(_this) {
      return function() {
        return $('input', '.checkableBoxFarolLicenca').prop('checked', false);
      };
    })(this));
  };

  FiltroAvancadoGraficosEstatisticosController.prototype.marcarTodosFarois = function() {
    return $('#marcar-todos').on('click', (function(_this) {
      return function() {
        return $('input', '.checkableBoxFarolLicenca').prop('checked', true);
      };
    })(this));
  };

  FiltroAvancadoGraficosEstatisticosController.prototype.exibirEsconderDataDeInicio = function() {
    var desabilitarDataDeInicio, textoComboGrafico;
    textoComboGrafico = $("#Grafico_Nome", this.opcoes.Contexto).val();
    desabilitarDataDeInicio = textoComboGrafico === this.recursos.CustoDasLicencasObtidas || textoComboGrafico === this.recursos.EstudosDentroDoPrazo || textoComboGrafico === this.recursos.LicencasObtidasDentroDoPrazo || textoComboGrafico === this.recursos.TarefasDentroDoPrazo;
    if (desabilitarDataDeInicio) {
      $("#DataInicio").parent().closest('div').hide();
    } else {
      $("#DataInicio").parent().closest('div').show();
    }
    if ($("#Grafico", this.opcoes.Contexto).val() === '7') {
      $("#somenteprincipais-container", this.opcoes.Contexto).show();
    } else {
      $("#somenteprincipais-container", this.opcoes.Contexto).hide();
    }
    if (textoComboGrafico === this.recursos.StatusDasLicencas) {
      $("#datasPeriodo").hide();
      $("#datasValidadeLicenca").show();
      $("#datasObtencaoLicenca").show();
      return $("#container-selecao-de-cores-do-Farol").show();
    } else {
      $("#datasPeriodo").show();
      $("#datasValidadeLicenca").hide();
      $("#datasObtencaoLicenca").hide();
      return $("#container-selecao-de-cores-do-Farol").hide();
    }
  };

  return FiltroAvancadoGraficosEstatisticosController;

})(window.FiltroAvancadoBaseController);
