﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.filtroBuscarLicencasController = (function() {
  function filtroBuscarLicencasController(options) {
    this.options = options;
    this.configurarTags = bind(this.configurarTags, this);
    this.configurarDatePickers2 = bind(this.configurarDatePickers2, this);
    this.configurarDatePickers = bind(this.configurarDatePickers, this);
    this.camposDependentesTiposDeLicencaAmbiental = bind(this.camposDependentesTiposDeLicencaAmbiental, this);
    this.limparComboTipoLicenca = bind(this.limparComboTipoLicenca, this);
    this.limparCampo = bind(this.limparCampo, this);
    this.habilitarEnter = bind(this.habilitarEnter, this);
    this.submitFiltro = bind(this.submitFiltro, this);
    this.marcarTodosOsPlanosDeAcao = bind(this.marcarTodosOsPlanosDeAcao, this);
    this.desmarcarTodosOsPlanosDeAcao = bind(this.desmarcarTodosOsPlanosDeAcao, this);
    this.configurarComboTipoDeLicencasAmbientais = bind(this.configurarComboTipoDeLicencasAmbientais, this);
    this.configurarComboTiposPrimitivos = bind(this.configurarComboTiposPrimitivos, this);
    this.configurarComboResponsaveis = bind(this.configurarComboResponsaveis, this);
    this.configurarComboEmpreendimento = bind(this.configurarComboEmpreendimento, this);
    this.configurarComboTiposDeLicencas = bind(this.configurarComboTiposDeLicencas, this);
    this.configurarFiltro = bind(this.configurarFiltro, this);
    this.configurarFiltro();
    this.habilitarEnter();
    this.configurarComboTiposDeLicencas();
    this.configurarComboEmpreendimento();
    this.configurarComboResponsaveis();
    this.configurarComboTiposPrimitivos();
    this.desmarcarTodosOsPlanosDeAcao();
    this.marcarTodosOsPlanosDeAcao();
    this.configurarComboTipoDeLicencasAmbientais();
    this.configurarDatePickers();
    this.configurarDatePickers2();
    this.camposDependentesTiposDeLicencaAmbiental();
    this.configurarTags();
    $('.aplicarFiltro').unbind('click').click(this.submitFiltro);
    $('#LimparFiltro', this.options.contexto).unbind('click').click(this.limparCampo);
  }

  filtroBuscarLicencasController.prototype.configurarFiltro = function() {
    $('#filtro-busca-licenca').on('click', (function(_this) {
      return function() {
        return $('#filtro-busca-licencas-container').toggle();
      };
    })(this));
    return $('#fechar-filtro').on('click', (function(_this) {
      return function() {
        return $('#filtro-busca-licencas-container').toggle();
      };
    })(this));
  };

  filtroBuscarLicencasController.prototype.configurarComboTiposDeLicencas = function() {
    return setCombo(this.options.contexto, '#TipoDeLicencaNome');
  };

  filtroBuscarLicencasController.prototype.configurarComboEmpreendimento = function() {
    return setCombo(this.options.contexto, '#EmpreendimentoNome');
  };

  filtroBuscarLicencasController.prototype.configurarComboResponsaveis = function() {
    return setCombo(this.options.contexto, '#ResponsavelNome');
  };

  filtroBuscarLicencasController.prototype.configurarComboTiposPrimitivos = function() {
    $('#TipoPrimitivoNome').change(this.camposDependentesTiposDeLicencaAmbiental);
    return setCombo(this.options.contexto, '#TipoPrimitivoNome', this.camposDependentesTiposDeLicencaAmbiental);
  };

  filtroBuscarLicencasController.prototype.configurarComboTipoDeLicencasAmbientais = function() {
    return setCombo(this.options.contexto, '#TipoLicencaAmbientalNome');
  };

  filtroBuscarLicencasController.prototype.desmarcarTodosOsPlanosDeAcao = function() {
    return $('#desmarcar-todos').on('click', (function(_this) {
      return function() {
        return $('input', '#container-selecao-de-cores-do-Farol').prop('checked', false);
      };
    })(this));
  };

  filtroBuscarLicencasController.prototype.marcarTodosOsPlanosDeAcao = function() {
    return $('#marcar-todos').on('click', (function(_this) {
      return function() {
        return $('input', '#container-selecao-de-cores-do-Farol').prop('checked', true);
      };
    })(this));
  };

  filtroBuscarLicencasController.prototype.submitFiltro = function() {
    var dados;
    dados = $('#div-input-pesquisar', this.options.contexto).find('.tagit-hidden-field').serialize() + "&" + $('#main').find(":input").serialize();
    return $as.Onegreen.BuscarLicencas.Filtro.get(dados).success((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  filtroBuscarLicencasController.prototype.habilitarEnter = function() {
    return $('#IdentificadorLicenca').keypress((function(_this) {
      return function(event) {
        if (event.keyCode === 13) {
          return _this.submitFiltro();
        }
      };
    })(this));
  };

  filtroBuscarLicencasController.prototype.limparCampo = function() {
    $('#Empreendimento').val('');
    $('#EmpreendimentoNome').val('');
    $('#TipoDeLicenca').val('');
    $('#TipoDeLicencaNome').val('');
    $('#Responsavel').val('');
    $('#ResponsavelNome').val('');
    $('#TipoPrimitivo').val('');
    $('#TipoPrimitivoNome').val('');
    $('#DataInicioObt').val('');
    $('#DataFimObt').val('');
    $('#DataInicioVal').val('');
    $('#DataFimVal').val('');
    return this.camposDependentesTiposDeLicencaAmbiental();
  };

  filtroBuscarLicencasController.prototype.limparComboTipoLicenca = function() {
    $('#TipoLicencaAmbientalNome').val('');
    return $('#TipoLicencaAmbiental').val('');
  };

  filtroBuscarLicencasController.prototype.camposDependentesTiposDeLicencaAmbiental = function() {
    var tipoPrimitivoSelecionado;
    tipoPrimitivoSelecionado = $('#TipoPrimitivo').val() === "1";
    if (tipoPrimitivoSelecionado) {
      this.configurarComboTipoDeLicencasAmbientais();
    } else if ($('#TipoPrimitivo').val() === "2" || $('#TipoPrimitivo').val() === "3" || $('#TipoPrimitivo').val() === "4" || $('#TipoPrimitivo').val() === "") {
      this.limparComboTipoLicenca();
    }
    return $('#TipoLicencaAmbientalNome').data('autocompleter').disableElseEnable(!tipoPrimitivoSelecionado);
  };

  filtroBuscarLicencasController.prototype.configurarDatePickers = function() {
    return $('.date-pickerObt', this.options.contexto).datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      autoclose: true,
      language: Globalize.culture($("html").attr("lang")).name
    });
  };

  filtroBuscarLicencasController.prototype.configurarDatePickers2 = function() {
    return $('.date-pickerVal', this.options.contexto).datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      autoclose: true,
      language: Globalize.culture($("html").attr("lang")).name
    });
  };

  filtroBuscarLicencasController.prototype.configurarTags = function() {
    return $as.Onegreen.Tags.RetornarTags.get().success((function(_this) {
      return function(data) {
        return $('#NomeTag', _this.options.contexto).tagit({
          combo: true,
          availableTags: data,
          tagListUl: $('#tagsListUl', _this.options.contexto)
        });
      };
    })(this));
  };

  return filtroBuscarLicencasController;

})();
