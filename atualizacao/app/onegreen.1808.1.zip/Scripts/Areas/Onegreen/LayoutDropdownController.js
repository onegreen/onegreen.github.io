﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.layoutDropdownController = (function() {
  function layoutDropdownController(options) {
    this.options = options;
    this.ClickarFora = bind(this.ClickarFora, this);
    this.clickForaFechar = bind(this.clickForaFechar, this);
    this.clickMais = bind(this.clickMais, this);
    this.bodyClick = bind(this.bodyClick, this);
    this.dropDownMenu = bind(this.dropDownMenu, this);
    this.dropDownMenu();
    this.bodyClick();
    this.clickMais();
    this.clickForaFechar();
  }

  layoutDropdownController.prototype.dropDownMenu = function() {
    return $('li.mega-dropdown a').on('click', function(event) {
      $(this).parent().toggleClass('open');
      $('.overlay-back').fadeOut();
      $('.size').slideUp();
    });
  };

  layoutDropdownController.prototype.bodyClick = function() {
    return $('body').on('click', function(e) {
      if (!$('li.mega-dropdown').is(e.target) && $('li.mega-dropdown').has(e.target).length === 0 && $('.open').has(e.target).length === 0) {
        $('#overlay-back').remove;
      }
    });
  };

  layoutDropdownController.prototype.clickMais = function() {
    return $('.dropdownPlus').click(function() {
      $('.overlay-back').fadeToggle(500);
      return $(this).children('.size').slideToggle(400);
    });
  };

  layoutDropdownController.prototype.clickForaFechar = function() {
    return $('.overlay-back').click(function(event) {
      event.preventDefault;
      event.stopPropagation();
      $('.overlay-back').fadeOut();
      return $('.size').slideUp();
    });
  };

  layoutDropdownController.prototype.ClickarFora = function() {
    return $('body').on('click', function(e) {
      $('li.mega-dropdown a').parent().removeClass('open');
      $('.overlay-back').fadeOut();
      $('.size').slideUp();
      return $('#menu-principal').removeClass('c-branca');
    });
  };

  return layoutDropdownController;

})();
