var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.filtroBuscaTarefasController = (function() {
  function filtroBuscaTarefasController(options) {
    this.options = options;
    this.configurarTags = bind(this.configurarTags, this);
    this.habilitarEnter = bind(this.habilitarEnter, this);
    this.submitFiltro = bind(this.submitFiltro, this);
    this.loadComboResponsavel = bind(this.loadComboResponsavel, this);
    this.limparComboLicencas = bind(this.limparComboLicencas, this);
    this.loadComboLicenca = bind(this.loadComboLicenca, this);
    this.configurarFiltro = bind(this.configurarFiltro, this);
    this.camposDependentesLicencaAmbiental = bind(this.camposDependentesLicencaAmbiental, this);
    this.loadComboEmpreendimento = bind(this.loadComboEmpreendimento, this);
    this.loadComboTipoDeLicenca = bind(this.loadComboTipoDeLicenca, this);
    this.limparComboTipologia = bind(this.limparComboTipologia, this);
    this.loadComboTipologia = bind(this.loadComboTipologia, this);
    this.aoSelecionarLegislacao = bind(this.aoSelecionarLegislacao, this);
    this.camposDependentesLegislacaoAmbiental = bind(this.camposDependentesLegislacaoAmbiental, this);
    this.loadComboLegislacao = bind(this.loadComboLegislacao, this);
    this.loadComboEndereco = bind(this.loadComboEndereco, this);
    this.loadComboUnidade = bind(this.loadComboUnidade, this);
    this.loadCombos = bind(this.loadCombos, this);
    this.configurarFiltro();
    this.loadCombos();
    this.configurarTags();
    this.habilitarEnter();
    $('.aplicarFiltro').unbind('click').click(this.submitFiltro);
    $("#marcar-todos", "#container-selecao-de-planos-de-acao").click(this.marcarTodosOsPlanosDeAcao);
    $("#desmarcar-todos", "#container-selecao-de-planos-de-acao").click(this.desmarcarTodosOsPlanosDeAcao);
  }

  filtroBuscaTarefasController.prototype.loadCombos = function() {
    this.loadComboUnidade();
    this.loadComboEndereco();
    this.loadComboLegislacao();
    this.loadComboTipoDeLicenca();
    this.loadComboEmpreendimento();
    this.loadComboLicenca();
    this.loadComboResponsavel();
    this.loadComboTipologia();
    this.camposDependentesLicencaAmbiental();
    return this.camposDependentesLegislacaoAmbiental();
  };

  filtroBuscaTarefasController.prototype.loadComboUnidade = function() {
    return setCombo(this.options.contexto, "#NomeDaUnidadeGerencial");
  };

  filtroBuscaTarefasController.prototype.loadComboEndereco = function() {
    return setCombo(this.options.contexto, "#NomeDoEndereco");
  };

  filtroBuscaTarefasController.prototype.loadComboLegislacao = function() {
    $("#NomeDaLegislacaoAmbiental", this.options.contexto).change((function(_this) {
      return function() {
        if ($("#NomeDaLegislacaoAmbiental", _this.options.contexto).val() === '') {
          return $('#NomeDaTipologia').data('autocompleter').disableElseEnable(true);
        }
      };
    })(this));
    return setCombo(this.options.contexto, "#NomeDaLegislacaoAmbiental", this.camposDependentesLegislacaoAmbiental);
  };

  filtroBuscaTarefasController.prototype.camposDependentesLegislacaoAmbiental = function() {
    var legislacaoSelecionada;
    legislacaoSelecionada = $('#IdDaLegislacaoAmbiental').val() !== null && $('#IdDaLegislacaoAmbiental').val() !== 0 && $('#IdDaLegislacaoAmbiental').val() !== void 0 && $('#IdDaLegislacaoAmbiental').val() !== '';
    if (legislacaoSelecionada) {
      this.loadComboTipologia();
    } else {
      this.limparComboTipologia();
    }
    return $('#NomeDaTipologia').data('autocompleter').disableElseEnable(!legislacaoSelecionada);
  };

  filtroBuscaTarefasController.prototype.aoSelecionarLegislacao = function(input) {
    $("#IdDaTipologia", this.options.contexto).val('');
    return $("#NomeDaTipologia", this.options.contexto).val('');
  };

  filtroBuscaTarefasController.prototype.loadComboTipologia = function() {
    var parametros;
    parametros = {
      ideLegislacao: $('#IdDaLegislacaoAmbiental').val()
    };
    return setCombo(this.options.contexto, "#NomeDaTipologia", null, parametros);
  };

  filtroBuscaTarefasController.prototype.limparComboTipologia = function() {
    $("#IdDaTipologia", this.options.contexto).val('');
    return $("#NomeDaTipologia", this.options.contexto).val('');
  };

  filtroBuscaTarefasController.prototype.loadComboTipoDeLicenca = function() {
    return setCombo(this.options.contexto, "#NomeDoTipoDeLicenca");
  };

  filtroBuscaTarefasController.prototype.loadComboEmpreendimento = function() {
    $("#NomeDoEmpreendimento", this.options.contexto).change((function(_this) {
      return function() {
        if ($("#NomeDoEmpreendimento", _this.options.contexto).val() === '') {
          $('#NomeDaLicencaAmbiental').data('autocompleter').disableElseEnable(true);
          return _this.limparComboLicencas();
        }
      };
    })(this));
    return setCombo(this.options.contexto, "#NomeDoEmpreendimento", this.camposDependentesLicencaAmbiental);
  };

  filtroBuscaTarefasController.prototype.camposDependentesLicencaAmbiental = function() {
    var empreendimentoSelecionado;
    empreendimentoSelecionado = $('#IdDoEmpreendimento').val() !== null && $('#IdDoEmpreendimento').val() !== 0 && $('#IdDoEmpreendimento').val() !== void 0 && $('#IdDoEmpreendimento').val() !== '';
    if (empreendimentoSelecionado) {
      this.loadComboLicenca();
    } else {
      this.limparComboLicencas();
    }
    return $('#NomeDaLicencaAmbiental').data('autocompleter').disableElseEnable(!empreendimentoSelecionado);
  };

  filtroBuscaTarefasController.prototype.configurarFiltro = function() {
    $("#filtro-busca-tarefas").on('click', (function(_this) {
      return function() {
        return $("#filtro-busca-tarefas-container").toggle();
      };
    })(this));
    return $("#fechar-filtro", this.options.contexto).on('click', (function(_this) {
      return function() {
        return $("#filtro-busca-tarefas-container").toggle();
      };
    })(this));
  };

  filtroBuscaTarefasController.prototype.loadComboLicenca = function() {
    var parametros;
    parametros = {
      idDoEmpreendimento: $('#IdDoEmpreendimento').val()
    };
    return setCombo(this.options.contexto, "#NomeDaLicencaAmbiental", null, parametros);
  };

  filtroBuscaTarefasController.prototype.limparComboLicencas = function() {
    $('#IdDaLicencaAmbiental').val('');
    return $('#NomeDaLicencaAmbiental').val('');
  };

  filtroBuscaTarefasController.prototype.loadComboResponsavel = function() {
    return setCombo(this.options.contexto, "#NomeDoUsuarioResponsavel");
  };

  filtroBuscaTarefasController.prototype.marcarTodosOsPlanosDeAcao = function() {
    return $("input", "#container-selecao-de-planos-de-acao").prop("checked", true);
  };

  filtroBuscaTarefasController.prototype.desmarcarTodosOsPlanosDeAcao = function() {
    return $("input", "#container-selecao-de-planos-de-acao").prop("checked", false);
  };

  filtroBuscaTarefasController.prototype.submitFiltro = function() {
    var dados;
    dados = $('#div-input-pesquisar', this.options.contexto).find('.tagit-hidden-field').serialize() + "&" + $('#main').find(":input").serialize();
    return $as.Onegreen.BuscarTarefas.Filtro.get(dados).success((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  filtroBuscaTarefasController.prototype.habilitarEnter = function() {
    return $('#DescricaoTarefa').keypress((function(_this) {
      return function(event) {
        if (event.keyCode === 13) {
          return _this.submitFiltro();
        }
      };
    })(this));
  };

  filtroBuscaTarefasController.prototype.configurarTags = function() {
    return $as.Onegreen.Tags.RetornarTags.get().success((function(_this) {
      return function(data) {
        return $('#NomeTag', _this.options.contexto).tagit({
          combo: true,
          availableTags: data,
          tagListUl: $('#tagsListUl', _this.options.contexto)
        });
      };
    })(this));
  };

  return filtroBuscaTarefasController;

})();
