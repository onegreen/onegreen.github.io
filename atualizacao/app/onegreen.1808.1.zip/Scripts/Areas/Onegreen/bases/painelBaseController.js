﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.painelBaseController = (function() {
  function painelBaseController(options, recursos) {
    this.options = options;
    this.recursos = recursos;
    this.atualizarBoxesAbertos = bind(this.atualizarBoxesAbertos, this);
    this.configurarExibicaoDoBox = bind(this.configurarExibicaoDoBox, this);
    this.marcarPercentualDeConclusaoToggle = bind(this.marcarPercentualDeConclusaoToggle, this);
    this.configurarFiltroDeCondicionantes = bind(this.configurarFiltroDeCondicionantes, this);
    this.loadCondicionantes = bind(this.loadCondicionantes, this);
    this.configurarFiltroDeAcoes = bind(this.configurarFiltroDeAcoes, this);
    this.loadMarcosDeProjeto = bind(this.loadMarcosDeProjeto, this);
    this.loadLicencas = bind(this.loadLicencas, this);
    this.funcaoCallBack = bind(this.funcaoCallBack, this);
    this.reload = bind(this.reload, this);
    this.configuraLinkVoltarDaLicenca = bind(this.configuraLinkVoltarDaLicenca, this);
    this.loadComboUnidadeGerencial = bind(this.loadComboUnidadeGerencial, this);
    this.defineFiltro = bind(this.defineFiltro, this);
    this.configuraAplicarFiltro = bind(this.configuraAplicarFiltro, this);
    this.preencherFiltro = bind(this.preencherFiltro, this);
    $(".js-titulo-box-meu-painel").unbind("click").bind("click", (function(_this) {
      return function(event) {
        return $(event.delegateTarget).prev("i").click();
      };
    })(this));
    $(".js-toggle-box-meu-painel").unbind("click").bind("click", (function(_this) {
      return function(event) {
        return _this.configurarExibicaoDoBox(event);
      };
    })(this));
    $("#expandir-todos").unbind("click").bind("click", (function(_this) {
      return function(event) {
        return $(".js-toggle-box-meu-painel").each(function() {
          if (!$(this).data("aberto")) {
            return $(this).click();
          }
        });
      };
    })(this));
  }

  painelBaseController.prototype.preencherFiltro = function() {
    $("#IdUnidadeGerencial").val(window.FiltroPainel.IdUnidadeGerencial);
    $("#UnidadeGerencialNome").val(window.FiltroPainel.NomeUnidadeGerencial);
    if (window.FiltroPainel.IncluirSubordinadas) {
      return $("#IncluirSubordinadas").attr("checked", "checked");
    } else {
      return $("#IncluirSubordinadas").removeAttr("checked");
    }
  };

  painelBaseController.prototype.configuraAplicarFiltro = function() {
    return $("#AplicarFiltro").click((function(_this) {
      return function(e) {
        e.preventDefault();
        $("#painel-container").fadeOut();
        $("#painel-container").fadeIn();
        _this.defineFiltro();
        _this.carregarTela();
        return _this.atualizarBoxesAbertos();
      };
    })(this));
  };

  painelBaseController.prototype.defineFiltro = function() {
    var UnidadeGerencialNome;
    window.FiltroPainel.IdDoUsuario = parseInt($("#IdDoUsuario").val());
    UnidadeGerencialNome = $("#UnidadeGerencialNome").val();
    window.FiltroPainel.IdUnidadeGerencial = $("#IdUnidadeGerencial").val();
    if (!(window.FiltroPainel.IdUnidadeGerencial > 0)) {
      UnidadeGerencialNome = '(' + this.recursos.Todas + ')';
    }
    window.FiltroPainel.NomeUnidadeGerencial = UnidadeGerencialNome;
    return window.FiltroPainel.IncluirSubordinadas = $("#IncluirSubordinadas").attr("checked") !== void 0;
  };

  painelBaseController.prototype.loadComboUnidadeGerencial = function() {
    this.preencherFiltro();
    return $('#UnidadeGerencialNome').autocompleter(this.options.urlComboUnidadeGerencial, {
      loadOnDemand: false,
      elementToClick: "#UnidadeGerencialNomeBtn",
      keyElement: "#IdUnidadeGerencial",
      defaultOption: {
        Key: "",
        Value: '(' + this.recursos.Todas + ')'
      }
    });
  };

  painelBaseController.prototype.configuraLinkVoltarDaLicenca = function() {
    var link;
    link = "<li class='divider'></li><li class='voltar'><a href='' onclick='VoltarERecarregar();return false;'>(" + this.recursos.Voltar + ")<i class='fa swicon-seta fr'></i></a></li>";
    return $(link).appendTo("#linksVoltar");
  };

  painelBaseController.prototype.reload = function() {
    return eval(atividadePainel.callback);
  };

  painelBaseController.prototype.funcaoCallBack = function() {
    return this.reload();
  };

  painelBaseController.prototype.loadLicencas = function() {
    $('#licencas-grafico-container, #licencas-tabela-container').html(this.ajaxLoader);
    return $as.Onegreen.LicencasAmbientais.LicencasPorEnvolvidos.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#licencas-grafico-container").html($(data).filter("#grafico-licencas"));
        $("#licencas-tabela-container").html($(data).filter("#tabela-licencas"));
        $("[rel=tooltip]").tooltip();
        $("[rel=popover]").popover({
          placement: "top"
        });
        return _this.configuraLinkVoltarDaLicenca();
      };
    })(this));
  };

  painelBaseController.prototype.loadMarcosDeProjeto = function() {
    $('#acoes-grafico-container, #acoes-tabela-container').html(this.ajaxLoader);
    return $as.Onegreen.AtividadesDoEmpreendimento.AcoesPeloResponsavel.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#acoes-tabela-container").html($(data).filter("#tabela-acoes"));
        $("[rel=tooltip]").tooltip();
        $("[rel=popover]").popover({
          placement: "top"
        });
        $("[id^=Percentual].btn-warning").prevAll().addClass("btn-warning");
        return setTimeout(function() {
          Atividades.api.boot();
          return _this.configurarFiltroDeAcoes();
        }, 500);
      };
    })(this));
  };

  painelBaseController.prototype.configurarFiltroDeAcoes = function() {
    $("#acoes-que-designei", "#acoes-tabela-container").unbind("click").bind("click", (function(_this) {
      return function(evento) {
        $("label", "#acoes-tabela-container").removeClass("btn-warning");
        $(evento.delegateTarget).addClass("btn-warning");
        return $("a[data-idusuario]", "#acoes-tabela-container").each(function() {
          if ($( this ).data("idusuario") === window.FiltroPainel.IdDoUsuario) {
            return $( this ).parents("li").hide();
          } else {
            return $( this ).parents("li").show();
          }
        });
      };
    })(this));
    $("#acoes-ambos", "#acoes-tabela-container").unbind("click").bind("click", (function(_this) {
      return function(evento) {
        $("label", "#acoes-tabela-container").removeClass("btn-warning");
        $(evento.delegateTarget).addClass("btn-warning");
        return $("li", "#acoes-tabela-container").show();
      };
    })(this));
    return $("#acoes-sob-minha-responsabilidade", "#acoes-tabela-container").unbind("click").bind("click", (function(_this) {
      return function(evento) {
        $("label", "#acoes-tabela-container").removeClass("btn-warning");
        $(evento.delegateTarget).addClass("btn-warning");
        return $("a[data-idusuario]", "#acoes-tabela-container").each(function() {
          if ($( this ).data("idusuario") === window.FiltroPainel.IdDoUsuario) {
            return $( this ).parents("li").show();
          } else {
            return $( this ).parents("li").hide();
          }
        });
      };
    })(this));
  };

  painelBaseController.prototype.loadCondicionantes = function() {
    $('#condicionantes-grafico-container, #condicionantes-tabela-container').html(this.ajaxLoader);
    return $as.Onegreen.AtividadesDaLicenca.CondicionantesPeloResponsavel.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#condicionantes-tabela-container").html($(data).filter("#tabela-condicionantes"));
        $("[rel=tooltip]").tooltip();
        $("[rel=popover]").popover({
          placement: "top"
        });
        $("[id^=Percentual].btn-warning").prevAll().addClass("btn-warning");
        return setTimeout(function() {
          Atividades.api.boot();
          return _this.configurarFiltroDeCondicionantes();
        }, 500);
      };
    })(this));
  };

  painelBaseController.prototype.configurarFiltroDeCondicionantes = function() {
    $("#condicionantes-que-designei", "#condicionantes-tabela-container").unbind("click").bind("click", (function(_this) {
      return function(evento) {
        $("label", "#condicionantes-tabela-container").removeClass("btn-warning");
        $(evento.delegateTarget).addClass("btn-warning");
        return $("a[data-idusuario]", "#condicionantes-tabela-container").each(function() {
          if ($( this ).data("idusuario") === window.FiltroPainel.IdDoUsuario) {
            return $( this ).parents("li").hide();
          } else {
            return $( this ).parents("li").show();
          }
        });
      };
    })(this));
    $("#condicionantes-ambos", "#condicionantes-tabela-container").unbind("click").bind("click", (function(_this) {
      return function(evento) {
        $("label", "#condicionantes-tabela-container").removeClass("btn-warning");
        $(evento.delegateTarget).addClass("btn-warning");
        return $("li", "#condicionantes-tabela-container").show();
      };
    })(this));
    return $("#condicionantes-sob-minha-responsabilidade", "#condicionantes-tabela-container").unbind("click").bind("click", (function(_this) {
      return function(evento) {
        $("label", "#condicionantes-tabela-container").removeClass("btn-warning");
        $(evento.delegateTarget).addClass("btn-warning");
        return $("a[data-idusuario]", "#condicionantes-tabela-container").each(function() {
          if ($( this ).data("idusuario") === window.FiltroPainel.IdDoUsuario) {
            return $( this ).parents("li").show();
          } else {
            return $( this ).parents("li").hide();
          }
        });
      };
    })(this));
  };

  painelBaseController.prototype.marcarPercentualDeConclusaoToggle = function(element) {
    var $percentualAtual;
    $percentualAtual = $(element);
    $percentualAtual.nextAll($('#PercentualDeConclusaoToggle')).removeClass("btn-warning");
    $percentualAtual.prevAll($('#PercentualDeConclusaoToggle')).addClass("btn-warning");
    return $percentualAtual.addClass("btn-warning");
  };

  painelBaseController.prototype.configurarExibicaoDoBox = function(event) {
    var conteudo, divPai, elemento, grafico;
    elemento = $(event.delegateTarget);
    conteudo = elemento.nextAll(".js-conteudo-box-meu-painel");
    grafico = elemento.nextAll(".js-grafico-box-meu-painel");
    divPai = $(elemento).parent("div");
    if (elemento.data("aberto")) {
      elemento.attr("title", this.recursos.Exibir);
      elemento.attr("data-original-title", this.recursos.Exibir);
      elemento.addClass("fa-rotate-90");
      elemento.addClass("mostrar");
      divPai.addClass("mostrar-hover");
      conteudo.hide();
      grafico.hide();
      return elemento.data("aberto", false);
    } else {
      elemento.data("aberto", true);
      elemento.attr("title", this.recursos.Fechar);
      elemento.attr("data-original-title", this.recursos.Fechar);
      elemento.removeClass("fa-rotate-90");
      elemento.removeClass("mostrar");
      divPai.removeClass("mostrar-hover");
      if (!elemento.data("carregado")) {
        elemento.data("carregado", true);
        eval(elemento.data("funcao"));
      }
      conteudo.show();
      return grafico.show();
    }
  };

  painelBaseController.prototype.atualizarBoxesAbertos = function() {
    return $(".js-toggle-box-meu-painel").each(function() {
      if ($(this).data("aberto")) {
        return eval($(this).data("funcao"));
      } else {
        return $(this).data("carregado", false);
      }
    });
  };

  return painelBaseController;

})();
