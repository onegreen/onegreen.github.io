﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.Atividades || (this.Atividades = {});

Atividades.StatusDeConclusaoDoPlanoDeAcaoController = (function() {
  function StatusDeConclusaoDoPlanoDeAcaoController(container, idPlanoDeAcao) {
    this.container = container;
    this.idPlanoDeAcao = idPlanoDeAcao;
    this.reload = bind(this.reload, this);
    $(this.container).data("controller", this);
  }

  StatusDeConclusaoDoPlanoDeAcaoController.prototype.reload = function() {
    return $as.Atividades.PlanosDeAcao.StatusDeConclusaoDoPlanoDeAcao.get({
      idPlanoDeAcao: this.idPlanoDeAcao
    }).done((function(_this) {
      return function(data) {
        return $(_this.container).html(data);
      };
    })(this));
  };

  return StatusDeConclusaoDoPlanoDeAcaoController;

})();
