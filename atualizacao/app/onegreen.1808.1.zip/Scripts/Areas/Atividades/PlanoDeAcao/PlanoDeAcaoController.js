﻿var base,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.Atividades || (this.Atividades = {});

(base = this.Atividades).PlanoDeAcao || (base.PlanoDeAcao = {});

Atividades.PlanoDeAcao.PlanoDeAcaoController = (function() {
  PlanoDeAcaoController.prototype.id = 0;

  PlanoDeAcaoController.prototype.$view = null;

  PlanoDeAcaoController.prototype.tableContainer = null;

  function PlanoDeAcaoController(view, cadastroSimplificado, urlComboResponsavel) {
    this.view = view;
    if (cadastroSimplificado == null) {
      cadastroSimplificado = false;
    }
    this.urlComboResponsavel = urlComboResponsavel;
    this.configurarTransferenciaDeResponsabilidade = bind(this.configurarTransferenciaDeResponsabilidade, this);
    this.configurarReprogramacao = bind(this.configurarReprogramacao, this);
    this.setDatePickerBy = bind(this.setDatePickerBy, this);
    this.setDatePicker = bind(this.setDatePicker, this);
    this.tratarParametros = bind(this.tratarParametros, this);
    this.salvarAtividadeSimplificado = bind(this.salvarAtividadeSimplificado, this);
    this.configurarCadastroSimplificado = bind(this.configurarCadastroSimplificado, this);
    this.toggleBotaoFiltro = bind(this.toggleBotaoFiltro, this);
    this.filtrarComEnter = bind(this.filtrarComEnter, this);
    this.filtrarPorPeriodo = bind(this.filtrarPorPeriodo, this);
    this.configurarMarcacaoDoFiltro = bind(this.configurarMarcacaoDoFiltro, this);
    this.filtrarPorStatus = bind(this.filtrarPorStatus, this);
    this.atualizarCascata = bind(this.atualizarCascata, this);
    this.reloadFiltroDeStatus = bind(this.reloadFiltroDeStatus, this);
    this.reload = bind(this.reload, this);
    this.configurarClickDeLinkNaTabela = bind(this.configurarClickDeLinkNaTabela, this);
    this.configurarBind = bind(this.configurarBind, this);
    this.$view = $(this.view);
    this.id = this.$view.data("id");
    this.$view.data("controller", this);
    this.cadastroSimplificado = cadastroSimplificado;
    this.filtroStatus = ['EmExecucao', 'Atrasada', 'Planejada', 'Concluida', 'ConcluidaComAtraso'];
    this.configurarBind(this.view);
  }

  PlanoDeAcaoController.prototype.configurarBind = function(contexto) {
    this.usuario = 0;
    $("[rel=tooltip]", this.view).tooltip();
    this.statusControl = "#status-atividades-" + this.id;
    this.statusFiltroControl = $("#container-filtro-status-" + this.id).on("click", "[data-status]", this.filtrarPorStatus);
    this.exibirTodosStatusControl = $("#container-filtro-status-" + this.id).on("click", ".exibir-todas", this.filtrarPorStatus);
    this.searchInput = $("#filtrar-plano-acao-" + this.id, "#filtro-" + this.id).keypress(this.filtrarComEnter);
    this.statusInput = $("#status-" + this.id, contexto);
    this.periodoInput = $("#FimPrevisto-" + this.id, contexto);
    this.periodoControl = $("a", "[data-periodo-id = 'Periodo-" + this.id + "']").click(this.filtrarPorPeriodo);
    this.transferirResponsabilidade = $("#btn-transferir-responsabilidade-" + this.id).click(this.configurarTransferenciaDeResponsabilidade);
    this.filtrarControl = $("#filtrar-atividades-" + this.id, "#filtro-" + this.id).click(this.reload);
    this.exibirExcluidasControl = $("#exibir-excluidas-atividades-" + this.id, contexto).click(this.toggleBotaoFiltro);
    this.tableContainer = $("[data-atividades-table-container]", contexto);
    this.reprogramarControl = $("#btn-reprogramar-atividade-" + this.id, contexto).on("click", this.configurarReprogramacao);
    this.btnTipoUsuario = $("#BotaoTipoUsuario", this.view).click(this.marcarOpcaoUsuarioDoSistema);
    this.btnTipoTerceiro = $("#BotaoTipoTerceiro", this.view).click(this.marcarOpcaoUsuarioTerceiro);
    this.configurarCadastroSimplificado();
    return this.configurarClickDeLinkNaTabela();
  };

  PlanoDeAcaoController.prototype.configurarClickDeLinkNaTabela = function() {
    return $(this.view).on("click", ".plano-acao tr[data-toggle-display] a:not(.excluir, .usuario)", (function(_this) {
      return function(evt) {
        var container, url;
        evt.preventDefault();
        evt.stopPropagation();
        url = $(evt.currentTarget).attr('href');
        container = $(evt.currentTarget).attr('data-ajax-update');
        return $.ajax({
          url: url,
          type: 'GET',
          success: function(data) {
            return $(container).html(data);
          }
        });
      };
    })(this));
  };

  PlanoDeAcaoController.prototype.reload = function() {
    var contexto, ordenar;
    contexto = "filtroAdicao-" + this.id;
    ordenar = $(".ordenar", "#container-plano-acao" + this.id).is(':visible');
    return $as.Atividades.Atividades.Filtrar.get({
      filtro: this.searchInput.val(),
      idPlanoAcao: this.id,
      exibirExcluidas: $("#status-desativada", $(this.statusControl, this.contexto)).hasClass("js-MarcadoDesativada"),
      status: this.filtroStatus,
      periodo: this.periodoInput.val(),
      listarSomenteCriticas: $("#status-critica", $(this.statusControl, this.contexto)).hasClass("js-MarcadoCritica"),
      listarSomenteMilestones: $("#status-milestone", $(this.statusControl, this.contexto)).hasClass("js-MarcadoMilestone"),
      listarPrincipais: $("#status-principais", $(this.statusControl, this.contexto)).hasClass("js-MarcadoPrincipais")
    }).done((function(_this) {
      return function(data) {
        _this.tableContainer.html(data);
        _this.atualizarCascata();
        _this.transferirResponsabilidade.addClass('none');
        _this.reloadFiltroDeStatus();
        if (ordenar) {
          _this.manterOrdenacao(_this.id);
        }
        $("[rel=tooltip]", _this.view).tooltip();
      };
    })(this));
  };

  PlanoDeAcaoController.prototype.manterOrdenacao = function(idDoPlanoDeAcao) {
    return $(".ordenar", "#container-plano-acao" + idDoPlanoDeAcao).toggle();
  };

  PlanoDeAcaoController.prototype.reloadFiltroDeStatus = function() {
    var contexto;
    contexto = "filtroAdicao-" + this.id;
    return $as.Atividades.PlanosDeAcao.DefinirFiltroDeStatusDasAtividades.get({
      idDoPlanoDeAcao: this.id,
      statusSelecionados: this.filtroStatus,
      listarCriticas: $("#status-critica", $(this.statusControl, this.contexto)).hasClass("js-MarcadoCritica"),
      listarMilestones: $("#status-milestone", $(this.statusControl, this.contexto)).hasClass("js-MarcadoMilestone"),
      listarDesativadas: $("#status-desativada", $(this.statusControl, this.contexto)).hasClass("js-MarcadoDesativada"),
      listarPrincipais: $("#status-principais", $(this.statusControl, this.contexto)).hasClass("js-MarcadoPrincipais")
    }).done((function(_this) {
      return function(data) {
        $("#container-filtro-status-" + _this.id).html(data);
      };
    })(this));
  };

  PlanoDeAcaoController.prototype.atualizarCascata = function() {
    var elemento, elementosParaRecarregar, j, len, parentCascade, recarregar, results;
    parentCascade = $("[data-atividade-cascade]", this.$view);
    if (parentCascade.length) {
      elementosParaRecarregar = $(parentCascade.data("atividade-cascade"));
      recarregar = (function(_this) {
        return function(el) {
          if (el.data("controller")) {
            el.data("controller").reload();
          }
          if (el.data("cascade-function")) {
            return eval(el.data("cascade-function"));
          }
        };
      })(this);
      results = [];
      for (j = 0, len = elementosParaRecarregar.length; j < len; j++) {
        elemento = elementosParaRecarregar[j];
        results.push(recarregar($(elemento)));
      }
      return results;
    }
  };

  PlanoDeAcaoController.prototype.filtrarPorStatus = function(event) {
    event.preventDefault();
    this.configurarMarcacaoDoFiltro(event);
    return this.reload();
  };

  PlanoDeAcaoController.prototype.configurarMarcacaoDoFiltro = function(event) {
    var atrasadas, contexto, elemento, elementosMarcados, filtro, noPrazo, qtdElementosMarcados, status;
    elemento = $(event.currentTarget, $(this.statusControl, this.contexto));
    status = elemento.data("status");
    contexto = elemento.parent();
    elementosMarcados = (function(_this) {
      return function() {
        return $(".js-Marcado", $(_this.statusControl, _this.contexto));
      };
    })(this);
    qtdElementosMarcados = elementosMarcados().length;
    this.filtroStatus = [];
    filtro = this.filtroStatus;
    elementosMarcados().each(function() {
      return filtro.push($(this).attr('data-status'));
    });
    atrasadas = $('[data-status=Atrasadas]', this.contexto);
    noPrazo = $('[data-status=NoPrazo]', this.contexto);
    if (status && status !== 'Critica' && status !== 'Milestone' && status !== 'Desativada' && status !== 'Atrasadas' && status !== 'NoPrazo' && status !== 'Principais') {
      if (elemento.hasClass('js-Marcado')) {
        filtro.remove(elemento.data('status'));
      } else {
        filtro.push(elemento.data('status'));
      }
    } else if (status && status === 'Critica') {
      elemento.toggleClass('js-MarcadoCritica');
    } else if (status && status === 'Milestone') {
      elemento.toggleClass('js-MarcadoMilestone');
    } else if (status && status === 'Desativada') {
      elemento.toggleClass('js-MarcadoDesativada');
    } else if (status && status === 'Principais') {
      elemento.toggleClass('js-MarcadoPrincipais');
    } else if (status && status === 'Atrasadas') {
      elemento.toggleClass('js-MarcadoAtrasadas');
    } else if (status && status === 'NoPrazo') {
      elemento.toggleClass('js-MarcadoNoPrazo');
    } else {
      filtro = [];
    }
    if ($('[data-status=Atrasadas]', contexto).hasClass('js-MarcadoAtrasadas')) {
      filtro.push('Atrasadas');
    }
    if ($('[data-status=NoPrazo]', contexto).hasClass('js-MarcadoNoPrazo')) {
      filtro.push('NoPrazo');
    }
    return this.filtroStatus = filtro;
  };

  PlanoDeAcaoController.prototype.filtrarPorPeriodo = function(event) {
    var botao, recurso;
    event.preventDefault();
    botao = $(event.delegateTarget);
    recurso = resourceJsonCommom.FimPrevisto + ": " + (botao.text());
    this.periodoInput.val(botao.data("periodo"));
    $("#descricao-previsto-" + this.id, this.view).text(recurso);
    return this.reload();
  };

  PlanoDeAcaoController.prototype.filtrarComEnter = function(event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      return this.reload();
    }
  };

  PlanoDeAcaoController.prototype.toggleBotaoFiltro = function(event) {
    $(event.delegateTarget).toggleClass('btn-primary').toggleClass('active');
    return this.reload();
  };

  PlanoDeAcaoController.prototype.configurarCadastroSimplificado = function() {
    var inputsTarefaSimplificada;
    inputsTarefaSimplificada = $(".js-TarefaSimples input", this.view);
    inputsTarefaSimplificada.focus((function(_this) {
      return function() {
        $(".js-informacoesComplementaresNovaTarefa", _this.view).fadeIn();
      };
    })(this));
    inputsTarefaSimplificada.blur((function(_this) {
      return function() {
        return setTimeout(function() {
          var i, input, j, manterCampos, ref;
          manterCampos = false;
          for (i = j = 0, ref = inputsTarefaSimplificada.length - 1; j <= ref; i = j += 1) {
            input = $(inputsTarefaSimplificada[i]);
            manterCampos = manterCampos || (input.is(":focus") || input.val().length > 0) && input.attr("type") !== "hidden";
          }
          if (!manterCampos) {
            return $(".js-informacoesComplementaresNovaTarefa", _this.view).fadeOut();
          }
        }, 200);
      };
    })(this));
  };

  PlanoDeAcaoController.prototype.salvarAtividadeSimplificado = function(elemento) {
    var contexto, inputs, pai, parametros, valido;
    pai = $(elemento).parent().parent();
    valido = true;
    inputs = $("input", this.view);
    contexto = $(".js-objeto", this.view).val();
    if ($("#BotaoTipoUsuario").hasClass("btn-warning") && $("input[id ^= NomeDoResponsavelDaTarefa]", this.view).val() === "") {
      valido = false;
      $("input[id ^= NomeDoResponsavelDaTarefa]", this.view).parent().addClass('error');
    } else if ($("#BotaoTipoTerceiro").hasClass("btn-warning") && $("#NomeResponsavelTerceiro", this.view).val() === "" && $("#EmailResponsavelTerceiro", this.view).val() === "") {
      valido = false;
      $("#NomeResponsavelTerceiro", this.view).parent().addClass('error');
      $("#EmailResponsavelTerceiro", this.view).parent().addClass('error');
    } else if ($("#BotaoTipoTerceiro").hasClass("btn-warning") && $("#NomeResponsavelTerceiro", this.view).val() === "") {
      valido = false;
      $("#NomeResponsavelTerceiro", this.view).parent().addClass('error');
    } else if ($("#BotaoTipoTerceiro").hasClass("btn-warning") && $("#EmailResponsavelTerceiro", this.view).val() === "") {
      valido = false;
      $("#EmailResponsavelTerceiro", this.view).parent().addClass('error');
    }
    if ($("#FimPrevistoNovaTarefa", this.view).val() === "") {
      valido = false;
      $("#FimPrevistoNovaTarefa", this.view).parent().addClass('error');
    }
    if ($(".js-DescricaoTarefaSimples", this.view).val() === "") {
      valido = false;
      $(".js-DescricaoTarefaSimples", this.view).parent().addClass('error');
    }
    if (valido) {
      parametros = inputs.serialize();
      parametros = this.tratarParametros(parametros);
      $as.Atividades.Atividades.CreateEditAtividade.post(parametros).done((function(_this) {
        return function(data) {
          if (data.temErros) {
            adicionarErroPorNomeDoInput(data.erros, _this.view);
          } else {
            removerErroPorNomeDoInput(inputs);
            $(".js-DescricaoTarefaSimples", _this.view).val('');
            _this.reload();
            $(".js-DescricaoTarefaSimples", _this.view).focus();
          }
        };
      })(this));
    }
  };

  PlanoDeAcaoController.prototype.tratarParametros = function(parametros) {
    return parametros;
  };

  PlanoDeAcaoController.prototype.setDatePicker = function(propertyName) {
    return this.setDatePickerBy("#" + propertyName);
  };

  PlanoDeAcaoController.prototype.setDatePickerBy = function(selector) {
    var contexto;
    contexto = "filtroAdicao-" + this.id;
    return $(selector, this.contexto).datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      autoclose: true
    });
  };

  PlanoDeAcaoController.prototype.configurarReprogramacao = function(evento) {
    var atividades, idsDasAtividades;
    atividades = $("tr[data-atividade].selecionado", this.$view);
    idsDasAtividades = [];
    atividades.each((function(_this) {
      return function(index) {
        return idsDasAtividades.push($(atividades[index]).attr("data-atividade"));
      };
    })(this));
    return $as.Atividades.Atividades.Reprogramar.get({
      idsDasAtividades: idsDasAtividades,
      recarregarAtividade: false
    }).done((function(_this) {
      return function(data) {
        return $("#box-reprogramar-atividade").html(data);
      };
    })(this));
  };

  PlanoDeAcaoController.prototype.configurarTransferenciaDeResponsabilidade = function(evento) {
    var atividades, idsDasAtividades;
    atividades = $("tr[data-atividade].selecionado", this.$view);
    idsDasAtividades = [];
    atividades.each((function(_this) {
      return function(index) {
        return idsDasAtividades.push($(atividades[index]).attr("data-atividade"));
      };
    })(this));
    return $as.Atividades.PlanosDeAcao.TransferirResponsabilidadePorAtividade.get({
      idsDasAtividades: idsDasAtividades,
      idDoPlanoDeAcao: this.id
    }).done((function(_this) {
      return function(data) {
        return $("#main-modal").html(data);
      };
    })(this));
  };

  PlanoDeAcaoController.prototype.inserirResponsavelTerceiro = function(idDoPlanoDeAcao, containerID, campoNome, campoEmail) {
    var contexto;
    contexto = $("[id=adicaoSimplificada-" + idDoPlanoDeAcao + "][data-container-id=" + containerID + "]");
    return $as.Atividades.PlanosDeAcao.InserirResponsavelTerceiro.get({
      idDoPlanoDeAcao: idDoPlanoDeAcao,
      ideObj: containerID,
      nome: $(campoNome, contexto).val(),
      email: $(campoEmail, contexto).val()
    }).success((function(_this) {
      return function(data) {
        return $("#main-modal").html(data);
      };
    })(this));
  };

  PlanoDeAcaoController.prototype.excluirResponsavelTerceiro = function(idDoPlanoDeAcao, containerID) {
    var contexto;
    contexto = $("[id=adicaoSimplificada-" + idDoPlanoDeAcao + "][data-container-id=" + containerID + "]");
    $('#NomeResponsavelTerceiro', contexto).val('');
    $('#EmailResponsavelTerceiro', contexto).val('');
    $('#divUsuarioTerceiro', contexto).hide();
    return $('#divUsuario', contexto).show();
  };

  PlanoDeAcaoController.prototype.salvarResponsavelTerceiro = function(idDoPlanoDeAcao, containerID, nome, email) {
    var contexto, tooltipUsuario;
    if (email === null) {
      email = '';
    }
    contexto = $("[id=adicaoSimplificada-" + idDoPlanoDeAcao + "][data-container-id=" + containerID + "]");
    $('#NomeResponsavelTerceiro', contexto).val(nome);
    $('#EmailResponsavelTerceiro', contexto).val(email);
    $('#divUsuario', contexto).hide();
    $('#labelUsuarioTerceiro', contexto).text(nome);
    $('#divUsuarioTerceiro', contexto).show();
    tooltipUsuario = nome + "  " + email;
    $('#divUsuarioTerceiro #labelUsuarioTerceiro', contexto).attr('data-original-title', tooltipUsuario);
    return $("[rel='tooltip']").tooltip();
  };

  PlanoDeAcaoController.prototype.adicionarAtividade = function(elemento) {
    var id;
    id = elemento.data('id');
    $("#adicaoSimplificada-" + id).toggle('fast');
    return $("#filtro-" + id).hide();
  };

  return PlanoDeAcaoController;

})();
