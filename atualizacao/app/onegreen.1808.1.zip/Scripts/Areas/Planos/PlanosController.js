﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.planosController = (function(superClass) {
  extend(planosController, superClass);

  function planosController(view, options) {
    this.view = view;
    this.options = options;
    this.irParaAreas = bind(this.irParaAreas, this);
    this.irParaUsuarios = bind(this.irParaUsuarios, this);
    this.avisoDeReenvioDeEmail = bind(this.avisoDeReenvioDeEmail, this);
    this.adicionarUsuario = bind(this.adicionarUsuario, this);
    this.SalvarEdicao = bind(this.SalvarEdicao, this);
    this.cancelarEdicao = bind(this.cancelarEdicao, this);
    this.editarUg = bind(this.editarUg, this);
    this.adicionarUnidade = bind(this.adicionarUnidade, this);
    this.atualizarValorTotal = bind(this.atualizarValorTotal, this);
    this.calcularValores = bind(this.calcularValores, this);
    this.postFormPlano = bind(this.postFormPlano, this);
    this.bindActionsLinksDosPlanos = bind(this.bindActionsLinksDosPlanos, this);
    this.bindCalculoValor = bind(this.bindCalculoValor, this);
    planosController.__super__.constructor.call(this, this.view, null);
    $(document).scrollTop(0);
    $('[alt=integer_2]').setMask();
    this.bindCalculoValor();
    this.bindActionsLinksDosPlanos();
    $('.lista-vantagens').find('li').each(function() {
      var $el, $span, text;
      $el = $(this);
      if ($el.data('del')) {
        $span = $el.find('span');
        text = $span.text();
        $span.text('');
        $span.html("<del>" + text + "</del>");
        return $el.find('i').removeClass('fa-check').addClass('fa-times');
      }
    });
  }

  planosController.prototype.bindCalculoValor = function() {
    return $('.js-quantidade-usuarios').keyup((function(_this) {
      return function(e) {
        return _this.calcularValores($(e.currentTarget));
      };
    })(this));
  };

  planosController.prototype.bindActionsLinksDosPlanos = function() {
    return $('.js-link-post').click((function(_this) {
      return function(e) {
        var $a;
        $a = $(e.currentTarget);
        return _this.postFormPlano($a);
      };
    })(this));
  };

  planosController.prototype.postFormPlano = function($a) {
    $('#formPlano').attr('action', $a.data('action'));
    $('#idDoPlano').val($a.data('id-do-plano'));
    $('#formaDeContratacao').val($a.data('forma-de-contratacao'));
    $('#nomeDoPlano').val($a.data('nome-do-plano'));
    return $('#formPlano').submit();
  };

  planosController.prototype.calcularValores = function($element) {
    var $content_plano, quantidade, valor, valorFormatado;
    $content_plano = $element.parents('.js-item-plano');
    valor = window.parseFloatCulture($content_plano.find('.js-preco-plano').text());
    quantidade = parseInt($content_plano.find('.js-quantidade-usuarios').val());
    if (isNaN(quantidade)) {
      quantidade = 0;
    }
    valorFormatado = window.formatNumberCulture(valor * quantidade, 2);
    $content_plano.find('.js-valor-total-plano').text(valorFormatado);
    this.atualizarValorTotal();
    return $('#btnContratar').show();
  };

  planosController.prototype.atualizarValorTotal = function() {
    var valorFormatado, valorTotal;
    valorTotal = 0;
    $('.js-valor-total-plano').each(function() {
      return valorTotal += parseFloatCulture($(this).text());
    });
    valorFormatado = window.formatNumberCulture(valorTotal, 2);
    return $('.js-valor-total-planos').text(valorFormatado);
  };

  planosController.prototype.adicionarUnidade = function() {
    return $as.Planos.Planos.SalvarUG.post({
      Sigla: (this.get('#SiglaUnidade')).val(),
      Nome: (this.get('#NomeUnidade')).val()
    }).done((function(_this) {
      return function(data) {
        var txtNomeUnidade, txtSiglaUnidade;
        if (data.success) {
          return $as.Planos.Planos.ListagemUgs.get().done(function(html) {
            $('#unidades-container').html(html);
            return $('#vincular-ug-' + data.data.id).click();
          });
        } else {
          $('#add-area-container').html(data);
          txtSiglaUnidade = _this.get('#SiglaUnidade');
          txtNomeUnidade = _this.get('#NomeUnidade');
          if (txtSiglaUnidade.val() === '') {
            txtSiglaUnidade.addClass('inputError');
          }
          if (txtNomeUnidade.val() === '') {
            return txtNomeUnidade.addClass('inputError');
          }
        }
      };
    })(this));
  };

  planosController.prototype.editarUg = function(id) {
    var txtNomeUnidade, txtSiglaUnidade;
    $('#edit-ug-' + id).show();
    $('#display-ug-' + id).hide();
    txtSiglaUnidade = $('.sigla', '#ug-' + id);
    txtNomeUnidade = $('.nome', '#ug-' + id);
    txtSiglaUnidade.val($('#display-ug-sigla-' + id, '#display-ug-' + id).text().trim());
    txtNomeUnidade.val($('#display-ug-nome-' + id, '#display-ug-' + id).text().trim());
    return txtSiglaUnidade.focus();
  };

  planosController.prototype.cancelarEdicao = function(id) {
    $('#edit-ug-' + id).hide();
    $('#display-ug-' + id).show();
    return $('#valida-add-area').hide();
  };

  planosController.prototype.SalvarEdicao = function(id) {
    var txtNomeUnidade, txtSiglaUnidade;
    txtSiglaUnidade = $('.sigla', '#ug-' + id);
    txtNomeUnidade = $('.nome', '#ug-' + id);
    return $as.Planos.Planos.SalvarEdicaoUG.post({
      id: id,
      sigla: txtSiglaUnidade.val(),
      nome: txtNomeUnidade.val()
    }).done(function(data) {
      if (data.success) {
        $('#display-ug-sigla-' + id, '#display-ug-' + id).text(txtSiglaUnidade.val());
        $('#display-ug-nome-' + id, '#display-ug-' + id).text(txtNomeUnidade.val());
        $('#edit-ug-' + id).hide();
        $('#display-ug-' + id).show();
        return $('#valida-add-area').hide();
      } else if (data.error) {
        $('#msg-erro-area').text(data.message);
        $('#valida-add-area').show();
        txtSiglaUnidade.addClass('inputError');
        if (txtNomeUnidade.val() === '') {
          return txtNomeUnidade.addClass('inputError');
        } else {
          return txtNomeUnidade.removeClass('inputError');
        }
      }
    });
  };

  planosController.prototype.adicionarUsuario = function() {
    return $as.Planos.Planos.SalvarUsuario.post({
      Email: (this.get('#EmailDoUsuario')).val(),
      Nome: (this.get('#NomeDoUsuario')).val()
    }).done((function(_this) {
      return function(data) {
        var txtEmail, txtNome;
        if (data.success) {
          return $as.Planos.Planos.ListagemUsuarios.get().done(function(html) {
            return $('#usuarios-container').html(html);
          });
        } else {
          $('#add-usuario-container').html(data);
          txtNome = _this.get('#NomeDoUsuario');
          txtEmail = _this.get('#EmailDoUsuario');
          if (txtEmail.val() === '') {
            txtEmail.addClass('inputError');
          }
          if (txtNome.val() === '') {
            return txtNome.addClass('inputError');
          }
        }
      };
    })(this));
  };

  planosController.prototype.reloadUsuarios = function() {
    return $as.Planos.Planos.ListagemUsuarios.get().done(function(html) {
      return $('#usuarios-container').html(html);
    });
  };

  planosController.prototype.selecionarPlano = function(elemento) {
    $('#planos-container div').removeClass('planos-box-destaque');
    $(elemento).addClass('planos-box-destaque');
    $('div.plano-container').hide();
    return $('#descricao-plano-' + $(elemento).attr('idDoPlano')).show();
  };

  planosController.prototype.salvarNomeDaEmpresa = function() {
    return $('#formEmpresa').submit();
  };

  planosController.prototype.avisoDeReenvioDeEmail = function(msg) {
    return showBottomNoty(msg, 4000, null);
  };

  planosController.prototype.irParaUsuarios = function(msg) {
    var $txtemail;
    $txtemail = $('#EmailDoUsuario');
    if ($txtemail.length) {
      return $txtemail.focus();
    } else {
      return showBottomNoty(msg, 4000, null);
    }
  };

  planosController.prototype.irParaAreas = function(msg) {
    var $txtsigla;
    $txtsigla = $('#SiglaUnidade', this.view);
    if ($txtsigla.length) {
      return $txtsigla.focus();
    } else {
      return showBottomNoty(msg, 4000, null);
    }
  };

  return planosController;

})(window.baseController);
