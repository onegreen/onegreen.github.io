﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.filtroPainelController = (function() {
  function filtroPainelController(options, func) {
    this.options = options;
    this.aplicarFiltro = bind(this.aplicarFiltro, this);
    this.configurarAplicarFiltro = bind(this.configurarAplicarFiltro, this);
    this.carregaComboOrigem = bind(this.carregaComboOrigem, this);
    this.carregaComboUnidadeGerencial = bind(this.carregaComboUnidadeGerencial, this);
    this.defineFiltros = bind(this.defineFiltros, this);
    this.defineFiltros(func);
  }

  filtroPainelController.prototype.defineFiltros = function(func) {
    var filtroFarol;
    filtroFarol = window.FiltroFarolDeProjeto;
    if (filtroFarol === void 0) {
      $.ajax({
        url: this.options.UrlFiltroDefault,
        async: false,
        success: function(filtro) {
          return window.FiltroFarolDeProjeto = {
            IdUnidadeGerencial: filtro.IdUnidadeGerencial,
            UnidadeGerencialNome: filtro.UnidadeGerencialNome,
            IdOrigem: filtro.IdOrigem,
            OrigemNome: filtro.OrigemNome,
            Descricao: filtro.Descricao,
            Coluna: filtro.ColunaOrdenacao,
            Ordem: filtro.TipoOrdenacao,
            IncluirSubordinadas: filtro.IncluirSubordinadas,
            ExibirCancelados: filtro.ExibirCancelados,
            StatusDoProjeto: filtro.StatusDoProjeto,
            StatusAtividade: filtro.StatusAtividade
          };
        }
      });
    }
    this.carregaComboUnidadeGerencial();
    this.carregaComboOrigem();
    this.configurarAplicarFiltro();
    return func();
  };

  filtroPainelController.prototype.carregaComboUnidadeGerencial = function() {
    $("#IdUnidadeGerencial").val(window.FiltroFarolDeProjeto.IdUnidadeGerencial);
    $("#UnidadeGerencialNome").val(window.FiltroFarolDeProjeto.UnidadeGerencialNome);
    return $("#UnidadeGerencialNome").autocompleter(this.options.UrlComboUnidadeGerencial, {
      loadOnDemand: false,
      elementToClick: "#UnidadeGerencialNomeBtn",
      keyElement: "#IdUnidadeGerencial",
      onSelected: (function(_this) {
        return function(valueInput) {
          window.FiltroFarolDeProjeto.IdUnidadeGerencial = $(valueInput).val();
          return window.FiltroFarolDeProjeto.UnidadeGerencialNome = $('#UnidadeGerencialNome').val();
        };
      })(this),
      defaultOption: this.options.ComboUnidadeGerencialDefault
    });
  };

  filtroPainelController.prototype.carregaComboOrigem = function() {
    $("#IdOrigem").val(window.FiltroFarolDeProjeto.IdOrigem);
    $("#OrigemNome").val(window.FiltroFarolDeProjeto.OrigemNome);
    return $("#OrigemNome").autocompleter(this.options.UrlComboOrigem, {
      loadOnDemand: false,
      elementToClick: "#OrigemNomeBtn",
      keyElement: "#IdOrigem",
      onSelected: (function(_this) {
        return function(valueInput) {
          window.FiltroFarolDeProjeto.IdOrigem = $(valueInput).val();
          return window.FiltroFarolDeProjeto.OrigemNome = $('#OrigemNome').val();
        };
      })(this),
      defaultOption: this.options.ComboOrigemDefault
    });
  };

  filtroPainelController.prototype.configurarAplicarFiltro = function() {
    return $("#AplicarFiltro").click(this.aplicarFiltro);
  };

  filtroPainelController.prototype.aplicarFiltro = function(event) {
    $as.EPM.Projetos.SalvarFiltro.post(window.FiltroFarolDeProjeto);
    if (this.options.aplicarFiltro) {
      return this.options.aplicarFiltro(event);
    }
  };

  return filtroPainelController;

})();
