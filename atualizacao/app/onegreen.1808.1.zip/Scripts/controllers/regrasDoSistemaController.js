﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.regrasDoSistemaController = (function() {
  regrasDoSistemaController.currentModulo = "";

  function regrasDoSistemaController(options, contexto) {
    this.options = options;
    this.contexto = contexto;
    this.permitirNegarAcessoATodosOsMenusPorGrupoDeUsuario = bind(this.permitirNegarAcessoATodosOsMenusPorGrupoDeUsuario, this);
    this.alterarAcessoDoGrupoDeUsuarioAoMenu = bind(this.alterarAcessoDoGrupoDeUsuarioAoMenu, this);
    this.onLoadIndexPorModulo = bind(this.onLoadIndexPorModulo, this);
    this.exibirOcultarSubordinadas = bind(this.exibirOcultarSubordinadas, this);
    this.exibirSubordinadas = bind(this.exibirSubordinadas, this);
    this.ocultarSubordinadas = bind(this.ocultarSubordinadas, this);
    this.permitirNegarEmTodasAsUnidades = bind(this.permitirNegarEmTodasAsUnidades, this);
    this.vincularUnidadeGerencial = bind(this.vincularUnidadeGerencial, this);
    this.desvincularUnidadesSelecionadas = bind(this.desvincularUnidadesSelecionadas, this);
    this.loadComboGrupoDeUsuarios = bind(this.loadComboGrupoDeUsuarios, this);
    this.loadComboUsuarios = bind(this.loadComboUsuarios, this);
    this.aoSelecionarComboDeUsuarioOuGrupoDeUsuario = bind(this.aoSelecionarComboDeUsuarioOuGrupoDeUsuario, this);
    this.preencheComboDeUsuarios = bind(this.preencheComboDeUsuarios, this);
    this.preencheComboDeGrupos = bind(this.preencheComboDeGrupos, this);
    this.excluirUnidadesSelecionadas = bind(this.excluirUnidadesSelecionadas, this);
    this.alterarRegraGeralDoGrupoDeUsuario = bind(this.alterarRegraGeralDoGrupoDeUsuario, this);
    this.alterarRegraGeralDoUsuario = bind(this.alterarRegraGeralDoUsuario, this);
    this.alterarRegraDoGrupoDeUsuario = bind(this.alterarRegraDoGrupoDeUsuario, this);
    this.alterarRegraDoUsuario = bind(this.alterarRegraDoUsuario, this);
    this.alterarModulo = bind(this.alterarModulo, this);
    this.definirAbaParaRecarregar = bind(this.definirAbaParaRecarregar, this);
    this.configuraSelecaoDeTipo = bind(this.configuraSelecaoDeTipo, this);
    this.carregarRegraPorGrupo = bind(this.carregarRegraPorGrupo, this);
    this.carregarRegraPorUsuario = bind(this.carregarRegraPorUsuario, this);
    this.carregarManutencao = bind(this.carregarManutencao, this);
    this.carregarRegras = bind(this.carregarRegras, this);
    this.configurarExibicaoDosBotoes = bind(this.configurarExibicaoDosBotoes, this);
    this.loadComboUsuarios();
    this.loadComboGrupoDeUsuarios();
    this.configuraSelecaoDeTipo();
    this.preencheComboDeGrupos();
    this.configurarExibicaoDosBotoes();
    this.definirAbaParaRecarregar();
    $("a[data-moduloId]").click(this.alterarModulo);
    $("#btnVincularUnidades").click(this.vincularUnidadeGerencial);
    $("#btnDesvincularUnidades").click(this.excluirUnidadesSelecionadas);
  }

  regrasDoSistemaController.prototype.configurarExibicaoDosBotoes = function() {
    if ($("#BotaoTipoUsuario").hasClass("btn-warning")) {
      $("#tabManutencao").hide();
      $("#divComboGrupoDoUsuario").hide();
      $("#divComboUsuario").show();
    } else if ($("#BotaoTipoGrupo").hasClass("btn-warning")) {
      $("#tabManutencao").show();
      $("#divComboUsuario").hide();
      $("#divComboGrupoDoUsuario").show();
    }
    $("#btnVincularUnidades").hide();
    $("#btnDesvincularUnidades").hide();
    return $("#divBtnUG").hide();
  };

  regrasDoSistemaController.prototype.carregarRegras = function(idDoUsuario, idDoGrupoDeUsuario, idDoModulo, idDaUnidadeSuperior) {
    return $as.RegrasDoSistema.IndexPorModulo.get({
      idDoUsuario: idDoUsuario,
      idDoGrupoDeUsuario: idDoGrupoDeUsuario,
      idDoModulo: idDoModulo,
      idDaUnidadeSuperior: idDaUnidadeSuperior
    }).success((function(_this) {
      return function(data) {
        $("#regrasPorModulo").html(data);
        return $("i[data-idunidade]").click(_this.exibirOcultarSubordinadas);
      };
    })(this));
  };

  regrasDoSistemaController.prototype.carregarManutencao = function() {
    return $as.RegrasDoSistema.Manutencao.get({
      idDoGrupoDeUsuario: $("#IdDoGrupoDoUsuario").val()
    }).success((function(_this) {
      return function(data) {
        return $("#regrasPorModulo").html(data);
      };
    })(this));
  };

  regrasDoSistemaController.prototype.carregarRegraPorUsuario = function() {
    return $as.RegrasDoSistema.RegrasGerais.get({
      idDoUsuario: $("#IdDoUsuario").val()
    }).success((function(_this) {
      return function(data) {
        return $("#regrasPorModulo").html(data);
      };
    })(this));
  };

  regrasDoSistemaController.prototype.carregarRegraPorGrupo = function() {
    return $as.RegrasDoSistema.RegrasGerais.get({
      idDoGrupoDeUsuario: $("#IdDoGrupoDoUsuario").val()
    }).success((function(_this) {
      return function(data) {
        return $("#regrasPorModulo").html(data);
      };
    })(this));
  };

  regrasDoSistemaController.prototype.configuraSelecaoDeTipo = function() {
    var $botaoGrupoDeUsuario, $botaoUsuario, $comboDeGrupoDeUsuario, $comboDeUsuario, $manutencao;
    $botaoUsuario = $("#BotaoTipoUsuario");
    $botaoGrupoDeUsuario = $("#BotaoTipoGrupo");
    $manutencao = $("#tabManutencao");
    $comboDeGrupoDeUsuario = $("#divComboGrupoDoUsuario");
    $comboDeUsuario = $("#divComboUsuario");
    $botaoUsuario.on("click", (function(_this) {
      return function() {
        if ($("#GrupoDoUsuarioNome").val().trim() === "") {
          _this.preencheComboDeGrupos();
          return setTimeout(function() {
            return _this.definirAbaParaRecarregar();
          }, 200);
        } else {
          $botaoGrupoDeUsuario.removeClass("btn-warning");
          $botaoUsuario.addClass("btn-warning");
          $manutencao.hide();
          $comboDeGrupoDeUsuario.hide();
          $comboDeUsuario.show();
          return _this.definirAbaParaRecarregar();
        }
      };
    })(this));
    return $botaoGrupoDeUsuario.on("click", (function(_this) {
      return function() {
        if ($("#UsuarioNome").val().trim() === "") {
          _this.preencheComboDeUsuarios();
          return setTimeout(function() {
            return _this.definirAbaParaRecarregar();
          }, 200);
        } else {
          $botaoUsuario.removeClass("btn-warning");
          $botaoGrupoDeUsuario.addClass("btn-warning");
          $comboDeUsuario.hide();
          $comboDeGrupoDeUsuario.show();
          $manutencao.show();
          return _this.definirAbaParaRecarregar();
        }
      };
    })(this));
  };

  regrasDoSistemaController.prototype.definirAbaParaRecarregar = function(tipoDoModulo) {
    var eGrupoDeUsuario, eManutencao, eRegrasGerais, ref, ref1;
    if (!tipoDoModulo) {
      tipoDoModulo = $("#tabModulos .active a").attr("data-tipomodulo");
    }
    eManutencao = (ref = tipoDoModulo === "manutencao") != null ? ref : {
      "true": false
    };
    eRegrasGerais = (ref1 = tipoDoModulo === "regrasGerais") != null ? ref1 : {
      "true": false
    };
    eGrupoDeUsuario = $("#BotaoTipoGrupo").hasClass("btn-warning");
    if (eManutencao && eGrupoDeUsuario) {
      return this.carregarManutencao();
    } else if (eRegrasGerais) {
      if (eGrupoDeUsuario) {
        return this.carregarRegraPorGrupo();
      } else {
        return this.carregarRegraPorUsuario();
      }
    } else {
      if (eGrupoDeUsuario) {
        return this.carregarRegras(null, $("#IdDoGrupoDoUsuario").val(), regrasDoSistemaController.currentModulo);
      } else {
        if (regrasDoSistemaController.currentModulo === "") {
          return this.carregarRegraPorUsuario();
        } else {
          return this.carregarRegras($("#IdDoUsuario").val(), null, regrasDoSistemaController.currentModulo);
        }
      }
    }
  };

  regrasDoSistemaController.prototype.alterarModulo = function(event) {
    var elemento;
    elemento = $(event.target);
    regrasDoSistemaController.currentModulo = elemento.attr("data-moduloId");
    this.definirAbaParaRecarregar(elemento.attr("data-tipomodulo"));
    if (regrasDoSistemaController.currentModulo === "") {
      $("#btnVincularUnidades").hide();
      $("#btnDesvincularUnidades").hide();
      return $("#divBtnUG").hide();
    } else {
      $("#btnVincularUnidades").show();
      return $("#divBtnUG").show();
    }
  };

  regrasDoSistemaController.prototype.alterarRegraDoUsuario = function(element, evento, idDaRegra, idDaUnidade) {
    evento.cancelBubble = true;
    return $as.RegrasDoSistema.AlterarRegraDoUsuario.get({
      idDaRegra: idDaRegra,
      idDoUsuario: $("#IdDoUsuario").val(),
      idDaUnidade: idDaUnidade
    }).success((function(_this) {
      return function() {
        return _this.definirAbaParaRecarregar();
      };
    })(this));
  };

  regrasDoSistemaController.prototype.alterarRegraDoGrupoDeUsuario = function(element, evento, idDaRegra, idDaUnidade) {
    evento.cancelBubble = true;
    return $as.RegrasDoSistema.AlterarRegraGrupoDeUsuario.get({
      idDaRegra: idDaRegra,
      idDoGrupoDeUsuario: $("#IdDoGrupoDoUsuario").val(),
      idDaUnidade: idDaUnidade
    }).success((function(_this) {
      return function() {
        return _this.definirAbaParaRecarregar();
      };
    })(this));
  };

  regrasDoSistemaController.prototype.alterarRegraGeralDoUsuario = function(idDaRegra, idDoUsuario) {
    return $as.RegrasDoSistema.AlterarRegraGeralDoUsuario.get({
      idDaRegra: idDaRegra,
      idDoUsuario: idDoUsuario
    }).success(function(data) {
      return $("#regrasPorModulo").html(data);
    });
  };

  regrasDoSistemaController.prototype.alterarRegraGeralDoGrupoDeUsuario = function(idDaRegra, idDoGrupoDeUsuario) {
    return $as.RegrasDoSistema.AlterarRegraGeralDoGrupoDeUsuario.get({
      idDaRegra: idDaRegra,
      idDoGrupoDeUsuario: idDoGrupoDeUsuario
    }).success(function(data) {
      return $("#regrasPorModulo").html(data);
    });
  };

  regrasDoSistemaController.prototype.excluirUnidadesSelecionadas = function(event) {
    return window.modalConfirm($(event.target).attr("data-ajax-confirm"), this.desvincularUnidadesSelecionadas);
  };

  regrasDoSistemaController.prototype.preencheComboDeGrupos = function() {
    return $as.API.GruposDeUsuario.RetornarCombo.get().success(function(data) {
      if ($("#GrupoDoUsuarioNome").val() === "") {
        $("#IdDoGrupoDoUsuario").val(data[0].Key);
        return $("#GrupoDoUsuarioNome").val(data[0].Value);
      }
    });
  };

  regrasDoSistemaController.prototype.preencheComboDeUsuarios = function() {
    return $as.API.Usuarios.RetornarComboAtivos.get().success(function(data) {
      if ($("#UsuarioNome").val() === "") {
        $("#IdDoUsuario").val(data[0].Key);
        return $("#UsuarioNome").val(data[0].Value);
      }
    });
  };

  regrasDoSistemaController.prototype.aoSelecionarComboDeUsuarioOuGrupoDeUsuario = function() {
    return this.definirAbaParaRecarregar();
  };

  regrasDoSistemaController.prototype.loadComboUsuarios = function() {
    return setCombo(this.contexto, "#UsuarioNome", this.aoSelecionarComboDeUsuarioOuGrupoDeUsuario);
  };

  regrasDoSistemaController.prototype.loadComboGrupoDeUsuarios = function() {
    return setCombo(this.contexto, "#GrupoDoUsuarioNome", this.aoSelecionarComboDeUsuarioOuGrupoDeUsuario);
  };

  regrasDoSistemaController.prototype.desvincularUnidadesSelecionadas = function() {
    var idDoGrupo, idDoUsuario;
    if ($("#BotaoTipoUsuario").hasClass("btn-warning")) {
      idDoUsuario = $("#IdDoUsuario", "#contextoDasRegras").val();
    } else if ($("#BotaoTipoGrupo").hasClass("btn-warning")) {
      idDoGrupo = $("#IdDoGrupoDoUsuario", "#contextoDasRegras").val();
    }
    return $.ajax({
      type: "POST",
      url: this.options.urlDesvincularUnidadesSelecionadas + $('[name=ids]', '.linhaUnidade.selecionado').serialize(),
      data: {
        idDoUsuario: idDoUsuario,
        idDoGrupoDeUsuario: idDoGrupo,
        idDoModulo: regrasDoSistemaController.currentModulo
      },
      success: function(html) {
        return $("#regrasPorModulo").html(html);
      }
    });
  };

  regrasDoSistemaController.prototype.vincularUnidadeGerencial = function() {
    return $as.RegrasDoSistema.VincularUnidadeGerencial.get().success(function(data) {
      return $("#modalVincularUnidadeGerencial").html(data);
    });
  };

  regrasDoSistemaController.prototype.permitirNegarEmTodasAsUnidades = function(idDaRegra, idDoModulo, permissao, idDoUsuario, idDoGrrupoDeUsuario, idDaUnidadeSuperior) {
    return $as.RegrasDoSistema.PermitirNegarEmTodasAsUnidades.get({
      idDaRegra: idDaRegra,
      idDoModulo: idDoModulo,
      permissao: permissao,
      idDoUsuario: idDoUsuario,
      idDoGrupoDeUsuario: idDoGrrupoDeUsuario,
      idDaUnidadeSuperior: idDaUnidadeSuperior
    }).success(function(data) {
      return $("#regrasPorModulo").html(data);
    });
  };

  regrasDoSistemaController.prototype.realcarRegra = function() {
    return $(".realcaRegra").on("mouseover", function(e) {
      var idDaRegra;
      idDaRegra = $(this).attr("forregra");
      return $("#regra-" + idDaRegra).css("background-color", "#EEE");
    }).on("mouseout", function(e) {
      var idDaRegra;
      idDaRegra = $(this).attr("forregra");
      return $("#regra-" + idDaRegra).css("background-color", "");
    });
  };

  regrasDoSistemaController.prototype.ocultarSubordinadas = function(elemento, idDaUnidade) {
    if (idDaUnidade !== void 0) {
      $("[data-pai='" + idDaUnidade + "']").each((function(_this) {
        return function(i, e) {
          var idUnidade;
          $(e).addClass('none');
          idUnidade = $(e).data('idunidade');
          return _this.ocultarSubordinadas($(e), idUnidade);
        };
      })(this));
      return elemento.find('i').removeClass("fa-minus-square").addClass("fa-plus-square");
    }
  };

  regrasDoSistemaController.prototype.exibirSubordinadas = function(elemento, idDaUnidade) {
    idDaUnidade = elemento.data('idunidade');
    $("[data-pai='" + idDaUnidade + "']").removeClass('none');
    return elemento.removeClass("fa-plus-square").addClass("fa-minus-square");
  };

  regrasDoSistemaController.prototype.exibirOcultarSubordinadas = function(event) {
    var elemento, idDaUnidade;
    elemento = $(event.target);
    idDaUnidade = elemento.data('idunidade');
    if (elemento.hasClass("fa-plus-square")) {
      this.exibirSubordinadas(elemento, idDaUnidade);
    } else {
      this.ocultarSubordinadas(elemento.parent().parent(), idDaUnidade);
    }
    return event.cancelBubble = true;
  };

  regrasDoSistemaController.prototype.setToolTip = function() {
    return $('.seta-botao').tooltip();
  };

  regrasDoSistemaController.prototype.onLoadIndexPorModulo = function() {
    this.realcarRegra();
    this.setToolTip();
    $("#btnDesvincularUnidades").hide();
    $("#btnVincularUnidades").show();
    $("#divBtnUG").show();
    return $(".linhaUnidade:not(.cabecalho)").click(function() {
      $(this).toggleClass("selecionado");
      $(this).parent().toggleClass("selecionado");
      if ($(".selecionado").length > 0) {
        $("#btnDesvincularUnidades").show();
        $("#btnVincularUnidades").hide();
      } else {
        $("#btnDesvincularUnidades").hide();
        $("#btnVincularUnidades").show();
      }
      return $("#divBtnUG").show();
    });
  };

  regrasDoSistemaController.prototype.alterarAcessoDoGrupoDeUsuarioAoMenu = function(idDoMenuDoSistema, idDoGrupoDeUsuario) {
    return $as.RegrasDoSistema.AlterarAcessoDoGrupoDeUsuarioAoMenu.get({
      idDoMenuDoSistema: idDoMenuDoSistema,
      idDoGrupoDeUsuario: idDoGrupoDeUsuario
    }).success(function(data) {
      return $("#regrasPorModulo").html(data);
    });
  };

  regrasDoSistemaController.prototype.permitirNegarAcessoATodosOsMenusPorGrupoDeUsuario = function(permitirAcesso) {
    return $as.RegrasDoSistema.PermitirNegarAcessoATodosOsMenusPorGrupoDeUsuario.get({
      idDoGrupoDeUsuario: $("#IdDoGrupoDoUsuario").val(),
      permitirAcesso: permitirAcesso
    }).success(function(data) {
      return $("#regrasPorModulo").html(data);
    });
  };

  return regrasDoSistemaController;

})();
