﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.selecaoPlanoAcaoController = (function() {
  function selecaoPlanoAcaoController(options) {
    this.options = options;
    this.adicionarTarefa = bind(this.adicionarTarefa, this);
    this.carregarComboPlanoDeAcao = bind(this.carregarComboPlanoDeAcao, this);
  }

  selecaoPlanoAcaoController.prototype.carregarComboPlanoDeAcao = function() {
    var funcao;
    funcao = (function(_this) {
      return function() {
        _this.adicionarTarefa($('#PlanoDeAcao_Id').val(), _this.options.idObjeto, _this.options.tipoObjeto, _this.options.causaAtividade);
        return $('#close-modal-selecionarplanodeacao').click();
      };
    })(this);
    return setCombo(this.options.contexto, "#PlanoDeAcao_Nome", funcao);
  };

  selecaoPlanoAcaoController.prototype.adicionarTarefa = function(idPlanoDeAcao, idDoObjeto, tipoDoObjeto, causaAtividade) {
    return $as.Atividades.Atividades.CreatePorObjetoOque.post({
      idPlanoAcao: idPlanoDeAcao,
      idObjeto: idDoObjeto,
      tipoObjeto: tipoDoObjeto,
      causa: causaAtividade
    }).success((function(_this) {
      return function(data) {
        window.GetDiv('create-atividade-container').html(data.data.html);
        if (!$('#collapse-' + data.data.idDaFerramenta).is(':visible')) {
          return $('#anchor-fer-' + data.data.idDaFerramenta).click();
        }
      };
    })(this));
  };

  return selecaoPlanoAcaoController;

})();
