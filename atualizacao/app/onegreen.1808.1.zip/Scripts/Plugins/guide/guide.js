(function ( $ ) {
    $('body').on('click', '[data-help]', function () {
        if ($('.guideMask').length == 0) {

            var $elTrigger = $(this);
            
            if ($elTrigger.attr('data-help') != '') {
                $as.Guide.GetSteps.get({ tela: $elTrigger.data('help') });
            } else {
                var $defaultGuide = $('[dataguide]');

                if ($defaultGuide.length) {
                    $as.Guide.GetSteps.get({ tela: $defaultGuide.attr('dataguide') });
                }
            }
        }
    });

    var generalOptions = null; 
    var guide = function() {
        var container,
            defaults = {
                margin: 10,
                exitOnEsc : true
            },
            topMask = $("<div/>").addClass("guideMask"),
            bottomMask = $("<div/>").addClass("guideMask"),
            leftMask = $("<div/>").addClass("guideMask"),
            rightMask = $("<div/>").addClass("guideMask"),
            bubble = $("<div/>").addClass("guideBubble"),
            holdingSteps,
            steps,
            position,
            prevButton = $("<button/>").addClass("btn btn-mini");
            nextButton = $("<button/>").addClass("btn btn-mini btn-warning");
            arrow = $("<div/>").addClass("guideBubble-arrow").addClass("top"),

            gotoStep = function(i) {
                positionMask(i);
                positionBubble(i);
                scrollIntoView();
            },
            onKeyDown = function (e) {
                if (e.keyCode === 27 && generalOptions.exitOnEsc == true) {
                    //escape key pressed, exit the intro
                    clearGuide();
                } else if (e.keyCode === 37) {
                    //left arrow
                    prevStep();
                } else if (e.keyCode === 39 || e.keyCode === 13) {
                    //right arrow or enter
                    nextStep();
                    //prevent default behaviour on hitting Enter, to prevent steps being skipped in some browsers
                    if (e.preventDefault) {
                        e.preventDefault();
                    } else {
                        e.returnValue = false;
                    }
                }
            },
            nextStep = function() {
                position++;
                if (position>=steps.length) {
                    clearGuide();
                } else {
                    gotoStep(position);
                }
            },
            prevStep = function() {
                var newposition = position - 1;
                if (newposition < 0) {
                    //position = steps.length - 1;
                    return;
                }

                position = newposition;
                gotoStep(position);
            },
            getElementAttrs = function(element) {
                return {
                    top: element.offset().top,
                    left: element.offset().left,
                    width: element.outerWidth(),
                    height: element.outerHeight()
                }
            },
            positionMask = function(i) {

                $('body').css('overflow', 'hidden');

                var element = steps[i].element,
                    margin = (steps[i].options && steps[i].options.margin) ? steps[i].options.margin : generalOptions.margin,
                    attrs = getElementAttrs(element),
                    top = attrs.top,
                    left = attrs.left,
                    width = attrs.width,
                    height = attrs.height;

                topMask.css({
                    height: (top - margin) + "px",
                    overflow : 'hidden'
                });
                 
                bottomMask.css({
                    top: (height + top + margin) + "px",
                    height: ($(document).height() - height - top - margin) + "px",
                    overflow : 'hidden'
                });
                 
                leftMask.css({
                    width: (left - margin) + "px",
                    top: (top - margin) + "px",
                    height: (height + margin*2) + "px",
                    overflow : 'hidden'
                });
                 
                rightMask.css({
                    left: (left + width + margin) + "px",
                    top: (top - margin) + "px",
                    height: (height + margin*2) + "px",
                    width: ($(document).width() - width - left - margin) + "px",
                    overflow : 'hidden'
                });
                
            },
            setArrow = function(position){
                $(".guideBubble-arrow", bubble)
                        .css({"right": ""})
                        .css({"left": ""})
                        .removeClass('top')
                        .removeClass('bottom')
                        .removeClass('left')
                        .removeClass('right')
                        .addClass(position);
            },
            positionBubble = function(i) {
                bubble.fadeOut(250);

                $(".step", bubble).html(i + 1);
                $(".intro", bubble).html(steps[i].intro);

                var element = steps[i].element,
                    margin = (steps[i].options && steps[i].options.margin) ? steps[i].options.margin : generalOptions.margin,
                    top = element.offset().top,
                    left = element.offset().left,
                    width = element.outerWidth(),
                    height = element.outerHeight();

                var css = {
                    top: (height + top + margin + 10) + "px"
                };

                var placement = 'bottom';

                if(steps[i].options.placement)
                    placement = steps[i].options.placement;

                if(placement == 'bottom'){
                    setArrow('top');
                    if ((left + bubble.outerWidth()) > $(document).width()) {
                        $(".guideBubble-arrow", bubble).css({"right": "10px"});
                        css.left = left + element.outerWidth() - bubble.outerWidth() + margin;
                    } else {
                        $(".guideBubble-arrow", bubble).css({"right": "auto", "left" : "30px"});
                        css.left = left - margin;
                    }

                }else if(placement == 'right'){
                    setArrow('left');
                    css = {
                        top: top + "px",
                        left : (left + width + margin + 10) + 'px'
                    };
                }
                else if (placement == 'top') {
                    setArrow('bottom');
                    css = {
                        top: top - bubble.height() - margin - 30 + "px"
                    };
                }

                bubble.animate(css, 0, function() {
                    if (steps[i].options.callback) {
                        steps[i].options.callback();
                    }
                }).fadeIn(300);
 
                prevButton.removeClass("disabled");
                nextButton.removeClass("disabled");

                if (!position) {
                    prevButton.addClass("disabled");
                }
                
                if (position==(steps.length-1)) {
                    nextButton.text(generalOptions.closeText).addClass("btn-danger").removeClass("btn-warning");
                } else {
                    nextButton.text(generalOptions.nextText).removeClass("btn-danger").addClass("btn-warning");
                }
                
            },
            scrollIntoView = function() {
                if($.browser.msie)
                    return;

                var element = steps[position].element;

                $('html, body').scrollTop(element.offset().top - options.offsetTop);

                /*if(!_elementInViewport(element[0])){
                    $('html, body').scrollTop(element.offset().top - 200);
                }*/
            },
            clearGuide = function () {
                $('body').css('overflow', 'auto');
                bubble.detach();
                topMask.add(bottomMask).add(leftMask).add(rightMask).animate({
                    opacity: 0
                }, 500, function () {
                    topMask.add(bottomMask).add(leftMask).add(rightMask).detach();
                })

                //clean listeners
                if (window.removeEventListener) {
                    window.removeEventListener('keydown', onKeyDown, true);
                } else if (document.detachEvent) { //IE
                    document.detachEvent('onkeydown', onKeyDown);
                }
                bindUnbindClearGuid();
            },
            bindUnbindClearGuid = function () {
                $('.remove-guide').unbind('click', closeGuid);
                $('.remove-guide').removeClass('remove-guide');
            },
            closeGuid =function () {
                clearGuide();
            },
            getMaximumZIndex = function() {
                var max = 0;   
                $("*").each(function() {
                    var current = parseInt($(this).css("zIndex"), 10);
                    if(current > max) {
                        max = current;
                    }
                });
                return max;
            }
       
 
        return {
            init: function(opts) {
                container = $(this);
                options = $.extend({}, defaults, opts);
                generalOptions = options;
                steps = [];
                holdingSteps = [];
                position = -1;
                zIndex = getMaximumZIndex();
                offsetTop = 200;

                if (opts && options.offsetTop)
                    offsetTop = options.offsetTop;
   
                topMask.add(bottomMask).add(leftMask).add(rightMask).css("z-index", zIndex + 1);
                bubble.css("z-index", zIndex + 2).html("")
                    .append(arrow)
                    .append($("<div/>").addClass("step").html("1"))
                    .append($("<div/>").addClass("intro"))
                    .append($("<hr/>").addClass("no-margin"))
                    .append($("<div/>").addClass("btn-group mtm pull-right")
                    .append(prevButton)
                    .append(nextButton));

                prevButton.on("click", function(event) {
                    if (!$(this).hasClass("disabled")) {
                        prevStep();
                        event.preventDefault();
                        return false;
                    }
                }).text(options.prevText);

                nextButton.on("click", function(event) {
                    if (!$(this).hasClass("disabled")) {
                        nextStep();
                        event.preventDefault();
                        return false;
                    }
                }).text(options.nextText);


                var next = function(event) {
                    if (!$(this).hasClass("disabled")) {
                        nextStep();
                        event.preventDefault();
                        return false;
                    }
                };

                topMask.add(bottomMask).add(leftMask).add(rightMask).on("click", function() {
                    clearGuide();
                });

                return {
                    addStep: function(selector, introduction, options) {
                        holdingSteps.push({
                            selector: selector,
                            intro: introduction,
                            options: options || {}
                        });
                        var tiposDeElementos = ['a', 'input', 'button', 'i'];
                        for (var i = 0; i < tiposDeElementos.length; i++) {
                            if ($(selector).find(tiposDeElementos[i]).length > 0) {
                                $(selector).find(tiposDeElementos[i]).each(function (i, e) {
                                    if ($(e).data('help') == undefined) {
                                        $(e).bind('click', closeGuid);
                                        $(e).addClass('remove-guide');
                                    }
                                });
                            } else if ($(selector).is(tiposDeElementos[i])) {
                                $(selector).bind('click', closeGuid);
                                $(selector).addClass('remove-guide');
                            }
                        }
                    },
                    resetStep: function(){
                        holdingSteps = [];
                        steps = [];
                    },
                    defineOffsetTop: function (offsetTop) {
                        options.offsetTop = offsetTop
                    },
                    start: function () {
                        container.append(topMask, bottomMask, leftMask, rightMask);
                        container.append(bubble);

                        if (window.addEventListener) {
                            window.addEventListener('keydown', onKeyDown, true);
                        } else if (document.attachEvent) { //IE
                            document.attachEvent('onkeydown', onKeyDown);
                        }

                        topMask.add(bottomMask).add(leftMask).add(rightMask).animate({
                            opacity: 0.5
                        }, 500);
                        position = -1;
                        steps = [];
                        $.each(holdingSteps, function(i, step) {
                            if ($(step.selector).length) {
                                var attrs = getElementAttrs($(step.selector));
                                if (attrs.width!=0 && attrs.height!=0) {
                                    steps.push({
                                        element: $(step.selector),
                                        selector: step.selector,
                                        intro: step.intro,
                                        options: step.options
                                    });
                                }
                            }
                        });
                        
                        nextStep();
                    }
                }
            },
             
        }
    }();
 
    $.fn.extend({
        guide: guide.init
    });
}( jQuery ));


/**
    * Add overlay layer to the page
    * http://stackoverflow.com/questions/123999/how-to-tell-if-a-dom-element-is-visible-in-the-current-viewport
    *
    * @api private
    * @method _elementInViewport
    * @param {Object} el
    */
    function _elementInViewport(el) {
        var rect = el.getBoundingClientRect();

        return (
          rect.top >= 0 &&
          rect.left >= 0 &&
          (rect.bottom + 80) <= window.innerHeight && // add 80 to get the text right
          rect.right <= window.innerWidth
        );
    }
