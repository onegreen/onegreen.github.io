$(document).ready(function() {
	$("#mainMenu a.enableLink").click(function() {
			var url = $(this).attr("href");
			if ($(this).attr('target')!='_blank')
				window.location.href = url;
		});
});