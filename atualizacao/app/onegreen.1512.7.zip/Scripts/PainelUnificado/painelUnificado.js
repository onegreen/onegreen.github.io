﻿var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.painelUnificado = window.painelUnificado = (function() {
  function painelUnificado(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.abrirNotificacao = __bind(this.abrirNotificacao, this);
    this.carregarAbaSelecionada = __bind(this.carregarAbaSelecionada, this);
    this.salvarAbaSelecionada = __bind(this.salvarAbaSelecionada, this);
    this.carregarDesempenho = __bind(this.carregarDesempenho, this);
    this.carregarRadar = __bind(this.carregarRadar, this);
    this.carregarAgenda = __bind(this.carregarAgenda, this);
    this.carregarPopoverProgramaDeResultado = __bind(this.carregarPopoverProgramaDeResultado, this);
    this.recarregarPainel = __bind(this.recarregarPainel, this);
    this.aoAprovarReprogramacao = __bind(this.aoAprovarReprogramacao, this);
    this.recarregarReprogramacoesPendentesDeAprovacao = __bind(this.recarregarReprogramacoesPendentesDeAprovacao, this);
    this.carregarPopoverReprogramacoesSolicitadas = __bind(this.carregarPopoverReprogramacoesSolicitadas, this);
    this.carregarPopoverSolucoes = __bind(this.carregarPopoverSolucoes, this);
    this.carregarCorpo = __bind(this.carregarCorpo, this);
    this.carregarPainel = __bind(this.carregarPainel, this);
    this.aoSelecionarData = __bind(this.aoSelecionarData, this);
    this.VerificarAvancoDoFluxoMedianteExecucaoDaAcao = __bind(this.VerificarAvancoDoFluxoMedianteExecucaoDaAcao, this);
    this.load = __bind(this.load, this);
    this.irParaODiaDeHoje = $("#irParaODiaDeHoje");
    this.load();
    this.carregarAbaSelecionada(this.options.abaSelecionada);
  }

  painelUnificado.prototype.load = function() {
    this.btnCarregarAgenda = $("#carregar-Agenda");
    this.btnCarregarRadar = $("#carregar-Radar");
    this.btnCarregarDesempenho = $("#carregar-Desempenho");
    this.data = this.options.Data;
    this.calendario = new calendarioDoPainel($('#container-calendario'), {
      data: this.data,
      aoSelecionarData: this.aoSelecionarData
    });
    this.carregarCorpo();
    this.btnCarregarRadar.unbind("click").bind("click", (function(_this) {
      return function() {
        return _this.carregarRadar(false);
      };
    })(this));
    this.btnCarregarDesempenho.unbind("click").bind("click", (function(_this) {
      return function() {
        return _this.carregarDesempenho(false);
      };
    })(this));
    this.btnCarregarAgenda.unbind("click").bind("click", (function(_this) {
      return function() {
        return _this.carregarAgenda(false);
      };
    })(this));
    this.irParaODiaDeHoje.click((function(_this) {
      return function(e) {
        var $el, data;
        $el = $(e.currentTarget);
        data = $el.data("date");
        $('.dia-selecionado').removeClass('dia-selecionado');
        _this.aoSelecionarData(e, data);
        _this.calendario.scrollToHoje();
        $("td.calendar-hoje").addClass("dia-selecionado");
        return _this.carregarPopoverReprogramacoesSolicitadas();
      };
    })(this));
    if (this.options.abrirLinkDireto) {
      return this.abrirNotificacao(this.options.idDaNotificacao);
    }
  };

  painelUnificado.prototype.VerificarAvancoDoFluxoMedianteExecucaoDaAcao = function(event, element, idTarefa, idPlanoDeAcao) {
    return $as.PainelUnificado.AcaoPertenceAUmaSolucaoDeProblemas.post({
      idPlanoDeAcao: idPlanoDeAcao
    }).done((function(_this) {
      return function(resultado) {
        $('.js-base-tarefa').unbind("atualizar").bind('atualizar', _this.VerificarAvancoDoFluxoMedianteExecucaoDaAcao);
        if (resultado.data.verificarSolucao) {
          return $as.Melhorias.SolucoesDeProblemas.VerificarAvancoDoFluxoMedianteExecucaoDaAcao.post({
            idDaSolucao: resultado.data.id,
            idDaAtividade: idTarefa
          }).done(function(data) {
            var funcao;
            if (data.data.recarregar) {
              funcao = $('.js-estadoAtual', $("#info-solucao-" + resultado.data.id).parent()).data('cascade-function');
              eval(funcao);
              return showBottomNoty(data.data.mensagem);
            }
          });
        }
      };
    })(this));
  };

  painelUnificado.prototype.aoSelecionarData = function(event, data) {
    var done;
    done = (function(_this) {
      return function() {
        var mostrarPainel;
        mostrarPainel = $("#mostrarPainel a");
        if (!mostrarPainel.parent().hasClass('active')) {
          $('#painel').removeClass('active');
        }
        _this.carregarCorpo();
        mostrarPainel.click();
        swIntercom("Mudou de data no Meu Painel");
      };
    })(this);
    return this.carregarPainel(data, done);
  };

  painelUnificado.prototype.carregarPainel = function(data, done) {
    var container;
    container = $('#painel-container');
    this.data = data;
    return $as.PainelUnificado.CorpoPainel.get({
      data: data
    }).done(function(data) {
      var html;
      html = $(data).find("#painel-container");
      container.replaceWith(html);
      if (done) {
        return done();
      }
    });
  };

  painelUnificado.prototype.carregarCorpo = function() {
    var container;
    container = $('#corpo-painel');
    $('#popover').popover({
      trigger: 'hover',
      html: true
    });
    $('[rel=tooltip]').tooltip();
    $('.js-base-tarefa').unbind("atualizar").bind('atualizar', this.VerificarAvancoDoFluxoMedianteExecucaoDaAcao);
    this.carregarPopoverSolucoes();
    this.carregarPopoverReprogramacoesSolicitadas();
    this.carregarPopoverProgramaDeResultado();
    return Atividades.api.boot();
  };

  painelUnificado.prototype.carregarPopoverSolucoes = function() {
    return $('#corpo-painel').unbind('click').on("click", "i[data-solucao-painelunificado]", (function(_this) {
      return function(event) {
        var $el, evt, idDaSolucaoDeProblema, tag;
        $(".popover").remove();
        evt = event || window.event;
        tag = evt.target.tagName || evt.srcElement.tagName;
        if (tag === 'A') {
          return;
        }
        $el = $(evt.currentTarget);
        idDaSolucaoDeProblema = $el.data("solucao-painelunificado");
        return $as.Melhorias.SolucoesDeProblemas.DetalhesSolucaoDeProblema.get({
          idDaSolucaoDeProblema: idDaSolucaoDeProblema,
          exibicaoSimplificada: false
        }).success(function(data) {
          var $data, callPopover, content, title;
          $data = $(data);
          title = $data.find("#detalhes-solucaodeproblema-title").html();
          content = $data.find("#detalhes-solucaodeproblema-content").html();
          callPopover = function() {
            $el.popover({
              trigger: 'manual',
              html: true,
              title: title + '<span class="fr cursor-pointer" onclick="popover.close($(this))"><i class="fa fa-times fa-1"></i></span>',
              content: content,
              placement: 'bottom'
            });
            $el.popover('show');
          };
          setTimeout(callPopover, 200);
        });
      };
    })(this));
  };

  painelUnificado.prototype.carregarPopoverReprogramacoesSolicitadas = function() {
    return $("#main").on("click", "button[data-reprogramacao-solicitada]", (function(_this) {
      return function(event) {
        var $el, evt, idDaAtividade, tag;
        $(".popover").remove();
        evt = event || window.event;
        tag = evt.target.tagName || evt.srcElement.tagName;
        if (tag === 'A') {
          return;
        }
        $el = $(evt.currentTarget);
        idDaAtividade = $el.data("reprogramacao-solicitada");
        return $as.Atividades.Atividades.DetalhesDaReprogramacao.get({
          idDaAtividade: idDaAtividade
        }).success(function(data) {
          var $data, callPopover, content, title;
          $data = $(data);
          title = $data.find("#detalhes-atividade-title").html();
          content = $data.find("#detalhes-atividade-content").html();
          callPopover = function() {
            $el.popover({
              trigger: 'manual',
              html: true,
              title: title + '<span class="fr cursor-pointer" onclick="popover.close($(this))"><i class="fa fa-times fa-1"></i></span>',
              content: content,
              placement: 'left'
            });
            $el.popover('show');
          };
          setTimeout(callPopover, 200);
        });
      };
    })(this));
  };

  painelUnificado.prototype.recarregarReprogramacoesPendentesDeAprovacao = function() {
    return $as.PainelUnificado.RecarregarReprogramacoesPendentesDeAprovacao.get({
      idDoUsuario: this.options.IdDoUsuario
    }).success((function(_this) {
      return function(data) {
        return $("#reprogramacoesPendentesDeAprovacao").replaceWith(data);
      };
    })(this));
  };

  painelUnificado.prototype.aoAprovarReprogramacao = function(data) {
    Atividades.api.verificarExigenciaDeNotificacao(data.data.idDaAtividade);
    return this.recarregarReprogramacoesPendentesDeAprovacao();
  };

  painelUnificado.prototype.recarregarPainel = function() {
    this.carregarPainel($('.dia-selecionado').data('date'));
    if (!this.btnCarregarRadar.data("carregarradar")) {
      this.carregarRadar(true);
      return this.carregarDesempenho(true);
    }
  };

  painelUnificado.prototype.carregarPopoverProgramaDeResultado = function() {
    return $('#corpo-painel').on("click", "i[data-programa-de-resultado]", (function(_this) {
      return function(event) {
        var $el, evt, idDoProgramaDeResultadoPorUsuario, tag;
        $(".popover").remove();
        evt = event || window.event;
        tag = evt.target.tagName || evt.srcElement.tagName;
        if (tag === 'A') {
          return;
        }
        $el = $(evt.currentTarget);
        idDoProgramaDeResultadoPorUsuario = $el.data("programa-de-resultado");
        return $as.Performance.ProgramasDeResultadosPorUsuario.DetalhesDoPrograma.get({
          idDoProgramaDeResultadoPorUsuario: idDoProgramaDeResultadoPorUsuario
        }).success(function(data) {
          var $data, callPopover, content, title;
          $data = $(data);
          title = $data.find("#detalhes-programa-de-resultado-title").html();
          content = $data.find("#detalhes-programa-de-resultado-content").html();
          callPopover = function() {
            $el.popover({
              trigger: 'manual',
              html: true,
              title: title + '<span class="fr cursor-pointer" onclick="popover.close($(this))"><i class="fa fa-times fa-1"></i></span>',
              content: content,
              placement: 'top'
            });
            $el.popover('show');
          };
          setTimeout(callPopover, 200);
        });
      };
    })(this));
  };

  painelUnificado.prototype.carregarAgenda = function(forcar) {
    $('#containerPrincipal').attr('dataguide', 'meuPainel');
    window.guide.defineOffsetTop(400);
    return this.salvarAbaSelecionada("Agenda");
  };

  painelUnificado.prototype.carregarRadar = function(forcar) {
    $('#containerPrincipal').attr('dataguide', 'radar');
    window.guide.defineOffsetTop(200);
    popover.closeAll();
    this.salvarAbaSelecionada("Radar");
    if (this.btnCarregarRadar.data("carregar") || forcar) {
      $as.PainelUnificado.CarregarRadar.get().success((function(_this) {
        return function(data) {
          $("#radar").html(data).fadeIn().css("display", "");
          _this.carregarPopoverSolucoes();
          Atividades.api.boot();
          _this.carregarPopoverReprogramacoesSolicitadas();
          $('[rel=tooltip]', "#radar").tooltip();
          swIntercom("Abriu o Radar no Meu Painel");
        };
      })(this));
      this.btnCarregarRadar.data("carregar", false);
      return Atividades.api.boot();
    }
  };

  painelUnificado.prototype.carregarDesempenho = function(forcar) {
    $('#containerPrincipal').attr('dataguide', 'desempenho');
    window.guide.defineOffsetTop(350);
    popover.closeAll();
    if (!forcar) {
      this.salvarAbaSelecionada("Desempenho");
    }
    if (this.btnCarregarDesempenho.data("carregar") || forcar) {
      $as.PainelUnificado.CarregarDesempenho.get().success((function(_this) {
        return function(data) {
          $("#desempenho").html(data).fadeIn().css("display", "");
          swIntercom("Abriu o Desempenho no Meu Painel");
        };
      })(this));
      return this.btnCarregarDesempenho.data("carregar", false);
    }
  };

  painelUnificado.prototype.salvarAbaSelecionada = function(aba) {
    return $as.PainelUnificado.SalvarAbaSelecionada.post({
      aba: aba
    });
  };

  painelUnificado.prototype.carregarAbaSelecionada = function(aba) {
    switch (aba) {
      case "Desempenho":
        return this.carregarDesempenho(true);
      case "Radar":
        return this.carregarRadar(true);
    }
  };

  painelUnificado.prototype.abrirNotificacao = function(idDaNotificacao) {
    return $as.NotificacoesDoUsuario.NotificacoesExterna.ObterLinkDiretoDaNotificacao.get({
      idDaNotificacao: idDaNotificacao
    }).done((function(_this) {
      return function(link) {
        return $.ajax({
          url: link,
          success: function(data) {
            return Notificacoes.api.linkDiretoNotificao(data);
          }
        });
      };
    })(this));
  };

  return painelUnificado;

})();
