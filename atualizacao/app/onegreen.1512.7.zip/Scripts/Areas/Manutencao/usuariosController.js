﻿var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.usuariosController = (function() {
  function usuariosController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.aoAlterarChefe = __bind(this.aoAlterarChefe, this);
    this.ativarJCrop = __bind(this.ativarJCrop, this);
    this.configurarUpload = __bind(this.configurarUpload, this);
    this.AlterarSenha = __bind(this.AlterarSenha, this);
    this.AtivarDesativarUsuarioNovo = __bind(this.AtivarDesativarUsuarioNovo, this);
    this.AtivarDesativarUsuario = __bind(this.AtivarDesativarUsuario, this);
    this.DefinirIdade = __bind(this.DefinirIdade, this);
    this.DefinirBotaoExcluir = __bind(this.DefinirBotaoExcluir, this);
    this.alterarEstadoCivil = __bind(this.alterarEstadoCivil, this);
    setCombo(this.contexto, "#Cargo_NomeDoCargo");
    setCombo(this.contexto, "#UnidadeGerencial_SiglaAtual");
    setCombo(this.contexto, "#Chefe_NomeDoChefe");
    setCombo(this.contexto, "#FusoHorario_Nome");
    $("#DataDeAdmissaoBtn").closest('.form-input').after("<label id='labelDataDeAdmissao' class='mlm mrl mts'>" + this.options.DataDeAdmissaoAgeInExtensiveFormat + "</label>");
    $("#DataDeAdmissaoNaFuncaoBtn").closest('.form-input').after("<label id='labelDataDeAdmissaoNaFuncao' class='mlm mrl mts'>" + this.options.DataDeAdmissaoNaFuncaoAgeInExtensiveFormat + "</label>");
    $("#Cargo_NomeDoCargo").removeAttr("data-val-required");
    $("#Chefe_NomeDoChefe").removeAttr("data-val-required");
    $("input[alt]").setMask();
    this.opcoesEstadoCivil = $("#opcoesEstadoCivil a", this.contexto);
    this.opcoesEstadoCivil.click(this.alterarEstadoCivil);
    $("#DataDeAdmissao, #DataDeAdmissaoNaFuncao").change((function(_this) {
      return function() {
        return _this.DefinirIdade($(_this));
      };
    })(this));
    $('#DataDeNascimento').datepicker({
      yearRange: '-100:+0',
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      onSelect: (function(_this) {
        return function() {
          return $(_this).change();
        };
      })(this)
    });
    $("#DataDeAdmissaoNaFuncao").datepicker({
      yearRange: '-100:+0',
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      onSelect: (function(_this) {
        return function() {
          return $(_this).change();
        };
      })(this)
    });
    $('#aRedefinirSenha').click((function(_this) {
      return function() {
        return $.ajax({
          type: 'GET',
          url: _this.options.urlRedefinirSenha,
          success: function(html) {
            return $('#RedefinirSenha').html(html);
          }
        });
      };
    })(this));
    $('#DeleteFoto', this.contexto).click((function(_this) {
      return function() {
        return $.ajax({
          url: _this.options.urlDeleteFoto,
          data: {
            idDoUsuario: _this.options.referenciaUnica
          },
          success: function(data) {
            _this.recarregarFoto();
            $('#DeleteFoto').hide();
            return $('#separadorFoto').hide();
          }
        });
      };
    })(this));
    $('#btnFecharCreateEditUsuario', this.contexto).click((function(_this) {
      return function() {
        if (_this.options.idDoUsuario === '0') {
          $.ajax({
            url: _this.options.urlFecharCreateEditUsuario,
            data: {
              referenciaUnica: _this.options.referenciaUnica,
              somenteTemporaria: false
            }
          });
        }
        return window.Usuario.reload();
      };
    })(this));
    $("#Nome").focus();
    this.uploadFoto = $('#UploadFoto', this.contexto);
    this.inputFoto = $('#inputFoto');
    this.configurarUpload();
    AjaxTab.BindTabs(this.contexto);
    $('#container-usuario').find(':input').change((function(_this) {
      return function() {
        $('#btn-salvar').removeClass('btn-default');
        return $('#btn-salvar').addClass('btn-primary');
      };
    })(this));
    this.DefinirBotaoExcluir();
  }

  usuariosController.prototype.alterarEstadoCivil = function(evt) {
    var $elemento;
    $elemento = $(evt.currentTarget);
    $('#EstadoCivil', this.contexto).val($elemento.attr("option")).change();
    $('#labelEstadoCivil', this.contexto).text($elemento.text());
    return $('#labelEstadoCivil', this.contexto).append(' <span class="caret"></span>');
  };

  usuariosController.prototype.DefinirBotaoExcluir = function($el) {
    return $.post(this.options.urlPossuiFoto, {
      idDoUsuario: this.options.idDoUsuario
    }, (function(_this) {
      return function(data) {
        if (!data.success) {
          $('#DeleteFoto').hide();
          return $('#separadorFoto').hide();
        }
      };
    })(this));
  };

  usuariosController.prototype.DefinirIdade = function($el) {
    $.get(this.options.urlDefinirIdade, {
      data: $el.val()
    }, (function(_this) {
      return function(idade) {};
    })(this));
    return $('#label' + $el.attr('id')).text(idade);
  };

  usuariosController.prototype.AtivarDesativarUsuario = function(ativar) {
    return $.ajax({
      type: "GET",
      url: this.options.urlAtivarDesativarUsuario,
      data: {
        ativar: ativar,
        id: this.options.idDoUsuario
      },
      success: (function(_this) {
        return function(html) {
          return $("#main").html(html);
        };
      })(this)
    });
  };

  usuariosController.prototype.AtivarDesativarUsuarioNovo = function(ativar) {
    if (ativar) {
      $("#btnAtivarDesativarUsuarioNovo").removeClass("btn-warning");
      $("#btnAtivarDesativarUsuarioNovo").attr("onClick", "AtivarDesativarUsuarioNovo(false); return false");
      $("#btnAtivarDesativarUsuarioNovo").html(this.options.Resource.DesativarUsuario);
      return $("#Ativo").val("True");
    } else {
      $('#btnAtivarDesativarUsuarioNovo').addClass('btn-warning');
      $('#btnAtivarDesativarUsuarioNovo').attr('onClick', 'AtivarDesativarUsuarioNovo(true); return false');
      $('#btnAtivarDesativarUsuarioNovo').html(this.options.Resource.AtivarUsuario);
      return $('#Ativo').val('False');
    }
  };

  usuariosController.prototype.AlterarSenha = function(el) {
    return $.ajax({
      type: "GET",
      url: $(el).attr("href"),
      success: function(data) {
        return window.GetDiv("divRedefineSenha").html(data);
      }
    });
  };

  usuariosController.prototype.configurarUpload = function() {
    this.uploadFoto.click((function(_this) {
      return function() {
        return _this.inputFoto.click();
      };
    })(this));
    return this.inputFoto.change((function(_this) {
      return function() {
        var form;
        form = FileUpload.getFormData($("#FormUploadPerfil", _this.contexto));
        return $as.Manutencao.Usuarios.Upload.postFormData(form).done(function(data) {
          if (data.success) {
            return _this.iniciarCrop();
          } else {
            return window.MostrarMensagemAviso(data.message);
          }
        });
      };
    })(this));
  };

  usuariosController.prototype.iniciarCrop = function() {
    return $as.Manutencao.Usuarios.IniciarCrop.get({
      idDoUsuario: this.options.referenciaUnica
    }).done((function(_this) {
      return function(data) {
        $('#main-modal').html(data);
        return _this.ativarJCrop();
      };
    })(this));
  };

  usuariosController.prototype.ativarJCrop = function() {
    return $('#imagem_crop', "#modalSelecionaFoto").Jcrop({
      bgColor: 'black',
      bgOpacity: .4,
      aspectRatio: 1,
      setSelect: [0, 0, 60, 60],
      onSelect: this.showCoords,
      onChange: this.showCoords,
      allowSelect: false
    }, function() {
      var jcrop;
      return jcrop = this;
    });
  };

  usuariosController.prototype.showCoords = function(c) {
    var contextoCoords;
    contextoCoords = "#modalSelecionaFoto";
    $("#x1", contextoCoords).val(c.x);
    $("#x2", contextoCoords).val(c.x2);
    $("#y1", contextoCoords).val(c.y);
    $("#y2", contextoCoords).val(c.y2);
    return $("#recortar", contextoCoords).removeClass("hidden");
  };

  usuariosController.prototype.submitCrop = function() {
    return $as.Manutencao.Usuarios.Crop.post($("#modalSelecionaFoto :input").serialize()).done((function(_this) {
      return function(data) {
        $('#DeleteFoto', _this.contexto).show();
        $('#separadorFoto', _this.contexto).show();
        return _this.recarregarFoto();
      };
    })(this));
  };

  usuariosController.prototype.recarregarFoto = function() {
    return $as.Manutencao.Usuarios.RecarregarFoto.get({
      idDoUsuario: this.options.referenciaUnica
    }).done((function(_this) {
      return function(data) {
        return $('#foto-usuario', _this.contexto).html(data);
      };
    })(this));
  };

  usuariosController.prototype.aoAlterarChefe = function() {
    return $as.Manutencao.Usuarios.ObterNomeDoChefeAtual.get({
      idDoUsuario: this.options.referenciaUnica
    }).done((function(_this) {
      return function(html) {
        $('#container-chefe', _this.contexto).html(html);
        return $('#close-modal-alterarchefe').click();
      };
    })(this));
  };

  return usuariosController;

})();
