﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.ParticipantesDoAgendamentoController = (function(superClass) {
  extend(ParticipantesDoAgendamentoController, superClass);

  function ParticipantesDoAgendamentoController(view, options, resource) {
    this.view = view;
    this.options = options;
    this.resource = resource;
    this.errorTamanhoEmail = bind(this.errorTamanhoEmail, this);
    this.aplicarFormatacaoDeValidacaoNoCampoEmail = bind(this.aplicarFormatacaoDeValidacaoNoCampoEmail, this);
    this.aplicarFormatacaoDeValidacaoNoCampoNome = bind(this.aplicarFormatacaoDeValidacaoNoCampoNome, this);
    this.editarParticipanteTerceiro = bind(this.editarParticipanteTerceiro, this);
    this.mostrarOcultarEdicaoParticipante = bind(this.mostrarOcultarEdicaoParticipante, this);
    this.salvarParticipanteDoSistema = bind(this.salvarParticipanteDoSistema, this);
    this.salvarParticipanteSemEmail = bind(this.salvarParticipanteSemEmail, this);
    this.salvarParticipanteSelecionado = bind(this.salvarParticipanteSelecionado, this);
    this.resetarCampos = bind(this.resetarCampos, this);
    this.mostrarCompoEmail = bind(this.mostrarCompoEmail, this);
    this.adicionarParticipante = bind(this.adicionarParticipante, this);
    this.salvarParticipante = bind(this.salvarParticipante, this);
    this.ReloadParticipantes = bind(this.ReloadParticipantes, this);
    this.PegarHiddenID = bind(this.PegarHiddenID, this);
    this.DefinirJustificativas = bind(this.DefinirJustificativas, this);
    this.AlterarParaAusente = bind(this.AlterarParaAusente, this);
    this.AlterarParaPresente = bind(this.AlterarParaPresente, this);
    this.SolicitarAprovacao = bind(this.SolicitarAprovacao, this);
    this.EnviarAta = bind(this.EnviarAta, this);
    this.EnviarNotificacao = bind(this.EnviarNotificacao, this);
    this.Serializar = bind(this.Serializar, this);
    this.AplicarFiltroAoElemento = bind(this.AplicarFiltroAoElemento, this);
    this.filtrarPorAtributo = bind(this.filtrarPorAtributo, this);
    this.ExcluirParticipante = bind(this.ExcluirParticipante, this);
    this.DefinirJustificativa = bind(this.DefinirJustificativa, this);
    this.MarcarComoAusente = bind(this.MarcarComoAusente, this);
    this.MarcarComoPresente = bind(this.MarcarComoPresente, this);
    this.SolicitarAoParticipanteAprovacao = bind(this.SolicitarAoParticipanteAprovacao, this);
    this.EnviarAtaAoParticipante = bind(this.EnviarAtaAoParticipante, this);
    this.EnviarConvite = bind(this.EnviarConvite, this);
    this.mostrarOpcoesDoFiltro = bind(this.mostrarOpcoesDoFiltro, this);
    ParticipantesDoAgendamentoController.__super__.constructor.call(this, this.view, null);
    this.mostrarOpcoesDoFiltro();
    this.IdsExclusaoParticipantes = null;
    (this.get('input')).placeholder();
    (this.get('[rel=tooltip]')).tooltip();
    (this.get('#Nome')).autocompleter(this.options.UrlComboParticipantes, {
      loadOnDemand: false,
      keyElement: '#idParticipante',
      selectOnTypeArrow: false,
      onSelected: this.adicionarParticipante
    });
    (this.get('[filter-Val]')).click((function(_this) {
      return function(e) {
        $(e.currentTarget).toggleClass('status-inativo');
        return _this.filtrarPorAtributo('convite', _this.View);
      };
    })(this));
    (this.get('#selecionarTodos')).click((function(_this) {
      return function(e) {
        var $a;
        $a = $(e.currentTarget).find('a');
        if ($a.attr('data-desmarcar') !== 'true') {
          return (_this.get('.box-lista-usuario')).click();
        } else {
          return (_this.get('.selecionado')).click();
        }
      };
    })(this));
    (this.get('#TodosStatusParticipantes')).click((function(_this) {
      return function() {
        (_this.get('[filter-Val]')).each(function(e) {
          return $(e.currentTarget).removeClass('status-inativo');
        });
        return _this.filtrarPorAtributo('convite', _this.View);
      };
    })(this));
    (this.get('#NenhumStatusPArticipantes')).click((function(_this) {
      return function() {
        (_this.get('[filter-Val]')).each(function(e) {
          return $(e.currentTarget).addClass('status-inativo');
        });
        return _this.filtrarPorAtributo('convite', _this.View);
      };
    })(this));
    (this.get('#EnviarConvitesParaSelecionados')).click((function(_this) {
      return function() {
        var hiddens;
        hiddens = _this.get('.selecionado [type=hidden]');
        if (hiddens.length) {
          return _this.EnviarNotificacao(hiddens);
        }
      };
    })(this));
    (this.get('#EnviarAta')).click((function(_this) {
      return function() {
        var hiddens;
        hiddens = _this.get('.selecionado [type=hidden]');
        if (hiddens.length) {
          return _this.EnviarAta(hiddens);
        }
      };
    })(this));
    (this.get('#SolicitarAprovacao')).click((function(_this) {
      return function() {
        var hiddens;
        hiddens = _this.get('.selecionado [type=hidden]');
        if (hiddens.length) {
          return _this.SolicitarAprovacao(hiddens);
        }
      };
    })(this));
    (this.get('#MarcarSelecionadosComoPresente')).click((function(_this) {
      return function() {
        var hiddens;
        hiddens = _this.get('.selecionado [type=hidden]');
        if (hiddens.length) {
          return _this.MarcarComoPresente(hiddens);
        }
      };
    })(this));
    (this.get('#MarcarSelecionadosComoAusente')).click((function(_this) {
      return function() {
        var hiddens;
        hiddens = _this.get('.selecionado [type=hidden]');
        if (hiddens.length) {
          if (_this.options.ECorporativo) {
            return _this.DefinirJustificativas(hiddens);
          } else {
            return _this.MarcarComoAusente(hiddens);
          }
        }
      };
    })(this));
    (this.get('#JustificarAusenciaSelecionado')).click((function(_this) {
      return function() {
        var hiddens;
        hiddens = $('.selecionado [type=hidden]', _this.view);
        if (hiddens.length) {
          return _this.DefinirJustificativas(hiddens);
        }
      };
    })(this));
    $(this.view).on({
      click: (function(_this) {
        return function(e) {
          var dependentes;
          $(e.currentTarget).toggleClass('selecionado');
          dependentes = _this.get('.HabilitarDesabilitar');
          if ((_this.get('.selecionado')).length) {
            $('#selecionarTodos a').text(_this.resource.DesmarcarSelecionados);
            $('#selecionarTodos a').attr('data-desmarcar', 'true');
            dependentes.removeAttr('disabled');
            return dependentes.removeClass('disabled');
          } else {
            $('#selecionarTodos a').text(_this.resource.SelecionarTodos);
            dependentes.attr('disabled', 'disabled');
            $('#selecionarTodos a').attr('data-desmarcar', 'false');
            return dependentes.addClass('disabled');
          }
        };
      })(this)
    }, '.box-lista-usuario:not(.novo)');
    Participante.excluirSelecionados = (function(_this) {
      return function(ids) {
        if (!ids) {
          _this.IdsExclusaoParticipantes = _this.get('.selecionado [type=hidden]');
        } else {
          _this.IdsExclusaoParticipantes = ids;
        }
        if (_this.IdsExclusaoParticipantes.length) {
          return window.modalConfirm(_this.resource.DesejaExcluirOsRegistrosSelecionados, Participante.excluirConfirmado);
        }
      };
    })(this);
    Participante.excluirConfirmado = (function(_this) {
      return function() {
        return $as.Agenda.Participantes.DeletarVarios.post(_this.Serializar(_this.IdsExclusaoParticipantes) + '&idDoAgendamento=' + _this.options.IdDoAgendamento).done(function() {
          return _this.ReloadParticipantes();
        });
      };
    })(this);
    Participante.salvarParticipanteSemEmailConfirmado = (function(_this) {
      return function() {
        $('#EhUsuarioDoSistema', '#NovoUsuario').val('False');
        return _this.salvarParticipante();
      };
    })(this);
  }

  ParticipantesDoAgendamentoController.prototype.AlterarPresenca = function(idCallBack, status) {
    return $as.Agenda.Participantes.ModificarPresenca.get({
      idDoParticipante: idCallBack,
      presenca: status
    }).done(function(retn) {
      return $('#' + idCallBack + '-status-presenca').html(retn);
    });
  };

  ParticipantesDoAgendamentoController.prototype.mostrarOpcoesDoFiltro = function() {
    if ($('#Iniciada').val() === 'cancelada') {
      $('.naoRealizada', '#participantes-container').hide();
      return $('.realizada', '#participantes-container').hide();
    } else if ($('#Iniciada').val() === 'true') {
      $('.naoRealizada', '#participantes-container').hide();
      return $('.realizada', '#participantes-container').show();
    } else {
      $('.realizada', '#participantes-container').hide();
      return $('.naoRealizada', '#participantes-container').show();
    }
  };

  ParticipantesDoAgendamentoController.prototype.EnviarConvite = function(el) {
    var hidden;
    hidden = this.PegarHiddenID(el);
    return this.EnviarNotificacao(hidden);
  };

  ParticipantesDoAgendamentoController.prototype.EnviarAtaAoParticipante = function(el) {
    var hidden;
    hidden = this.PegarHiddenID(el);
    return this.EnviarAta(hidden);
  };

  ParticipantesDoAgendamentoController.prototype.SolicitarAoParticipanteAprovacao = function(el) {
    var hidden;
    hidden = this.PegarHiddenID(el);
    return this.SolicitarAprovacao(hidden);
  };

  ParticipantesDoAgendamentoController.prototype.MarcarComoPresente = function(el) {
    var hidden;
    hidden = this.PegarHiddenID(el);
    return this.AlterarParaPresente(hidden);
  };

  ParticipantesDoAgendamentoController.prototype.MarcarComoAusente = function(el) {
    var hidden;
    hidden = this.PegarHiddenID(el);
    return this.AlterarParaAusente(hidden);
  };

  ParticipantesDoAgendamentoController.prototype.DefinirJustificativa = function(el) {
    var hidden;
    hidden = this.PegarHiddenID(el);
    return this.DefinirJustificativas(hidden);
  };

  ParticipantesDoAgendamentoController.prototype.ExcluirParticipante = function(el) {
    var hidden;
    hidden = this.PegarHiddenID(el);
    return Participante.excluirSelecionados(hidden);
  };

  ParticipantesDoAgendamentoController.prototype.filtrarPorAtributo = function(atributo, contexto) {
    var filtros, i, item, itens, k, ref, results;
    filtros = this.get('.status-inativo');
    itens = this.get('.filtravel');
    results = [];
    for (i = k = 0, ref = itens.length; k <= ref; i = k += 1) {
      item = $(itens[i]);
      results.push(this.AplicarFiltroAoElemento(item, filtros, atributo));
    }
    return results;
  };

  ParticipantesDoAgendamentoController.prototype.AplicarFiltroAoElemento = function(elemento, filtros, atributo) {
    var filtro, j, k, mostrar, ref, valorFiltro;
    mostrar = true;
    for (j = k = 0, ref = filtros.length; k <= ref; j = k += 1) {
      filtro = $(filtros[j]);
      valorFiltro = filtro.attr('filter-Val');
      mostrar = mostrar && !(elemento.attr(atributo) === valorFiltro);
    }
    if (!mostrar) {
      return elemento.hide('slow');
    } else {
      return elemento.show('slow');
    }
  };

  ParticipantesDoAgendamentoController.prototype.Serializar = function(valores) {
    var j, k, ref, serialized, valor;
    serialized = '';
    for (j = k = 0, ref = valores.length; k <= ref; j = k += 1) {
      valor = $(valores[j]);
      serialized = serialized + valor.attr('name') + '=' + valor.val() + '&';
    }
    serialized = serialized.substring(0, serialized.length - 1);
    return serialized;
  };

  ParticipantesDoAgendamentoController.prototype.EnviarNotificacao = function(ids) {
    var parametros;
    parametros = this.Serializar(ids) + '&idDoAgendamento=' + this.options.IdDoAgendamento;
    return $as.Agenda.Agendamentos.NotificarParticipantes.get(parametros).done((function(_this) {
      return function(msg) {
        return _this.ReloadParticipantes(msg);
      };
    })(this));
  };

  ParticipantesDoAgendamentoController.prototype.EnviarAta = function(ids) {
    var parametros;
    parametros = this.Serializar(ids) + '&idDoAgendamento=' + this.options.IdDoAgendamento;
    return $as.Agenda.Agendamentos.EnviarAtaParaVisualizacao.get(parametros).done((function(_this) {
      return function(msg) {
        return _this.ReloadParticipantes(msg);
      };
    })(this));
  };

  ParticipantesDoAgendamentoController.prototype.SolicitarAprovacao = function(ids) {
    var parametros;
    parametros = this.Serializar(ids) + '&idDoAgendamento=' + this.options.IdDoAgendamento;
    return $as.Agenda.Agendamentos.SolicitarConfirmacaoDaAta.get(parametros).done((function(_this) {
      return function(msg) {
        return _this.ReloadParticipantes(msg);
      };
    })(this));
  };

  ParticipantesDoAgendamentoController.prototype.AlterarParaPresente = function(ids, elemento) {
    return $as.Agenda.Participantes.ModificarPresencaParaPresente.post(this.Serializar(ids)).done((function(_this) {
      return function(data) {
        return _this.ReloadParticipantes();
      };
    })(this));
  };

  ParticipantesDoAgendamentoController.prototype.AlterarParaAusente = function(ids, elemento) {
    return $as.Agenda.Participantes.ModificarPresencaParaAusente.post(this.Serializar(ids)).done((function(_this) {
      return function(data) {
        return _this.ReloadParticipantes();
      };
    })(this));
  };

  ParticipantesDoAgendamentoController.prototype.DefinirJustificativas = function(ids, elemento) {
    return $as.Agenda.Participantes.DefinirMotivoDeNaoComparecimento.get(this.Serializar(ids)).done(function(data) {
      return $('#definir-motivo-container').html(data);
    });
  };

  ParticipantesDoAgendamentoController.prototype.PegarHiddenID = function(elemento) {
    return $('[name=Ids]', $(elemento).parent());
  };

  ParticipantesDoAgendamentoController.prototype.ReloadParticipantes = function(msg) {
    return $as.Agenda.Participantes.Index.get({
      idDoPai: this.options.IdDoAgendamento
    }).done((function(_this) {
      return function(html) {
        $('#participantes-container').html(html);
        (_this.get('[rel=tooltip]')).tooltip();
        if ((msg != null) && msg !== '') {
          return showBottomNoty(msg);
        }
      };
    })(this));
  };

  ParticipantesDoAgendamentoController.prototype.salvarParticipante = function() {
    return $as.Agenda.Participantes.CreateParticipante.post($('#NovoUsuario :input').filter(':input').serialize()).done((function(_this) {
      return function(data) {
        var erro, k, len, ref, str, txtEmail, txtNome;
        txtEmail = $('#Email', '#NovoUsuario');
        txtNome = $('#Nome', '#NovoUsuario');
        if (data.error == null) {
          (_this.get('#participantesDoAgendamento')).append(data).hide().fadeIn(1000);
          $('#EhUsuarioDoSistema', '#NovoUsuario').val('False');
          $('#Usuario_Id', '#NovoUsuario').val(null);
          $('#idParticipante').val(null);
          $('#Nome', '#NovoUsuario').val(null);
          $('#Email', '#NovoUsuario').val(null);
          txtNome.val(null);
          txtNome.animate({
            top: '20px'
          }, 500).focus();
          txtNome.css('border', '');
          txtNome.attr('title', '');
          txtNome.tooltip('disable');
          txtEmail.val(null);
          txtEmail.animate({
            top: '0px'
          }, 500).hide();
          txtNome.attr('placeholder', _this.resource.InformeUmNomeOuEmail);
          (_this.get('[rel=tooltip]')).tooltip();
          _this.mostrarOpcoesDoFiltro();
          window.agendamentoController.VerificarNecessidadeDeConvocacao();
          swIntercom('Adicionou participante na reuniao');
          if (typeof Events !== "undefined" && Events !== null) {
            Events.Track.NotifyEvent('CreateEdit', 'Participantes', 'Adicionar');
          }
          txtNome.focus();
        }
        if (data.emailInvalido) {
          _this.aplicarFormatacaoDeValidacaoNoCampoEmail(txtEmail, true);
        }
        if (data.errors && data.errors.length) {
          str = '';
          ref = data.errors;
          for (k = 0, len = ref.length; k < len; k++) {
            erro = ref[k];
            str = str + erro + "</br>";
          }
          showBottomNoty(str);
          return _this.resetarCampos();
        }
      };
    })(this));
  };

  ParticipantesDoAgendamentoController.prototype.adicionarParticipante = function() {
    var selecionado, txtEhUsuarioDoSistema, txtEmail, txtNome;
    selecionado = $('#idParticipante').val();
    txtEmail = $('#Email', '#NovoUsuario');
    txtNome = $('#Nome', '#NovoUsuario');
    txtEhUsuarioDoSistema = $('#EhUsuarioDoSistema', '#NovoUsuario');
    this.aplicarFormatacaoDeValidacaoNoCampoNome(txtNome, false);
    this.aplicarFormatacaoDeValidacaoNoCampoEmail(txtEmail, false);
    $('#Agendamento_Id', '#NovoUsuario').val(this.options.IdDoAgendamento);
    if (selecionado !== null && selecionado !== '') {
      return this.salvarParticipanteSelecionado(selecionado);
    } else {
      if (!txtEmail.is(":visible") && !window.EmailValido(txtNome.val())) {
        return this.mostrarCompoEmail(txtEmail, txtNome);
      } else {
        if (txtNome.val() === '' || txtNome.val() === this.resource.InformeUmNomeOuEmail) {
          return this.aplicarFormatacaoDeValidacaoNoCampoNome(txtNome, true);
        } else if (txtEmail.val() === '' && !window.EmailValido(txtNome.val())) {
          return this.salvarParticipanteSemEmail();
        } else {
          if (window.EmailValido(txtNome.val())) {
            if (txtNome.val().length <= 50) {
              this.errorTamanhoEmail(false);
              if (txtEmail.val() === '') {
                txtEmail.val(txtNome.val());
                txtNome.val(null);
                this.mostrarCompoEmail(txtEmail, txtNome);
              }
              return $.get(this.options.UrlInformacoesPorEmail, {
                emailDoUsuario: txtEmail.val()
              }, (function(_this) {
                return function(usuario) {
                  if (usuario && usuario.Id) {
                    return _this.salvarParticipanteDoSistema(usuario.Id);
                  } else {
                    if (txtNome.val() !== '' && txtEmail.val() !== '') {
                      txtEhUsuarioDoSistema.val('False');
                      return _this.salvarParticipante();
                    } else {
                      return _this.mostrarCompoEmail(txtEmail, txtNome);
                    }
                  }
                };
              })(this));
            } else {
              return this.errorTamanhoEmail(true);
            }
          }
        }
      }
    }
  };

  ParticipantesDoAgendamentoController.prototype.mostrarCompoEmail = function(txtEmail, txtNome) {
    txtEmail.attr('style', 'left:15px;').show();
    txtEmail.animate({
      top: '11px'
    }, 500);
    txtNome.attr('style', 'left:15px;');
    txtNome.animate({
      top: '5px'
    }, 500);
    txtNome.attr("placeholder", this.resource.InformeUmNome);
    if (txtNome.val() === '' || txtNome.val() === this.resource.InformeUmNomeOuEmail || txtNome.val() === this.resource.InformeUmNome) {
      return txtNome.focus();
    } else {
      return txtEmail.focus();
    }
  };

  ParticipantesDoAgendamentoController.prototype.resetarCampos = function() {
    $('#EhUsuarioDoSistema', '#NovoUsuario').val('');
    $('#Usuario_Id', '#NovoUsuario').val('');
    return $('#idParticipante', '#NovoUsuario').val('');
  };

  ParticipantesDoAgendamentoController.prototype.salvarParticipanteSelecionado = function(selecionado) {
    $('#EhUsuarioDoSistema', '#NovoUsuario').val('True');
    $('#Usuario_Id', '#NovoUsuario').val(selecionado);
    return this.salvarParticipante();
  };

  ParticipantesDoAgendamentoController.prototype.salvarParticipanteSemEmail = function() {
    return window.modalConfirm(this.resource.AdicionarParticipanteSemEmail, Participante.salvarParticipanteSemEmailConfirmado);
  };

  ParticipantesDoAgendamentoController.prototype.salvarParticipanteDoSistema = function(idUsuario) {
    $('#EhUsuarioDoSistema', '#NovoUsuario').val('True');
    $('#Usuario_Id', '#NovoUsuario').val(idUsuario);
    return this.salvarParticipante();
  };

  ParticipantesDoAgendamentoController.prototype.mostrarOcultarEdicaoParticipante = function(idContainer) {
    var container, dvCartaoParticipante, dvEditarParticipanteTerceiro, form, hidEmail, hidNome, txtEmail, txtNome;
    container = $('#' + idContainer);
    dvEditarParticipanteTerceiro = container.find('.dvEditarParticipanteTerceiro');
    dvCartaoParticipante = container.find('.dvCartaoParticipante');
    form = dvEditarParticipanteTerceiro.find(':input');
    txtNome = form.filter("input[name='nome']");
    txtEmail = form.filter("input[name='email']");
    hidNome = form.filter("input[name='hidNome']");
    hidEmail = form.filter("input[name='hidEmail']");
    txtEmail.val(hidEmail.val());
    txtNome.val(hidNome.val());
    dvEditarParticipanteTerceiro.toggle(300);
    return dvCartaoParticipante.toggle(300);
  };

  ParticipantesDoAgendamentoController.prototype.editarParticipanteTerceiro = function(idContainer) {
    var container, dvEditarParticipanteTerceiro, form, formSerialize, txtEmail, txtNome;
    container = $('#' + idContainer);
    dvEditarParticipanteTerceiro = container.find('.dvEditarParticipanteTerceiro');
    form = dvEditarParticipanteTerceiro.find(':input');
    txtNome = form.filter("input[name='nome']");
    txtEmail = form.filter("input[name='email']");
    if (txtNome.val() === '') {
      return txtNome.focus();
    } else if (txtEmail.val() !== '' && !window.EmailValido(txtEmail.val())) {
      txtEmail.addClass('error');
      txtEmail.attr('title', this.resource.EmailInvalido);
      return txtEmail.tooltip();
    } else {
      formSerialize = form.filter(function() {
        return this.value !== '';
      }).serialize();
      return $as.Agenda.Participantes.EditarParticipanteTerceiro.post(formSerialize).done((function(_this) {
        return function(data) {
          var errorContainer, hidEmail, hidNome;
          if (data.Error) {
            hidNome = form.filter("input[name='hidNome']");
            hidEmail = form.filter("input[name='hidEmail']");
            txtEmail.val(hidEmail.val());
            txtNome.val(hidNome.val());
            errorContainer = $("#MensagemDeErro-Business", "#modalErroBusiness");
            errorContainer.text(data.Message);
            $("#modalErroBusiness").modal();
          } else {
            container.html(data);
          }
          return (_this.get('[rel=tooltip]')).tooltip();
        };
      })(this));
    }
  };

  ParticipantesDoAgendamentoController.prototype.aplicarFormatacaoDeValidacaoNoCampoNome = function(txtNome, possuiErro) {
    txtNome.attr('title', this.resource.InformeUmNome);
    txtNome.attr('data-original-title', this.resource.InformeUmNome);
    txtNome.tooltip('enable');
    if (possuiErro) {
      txtNome.css('border', '1px solid #a94442');
      txtNome.addClass('error');
      txtNome.focus();
      txtNome.attr('title', '');
      txtNome.tooltip('enable');
    } else {
      txtNome.css('border', '');
      txtNome.removeClass('error');
      txtNome.attr('title', '');
      txtNome.tooltip('disable');
    }
  };

  ParticipantesDoAgendamentoController.prototype.aplicarFormatacaoDeValidacaoNoCampoEmail = function(txtEmail, possuiErro) {
    txtEmail.attr('title', this.resource.EmailInvalido);
    txtEmail.tooltip('enable');
    if (possuiErro) {
      txtEmail.css('border', '1px solid #a94442');
      txtEmail.addClass('error');
      txtEmail.focus();
      txtEmail.attr('title', '');
      txtEmail.tooltip('enable');
    } else {
      txtEmail.css('border', '');
      txtEmail.removeClass('error');
      txtEmail.attr('title', '');
      txtEmail.tooltip('disable');
    }
  };

  ParticipantesDoAgendamentoController.prototype.errorTamanhoEmail = function(possuiErro) {
    var txtNome;
    txtNome = $('#Nome', '#NovoUsuario');
    txtNome.attr('data-original-title', this.resource.OTamanhoMaximoDoCampoXEDeYCaracteres.replace("{0}", this.resource.Email).replace("{1}", "50"));
    txtNome.tooltip('enable');
    if (possuiErro) {
      txtNome.css('border', '1px solid #a94442');
      txtNome.addClass('error');
      txtNome.focus();
      txtNome.attr('title', '');
      txtNome.tooltip('enable');
    } else {
      txtNome.attr('data-original-title', this.resource.InformeUmNome);
      txtNome.css('border', '');
      txtNome.removeClass('error');
      txtNome.attr('title', '');
      txtNome.tooltip('disable');
    }
  };

  return ParticipantesDoAgendamentoController;

})(window.baseController);
