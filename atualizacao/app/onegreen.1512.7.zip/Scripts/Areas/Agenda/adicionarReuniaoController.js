﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.adicionarReuniaoController = (function(superClass) {
  extend(adicionarReuniaoController, superClass);

  function adicionarReuniaoController() {
    this.RetornarDataTextual = bind(this.RetornarDataTextual, this);
    $('#adicionarreuniao-modal').window();
    setCombo("#adicionarreuniao-modal", '#Tipo_Nome');
    setCombo("#adicionarreuniao-modal", '#UnidadeGerencial_SiglaAtual');
    $('#DescricoesAssuntosParaAdicao').TextAreaExpander(40);
    this.RetornarDataTextual();
  }

  adicionarReuniaoController.prototype.RetornarDataTextual = function(data) {
    var dataIni, datainicioPrevisto, horaIni;
    dataIni = data ? data : (this.get('#DataInicioPrevista_Date')).val();
    horaIni = (this.get('#DataInicioPrevista_Time')).val();
    datainicioPrevisto = dataIni + ' ' + horaIni;
    return $as.Agenda.Agendamentos.RetornarDataTextual.get({
      datainicioPrevisto: datainicioPrevisto
    }).done((function(_this) {
      return function(retn) {
        (_this.get('#DataInicioPrevista_Date')).val(retn.data);
        (_this.get('#DataInicioPrevistaTextual')).val(retn.data);
        (_this.get('#DataTerminoPrevista_Date')).val(retn.data);
        (_this.get('#DataTerminoPrevista_Time')).val(retn.hora);
        return (_this.get('#descDiaSemana')).html(retn.diaDaSemana);
      };
    })(this));
  };

  adicionarReuniaoController.prototype.Redirecionar = function(idDaReuniao) {
    return window.location.href = $as.Agenda.Agendamentos.Edit.url + "/" + idDaReuniao;
  };

  adicionarReuniaoController.prototype.SalvarReuniao = function() {
    return $as.Agenda.Agendamentos.Create.post($('#formReuniao').serialize()).done((function(_this) {
      return function(res) {
        if (res.success) {
          swIntercom('Criou uma reuniao');
          return _this.Redirecionar(res.data.id);
        } else {
          return $('#box-createEdit-agendamento').html(res);
        }
      };
    })(this));
  };

  return adicionarReuniaoController;

})(window.baseController);
