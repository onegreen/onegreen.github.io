﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.nomesDasCoresController = (function() {
  var $currentLabel, idDaEmpresa, modoDeEdicao;

  $currentLabel = null;

  modoDeEdicao = false;

  idDaEmpresa = null;

  function nomesDasCoresController(idDaEmpresa1, podeAlterar, contextoGeral) {
    this.idDaEmpresa = idDaEmpresa1;
    this.podeAlterar = podeAlterar;
    this.contextoGeral = contextoGeral;
    this.ObterCorPadrao = bind(this.ObterCorPadrao, this);
    this.SalvarCoresDaReuniao = bind(this.SalvarCoresDaReuniao, this);
    this.AjustarTabelaDeCores = bind(this.AjustarTabelaDeCores, this);
    this.SelecionarNivel = bind(this.SelecionarNivel, this);
    this.SelectTd = bind(this.SelectTd, this);
    this.DefinirCliqueTabela = bind(this.DefinirCliqueTabela, this);
    this.MostrarCores = bind(this.MostrarCores, this);
    this.IniciarCoresDaReuniao = bind(this.IniciarCoresDaReuniao, this);
    this.EditarNomeDaCor = bind(this.EditarNomeDaCor, this);
    this.contextoGeral = $("#" + this.contextoGeral);
    this.contextoDasCores = $("#cores-container", this.contextoGeral);
    this.$tabela = $("#tb-cor", this.contextoDasCores);
    this.IniciarCoresDaReuniao();
    this.idDaEmpresa = this.idDaEmpresa;
  }

  nomesDasCoresController.prototype.EditarNomeDaCor = function($cor) {
    $('#tb-cor input:text', this.contextoDasCores).show();
    $('#tb-cor input:radio', this.contextoDasCores).hide();
    $('#tb-cor label', this.contextoDasCores).hide();
    $('#tb-cor span', this.contextoDasCores).hide();
    $('#BtnEditarCores', this.contextoDasCores).hide();
    $('#BtnSalvarCores', this.contextoDasCores).show();
    $('#BtnCancelarEdicao', this.contextoDasCores).show();
    return modoDeEdicao = true;
  };

  nomesDasCoresController.prototype.CancelarEdicaoDeCores = function() {
    $('#tb-cor', this.contextoDasCores).fadeOut(1);
    $('#BtnSalvarCores', this.contextoDasCores).hide();
    $('#BtnEditarCores', this.contextoDasCores).hide();
    $('#BtnCancelarEdicao', this.contextoDasCores).hide();
    $("#corPadrao", this.contextoDasCores).fadeIn(500);
    $('#tb-cor label', this.contextoDasCores).show();
    $('#tb-cor span', this.contextoDasCores).show();
    $('#tb-cor input:text', this.contextoDasCores).hide();
    return modoDeEdicao = false;
  };

  nomesDasCoresController.prototype.IniciarCoresDaReuniao = function() {
    $('#tb-cor', this.contextoDasCores).find("input").hide();
    $('#corPadrao', this.contextoDasCores).find("input").hide();
    $('#BtnSalvarCores', this.contextoDasCores).hide();
    $('#BtnEditarCores', this.contextoDasCores).hide();
    $('#BtnCancelarEdicao', this.contextoDasCores).hide();
    $('#tb-cor', this.contextoDasCores).hide();
    if (this.podeAlterar) {
      $('#corPadrao', this.contextoDasCores).click(this.MostrarCores);
      $('#iconeCores', this.contextoDasCores).click(this.MostrarCores);
    } else {
      $('#corPadrao', this.contextoDasCores).addClass("cursor-not-allowed");
      $('#iconeCores', this.contextoDasCores).addClass("cursor-not-allowed");
      $('#iconeCores', this.contextoDasCores).children().addClass("cursor-not-allowed");
    }
    this.AjustarTabelaDeCores();
    return modoDeEdicao = false;
  };

  nomesDasCoresController.prototype.MostrarCores = function() {
    $("#corPadrao", this.contextoDasCores).hide();
    $("#tb-cor", this.contextoDasCores).fadeIn(500);
    $('#BtnEditarCores', this.contextoDasCores).show();
    return $('#BtnCancelarEdicao', this.contextoDasCores).hide();
  };

  nomesDasCoresController.prototype.DefinirCliqueTabela = function() {
    var that;
    that = this;
    $("div", this.$tabela).css("cursor", "pointer").click(function(event) {
      event.stopPropagation();
      if ($currentLabel !== null) {
        $currentLabel.css("font-weight", "normal");
        $currentLabel.parent().removeClass('corSelecionada');
        $('input[radio]', $currentLabel).removeAttr('checked');
        $("i", $currentLabel).remove();
      }
      that.SelectTd($(this, this.contextoDasCores));
    });
  };

  nomesDasCoresController.prototype.SelectTd = function($tdz) {
    if ($tdz.hasClass('corSelecionada')) {
      $tdz.removeClass('corSelecionada');
      $(':radio', $currentLabel).removeAttr('checked');
    } else {
      $tdz.addClass('corSelecionada');
      $currentLabel = $tdz.find("label");
      $(':radio', $currentLabel).attr('checked', 'checked');
      $currentLabel.css("font-weight", "bold");
    }
    $('#CorDaReuniao', this.contextoGeral).val($(':radio', $currentLabel).val()).change();
    if (!modoDeEdicao) {
      this.ObterCorPadrao($(':radio', $currentLabel).val());
    }
  };

  nomesDasCoresController.prototype.SelecionarNivel = function(nivel) {
    var $td;
    $td = $("tr td[data-nivel='" + nivel + "']", this.$tabela);
    return this.SelectTd($td);
  };

  nomesDasCoresController.prototype.AjustarTabelaDeCores = function() {
    this.DefinirCliqueTabela();
    return this.$tabela.find("input").hide();
  };

  nomesDasCoresController.prototype.SalvarCoresDaReuniao = function() {
    return $as.Agenda.NomesDasCores.SalvarNomesDasCores.post($('#cores-container :input', this.contextoGeral).serialize()).done((function(_this) {
      return function(data) {
        $('#cores-container', _this.contextoGeral).html(data);
        return _this.MostrarCores();
      };
    })(this));
  };

  nomesDasCoresController.prototype.ObterCorPadrao = function(corDaReuniao) {
    return $as.Agenda.NomesDasCores.CorPadrao.get({
      corDaReuniao: corDaReuniao,
      idDaEmpresa: this.idDaEmpresa
    }).done((function(_this) {
      return function(data) {
        $('#corPadrao', _this.contextoDasCores).html(data);
        return _this.CancelarEdicaoDeCores();
      };
    })(this));
  };

  return nomesDasCoresController;

})();
