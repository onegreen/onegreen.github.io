﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.listagemDeAgendamentosController = (function(superClass) {
  extend(listagemDeAgendamentosController, superClass);

  function listagemDeAgendamentosController(view, options, resource) {
    this.view = view;
    this.options = options;
    this.resource = resource;
    this.setarEspacoEmBrancoParaScroll = bind(this.setarEspacoEmBrancoParaScroll, this);
    this.scrollItemToTop = bind(this.scrollItemToTop, this);
    this.selecionarData = bind(this.selecionarData, this);
    this.carregarDatasPosteriores = bind(this.carregarDatasPosteriores, this);
    this.carregarDatasAnteriores = bind(this.carregarDatasAnteriores, this);
    this.carregar = bind(this.carregar, this);
    listagemDeAgendamentosController.__super__.constructor.call(this, this.view, null);
    this.view = $(this.view);
    this.carregar();
    this.calendario = new calendario(this.view.find('#CalendarContainer'), {
      data: this.options.dataBase,
      aoSelecionarData: this.selecionarData,
      carregarDatasAnteriores: this.carregarDatasAnteriores,
      carregarDatasPosteriores: this.carregarDatasPosteriores
    });
  }

  listagemDeAgendamentosController.prototype.carregar = function() {
    if (window.agendamentoController && window.agendamentoController.currentNoty) {
      window.agendamentoController.currentNoty.close();
    }
    $("#lnkAgenda").closest("ul").find("li").removeClass("active");
    $("#lnkAgenda").parent().addClass("active");
    $("[rel=tooltip]").tooltip({
      container: 'body'
    });
    this.view.find('#IrParaODiaDeHoje').unbind('click').click((function(_this) {
      return function() {
        return _this.scrollItemToTop("#SpanHoje");
      };
    })(this));
    return this.setarEspacoEmBrancoParaScroll();
  };

  listagemDeAgendamentosController.prototype.carregarDatasAnteriores = function(event) {
    return $as.Agenda.FiltroDeAgendamentos.AdicinarMesesNoCalendario.post({
      offSet: -1
    }).done((function(_this) {
      return function(data) {
        if (data.success) {
          return Agenda.api.listar();
        }
      };
    })(this));
  };

  listagemDeAgendamentosController.prototype.carregarDatasPosteriores = function(event) {
    return $as.Agenda.FiltroDeAgendamentos.AdicinarMesesNoCalendario.post({
      offSet: 1
    }).done((function(_this) {
      return function(data) {
        if (data.success) {
          return Agenda.api.listar();
        }
      };
    })(this));
  };

  listagemDeAgendamentosController.prototype.selecionarData = function(event, data) {
    var ancora;
    ancora = $(event.delegateTarget);
    return this.scrollItemToTop('#reunioes_' + ancora.attr('id'));
  };

  listagemDeAgendamentosController.prototype.scrollItemToTop = function(seletor) {
    var altura, offsetTarget;
    altura = 100;
    offsetTarget = $(seletor).offset();
    if ($(seletor).length > 0) {
      return $('html, body').animate({
        scrollTop: offsetTarget.top - altura
      }, 300);
    }
  };

  listagemDeAgendamentosController.prototype.setarEspacoEmBrancoParaScroll = function() {
    var currentDate, height;
    if (this.options.existeAgendamentoHoje) {
      height = $(window).height() - 304 + "px";
    } else {
      height = $(window).height() - 268 + "px";
    }
    $('#EspacoEmBrancoProScroll').css('height', height);
    currentDate = null;
    if (currentDate !== null && $(currentDate).length) {
      return this.scrollItemToTop(currentDate);
    } else {
      return this.scrollItemToTop("#SpanHoje");
    }
  };

  return listagemDeAgendamentosController;

})(window.baseController);

window.Agendamento || (window.Agendamento = {});

window.Agendamento.reload = function() {
  return Agenda.api.listar();
};

window.Agendamento.removerItem = function(id) {
  var $div;
  $div = $("div[agd-id=" + id + "]");
  $div.hide(800);
  return $div.next('hr').hide();
};
