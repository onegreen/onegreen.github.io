﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.AssuntosDoAgendamentoController = (function(superClass) {
  extend(AssuntosDoAgendamentoController, superClass);

  function AssuntosDoAgendamentoController(view, options, resource) {
    this.view = view;
    this.options = options;
    this.resource = resource;
    this.AbrirPlanoDeAcao = bind(this.AbrirPlanoDeAcao, this);
    this.AdicionarAtividade = bind(this.AdicionarAtividade, this);
    this.MoverAssuntoParaBaixo = bind(this.MoverAssuntoParaBaixo, this);
    this.MoverAssuntoParaCima = bind(this.MoverAssuntoParaCima, this);
    this.AdicionarAssunto = bind(this.AdicionarAssunto, this);
    this.SalvarAssunto = bind(this.SalvarAssunto, this);
    this.VerificaTrAnterior = bind(this.VerificaTrAnterior, this);
    this.VerificaProximoTr = bind(this.VerificaProximoTr, this);
    this.CallBackListagemPlanoDeAcao = bind(this.CallBackListagemPlanoDeAcao, this);
    AssuntosDoAgendamentoController.__super__.constructor.call(this, this.view, null);
    (this.get('input')).placeholder();
    (this.get('[rel=tooltip]')).tooltip();
    (this.get('textarea')).TextAreaExpander(25);
    $(this.view).on({
      keydown: (function(_this) {
        return function(e) {
          return _this.VerificaProximoTr(e, $(e.currentTarget));
        };
      })(this)
    }, '.comentario');
    $(this.view).on({
      keydown: (function(_this) {
        return function(e) {
          return _this.VerificaTrAnterior(e, $(e.currentTarget));
        };
      })(this)
    }, '.js-descricao');
    $(this.view).on({
      change: (function(_this) {
        return function(e) {
          return _this.SalvarAssunto($(e.currentTarget).parents('.assunto'));
        };
      })(this)
    }, 'tr :input[type=text]:not(.js-add-tarefa), textarea');
    $('.planosdeacao').on('shown', function() {
      return this.AbrirPlanoDeAcao($(this).attr('planodeacao-id'), $(this).attr('assunto-id'));
    });
    window.ListagemPlanoDeAcaoCallback = this.CallBackListagemPlanoDeAcao;
    window.planosDeAcaoAbertos = [];
    $('[rel=tooltip]').tooltip();
  }

  AssuntosDoAgendamentoController.prototype.CallBackListagemPlanoDeAcao = function(id, qtd) {
    var containerQtd;
    containerQtd = '#qtdTarefas' + id + ' > span';
    return $(containerQtd).html(qtd);
  };

  AssuntosDoAgendamentoController.prototype.VerificaProximoTr = function(e, $el) {
    var $input, $proximoTr, code;
    code = e.keyCode || e.which;
    if (code === 9 && !e.shiftKey) {
      $proximoTr = $el.parents('.assunto').next();
      if ($proximoTr.length) {
        $input = $proximoTr.find(".js-descricao");
        $input.focus();
        return false;
      }
    }
  };

  AssuntosDoAgendamentoController.prototype.VerificaTrAnterior = function(e, $el) {
    var $input, $trAnterior, code;
    code = e.keyCode || e.which;
    if (code === 9 && e.shiftKey) {
      $trAnterior = $el.parents('.assunto').prev();
      if ($trAnterior.length) {
        $input = $trAnterior.find(".comentario");
        $input.focus();
        return false;
      }
    }
  };

  AssuntosDoAgendamentoController.prototype.SalvarAssunto = function($trAssunto) {
    if ($trAssunto.find('.js-descricao').val() === '') {
      $trAssunto.find('.js-descricao').val(this.resource.SemNome);
    }
    maxlength.verificarTamanhoTexto($trAssunto.find('.comentario'));
    return $as.Agenda.Assuntos.SaveOnChange.post($('textarea, :input', $trAssunto).serialize()).done((function(_this) {
      return function(data) {
        var novoId;
        $trAssunto.find('#acoes').html(data);
        novoId = $(data).find('#Id').val();
        $trAssunto.find('.js-descricao').removeAttr('onchange');
        $trAssunto.find('#ordenacao').find('i').attr('data-id', novoId);
        $trAssunto.find('#ordenacao').show();
        $trAssunto.find('#ordenacao').addClass('excluir');
        $trAssunto.attr('id', novoId);
        $trAssunto.find('.plano-acao-assuntos').attr('id', 'container-inner-acoes-assunto-' + novoId);
        $trAssunto.find('.container-acoes-assunto').attr('id', 'container-acoes-assunto-' + novoId);
        $('input', '#assuntos-table').placeholder();
        swIntercom('Adicionou/editou assunto na reuniao');
        if (typeof Events !== "undefined" && Events !== null) {
          Events.Track.NotifyEvent('CreateEdit', 'Assunto', 'Salvar');
        }
        return window.agendamentoController.VerificarNecessidadeDeConvocacao();
      };
    })(this));
  };

  AssuntosDoAgendamentoController.prototype.AdicionarAssunto = function(focusNoNovoAssunto) {
    var $input;
    $input = $('#assuntos-table tr:last-child').find(".js-descricao");
    if ($input.val() === '') {
      return $input.focus();
    } else {
      return $as.Agenda.Assuntos.ItemAssunto.get({
        idDoAgendamento: this.options.IdDoAgendamento,
        ordem: this.options.Ordem
      }).done((function(_this) {
        return function(data) {
          $('#assuntos-tbody').append(data);
          $('#assuntos-table').find('textarea').TextAreaExpander();
          _this.options.Ordem++;
          if (focusNoNovoAssunto) {
            return $input.focus();
          }
        };
      })(this));
    }
  };

  AssuntosDoAgendamentoController.prototype.MoverAssuntoParaCima = function(seta) {
    return $as.Agenda.Assuntos.MoverAssuntoParaCima.get({
      idAssunto: $(seta).attr('data-id')
    }).done(function(data) {
      swIntercom('Moveu assunto para cima');
      return $("#assuntosagd-container").html(data);
    });
  };

  AssuntosDoAgendamentoController.prototype.MoverAssuntoParaBaixo = function(seta) {
    return $as.Agenda.Assuntos.MoverAssuntoParaBaixo.get({
      idAssunto: $(seta).attr('data-id')
    }).done(function(data) {
      swIntercom('Moveu assunto para baixo');
      return $("#assuntosagd-container").html(data);
    });
  };

  AssuntosDoAgendamentoController.prototype.AdicionarAtividade = function(idAssunto) {
    var $container, idPlanoDeAcao;
    $container = $('#container-acoes-assunto-' + idAssunto);
    idPlanoDeAcao = $('#PlanoDeAcao_Id').val();
    if (!$container.is(':visible')) {
      this.AbrirPlanoDeAcao(idAssunto);
    }
    $('.js-DescricaoTarefaSimples', $container).focus();
    return this.EsconderIconeInformacoes();
  };

  AssuntosDoAgendamentoController.prototype.AbrirPlanoDeAcao = function(idAssunto) {
    var $container, idPlanoDeAcao;
    idPlanoDeAcao = $('#PlanoDeAcao_Id').val();
    $container = $('#container-acoes-assunto-' + idAssunto);
    if (!$container.is(':visible')) {
      if (window.planosDeAcaoAbertos[idAssunto] === null || !window.planosDeAcaoAbertos[idAssunto]) {
        return $as.Atividades.PlanosDeAcao.IndexPorObjeto.get({
          idDoPlanoDeAcao: idPlanoDeAcao,
          idObjeto: idAssunto,
          tipoObjeto: 'PortalSIM.Domain.Agenda.Assunto'
        }).done((function(_this) {
          return function(data) {
            window.planosDeAcaoAbertos[idAssunto] = true;
            $container.html(data);
            $container.show();
            _this.EsconderIconeInformacoes();
            return swIntercom('Abriu plano de acao para visualizacao');
          };
        })(this));
      } else {
        $container.show();
        return this.EsconderIconeInformacoes();
      }
    } else {
      return $container.hide();
    }
  };

  AssuntosDoAgendamentoController.prototype.EsconderIconeInformacoes = function() {
    return $('.js-buscar-informacoes-atividade').hide();
  };

  return AssuntosDoAgendamentoController;

})(window.baseController);
