﻿var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

window.apresentacaoDePaineisListagemEditController = (function(_super) {
  __extends(apresentacaoDePaineisListagemEditController, _super);

  function apresentacaoDePaineisListagemEditController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.ativarEventosItens = __bind(this.ativarEventosItens, this);
    this.moverParaBaixo = __bind(this.moverParaBaixo, this);
    this.moverParaCima = __bind(this.moverParaCima, this);
    this.configurarItens = __bind(this.configurarItens, this);
    this.excluirItemConfirmado = __bind(this.excluirItemConfirmado, this);
    this.excluirItem = __bind(this.excluirItem, this);
    this.alterarDuracao = __bind(this.alterarDuracao, this);
    this.alterarAtraso = __bind(this.alterarAtraso, this);
    this.recarregarListagemDeItens = __bind(this.recarregarListagemDeItens, this);
    this.adicionarItem = __bind(this.adicionarItem, this);
    this.verificarBloqueiosDaAdicao = __bind(this.verificarBloqueiosDaAdicao, this);
    this.selecionarTemplate = __bind(this.selecionarTemplate, this);
    this.templateKeyPress = __bind(this.templateKeyPress, this);
    this.esconderSelecaoDeTemplate = __bind(this.esconderSelecaoDeTemplate, this);
    this.selecionarPrimeiroTemplate = __bind(this.selecionarPrimeiroTemplate, this);
    this.loadAdicaoRapida = __bind(this.loadAdicaoRapida, this);
    this.comboUnidadesGerenciais = __bind(this.comboUnidadesGerenciais, this);
    this.adicionarUnidade = __bind(this.adicionarUnidade, this);
    this.alterarUnidadePrincipal = __bind(this.alterarUnidadePrincipal, this);
    this.comboUnidade = __bind(this.comboUnidade, this);
    this.alterarPublico = __bind(this.alterarPublico, this);
    this.salvarNome = __bind(this.salvarNome, this);
    this.load = __bind(this.load, this);
    apresentacaoDePaineisListagemEditController.__super__.constructor.call(this, this.view, this.model);
    this.currentNoty = null;
    this.load();
    this.comboUnidadesGerenciais();
  }

  apresentacaoDePaineisListagemEditController.prototype.load = function() {
    $('#filtro-ug-topo').hide();
    this.get(".js-Nome").change(this.salvarNome);
    this.get(".js-Nome").focus();
    this.get('#Publico-Nao').click(this.alterarPublico);
    this.get('#Publico-Sim').click(this.alterarPublico);
    this.comboUnidade();
    this.loadAdicaoRapida();
    this.configurarItens();
    this.get('[title]').tooltip();
    return window.MarcarMenuSuperior("#lnkApresentacoes");
  };

  apresentacaoDePaineisListagemEditController.prototype.salvarNome = function(event) {
    var apresentacao;
    apresentacao = {
      id: this.options.Id,
      nome: $(event.delegateTarget).val()
    };
    return $as.ReportSIM.ApresentacoesDePaineis.SalvarNome.postJson(JSON.stringify(apresentacao)).done((function(_this) {
      return function(html) {
        return _this.get('#validation-nome-container').html(html);
      };
    })(this));
  };

  apresentacaoDePaineisListagemEditController.prototype.alterarPublico = function(event) {
    var containerPublico, containerUnidades, publico;
    publico = this.get('#Publico-Sim').is(':checked');
    containerPublico = this.get('#mostrador-publica');
    containerUnidades = this.get('#mostrador-unidades, #unidades-visualizam-apresentacao');
    if (publico) {
      containerUnidades.fadeOut();
      containerPublico.fadeIn();
    } else {
      containerUnidades.fadeIn();
      containerPublico.fadeOut();
    }
    return $as.ReportSIM.ApresentacoesDePaineis.AlterarPublico.post({
      idDaApresentacao: this.options.Id,
      publico: publico
    });
  };

  apresentacaoDePaineisListagemEditController.prototype.comboUnidade = function() {
    return setCombo(this.options.SeletorContexto, '#UnidadeGerencial_SiglaAtual', this.alterarUnidadePrincipal);
  };

  apresentacaoDePaineisListagemEditController.prototype.alterarUnidadePrincipal = function(item) {
    return $as.ReportSIM.ApresentacoesDePaineis.AlterarUnidadePrincipal.post({
      idDaApresentacao: this.options.Id,
      idUnidade: item.val()
    }).done((function(_this) {
      return function() {
        return _this.get('#configuracao-nome-unidade').text(_this.get('#UnidadeGerencial_SiglaAtual').val());
      };
    })(this));
  };

  apresentacaoDePaineisListagemEditController.prototype.adicionarUnidade = function(item) {
    return $as.ReportSIM.ApresentacoesDePaineis.AdicionarUnidade.post({
      idDaApresentacao: this.options.Id,
      idUnidade: item.Id
    }).done((function(_this) {
      return function() {
        return _this.get('#mostrador-unidades').append("<span id='mostrador-listaDeDistribuicao-" + item.Id + "' class='label label-default mrs'>" + item.Nome + "</span>");
      };
    })(this));
  };

  apresentacaoDePaineisListagemEditController.prototype.comboUnidadesGerenciais = function() {
    var $combo, $divCombo, idApresentacao, unidadesGerenciaisViewModel;
    idApresentacao = this.options.Id;
    unidadesGerenciaisViewModel = {
      unidadesGerenciais: ko.observableArray(this.options.unidadesGerenciais),
      removeUnidade: function(item) {
        this.unidadesGerenciais.remove(item);
        $as.ReportSIM.ApresentacoesDePaineis.RemoverUnidade.post({
          idDaApresentacao: idApresentacao,
          idUnidade: item.Id
        });
        return $("#mostrador-unidade-" + item.Id).remove();
      }
    };
    window.unidadesGerenciaisViewModel = unidadesGerenciaisViewModel;
    ko.applyBindings(unidadesGerenciaisViewModel, this.get('#unidadesGerenciais_itens')[0]);
    $combo = this.get('#UnidadesGerenciaisCombo');
    $divCombo = $combo.parents('div.autocompleter');
    return $combo.autocompleter($divCombo.attr('data-url'), {
      elementToClick: '#UnidadesGerenciaisComboBtn',
      multiSelectArray: unidadesGerenciaisViewModel.unidadesGerenciais,
      onSelected: this.adicionarUnidade,
      multiSelectElement: '#unidadesGerenciais_itens'
    });
  };

  apresentacaoDePaineisListagemEditController.prototype.loadAdicaoRapida = function() {
    this.template = this.get("#template");
    this.modalSelecaoTemplate = this.get('#modal-smart');
    this.inputNome = this.get('#nome-painel-apresentacao');
    this.inputAtraso = this.get('#atraso-item-apresentacao');
    this.inputDuracao = this.get('#duracao-item-apresentacao');
    this.botaoAdicionarPainel = this.get('#botao-adicionar-painel');
    this.template.focusin(this.selecionarPrimeiroTemplate);
    this.template.click(this.selecionarPrimeiroTemplate);
    this.inputAtraso.focusin(this.esconderSelecaoDeTemplate);
    this.inputNome.keyup(this.verificarBloqueiosDaAdicao);
    this.inputAtraso.keyup(this.verificarBloqueiosDaAdicao);
    this.inputDuracao.keyup(this.verificarBloqueiosDaAdicao);
    $('.js-template-para-selecao', this.modalSelecaoTemplate).keydown(this.templateKeyPress);
    $('.js-template-para-selecao', this.modalSelecaoTemplate).focusin(this.selecionarTemplate);
    $('.js-template-para-selecao', this.modalSelecaoTemplate).unbind('click').click((function(_this) {
      return function(event) {
        _this.selecionarTemplate(event);
        return _this.esconderSelecaoDeTemplate();
      };
    })(this));
    this.get('#botao-adicionar-painel').unbind('click').click(this.adicionarItem);
    this.ativarEventosItens();
    return this.verificarBloqueiosDaAdicao();
  };

  apresentacaoDePaineisListagemEditController.prototype.selecionarPrimeiroTemplate = function(event) {
    event.preventDefault();
    event.stopPropagation();
    this.modalSelecaoTemplate.addClass("active");
    if (this.selectedTemplateContainer) {
      return this.selectedTemplateContainer.focus();
    } else {
      return $(".js-template-para-selecao:first", this.modalSelecaoTemplate).focus();
    }
  };

  apresentacaoDePaineisListagemEditController.prototype.esconderSelecaoDeTemplate = function() {
    return $("#modal-smart").removeClass("active");
  };

  apresentacaoDePaineisListagemEditController.prototype.templateKeyPress = function(event) {
    event.preventDefault();
    event.stopPropagation();
    switch (event.keyCode || event.which) {
      case KeyCodes.Enter:
      case KeyCodes.Tab:
      case KeyCodes.Escape:
        this.inputNome.focus();
        return this.esconderSelecaoDeTemplate();
      case KeyCodes.ArrowDown:
        return this.selectedTemplateContainer.parent().next().next().next().next().find('a').focus();
      case KeyCodes.ArrowUp:
        return this.selectedTemplateContainer.parent().prev().prev().prev().prev().find('a').focus();
      case KeyCodes.RigthArrow:
        return this.selectedTemplateContainer.parent().next().find('a').focus();
      case KeyCodes.ArrowLeft:
        return this.selectedTemplateContainer.parent().prev().find('a').focus();
    }
  };

  apresentacaoDePaineisListagemEditController.prototype.selecionarTemplate = function(event) {
    var src;
    this.selectedTemplateContainer = $(event.delegateTarget);
    src = $('img', this.selectedTemplateContainer).attr('src');
    $('img', this.template).attr('src', src);
    return this.template.data('id', this.selectedTemplateContainer.data('id'));
  };

  apresentacaoDePaineisListagemEditController.prototype.verificarBloqueiosDaAdicao = function() {
    var bloqueado, item;
    item = {
      Painel: {
        Nome: this.inputNome.val(),
        Template: {
          Id: this.template.data('id')
        }
      },
      Atraso: this.inputAtraso.val(),
      Duracao: this.inputDuracao.val(),
      ApresentacoesDePaineis: {
        Id: this.options.Id
      }
    };
    bloqueado = false;
    bloqueado = bloqueado || !item.Atraso.length || isNaN(item.Atraso) || parseInt(item.Atraso) < 0 || parseInt(item.Atraso) > 1460;
    bloqueado = bloqueado || !item.Duracao.length || isNaN(item.Duracao) || parseInt(item.Duracao) < 10 || parseInt(item.Duracao) > 1000;
    bloqueado = bloqueado || !item.Painel.Nome.length;
    if (bloqueado) {
      this.botaoAdicionarPainel.addClass('c-cinza');
      return false;
    } else {
      this.botaoAdicionarPainel.removeClass('c-cinza');
      return item;
    }
  };

  apresentacaoDePaineisListagemEditController.prototype.adicionarItem = function() {
    var item;
    item = this.verificarBloqueiosDaAdicao();
    if (item) {
      return $as.ReportSIM.ApresentacoesDePaineis.AdicionarItem.postJson(JSON.stringify(item)).done((function(_this) {
        return function(html) {
          _this.get('#itensdaapresentacaodepainel-container').html(html);
          _this.inputNome.val('');
          _this.inputNome.focus();
          return _this.configurarItens();
        };
      })(this));
    }
  };

  apresentacaoDePaineisListagemEditController.prototype.recarregarListagemDeItens = function() {
    return $as.ReportSIM.ApresentacoesDePaineis.MostrarItens.post({
      id: this.options.Id
    }).done((function(_this) {
      return function(html) {
        _this.get('#itensdaapresentacaodepainel-container').html(html);
        return _this.configurarItens();
      };
    })(this));
  };

  apresentacaoDePaineisListagemEditController.prototype.alterarAtraso = function(event) {
    var id, input, valorNovo;
    input = $(event.delegateTarget);
    valorNovo = input.val();
    id = input.closest('li').data('id');
    return $as.ReportSIM.ItensDaApresentacaoDePainel.AlterarAtraso.post({
      id: id,
      valor: valorNovo
    }).done((function(_this) {
      return function(result) {
        input.val(result.valor);
        if (!result.alterado) {
          return input.focus();
        }
      };
    })(this));
  };

  apresentacaoDePaineisListagemEditController.prototype.alterarDuracao = function(event) {
    var id, input, valorNovo;
    input = $(event.delegateTarget);
    valorNovo = input.val();
    id = input.closest('li').data('id');
    return $as.ReportSIM.ItensDaApresentacaoDePainel.AlterarDuracao.post({
      id: id,
      valor: valorNovo
    }).done((function(_this) {
      return function(result) {
        input.val(result.valor);
        if (!result.valido) {
          $('#validacao-duracao').show();
          input.parent().addClass('error');
          return input.focus();
        } else {
          $('#validacao-duracao').hide();
          return input.parent().removeClass('error');
        }
      };
    })(this));
  };

  apresentacaoDePaineisListagemEditController.prototype.excluirItem = function(event) {
    var id;
    id = $(event.delegateTarget).closest('li').data('id');
    return Confirmacao.mostrar(Resource.DesejaRealmenteExcluirEsteRegistro, (function(_this) {
      return function() {
        return _this.excluirItemConfirmado(id);
      };
    })(this));
  };

  apresentacaoDePaineisListagemEditController.prototype.excluirItemConfirmado = function(id) {
    return $as.ReportSIM.ItensDaApresentacaoDePainel.ExcluirItem.post({
      id: id
    }).done(this.recarregarListagemDeItens);
  };

  apresentacaoDePaineisListagemEditController.prototype.configurarItens = function() {
    this.ativarEventosItens();
    return $("[rel=tooltip]").tooltip();
  };

  apresentacaoDePaineisListagemEditController.prototype.moverParaCima = function(event) {
    return $as.ReportSIM.ItensDaApresentacaoDePainel.MoverParaCima.post({
      id: $(event.delegateTarget).closest('li').data('id')
    }).done(this.recarregarListagemDeItens);
  };

  apresentacaoDePaineisListagemEditController.prototype.moverParaBaixo = function(event) {
    return $as.ReportSIM.ItensDaApresentacaoDePainel.MoverParaBaixo.post({
      id: $(event.delegateTarget).closest('li').data('id')
    }).done(this.recarregarListagemDeItens);
  };

  apresentacaoDePaineisListagemEditController.prototype.ativarEventosItens = function() {
    this.get('.js-MoverParaCima').unbind('click').click(this.moverParaCima);
    this.get('.js-MoverParaBaixo').unbind('click').click(this.moverParaBaixo);
    this.get('.js-MoverParaCima').first().addClass('disabled').unbind('click');
    this.get('.js-MoverParaBaixo').last().addClass('disabled').unbind('click');
    this.get('.js-atraso-item').change(this.alterarAtraso);
    this.get('.js-duracao-item').change(this.alterarDuracao);
    return this.get('.js-excluir-item-apresentacao').unbind('click').click(this.excluirItem);
  };

  return apresentacaoDePaineisListagemEditController;

})(window.baseController);
