﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.avaliacaoDeDesempenhoController = (function() {
  function avaliacaoDeDesempenhoController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.relatorioDePlanosDeAcao = bind(this.relatorioDePlanosDeAcao, this);
    this.activeLista = bind(this.activeLista, this);
    this.activeCard = bind(this.activeCard, this);
    this.recarregar = bind(this.recarregar, this);
    this.carregarLista = bind(this.carregarLista, this);
    this.obterParametros = bind(this.obterParametros, this);
    this.bindTrocaDeUsuario = bind(this.bindTrocaDeUsuario, this);
    this.bindTrocaDeCiclo = bind(this.bindTrocaDeCiclo, this);
    this.carregarComboDeUsuarios = bind(this.carregarComboDeUsuarios, this);
    this.alterarPlanoDeGestao = bind(this.alterarPlanoDeGestao, this);
    this.bindAcoesListagem = bind(this.bindAcoesListagem, this);
    this.$contexto = $(this.contexto);
    this.carregarComboDeUsuarios();
    this.bindTrocaDeCiclo();
    this.bindTrocaDeUsuario();
    this.bindAcoesListagem();
    window.filtroUGEPlanoDeGestao.configurar('#filtro-ug-topo', null, this.alterarPlanoDeGestao);
    $("#filtro-ug-topo").show();
    $('#link-adicionar').hide();
    $('#link-filtro-avancado').hide();
    $('#filtro-ug-geral').hide();
    $('#separador-filtro-ug-geral').hide();
    $('[rel=tooltip]').tooltip();
    this.configurarRelatorioPlanosDeAcao();
    this.obterParametorStatico = this.obterParametros;
  }

  avaliacaoDeDesempenhoController.prototype.bindAcoesListagem = function() {
    this.$contexto.find("#link-card").click(this.activeCard);
    this.$contexto.find("#link-lista").click(this.activeLista);
    this.$contexto.find("#link-relatorioPlanoDeAcao").click(this.relatorioDePlanosDeAcao);
    setDropDown(this.contexto, '#Ordenacao-dropdown', this.carregarLista);
    return this.$contexto.find("input:radio[name=TipoDeOrdenacao]").change(this.carregarLista);
  };

  avaliacaoDeDesempenhoController.prototype.alterarPlanoDeGestao = function(idDoPlanoDeGestao) {
    return $as.Performance.FiltroDeIndicadores.MudarPlanoDeGestao.post({
      idDoPlanoDeGestao: idDoPlanoDeGestao
    }, {
      global: false
    }).done(function(data) {
      swIntercom('Mudou de plano de gestão pela Avaliação de Desempenho');
      return window.reload();
    });
  };

  avaliacaoDeDesempenhoController.prototype.carregarComboDeUsuarios = function() {
    return setCombo(this.contexto, '#Usuario_Nome', this.recarregar);
  };

  avaliacaoDeDesempenhoController.prototype.bindTrocaDeCiclo = function() {
    return this.$contexto.find('.js-ciclo-avaliacao').click((function(_this) {
      return function() {
        var id;
        id = $( this ).data('id');
        return _this.recarregar(id);
      };
    })(this));
  };

  avaliacaoDeDesempenhoController.prototype.bindTrocaDeUsuario = function() {
    this.$contexto.find("#trocar-usuario").click((function(_this) {
      return function() {
        _this.$contexto.find("#container-trocar-usuario").removeClass("none");
        return $( this ).addClass("none");
      };
    })(this));
    return this.$contexto.find("#cancelar-trocar-usuario").click((function(_this) {
      return function() {
        _this.$contexto.find("#container-trocar-usuario").addClass("none");
        return _this.$contexto.find("#trocar-usuario").removeClass("none");
      };
    })(this));
  };

  avaliacaoDeDesempenhoController.prototype.obterParametros = function(idDoCicloDeAvaliacao, idDoUsuarioSuperior, exibirModoLista, exibirRelatorioPlanosDeAcao, ordenacao) {
    var parameters;
    return parameters = {
      idDoCicloDeAvaliacao: idDoCicloDeAvaliacao === void 0 || isNaN(idDoCicloDeAvaliacao) ? this.$contexto.find("#IdDoCicloDeAvaliacao").val() : idDoCicloDeAvaliacao,
      idDoUsuarioSuperior: idDoUsuarioSuperior === void 0 || isNaN(idDoUsuarioSuperior) ? this.$contexto.find("#Usuario_Id").val() : idDoUsuarioSuperior,
      exibirModoLista: exibirModoLista === void 0 ? this.$contexto.find("#ExibirModoLista").val() : exibirModoLista,
      exibirRelatorioPlanosDeAcao: exibirRelatorioPlanosDeAcao === void 0 ? this.$contexto.find("#ExibirRelatorioPlanosDeAcao").val() : exibirRelatorioPlanosDeAcao,
      ordenacao: ordenacao === void 0 ? this.$contexto.find("#Ordenacao").val() : ordenacao
    };
  };

  avaliacaoDeDesempenhoController.prototype.carregarLista = function() {
    var parameters;
    parameters = this.obterParametros();
    return $as.Performance.AvaliacoesDeDesempenho.ListaOuCardsDosColaboradores.get(parameters).done((function(_this) {
      return function(data) {
        return _this.$contexto.find("#colaboradores-container").html(data);
      };
    })(this));
  };

  avaliacaoDeDesempenhoController.prototype.recarregar = function(idDoCicloDeAvaliacao, idDoUsuarioSuperior, exibirModoLista, exibirRelatorioPlanosDeAcao, ordenacao) {
    var parameters;
    parameters = this.obterParametros(idDoCicloDeAvaliacao, idDoUsuarioSuperior, exibirModoLista, exibirRelatorioPlanosDeAcao, ordenacao);
    return $as.Performance.AvaliacoesDeDesempenho.Index.get(parameters).done((function(_this) {
      return function(data) {
        return $("#view-index-avaliacaoDeDesempenho").html(data);
      };
    })(this));
  };

  avaliacaoDeDesempenhoController.prototype.activeCard = function() {
    this.$contexto.find("#ExibirModoLista").val("false");
    this.$contexto.find("#ExibirRelatorioPlanosDeAcao").val("false");
    $('[rel=tooltip]').tooltip();
    this.$contexto.find("#link-lista").removeClass("active");
    this.$contexto.find("#link-relatorioPlanoDeAcao").removeClass("active");
    this.$contexto.find("#link-card").addClass("active");
    this.$contexto.find("#link-relatorioPlanoDeAcaoCsv").hide();
    this.$contexto.find("#ordenacao-avaliacao").show();
    return this.carregarLista();
  };

  avaliacaoDeDesempenhoController.prototype.activeLista = function() {
    this.$contexto.find("#ExibirModoLista").val("true");
    this.$contexto.find("#ExibirRelatorioPlanosDeAcao").val("false");
    this.$contexto.find("#link-card").removeClass("active");
    this.$contexto.find("#link-relatorioPlanoDeAcao").removeClass("active");
    this.$contexto.find("#link-lista").addClass("active");
    this.$contexto.find("#link-relatorioPlanoDeAcaoCsv").hide();
    this.$contexto.find("#ordenacao-avaliacao").show();
    return this.carregarLista();
  };

  avaliacaoDeDesempenhoController.prototype.ativarRelatorioPlanosDeAcao = function() {
    this.$contexto.find("#link-lista").removeClass("active");
    this.$contexto.find("#link-card").removeClass("active");
    this.$contexto.find("#link-relatorioPlanoDeAcao").addClass("active");
    this.$contexto.find("#link-relatorioPlanoDeAcaoCsv").show();
    this.$contexto.find("#ordenacao-avaliacao").hide();
    $('#close-modal-atividade', $('#atividade-modal')).click();
    return this.$contexto.find("#link-relatorioPlanoDeAcaoCsv").unbind('click').click(function() {
      return $('#submitPlanosDeAcaoCsv').click();
    });
  };

  avaliacaoDeDesempenhoController.prototype.configurarRelatorioPlanosDeAcao = function() {
    var exibirRelatorioPlanosDeAcao;
    exibirRelatorioPlanosDeAcao = this.$contexto.find("#ExibirRelatorioPlanosDeAcao").val();
    if (exibirRelatorioPlanosDeAcao === 'false') {
      return this.$contexto.find("#link-relatorioPlanoDeAcaoCsv").hide();
    } else {
      return this.ativarRelatorioPlanosDeAcao();
    }
  };

  avaliacaoDeDesempenhoController.prototype.relatorioDePlanosDeAcao = function() {
    var parameters;
    this.ativarRelatorioPlanosDeAcao();
    parameters = this.obterParametros();
    return $as.Performance.AvaliacoesDeDesempenho.RelatorioDePlanosDeAcaoIndividuais.get(parameters).done((function(_this) {
      return function(data) {
        _this.$contexto.find("#ExibirRelatorioPlanosDeAcao").val("true");
        return _this.$contexto.find("#colaboradores-container").html(data);
      };
    })(this));
  };

  return avaliacaoDeDesempenhoController;

})();
