﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.itensDoDesdobramentoController = (function() {
  function itensDoDesdobramentoController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.loadComboIndicador = bind(this.loadComboIndicador, this);
    this.loadComboUnidadeGerencial = bind(this.loadComboUnidadeGerencial, this);
    $(this.contexto).window();
    this.loadComboUnidadeGerencial();
    if ($('#UnidadeGerencial_Id', this.contexto).val() !== '') {
      this.loadComboIndicador($('#UnidadeGerencial_Id', this.contexto).val());
    }
  }

  itensDoDesdobramentoController.prototype.loadComboUnidadeGerencial = function() {
    var aoSelecionar;
    aoSelecionar = (function(_this) {
      return function(input) {
        $("#Indicador_Id", _this.contexto).val('');
        $("#Indicador_Nome", _this.contexto).val('');
        return _this.loadComboIndicador($(input).val());
      };
    })(this);
    return setCombo(this.contexto, '#UnidadeGerencial_SiglaAtual', aoSelecionar);
  };

  itensDoDesdobramentoController.prototype.loadComboIndicador = function(idUnidadeGerencial, idPlanoGestao) {
    var parametros;
    parametros = {
      idUnidadeGerencial: idUnidadeGerencial
    };
    return Results.api.setComboIndicador(this.contexto, '#Indicador_Nome', null, parametros);
  };

  return itensDoDesdobramentoController;

})();
