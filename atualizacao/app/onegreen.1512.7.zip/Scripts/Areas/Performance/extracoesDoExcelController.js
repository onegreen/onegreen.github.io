﻿(function() {
  var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  window.extracoesDoExcelController = (function() {
    function extracoesDoExcelController(contexto, resource, options) {
      this.contexto = contexto;
      this.resource = resource;
      this.options = options;
      this.aoSelecionarArquivo = __bind(this.aoSelecionarArquivo, this);
      this.verificarArquivoSelecionado = __bind(this.verificarArquivoSelecionado, this);
      this.removerValidacao = __bind(this.removerValidacao, this);
      this.encaminharParaEdicao = __bind(this.encaminharParaEdicao, this);
      this.editarModelo = __bind(this.editarModelo, this);
      this.esconderExibirBtnProximoSalvar = __bind(this.esconderExibirBtnProximoSalvar, this);
      this.exibirEsconderSelecaoDeModelo = __bind(this.exibirEsconderSelecaoDeModelo, this);
      this.modeloExistente = __bind(this.modeloExistente, this);
      this.novoModelo = __bind(this.novoModelo, this);
      this.modeloNovoOuExistente = __bind(this.modeloNovoOuExistente, this);
      this.aoSalvar = __bind(this.aoSalvar, this);
      this.exibirLogs = __bind(this.exibirLogs, this);
      this.verificarFormaDeImportacaoSemData = __bind(this.verificarFormaDeImportacaoSemData, this);
      this.exibirLoadCarregamento = __bind(this.exibirLoadCarregamento, this);
      this.bind = __bind(this.bind, this);
      this.mostrarEsconderArquivo = __bind(this.mostrarEsconderArquivo, this);
      this.esconderBotoesRodapeModal = __bind(this.esconderBotoesRodapeModal, this);
      this.avancarOuRetornar = __bind(this.avancarOuRetornar, this);
      this.salvar = __bind(this.salvar, this);
      this.configurarDatePickerFarolMensal = __bind(this.configurarDatePickerFarolMensal, this);
      this.configurarDatePickerFarolSemana = __bind(this.configurarDatePickerFarolSemana, this);
      this.configurarDatePickerFarolDiario = __bind(this.configurarDatePickerFarolDiario, this);
      $('#importacao-excel-modal').show();
      $('#documento-anexado').hide();
      $('#btnEditarModelo').hide();
      $('#btnRecarregarTela').hide();
      if (this.options.Frequencia === 'Diaria') {
        this.configurarDatePickerFarolDiario('datadosvalores');
      } else if (this.options.Frequencia === 'Mensal') {
        this.configurarDatePickerFarolMensal('datadosvalores');
      } else {
        this.configurarDatePickerFarolSemana('datadosvalores');
      }
      this.esconderExibirBtnProximoSalvar(true);
      this.bind();
    }

    extracoesDoExcelController.prototype.configurarDatePickerFarolDiario = function(idInput) {
      return $("#" + idInput).datepicker({
        orientation: "top auto",
        autoclose: true,
        forceParse: true,
        calendarWeeks: false
      });
    };

    extracoesDoExcelController.prototype.configurarDatePickerFarolSemana = function(idInput) {
      return $("#" + idInput).datepicker({
        orientation: "top auto",
        autoclose: true,
        forceParse: true,
        calendarWeeks: true,
        daysOfWeekDisabled: "1,2,3,4,5,6"
      });
    };

    extracoesDoExcelController.prototype.configurarDatePickerFarolMensal = function(idInput) {
      return $("#" + idInput).datepicker({
        orientation: "top auto",
        autoclose: true,
        forceParse: true,
        calendarWeeks: false,
        minViewMode: 'months',
        maxViewMode: 'months'
      });
    };

    extracoesDoExcelController.prototype.salvar = function(e) {
      var erros, summary;
      erros = "";
      $('ul', '#js-summary', this.contexto).empty();
      $('#js-summary', this.contexto).removeClass('validation-summary-errors');
      if ($('#Nome-NomeDoArquivoExtracaoExcel', this.contexto).text() === "") {
        erros += '<li>' + this.resource.OCampoNomeDoArquivoEObrigatorio + '</li>';
        $('#NomeDoArquivoExtracaoExcel', this.contexto).parents('.form-group', this.contexto).addClass('error');
      } else {
        $('#NomeDoArquivoExtracaoExcel', this.contexto).parents('.form-group', this.contexto).removeClass('error');
      }
      if ($('#ModeloDeImportacaoDeExcel_Nome', this.contexto).val() === "") {
        erros += '<li>' + this.resource.OCampoModeloEObrigatorio + '</li>';
        $('#selecionarModelo', this.contexto).addClass('error');
      } else {
        $('#selecionarModelo', this.contexto).removeClass('error');
      }
      if ($('.js-informe-a-data').is(':visible')) {
        if ($('#datadosvalores', this.contexto).val() === "") {
          erros += '<li>' + this.resource.OCampoDataEObrigatorio + '</li>';
          $('.js-informe-a-data', this.contexto).addClass('error');
        } else {
          $('.js-informe-a-data', this.contexto).removeClass('error');
        }
      }
      erros = "";
      if (erros !== "") {
        summary = $('.validation-summary-errors', this.contexto);
        if (summary.length === 0) {
          summary = $('#js-summary', this.contexto);
          $('#js-summary', this.contexto).addClass('validation-summary-errors');
        }
        $('ul', summary).append(erros);
        return false;
      } else {
        return this.exibirLoadCarregamento();
      }
    };

    extracoesDoExcelController.prototype.avancarOuRetornar = function(esconder, exibir) {
      esconder.hide();
      return exibir.show();
    };

    extracoesDoExcelController.prototype.esconderBotoesRodapeModal = function() {
      return $('.modal-footer .btn', this.contexto).hide();
    };

    extracoesDoExcelController.prototype.mostrarEsconderArquivo = function(mostrar) {
      if (mostrar !== void 0) {
        if (mostrar) {
          return $('#spanFileUpload').show();
        } else {
          return $('#spanFileUpload').hide();
        }
      } else {
        if ($('#spanFileUpload:visible').length === 0) {
          return $('#spanFileUpload').show();
        } else {
          return $('#spanFileUpload').hide();
        }
      }
    };

    extracoesDoExcelController.prototype.escolherFrequencia = function() {
      var frequencia, texto;
      frequencia = $( this ).eq(0).data('frequencia');
      texto = $( this ).eq(0).text();
      $('#dropdown-frequencia').text(texto);
      return $('#frequencia').val(frequencia);
    };

    extracoesDoExcelController.prototype.bind = function() {
      $('#spanFileUpload [type="file"]').on('click', $('#documento-anexado').hide());
      $('#close-modal-importacao-excel').on('click', function() {
        return $('#spanFileUpload').hide();
      });
      setCombo(this.contexto, '#ModeloDeImportacaoDeExcel_Nome', this.verificarFormaDeImportacaoSemData);
      $('ul>li>a[data-frequencia]', this.contexto).on('click', this.escolherFrequencia);
      return $('#box-TipoImportacao label', this.contexto).on('click', this.escolherTipoImportacao);
    };

    extracoesDoExcelController.prototype.exibirLoadCarregamento = function() {
      $('[data-passo]').hide();
      $('[data-passo="final"]').show();
      $('#spanFileUpload').hide();
      this.esconderBotoesRodapeModal();
      return this.removerValidacao();
    };

    extracoesDoExcelController.prototype.verificarFormaDeImportacaoSemData = function(data) {
      var idModelo;
      idModelo = $(data.selector).val();
      $as.Performance.ModeloDeImportacaoDeExcel.VerificarFormaDeImportacaoSemData.get({
        idModelo: idModelo
      }).done((function(_this) {
        return function(data) {
          if (data) {
            return $('#infomarDataPlanilha', _this.contexto).show();
          } else {
            return $('#infomarDataPlanilha', _this.contexto).hide();
          }
        };
      })(this));
      $('#btnEditarModelo').show();
      return $('#btnExcluirModelo').hide();
    };

    extracoesDoExcelController.prototype.exibirLogs = function(response) {
      $('[data-passo="log"]').html(response);
      this.avancarOuRetornar($("[data-passo='final']"), $("[data-passo='log']"));
      $('#BotaoCancelar--0-0', this.contexto).show();
      $('#btnRecarregarTela').show();
      return $('#importacao-excel-modal').show();
    };

    extracoesDoExcelController.prototype.aoSalvar = function(data) {
      var btns;
      $('#importacao-excel-modal').hide();
      this.dataLogs = data.data.responseLogs;
      if (data.data.responseSemDados.length > 0) {
        return showBottomNoty(data.data.responseSemDados);
      } else if (data.data.responseLogs.length > 0) {
        btns = [
          {
            addClass: 'btn btn-primary',
            text: this.resource.RecarregarATela,
            onClick: (function(_this) {
              return function($noty) {
                $noty.close();
                return location.reload();
              };
            })(this)
          }, {
            addClass: 'btn btn-default',
            text: this.resource.VerLogDeErros,
            onClick: (function(_this) {
              return function($noty) {
                $noty.close();
                return _this.exibirLogs(_this.dataLogs);
              };
            })(this)
          }
        ];
        return showBottomNoty(this.resource.OcorreramAlgunsErrosDuranteAImportacao, 15000, btns);
      } else {
        btns = [
          {
            addClass: 'btn btn-primary',
            text: this.resource.SimRecarregarAgora,
            onClick: (function(_this) {
              return function($noty) {
                $noty.close();
                return location.reload();
              };
            })(this)
          }, {
            addClass: 'btn btn-default',
            text: this.resource.AgoraNao,
            onClick: (function(_this) {
              return function($noty) {
                return $noty.close();
              };
            })(this)
          }
        ];
        return showBottomNoty(this.resource.DadosImportadosComSucessoDesejaRecarregarAPagina, 15000, btns);
      }
    };

    extracoesDoExcelController.prototype.modeloNovoOuExistente = function(el) {
      var opcao;
      opcao = $(el).data('novo');
      if (opcao) {
        this.novoModelo();
        $('#btnEditarModelo', this.contexto).hide();
        $('#btnExcluirModelo', this.contexto).hide();
        return $('.js-informe-a-data', this.contexto).hide();
      } else {
        this.modeloExistente();
        $('.js-informe-a-data', this.contexto).show();
        if ($('#ModeloDeImportacaoDeExcel_Id', this.contexto).val() !== "" && $('#ModeloDeImportacaoDeExcel_Id', this.contexto).val() !== '0') {
          $('#btnEditarModelo', this.contexto).show();
          return $('#btnExcluirModelo', this.contexto).hide();
        }
      }
    };

    extracoesDoExcelController.prototype.novoModelo = function() {
      this.exibirEsconderSelecaoDeModelo(false);
      return this.esconderExibirBtnProximoSalvar(true);
    };

    extracoesDoExcelController.prototype.modeloExistente = function() {
      this.exibirEsconderSelecaoDeModelo(true);
      return this.esconderExibirBtnProximoSalvar(false);
    };

    extracoesDoExcelController.prototype.exibirEsconderSelecaoDeModelo = function(exibir) {
      if (exibir) {
        return $('#selecionarModelo').show();
      } else {
        return $('#selecionarModelo').hide();
      }
    };

    extracoesDoExcelController.prototype.esconderExibirBtnProximoSalvar = function(novoModelo) {
      if (novoModelo) {
        $('#btnProximo', this.contexto).show();
        return $('#BotaoSalvar--0-0', this.contexto).hide();
      } else {
        $('#btnProximo', this.contexto).hide();
        return $('#BotaoSalvar--0-0', this.contexto).show();
      }
    };

    extracoesDoExcelController.prototype.editarModelo = function() {
      return FileUpload.upload(this.encaminharParaEdicao);
    };

    extracoesDoExcelController.prototype.encaminharParaEdicao = function(nomeDoArquivo) {
      console.log(nomeDoArquivo);
      return $as.Performance.ModeloDeImportacaoDeExcel.VerificarDocumentoSelecionado.post({
        NomeDoArquivo: nomeDoArquivo
      }).done((function(_this) {
        return function(data) {
          var idModelo;
          if (data.success) {
            idModelo = $('#ModeloDeImportacaoDeExcel_Id').val();
            return $as.Performance.ModeloDeImportacaoDeExcel.CreateEdit.get({
              idModelo: idModelo,
              nomeDoArquivo: nomeDoArquivo,
              nomeDoModelo: $('#Nome', _this.contexto).val()
            }).done(function(data) {
              $('#alternative-modal-container').html(data);
              $(_this.contexto).hide();
              $("[date-picker]").setMask();
              $('#btnExcluirModelo').hide();
              $('#FileName').val(nomeDoArquivo);
              return $('#NomeDoArquivo').val($('#Nome', _this.contexto).val());
            });
          } else {
            return $('#main-modal').html(data);
          }
        };
      })(this));
    };

    extracoesDoExcelController.prototype.removerValidacao = function() {
      $('.form-group.error', this.contexto).removeClass('error');
      return $('.validation-summary-errors', this.contexto).hide();
    };

    extracoesDoExcelController.prototype.selecionarNovoModelo = function() {
      if ($('#importacaoTipoModeloNovo').is(':checked')) {
        return FileUpload.upload(this.verificarArquivoSelecionado);
      }
    };

    extracoesDoExcelController.prototype.verificarArquivoSelecionado = function(nomeDoArquivo) {
      return $as.Performance.ModeloDeImportacaoDeExcel.VerificarDocumentoSelecionado.post({
        NomeDoArquivo: nomeDoArquivo
      }).done((function(_this) {
        return function(data) {
          if (data.success) {
            return $as.Performance.ModeloDeImportacaoDeExcel.CreateEdit.get({
              idModelo: null,
              nomeDoArquivo: nomeDoArquivo,
              nomeDoModelo: $('#Nome', _this.contexto).val()
            }).done(function(modal) {
              $('#alternative-modal-container').html(modal);
              $('#btnExcluirModelo').hide();
              $('#FileName').val(nomeDoArquivo);
              return $('#NomeDoArquivo').val($('#Nome', _this.contexto).val());
            });
          } else {
            return $('#main-modal').html(data);
          }
        };
      })(this));
    };

    extracoesDoExcelController.prototype.aoSelecionarArquivo = function() {
      var nomeArquivo;
      nomeArquivo = $('#NomeDoArquivo').val();
      nomeArquivo = nomeArquivo.substring(nomeArquivo.indexOf('_') + 1, nomeArquivo.indexOf('.'));
      return $as.Performance.ModeloDeImportacaoDeExcel.SugerirModeloDeImportacaoPorNomeDoArquivo.get({
        nomeArquivo: nomeArquivo
      }).done((function(_this) {
        return function(data) {
          var idModelo;
          if (data !== null) {
            $("#ModeloDeImportacaoDeExcel_Nome").setValueAutocompleter(data.Id, data.Nome);
            $('[for="importacaoTipoModeloExistente"]').click();
            idModelo = data.Id;
            return $as.Performance.ModeloDeImportacaoDeExcel.VerificarFormaDeImportacaoSemData.get({
              idModelo: idModelo
            }).done(function(data) {
              if (data) {
                return $('#infomarDataPlanilha', _this.contexto).show();
              } else {
                return $('#infomarDataPlanilha', _this.contexto).hide();
              }
            });
          }
        };
      })(this));
    };

    return extracoesDoExcelController;

  })();

}).call(this);
