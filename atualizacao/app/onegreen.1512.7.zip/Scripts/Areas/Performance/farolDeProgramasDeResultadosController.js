﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.farolDeProgramasDeResultadosController = (function(superClass) {
  extend(farolDeProgramasDeResultadosController, superClass);

  function farolDeProgramasDeResultadosController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.bindTrocaDeUsuario = bind(this.bindTrocaDeUsuario, this);
    this.recarregarFarolMensal = bind(this.recarregarFarolMensal, this);
    this.recarregar = bind(this.recarregar, this);
    this.aplicarValoresFarolMensal = bind(this.aplicarValoresFarolMensal, this);
    this.alterarMes = bind(this.alterarMes, this);
    this.alterarUsuario = bind(this.alterarUsuario, this);
    this.alterarPrograma = bind(this.alterarPrograma, this);
    this.obterValoresMes = bind(this.obterValoresMes, this);
    this.carregarComboDeUsuarios = bind(this.carregarComboDeUsuarios, this);
    this.alterarFormaDeVisualizacao = bind(this.alterarFormaDeVisualizacao, this);
    this.alterarPlanoDeGestao = bind(this.alterarPlanoDeGestao, this);
    farolDeProgramasDeResultadosController.__super__.constructor.call(this, this.options, true);
    this.carregarComboDeUsuarios();
    this.bindTrocaDeUsuario();
    if (this.options.NotaInvalida) {
      $('#nota-invalida').show();
      $('#container-nota').addClass('bg-atrasada');
    } else {
      $('#container-nota').addClass('bg-primario');
    }
    $('.js-comutador-frequencia').find('[role=presentation]').click(this.alterarFormaDeVisualizacao);
    window.reloadBrowser = window.reload;
    window.reload = this.recarregar;
    window.filtroUGEPlanoDeGestao.configurar('#filtro-ug-topo', null, this.alterarPlanoDeGestao);
    $(this.contexto).find('#link-programas-inativos').click((function(_this) {
      return function() {
        var $contexto;
        $contexto = $(_this.contexto);
        $contexto.find('#container-programas-inativos').show();
        return $contexto.find('#mensagem-programas-inativos').hide();
      };
    })(this));
    $(this.contexto).find('#link-programas-invalidos').click((function(_this) {
      return function() {
        var $contexto;
        $contexto = $(_this.contexto);
        $contexto.find('.container-programas-invalidos').show();
        return $contexto.find('#mensagem-programas-invalidos').hide();
      };
    })(this));
  }

  farolDeProgramasDeResultadosController.prototype.alterarPlanoDeGestao = function(idDoPlanoDeGestao) {
    this.options.Filtro.IdDoPlanoDeGestao = idDoPlanoDeGestao;
    return $as.Performance.FarolDeProgramasDeResultados.AlterarPlanoDeGestao.post(this.options.Filtro).done(function(data) {
      if (data.success) {
        return window.reloadBrowser();
      }
    });
  };

  farolDeProgramasDeResultadosController.prototype.alterarFormaDeVisualizacao = function(event) {
    this.options.Filtro.FormaDeVisualizacao = $(event.delegateTarget).data("visualizacao");
    console.log($(event.delegateTarget));
    this.options.Filtro.FarolAcumulado = false;
    this.options.Filtro.FarolTendencia = false;
    return this.recarregar();
  };

  farolDeProgramasDeResultadosController.prototype.carregarComboDeUsuarios = function() {
    var funcao;
    funcao = (function(_this) {
      return function() {
        return _this.alterarUsuario();
      };
    })(this);
    return setCombo(this.contexto, '#Usuario_Nome', funcao);
  };

  farolDeProgramasDeResultadosController.prototype.obterValoresMes = function(event) {
    this.options.mesSelecionado = $(event.delegateTarget).data("mes");
    this.options.Filtro.Mes = this.options.mesSelecionado;
    this.colorirLinhas(this.linhaSelecionada);
    return this.recarregarFarolMensal();
  };

  farolDeProgramasDeResultadosController.prototype.alterarPrograma = function(idDoPrograma) {
    this.options.Filtro.IdDoPrograma = idDoPrograma;
    return this.recarregar();
  };

  farolDeProgramasDeResultadosController.prototype.alterarUsuario = function() {
    this.options.Filtro.IdDoUsuario = $('#Usuario_Id').val();
    return this.recarregar();
  };

  farolDeProgramasDeResultadosController.prototype.alterarMes = function() {
    return $as.Performance.FarolDeProgramasDeResultados.MudarMes.post(this.options.Filtro).done((function(_this) {
      return function(dados) {
        return _this.aplicarValoresFarolMensal(dados);
      };
    })(this));
  };

  farolDeProgramasDeResultadosController.prototype.aplicarValoresFarolMensal = function(dados) {
    var farol, grupo, grupos, i, id, j, len, len1, linha, linhas, referencia, results, textoMeta, textoNota, textoPeso, textoPontuacao, textoReal, valor, valores;
    valores = dados.valores;
    $('#lblPontuacao').text(dados.total);
    grupos = $('.js-pontuacao');
    for (i = 0, len = grupos.length; i < len; i++) {
      grupo = grupos[i];
      id = $(grupo).data('id');
      $(grupo).text(dados.pontuacaoPorGrupo[id]);
    }
    linhas = $('.js-farol');
    if (this.options.Filtro.FarolTendencia) {
      $('#TabelaCabecalhoFarol').find('#toggleReal').addClass('none');
      $('#TabelaCabecalhoFarol').find('#toggleTendencia').removeClass('none');
    } else {
      $('#TabelaCabecalhoFarol').find('#toggleReal').removeClass('none');
      $('#TabelaCabecalhoFarol').find('#toggleTendencia').addClass('none');
    }
    results = [];
    for (j = 0, len1 = linhas.length; j < len1; j++) {
      linha = linhas[j];
      linha = $(linha);
      valor = valores[linha.data('referencia')];
      if (!valor) {
        valor = {
          TextoReal: "-",
          TextoMeta: "-",
          TextoPercentual: "-",
          TextoMetaInferior: "-",
          TextoMetaSuperior: "-"
        };
      }
      textoReal;
      textoMeta;
      textoPeso = '-';
      textoNota = '-';
      textoPontuacao = '-';
      if (this.options.Filtro.FarolTendencia) {
        textoReal = valor.TextoRealizadoRitmo;
      } else {
        textoReal = valor.TextoReal;
      }
      if ($('.js-farol-meta', linha).data('entrefaixas')) {
        if (this.options.Filtro.FarolTendencia) {
          textoMeta = "" + valor.TextoMetaInferiorDaTendencia + "<br/>" + valor.TextoMetaSuperiorDaTendencia;
        } else {
          textoMeta = "" + valor.TextoMetaInferior + "<br/>" + valor.TextoMetaSuperior;
        }
      } else {
        if (this.options.Filtro.FarolTendencia) {
          textoMeta = valor.TextoMetaRitmo;
        } else {
          textoMeta = valor.TextoMeta;
        }
      }
      $('.js-farol-real', linha).html(textoReal);
      $('.js-farol-meta', linha).html(textoMeta);
      $('.js-farol-peso', linha).html(valor.TextoPeso);
      $('.js-farol-nota', linha).html(valor.TextoNota);
      $('.js-farol-pontuacao', linha).html(valor.TextoPontuacao);
      if (!valor.PossuiApenasReal) {
        results.push((function() {
          var ref, results1;
          ref = valor.Farois;
          results1 = [];
          for (referencia in ref) {
            farol = ref[referencia];
            $(".js-valor-" + referencia + " .js-cor-farol", linha).attr('class', "sw-farol0" + (farol.substring(1)) + " font14 va-middle js-cor-farol");
            $('.js-farol-acumulado .js-cor-farol', linha).attr('class', "sw-farol0" + (valor.Farois['FarolAcumulado'].substring(1)) + " font14 va-middle js-cor-farol");
            results1.push($('.js-farol-ritmo .js-cor-farol', linha).attr('class', "sw-farol0" + (valor.Farois['FarolRitmo'].substring(1)) + " font14 va-middle js-cor-farol"));
          }
          return results1;
        })());
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  farolDeProgramasDeResultadosController.prototype.recarregar = function() {
    return $as.Performance.FarolDeProgramasDeResultados.Index.post(this.options.Filtro).done(function(html) {
      return $('#main').html(html);
    });
  };

  farolDeProgramasDeResultadosController.prototype.recarregarFarolMensal = function() {
    this.options.Filtro.FarolAcumulado = this.farolAcumulado;
    this.options.Filtro.FarolTendencia = this.farolTendencia;
    return this.alterarMes();
  };

  farolDeProgramasDeResultadosController.prototype.bindTrocaDeUsuario = function() {
    $(this.contexto).find("#trocar-usuario").click((function(_this) {
      return function() {
        $(_this.contexto).find("#container-trocar-usuario").removeClass("none");
        return $(_this.contexto).find("#trocar-usuario").addClass("none");
      };
    })(this));
    return $(this.contexto).find("#cancelar-trocar-usuario").click((function(_this) {
      return function() {
        $(_this.contexto).find("#container-trocar-usuario").addClass("none");
        return $(_this.contexto).find("#trocar-usuario").removeClass("none");
      };
    })(this));
  };

  return farolDeProgramasDeResultadosController;

})(window.farolBaseController);
