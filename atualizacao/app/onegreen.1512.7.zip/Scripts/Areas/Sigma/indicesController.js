﻿window.indicesController = (function() {
  function indicesController() {}

  indicesController.configurarVoltar = function() {
    return window.VoltarERecarregar = function() {
      return $as.Sigma.Indices.Index.post().success(function(data) {
        return $('#main').html(data);
      });
    };
  };

  return indicesController;

})();
