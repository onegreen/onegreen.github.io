﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.Atividades || (this.Atividades = {});

Atividades.resumoDasTarefasController = (function() {
  function resumoDasTarefasController(contexto, resource) {
    this.contexto = contexto;
    this.resource = resource;
    this.loadComboResponsavel = bind(this.loadComboResponsavel, this);
    this.loadComboUnidade = bind(this.loadComboUnidade, this);
    this.loadComboPlanoDeGestao = bind(this.loadComboPlanoDeGestao, this);
    this.aoSelecionarPlanoDeGestao = bind(this.aoSelecionarPlanoDeGestao, this);
    this.listarTarefas = bind(this.listarTarefas, this);
    this.tratarCamposDeData = bind(this.tratarCamposDeData, this);
    this.bloquearCampoDeData = bind(this.bloquearCampoDeData, this);
    this.configurarDatePickers = bind(this.configurarDatePickers, this);
    this.montarSeries = bind(this.montarSeries, this);
    this.montarCategorias = bind(this.montarCategorias, this);
    this.plotarGrafico = bind(this.plotarGrafico, this);
    this.configurarGrafico = bind(this.configurarGrafico, this);
    this.esconderAcoesDoTopo = bind(this.esconderAcoesDoTopo, this);
    this.loadComboPlanoDeGestao();
    this.loadComboUnidade();
    this.loadComboResponsavel();
    this.configurarDatePickers();
    this.esconderAcoesDoTopo();
    $(".js-grafico-das-tarefas", "#tabela-do-resumo-das-acoes").click(this.configurarGrafico);
    $("input[name='radio-tipo-de-grafico']", "#modal-de-graficos").change(function() {
      return $(".js-grafico-percentual-ou-quantidade").toggle(1000);
    });
    $('[rel="tooltip"]').tooltip();
    MarcarMenuSuperior("#lnkResumoDasAcoes");
  }

  resumoDasTarefasController.prototype.esconderAcoesDoTopo = function() {
    $('#filtro-ug-topo').hide();
    $('#link-filtro-avancado').hide();
    return $('#link-adicionar').hide();
  };

  resumoDasTarefasController.prototype.configurarGrafico = function(e) {
    var categorias, options, series;
    options = $(e.delegateTarget).data("options");
    categorias = this.montarCategorias(options);
    series = this.montarSeries(options);
    this.plotarGrafico(options, categorias, series, "#grafico-percentual", "percent");
    this.plotarGrafico(options, categorias, series, "#grafico-quantidade", "column");
    return $("#modal-de-graficos").window({
      width: 620
    });
  };

  resumoDasTarefasController.prototype.plotarGrafico = function(options, categories, series, container, stacking) {
    var config;
    config = ModelosDeGrafico.api.getConfig({
      categories: categories,
      showGriX: 1,
      showGriY: 1,
      nomeEixoY1: '',
      nomeEixoY2: '',
      titulo: options.titulo,
      bgColor: 'default',
      unit: '',
      stacking: stacking,
      type: 'column',
      legendaAbaixo: '',
      tooltipNotShared: true
    });
    return ModelosDeGrafico.api.build(container, config, series);
  };

  resumoDasTarefasController.prototype.montarCategorias = function(options) {
    var categorias;
    categorias = [this.resource.Planejadas, this.resource.EmExecucao, this.resource.Finalizadas];
    return categorias;
  };

  resumoDasTarefasController.prototype.montarSeries = function(options) {
    var series;
    series = [
      {
        name: this.resource.NoPrazo,
        data: [
          {
            y: options.planejadas.noPrazo,
            descricao: options.planejadas.noPrazo,
            name: this.resource.NoPrazo
          }, {
            y: options.emExecucao.noPrazo,
            descricao: options.emExecucao.noPrazo,
            name: this.resource.NoPrazo
          }, {
            y: options.finalizada.noPrazo,
            descricao: options.finalizada.noPrazo,
            name: this.resource.NoPrazo
          }
        ],
        color: "#7cbc29",
        type: "column",
        yAxis: 1
      }, {
        name: this.resource.Atrasadas,
        color: "#e31b23",
        data: [
          {
            y: options.planejadas.atrasadas,
            descricao: options.planejadas.atrasadas,
            name: this.resource.Atrasadas
          }, {
            y: options.emExecucao.atrasadas,
            descricao: options.emExecucao.atrasadas,
            name: this.resource.Atrasadas
          }, {
            y: options.finalizada.atrasadas,
            descricao: options.finalizada.atrasadas,
            name: this.resource.Atrasadas
          }
        ],
        type: "column",
        yAxis: 1
      }, {
        name: this.resource.Total,
        data: [
          {
            y: 0,
            descricao: '',
            name: this.resource.Planejadas
          }, {
            y: 0,
            descricao: '',
            name: this.resource.EmExecucao
          }, {
            y: 0,
            descricao: '',
            name: this.resource.Finalizadas
          }
        ],
        type: "column",
        showInLegend: false,
        yAxis: 1
      }
    ];
    return series;
  };

  resumoDasTarefasController.prototype.configurarDatePickers = function() {
    $("#DataInicialParaFiltrarOFimPrevisto", this.contexto).datepicker();
    $("#DataFinalParaFiltrarOFimPrevisto", this.contexto).datepicker();
    $("#DataInicialParaFiltrarOFimRealizado", this.contexto).datepicker();
    $("#DataFinalParaFiltrarFimRealizado", this.contexto).datepicker();
    this.tratarCamposDeData("#DataInicialParaFiltrarOFimPrevisto", "#DataFinalParaFiltrarOFimPrevisto");
    this.tratarCamposDeData("#DataInicialParaFiltrarOFimRealizado", "#DataFinalParaFiltrarFimRealizado");
    $("#DataInicialParaFiltrarOFimPrevisto", this.contexto).on('change', (function(_this) {
      return function() {
        return _this.tratarCamposDeData("#DataInicialParaFiltrarOFimPrevisto", "#DataFinalParaFiltrarOFimPrevisto");
      };
    })(this));
    return $("#DataInicialParaFiltrarOFimRealizado", this.contexto).on('change', (function(_this) {
      return function() {
        return _this.tratarCamposDeData("#DataInicialParaFiltrarOFimRealizado", "#DataFinalParaFiltrarFimRealizado");
      };
    })(this));
  };

  resumoDasTarefasController.prototype.bloquearCampoDeData = function(campo, bloquear) {
    if (bloquear) {
      $(campo, this.contexto).attr('disabled', 'disabled');
      return $(campo, this.contexto).val('');
    } else {
      return $(campo, this.contexto).removeAttr('disabled');
    }
  };

  resumoDasTarefasController.prototype.tratarCamposDeData = function(inicio, fim) {
    var dataDeInicioEstaVazia, valorDaDataDeInicio;
    dataDeInicioEstaVazia = $(inicio, this.contexto).val().trim() === '';
    if (dataDeInicioEstaVazia) {
      return this.bloquearCampoDeData(fim, true);
    } else {
      valorDaDataDeInicio = $(inicio, this.contexto).data('datepicker').getFormattedDate();
      $(fim, this.contexto).datepicker('setStartDate', valorDaDataDeInicio);
      return this.bloquearCampoDeData(fim, false);
    }
  };

  resumoDasTarefasController.prototype.listarTarefas = function(json) {
    return $as.Atividades.ResumoDasTarefas.ObterListagemDasTarefas.post(json).success((function(_this) {
      return function(data) {
        $("#main-modal").html(data);
      };
    })(this));
  };

  resumoDasTarefasController.prototype.aoSelecionarPlanoDeGestao = function(input) {
    $("#NomeDaUnidadeGerencial", this.contexto).val('');
    $("#IdDaUnidadeGerencial", this.contexto).val('');
    return this.loadComboUnidade(input.val());
  };

  resumoDasTarefasController.prototype.loadComboPlanoDeGestao = function() {
    return setCombo(this.contexto, "#NomeDoPlanoDeGestao", this.aoSelecionarPlanoDeGestao);
  };

  resumoDasTarefasController.prototype.loadComboUnidade = function(idDoPlanoDeGestao) {
    var parametros;
    if (!idDoPlanoDeGestao) {
      idDoPlanoDeGestao = $("#IdDoPlanoDeGestao", this.contexto).val();
    }
    parametros = {
      idDoPlanoDeGestao: idDoPlanoDeGestao
    };
    return setCombo(this.contexto, "#NomeDaUnidadeGerencial", null, parametros);
  };

  resumoDasTarefasController.prototype.loadComboResponsavel = function() {
    return setCombo(this.contexto, "#NomeDoUsuarioResponsavel");
  };

  return resumoDasTarefasController;

})();
