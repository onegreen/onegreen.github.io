﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.listagemDeGruposResponsaveisPorAprovacaoEVerificacaoController = (function() {
  function listagemDeGruposResponsaveisPorAprovacaoEVerificacaoController(contexto) {
    this.contexto = contexto;
    this.carregarCombos = bind(this.carregarCombos, this);
    this.carregarCombos();
  }

  listagemDeGruposResponsaveisPorAprovacaoEVerificacaoController.prototype.carregarCombos = function() {
    setCombo(this.contexto, "#NomeDaUnidade", null);
    setCombo(this.contexto, "#NomeDaOrigem", null);
    return setCombo(this.contexto, "#NomeDoMetodo", null);
  };

  return listagemDeGruposResponsaveisPorAprovacaoEVerificacaoController;

})();
