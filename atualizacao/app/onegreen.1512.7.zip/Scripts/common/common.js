﻿var objetoNavegador;

Math.log10 || (Math.log10 = function(x) {
  return Math.round(Math.log(x) / Math.LN10);
});

window.swIntercom = function() {
  var _args;
  _args = Array.prototype.slice.call(arguments);
  _args.splice(0, 0, 'trackEvent');
  if ('Intercom' in window) {
    setTimeout((function() {
      window.Intercom.apply(null, _args);
    }), 20);
  }
};

window.setFoco = function(campo) {
  var campoFoco;
  campoFoco = campo;
  if (campoFoco != null) {
    setTimeout(function() {
      return campoFoco.focus();
    }, 5);
  }
};

window.adicionarErroPorNomeDoInput = function(erros, contexto) {
  var i, input, _i, _len, _ref;
  _ref = erros.length;
  for (_i = 0, _len = _ref.length; _i < _len; _i++) {
    i = _ref[_i];
    input = $('input[name=\'' + erros[i].nome + '\']', contexto);
    input.parent().addClass('error');
    input.attr('data-original-title', erros[i].erro);
    input.tooltip();
  }
};

window.removerErroPorNomeDoInput = function(inputs) {
  var i, _i, _len, _ref;
  _ref = inputs.length;
  for (_i = 0, _len = _ref.length; _i < _len; _i++) {
    i = _ref[_i];
    $(inputs[i]).parent.removeClass('error');
    $(inputs[i]).removeClass('inputError');
    $(inputs[i]).attr('data-original-title', '');
    $(inputs[i]).tooltip();
  }
};

window.MarcarMenuSuperior = function(idDoMenu) {
  $('li', $(idDoMenu).parents('ul')).removeClass('active');
  $(idDoMenu).parent().addClass('active');
};

window.MostrarMensagemAviso = function(msg) {
  $("#MensagemDeErro-Business", "#modalErroBusiness").text(msg);
  $("#modalErroBusiness").modal();
};

window.GetDiv = function(id) {
  if ($('#' + id).length === 0) {
    $('body').append('<div id=\'' + id + '\'></div>');
  }
  return $('#' + id);
};

window.reload = function() {
  window.location.reload(true);
};

window.definirMascaraDecimal = function($el, precisao) {
  return $el.keypress(function(e) {
    return window.setarMascaraDecimal(e);
  }).change(function(e) {
    var target, valor;
    target = e.target || e.srcElement;
    valor = window.FormatarNumero($(target).val(), precisao);
    if (valor === '' || !isNaN(parseInt(valor))) {
      $(target).val(valor);
    }
  });
};

window.setarMascaraDecimal = (function(_this) {
  return function(e) {
    var keycode, target;
    target = e.target || e.srcElement;
    keycode = e.charCode || e.keyCode;
    return window.VerificarValor(target, keycode);
  };
})(this);

window.parseFloatCulture = function(value) {
  if ($('html').attr('lang') === 'pt') {
    value = value.replace('.', '').replace(',', '.');
  }
  return parseFloat(value);
};

window.formatNumberCulture = function(value, precision) {
  value = String(Number(value).toFixed(precision));
  if ($('html').attr('lang') === 'pt') {
    value = value.replace(',', '').replace('.', ',');
  }
  return value;
};

window.FormatarNumero = function(value, digits) {
  var CntLocal, DecimalSeparator, DecimalSeparator2, GroupSeparator, TmpNewValue, TmpReturnValue, ValorAtual, digitos, i, tSignal, tValue, tmpNum, tmpRtn, tmpValue;
  if (value === '') {
    return '';
  }
  tSignal = "";
  if (String(value).indexOf("-") >= 0) {
    value = String(value).replace("-", "");
    tSignal = "-";
  }
  digitos = 2;
  ValorAtual = new String(value);
  tmpValue = new String();
  tmpNum = new String();
  DecimalSeparator = ",";
  GroupSeparator = ".";
  DecimalSeparator2 = ".";
  if ($('html').attr('lang') === 'en') {
    DecimalSeparator = ".";
    GroupSeparator = ",";
  }
  while (ValorAtual.indexOf(GroupSeparator) > 0) {
    ValorAtual = ValorAtual.replace(GroupSeparator, "");
  }
  ValorAtual = String(ValorAtual).replace(DecimalSeparator, DecimalSeparator2);
  tValue = new Number(ValorAtual);
  tValue = tValue.toFixed(digits);
  tmpValue = tValue;
  tmpValue = tmpValue.replace(DecimalSeparator2, DecimalSeparator);
  TmpReturnValue = new String(tmpValue);
  TmpNewValue = new String();
  CntLocal = 1;
  tmpRtn = String(TmpReturnValue).split(DecimalSeparator);
  TmpReturnValue = tmpRtn[0];
  i = TmpReturnValue.length;
  while (i > 0) {
    TmpNewValue = TmpReturnValue.charAt(i - 1) + TmpNewValue;
    if (CntLocal === 3 && i > 1) {
      TmpNewValue = GroupSeparator + TmpNewValue;
      CntLocal = 0;
    }
    CntLocal += 1;
    i--;
  }
  if (digits > 0) {
    TmpNewValue += DecimalSeparator + tmpRtn[1];
  }
  if (String(TmpNewValue).length > 0) {
    tmpValue = TmpNewValue;
  }
  return tSignal + tmpValue;
};

window.VerificarValor = function(object, keycode, unsigned, integer) {
  var NUM_DECIMAIS, codigoSeparador, estaAEsquerdaDaVirgula, evento_key, numPosCursor, numPosVirgula, numeroDeDigitosAntesDaVirgula, retorno, strParteDecimal, strParteInteira, valorCampo;
  if (object.value === void 0) {
    return false;
  }
  valorCampo = object.value;
  evento_key = keycode;
  if (unsigned !== void 0 && unsigned && evento_key === 45) {
    evento_key = null;
  }
  numPosVirgula = 0;
  numPosCursor = object.selectionStart;
  strParteInteira = "";
  strParteDecimal = "";
  NUM_DECIMAIS = 10;
  retorno = true;
  codigoSeparador = window.separadorDecimal === "," ? 44 : 46;
  numeroDeDigitosAntesDaVirgula = Math.floor(Math.log10(parseInt(valorCampo.replace(/\./g, ''))) + 1);
  switch (evento_key) {
    case 45:
    case 48:
    case 49:
    case 50:
    case 51:
    case 52:
    case 53:
    case 54:
    case 55:
    case 56:
    case 57:
      break;
    case codigoSeparador:
      if (valorCampo === "" || (integer !== void 0 && integer)) {
        evento_key = 0;
        retorno = false;
      }
      break;
      break;
    default:
      evento_key = 0;
      retorno = false;
  }
  if (evento_key === codigoSeparador) {
    if (valorCampo.indexoOf(",") !== -1) {
      evento_key = 0;
      retorno = false;
    }
  }
  if ((numPosVirgula = valorCampo.indexOf(window.separadorDecimal)) !== -1) {
    estaAEsquerdaDaVirgula = object.selectionStart <= numPosVirgula;
    strParteInteira = valorCampo.substr(0, numPosVirgula - 1);
    strParteDecimal = valorCampo.substr(numPosVirgula + 1, valorCampo.length);
    if (estaAEsquerdaDaVirgula) {
      if (numeroDeDigitosAntesDaVirgula > 10) {
        retorno = false;
      }
    }
    if (strParteDecimal.length > (NUM_DECIMAIS - 1)) {
      evento_key = 0;
      retorno = false;
    }
  } else {
    if (numeroDeDigitosAntesDaVirgula > 10) {
      retorno = evento_key === codigoSeparador ? true : false;
    }
  }
  return retorno;
};

window.EmailValido = function(email) {
  var filter, valido;
  filter = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
  valido = filter.test(email);
  return valido;
};

$.fn.scrollTo = function(target, options, callback) {
  var settings;
  if (typeof options === 'function' && arguments.length === 2) {
    callback = options;
    options = target;
  }
  settings = $.extend({
    scrollTarget: target,
    offsetTop: 50,
    duration: 500,
    easing: 'swing'
  }, options);
  return this.each(function() {
    var scrollPane, scrollTarget, scrollY;
    scrollPane = $(this);
    scrollTarget = typeof settings.scrollTarget === "number" ? settings.scrollTarget : $(settings.scrollTarget);
    scrollY = typeof scrollTarget === "number" ? scrollTarget : scrollTarget.offset().top + scrollPane.scrollTop() - parseInt(settings.offsetTop);
    scrollPane.animate({
      scrollTop: scrollY
    }, parseInt(settings.duration), settings.easing, function() {
      if (typeof callback === 'function') {
        callback.call(this);
      }
    });
  });
};

window.getFunctionFromString = function(string) {
  var fn, parts;
  parts = string.split(".");
  fn = window;
  while (fn && parts.length) {
    fn = fn[parts.shift()];
  }
  if (typeof fn === "function") {
    return fn;
  }
};

window.IE8GarbageCollect = function() {
  if ((navigator.appVersion.indexOf("MSIE 8") !== -1) && (typeof CollectGarbage === "function")) {
    CollectGarbage();
  }
};

window.CreateEventoDoFacilitador = function(contexto, nomeDoFacilitador, idDoInput, fn) {
  window[nomeDoFacilitador] = {
    aoSalvar: function(data) {
      $(idDoInput).setValueAutocompleter(data.data.key, data.data.nome, fn);
      $(contexto).hide();
      if (fn) {
        fn(data);
      }
    }
  };
};

window.isNullOrEmpty = function(string) {
  if (string === 'undefined' || (string == null) || string === "") {
    return true;
  } else {
    return false;
  }
};

window.repeatString = function(string, quantidade) {
  var i, response;
  response = "";
  i = 0;
  while (i < quantidade) {
    response = response + string;
    i++;
  }
  return response;
};

window.animate1 = function(canvasName, elementSelector, spinnerName, speed, layer, strokeWidth, radius, spinnerColor) {
  var x;
  try {
    $('#' + canvasName, elementSelector).animateLayer(spinnerName, {
      start: 0,
      end: 90,
      rotate: '+=360'
    }, speed, 'linear', function(layer) {
      $(this).animateLayer(layer, {
        start: 0,
        end: 359,
        rotate: '+=360'
      }, speed, 'linear', animate2(canvasName, elementSelector, spinnerName, speed, true, strokeWidth, radius, spinnerColor));
    });
  } catch (_error) {
    x = _error;
  }
};

window.animate2 = function(canvasName, elementSelector, spinnerName, speed, layer, strokeWidth, radius, spinnerColor) {
  var x;
  try {
    $('#' + canvasName, elementSelector).animateLayer(spinnerName, {
      start: 90,
      end: 180,
      rotate: '+=360'
    }, speed, 'linear', function(layer) {
      $(this).animateLayer(layer, {
        start: 90,
        end: 449,
        rotate: '+=360'
      }, speed, 'linear', animate3(canvasName, elementSelector, spinnerName, speed, true, strokeWidth, radius, spinnerColor));
    });
  } catch (_error) {
    x = _error;
  }
};

window.animate3 = function(canvasName, elementSelector, spinnerName, speed, layer, strokeWidth, radius, spinnerColor) {
  var x;
  try {
    $('#' + canvasName, elementSelector).animateLayer(spinnerName, {
      start: 180,
      end: 270,
      rotate: '+=360'
    }, speed, 'linear', function(layer) {
      $(this).animateLayer(layer, {
        start: 180,
        end: 539,
        rotate: '+=360'
      }, speed, 'linear', animate4(canvasName, elementSelector, spinnerName, speed, true, strokeWidth, radius, spinnerColor));
    });
  } catch (_error) {
    x = _error;
  }
};

window.animate4 = function(canvasName, elementSelector, spinnerName, speed, layer, strokeWidth, radius, spinnerColor) {
  var x;
  try {
    $('#' + canvasName, elementSelector).animateLayer(spinnerName, {
      start: 270,
      end: 359,
      rotate: '+=360'
    }, speed, 'linear', function(layer) {
      $(this).animateLayer(layer, {
        start: 270,
        end: 629,
        rotate: '+=360'
      }, speed, 'linear', animate5(canvasName, elementSelector, spinnerName, speed, true, strokeWidth, radius, spinnerColor));
    });
  } catch (_error) {
    x = _error;
  }
};

window.animate5 = function(canvasName, elementSelector, spinnerName, speed, layer, strokeWidth, radius, spinnerColor) {
  var x;
  try {
    $('#' + canvasName, elementSelector).animateLayer(spinnerName, {
      start: 359,
      end: 449,
      rotate: '+=360'
    }, speed, 'linear', function(layer) {
      $(this).animateLayer(layer, {
        start: 359,
        end: 719,
        rotate: '+=360'
      }, speed, 'linear', reset(canvasName, elementSelector, spinnerName, speed, true, strokeWidth, radius, spinnerColor));
    });
  } catch (_error) {
    x = _error;
  }
};

window.reset = function(canvasName, elementSelector, spinnerName, speed, layer, strokeWidth, radius, spinnerColor) {
  var x;
  try {
    $('#' + canvasName, elementSelector).removeLayer(spinnerName);
    $('#' + canvasName, elementSelector).html('');
    drawSpinner(elementSelector, strokeWidth, radius, speed, spinnerColor);
  } catch (_error) {
    x = _error;
  }
};

window.drawSpinner = function(elementSelector, strokeWidth, radius, speed, spinnerColor) {
  var canvasName, canvasSize, spinnerName;
  canvasSize = radius * 2 + strokeWidth * 2;
  spinnerName = 'sw-spinner-layer';
  canvasName = 'sw-spinner-canvas';
  if ($(elementSelector).length) {
    $(elementSelector).addClass('spinner spinner-bg-branco');
    $(elementSelector).html('<canvas id=' + canvasName + ' height=' + canvasSize + ' width=' + canvasSize + '></canvas>');
    $('#' + canvasName, elementSelector).drawArc({
      layer: true,
      name: spinnerName,
      strokeStyle: spinnerColor,
      strokeWidth: strokeWidth,
      x: radius + strokeWidth,
      y: radius + strokeWidth,
      radius: radius,
      start: 0,
      end: 90,
      ccw: true
    });
    if ($('#' + canvasName, elementSelector).length) {
      animate1(canvasName, elementSelector, spinnerName, speed, true, strokeWidth, radius, spinnerColor);
    }
  }
};

window.stopSpinner = function(elementSelector) {
  $(elementSelector).removeClass("spinner spinner-bg-branco");
  $('#sw-spinner-canvas', elementSelector).fadeOut();
  $('#sw-spinner-canvas', elementSelector).remove();
};

window.cleanContext = function($jElement) {
  $jElement.off();
  $jElement.unbind();
  $jElement.detach();
  $jElement.children().each((function() {
    cleanContext($(this));
  }));
};

window.Setas = {
  AlterarSeta: function(link) {
    var icon;
    icon = $("i", link);
    if (classAntiga.indexOf("up" > 0 || classAntiga.indexOf("down" > 0))) {
      Setas.InverterOrientacao("down", "up", icon);
    } else {
      Setas.InverterOrientacao("right", "left", icon);
    }
  },
  AlterarSetaRightDown: function(link) {
    var $icon, classBaixo, classDireita;
    $icon = $("i", link);
    classDireita = 'fa-chevron-right';
    classBaixo = 'fa-chevron-down';
    if ($icon.hasClass(classDireita)) {
      $icon.removeClass(classDireita);
      $icon.addClass(classBaixo);
    } else {
      $icon.removeClass(classBaixo);
      $icon.addClass(classDireita);
    }
  },
  InverterOrientacao: function(antiga, nova, elemento) {
    var aux, classAntiga;
    classAntiga = elemento.attr('class');
    aux = '';
    if (classAntiga.indexOf(nova > 0)) {
      aux = antiga;
      antiga = nova;
      nova = aux;
    }
    elemento.removeClass(classAntiga);
    elemento.addClass(classAntiga.replace(antiga, nova));
  }
};

window.separadorDecimal = resourceJsonCommom.SeparadorDecimal;

window.KeyCodes = {
  Backspace: 8,
  Tab: 9,
  Enter: 13,
  End: 35,
  Home: 36,
  ArrowLeft: 37,
  ArrowUp: 38,
  ArrowRight: 39,
  ArrowDown: 40,
  Delete: 46,
  Add: 107,
  Substract: 109,
  F2: 113,
  Escape: 27,
  PageDown: 34,
  PageUp: 33,
  Shift: 16,
  z: 90,
  y: 89
};

window.PlanilhaDeIndicadores = {
  CelulaSelecionada: -1,
  LinhaSelecionada: -1,
  ScrollLeft: -1,
  ScrollTop: -1,
  ManterPosicao: true
};

objetoNavegador = {
  nome: "",
  versao: "",
  cookie: ""
};

window.setaNavegador = function() {
  var Navegador, cookieHabilitado, detectIEregexp;
  Navegador = objetoNavegador;
  cookieHabilitado = navigator.cookieEnabled;
  Navegador.cookie = cookieHabilitado ? true : false;
  if (/OPR[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
    Navegador.nome = "Opera";
    Navegador.versao = new Number(RegExp.$1);
    return Navegador;
  }
  if (/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
    Navegador.nome = "Firefox";
    Navegador.versao = new Number(RegExp.$1);
    return Navegador;
  }
  if (/Chrome[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
    Navegador.nome = "Chrome";
    Navegador.versao = new Number(RegExp.$1);
    return Navegador;
  }
  if (!/Chrome/.test(navigator.UserAgent) && /Safari[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
    Navegador.nome = "Safari";
    Navegador.versao = new Number(RegExp.$1);
    return Navegador;
  }
  if (navigator.userAgent.indexOf('MSIE') !== -1) {
    detectIEregexp = /MSIE (\d+\.\d+);/;
  } else {
    detectIEregexp = /Trident.*rv[ :]*(\d+\.\d+)/;
  }
  if (detectIEregexp.test(navigator.userAgent)) {
    Navegador.nome = "Internet Explorer";
    Navegador.versao = new Number(RegExp.$1);
    return Navegador;
  }
  Navegador.nome = "NaoSuportado";
  return Navegador;
};

window.testaNavegador = function() {
  var Navegador;
  Navegador = objetoNavegador;
  Navegador = setaNavegador();
  if (Navegador.nome === "Chrome" && Navegador.versao < 31.0) {
    window.location = $as.Home.BrowserNaoSuportado.url;
    return;
  }
  if (Navegador.nome === "Firefox" && Navegador.versao < 38.0) {
    window.location = $as.Home.BrowserNaoSuportado.url;
    return;
  }
  if (Navegador.nome === "Safari" && Navegador.versao < 7.1) {
    window.location = $as.Home.BrowserNaoSuportado.url;
    return;
  }
  if (Navegador.nome === "Opera" && Navegador.versao < 8) {
    window.location = $as.Home.BrowserNaoSuportado.url;
    return;
  }
  if (Navegador.nome === "Internet Explorer" && Navegador.versao < 10.0) {
    window.location = $as.Home.BrowserNaoSuportado.url;
    return;
  }
  if (Navegador.nome === "NaoSuportado") {
    window.location = $as.Home.BrowserNaoSuportado.url;
    return;
  }
};
