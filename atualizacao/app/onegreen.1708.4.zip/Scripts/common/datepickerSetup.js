﻿window.BindDatePickers = function() {
  $("input[date-picker=true]").datepicker({
    todayBtn: "linked",
    autoclose: true,
    todayHighlight: true
  }).on('show', function(ev) {
    var dependencia, elemento, elementoDependencia;
    elemento = $(ev.target);
    dependencia = $(ev.target).attr("dependencia");
    if (dependencia) {
      elementoDependencia = $('#' + dependencia);
      elemento.datepicker('setStartDate', elementoDependencia.val());
    }
  });
  $("input[hour-picker=true]").timePicker({
    startTime: "06:00",
    endTime: "22:00",
    show24Hours: $("html").attr("data-24hours") === "true",
    step: 30
  });
};

$(function() {
  return BindDatePickers();
});
