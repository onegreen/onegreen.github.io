﻿$(function() {
  var MostrarIndicadoresDeErro, MostrarIndicadoresDeObrigatorios, adicionarErro, marcar, setConfigs;
  setConfigs = function($result) {
    activateBtnToggle();
    MostrarIndicadoresDeObrigatorios();
    MostrarIndicadoresDeErro();
  };
  adicionarErro = function(lista) {
    var divFormGroup, i, input, len, results;
    results = [];
    for (i = 0, len = lista.length; i < len; i++) {
      input = lista[i];
      input = $(input);
      divFormGroup = input.closest('.form-group');
      if (divFormGroup && !$(divFormGroup).hasClass('error')) {
        results.push($(divFormGroup).addClass('error'));
      } else {
        results.push(void 0);
      }
    }
    return results;
  };
  marcar = function(lista) {
    var i, input, label, len;
    for (i = 0, len = lista.length; i < len; i++) {
      input = lista[i];
      input = $(input);
      if (!input.attr('marcado-como-obrigatorio')) {
        input.attr('marcado-como-obrigatorio', true);
        label = input.closest('.form-group').find('label:first');
        if (!$('.obrigatorio', label).length) {
          label.html('<span class="obrigatorio">*</span> ' + label.html());
        }
      }
    }
  };
  MostrarIndicadoresDeObrigatorios = function() {
    marcar($('input[type!=hidden][data-val-required]'));
    marcar($('textarea[data-val-required]'));
  };
  MostrarIndicadoresDeObrigatorios();
  MostrarIndicadoresDeErro = function() {
    adicionarErro($('textarea.input-validation-error[type!=hidden][data-val-required]'));
    adicionarErro($('input.input-validation-error[type!=hidden][data-val-required]'));
    return adicionarErro($("input.input-validation-error[type=hidden][data-val='true']"));
  };
  MostrarIndicadoresDeErro();
  $(document).ajaxStart(function() {
    setTimeout(function() {
      $('body').addClass("loading-body");
      window.drawSpinner("#js-spinner", 3, 10, 850, $(".navbar, #navbar-conteudo, .painel-simples-control").css('background-color'));
      $('#loading').fadeIn(200);
    }, 0);
  });
  $(document).ajaxStop(function() {
    setTimeout(function() {
      $('body').removeClass("loading-body");
      $('#loading').stop().fadeOut();
      $('.tooltip').hide();
      $('.popover').hide();
      window.stopSpinner('#js-spinner');
    }, 0);
    $.valHooks.textarea = {
      get: function(elem) {
        return elem.value.replace(/\r?\n/g, "\r\n");
      }
    };
  });
  window.jqAjaxError = function(e, jqxhr, settings, exception) {
    var businessException, errorContainer;
    if (window.apresentacao) {
      return;
    }
    if ((jqxhr.status === 401) || (jqxhr === 'error' && e.status === 401)) {
      window.location = '/';
      return;
    }
    if (jqxhr === 'error' || jqxhr.status === 0) {
      noInternet.show();
      return;
    }
    businessException = false;
    errorContainer = $("#MensagemDeErro-Business", "#modalErroBusiness");
    if (jqxhr.responseText.indexOf('LiteFx.BusinessException') > -1) {
      errorContainer.text($("h2", $(jqxhr.responseText)).text());
    } else {
      errorContainer.text(resourceJsonCommom.ErroInesperado);
    }
    $("#modalErroBusiness").modal();
  };
  $(document).ajaxError(window.jqAjaxError);
  $(document).ajaxSuccess(function(event, xhr, options) {
    setTimeout(function() {
      setConfigs($(this));
      BindDatePickers();
    }, 0);
  });
  window.loading = {
    show: function() {
      $('body').addClass("loading-body");
      $('#loading').fadeIn(200);
      window.drawSpinner("#js-spinner", 3, 10, 850, $(".navbar, #navbar-conteudo").css('background-color'));
    },
    hide: function() {
      setTimeout(function() {
        $('body').removeClass("loading-body");
        $('#loading').stop().fadeOut();
        window.stopSpinner('#js-spinner');
      }, 0);
    }
  };
  $("#loading").on('click', function(event) {
    event.stopPropagation();
  });
});
