﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.MenusController = (function(superClass) {
  extend(MenusController, superClass);

  function MenusController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.comboUnidadesGerenciais = bind(this.comboUnidadesGerenciais, this);
    this.adicionarUnidade = bind(this.adicionarUnidade, this);
    this.alterarUnidadePrincipal = bind(this.alterarUnidadePrincipal, this);
    this.comboUnidade = bind(this.comboUnidade, this);
    this.alterarPublico = bind(this.alterarPublico, this);
    this.configurarFilhos = bind(this.configurarFilhos, this);
    this.encontrarItemNoBakup = bind(this.encontrarItemNoBakup, this);
    this.ocorreuModificao = bind(this.ocorreuModificao, this);
    this.pegarItensModificados = bind(this.pegarItensModificados, this);
    this.gerarJSONMenu = bind(this.gerarJSONMenu, this);
    this.mostrarItens = bind(this.mostrarItens, this);
    this.reload = bind(this.reload, this);
    this.ativarEventosModal = bind(this.ativarEventosModal, this);
    this.abrirModal = bind(this.abrirModal, this);
    this.adicionarItem = bind(this.adicionarItem, this);
    this.adicionarItemAbaixoDeFilho = bind(this.adicionarItemAbaixoDeFilho, this);
    this.adicionarNaRaiz = bind(this.adicionarNaRaiz, this);
    this.mostrarTodos = bind(this.mostrarTodos, this);
    this.esconderTodos = bind(this.esconderTodos, this);
    this.alterarNome = bind(this.alterarNome, this);
    this.editarItem = bind(this.editarItem, this);
    this.excluirItem = bind(this.excluirItem, this);
    this.getItemId = bind(this.getItemId, this);
    this.solicitarConfimacaoDeExclusaoDeItem = bind(this.solicitarConfimacaoDeExclusaoDeItem, this);
    this.salvarOrdenacao = bind(this.salvarOrdenacao, this);
    this.cancelarOrdencao = bind(this.cancelarOrdencao, this);
    this.ativarOrdencao = bind(this.ativarOrdencao, this);
    this.ativarEventos = bind(this.ativarEventos, this);
    this.encontrarElementos = bind(this.encontrarElementos, this);
    MenusController.__super__.constructor.call(this, this.view, this.model);
    this.ativarEventos();
    this.paiDeTodos = {
      id: this.model.Id(),
      nome: this.inputNomeDoPai.val()
    };
    this.itensBackup = this.gerarJSONMenu();
    this.esconderTodos();
    this.comboUnidade();
    this.comboUnidadesGerenciais();
    this.get('#Publico-Nao').click(this.alterarPublico);
    this.get('#Publico-Sim').click(this.alterarPublico);
    this.get("[title]").tooltip();
  }

  MenusController.prototype.encontrarElementos = function() {
    this.menu = this.get('.dd');
    this.botaoEsconder = this.get('#EsconderTodos');
    this.botaoMostrar = this.get('#MostrarTodos');
    this.botaoOrdenar = this.get('#OrdenarItens');
    this.botaoSalvar = this.get('#SalvarOrdenacaoDosItens');
    this.botaoCancelar = this.get('#CancelarOrdenacaoDosItens');
    this.inputNomeDoPai = this.get('#NomeDoPaiDeTodos');
    this.modal = $('#modal-edicao-itens');
    return this.edicaoContainer = this.get('#editor-menu');
  };

  MenusController.prototype.ativarEventos = function() {
    this.encontrarElementos();
    this.menu.nestable();
    this.botaoEsconder.unbind('click').click(this.esconderTodos);
    this.botaoMostrar.unbind('click').click(this.mostrarTodos);
    this.botaoOrdenar.unbind('click').click(this.ativarOrdencao);
    this.botaoSalvar.unbind('click').click(this.salvarOrdenacao);
    this.botaoCancelar.unbind('click').click(this.cancelarOrdencao);
    this.get('.js-AdicionarItemNaRaiz').unbind('click').click(this.adicionarNaRaiz);
    this.get('.js-AdicionarItem').unbind('click').click(this.adicionarItemAbaixoDeFilho);
    this.get('.js-ExcluirItem').unbind('click').click(this.solicitarConfimacaoDeExclusaoDeItem);
    this.get('.js-EditarItem').unbind('click').click(this.editarItem);
    return this.get('#NomeDoPaiDeTodos').unbind('click').change(this.alterarNome);
  };

  MenusController.prototype.ativarOrdencao = function() {
    this.get('.js-EsconderAoOrdenar').hide();
    this.get('.js-MostrarAoOrdenar').show();
    this.get('.js-OrderHandle').show();
    this.get('.dd3-item').removeClass('dd3-itemPadding');
    return this.get('.dd3-content').removeClass('dd-padding');
  };

  MenusController.prototype.cancelarOrdencao = function() {
    this.get('.js-EsconderAoOrdenar').show();
    this.get('.js-MostrarAoOrdenar').hide();
    this.get('.js-OrderHandle').hide();
    this.get('.dd3-item').addClass('dd3-itemPadding');
    this.get('.dd3-content').addClass('dd-padding');
    return this.reload();
  };

  MenusController.prototype.salvarOrdenacao = function() {
    var itens, itensModificados;
    itens = this.gerarJSONMenu();
    itensModificados = JSON.stringify(this.pegarItensModificados(itens));
    return $as.ReportSIM.Menus.UpdateMenu.postJson(itensModificados).done((function(_this) {
      return function(html) {
        _this.reload();
        _this.get('.js-EsconderAoOrdenar').show();
        _this.get('.js-MostrarAoOrdenar').hide();
        return _this.get('.js-OrderHandle').hide();
      };
    })(this));
  };

  MenusController.prototype.solicitarConfimacaoDeExclusaoDeItem = function(event) {
    var id, mensagem;
    id = this.getItemId(event);
    mensagem = Resource.AoExcluirEsteItemTodosOsItensAbaixoDeleTambemSeraoExcluidosDesejaConfirmarAExclusao;
    return Confirmacao.mostrar(mensagem, (function(_this) {
      return function() {
        return _this.excluirItem(id);
      };
    })(this));
  };

  MenusController.prototype.getItemId = function(event) {
    return $(event.delegateTarget).closest('.js-ItemDeMenu').attr('data-id');
  };

  MenusController.prototype.excluirItem = function(idDoItem) {
    return $as.ReportSIM.Menus.DeleteItem.post({
      id: idDoItem
    }).done((function(_this) {
      return function(html) {
        return _this.reload();
      };
    })(this));
  };

  MenusController.prototype.editarItem = function(event) {
    return $as.ReportSIM.Menus.EditItem.get({
      id: this.getItemId(event)
    }).done((function(_this) {
      return function(html) {
        return _this.abrirModal(html);
      };
    })(this));
  };

  MenusController.prototype.alterarNome = function() {
    var menu;
    menu = {
      id: this.paiDeTodos.id,
      nome: this.get('#NomeDoPaiDeTodos').val()
    };
    return $as.ReportSIM.Menus.AlterarNome.postJson(JSON.stringify(menu)).done((function(_this) {
      return function(html) {
        return _this.get('#validation-nome-container').html(html);
      };
    })(this));
  };

  MenusController.prototype.esconderTodos = function() {
    return this.menu.nestable('collapseAll');
  };

  MenusController.prototype.mostrarTodos = function() {
    return this.menu.nestable('expandAll');
  };

  MenusController.prototype.adicionarNaRaiz = function() {
    return this.adicionarItem(this.paiDeTodos.id, this.menu.nestable('serialize').length);
  };

  MenusController.prototype.adicionarItemAbaixoDeFilho = function(event) {
    return this.adicionarItem(this.getItemId(event), $('li', event.delegateTarget).length);
  };

  MenusController.prototype.adicionarItem = function(idPai, ordem) {
    return $as.ReportSIM.Menus.CreateItem.get({
      idPai: idPai,
      ordem: ordem
    }).done((function(_this) {
      return function(html) {
        return _this.abrirModal(html);
      };
    })(this));
  };

  MenusController.prototype.abrirModal = function(html) {
    this.modal.html(html);
    $(this.modal).children('.modal').window();
    this.ativarEventosModal();
    return this.get("[title]").tooltip();
  };

  MenusController.prototype.ativarEventosModal = function() {
    var selecaoDocumento, selecaoPagina, selecaoTipoDocumentoOuLink, selecaoTipoMenu, selecaoTipoPagina;
    selecaoPagina = $('#selecao-pagina', this.modal);
    selecaoDocumento = $('#selecao-documentos', this.modal);
    selecaoTipoMenu = $('#TipoDeMenu-Menu', this.modal);
    selecaoTipoPagina = $('#TipoDeMenu-Pagina', this.modal);
    selecaoTipoDocumentoOuLink = $('#TipoDeMenu-DocumentoOuLink', this.modal);
    selecaoTipoMenu.parent().click((function(_this) {
      return function() {
        if (!selecaoTipoMenu.attr('disabled')) {
          selecaoPagina.hide();
          return selecaoDocumento.hide();
        }
      };
    })(this));
    selecaoTipoPagina.parent().click((function(_this) {
      return function() {
        if (!selecaoTipoPagina.attr('disabled')) {
          selecaoDocumento.hide();
          return selecaoPagina.show();
        }
      };
    })(this));
    selecaoTipoDocumentoOuLink.parent().click((function(_this) {
      return function() {
        if (!selecaoTipoDocumentoOuLink.attr('disabled')) {
          selecaoPagina.hide();
          return selecaoDocumento.show();
        }
      };
    })(this));
    $('#Documento_Id', this.modal).val($('#idDoAgregador', this.modal).val());
    return setCombo('#modal-edicao-itens', '#Pagina_Nome');
  };

  MenusController.prototype.reload = function() {
    return $as.ReportSIM.Menus.EditorForMenu.get({
      id: this.paiDeTodos.id
    }).done((function(_this) {
      return function(html) {
        var i, ids, item, j, len, ref;
        i = 0;
        ids = new Array();
        ref = _this.get('.dd-collapsed');
        for (j = 0, len = ref.length; j < len; j++) {
          item = ref[j];
          ids[i] = $(item).attr('id');
          i++;
        }
        _this.edicaoContainer.html(html);
        _this.ativarEventos();
        _this.mostrarItens(ids);
        _this.menu.nestable('collapseAllMark');
        _this.itensBackup = _this.gerarJSONMenu();
        return _this.get("[title]").tooltip();
      };
    })(this));
  };

  MenusController.prototype.mostrarItens = function(ids) {
    var id, item, j, len, results;
    results = [];
    for (j = 0, len = ids.length; j < len; j++) {
      id = ids[j];
      item = this.get("#" + id);
      if (item) {
        results.push(item.addClass('js-Esconder'));
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  MenusController.prototype.gerarJSONMenu = function() {
    var itens, itensBackup;
    itens = this.menu.nestable('serialize');
    itensBackup = new Array();
    this.paiDeTodos.children = itens;
    this.configurarFilhos(this.paiDeTodos, itensBackup);
    return itensBackup;
  };

  MenusController.prototype.pegarItensModificados = function(lista) {
    var backup, item, itensModificados, j, len;
    itensModificados = new Array();
    for (j = 0, len = lista.length; j < len; j++) {
      item = lista[j];
      backup = this.encontrarItemNoBakup(item.id);
      if (this.ocorreuModificao(item, backup)) {
        itensModificados.push(item);
      }
    }
    return itensModificados;
  };

  MenusController.prototype.ocorreuModificao = function(item, backup) {
    return item.ordem !== backup.ordem || item.pai !== backup.pai;
  };

  MenusController.prototype.encontrarItemNoBakup = function(id) {
    var itemBackup, j, len, ref;
    ref = this.itensBackup;
    for (j = 0, len = ref.length; j < len; j++) {
      itemBackup = ref[j];
      if (itemBackup.id === id) {
        return itemBackup;
      }
    }
  };

  MenusController.prototype.configurarFilhos = function(pai, list) {
    var filho, j, len, ordem, ref, results;
    ordem = 0;
    ref = pai.children;
    results = [];
    for (j = 0, len = ref.length; j < len; j++) {
      filho = ref[j];
      filho.menuPai = pai;
      filho.ordem = ordem;
      list.push({
        nome: filho.nome,
        id: filho.id,
        ordem: filho.ordem,
        pai: pai.id
      });
      ordem++;
      if (filho.children) {
        results.push(this.configurarFilhos(filho, list));
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  MenusController.prototype.alterarPublico = function(event) {
    var containerUnidades, publico;
    publico = this.get('#Publico-Sim').is(":checked");
    containerUnidades = this.get('#unidades-visualizam-apresentacao');
    if (publico) {
      containerUnidades.fadeOut();
      $('#mostrador-publica').show();
      $('#mostrador-unidades').hide();
    } else {
      containerUnidades.fadeIn();
      $('#mostrador-unidades').show();
      $('#mostrador-publica').hide();
    }
    return $as.ReportSIM.Menus.AlterarPublico.post({
      id: this.paiDeTodos.id,
      publico: publico
    });
  };

  MenusController.prototype.comboUnidade = function() {
    return setCombo("#menu-container", '#UnidadeGerencial_SiglaAtual', this.alterarUnidadePrincipal);
  };

  MenusController.prototype.alterarUnidadePrincipal = function(item) {
    this.get('#configuracao-nome-unidade').text(this.get('#UnidadeGerencial_SiglaAtual').val());
    return $as.ReportSIM.Menus.AlterarUnidadePrincipal.post({
      id: this.paiDeTodos.id,
      idUnidade: item.val()
    });
  };

  MenusController.prototype.adicionarUnidade = function(item) {
    this.get('#mostrador-unidades').append("<span id='mostrador-listaDeDistribuicao-" + item.Id + "' class='label label-default mrs'>" + item.Nome + "</span>");
    return $as.ReportSIM.Menus.AdicionarUnidade.post({
      id: this.paiDeTodos.id,
      idUnidade: item.Id
    });
  };

  MenusController.prototype.comboUnidadesGerenciais = function() {
    var $combo, $divCombo, id, unidadesGerenciaisViewModel;
    id = this.paiDeTodos.id;
    unidadesGerenciaisViewModel = {
      unidadesGerenciais: ko.observableArray(this.options.unidadesGerenciais),
      removeUnidade: function(item) {
        this.unidadesGerenciais.remove(item);
        return $as.ReportSIM.Menus.RemoverUnidade.post({
          id: id,
          idUnidade: item.Id
        });
      }
    };
    window.unidadesGerenciaisViewModel = unidadesGerenciaisViewModel;
    ko.applyBindings(unidadesGerenciaisViewModel, this.get('#unidadesGerenciais_itens')[0]);
    $combo = this.get('#UnidadesGerenciaisCombo');
    $divCombo = $combo.parents('div.autocompleter');
    return $combo.autocompleter($divCombo.attr('data-url'), {
      elementToClick: '#UnidadesGerenciaisComboBtn',
      multiSelectArray: unidadesGerenciaisViewModel.unidadesGerenciais,
      onSelected: this.adicionarUnidade,
      multiSelectElement: '#unidadesGerenciais_itens',
      createOptionIfNotExists: false,
      canAddNewItens: false
    });
  };

  return MenusController;

})(window.baseController);
