﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.relatoriosEditController = (function(superClass) {
  extend(relatoriosEditController, superClass);

  function relatoriosEditController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.alterarPeriodicidade = bind(this.alterarPeriodicidade, this);
    this.alterarDataDeEnvio = bind(this.alterarDataDeEnvio, this);
    this.recarregarSIMPart = bind(this.recarregarSIMPart, this);
    this.comboUnidadesGerenciais = bind(this.comboUnidadesGerenciais, this);
    this.adicionarUnidade = bind(this.adicionarUnidade, this);
    this.alterarUnidadePrincipal = bind(this.alterarUnidadePrincipal, this);
    this.alterarNomeDaPagina = bind(this.alterarNomeDaPagina, this);
    this.consolidarIds = bind(this.consolidarIds, this);
    this.submeterAlteracao = bind(this.submeterAlteracao, this);
    this.complementoExcluirSIMPart = bind(this.complementoExcluirSIMPart, this);
    this.terminarMovimento = bind(this.terminarMovimento, this);
    this.iniciarMovimento = bind(this.iniciarMovimento, this);
    this.ativarEventos = bind(this.ativarEventos, this);
    this.desativarEnventos = bind(this.desativarEnventos, this);
    this.localizarElementos = bind(this.localizarElementos, this);
    this.aoSelecionarUsuario = bind(this.aoSelecionarUsuario, this);
    this.aoSelecionarLista = bind(this.aoSelecionarLista, this);
    this.aoSelecionarMenu = bind(this.aoSelecionarMenu, this);
    this.loadComboDeUsuarios = bind(this.loadComboDeUsuarios, this);
    this.loadComboListaDeDistribuicao = bind(this.loadComboListaDeDistribuicao, this);
    this.alterarPublico = bind(this.alterarPublico, this);
    this.alterarPrincipal = bind(this.alterarPrincipal, this);
    this.configurarAlterarPrincipal = bind(this.configurarAlterarPrincipal, this);
    this.load = bind(this.load, this);
    relatoriosEditController.__super__.constructor.call(this, this.view, this.model);
    this.RaizDaRequisicao = $as.ReportSIM.Relatorios;
  }

  relatoriosEditController.prototype.load = function() {
    relatoriosEditController.__super__.load.apply(this, arguments);
    this.loadComboListaDeDistribuicao();
    this.loadComboDeUsuarios();
    this.get('#Publica-Nao').click(this.alterarPublico);
    this.get('#Publica-Sim').click(this.alterarPublico);
    this.comboUnidadesGerenciais();
    this.configurarAlterarPrincipal();
    $('[rel=tooltip]').tooltip();
    window.MarcarMenuSuperior("#lnkPagina");
    return setComboAsDropdown(this.view, "#PeriodicidadeDeEnvio", null, this.alterarPeriodicidade);
  };

  relatoriosEditController.prototype.configurarAlterarPrincipal = function() {
    return $('#btn-tornar-principal').click(this.alterarPrincipal);
  };

  relatoriosEditController.prototype.alterarPrincipal = function() {
    var $icone, principal;
    if (this.options.eAdministrador && this.get('#Publica-Sim').is(':checked')) {
      $icone = $('#btn-tornar-principal').find('i');
      principal = $icone.hasClass('fa-star');
      return this.RaizDaRequisicao.AlterarPrincipal.post({
        id: this.options.Id,
        tornarPrincipal: !principal
      }).done((function(_this) {
        return function() {
          if ($icone.hasClass('fa-star-o')) {
            $icone.addClass('fa-star');
            return $icone.removeClass('fa-star-o');
          } else {
            $icone.addClass('fa-star-o');
            return $icone.removeClass('fa-star');
          }
        };
      })(this));
    }
  };

  relatoriosEditController.prototype.alterarPublico = function(event) {
    var $icone, containerPublico, containerUnidades, publico;
    publico = this.get('#Publica-Sim').is(':checked');
    containerPublico = this.get('#mostrador-listaDeDistribuicao-publica');
    containerUnidades = this.get('#mostrador-listaDeDistribuicao-unidades, #unidades-visualizam-apresentacao');
    if (publico) {
      containerUnidades.fadeOut();
      containerPublico.fadeIn();
      $('#btn-tornar-principal').show();
    } else {
      containerUnidades.fadeIn();
      containerPublico.fadeOut();
      $icone = $('#btn-tornar-principal').find('i');
      $icone.addClass('fa-star-o');
      $icone.removeClass('fa-star');
      $('#btn-tornar-principal').hide();
    }
    return this.RaizDaRequisicao.AlterarPublico.post({
      id: this.options.Id,
      publico: publico
    });
  };

  relatoriosEditController.prototype.loadComboListaDeDistribuicao = function() {
    var $combo, $divCombo, listasDeDistribuicaoViewModel, modelo;
    modelo = this.modelo;
    listasDeDistribuicaoViewModel = {
      ListasDistribuicao: ko.observableArray(this.options.listasSelecionadas),
      removeLista: function(item) {
        this.ListasDistribuicao.remove(item);
        return $as.ReportSIM.Relatorios.DesvincularListaDeDistribuicao.post({
          id: modelo.Id,
          idLista: item.Id
        }).done((function(_this) {
          return function() {
            return $("#mostradorListaDeDistribuicao #mostrador-listaDeDistribuicao-" + item.Id).remove();
          };
        })(this));
      }
    };
    window.listasDeDistribuicaoViewModel = listasDeDistribuicaoViewModel;
    ko.applyBindings(listasDeDistribuicaoViewModel, $('#listasDeDistribuicao_itens')[0]);
    $combo = $("#ListasDeDistribuicaoCombo");
    $divCombo = $combo.parents("div.autocompleter");
    return $combo.autocompleter($divCombo.attr("data-url"), {
      elementToClick: "#ListasDeDistribuicaoComboBtn",
      multiSelectArray: listasDeDistribuicaoViewModel.ListasDistribuicao,
      onSelected: this.aoSelecionarLista,
      multiSelectElement: "#listasDeDistribuicao_itens"
    });
  };

  relatoriosEditController.prototype.loadComboDeUsuarios = function() {
    var comboDeUsuarios, containerUsuarios, itens, modelo, opcoesCombo, usuarioViewModel;
    modelo = this.modelo;
    containerUsuarios = $('#container-usuarios', this.view);
    comboDeUsuarios = $("#UsuariosCombo", containerUsuarios);
    itens = $("#usuarios_itens", containerUsuarios);
    usuarioViewModel = {
      usuarios: ko.observableArray(this.options.destinatariosSelecionados),
      removeUsuario: function(usuario) {
        this.usuarios.remove(usuario);
        return $as.ReportSIM.Relatorios.DesvincularDestinatario.post({
          id: modelo.Id,
          idDoUsuario: usuario.Id
        }).done((function(_this) {
          return function() {};
        })(this));
      }
    };
    window.usuarioViewModel = usuarioViewModel;
    ko.applyBindings(usuarioViewModel, itens[0]);
    opcoesCombo = {
      elementToClick: $("#UsuariosComboBtn", containerUsuarios),
      multiSelectArray: usuarioViewModel.usuarios,
      multiSelectElement: itens,
      onSelected: this.aoSelecionarUsuario
    };
    return comboDeUsuarios.autocompleter(containerUsuarios.attr("data-url"), opcoesCombo);
  };

  relatoriosEditController.prototype.aoSelecionarMenu = function(itemSelecionado) {
    return this.RaizDaRequisicao.AlterarMenu.post({
      id: this.modelo.Id,
      idMenu: itemSelecionado.val()
    }).done((function(_this) {
      return function() {
        return _this.get('#configuracao-nome-menu').text(_this.get('#Menu_NomeNaoValida').val());
      };
    })(this));
  };

  relatoriosEditController.prototype.aoSelecionarLista = function(itemSelecionado) {
    return this.RaizDaRequisicao.VincularListaDeDistribuicao.post({
      id: this.modelo.Id,
      idLista: itemSelecionado.Id
    }).done((function(_this) {
      return function() {
        return _this.get('#mostradorListaDeDistribuicao').append("<span id='mostrador-listaDeDistribuicao-" + itemSelecionado.Id + "' class='label label-default mrs'>" + itemSelecionado.Nome + "</span>");
      };
    })(this));
  };

  relatoriosEditController.prototype.aoSelecionarUsuario = function(usuario) {
    return this.RaizDaRequisicao.VincularDestinatario.post({
      id: this.modelo.Id,
      idDoUsuario: usuario.Id
    }).done((function(_this) {
      return function() {};
    })(this));
  };

  relatoriosEditController.prototype.localizarElementos = function() {
    relatoriosEditController.__super__.localizarElementos.apply(this, arguments);
    this.containerConfiguracao = this.get('#ConfiguracoesDaPagina');
    return this.containerEdicao = this.get('#EdicaoDaPagina');
  };

  relatoriosEditController.prototype.desativarEnventos = function() {
    relatoriosEditController.__super__.desativarEnventos.apply(this, arguments);
    this.get(".js-NomePagina").unbind("click");
    return this.get(".js-MoverSIMPart").unbind("click");
  };

  relatoriosEditController.prototype.ativarEventos = function() {
    relatoriosEditController.__super__.ativarEventos.apply(this, arguments);
    this.get(".js-NomePagina").change(this.alterarNomeDaPagina);
    this.get(".js-MoverSIMPart").unbind('click').click(this.iniciarMovimento);
    return this.get("#PrimeiroEnvio").change(this.alterarDataDeEnvio);
  };

  relatoriosEditController.prototype.iniciarMovimento = function(event) {
    event.stopPropagation();
    this.trocarTextoMascaras(Resource.CliqueAquiParaMoverParaCimaDesteItem);
    this.objetoMovimentando = this.getItemContainer(event);
    this.esconderS(this.objetoMovimentando, this.entrarEmEdicaoComTexto);
    this.esconder($('.js-MascaraInserir', this.objetoMovimentando));
    this.mascaras.unbind('click').click(this.terminarMovimento);
    return this.entrarEmEdicao();
  };

  relatoriosEditController.prototype.terminarMovimento = function(event) {
    event.stopPropagation();
    this.getItemContainer(event).before(this.objetoMovimentando);
    this.mostrarS(this.objetoMovimentando);
    this.sairDaEdicao();
    this.objetoReferencia = this.getItemContainer(event);
    return this.postNovaOrdem();
  };

  relatoriosEditController.prototype.complementoExcluirSIMPart = function() {
    return this.postNovaOrdem();
  };

  relatoriosEditController.prototype.submeterAlteracao = function() {
    relatoriosEditController.__super__.submeterAlteracao.apply(this, arguments);
    this.consolidarIds();
    return this.postNovaOrdem();
  };

  relatoriosEditController.prototype.consolidarIds = function() {
    var i, idItemDaPagina, item, len, ref, results;
    ref = this.get('.js-ContainerItem');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      item = ref[i];
      idItemDaPagina = $(".js-IdItem", item).val();
      $(item).attr("id", "Item_" + idItemDaPagina);
      results.push($(item).attr("idItem", idItemDaPagina));
    }
    return results;
  };

  relatoriosEditController.prototype.alterarNomeDaPagina = function(event) {
    var relatorio;
    relatorio = {
      id: this.modelo.Id,
      nome: $(event.delegateTarget).val()
    };
    if (this.get('#Menu_Id')) {
      relatorio.Menu = {
        id: this.get('#Menu_Id').val()
      };
    }
    return this.RaizDaRequisicao.AlterarNome.postJson(JSON.stringify(relatorio)).done((function(_this) {
      return function(html) {
        return _this.get('#dvErros').html(html);
      };
    })(this));
  };

  relatoriosEditController.prototype.alterarUnidadePrincipal = function(item) {
    return this.RaizDaRequisicao.AlterarUnidadePrincipal.post({
      id: this.modelo.Id,
      idUnidade: item.val()
    }).done((function(_this) {
      return function() {
        return _this.get('#configuracao-nome-unidade').text(_this.get('#UnidadeGerencial_SiglaAtual').val());
      };
    })(this));
  };

  relatoriosEditController.prototype.adicionarUnidade = function(item) {
    return this.RaizDaRequisicao.AdicionarUnidade.post({
      id: this.options.Id,
      idUnidade: item.Id
    }).done((function(_this) {
      return function() {
        return _this.get('#mostrador-listaDeDistribuicao-unidades').append("<span id='mostrador-unidade-" + item.Id + "' class='label label-default mrs'>" + item.Nome + "</span>");
      };
    })(this));
  };

  relatoriosEditController.prototype.comboUnidadesGerenciais = function() {
    var $combo, $divCombo, idApresentacao, unidadesGerenciaisViewModel;
    idApresentacao = this.modelo.Id;
    unidadesGerenciaisViewModel = {
      unidadesGerenciais: ko.observableArray(this.options.unidadesGerenciais),
      removeUnidade: function(item) {
        this.unidadesGerenciais.remove(item);
        return $as.ReportSIM.Relatorios.RemoverUnidade.post({
          id: idApresentacao,
          idUnidade: item.Id
        }).done((function(_this) {
          return function() {
            return $("#mostrador-unidade-" + item.Id).remove();
          };
        })(this));
      }
    };
    window.unidadesGerenciaisViewModel = unidadesGerenciaisViewModel;
    ko.applyBindings(unidadesGerenciaisViewModel, this.get('#unidadesGerenciais_itens')[0]);
    $combo = this.get('#UnidadesGerenciaisCombo');
    $divCombo = $combo.parents('div.autocompleter');
    return $combo.autocompleter($divCombo.attr('data-url'), {
      elementToClick: '#UnidadesGerenciaisComboBtn',
      multiSelectArray: unidadesGerenciaisViewModel.unidadesGerenciais,
      onSelected: this.adicionarUnidade,
      multiSelectElement: '#unidadesGerenciais_itens'
    });
  };

  relatoriosEditController.prototype.recarregarSIMPart = function(ret) {
    return $as.ReportSIM.Relatorios.AtualizarEdicaoItem.get({
      idItem: ret.data
    }).done((function(_this) {
      return function(html) {
        var idSIMPart;
        idSIMPart = $(html).attr('id');
        return _this.get("#" + idSIMPart).html(html);
      };
    })(this));
  };

  relatoriosEditController.prototype.alterarDataDeEnvio = function(event) {
    var dataDeEnvio;
    dataDeEnvio = $(event.currentTarget).val();
    return $as.ReportSIM.Relatorios.AlterarDataDeEnvio.post({
      id: this.modelo.Id,
      dataDeEnvio: dataDeEnvio
    }).done(function(data) {});
  };

  relatoriosEditController.prototype.alterarPeriodicidade = function(input) {
    var periodicidade;
    periodicidade = $(input).val();
    return $as.ReportSIM.Relatorios.AlterarPeriodicidade.post({
      id: this.modelo.Id,
      periodicidade: periodicidade
    }).done((function(_this) {
      return function(data) {
        if (periodicidade === '0') {
          _this.get("#PrimeiroEnvio").val('').change();
          return _this.get('#container-primeiro-envio').hide();
        } else {
          return _this.get('#container-primeiro-envio').show();
        }
      };
    })(this));
  };

  return relatoriosEditController;

})(window.dashboardEditBaseController);
