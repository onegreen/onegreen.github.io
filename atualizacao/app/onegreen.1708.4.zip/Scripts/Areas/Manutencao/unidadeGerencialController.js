﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.unidadeGerencialController = (function() {
  function unidadeGerencialController(options) {
    this.options = options;
    this.ocultarSubordinadas = bind(this.ocultarSubordinadas, this);
    this.exibirSubordinadas = bind(this.exibirSubordinadas, this);
    this.exibirOcultarSubordinadas = bind(this.exibirOcultarSubordinadas, this);
    this.marcaDesmarcaElementoParaExclusao = bind(this.marcaDesmarcaElementoParaExclusao, this);
    this.reload = bind(this.reload, this);
    $("#CamposProcurarUnidades").keyup(function() {
      var element, itens, k, len, results, valorPesquisa, verificarElementos, verificarFilhos;
      valorPesquisa = $.trim($(this).val().toLowerCase());
      itens = $(".filtravel", "#listagem-unidades");
      verificarFilhos = function(element) {
        var contem, filho;
        filho = $(filhos[j]);
        return contem = contem || (filho.text().toLowerCase().indexOf(valorPesquisa) !== -1);
      };
      verificarElementos = function(element) {
        var child, contem, filhos, k, len;
        contem = false;
        contem = contem || (element.text().toLowerCase().indexOf(valorPesquisa) !== -1);
        filhos = $(".observarNoFiltro", element);
        for (k = 0, len = filhos.length; k < len; k++) {
          child = filhos[k];
          verificarFilhos(child);
        }
        if (contem) {
          return element.css("display", "block");
        } else {
          return element.css("display", "none");
        }
      };
      results = [];
      for (k = 0, len = itens.length; k < len; k++) {
        element = itens[k];
        results.push(vericarElementos(element));
      }
      return results;
    });
  }

  unidadeGerencialController.prototype.reload = function(callback) {
    return $.ajax({
      type: 'POST',
      url: this.options.internalIndex,
      data: {},
      success: function(html) {
        $('#main').html(html);
        console.log(callback);
        if (callback !== void 0) {
          return callback();
        }
      }
    });
  };

  unidadeGerencialController.prototype.marcaDesmarcaElementoParaExclusao = function(elemento) {
    $(elemento).toggleClass('selecionado');
    if ($(".selecionado").length > 0) {
      return $("#excluir-selecionados-unidadegerencial").removeAttr('disabled');
    } else {
      return $("#excluir-selecionados-unidadegerencial").attr('disabled', 'disabled');
    }
  };

  unidadeGerencialController.prototype.exibirOcultarSubordinadas = function(el, idDaUnidade) {
    var elemento;
    elemento = $(el);
    if (elemento.hasClass("fa-plus-square")) {
      return this.exibirSubordinadas(elemento, idDaUnidade);
    } else {
      return this.ocultarSubordinadas(elemento, idDaUnidade);
    }
  };

  unidadeGerencialController.prototype.exibirSubordinadas = function(elemento, idDaUnidade) {
    return $.ajax({
      type: "GET",
      url: this.options.internalIndex,
      data: {
        idDaUnidadeGerencial: idDaUnidade
      },
      success: (function(_this) {
        return function(html) {
          var item, nivel;
          nivel = parseInt(elemento.parent().parent().data('nivel')) + 1;
          item = $($.parseHTML(html)).find('tr').attr('data-nivel', nivel);
          item.find('td').addClass("espacamento-hierarquia-0").addClass("espacamento-hierarquia-" + nivel);
          elemento.parent().parent().after(item);
          return elemento.removeClass("fa-plus-square").addClass("fa-minus-square");
        };
      })(this)
    });
  };

  unidadeGerencialController.prototype.ocultarSubordinadas = function(elemento, idDaUnidade) {
    if (idDaUnidade !== void 0) {
      $("[data-pai='" + idDaUnidade + "']").each((function(_this) {
        return function(i, e) {
          var idUnidade;
          idUnidade = $(e).data('idunidade');
          _this.ocultarSubordinadas($(e), idUnidade);
          elemento.find('i').removeClass("fa-minus-square").addClass("fa-plus-square");
          return $(e).remove();
        };
      })(this));
    }
    return elemento.removeClass("fa-minus-square").addClass("fa-plus-square");
  };

  return unidadeGerencialController;

})();
