﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.secaoDoModeloController = (function(superClass) {
  var itemDoCombo;

  extend(secaoDoModeloController, superClass);

  function secaoDoModeloController(view, options) {
    this.view = view;
    this.options = options;
    this.selecionarEstiloDaSecao = bind(this.selecionarEstiloDaSecao, this);
    this.atualizarItensDoCombo = bind(this.atualizarItensDoCombo, this);
    this.selecionarIndicador = bind(this.selecionarIndicador, this);
    this.alterarIndicador = bind(this.alterarIndicador, this);
    this.voltarParaAsOrigens = bind(this.voltarParaAsOrigens, this);
    this.aoSelecionarIndicador = bind(this.aoSelecionarIndicador, this);
    this.selecionarOrigem = bind(this.selecionarOrigem, this);
    this.selecionarAcumulado = bind(this.selecionarAcumulado, this);
    this.selecionarFormaDeAgrupamento = bind(this.selecionarFormaDeAgrupamento, this);
    this.selecionarTipoDaSecao = bind(this.selecionarTipoDaSecao, this);
    this.abrirModalParaConfigurarFormula = bind(this.abrirModalParaConfigurarFormula, this);
    this.exibirErros = bind(this.exibirErros, this);
    this.salvar = bind(this.salvar, this);
    this.salvarEEditarFormula = bind(this.salvarEEditarFormula, this);
    this.defineColorPicker = bind(this.defineColorPicker, this);
    this.configurarCombos = bind(this.configurarCombos, this);
    secaoDoModeloController.__super__.constructor.call(this, this.view, null);
    this.animation = '500';
    this.comboIndicador;
    this.comboUnidade;
    $("#secao-modal").window({
      height: 420
    });
    this.indicadorSelecionado = new itemDoCombo();
    this.unidadeSelecionada = new itemDoCombo();
    this.voltarParaDetalhes;
    this.comboIndicadorContainer = this.get("#comboIndicador-container");
    this.labelIndicador = this.get(".js-label-indicador");
    this.spanUnidade = this.get(".js-span-unidade");
    this.spanIndicador = this.get(".js-span-indicador");
    this.origensContainer = this.get("#origens-container");
    this.modalOrigens = this.get("#js-modal-origens");
    this.detalhesSecaoContainer = this.get('#detalhes-secao-container');
    this.corContainer = this.get('#cor-container');
    (this.get('#alterarOrigem')).unbind('click').bind('click', this.voltarParaAsOrigens);
    this.defineColorPicker(this.options.estilo !== 'spline');
    (this.get('#origens-container')).find('a').unbind('click').bind('click', (function(_this) {
      return function() {
        return _this.selecionarOrigem($( this ));
      };
    })(this));
    (this.get('#Acumulado')).unbind('click').bind('click', (function(_this) {
      return function() {
        return _this.selecionarAcumulado($( this ));
      };
    })(this));
    (this.get('#opcoes-TipoDaSecao a')).unbind('click').bind('click', (function(_this) {
      return function() {
        return _this.selecionarTipoDaSecao($( this ));
      };
    })(this));
    (this.get('#opcoes-FormaDeAgrupamento a')).unbind('click').bind('click', (function(_this) {
      return function() {
        return _this.selecionarFormaDeAgrupamento($( this ));
      };
    })(this));
    (this.get('#btn-salvarSecao')).unbind('click').bind('click', this.salvar);
    (this.get('#editar-formula')).unbind('click').bind('click', this.salvarEEditarFormula);
    this.get(".js-alterar-indicador").unbind('click').bind('click', this.alterarIndicador);
    this.get("#voltar-origens").unbind('click').bind('click', this.aoSelecionarIndicador);
    if (this.options.coresDoFarol) {
      (this.get('#CorDePreenchimento')).closest('.cores-container').find('[class*=evo-colorind]').hide();
    }
    this.get('#estiloDaSecao input:radio').change(this.selecionarEstiloDaSecao);
    this.configurarCombos();
    $("#descricao-periodo-container label").prepend("<span class='obrigatorio'>*</span> ");
  }

  secaoDoModeloController.prototype.configurarCombos = function() {
    var onSelectUG, parameters;
    onSelectUG = (function(_this) {
      return function(input) {
        var disable;
        disable = $(input).val() === '';
        _this.comboIndicador.reset();
        _this.comboIndicador.disableElseEnable(disable);
        return _this.atualizarItensDoCombo();
      };
    })(this);
    this.comboUnidade = setCombo(this.view, '#UnidadeGerencial_SiglaAtual', onSelectUG);
    parameters = {
      idUnidadeGerencial: (function(_this) {
        return function() {
          return _this.comboUnidade.value();
        };
      })(this)
    };
    this.comboIndicador = Results.api.setComboIndicador(this.view, '#Indicador_Nome', this.selecionarIndicador, parameters);
    if (this.comboIndicador) {
      this.comboIndicador.disableElseEnable(this.comboUnidade.value() === '');
      this.atualizarItensDoCombo();
    }
  };

  secaoDoModeloController.prototype.defineColorPicker = function(exibirFarol) {
    return (this.get('#CorDePreenchimento')).colorpicker({
      history: false,
      displayIndicator: false,
      exibirOpcaoFarol: exibirFarol,
      onClickCoresDoFarol: function() {
        $('#labelUsarCores').show();
        $('#labelUsarCores').addClass('fl cursor-pointer borda-cinza radius4 pas');
        $('#PreenchimentoDeAcordoComOFarol').val('True');
        $('#CorDePreenchimento').val('red');
        $('#CorDePreenchimento').next().css('background-color', 'red');
        return $('#CorDePreenchimento').closest('.cores-container').find('[class*=evo-colorind]').hide();
      }
    }).on('change.color', function() {
      $('#labelUsarCores').hide();
      $('#PreenchimentoDeAcordoComOFarol').val('False');
      return $('#CorDePreenchimento').closest('.cores-container').find('[class*=evo-colorind]').show();
    });
  };

  secaoDoModeloController.prototype.salvarEEditarFormula = function() {
    return $as.Manutencao.Secoes.CreateEdit.post($(this.view).find(':input').serialize()).done((function(_this) {
      return function(data) {
        if (data.error) {
          _this.detalhesSecaoContainer.html(data.data.html);
          return _this.exibirErros();
        } else {
          return _this.abrirModalParaConfigurarFormula(data.id);
        }
      };
    })(this));
  };

  secaoDoModeloController.prototype.salvar = function() {
    return $as.Manutencao.Secoes.CreateEdit.post($(this.view).find(':input').serialize()).done((function(_this) {
      return function(data) {
        if (data.error) {
          _this.detalhesSecaoContainer.html(data.data.html);
          return _this.exibirErros();
        } else {
          $('#close-modal-secao', _this.view).click();
          return Secao.reload();
        }
      };
    })(this));
  };

  secaoDoModeloController.prototype.exibirErros = function() {
    return $('#divErros', this.view).empty().html(this.detalhesSecaoContainer.find('#divErros-detalhes').html());
  };

  secaoDoModeloController.prototype.abrirModalParaConfigurarFormula = function(id) {
    $as.Manutencao.Secoes.ObterIdDaFormulaParaConfigurar.post({
      id: id
    }).done((function(_this) {
      return function(idFormula) {
        return $as.Performance.Formulas.Edit.get({
          id: idFormula.data.id,
          idSecao: id
        }).done(function(data) {
          return $('#main-modal').html(data);
        });
      };
    })(this));
    return Secao.reload();
  };

  secaoDoModeloController.prototype.selecionarTipoDaSecao = function($el) {
    (this.get('#btn-TipoDaSecao')).html($el.text() + ' <span class="caret"></span>');
    (this.get('#TipoDaSecao')).val($el.data('value'));
    if ($el.data('value') === 'AEsquerda' || $el.data('value') === 'ADireita') {
      (this.get('#descricao-periodo-container')).show();
      (this.get('#forma-agrupamento-container')).show();
      return (this.get('#DescricaoDoPeriodo')).val('#');
    } else {
      (this.get('#descricao-periodo-container')).hide();
      return (this.get('#forma-agrupamento-container')).hide();
    }
  };

  secaoDoModeloController.prototype.selecionarFormaDeAgrupamento = function($el) {
    (this.get('#btn-FormaDeAgrupamento')).html($el.text() + ' <span class="caret"></span>');
    return (this.get('#ValorApresentado')).val($el.data('value'));
  };

  secaoDoModeloController.prototype.selecionarAcumulado = function($el) {
    if ($el.is(':checked')) {
      return (this.get('#FormaDeCalculo')).val((this.get('#FonteAcumuladaSelecionada')).val());
    } else {
      return (this.get('#FormaDeCalculo')).val((this.get('#FonteSelecionada')).val());
    }
  };

  secaoDoModeloController.prototype.selecionarOrigem = function($el) {
    var nome, valor;
    nome = $el.data('desc');
    valor = $el.data('value');
    if (nome == null) {
      nome = $el.text();
    }
    (this.get('#Nome')).val(nome);
    (this.get('#labelOrigem')).text(nome);
    (this.get('#Origem')).val(valor);
    (this.get('#OrigemAcumuladaSelecionada')).val($el.data('acumulado'));
    if (!$el.data('acumulado')) {
      (this.get('#Acumulado')).attr('disabled', 'disabled');
    } else {
      (this.get('#Acumulado')).removeAttr('disabled');
    }
    if (valor === 'Formula') {
      (this.get('#atraso-container')).hide();
      (this.get('#acumulado-container')).hide();
      this.get('#indicador-selecionado').hide();
      (this.get('#config-formula')).show();
      this.labelIndicador.hide();
      if (this.comboUnidade) {
        this.atualizarItensDoCombo();
        this.comboUnidade.reset();
        this.comboIndicador.reset();
        this.comboIndicador.disableElseEnable(true);
      }
      $("#editar-formula", this.detalhesSecaoContainer).click();
    } else {
      $("#idUnidadeGerencial", this.comboIndicadorContainer).val(this.unidadeSelecionada.Id);
      $("#UnidadeGerencial_SiglaAtual", this.comboIndicadorContainer).val(this.unidadeSelecionada.Nome);
      $("#Indicador_Id", this.comboIndicadorContainer).val(this.indicadorSelecionado.Id);
      $("#Indicador_Nome", this.comboIndicadorContainer).val(this.indicadorSelecionado.Nome);
      (this.get('#atraso-container')).show();
      (this.get('#acumulado-container')).show();
      (this.get('#indicador-selecionado')).show();
      (this.get('#config-formula')).hide();
      this.labelIndicador.show();
      this.origensContainer.hide(this.animation);
      this.detalhesSecaoContainer.show(this.animation);
      $("#secao-modal-footer").show(this.animation);
    }
    this.comboIndicadorContainer.hide();
    return (this.get('#Nome')).focus();
  };

  secaoDoModeloController.prototype.aoSelecionarIndicador = function() {
    if (this.voltarParaDetalhes) {
      this.origensContainer.hide();
      this.comboIndicadorContainer.hide(this.animation);
      this.labelIndicador.show();
      this.detalhesSecaoContainer.show(this.animation);
      return $("#secao-modal-footer").show(this.animation);
    } else {
      return this.voltarParaAsOrigens();
    }
  };

  secaoDoModeloController.prototype.voltarParaAsOrigens = function() {
    $("#idUnidadeGerencial", this.comboIndicadorContainer).val(this.unidadeSelecionada.Id);
    $("#UnidadeGerencial_SiglaAtual", this.comboIndicadorContainer).val(this.unidadeSelecionada.Nome);
    $("#Indicador_Id", this.comboIndicadorContainer).val(this.indicadorSelecionado.Id);
    $("#Indicador_Nome", this.comboIndicadorContainer).val(this.indicadorSelecionado.Nome);
    if (this.comboIndicador) {
      this.comboIndicador.disableElseEnable(false);
    }
    this.detalhesSecaoContainer.hide(this.animation);
    this.labelIndicador.show();
    this.comboIndicadorContainer.hide(this.animation);
    this.modalOrigens.show();
    this.origensContainer.show(this.animation);
    $("#secao-indicador-modal-footer").hide(this.animation);
    return $("#secao-modal-footer").hide(this.animation);
  };

  secaoDoModeloController.prototype.alterarIndicador = function(e) {
    this.voltarParaDetalhes = $(e.currentTarget).data('voltar-detalhes');
    this.origensContainer.hide(this.animation);
    this.labelIndicador.hide();
    this.detalhesSecaoContainer.hide(this.animation);
    this.comboIndicadorContainer.show(this.animation);
    $("#secao-indicador-modal-footer").show(this.animation);
    return $("#secao-modal-footer").hide(this.animation);
  };

  secaoDoModeloController.prototype.selecionarIndicador = function() {
    this.spanUnidade.text(this.comboUnidade.text());
    this.spanIndicador.text(this.comboIndicador.text());
    this.atualizarItensDoCombo();
    this.aoSelecionarIndicador();
  };

  secaoDoModeloController.prototype.atualizarItensDoCombo = function() {
    this.indicadorSelecionado.Id = this.comboIndicador.value() || this.options.idIndicador;
    this.indicadorSelecionado.Nome = this.comboIndicador.text();
    this.unidadeSelecionada.Id = this.comboUnidade.value();
    return this.unidadeSelecionada.Nome = this.comboUnidade.text();
  };

  secaoDoModeloController.prototype.selecionarEstiloDaSecao = function(e) {
    var eixo1, eixo2, estilo;
    estilo = $(e.currentTarget).data('estilo');
    if (estilo === 'pizza') {
      this.corContainer.hide();
    } else {
      this.corContainer.show();
    }
    if (estilo === 'linha') {
      (this.get('#CorDePreenchimento')).data('evolColorpicker').val('#c00000');
    }
    this.defineColorPicker(estilo !== 'linha');
    if (estilo === 'barra') {
      eixo1 = 'X1';
      eixo2 = 'X2';
    } else {
      eixo1 = 'Y1';
      eixo2 = 'Y2';
    }
    $('#spanEixo-1', this.view).text(eixo1);
    return $('#spanEixo-2', this.view).text(eixo2);
  };

  itemDoCombo = function() {
    this.Id;
    this.Nome;
  };

  return secaoDoModeloController;

})(window.baseController);
