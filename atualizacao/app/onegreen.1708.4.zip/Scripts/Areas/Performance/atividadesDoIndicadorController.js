﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.atividadesDoIndicadorController = (function() {
  function atividadesDoIndicadorController(contexto, idDoPlanoDeAcao) {
    this.contexto = contexto;
    this.idDoPlanoDeAcao = idDoPlanoDeAcao;
    this.aoAlterarModoDeExibicaoDasConfiguracoes = bind(this.aoAlterarModoDeExibicaoDasConfiguracoes, this);
    this.EsconderConcluidas = bind(this.EsconderConcluidas, this);
    this.ExibirConcluidas = bind(this.ExibirConcluidas, this);
    this.EsconderExcluidas = bind(this.EsconderExcluidas, this);
    this.ExibirExcluidas = bind(this.ExibirExcluidas, this);
    this.reload = bind(this.reload, this);
    this.adicionarTarefaNoIndicador = bind(this.adicionarTarefaNoIndicador, this);
    $("#container-plano-acao" + this.idDoPlanoDeAcao + " a", this.contexto).click(this.adicionarTarefaNoIndicador);
    Atividades.api.boot();
  }

  atividadesDoIndicadorController.prototype.adicionarTarefaNoIndicador = function() {
    return $as.Atividades.Atividades.CreateAtividade.get({
      idDoPlanoDeAcao: this.idDoPlanoDeAcao,
      atividadeForaDoPlanoDeAcao: true
    }).success((function(_this) {
      return function(data) {
        return window.GetDiv("create-atividade-container").html(data);
      };
    })(this));
  };

  atividadesDoIndicadorController.prototype.reload = function() {
    var idDoIndicador;
    idDoIndicador = $("#IdDoIndicador", this.contexto).val();
    return $as.Performance.AtividadesDoIndicador.RecarregarAtividades.get({
      idDoIndicador: idDoIndicador
    }).success((function(_this) {
      return function(data) {
        var quantidadeDeTarefas;
        $("#tarefasDoIndicador", _this.contexto).html(data);
        quantidadeDeTarefas = $("#contadorTarefas", _this.contexto).val();
        $("#js-contadorTarefas", _this.contexto).html(quantidadeDeTarefas);
        return Atividades.api.boot();
      };
    })(this));
  };

  atividadesDoIndicadorController.prototype.ExibirExcluidas = function() {
    var exibirConcluidas, exibirExcluidas, idDoIndicador;
    idDoIndicador = $("#IdDoIndicador", this.contexto).val();
    exibirConcluidas = $("#ExibirConcluidas", this.contexto).val() === 'true';
    exibirExcluidas = $("#ExibirExcluidas", this.contexto).val();
    return $as.Performance.AtividadesDoIndicador.ExibirExcluidas.get({
      idDoIndicador: idDoIndicador,
      exibirExcluidas: true,
      exibirConcluidas: exibirConcluidas
    }).success((function(_this) {
      return function(data) {
        var quantidadeDeTarefas;
        $("#tarefasDoIndicador", _this.contexto).html(data);
        quantidadeDeTarefas = $("#contadorTarefas", _this.contexto).val();
        $("#js-contadorTarefas", _this.contexto).html(quantidadeDeTarefas);
        Atividades.api.boot();
        return _this.aoAlterarModoDeExibicaoDasConfiguracoes(true, exibirConcluidas);
      };
    })(this));
  };

  atividadesDoIndicadorController.prototype.EsconderExcluidas = function() {
    var exibirConcluidas, exibirExcluidas, idDoIndicador;
    idDoIndicador = $("#IdDoIndicador", this.contexto).val();
    exibirConcluidas = $("#ExibirConcluidas", this.contexto).val() === 'true';
    exibirExcluidas = false;
    return $as.Performance.AtividadesDoIndicador.EsconderExcluidas.get({
      idDoIndicador: idDoIndicador,
      exibirExcluidas: false,
      exibirConcluidas: exibirConcluidas
    }).success((function(_this) {
      return function(data) {
        var quantidadeDeTarefas;
        $("#tarefasDoIndicador", _this.contexto).html(data);
        quantidadeDeTarefas = $("#contadorTarefas", _this.contexto).val();
        $("#js-contadorTarefas", _this.contexto).html(quantidadeDeTarefas);
        Atividades.api.boot();
        return _this.aoAlterarModoDeExibicaoDasConfiguracoes(false, exibirConcluidas);
      };
    })(this));
  };

  atividadesDoIndicadorController.prototype.ExibirConcluidas = function() {
    var exibirConcluidas, exibirExcluidas, idDoIndicador;
    idDoIndicador = $("#IdDoIndicador", this.contexto).val();
    exibirConcluidas = $("#ExibirConcluidas", this.contexto).val();
    exibirExcluidas = $("#ExibirExcluidas", this.contexto).val() === 'true';
    return $as.Performance.AtividadesDoIndicador.ExibirConcluidas.get({
      idDoIndicador: idDoIndicador,
      exibirExcluidas: exibirExcluidas,
      exibirConcluidas: true
    }).success((function(_this) {
      return function(data) {
        var quantidadeDeTarefas;
        $("#tarefasDoIndicador", _this.contexto).html(data);
        quantidadeDeTarefas = $("#contadorTarefas", _this.contexto).val();
        $("#js-contadorTarefas", _this.contexto).html(quantidadeDeTarefas);
        Atividades.api.boot();
        return _this.aoAlterarModoDeExibicaoDasConfiguracoes(exibirExcluidas, true);
      };
    })(this));
  };

  atividadesDoIndicadorController.prototype.EsconderConcluidas = function() {
    var exibirConcluidas, exibirExcluidas, idDoIndicador;
    idDoIndicador = $("#IdDoIndicador", this.contexto).val();
    exibirConcluidas = false;
    exibirExcluidas = $("#ExibirExcluidas", this.contexto).val() === 'true';
    return $as.Performance.AtividadesDoIndicador.EsconderConcluidas.get({
      idDoIndicador: idDoIndicador,
      exibirExcluidas: exibirExcluidas,
      exibirConcluidas: exibirConcluidas
    }).success((function(_this) {
      return function(data) {
        var quantidadeDeTarefas;
        $("#tarefasDoIndicador", _this.contexto).html(data);
        quantidadeDeTarefas = $("#contadorTarefas", _this.contexto).val();
        $("#js-contadorTarefas", _this.contexto).html(quantidadeDeTarefas);
        Atividades.api.boot();
        return _this.aoAlterarModoDeExibicaoDasConfiguracoes(exibirExcluidas, false);
      };
    })(this));
  };

  atividadesDoIndicadorController.prototype.aoAlterarModoDeExibicaoDasConfiguracoes = function(exibirExcluidas, exibirConcluidas) {
    if (Boolean(exibirExcluidas)) {
      $('#btn-ocultar-excluidas', this.contexto).show();
      $('#btn-exibir-excluidas', this.contexto).hide();
    } else {
      $('#btn-ocultar-excluidas', this.contexto).hide();
      $('#btn-exibir-excluidas', this.contexto).show();
    }
    if (Boolean(exibirConcluidas)) {
      $('#btn-ocultar-concluidas', this.contexto).show();
      $('#btn-exibir-concluidas', this.contexto).hide();
    } else {
      $('#btn-ocultar-concluidas', this.contexto).hide();
      $('#btn-exibir-concluidas', this.contexto).show();
    }
    $('[rel=tooltip]').tooltip();
    return $('#js-contadorTarefas').text($(this.contexto).find('.listagem-tarefa').find('li').length);
  };

  return atividadesDoIndicadorController;

})();
