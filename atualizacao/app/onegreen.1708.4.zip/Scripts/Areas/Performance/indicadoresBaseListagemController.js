﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.indicadoresBaseListagemController = (function() {
  function indicadoresBaseListagemController(options) {
    this.options = options;
    this.setarHoverNoTrDaTable = bind(this.setarHoverNoTrDaTable, this);
    $("[rel=tooltip]").tooltip();
    $(".js-utilizacaoDoIndicador").click(this.bindUtilizacaoDoIndicador);
    this.setarHoverNoTrDaTable();
  }

  indicadoresBaseListagemController.prototype.setarHoverNoTrDaTable = function() {
    return $("table tr").hover(function() {
      return $(this).find(".js-utilizacaoDoIndicador").show();
    }, function() {
      return $(this).find(".js-utilizacaoDoIndicador").hide();
    });
  };

  indicadoresBaseListagemController.prototype.bindUtilizacaoDoIndicador = function() {
    var idDoIndicador;
    idDoIndicador = $(this).attr("data-indicador");
    return $as.Performance.IndicadoresBase.UtilizacaoDoIndicador.get({
      idDoIndicador: idDoIndicador
    }).success((function(_this) {
      return function(data) {
        return window.GetDiv("utilizacaoDoIndicador-modal").html(data);
      };
    })(this));
  };

  return indicadoresBaseListagemController;

})();
