﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.classificacaoDoLicenciamentoAmbientalController = (function() {
  function classificacaoDoLicenciamentoAmbientalController(options) {
    this.options = options;
    this.configurarBotaoVincular = bind(this.configurarBotaoVincular, this);
    this.configurarComboTipoDeLicenca = bind(this.configurarComboTipoDeLicenca, this);
    this.vincularTipoDeLicenca = bind(this.vincularTipoDeLicenca, this);
    if (this.options.eCreateEdit) {
      $('#classificacao-modal').window();
      $("#btnVincularTipoDeLicenca").click(this.vincularTipoDeLicenca);
      if (!this.options.novoRegistro) {
        this.configurarComboTipoDeLicenca();
        this.configurarBotaoVincular();
      }
    } else {
      $('.modal').modal('hide');
      $("[data-MoverClassificacaoParaCima]a").click(this.moverClassificacaoParaCima);
      $("[data-MoverClassificacaoParaBaixo]a").click(this.moverClassificacaoParaBaixo);
    }
  }

  classificacaoDoLicenciamentoAmbientalController.prototype.moverClassificacaoParaCima = function() {
    return $as.Onegreen.ClassificacoesDoLicenciamentoAmbiental.MoverClassificacaoParaCima.post({
      idDaClassificacao: $(this).data("moverclassificacaoparacima")
    }).success((function(_this) {
      return function(data) {
        return $("#classificacoesDoLicenciamentoAmbiental-container").html(data);
      };
    })(this));
  };

  classificacaoDoLicenciamentoAmbientalController.prototype.moverClassificacaoParaBaixo = function() {
    return $as.Onegreen.ClassificacoesDoLicenciamentoAmbiental.MoverClassificacaoParaBaixo.post({
      idDaClassificacao: $(this).data("moverclassificacaoparabaixo")
    }).success((function(_this) {
      return function(data) {
        return $("#classificacoesDoLicenciamentoAmbiental-container").html(data);
      };
    })(this));
  };

  classificacaoDoLicenciamentoAmbientalController.prototype.vincularTipoDeLicenca = function() {
    var idLicenca;
    idLicenca = $("#Tipo_Id").val();
    if (idLicenca !== "") {
      return $as.Onegreen.ClassificacoesDoLicenciamentoAmbiental.VincularLicenciamentoSugerido.post({
        idDaClassificacao: $("#IdDaClassificacao").val(),
        idDoTipoDeLicenca: $("#Tipo_Id").val()
      }).success((function(_this) {
        return function(data) {
          $("#licenciamentosSugeridos").html(data);
          $("#Tipo_Descricao").val('');
          $("#Tipo_Id").val('');
          _this.configurarComboTipoDeLicenca();
          return _this.configurarBotaoVincular();
        };
      })(this));
    }
  };

  classificacaoDoLicenciamentoAmbientalController.prototype.configurarComboTipoDeLicenca = function() {
    var funcao, parametros;
    parametros = {
      idDaClassificacao: this.options.idDaClassificacao,
      idDaLegislacao: this.options.idDaLegislacao
    };
    funcao = (function(_this) {
      return function() {
        return _this.configurarBotaoVincular();
      };
    })(this);
    return setCombo("#classificacao-modal", "#Tipo_Descricao", funcao, parametros);
  };

  classificacaoDoLicenciamentoAmbientalController.prototype.configurarBotaoVincular = function() {
    var idLicenca;
    idLicenca = $("#Tipo_Id").val();
    if (idLicenca === "") {
      return $("#btnVincularTipoDeLicenca").attr("disabled", "disabled");
    } else {
      return $("#btnVincularTipoDeLicenca").removeAttr("disabled");
    }
  };

  return classificacaoDoLicenciamentoAmbientalController;

})();
