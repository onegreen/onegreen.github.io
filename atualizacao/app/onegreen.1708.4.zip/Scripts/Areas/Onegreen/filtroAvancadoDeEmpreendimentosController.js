﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.filtroAvancadoDeEmpreendimentosController = (function() {
  function filtroAvancadoDeEmpreendimentosController(options) {
    this.options = options;
    this.configurarCamposQueDependemDaLegislacaoAmbiental = bind(this.configurarCamposQueDependemDaLegislacaoAmbiental, this);
    this.loadComboTipoDeLicenca = bind(this.loadComboTipoDeLicenca, this);
    this.loadComboTipologia = bind(this.loadComboTipologia, this);
    this.loadComboLegislacaoAmbiental = bind(this.loadComboLegislacaoAmbiental, this);
    this.loadComboUnidadeGerencial = bind(this.loadComboUnidadeGerencial, this);
    this.loadComboResponsavel = bind(this.loadComboResponsavel, this);
    this.configurarFiltro = bind(this.configurarFiltro, this);
    this.configurarFiltro();
    this.loadComboResponsavel();
    this.loadComboUnidadeGerencial();
    this.loadComboLegislacaoAmbiental();
    this.loadComboTipologia();
    this.loadComboTipoDeLicenca();
    this.configurarCamposQueDependemDaLegislacaoAmbiental();
  }

  filtroAvancadoDeEmpreendimentosController.prototype.configurarFiltro = function() {
    $("#filtro-avancado-de-empreendimentos").on('click', (function(_this) {
      return function() {
        return $("#filtro-avancado-de-empreendimentos-container").toggle();
      };
    })(this));
    return $("#fechar-filtro", this.options.contexto).on('click', (function(_this) {
      return function() {
        return $("#filtro-avancado-de-empreendimentos-container").toggle();
      };
    })(this));
  };

  filtroAvancadoDeEmpreendimentosController.prototype.loadComboResponsavel = function() {
    return setCombo(this.options.contexto, "#ResponsavelNome");
  };

  filtroAvancadoDeEmpreendimentosController.prototype.loadComboUnidadeGerencial = function() {
    return setCombo(this.options.contexto, "#UnidadeGerencialNome");
  };

  filtroAvancadoDeEmpreendimentosController.prototype.loadComboLegislacaoAmbiental = function() {
    return setCombo(this.options.contexto, "#LegislacaoAmbientalNome", this.configurarCamposQueDependemDaLegislacaoAmbiental);
  };

  filtroAvancadoDeEmpreendimentosController.prototype.loadComboTipologia = function() {
    return setCombo(this.options.contexto, "#TipoDeEmpreendimentoNome");
  };

  filtroAvancadoDeEmpreendimentosController.prototype.loadComboTipoDeLicenca = function() {
    return setCombo(this.options.contexto, "#TipoDeLicencaNome");
  };

  filtroAvancadoDeEmpreendimentosController.prototype.configurarCamposQueDependemDaLegislacaoAmbiental = function() {
    if ($('#LegislacaoAmbiental', this.options.contexto).val() === '') {
      $('#TipoDeEmpreendimento', this.options.contexto).val('');
      $('#TipoDeEmpreendimentoNome', this.options.contexto).val('');
      return $('#TipoDeEmpreendimentoNome', this.options.contexto).data('autocompleter').disable();
    } else {
      return $('#TipoDeEmpreendimentoNome').data('autocompleter').enable();
    }
  };

  return filtroAvancadoDeEmpreendimentosController;

})();
