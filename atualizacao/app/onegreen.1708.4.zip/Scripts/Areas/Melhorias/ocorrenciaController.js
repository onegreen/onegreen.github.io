﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.ocorrenciaController = (function() {
  function ocorrenciaController(options) {
    this.options = options;
    this.gruposResponsaveisPorAprovacao = bind(this.gruposResponsaveisPorAprovacao, this);
    this.configurarExibicaoDeGruposResponsaveis = bind(this.configurarExibicaoDeGruposResponsaveis, this);
    this.salvarOcorrencia = bind(this.salvarOcorrencia, this);
    this.carregarCombos = bind(this.carregarCombos, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.contexto = "#janelaOcorrencias";
    this.carregarCombos();
    this.configurarBinds();
    this.configurarExibicaoDeGruposResponsaveis();
  }

  ocorrenciaController.prototype.configurarBinds = function() {
    window.MarcarMenuSuperior("#lnkOcorrencias");
    $("[rel=tooltip]").tooltip();
    return $("#Salvar-Ocorrencia").click(this.salvarOcorrencia);
  };

  ocorrenciaController.prototype.carregarCombos = function() {
    setCombo(this.contexto, "#Unidade_SiglaAtual");
    return setCombo(this.contexto, "#Origem_Nome");
  };

  ocorrenciaController.prototype.salvarOcorrencia = function() {
    var parametros;
    parametros = $(":input", "#ocorrencia-container").serialize();
    return $as.Melhorias.Ocorrencias.Edit.post(parametros).success((function(_this) {
      return function(data) {
        return $("#main").html(data);
      };
    })(this));
  };

  ocorrenciaController.prototype.configurarExibicaoDeGruposResponsaveis = function() {
    if ($("#gruposResponsaveis").length > 0) {
      return $("ul", "[data-id-entidade=" + this.options.Id + "]").append($("#gruposResponsaveis"));
    }
  };

  ocorrenciaController.prototype.gruposResponsaveisPorAprovacao = function() {
    return $as.Melhorias.Ocorrencias.GruposResponsaveisPorAprovacao.get({
      idDaOcorrencia: this.options.Id
    }).success((function(_this) {
      return function(data) {
        return window.GetDiv("grupos-responsaveis-modal-container").html(data);
      };
    })(this));
  };

  return ocorrenciaController;

})();
