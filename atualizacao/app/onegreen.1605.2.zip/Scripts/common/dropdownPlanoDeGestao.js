﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.dropdownPlanoDeGestao = (function() {
  function dropdownPlanoDeGestao(view, options) {
    this.view = view;
    this.options = options;
    this.matrizVisivel = bind(this.matrizVisivel, this);
    this.fechar = bind(this.fechar, this);
    this.aoSelecionarExercicio = bind(this.aoSelecionarExercicio, this);
    this.moverParaPosicaoCorreta = bind(this.moverParaPosicaoCorreta, this);
    this.aoMudarParaListaAnterior = bind(this.aoMudarParaListaAnterior, this);
    this.aoMudarParaProximaLista = bind(this.aoMudarParaProximaLista, this);
    this.configurarRolagem = bind(this.configurarRolagem, this);
    this.aoAbrir = bind(this.aoAbrir, this);
    this.contexto = $('.js-container-dropdown', this.view);
    this.filtroDoPlanoDeGestao = $('.js-filtro-plano-de-gestao', "#filtro-ug-topo");
    this.bodyList = $('.block-list-body', this.contexto);
    this.proximaLista = $('#proximaLista', this.contexto);
    this.listaAnterior = $('#listaAnterior', this.contexto);
  }

  dropdownPlanoDeGestao.prototype.abrir = function() {
    if (!this.filtroDoPlanoDeGestao.data('carregado')) {
      return $as.PlanosDeGestao.Dropdown.get({}, {
        global: false
      }).success((function(_this) {
        return function(data) {
          _this.aoAbrir(data);
          return _this.filtroDoPlanoDeGestao.data('carregado', true);
        };
      })(this));
    } else {
      return this.aoAbrir();
    }
  };

  dropdownPlanoDeGestao.prototype.aoAbrir = function(data) {
    if (data) {
      this.filtroDoPlanoDeGestao.html($(data).html());
    }
    this.contexto.addClass('open');
    this.configurarRolagem();
    this.marcarPlanoDeGestaoAtual();
    return this.aoSelecionarExercicio();
  };

  dropdownPlanoDeGestao.prototype.configurarRolagem = function() {
    this.proximaLista.unbind('click').bind('click', (function(_this) {
      return function() {
        _this.filtroDoPlanoDeGestao.animate({
          left: "-=" + _this.bodyList.width() + ""
        }, 200);
        return _this.aoMudarParaProximaLista();
      };
    })(this));
    return this.listaAnterior.unbind('click').bind('click', (function(_this) {
      return function() {
        _this.filtroDoPlanoDeGestao.animate({
          left: "+=" + _this.bodyList.width() + ""
        }, 200);
        return _this.aoMudarParaListaAnterior();
      };
    })(this));
  };

  dropdownPlanoDeGestao.prototype.aoMudarParaProximaLista = function() {
    var eAUltimaListaASerExibida, listaOculta;
    listaOculta = this.matrizVisivel().next('ul');
    this.matrizVisivel().removeClass('js-matriz-visivel');
    listaOculta.addClass('js-matriz-visivel');
    eAUltimaListaASerExibida = listaOculta.next('ul').length;
    if (!eAUltimaListaASerExibida) {
      this.proximaLista.addClass('disabled');
    }
    return this.listaAnterior.removeClass('disabled');
  };

  dropdownPlanoDeGestao.prototype.aoMudarParaListaAnterior = function() {
    var eAPrimeiraListaASerExibida, listaOculta;
    listaOculta = this.matrizVisivel().prev('ul');
    this.matrizVisivel().removeClass('js-matriz-visivel');
    listaOculta.addClass('js-matriz-visivel');
    eAPrimeiraListaASerExibida = listaOculta.prev('ul').length;
    if (!eAPrimeiraListaASerExibida) {
      this.listaAnterior.addClass('disabled');
    }
    return this.proximaLista.removeClass('disabled');
  };

  dropdownPlanoDeGestao.prototype.marcarPlanoDeGestaoAtual = function() {
    var id, planoDeGestao;
    id = $("#IdDoPlanoDeGestao", "#filtro-ug-topo").val();
    planoDeGestao = $("#" + id);
    planoDeGestao.addClass('selected');
    planoDeGestao.parent('ul').addClass('js-matriz-visivel');
    return this.moverParaPosicaoCorreta();
  };

  dropdownPlanoDeGestao.prototype.moverParaPosicaoCorreta = function() {
    var matrizVisivel, posicaoDaListaVisivel, quantidadeDeListas;
    matrizVisivel = this.matrizVisivel();
    posicaoDaListaVisivel = this.matrizVisivel().index();
    quantidadeDeListas = $('.js-matriz-de-planos ul').length - 1;
    if (posicaoDaListaVisivel === quantidadeDeListas) {
      this.proximaLista.addClass('disabled');
      this.listaAnterior.removeClass('disabled');
    }
    if (posicaoDaListaVisivel === 0) {
      this.listaAnterior.addClass('disabled');
      this.proximaLista.removeClass('disabled');
    }
    return this.filtroDoPlanoDeGestao.css('left', '-' + this.bodyList.width() * posicaoDaListaVisivel + 'px');
  };

  dropdownPlanoDeGestao.prototype.aoSelecionarExercicio = function() {
    return $('.js-matriz-de-planos li', this.contexto).click((function(_this) {
      return function(e) {
        if ($(e.currentTarget).attr("id") !== void 0) {
          $('#NomeDaUnidade', "#filtro-ug-topo").val("");
          $('#IdDaUnidade', "#filtro-ug-topo").val("");
          $('#labelFiltroUG', "#filtro-ug-topo").text("");
          $("#divFiltroPlaGes").fadeOut({
            complete: function() {
              return $("#labelFiltroPlanoGestao", "#filtro-ug-topo").text($(e.currentTarget).text().trim()).show();
            }
          });
          _this.fechar();
          if (_this.options.aoSelecionar) {
            return _this.options.aoSelecionar($(e.currentTarget).attr("id"));
          }
        }
      };
    })(this));
  };

  dropdownPlanoDeGestao.prototype.fechar = function() {
    this.matrizVisivel().removeClass('js-matriz-visivel');
    return this.contexto.removeClass('open');
  };

  dropdownPlanoDeGestao.prototype.matrizVisivel = function() {
    return $("ul.js-matriz-visivel", this.filtroDoPlanoDeGestao);
  };

  return dropdownPlanoDeGestao;

})();
