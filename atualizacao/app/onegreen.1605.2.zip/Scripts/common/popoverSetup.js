﻿var definePopover;

definePopover = function() {
  window.popover = {
    target: null,
    titulo: '',
    conteudo: '',
    placement: 'left',
    build: function() {
      $(popover.target).popover({
        trigger: 'manual',
        html: true,
        title: '<span id="btn-fechar-popover" class="fr cursor-pointer" onclick="popover.hide()"; popover.target=\'\';" ><i class="fa fa-times fa-1"></i></span>' + popover.titulo,
        content: popover.conteudo,
        placement: popover.placement
      });
    },
    close: function(el) {
      var $currentPopover;
      $currentPopover = $(el).closest('.popover');
      $currentPopover.remove();
      $(popover.target).popover('destroy');
      --window.WindowZIndex;
      if (popover.closeCallBack) {
        popover.closeCallBack();
      }
    },
    closeAll: function() {
      return $(".popover").remove();
    },
    reopen: function(btn) {
      btn.parent().parent().show();
    },
    remove: function() {
      $(popover.target).popover('destroy');
    },
    hide: function() {
      if (popover.closeCallBack) {
        popover.closeCallBack();
        popover.closeCallBack = null;
      }
      if ($(popover.target).popover) {
        $(popover.target).popover('hide');
      }
    },
    show: function() {
      popover.build();
      $(popover.target).popover('show');
    }
  };
};

$(function() {
  definePopover();
});
