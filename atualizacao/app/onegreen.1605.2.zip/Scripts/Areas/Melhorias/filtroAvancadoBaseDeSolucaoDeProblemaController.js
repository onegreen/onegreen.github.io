﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.FiltroAvancadoBaseDeSolucaoDeProblemaController = (function() {
  function FiltroAvancadoBaseDeSolucaoDeProblemaController(opcoes, recursos) {
    this.opcoes = opcoes;
    this.recursos = recursos;
    this.verificarOpcoesDeUG = bind(this.verificarOpcoesDeUG, this);
    this.SetOpcaoPadraoCombo = bind(this.SetOpcaoPadraoCombo, this);
    this.AoSelecionarPlanoDeAcao = bind(this.AoSelecionarPlanoDeAcao, this);
    this.ConfigurarScroll = bind(this.ConfigurarScroll, this);
    this.ConfigurarBinds();
    this.LoadComboFiltroAvancado();
    this.LoadComboPlanoDeGestao();
    this.LoadComboOrigens();
    this.LoadComboEtapas();
    this.contexto = this.opcoes.Contexto;
    this.verificarOpcoesDeUG();
  }

  FiltroAvancadoBaseDeSolucaoDeProblemaController.prototype.ConfigurarScroll = function() {
    var api;
    api = $("#divScroll-filtro-avancado").data("jsp");
    if (api) {
      api.destroy();
    }
    return $("#divScroll-filtro-avancado").jScrollPane({
      allowPageScroll: false
    });
  };

  FiltroAvancadoBaseDeSolucaoDeProblemaController.prototype.ConfigurarBinds = function() {
    this.ConfigurarExibirFiltro();
    $('#btnSalvarFiltro').bind('click', (function(_this) {
      return function(e) {
        return _this.SalvarFiltro();
      };
    })(this));
    $('#btnExcluirFiltro').bind('click', (function(_this) {
      return function(e) {
        return $("#excluir-filtro-confirm").modal("show");
      };
    })(this));
    $("#btnLimpar").bind('click', (function(_this) {
      return function(e) {
        return _this.CarregarFiltroAvancado();
      };
    })(this));
    return $("#fecharFiltroAvancado", this.opcoes.Contexto).bind('click', (function(_this) {
      return function(e) {
        return $(_this.opcoes.Contexto).toggle();
      };
    })(this));
  };

  FiltroAvancadoBaseDeSolucaoDeProblemaController.prototype.LoadComboFiltroAvancado = function() {
    var select;
    select = (function(_this) {
      return function($input) {
        return _this.CarregarFiltroAvancado($input.val());
      };
    })(this);
    setCombo(this.opcoes.Contexto, "#FiltroAvancadoNome", select);
    return this.SetOpcaoPadraoCombo("#FiltroAvancadoNome", {
      Key: "",
      Value: "(" + this.recursos.Nenhum + ")"
    });
  };

  FiltroAvancadoBaseDeSolucaoDeProblemaController.prototype.LoadComboPlanoDeGestao = function() {
    setCombo(this.opcoes.Contexto, "#PlanoDeGestaoNome", this.AoSelecionarPlanoDeAcao);
    this.SetOpcaoPadraoCombo("#PlanoDeGestaoNome", {
      Key: "",
      Value: "(" + this.recursos.Todos + ")"
    });
    return this.LoadComboUnidadeGerencial($("#IdDoPlanoDeGestao", this.opcoes.Contexto).val());
  };

  FiltroAvancadoBaseDeSolucaoDeProblemaController.prototype.LoadComboUnidadeGerencial = function(idDoPlanoDeGestao) {
    var parametros;
    parametros = {
      idDoPlanoDeGestao: idDoPlanoDeGestao
    };
    return setCombo(this.opcoes.Contexto, "#UnidadeGerencialNome", this.verificarOpcoesDeUG, parametros);
  };

  FiltroAvancadoBaseDeSolucaoDeProblemaController.prototype.LoadComboOrigens = function() {
    var $combo, $divCombo, ListaDeOrigensViewModel, onSelect;
    ListaDeOrigensViewModel = {
      ListaDeOrigens: ko.observableArray(this.opcoes.OrigensSelecionadas),
      removeItem: function(origem) {
        return this.ListaDeOrigens.remove(origem);
      }
    };
    window.ListaDeOrigensViewModel = ListaDeOrigensViewModel;
    ko.applyBindings(ListaDeOrigensViewModel, $('#origens_itens')[0]);
    $combo = $("#OrigensCombo");
    $divCombo = $combo.parents("div.autocompleter");
    onSelect = (function(_this) {
      return function() {
        var apiScroll;
        apiScroll = $("#divScroll-filtro-avancado").data().jsp;
        apiScroll.reinitialise();
        return apiScroll.scrollToBottom();
      };
    })(this);
    return $combo.autocompleter($divCombo.attr("data-url"), {
      elementToClick: "#OrigensComboBtn",
      multiSelectArray: ListaDeOrigensViewModel.ListaDeOrigens,
      multiSelectElement: "#origens_itens",
      onSelected: function() {
        return onSelect();
      }
    });
  };

  FiltroAvancadoBaseDeSolucaoDeProblemaController.prototype.LoadComboEtapas = function() {
    var $combo, $divCombo, EtapasViewModel, _this, onSelect;
    _this = this;
    EtapasViewModel = {
      Etapas: ko.observableArray(this.opcoes.EtapasSelecionadas),
      removeItem: function(etapa) {
        return this.Etapas.remove(etapa);
      },
      removeAll: function() {
        var array;
        array = this.Etapas.slice(0);
        this.Etapas.removeAll(array);
        return _this.LoadComboEtapas();
      }
    };
    window.EtapasViewModel = EtapasViewModel;
    ko.applyBindings(EtapasViewModel, $('#etapas_itens')[0]);
    $combo = $("#EtapasCombo", this.opcoes.Contexto);
    $divCombo = $combo.parents("div.autocompleter");
    onSelect = (function(_this) {
      return function(jsonItem) {
        var apiScroll;
        if (jsonItem.Id === 0) {
          EtapasViewModel.removeAll();
          $combo.val(jsonItem.Nome);
        }
        apiScroll = $("#divScroll-filtro-avancado").data().jsp;
        apiScroll.reinitialise();
        return apiScroll.scrollToBottom();
      };
    })(this);
    return $combo.autocompleter($divCombo.attr("data-url"), {
      elementToClick: "#EtapasComboBtn",
      multiSelectArray: EtapasViewModel.Etapas,
      multiSelectElement: "#etapas_itens",
      defaultOption: {
        Key: "0",
        Value: "(" + this.recursos.TodasNaoCanceladas + ")"
      },
      onSelected: function(input) {
        return onSelect(input);
      }
    });
  };

  FiltroAvancadoBaseDeSolucaoDeProblemaController.prototype.AoSelecionarPlanoDeAcao = function(inputCombo) {
    $('#UnidadeGerencialNome', this.opcoes.Contexto).val("(" + this.recursos.Todas + ")");
    $('#IdUnidadeGerencial', this.opcoes.Contexto).val("");
    this.LoadComboUnidadeGerencial(inputCombo.val());
    return this.verificarOpcoesDeUG();
  };

  FiltroAvancadoBaseDeSolucaoDeProblemaController.prototype.SetOpcaoPadraoCombo = function(idCombo, opcao) {
    return $(idCombo, this.opcoes.Contexto).data("autocompleter").setOpcaoPadrao(opcao);
  };

  FiltroAvancadoBaseDeSolucaoDeProblemaController.prototype.ConfigurarExibirFiltro = function() {
    $("#filtro-aplicado, #btnFiltroAvancado").off('click');
    return $("#filtro-aplicado, #btnFiltroAvancado").on('click', (function(_this) {
      return function(e) {
        $(_this.opcoes.Contexto).toggle();
        return _this.ConfigurarScroll();
      };
    })(this));
  };

  FiltroAvancadoBaseDeSolucaoDeProblemaController.prototype.verificarOpcoesDeUG = function() {
    if ($('#IdUnidadeGerencial', this.contexto).val() !== '' && $("#IdDoPlanoDeGestao", this.contexto).val() !== '') {
      return $("#opcoesDeUG", this.contexto).show();
    } else {
      return $("#opcoesDeUG", this.contexto).hide();
    }
  };

  return FiltroAvancadoBaseDeSolucaoDeProblemaController;

})();
