﻿window.createEditIframeSIMPartController = (function() {
  function createEditIframeSIMPartController(contexto) {
    this.contexto = contexto;
    $(this.contexto).window();
  }

  return createEditIframeSIMPartController;

})();
