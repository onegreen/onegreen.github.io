﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.backlogController = (function() {
  function backlogController(options, func) {
    this.options = options;
    this.defineFiltros = bind(this.defineFiltros, this);
    this.defineFiltros(func);
  }

  backlogController.prototype.defineFiltros = function(func) {
    if (window.FiltroBacklog === void 0) {
      $.ajax({
        url: this.options.UrlFiltroDefault,
        async: false,
        success: function(filtro) {
          return window.FiltroBacklog = {
            IdUnidadeGerencial: filtro.IdUnidadeGerencial,
            UnidadeGerencialNome: filtro.UnidadeGerencialNome,
            IncluirSubordinadas: filtro.IncluirSubordinadas,
            IncluirSubordinadasNome: filtro.IncluirSubordinadasNome,
            Descricao: filtro.Descricao,
            Status: filtro.Status,
            StatusNome: filtro.StatusNome,
            ColunaOrdenacao: filtro.ColunaOrdenacao,
            TipoOrdenacao: filtro.TipoOrdenacao
          };
        }
      });
    }
    return func();
  };

  return backlogController;

})();
