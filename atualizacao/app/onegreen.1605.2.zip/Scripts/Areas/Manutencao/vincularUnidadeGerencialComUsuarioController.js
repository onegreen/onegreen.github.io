﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.vincularUnidadeGerencialComUsuarioController = (function() {
  function vincularUnidadeGerencialComUsuarioController(options) {
    this.options = options;
    this.salvarEAdicionarNovo = bind(this.salvarEAdicionarNovo, this);
    this.salvar = bind(this.salvar, this);
    this.executarVinculoDeUnidadeGerencial = bind(this.executarVinculoDeUnidadeGerencial, this);
    this.configurarComboUnidadeGerencial = bind(this.configurarComboUnidadeGerencial, this);
    this.configurarComboPlanoDeGestao = bind(this.configurarComboPlanoDeGestao, this);
    $("#vincularunidadegerencial-modal").window();
    this.configurarComboPlanoDeGestao();
  }

  vincularUnidadeGerencialComUsuarioController.prototype.configurarComboPlanoDeGestao = function() {
    return $('#PlanoDeGestaoNome').autocompleter(this.options.urlConfigurarComboPlanoDeGestao, {
      loadOnDemand: false,
      elementToClick: "#PlanoDeGestaoNomeBtn",
      onSelected: (function(_this) {
        return function() {
          return _this.configurarComboUnidadeGerencial();
        };
      })(this),
      keyElement: "#IdPlanoDeGestao"
    });
  };

  vincularUnidadeGerencialComUsuarioController.prototype.configurarComboUnidadeGerencial = function() {
    return $('#UnidadeGerencialNome').autocompleter(this.options.urlConfigurarComboUnidadeGerencial, {
      loadOnDemand: false,
      elementToClick: "#UnidadeGerencialNomeBtn",
      keyElement: "#IdUnidadeGerencial",
      parameters: {
        idDoUsuario: this.options.idDoUsuario,
        idDoPlanoDeGestao: $("[name=IdPlanoDeGestao]").val()
      }
    });
  };

  vincularUnidadeGerencialComUsuarioController.prototype.executarVinculoDeUnidadeGerencial = function(adicionarNovo) {
    idDoUsuario;
    idDoGrupo;
    var idDoGrupo, idDoUsuario, urlRegrasDoSistemaIndexPorModulo;
    urlRegrasDoSistemaIndexPorModulo = this.options.urlRegrasDoSistemaIndexPorModulo;
    if ($("#BotaoTipoUsuario").hasClass("btn-warning")) {
      idDoUsuario = $("#IdDoUsuario", "#contextoDasRegras").val();
    } else if ($("#BotaoTipoGrupo").hasClass("btn-warning")) {
      idDoGrupo = $("#IdDoGrupoDoUsuario", "#contextoDasRegras").val();
    }
    return $.ajax({
      type: "POST",
      url: this.options.urlExecutarVinculoDeUnidadeGerencial,
      data: {
        idDoUsuario: idDoUsuario,
        idDoGrupoDoUsuario: idDoGrupo,
        idDoModulo: window.regrasDoSistemaController.currentModulo,
        idDaUnidadeGerencial: $("#IdUnidadeGerencial").val(),
        incluirSubordinadas: $("input[name=IncluirSubordinadas]:checked").length > 0
      },
      success: function(data) {
        if (data.success) {
          if ($("#BotaoTipoUsuario").hasClass("btn-warning")) {
            idDoUsuario = $("#IdDoUsuario", "#contextoDasRegras").val();
          } else if ($("#BotaoTipoGrupo").hasClass("btn-warning")) {
            idDoGrupo = $("#IdDoGrupoDoUsuario", "#contextoDasRegras").val();
          }
          return $.get(urlRegrasDoSistemaIndexPorModulo, {
            idDoUsuario: idDoUsuario,
            idDoGrupoDeUsuario: idDoGrupo,
            idDoModulo: window.regrasDoSistemaController.currentModulo
          }).done((function(_this) {
            return function(html) {
              $("#regrasPorModulo").html(html);
              $("i[data-idunidade]").click(window.RegrasDoSistema.exibirOcultarSubordinadas);
              if (adicionarNovo) {
                return window.RegrasDoSistema.vincularUnidadeGerencial();
              }
            };
          })(this));
        } else {
          return $("#modalVincularUnidadeGerencial").html(data);
        }
      }
    });
  };

  vincularUnidadeGerencialComUsuarioController.prototype.salvar = function() {
    this.executarVinculoDeUnidadeGerencial();
    return $(".close").click();
  };

  vincularUnidadeGerencialComUsuarioController.prototype.salvarEAdicionarNovo = function() {
    return this.executarVinculoDeUnidadeGerencial(true);
  };

  return vincularUnidadeGerencialComUsuarioController;

})();
