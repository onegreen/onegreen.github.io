﻿this.ConfiguracoesController = (function() {
  function ConfiguracoesController(options) {
    var MessageNoresultsfound;
    this.options = options;
    $('#pesquisar').focus().change(this.procurarTermos);
    $('#btnPesquisar').click(this.procurarTermos);
    MessageNoresultsfound = $('#noresultsfound');
  }

  ConfiguracoesController.prototype.procurarTermos = function() {
    var termo;
    termo = $('#pesquisar').val().toLowerCase();
    $as.Admin.Configuracoes.RemoverCaracteresDaPesquisa.get({
      termo: termo
    }).done((function(_this) {
      return function(data) {
        return termo = data.termo;
      };
    })(this));
    $("#nenhum-resultado-encontrado").hide();
    if (termo === "" || termo === null) {
      $("li[data-descricao]").show();
    } else {
      $("li[data-descricao*='" + termo + "']").show();
      $("li[data-descricao]").not("[data-descricao*='" + termo + "']").hide();
    }
    $('[data-noresultsfound]').hide();
    return $(".result-list").each((function(_this) {
      return function(index) {
        if ($(".result-list").eq(index).find("li:visible").length === 0) {
          $(".result-list").eq(index).next().show();
        }
      };
    })(this));
  };

  return ConfiguracoesController;

})();
