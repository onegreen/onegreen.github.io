﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.relatorioResultadoDasAvaliacoes = (function() {
  function relatorioResultadoDasAvaliacoes(contexto, options, resource) {
    this.contexto = contexto;
    this.options = options;
    this.resource = resource;
    this.voltarPlanoDeGestao = bind(this.voltarPlanoDeGestao, this);
    this.postFormUrl = bind(this.postFormUrl, this);
    this.imprimir = bind(this.imprimir, this);
    this.$contexto = $(this.contexto);
    this.$contexto.window();
    setCombo(this.contexto, "#UnidadeGerencialNome");
    this.$contexto.find('[rel=tooltip]').tooltip();
  }

  relatorioResultadoDasAvaliacoes.prototype.imprimir = function(obj, event, url) {
    var $summary;
    event.preventDefault();
    if (this.$contexto.find('#idDaUnidadeGerencial').val() === "") {
      this.$contexto.find(".form-group.autocompleter").addClass("error");
      $summary = this.$contexto.find(".js-summary");
      $summary.addClass("validation-summary-errors");
      return $summary.find("ul").html("<li>" + this.resource.InformeAUnidadeGerencial + "</li>");
    } else {
      this.$contexto.find('.close').click();
      if (url === null || url === void 0 || url === '') {
        return this.$contexto.find('form').submit();
      } else {
        return this.postFormUrl(url);
      }
    }
  };

  relatorioResultadoDasAvaliacoes.prototype.postFormUrl = function(url) {
    return $.ajax({
      url: url,
      data: this.$contexto.find('form').serialize(),
      method: 'POST',
      type: 'html',
      success: (function(_this) {
        return function(html) {
          return $('#main').html(html);
        };
      })(this)
    });
  };

  relatorioResultadoDasAvaliacoes.prototype.voltarPlanoDeGestao = function(IdDoPlanoDeGestao) {
    return $as.PlanosDeGestao.Index.get().done((function(_this) {
      return function(html) {
        $('#main').html(html);
        $("#Plano-" + IdDoPlanoDeGestao).click();
        return setTimeout(function() {
          return $('a[href="#tabCiclosDeAvaliacao"]').click();
        }, 200);
      };
    })(this));
  };

  return relatorioResultadoDasAvaliacoes;

})();
