/*    
Example
        
$("#IdInputText").autocompleter('<%= Url.Action("Action", "Controller", new { format = Format.Json }) %>',
{
loadOnDemand: true, // Default false, load data in 200/200
// Your controller need receive two parameters: 'skip' ands 'take'                                
elementToClick: "#ElementWhenClickShowOptions",
keyElement: "#InputHiddenWhereIdWillBeHolded",
onSelected: funcion(input){ alert(input.val()); }, // or function name
parameters: { param : function(){ return myValue; }}            
});
*/
(function ($) {

	$.autocompleter = function (el, url, options) {
		// To avoid scope issues, use 'base' instead of 'this'
		// to reference this class from internal events and functions.
		var base = this;
		base.listHash = guidGenerator();
		// Access to jQuery and DOM versions of element
		base.$el = $(el);
		base.elid = base.$el.attr("id");
		base.el = el;

		// Add a reverse reference to the DOM object
		base.$el.data("autocompleter", base);

		base.parameterFlag = options.parameters ? true : false;

		var textInput = null;

		var valueInput = null;
		var multiSelectArray = null;
		var multiSelectElement = null;
		var JSONList = null;
		var list = null;

		var oldText = '';
		var typingTimeout;
		var size = 0;
		var selected = -1;

		var settings = null;

		base.init = function () {
			base.options = $.extend({}, $.autocompleter.defaultOptions, options);
			$(window).scroll(function (e) {
				if (list.is(':visible')) {
					list.hide();
					base.showList(list);
				}
			});
			settings = base.options;

			//this is the original input
			textInput = base.$el;

			if (!textInput.attr("readonly")) {
				if (settings.multiSelect)
					textInput.before('<ul class="ComboItens"></ul>');

				//create a new hidden input that will be used for holding the return value when posting the form, then swap names with the original input
				if (settings.keyElement !== null)
					valueInput = $(settings.keyElement);

				if (settings.multiSelectArray !== null) {
					multiSelectArray = settings.multiSelectArray;
				}

				if (settings.multiSelectElement !== null) {
					multiSelectElement = $(settings.multiSelectElement);
					$("a", multiSelectElement).click(base.removeElement);
				}
				var id = "#" + textInput.attr('id') + "_list" + base.listHash;
				if ($(id).length > 0)
					$(id).remove();

				//create the ul that will hold the text and values
				list = $('<ul id="' + textInput.attr('id') + '_list' + base.listHash + '" class="autocomplete"></ul>')

				if (!options.sameInputContainer)
					list.appendTo(settings.container);
				else
					textInput.after(list);

				/*$(base).ajaxStop(function () {
                if ($("#" + base.elid).length == 0)
                list.hide();
                });*/

				$.autocompleter.lists.push(textInput.attr('id') + '_list' + base.listHash);

				if ($.browser.msie && $.browser.version == "6.0")
					list.css({ top: textInput.offset().top + textInput.outerHeight(), left: textInput.offset().left, width: textInput.outerWidth(), 'z-index': 10010 });
				else
					list.css({ top: textInput.offset().top + textInput.outerHeight(), left: textInput.offset().left, 'min-width': textInput.outerWidth(), 'z-index': 10010 });

				if (!settings.openAsDropdown)
				{
				    if (settings.defaultText != null)
					    textInput.val(settings.defaultText);

				    textInput.keydown(base.keyDownHandler);
				    textInput.keyup(base.keyUpHandler);
				    //textInput.change(base.onChangeHandler);
				}

				if (settings.elementToClick !== null) {
					$(settings.elementToClick).unbind('click').click(base.handleClick);
					base.$elementToClick = $(settings.elementToClick);
				}

				if (settings.customButton != null) {
					textInput.parent().find('.add-on').after(settings.customButton);
				}
				//'<span class="add-on btn" title=""><i class="icon-search"></i></span>'

				$(document).click(function (e) {
					list.fadeOut('fast');
				});
			}
		};

		base.setOnSelected = function (func) {
			settings.onSelected = func;
		};

		base.setSelectOnTypeArrow = function (selecionar) {
			settings.selectOnTypeArrow = selecionar;
		};

		base.setParameters = function (parameters) {
			settings.parameters = parameters;
		};

		base.abrirPraCima = function (abrirPraCima) {
			settings.abrirParaCima = abrirPraCima
		};

		base.setOpcaoPadrao = function (opcao) {
			settings.defaultOption = opcao;
		};

		base.setactionOption = function (opcao) {
			settings.actionOption = opcao;
		};

		base.setDataType = function (type) {
			settings.dataType = type;
		};

		base.clear = function () {
			//list.fadeOut('fast');
			size = 0;
			selected = -1;
		};

		base.goToSelectedItem = function () {
			if (valueInput !== null) {
				if (valueInput.val() != 0) {
					var itemSelected = $("li[key='" + valueInput.val() + "']", list).addClass('selected');
					selected = list.children().index(itemSelected);
					list.scrollTop(selected * itemSelected.outerHeight());
				}
			}
		};

		base.appendToMultiSelect = function (itemSelected) {

			//var itemSelecionado = { "Id": itemSelected.attr('key'), "Nome": itemSelected.text() };

			var jsonItem = '{ "Id" : ' + itemSelected.attr('key') + ', "' + settings.multiSelectDescriptionName + '" : "' + itemSelected.text() + '" }';

			jsonItem = jQuery.parseJSON(jsonItem);

			var execute = function () {
			    multiSelectArray.push(jsonItem);

			    $("a", multiSelectElement).click(base.removeElement);

			    if (jsonItem.Id != '' && jsonItem.Id != 0)
			        itemSelected.remove();

			    size = list.children().length;
			    selected = -1;
			    textInput.val('');
			};

			if (settings.customizeMultiSelectDescriptionName != null)
			    settings.customizeMultiSelectDescriptionName(jsonItem, settings.multiSelectDescriptionName, execute);
			else
			    execute()

			if (settings.onSelected != null)
				settings.onSelected(jsonItem);
		};

		base.removeElement = function (evt) {
			$(this).parent().remove();
			oldText = '';
			list.fadeOut('fast');
			list.html('');
			evt.preventDefault();
		}

		base.getData = function (text) {
		    var emptyList = $("li", list).length == 0;
			window.clearInterval(typingTimeout);
			if (settings.minChars != null && text.length >= settings.minChars) {
				if (settings.before == "function") {
					settings.before(textInput, text);
				}
				settings.parameters.filter = text == '$click$' ? '' : text;
				if (settings.loadOnDemand == true || settings.loadOnDemand == "true") {
					settings.parameters.skip = 0;
					settings.parameters.take = 200;
				}

				if (settings.onlyOneRequest)
				{
				    if (emptyList)
				    {
				        base.executeRequest(text);
				    }
				    else
				    {
				        base.showList(list);
				        base.goToSelectedItem();
				    }
				}
				else
				{
				    if (text != oldText || base.parameterFlag)
				    {
				        base.executeRequest(text);
				    }
				    else
				    {
				        base.showList(list);
				        base.goToSelectedItem();
				    }

				}

                oldText = text;
			}


		};

		base.executeRequest = function (text) {
		    base.clear();
		    $.setInputFocus = false;
		    if (settings.JSONList == null) {
		        $.ajax({
		            global: false,
		            'url': url,
		            data: settings.parameters,
		            dataType: settings.dataType,
		            success: function (data) {
		                base.getDataSuccess(data, text);
		            }
		        });
		    }
		    else {
		        var listaJson = settings.JSONList;

		        if (settings.parameters.filter != '')
		            listaJson = _.reject(settings.JSONList, function (item) { return item.Value.toLowerCase().indexOf(settings.parameters.filter.toLowerCase()) == -1; });

		        base.getDataSuccess(listaJson, text);
		    }
		    if (settings.onLoad != null)
		        settings.onLoad($('#' + textInput.attr('id') + '_list' + base.listHash));
		}

		base.getDataSuccess = function (data, text) {
			if (data) {
				if (settings.dataType.toLowerCase() == 'json') {
					var itensESize = base.getItensESize(data);
					var items = itensESize.itens;
					size = itensESize.size;

					list.html(items);
				}
				else if (settings.dataType.toLowerCase() == 'html') {
					list.html(data);
					size = list.children().length;
				}

				if (size > 0) {
					var firstItem = list.children().eq(0);
					if (text.toString().toUpperCase() == firstItem.text().toUpperCase()) {
						selected = 0;
						if (valueInput != null)
							//valueInput.val(firstItem.attr('key'));
							base.goToSelectedItem();
					}
				}

				if ($.browser.msie && $.browser.version == "6.0") {
					if (30 * size > 200)
						list.css({ height: 200 });
					else
						list.css({ height: 'auto' });
				}

				base.showList(list);
				base.setClick();

				if (settings.after == "function") {
					settings.after(textInput, text);
				}
			}
			base.goToSelectedItem();
			textInput.focus();

			if (settings.htmlExtra != null) {
				$('li', list).append(settings.htmlExtra());
			}

			if ((settings.loadOnDemand == true || settings.loadOnDemand == "true") && data.length == 200) {
				list.append($('<li id="moreResult" key="000" > ... </li>').click(function (event) { base.getDataRange(settings.parameters.take, 200); event.stopPropagation(); }));
			}



		};
		base.setClick = function () {
			list.children().click(function (event) {
				list.children(".selected").removeClass("selected");
				$this = $(this);
				$this.addClass("selected");
				if (valueInput !== null) {

					var isActionOption = $this.closest('li').data('action-option');

					if (isActionOption) {
						if (settings.evaluateActionOption) {
							if (settings.setInputTextValue)
								textInput.val($this.text());
							list.fadeOut('fast');
							valueInput.val($this.attr('key'));
							selected = list.children().index(this);
							base.executeOnSelected($this)
						}
						else {
							textInput.val('');
						}
					}
					else {
                        if (settings.setInputTextValue)
                        {
                            if (settings.openAsDropdown)
                            {
                                textInput.html($this.text());
                                inputNameId = textInput.data("input-name-id");
                                $(inputNameId).val($this.text());
                            }
                            else
                            {
                                textInput.val($this.text());
                            }
                        }
						list.fadeOut('fast');
						valueInput.val($this.attr('key'));
						selected = list.children().index(this);
						base.executeOnSelected($this)
					}
				} else {
					base.appendToMultiSelect($this);
					//textInput.val('');
					list.fadeOut('fast');
					textInput.focus();
				}
				return;
			});
		};
		base.executeOnSelected = function (input) {
			if (settings.onSelected != null) {
				var parametro = valueInput;

				if (settings.JSONList != null)
					parametro = settings.JSONList[$(input).attr('index')]

				settings.onSelected(parametro);
			}
		};
		base.getItensESize = function (data) {
			var items = '';
			var size = 0;

			//fix IE8 com seletor "[value=valor]"
			var verificarSelecionados = function (value) {
				var retorno = false;
				$(':input', multiSelectElement).map(function () {
					if ($(this).val() == value) {
						retorno = true;
						return;
					}
				});

				return retorno;
			};

			if (settings.defaultOption != null)
				items += '<li key="' + settings.defaultOption.Key + '">' + settings.defaultOption.Value + '</li>';

			if (multiSelectElement == null) {
				size = data.length;
				for (i = 0; i < data.length; i++)//iterate over all options
				{
					var index = settings.JSONList != null ? data[i].Index : i;
					items += '<li index="' + index + '" key="' + data[i].Key + '">' + data[i].Value + '</li>';
				}
			}
			else {
				for (i = 0; i < data.length; i++)//iterate over all options
				{
					if (!verificarSelecionados(data[i].Key)) {
						var index = settings.JSONList != null ? data[i].Index : i;
						items += '<li index="' + index + '" key="' + data[i].Key + '">' + data[i].Value + '</li>';
						size++;
					}
				}
			}

			if (settings.actionOption != null)
				items += '<li class="adicionar-combo" data-action-option="true" key="' + settings.actionOption.Key + '">' + settings.actionOption.Value + '</li>';

			return { itens: items, size: size };
		}

		base.getDataRange = function (skip, take) {
			settings.parameters.skip = skip;
			settings.parameters.take = take;
			if (settings.JSONList == null) {
				$.ajax({
					'url': url,
					global: false,
					data: settings.parameters,
					dataType: settings.dataType,
					success: function (data) {
						base.getDataRangeSuccess(data, skip, take);
					}
				});
			}
			else {
				var listaJson = settings.JSONList;

				if (settings.parameters.filter != '')
					listaJson = _.reject(settings.JSONList, function (item) { return item.Value.toLowerCase().indexOf(settings.parameters.filter.toLowerCase()) == -1; });

				base.getDataRangeSuccess(listaJson, skip, take);
			}

			if (settings.onLoad != null)
				settings.onLoad($('#' + textInput.attr('id') + '_list' + base.listHash));
		}

		base.getDataRangeSuccess = function (data, skip, take) {
			if (data) {
				if (settings.dataType.toLowerCase() == 'json') {

					var itensESize = base.getItensESize(data);
					var items = itensESize.itens;
					size = itensESize.size;

					$("li:last", list).before(items);
					$("li:last", list).remove();

					base.setClick();

					if (data.length == 200) {
						list.append($('<li id="moreResult" key="000"> ... </li>').click(function (event) { base.getDataRange(skip + 200, 200); event.stopPropagation(); }));
					}
					base.showList(list);
				}
			}
		}

		base.onChangeHandler = function (e) {
			settings.parameters.filter = textInput.val();
			base.clear();
			$.setInputFocus = false;
			if (valueInput != null) {
				if (valueInput.val() == '') {
					if (settings.JSONList == null) {
						setTimeout(function () {
							$.ajax({
								global: false,
								'url': url,
								data: settings.parameters,
								dataType: settings.dataType,
								async: false,
								success: function (data) {
									if (data) {
										if (settings.dataType.toLowerCase() == 'json') {
											if (data.length > 0) {
												if (data[0].Value.toUpperCase() == textInput.val().toUpperCase()) {
													valueInput.val(data[0].Key);
													textInput.val(data[0].Value);
													selected = 0;
													if (settings.onSelected != null)
														settings.onSelected(valueInput);
												}
											}
											else {
												if (settings.selectOnTypeArrow)
													textInput.val('');
											}
										}
									}
								}
							})
						}, 200);
					}
				}
			}

		};

		base.keyUpHandler = function (e) {
			/*Tirei a funcionalidade de trazer os dados
            if (e.which == 9) {
            if (settings.elementToClick !== null)
            $(settings.elementToClick).click();
            }*/
		};

		base.keyDownHandler = function (e) {
			window.clearInterval(typingTimeout);
			if (e.which == 27)//escape
			{
				list.fadeOut('fast');
			} /* else if (e.which == 46 || e.which == 8)//delete and backspace
			{
				//invalidate previous selection
				if (settings.validSelection) {
					if (valueInput !== null) {
						valueInput.val('');

						//if (settings.onSelected != null) {
						//    settings.onSelected(valueInput);
						//}
					}
				}
			}*/
			else if (e.which == 13)//enter 
			{
				var listStatus = list.css("display") == "none";

				if (list.css("display") == "none")//if the list is not visible then make a new request, otherwise hide the list
				{
					if (!settings.selectOnTypeArrow)
						textInput.change();
					else
						base.getData(textInput.val());

				} else {
					if (multiSelectElement !== null) {
						if (selected !== -1) {
							var itemSelected = list.children().eq(selected);
							base.appendToMultiSelect(itemSelected);
							textInput.val('');
							list.fadeOut('fast');
							textInput.focus();
						}
						else {
							if (settings.canAddNewItens) {
								var itemSelecionado = { "Id": 0, "Nome": textInput.val() };
								multiSelectArray.push(itemSelecionado);
								if (settings.onSelected != null)
									settings.onSelected(itemSelecionado);
							}
						}
						textInput.val('');
					} else {
						list.fadeOut('fast');
					}
				}

				e.preventDefault();

				var itemSelected = list.children('.selected')

				if(itemSelected.length == 0)
				    itemSelected =  list.children(':first');

				if (!settings.selectOnTypeArrow) {
					valueInput.val(itemSelected.attr('key'));
					base.executeOnSelected($(itemSelected));

				}
				return false;
			}
			else if (e.which == 40 || e.which == 9 || e.which == 38)//move up, down 
			{
				switch (e.which) {
					case 40:
						selected = selected >= size - 1 ? 0 : selected + 1;
						break;
					case 9:
						selected = selected == -1 ? 0 : selected;
						list.fadeOut('fast');
						setTimeout(function () { base.onChangeHandler(e); }, 100);
						break;
					case 38:
						selected = selected <= 0 ? size - 1 : selected - 1;
						break;
					default:
						break;
				}
				//set selected item and input values
				list.children().removeClass('selected');
				var itemSelected = list.children().eq(selected);


				if (itemSelected.length == 1) {
					if (settings.selectOnTypeArrow && !settings.keepItemIfNotExists) {
						textInput.val(itemSelected.text());
						if (valueInput !== null) {
							valueInput.val(itemSelected.attr('key'));
							base.executeOnSelected($(itemSelected))

						}
					}
					itemSelected.addClass('selected');
					list.animate({ scrollTop: selected * itemSelected.outerHeight() }, { queue: false, duration: 'fast' });
				}


			} else {
				//invalidate previous selection
				if (settings.validSelection) {
					if (valueInput !== null) {
						if (settings.createOptionIfNotExists && textInput.val().trim() !== '') {
							valueInput.val('0');
						} else {
							valueInput.val('');
						}
					}
				}
				typingTimeout = window.setTimeout(function () {
					base.getData(textInput.val());
					$(".selected", list).css('display', 'none');
				}, settings.timeout);
			}
		};

		base.handleClick = function (e) {
			//if the list is not visible then make a new request, otherwise hide the list            
			if (list.css("display") == "none") {
				base.getData('$click$');
			} else {
				list.fadeOut('fast');
			}
			textInput.focus();
			e.stopPropagation();
		};

		base.showList = function (actualList) {

			if (!textInput.attr("readonly")) {
				var calculatedTop = textInput.offset().top + textInput.outerHeight();
				sb_windowTools.updateDimensions();

				var abrirPraCima = Math.abs(Math.abs(sb_windowTools.windowSize.windowHeight - textInput.offset().top) - Math.abs(sb_windowTools.pageDimensions.verticalOffsetBottom())).value < 240;
				var $divModal = textInput.closest('.modal')

				if ($divModal.length > 0) {
					abrirPraCima = false;
				}

				if (abrirPraCima || settings.abrirParaCima) {
					calculatedTop = textInput.offset().top - list.height() - 2;
				}
				//alert(calculatedTop);
				list.css({ top: calculatedTop, left: textInput.offset().left, 'min-width': textInput.outerWidth(), 'z-index': 10010, width: textInput.outerWidth() });
				actualList.show();
				for (var i = 0; i <= $.autocompleter.lists.length; i++) {
					if ($.autocompleter.lists[i] != actualList.attr('id'))
						$('#' + $.autocompleter.lists[i]).fadeOut('fast');
				}
			}
		};

		base.disable = function () {
			base.$el.attr('disabled', 'disabled');
			if (base.$elementToClick != null) {
				base.$elementToClick.attr('disabled', 'disabled');
				base.$elementToClick.unbind('click');
			}
		};

		base.enable = function () {
			base.$el.removeAttr('disabled', 'disabled');
			if (base.$elementToClick != null) {
				base.$elementToClick.removeAttr('disabled', 'disabled');
				base.$elementToClick.unbind('click').click(base.handleClick);
			}
		};

		base.disableElseEnable = function (habilitar) {
			if (habilitar)
				base.disable();
			else
				base.enable();
		}

		base.reset = function () {
			textInput.val('');
			valueInput.val('');
		};

		base.destroyList = function () {
			list.remove();
		};

		base.value = function () {
			return valueInput.val();
		};

		base.text = function () {
			return textInput.val();
		};

		// Run initializer
		base.init();
	};

	$.autocompleter.defaultOptions = {
		minChars: 1,
		timeout: 500,
		after: null,
		before: null,
		onSelected: null,
		onLoad: null,
		customizeMultiSelectDescriptionName: null,
		validSelection: true,
		elementToClick: null,
		multiSelectArray: null,
		multiSelectElement: null,
		canAddNewItens: true,
		loadOnDemand: false,
		keyName: null,
		keyElement: null,
		dataType: 'json',
		multiSelectDescriptionName: 'Nome',
		createOptionIfNotExists: false,
		defaultOption: null,
		parameters: {},
		customButton: null,
		selectOnTypeArrow: true,
		abrirParaCima: false,
		htmlExtra: null,
		keepItemIfNotExists: false,
		actionOption: null,
		evaluateActionOption: true,
		container: '#main',
		setInputTextValue: true,
		openAsDropdown: false,
        onlyOneRequest: false
	};

	$.autocompleter.lists = new Array();

	$.fn.autocompleter = function (url, options) {
		return this.each(function () {
			(new $.autocompleter(this, url, options));
		});
	};

	$.fn.setValueAutocompleter = function (key, name) {
	    var elemento = this.closest('.autocompleter');
	    var inputKey = elemento.find('input[type=hidden]');
	    inputKey.val(key);
	    var inputName = elemento.find('input[type=text]');
	    inputName.val(name);
	}

})(jQuery);


function guidGenerator() {
	var S4 = function () {
		return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
	};
	return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
}

function setComboAsDropdown(contextId, elementId, parameters, onSelected) {
    var opcoes = {
		contextId: contextId,
		elementId: elementId + "-Combo-As-Dropdown",
		onSelected: onSelected,
		defaultOption: null,
		actionOption: null,
		createOptionIfNotExists: false,
		customButton: '',
		parameters: parameters == undefined || parameters == null ? {} : parameters,
		sameInputContainer: null,
		openAsDropdown: true,
        onlyOneRequest: true
	};
    
    $(opcoes.elementId, options.contextId).click(function () {
        setTimeout(function () {
            $(opcoes.elementId + "Btn", options.contextId).click();
        }, 100)
    });
	return setComboJSON(opcoes);
}

function setCombo(contextId, elementId, funcOnSelect, parameters, createOptionIfNotExists, customButton, defaultOption, actionOption, sameInputContainer) {

	var opcoes = {
		contextId: contextId,
		elementId: elementId,
		onSelected: funcOnSelect,
		defaultOption: defaultOption,
		actionOption: actionOption,
		createOptionIfNotExists: createOptionIfNotExists != null ? createOptionIfNotExists : false,
		customButton: customButton != null ? customButton : '',
		parameters: parameters == undefined || parameters == null ? {} : parameters,
		sameInputContainer: sameInputContainer
	};

	return setComboJSON(opcoes);
}

function setComboJSON(options) {

	var optionsDefault = {
		contextId: null,
		elementId: null,
		loadOnDemand: false,
		elementToClick: null,
		keyElement: null,
		createOptionIfNotExists: false,
		customButton: null,
		parameters: {}
	};

	var element = $(options.elementId, options.contextId);
	if (element.length > 0 && !element.hasClass("readonly")) {
		var $divParent = element.parents("div.autocompleter")
		var url = $divParent.attr("data-url");

		optionsDefault.keyElement = options.contextId + ' ' + $divParent.attr("data-key");
		optionsDefault.elementToClick = options.contextId + ' ' + options.elementId + "Btn"
		optionsDefault.loadOnDemand = $divParent.attr("data-ondemand");

		if (element.data('autocompleter')) {
			element.data('autocompleter').destroyList();
		}

		var opcoes = $.extend({}, optionsDefault, options);

		element.autocompleter(url, opcoes);

		if (options.parameters != null)
			element.data("autocompleter").setParameters(options.parameters);
	}

	return element.data("autocompleter");
}

function setDropDown(contextId, elementId, funcOnSelect) {
	var element = $(elementId, contextId);
	var input = $('input', element);
	var button = $('span.dropdown-text', element);
	var list = $('li', element);

	list.click(function (evt) {
		var li = $(this);
		button.html($('a', li).text().trim());
		input.val(li.attr('value'));
		if (funcOnSelect)
		    funcOnSelect(evt);
	});
}