﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.treeviewUnidades = (function() {
  function treeviewUnidades(view, options) {
    this.view = view;
    this.options = options;
    this.get = bind(this.get, this);
    this.pegarUnidade = bind(this.pegarUnidade, this);
    this.pegarIdUnidade = bind(this.pegarIdUnidade, this);
    this.pegarLi = bind(this.pegarLi, this);
    this.fechar = bind(this.fechar, this);
    this.abrir = bind(this.abrir, this);
    this.toggleTreeView = bind(this.toggleTreeView, this);
    this.selecionarUnidade = bind(this.selecionarUnidade, this);
    this.procurarSelecionada = bind(this.procurarSelecionada, this);
    this.abrirArvore = bind(this.abrirArvore, this);
    this.desdobrarUnidade = bind(this.desdobrarUnidade, this);
    this.esconderTreeview = bind(this.esconderTreeview, this);
    this.mostrarTreeview = bind(this.mostrarTreeview, this);
    this.eventosNasUnidades = bind(this.eventosNasUnidades, this);
    this.eventos = bind(this.eventos, this);
    this.descobrirElementos = bind(this.descobrirElementos, this);
    this.contexto = $('.js-container-treeview', this.view);
    this.descobrirElementos();
    this.eventos(this.contexto);
  }

  treeviewUnidades.prototype.descobrirElementos = function() {
    this.botaoFecharTreeview = this.get('.js-fechar-treeview');
    this.botaoMostarTreeView = this.get('.js-mostrar-treeview');
    this.containerUnidadesTreeview = this.get('.js-container-unidades');
    this.comboContainer = this.get('.js-combo-container');
    this.inputCombo = $('input[type=text]', this.comboContainer);
    return this.ulCombo = $('ul', this.comboContainer);
  };

  treeviewUnidades.prototype.eventos = function() {
    this.botaoFecharTreeview.unbind('click').click(this.fecharTreeView);
    this.botaoMostarTreeView.unbind('click').click(this.mostrarTreeview);
    this.inputCombo.keyup(this.esconderTreeview);
    return this.inputCombo.keydown(this.esconderLinha);
  };

  treeviewUnidades.prototype.eventosNasUnidades = function(contexto) {
    $('.js-desdobrar-unidade', contexto).unbind('click').click(this.desdobrarUnidade);
    return $('.js-selecionar-unidade', contexto).unbind('click').click(this.selecionarUnidade);
  };

  treeviewUnidades.prototype.mostrarTreeview = function() {
    this.botaoMostarTreeView.hide();
    this.containerUnidadesTreeview.show();
    return this.ulCombo.hide();
  };

  treeviewUnidades.prototype.esconderTreeview = function() {
    this.botaoMostarTreeView.show();
    this.containerUnidadesTreeview.hide();
    this.ulCombo.show();
    return {
      esconderLinha: (function(_this) {
        return function() {};
      })(this)
    };
  };

  treeviewUnidades.prototype.desdobrarUnidade = function(event) {
    var idUnidade, item, li;
    item = $(event.delegateTarget);
    li = this.pegarLi(item);
    if (li.hasClass('open')) {
      return li.removeClass('open');
    } else {
      idUnidade = this.pegarIdUnidade(item);
      return this.abrirArvore(idUnidade, li);
    }
  };

  treeviewUnidades.prototype.abrirArvore = function(idUnidade, container) {
    if (idUnidade || !$(container).data('carregado')) {
      return $.ajax({
        url: this.contexto.data('urlpadrao'),
        data: {
          id: idUnidade
        },
        global: false,
        success: (function(_this) {
          return function(html) {
            $('.js-ul-treeview', container).replaceWith(html);
            container.addClass('open');
            _this.eventosNasUnidades(container);
            _this.procurarSelecionada(container);
            $('#NomeDaUnidade', _this.contexto).focus();
            return $(container).data('carregado', true);
          };
        })(this)
      });
    }
  };

  treeviewUnidades.prototype.procurarSelecionada = function(container) {
    if (this.options.unidadeSelecionada) {
      return $(".js-treeview-unidade[data-unidade=" + this.options.unidadeSelecionada + "]", container).addClass('active');
    }
  };

  treeviewUnidades.prototype.selecionarUnidade = function(event) {
    var unidade;
    unidade = this.pegarUnidade($(event.delegateTarget));
    $(this.view).trigger('unidadeSelecionada', [unidade]);
    if (this.options.aoSelecionar) {
      this.options.aoSelecionar(unidade);
    }
    return this.fechar();
  };

  treeviewUnidades.prototype.toggleTreeView = function() {
    if (this.contexto.hasClass('open')) {
      return this.fechar();
    } else {
      return this.abrir();
    }
  };

  treeviewUnidades.prototype.abrir = function() {
    this.abrirArvore(null, this.get('.js-container-unidades'));
    return this.contexto.addClass('open');
  };

  treeviewUnidades.prototype.fechar = function() {
    return this.contexto.removeClass('open');
  };

  treeviewUnidades.prototype.pegarLi = function(item) {
    if ($(item).hasClass('js-treeview-unidade')) {
      return $(item);
    }
    return $(item).closest('.js-treeview-unidade');
  };

  treeviewUnidades.prototype.pegarIdUnidade = function(item) {
    return this.pegarUnidade(item).id;
  };

  treeviewUnidades.prototype.pegarUnidade = function(item) {
    var li;
    li = this.pegarLi(item);
    return {
      id: li.data('unidade'),
      sigla: li.data('sigla'),
      nome: li.data('nome')
    };
  };

  treeviewUnidades.prototype.get = function(seletor) {
    return $(seletor, this.contexto);
  };

  return treeviewUnidades;

})();
