﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.calendario = (function() {
  function calendario(contexto1, options) {
    this.contexto = contexto1;
    this.options = options;
    this.scrollToElement = bind(this.scrollToElement, this);
    this.scrollToHoje = bind(this.scrollToHoje, this);
    this.esconderCalendarioBackdrop = bind(this.esconderCalendarioBackdrop, this);
    this.onScroll = bind(this.onScroll, this);
    this.carregarDatasPosteriores = bind(this.carregarDatasPosteriores, this);
    this.carregarDatasAnteriores = bind(this.carregarDatasAnteriores, this);
    this.updateContainer = bind(this.updateContainer, this);
    this.aoSelecionarData = bind(this.aoSelecionarData, this);
    this.get = bind(this.get, this);
    this.load = bind(this.load, this);
    this.setarDateRange = bind(this.setarDateRange, this);
    this.datasContainer = this.get('.js-datas-container');
    this.load();
    this.setarDateRange();
  }

  calendario.prototype.setarDateRange = function() {
    this.dataInicio = $(".js-calendario-semana td:first", this.contexto).data('date');
    return this.dataFim = $(".js-calendario-semana td:last", this.contexto).data('date');
  };

  calendario.prototype.load = function() {
    this.datasContainer.jScrollPane({
      allowPageScroll: false
    });
    this.datasContainer.scroll(this.onScroll);
    this.updateContainer();
    this.scrollToHoje();
    return $('.calendario-backdrop, .calendario-nome-mes').click((function(_this) {
      return function() {
        return false;
      };
    })(this));
  };

  calendario.prototype.get = function(seletor) {
    return $(seletor, this.contexto);
  };

  calendario.prototype.aoSelecionarData = function(event) {
    var data, link;
    link = $(event.delegateTarget);
    data = link.data('date');
    $('.dia-selecionado').removeClass('dia-selecionado');
    $(link).addClass('dia-selecionado');
    if (this.options.aoSelecionarData) {
      return this.options.aoSelecionarData(event, data);
    }
  };

  calendario.prototype.updateContainer = function() {
    var contexto;
    contexto = this.get('.js-datas-container');
    contexto.data('jsp').reinitialise();
    $('.js-data-calendario[data-date="' + this.options.data + '"]').addClass('dia-selecionado');
    $('.js-calendario-mais-acima', contexto).unbind('click').click(this.options.carregarDatasAnteriores || this.carregarDatasAnteriores);
    $('.js-calendario-mais-abaixo', contexto).unbind('click').click(this.options.carregarDatasPosteriores || this.carregarDatasPosteriores);
    $('.js-data-calendario', contexto).unbind('click').click(this.aoSelecionarData);
    $('.jspPane, .jspContainer, .js-datas-container').css('width', '');
    return contexto;
  };

  calendario.prototype.carregarDatasAnteriores = function(event) {
    var linha;
    linha = $(event.delegateTarget);
    linha.hide();
    return $as.Calendario.CarregarCalendarioAnteriores.get({
      dataBase: linha.data('date')
    }).done((function(_this) {
      return function(html) {
        linha.after($('.js-calendario-semana', $(html)));
        linha.data('date', $('.js-calendario-mais-acima', $(html)).data('date'));
        linha.show();
        return _this.updateContainer();
      };
    })(this));
  };

  calendario.prototype.carregarDatasPosteriores = function(event) {
    var linha;
    linha = $(event.delegateTarget);
    linha.hide();
    return $as.Calendario.CarregarCalendarioPosteriores.get({
      dataBase: linha.data('date')
    }).done((function(_this) {
      return function(html) {
        linha.before($('.js-calendario-semana', $(html)));
        linha.data('date', $('.js-calendario-mais-abaixo', $(html)).data('date'));
        linha.show();
        return _this.updateContainer();
      };
    })(this));
  };

  calendario.prototype.onScroll = function() {
    $('.calendario-backdrop').fadeIn();
    $('.calendario-nome-mes').fadeIn();
    if (this.timeOut) {
      clearTimeout(this.timeOut);
    }
    return this.timeOut = setTimeout(this.esconderCalendarioBackdrop, 600);
  };

  calendario.prototype.esconderCalendarioBackdrop = function() {
    $('.calendario-backdrop').fadeOut();
    return $('.calendario-nome-mes').fadeOut();
  };

  calendario.prototype.scrollToHoje = function() {
    return this.scrollToElement("td.calendar-hoje");
  };

  calendario.prototype.scrollToElement = function(seletor) {
    var elemento, offset;
    elemento = $(seletor, this.datasContainer);
    if (elemento.length) {
      offset = elemento.position().top - (this.datasContainer.height() / 2);
      return this.datasContainer.data('jsp').scrollToY(offset);
    }
  };

  return calendario;

})();

window.calendarioDoPainel = (function() {
  function calendarioDoPainel(contexto1, opcoes) {
    this.contexto = contexto1;
    this.opcoes = opcoes;
    this.carregarMes = bind(this.carregarMes, this);
    this.mesAnterior = bind(this.mesAnterior, this);
    this.proximoMes = bind(this.proximoMes, this);
    this.aoSelecionarData = bind(this.aoSelecionarData, this);
    this.configurarCombos = bind(this.configurarCombos, this);
    this.irParaODiaDeHoje = bind(this.irParaODiaDeHoje, this);
    this.toggleIrParaHoje = bind(this.toggleIrParaHoje, this);
    this.binds = bind(this.binds, this);
    this.$contexto = $(this.contexto);
    this.binds();
    this.htmlMesDoFiltro = this.$contexto.find('.js-calendario');
    this.mesDoFiltro = this.$contexto.find('#mesSelecionado').val();
    this.anoDoFiltro = this.$contexto.find('#anoSelecionado').val();
  }

  calendarioDoPainel.prototype.binds = function() {
    this.$contexto.find('#collapseCalendarioSimples').unbind('click').click((function(_this) {
      return function() {
        _this.$contexto.find('.js-calendario').replaceWith(_this.htmlMesDoFiltro);
        _this.binds();
        return setTimeout(function() {
          return _this.$contexto.find('.calendario-simples-wrap').toggleClass('cs-collapse');
        }, 0);
      };
    })(this));
    this.$contexto.find('.js-data-calendario').unbind('click').click(this.aoSelecionarData);
    this.$contexto.find('#carouselNext').unbind('click').click(this.proximoMes);
    this.$contexto.find('#carouselPrev').unbind('click').click(this.mesAnterior);
    this.$contexto.find('#irParaHoje').unbind('click').click(this.irParaODiaDeHoje);
    this.configurarCombos();
    return this.toggleIrParaHoje();
  };

  calendarioDoPainel.prototype.toggleIrParaHoje = function() {
    return this.$contexto.find('#irParaHoje').parent().toggleClass('none', this.$contexto.find('.hoje.selected').length > 0);
  };

  calendarioDoPainel.prototype.irParaODiaDeHoje = function(e) {
    return $as.PainelUnificado.Index.get().done((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  calendarioDoPainel.prototype.configurarCombos = function() {
    this.$contexto.find('#comboMeses').find('li').unbind('click').click((function(_this) {
      return function() {
        var mes;
        mes = $( this ).data("value");
        return _this.carregarMes(mes, _this.$contexto.find('#anoSelecionado').val(), true);
      };
    })(this));
    return this.$contexto.find('#comboAnos').find('li').unbind('click').click((function(_this) {
      return function() {
        var ano;
        ano = $( this ).data("value");
        return _this.carregarMes(_this.$contexto.find('#mesSelecionado').val(), ano, true);
      };
    })(this));
  };

  calendarioDoPainel.prototype.aoSelecionarData = function(event) {
    var data, link;
    link = $(event.delegateTarget);
    data = link.data('date');
    this.$contexto.find('.selected').removeClass('selected');
    link.addClass('selected');
    link.closest('.calendario-simples').find('.cs-visible').removeClass('cs-visible');
    link.closest('.cs-row').addClass('cs-visible');
    if (this.opcoes.aoSelecionarData) {
      this.opcoes.aoSelecionarData(event, data);
    }
    this.htmlMesDoFiltro = this.$contexto.find('.js-calendario');
    this.$contexto.find('.calendario-simples-wrap').addClass('cs-collapse');
    return this.toggleIrParaHoje();
  };

  calendarioDoPainel.prototype.proximoMes = function() {
    var ano, calendario, mes;
    calendario = this.$contexto.find('.js-calendario');
    mes = parseInt(calendario.find('#mesSelecionado').val());
    ano = parseInt(calendario.find('#anoSelecionado').val());
    if (mes === 12) {
      mes = 1;
      ano++;
    } else {
      mes++;
    }
    return this.carregarMes(mes, ano, true);
  };

  calendarioDoPainel.prototype.mesAnterior = function() {
    var ano, calendario, mes;
    calendario = this.$contexto.find('.js-calendario');
    mes = parseInt(calendario.find('#mesSelecionado').val());
    ano = parseInt(calendario.find('#anoSelecionado').val());
    if (mes === 1) {
      mes = 12;
      ano--;
    } else {
      mes--;
    }
    return this.carregarMes(mes, ano, true);
  };

  calendarioDoPainel.prototype.carregarMes = function(mes, ano, abrirColapse) {
    return $as.PainelUnificado.Calendario.post({
      mes: mes,
      ano: ano
    }).done((function(_this) {
      return function(data) {
        _this.$contexto.find('.js-calendario').replaceWith(data);
        _this.binds();
        if (abrirColapse) {
          return _this.$contexto.find('.js-calendario').removeClass('cs-collapse');
        }
      };
    })(this));
  };

  return calendarioDoPainel;

})();
