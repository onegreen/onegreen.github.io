﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.vinculoUsuarioComUnidadeController = (function() {
  function vinculoUsuarioComUnidadeController(contexto) {
    this.contexto = contexto;
    this.reload = bind(this.reload, this);
    this.carregarUsuarioPorUnidade = bind(this.carregarUsuarioPorUnidade, this);
    this.carregarComboUnidadesDaEmpresa = bind(this.carregarComboUnidadesDaEmpresa, this);
    redimensionarModalLateral();
    this.carregarComboUnidadesDaEmpresa();
    $(this.contexto).css('z-index', ++window.WindowZIndex);
    $('#btn-Fechar').click(function() {
      --window.WindowZIndex;
      return $('#vinculoUsuarioComUnidade-modal-container').empty();
    });
    $("[rel=tooltip]").tooltip();
  }

  vinculoUsuarioComUnidadeController.prototype.carregarComboUnidadesDaEmpresa = function() {
    setCombo(this.contexto, '#UnidadeGerencial_SiglaAtual', this.carregarUsuarioPorUnidade);
    return $('#UnidadeGerencial_SiglaAtual', this.contexto).focus();
  };

  vinculoUsuarioComUnidadeController.prototype.carregarUsuarioPorUnidade = function() {
    return $as.Manutencao.Usuarios.ListarUsuariosDaEmpresaParaVinculoComUnidade.get({
      idUnidade: $('#UnidadeGerencial_Id').val()
    }).done((function(_this) {
      return function(data) {
        $('#usuariosDaEmpresa-container').html(data);
      };
    })(this));
  };

  vinculoUsuarioComUnidadeController.prototype.reload = function() {
    return this.carregarUsuarioPorUnidade();
  };

  return vinculoUsuarioComUnidadeController;

})();
