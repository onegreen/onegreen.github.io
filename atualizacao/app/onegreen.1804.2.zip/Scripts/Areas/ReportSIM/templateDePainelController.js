﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.templateDePainelController = (function(superClass) {
  extend(templateDePainelController, superClass);

  function templateDePainelController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.juntarContainers = bind(this.juntarContainers, this);
    this.juntarSelecionados = bind(this.juntarSelecionados, this);
    this.dividirSelecionadosVerticalmente = bind(this.dividirSelecionadosVerticalmente, this);
    this.dividirSelecionadosHorizontalmente = bind(this.dividirSelecionadosHorizontalmente, this);
    this.executarRegrasDeBloqueio = bind(this.executarRegrasDeBloqueio, this);
    this.verificarBotoesHabilitados = bind(this.verificarBotoesHabilitados, this);
    this.habilitar = bind(this.habilitar, this);
    this.desabilitar = bind(this.desabilitar, this);
    this.habilitarBotoes = bind(this.habilitarBotoes, this);
    this.desabilitarBotoes = bind(this.desabilitarBotoes, this);
    this.selecionarItem = bind(this.selecionarItem, this);
    this.eventosItens = bind(this.eventosItens, this);
    this.deselecionarTodos = bind(this.deselecionarTodos, this);
    this.serializeChildren = bind(this.serializeChildren, this);
    this.serializarTemplate = bind(this.serializarTemplate, this);
    this.salvar = bind(this.salvar, this);
    this.ativarEventos = bind(this.ativarEventos, this);
    this.encontrarElementos = bind(this.encontrarElementos, this);
    templateDePainelController.__super__.constructor.call(this, this.view, this.model);
    this.encontrarElementos();
    this.ativarEventos();
    this.eventosItens();
    this.executarRegrasDeBloqueio();
  }

  templateDePainelController.prototype.encontrarElementos = function() {
    this.botaoDividirHorizontal = this.get('#botao-dividir-horizontal-container');
    this.botaoDividirVertical = this.get('#botao-dividir-vertical-container');
    this.botaoJuntar = this.get('#botao-juntar-container');
    this.botaoDeselecionarTodos = this.get('#botao-deselecionar-todos');
    this.botaoSalvar = this.get('#botao-salvar');
    return this.templateContainer = this.get('#template-container');
  };

  templateDePainelController.prototype.ativarEventos = function() {
    this.botaoDividirHorizontal.click(this.dividirSelecionadosHorizontalmente);
    this.botaoDividirVertical.click(this.dividirSelecionadosVerticalmente);
    this.botaoJuntar.click(this.juntarSelecionados);
    this.botaoDeselecionarTodos.click(this.deselecionarTodos);
    return this.botaoSalvar.click(this.salvar);
  };

  templateDePainelController.prototype.salvar = function() {
    return $as.ReportSIM.TemplatesDePainel.SalvarTemplate.postJson(this.serializarTemplate());
  };

  templateDePainelController.prototype.serializarTemplate = function() {
    var i, len, ref, selecionado, template;
    template = this.serializeChildren(this.templateContainer);
    template.Id = $('#Id').val();
    template.Nome = $('#Nome').val();
    template.Ordem = $('#Ordem').val();
    template.Selecionados = new Array();
    ref = this.get('.item-selected');
    for (i = 0, len = ref.length; i < len; i++) {
      selecionado = ref[i];
      template.Selecionados.push($(selecionado).data('referencianotemplate'));
    }
    return JSON.stringify(template);
  };

  templateDePainelController.prototype.serializeChildren = function(pai) {
    var agrupador, child, i, len, ref;
    agrupador = pai.data();
    agrupador.Itens = new Array();
    ref = pai.children(".js-ItemDoTemplate");
    for (i = 0, len = ref.length; i < len; i++) {
      child = ref[i];
      agrupador.Itens.push(this.serializeChildren($(child)));
    }
    return agrupador;
  };

  templateDePainelController.prototype.deselecionarTodos = function() {
    this.get('.item-selected').removeClass('item-selected');
    return this.executarRegrasDeBloqueio();
  };

  templateDePainelController.prototype.eventosItens = function() {
    return this.get('.js-ItemDoTemplate').unbind("click").click(this.selecionarItem);
  };

  templateDePainelController.prototype.selecionarItem = function(event) {
    var itemContainer;
    event.stopPropagation();
    itemContainer = $(event.delegateTarget);
    $(itemContainer).toggleClass('item-selected');
    return this.executarRegrasDeBloqueio();
  };

  templateDePainelController.prototype.desabilitarBotoes = function() {
    this.desabilitar(this.botaoJuntar);
    this.desabilitar(this.botaoDividirVertical);
    this.desabilitar(this.botaoDividirHorizontal);
    return this.desabilitar(this.botaoDeselecionarTodos);
  };

  templateDePainelController.prototype.habilitarBotoes = function() {
    this.habilitar(this.botaoJuntar);
    this.habilitar(this.botaoDividirVertical);
    this.habilitar(this.botaoDividirHorizontal);
    return this.habilitar(this.botaoDeselecionarTodos);
  };

  templateDePainelController.prototype.desabilitar = function(item) {
    return item.attr('disabled', 'disabled');
  };

  templateDePainelController.prototype.habilitar = function(item) {
    return item.removeAttr('disabled');
  };

  templateDePainelController.prototype.verificarBotoesHabilitados = function(itens) {
    var alturaInicial, colunaInicial, i, impossivelJuntarNaDiagonal, impossivelJuntarNaHorizontal, impossivelJuntarNaVertical, item, larguraInicial, len, linhaInicial, results, somaAltura, somaLargura;
    somaLargura = 0;
    somaAltura = 0;
    larguraInicial = itens[0].largura;
    alturaInicial = itens[0].altura;
    linhaInicial = itens[0].linha;
    colunaInicial = itens[0].coluna;
    if (itens.length <= 1) {
      this.desabilitar(this.botaoJuntar);
    }
    results = [];
    for (i = 0, len = itens.length; i < len; i++) {
      item = itens[i];
      somaLargura += item.larguraAbsoluta;
      somaAltura += item.altura;
      impossivelJuntarNaHorizontal = linhaInicial === item.linha && alturaInicial !== item.altura && somaLargura >= parseInt(this.options.LarguraDoGrid);
      impossivelJuntarNaVertical = colunaInicial === item.coluna && larguraInicial !== item.largura && somaAltura > 100;
      impossivelJuntarNaDiagonal = linhaInicial !== item.linha && colunaInicial !== item.coluna;
      if (impossivelJuntarNaHorizontal || impossivelJuntarNaVertical || impossivelJuntarNaDiagonal) {
        this.desabilitar(this.botaoJuntar);
      }
      if (item.larguraabsoluta <= parseInt(this.options.MenorLargura)) {
        this.desabilitar(this.botaoDividirHorizontal);
      }
      if (item.altura <= 25) {
        results.push(this.desabilitar(this.botaoDividirVertical));
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  templateDePainelController.prototype.executarRegrasDeBloqueio = function() {
    var i, itens, len, ref, selecionado;
    itens = new Array();
    this.habilitarBotoes();
    ref = this.get('.item-selected');
    for (i = 0, len = ref.length; i < len; i++) {
      selecionado = ref[i];
      itens.push($(selecionado).data());
    }
    if (itens.length) {
      this.verificarBotoesHabilitados(itens);
      return this.habilitar(this.botaoDeselecionarTodos);
    } else {
      return this.desabilitarBotoes();
    }
  };

  templateDePainelController.prototype.dividirSelecionadosHorizontalmente = function() {
    this.executarRegrasDeBloqueio();
    return $as.ReportSIM.TemplatesDePainel.DividirNaHorizontal.postJson(this.serializarTemplate()).done((function(_this) {
      return function(html) {
        _this.templateContainer.html(html);
        return _this.eventosItens();
      };
    })(this));
  };

  templateDePainelController.prototype.dividirSelecionadosVerticalmente = function() {
    this.executarRegrasDeBloqueio();
    return $as.ReportSIM.TemplatesDePainel.DividirNaVertical.postJson(this.serializarTemplate()).done((function(_this) {
      return function(html) {
        _this.templateContainer.html(html);
        return _this.eventosItens();
      };
    })(this));
  };

  templateDePainelController.prototype.juntarSelecionados = function() {
    this.executarRegrasDeBloqueio();
    return $as.ReportSIM.TemplatesDePainel.Juntar.postJson(this.serializarTemplate()).done((function(_this) {
      return function(html) {
        _this.templateContainer.html(html);
        return _this.eventosItens();
      };
    })(this));
  };

  templateDePainelController.prototype.juntarContainers = function(itens, itemPrincipal, forcarLargura) {
    var coluna, colunaItem, i, item, itensNaMesmaColuna, itensNaMesmaLinha, len, linha, linhaItem;
    itensNaMesmaLinha = true;
    itensNaMesmaColuna = true;
    linha = itemPrincipal.offset().top;
    coluna = itemPrincipal.offset().left;
    for (i = 0, len = itens.length; i < len; i++) {
      item = itens[i];
      linhaItem = $(item).offset().top;
      colunaItem = $(item).offset().left;
      itensNaMesmaLinha = itensNaMesmaLinha && (linha === linhaItem);
      itensNaMesmaColuna = itensNaMesmaColuna && (coluna === colunaItem);
    }
    if (itensNaMesmaLinha) {
      this.alterarDimensao(itens, itemPrincipal, 'largura', this.mudarLargura);
    }
    if (itensNaMesmaColuna) {
      return this.alterarDimensao(itens, itemPrincipal, 'altura', this.mudarAltura);
    }
  };

  return templateDePainelController;

})(window.baseController);
