﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.noticiaEditController = (function(superClass) {
  extend(noticiaEditController, superClass);

  function noticiaEditController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.comboUnidadesGerenciais = bind(this.comboUnidadesGerenciais, this);
    this.comboUnidade = bind(this.comboUnidade, this);
    this.atualizarDescricaoDoDia = bind(this.atualizarDescricaoDoDia, this);
    this.alterarArquivo = bind(this.alterarArquivo, this);
    this.toolBar = bind(this.toolBar, this);
    this.excluirArquivo = bind(this.excluirArquivo, this);
    this.alterarPublico = bind(this.alterarPublico, this);
    this.load = bind(this.load, this);
    noticiaEditController.__super__.constructor.call(this, this.view, this.model);
    this.load();
  }

  noticiaEditController.prototype.load = function() {
    this.InputArquivo = this.get('#ImagemPrincipal');
    this.get('.js-rich-text').summernote();
    this.get('#botao-selecionar-arquivo').unbind('click').click((function(_this) {
      return function() {
        return _this.InputArquivo.click();
      };
    })(this));
    this.get('#botao-excluir-arquivo').unbind('click').click(this.excluirArquivo);
    this.InputArquivo.change(this.alterarArquivo);
    this.get('#DataDePublicacao_Date').change(this.atualizarDescricaoDoDia);
    this.get('#Publico-Nao').click(this.alterarPublico);
    this.get('#Publico-Sim').click(this.alterarPublico);
    this.comboUnidade();
    return this.comboUnidadesGerenciais();
  };

  noticiaEditController.prototype.alterarPublico = function(event) {
    var $chKPrivado, $chkPublico, $labelPrivado, $labelPublico, containerUnidades, publico;
    $chkPublico = this.get('#Publico-Sim');
    $chKPrivado = this.get('#Publico-Nao');
    $labelPublico = $chkPublico.closest("label");
    $labelPrivado = $chKPrivado.closest("label");
    publico = $chkPublico.is(':checked');
    containerUnidades = this.get('#unidades-visualizam-apresentacao');
    if (publico) {
      containerUnidades.fadeOut();
      $chkPublico.attr('checked', 'checked');
      $chKPrivado.removeAttr('checked');
      $labelPublico.addClass('active');
      $labelPrivado.removeClass('active');
      $('#mostrador-publica').show();
      return $('#mostrador-unidades').hide();
    } else {
      containerUnidades.fadeIn();
      $chKPrivado.attr('checked', 'checked');
      $chkPublico.removeAttr('checked');
      $labelPublico.removeClass('active');
      $labelPrivado.addClass('active');
      $('#mostrador-unidades').show();
      return $('#mostrador-publica').hide();
    }
  };

  noticiaEditController.prototype.excluirArquivo = function() {
    this.InputArquivo.val('');
    this.get('#DescricaoDoArquivo').html('');
    return this.get('#NomeImagemPrincipal').val('');
  };

  noticiaEditController.prototype.toolBar = function() {
    return [['Insert', ['link', 'table']], ['font', ['color', 'fontsize', 'height']], ['Style', ['bold', 'italic', 'underline', 'strikethrough', 'clear']], ['para', ['ul', 'ol', 'paragraph']], ['Misc', ['fullscreen', 'codeview']], ['actions', ['undo', 'redo']], ['help', ['help']]];
  };

  noticiaEditController.prototype.alterarArquivo = function(event) {
    return $('#DescricaoDoArquivo').html($(event.delegateTarget).val().replace('fakepath', '...'));
  };

  noticiaEditController.prototype.atualizarDescricaoDoDia = function() {
    return $as.ReportSIM.Noticias.PegarDescricaoDoDia.get({
      data: $('#DataDePublicacao_Date').val()
    }).done((function(_this) {
      return function(texto) {
        return $('#descricao-dia').html(texto);
      };
    })(this));
  };

  noticiaEditController.prototype.comboUnidade = function() {
    return setCombo("#selecao-de-acesso", '#UnidadeGerencial_SiglaAtual', (function(_this) {
      return function() {
        return _this.get('#configuracao-nome-unidade').text(_this.get('#UnidadeGerencial_SiglaAtual').val());
      };
    })(this));
  };

  noticiaEditController.prototype.comboUnidadesGerenciais = function() {
    var $combo, $divCombo, unidadesGerenciaisViewModel;
    unidadesGerenciaisViewModel = {
      unidadesGerenciais: ko.observableArray(this.options.unidadesGerenciais),
      removeUnidade: function(item) {
        this.unidadesGerenciais.remove(item);
        return $("#mostrador-unidade-" + item.Id).remove();
      }
    };
    window.unidadesGerenciaisViewModel = unidadesGerenciaisViewModel;
    ko.applyBindings(unidadesGerenciaisViewModel, this.get('#unidadesGerenciais_itens')[0]);
    $combo = this.get('#UnidadesGerenciaisCombo');
    $divCombo = $combo.parents('div.autocompleter');
    return $combo.autocompleter($divCombo.attr('data-url'), {
      elementToClick: '#UnidadesGerenciaisComboBtn',
      onSelected: (function(_this) {
        return function(item) {
          return _this.get('#mostrador-unidades').append("<span id='mostrador-listaDeDistribuicao-" + item.Id + "' class='label label-default mrs'>" + item.Nome + "</span>");
        };
      })(this),
      multiSelectArray: unidadesGerenciaisViewModel.unidadesGerenciais,
      multiSelectElement: '#unidadesGerenciais_itens',
      createOptionIfNotExists: false,
      canAddNewItens: false
    });
  };

  return noticiaEditController;

})(window.baseController);
