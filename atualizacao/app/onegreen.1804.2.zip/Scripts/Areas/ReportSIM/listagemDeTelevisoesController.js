﻿window.listagemDeTelevisoesController = (function() {
  function listagemDeTelevisoesController(contexto) {
    this.contexto = contexto;
    this.adicionarTv = $('#js-add-tv', this.contexto);
    this.adicionarTv.click(this.adicionarTv);
  }

  listagemDeTelevisoesController.prototype.adicionarTv = function() {
    return console.log('adicionar tv');
  };

  return listagemDeTelevisoesController;

})();
