﻿this.SolucaoDeProblema || (this.SolucaoDeProblema = {});

SolucaoDeProblema.api = (function() {
  function api() {}

  api.boot = function() {
    api.configurarCallbackPopoverPaineis();
    return api.configurarCallbackPopoverElaboradorPaineis();
  };

  api.configurarCallbackPopoverPaineis = function() {
    return $("body").on("click", "i[data-solucaodeproblema-painel]", function(event) {
      var $el, evt, exibicaoSimplificada, idDaSolucaoDeProblema, tag;
      $(".popover").remove();
      evt = event || window.event;
      tag = evt.target.tagName || evt.srcElement.tagName;
      if (tag === 'A') {
        return;
      }
      $el = $(evt.currentTarget);
      idDaSolucaoDeProblema = $el.data("solucaodeproblema-painel");
      exibicaoSimplificada = $el.data("exibicaosimplificada-painel");
      return $as.Melhorias.SolucoesDeProblemas.DetalhesSolucaoDeProblema.get({
        idDaSolucaoDeProblema: idDaSolucaoDeProblema,
        exibicaoSimplificada: exibicaoSimplificada
      }).success(function(data) {
        var $data, callPopover, content, title;
        $data = $(data);
        title = $data.find("#detalhes-solucaodeproblema-title").html();
        content = $data.find("#detalhes-solucaodeproblema-content").html();
        callPopover = function() {
          $el.popover({
            trigger: 'manual',
            html: true,
            title: title + '<span class="fr cursor-pointer" onclick="popover.close($(this))">x</span>',
            content: content,
            placement: 'right'
          });
          $el.popover('show');
        };
        setTimeout(callPopover, 200);
      });
    });
  };

  api.configurarCallbackPopoverElaboradorPaineis = function() {
    return $("body").on("click", "span[data-solucaodeproblema-elaborador-painel]", function(event) {
      var $el, evt, idDaSolucaoDeProblema, tag;
      $(".popover").remove();
      evt = event || window.event;
      tag = evt.target.tagName || evt.srcElement.tagName;
      if (tag === 'A') {
        return;
      }
      $el = $(evt.currentTarget);
      idDaSolucaoDeProblema = $el.data("solucaodeproblema-elaborador-painel");
      return $as.Melhorias.SolucoesDeProblemas.ElaboradoresSolucaoDeProblema.get({
        idDaSolucaoDeProblema: idDaSolucaoDeProblema
      }).success(function(data) {
        var $data, callPopover, content, title;
        $data = $(data);
        title = $data.find("#elaboradores-solucaodeproblema-title").html();
        content = $data.find("#elaboradores-solucaodeproblema-content").html();
        callPopover = function() {
          $el.popover({
            trigger: 'manual',
            html: true,
            title: title + '<span class="fr cursor-pointer" onclick="popover.close($(this))">x</span>',
            content: content,
            placement: 'left'
          });
          $el.popover('show');
        };
        setTimeout(callPopover, 200);
      });
    });
  };

  return api;

})();

SolucaoDeProblema.api.boot();
