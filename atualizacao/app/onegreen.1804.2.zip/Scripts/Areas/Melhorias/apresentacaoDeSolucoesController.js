﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.apresentacaoDeSolucoesController = (function(superClass) {
  extend(apresentacaoDeSolucoesController, superClass);

  function apresentacaoDeSolucoesController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.exibirItemExpandido = bind(this.exibirItemExpandido, this);
    this.carregarPopoverSolucoes = bind(this.carregarPopoverSolucoes, this);
    this.verificarMensagemInserirItens = bind(this.verificarMensagemInserirItens, this);
    this.salvarApresentacao = bind(this.salvarApresentacao, this);
    this.aguardarEsalvarApresentacao = bind(this.aguardarEsalvarApresentacao, this);
    this.atualizarIdsDasSolucoesDeProblemasVinculadasParaFiltro = bind(this.atualizarIdsDasSolucoesDeProblemasVinculadasParaFiltro, this);
    this.vincularSolucaoDeProblema = bind(this.vincularSolucaoDeProblema, this);
    this.executarExclusaoDoItem = bind(this.executarExclusaoDoItem, this);
    this.solicitarconfirmacaoDeExclusaoDoItem = bind(this.solicitarconfirmacaoDeExclusaoDoItem, this);
    this.carregarFiltro = bind(this.carregarFiltro, this);
    this.ativarEventos = bind(this.ativarEventos, this);
    apresentacaoDeSolucoesController.__super__.constructor.call(this, this.view, this.model);
    apresentacaoDeSolucoesController.setInputNames(this.get('.js-solucao-apresentacao'), "Itens");
    this.ativarEventos();
    this.carregarFiltro();
    this.ultimoNome = this.model.Nome();
    if ($(".js-panel-configuracao-do-item").length === 1) {
      this.exibirItemExpandido();
    }
  }

  apresentacaoDeSolucoesController.prototype.ativarEventos = function() {
    var container;
    container = this.get('.js-itens-container');
    apresentacaoDeSolucoesController.bindDeConfiguracoes(container, true);
    container.on('change', '.js-check-configuracao', this.aguardarEsalvarApresentacao);
    container.on('change', '.js-radio-configuracao', this.aguardarEsalvarApresentacao);
    container.on('click', 'a[data-toggle-checkbox]', this.aguardarEsalvarApresentacao);
    container.on('click', '.js-excluir-configuracao-do-item', this.solicitarconfirmacaoDeExclusaoDoItem);
    container.on('click', 'span[data-solucao-item-da-apresentacao]', this.carregarPopoverSolucoes);
    this.get('.js-salvar-ao-alterar').unbind('change').change(this.salvarApresentacao);
    container.sortable({
      handle: ".js-ordernar",
      revert: "invalid",
      cursor: 'move',
      update: (function(_this) {
        return function(event, ui) {
          apresentacaoDeSolucoesController.setInputNames(_this.get('.js-solucao-apresentacao'), "Itens");
          return _this.salvarApresentacao();
        };
      })(this)
    });
    return this.get("[rel=tooltip]").tooltip();
  };

  apresentacaoDeSolucoesController.bindDeConfiguracoes = function(container) {
    container.on('change', '.js-check-configuracao', apresentacaoDeSolucoesController.alterarConfiguracao);
    container.on('change', '.js-radio-configuracao', apresentacaoDeSolucoesController.alterarConfiguracaoExclusiva);
    return container.on('click', 'a[data-toggle-checkbox]', apresentacaoDeSolucoesController.marcarDesmarcarConfiguracoes);
  };

  apresentacaoDeSolucoesController.prototype.carregarFiltro = function() {
    return $as.Melhorias.ApresentacoesDeSolucaoDeProblema.FiltroAvancadoSolucaoDeProblema.get(this.get("input[name=IdsDasSolucoesDeProblemasVinculadas]").serialize()).success((function(_this) {
      return function(html) {
        return $('#form-filtro-avancado').html(html);
      };
    })(this));
  };

  apresentacaoDeSolucoesController.alterarConfiguracao = function(event) {
    var configuracao, contexto, hidden;
    contexto = $(event.currentTarget).closest('.js-container-configuracao');
    hidden = $('.js-item-configuracao', contexto);
    configuracao = $('.js-check-configuracao', contexto);
    return hidden.val($(event.currentTarget).is(':checked'));
  };

  apresentacaoDeSolucoesController.alterarConfiguracaoExclusiva = function(event) {
    var check, contextoInput, marcar;
    check = $(event.currentTarget);
    contextoInput = check.closest('.js-container-configuracao');
    marcar = check.is(':checked');
    apresentacaoDeSolucoesController.desmarcarTodosInputs(check);
    if (marcar) {
      check.attr('checked', 'checked');
      return $('.js-item-configuracao', contextoInput).val(true);
    }
  };

  apresentacaoDeSolucoesController.desmarcarTodosInputs = function(input) {
    var contexto;
    contexto = input.closest('.js-marcacao-exclusiva');
    $('.js-radio-configuracao', contexto).removeAttr('checked');
    return $('.js-item-configuracao', contexto).val(false);
  };

  apresentacaoDeSolucoesController.setInputNames = function(contexto, propertyName) {
    var chave, contador, i, input, item, j, len, len1, ref, results;
    contador = 0;
    results = [];
    for (i = 0, len = contexto.length; i < len; i++) {
      item = contexto[i];
      ref = $('.js-input-item', $(item));
      for (j = 0, len1 = ref.length; j < len1; j++) {
        input = ref[j];
        input = $(input);
        chave = input.data('vinculo');
        if (propertyName === void 0) {
          input.attr('name', chave);
        } else {
          input.attr('name', propertyName + "[" + contador + "]." + chave);
        }
        if (chave === 'Ordem') {
          input.val(contador);
        }
      }
      results.push(contador++);
    }
    return results;
  };

  apresentacaoDeSolucoesController.prototype.solicitarconfirmacaoDeExclusaoDoItem = function(e) {
    this.configuracaoDoItem = $(e.currentTarget);
    return window.modalConfirm(this.configuracaoDoItem.attr("data-ajax-confirm"), this.executarExclusaoDoItem);
  };

  apresentacaoDeSolucoesController.prototype.executarExclusaoDoItem = function() {
    this.configuracaoDoItem.parents(".js-panel-configuracao-do-item").remove();
    apresentacaoDeSolucoesController.setInputNames(this.get('.js-solucao-apresentacao'), "Itens");
    this.salvarApresentacao();
    return this.atualizarIdsDasSolucoesDeProblemasVinculadasParaFiltro();
  };

  apresentacaoDeSolucoesController.prototype.vincularSolucaoDeProblema = function() {
    var idsDasSolucoesDeProblema;
    idsDasSolucoesDeProblema = $("input[name='ids']:checked", "#selecaoDeSolucaoDeProblema-modal-body").serialize();
    return $as.Melhorias.ApresentacoesDeSolucaoDeProblema.AdicionarItem.get(idsDasSolucoesDeProblema).success((function(_this) {
      return function(data) {
        $(".js-itens-container").append(data);
        apresentacaoDeSolucoesController.setInputNames(_this.get('.js-solucao-apresentacao'), "Itens");
        _this.get('.js-check-configuracao').unbind('change').change(_this.alterarConfiguracao);
        _this.get("[rel=tooltip]").tooltip();
        _this.salvarApresentacao();
        _this.atualizarIdsDasSolucoesDeProblemasVinculadasParaFiltro();
        return $('#fecharFiltroAvancado').click();
      };
    })(this));
  };

  apresentacaoDeSolucoesController.prototype.atualizarIdsDasSolucoesDeProblemasVinculadasParaFiltro = function() {
    var idsDasSolucoesDeProblemasVinculadas;
    idsDasSolucoesDeProblemasVinculadas = [];
    $("input[name=IdsDasSolucoesDeProblemasVinculadas]").each(function() {
      return idsDasSolucoesDeProblemasVinculadas.push($(this).val());
    });
    return $("#IdsDasEntidadesQueJaEstaoVinculadas").val(idsDasSolucoesDeProblemasVinculadas);
  };

  apresentacaoDeSolucoesController.marcarDesmarcarConfiguracoes = function(e) {
    var contexto, marcar;
    contexto = $(e.currentTarget).data("toggle-checkbox");
    marcar = $(e.currentTarget).data("toggle-checkbox-value");
    if (marcar) {
      $("#" + contexto + " .js-check-configuracao").attr("checked", "checked");
    } else {
      $("#" + contexto + " .js-check-configuracao,.js-radio-configuracao").removeAttr("checked");
      $("#" + contexto + " .js-radio-configuracao").val(marcar);
    }
    return $("#" + contexto + " .js-item-configuracao").val(marcar);
  };

  apresentacaoDeSolucoesController.prototype.aguardarEsalvarApresentacao = function() {
    if (this.timeOut) {
      clearTimeout(this.timeOut);
    }
    return this.timeOut = setTimeout(this.salvarApresentacao, 1500);
  };

  apresentacaoDeSolucoesController.prototype.salvarApresentacao = function() {
    return $as.Melhorias.ApresentacoesDeSolucaoDeProblema.SalvarApresentacao.post(this.get('input').serialize()).done((function(_this) {
      return function(resposta) {
        if (!resposta.success) {
          _this.get('.validation-summary-valid').html(resposta);
          _this.get('.js-nome-apresentacao').val(_this.ultimoNome);
        } else {
          _this.get('.validation-summary-valid').html('<ul></ul>');
          _this.ultimoNome = _this.get('.js-nome-apresentacao').val();
        }
        _this.get("[rel=tooltip]").tooltip();
        return _this.verificarMensagemInserirItens();
      };
    })(this));
  };

  apresentacaoDeSolucoesController.prototype.verificarMensagemInserirItens = function() {
    var botaoDownload, downloadDesativado;
    botaoDownload = this.get('#botao-download');
    downloadDesativado = this.get('#botao-download-disable');
    if ($('.js-panel-configuracao-do-item').length) {
      this.get('#mensage-como-inserir-itens').hide();
      botaoDownload.removeClass('none');
      return downloadDesativado.addClass('none');
    } else {
      this.get('#mensage-como-inserir-itens').fadeIn();
      botaoDownload.addClass('none');
      return downloadDesativado.removeClass('none');
    }
  };

  apresentacaoDeSolucoesController.prototype.carregarPopoverSolucoes = function(event) {
    var $el, evt, idDaSolucaoDeProblema, tag;
    $(".popover").remove();
    evt = event || window.event;
    tag = evt.target.tagName || evt.srcElement.tagName;
    if (tag === 'A') {
      return;
    }
    $el = $(evt.currentTarget);
    idDaSolucaoDeProblema = $el.data("solucao-item-da-apresentacao");
    return $as.Melhorias.SolucoesDeProblemas.DetalhesSolucaoDeProblema.get({
      idDaSolucaoDeProblema: idDaSolucaoDeProblema,
      exibicaoSimplificada: false
    }).success((function(_this) {
      return function(data) {
        var $data, callPopover, content, title;
        $data = $(data);
        title = $data.find("#detalhes-solucaodeproblema-title").html();
        content = $data.find("#detalhes-solucaodeproblema-content").html();
        callPopover = function() {
          $el.popover({
            trigger: 'manual',
            html: true,
            title: title + '<span class="fr cursor-pointer" onclick="popover.close($(this))"><i class="fa fa-times fa-1"></i></span>',
            content: content,
            placement: 'left'
          });
          $el.popover('show');
        };
        setTimeout(callPopover, 200);
      };
    })(this));
  };

  apresentacaoDeSolucoesController.editar = function(resposta) {
    return $as.Melhorias.ApresentacoesDeSolucaoDeProblema.Edit.get(resposta.data).done(function(html) {
      return $('#main').html(html);
    });
  };

  apresentacaoDeSolucoesController.prototype.exibirItemExpandido = function() {
    return $(".js-panel-configuracao-do-item h4 a").click();
  };

  return apresentacaoDeSolucoesController;

})(window.baseController);
