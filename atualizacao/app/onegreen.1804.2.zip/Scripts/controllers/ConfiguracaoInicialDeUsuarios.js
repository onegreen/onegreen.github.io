﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.ConfiguracaoInicialDeUsuarios = (function(superClass) {
  extend(ConfiguracaoInicialDeUsuarios, superClass);

  function ConfiguracaoInicialDeUsuarios(view, options) {
    this.view = view;
    this.options = options;
    this.aoExcluir = bind(this.aoExcluir, this);
    this.reload = bind(this.reload, this);
    this.limparCampos = bind(this.limparCampos, this);
    this.marcarCampo = bind(this.marcarCampo, this);
    this.adicionarErros = bind(this.adicionarErros, this);
    this.aoSalvar = bind(this.aoSalvar, this);
    this.loadComboUnidades = bind(this.loadComboUnidades, this);
    ConfiguracaoInicialDeUsuarios.__super__.constructor.call(this, this.view, null);
    this.listaUsuarios = this.get('#tabela-usuarios');
    this.erros = this.get('#validation-erros');
    this.loadComboUnidades();
    this.get('[rel=tooltip]').tooltip();
  }

  ConfiguracaoInicialDeUsuarios.prototype.loadComboUnidades = function() {
    return this.comboUnidade = setCombo(this.view, '#unidadeGerencial');
  };

  ConfiguracaoInicialDeUsuarios.prototype.aoSalvar = function(data) {
    if (data.success) {
      return $as.Manutencao.Usuarios.ConfiguracaoInicial.get().done((function(_this) {
        return function(data) {
          _this.listaUsuarios.find('tbody').html($('#tabela-usuarios tbody', $(data)).html());
          _this.erros.hide().find('ul').empty();
          _this.limparCampos(['nome', 'email']);
          _this.listaUsuarios.find('input').parent().removeClass('error');
          return _this.get('#nome').focus();
        };
      })(this));
    } else {
      return this.adicionarErros(data.erros);
    }
  };

  ConfiguracaoInicialDeUsuarios.prototype.adicionarErros = function(erros) {
    var erro, i, item, len, listaErros;
    listaErros = this.erros.find('ul');
    listaErros.empty();
    this.listaUsuarios.find('input').parent().removeClass('error');
    for (i = 0, len = erros.length; i < len; i++) {
      erro = erros[i];
      item = "<li data-field-name=" + erro.nome + " data-field-id=" + erro.nome + ">" + erro.erro + "</li>";
      listaErros.append(item);
      this.marcarCampo(erro.nome);
    }
    return this.erros.show();
  };

  ConfiguracaoInicialDeUsuarios.prototype.marcarCampo = function(campo) {
    return $("#" + campo).parent().addClass('error');
  };

  ConfiguracaoInicialDeUsuarios.prototype.limparCampos = function(campos) {
    var campo, i, len, results;
    results = [];
    for (i = 0, len = campos.length; i < len; i++) {
      campo = campos[i];
      results.push($('#' + campo).val(''));
    }
    return results;
  };

  ConfiguracaoInicialDeUsuarios.prototype.reload = function() {
    return $as.Manutencao.Usuarios.ConfiguracaoInicial.get().done((function(_this) {
      return function(data) {
        return _this.listaUsuarios.find('tbody').html($('#tabela-usuarios tbody', $(data)).html());
      };
    })(this));
  };

  ConfiguracaoInicialDeUsuarios.prototype.aoExcluir = function(data) {
    if (data.success) {
      return this.reload();
    }
  };

  return ConfiguracaoInicialDeUsuarios;

})(window.baseController);
