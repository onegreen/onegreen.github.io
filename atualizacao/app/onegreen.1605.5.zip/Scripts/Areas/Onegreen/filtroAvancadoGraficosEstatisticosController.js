﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.FiltroAvancadoGraficosEstatisticosController = (function(superClass) {
  extend(FiltroAvancadoGraficosEstatisticosController, superClass);

  function FiltroAvancadoGraficosEstatisticosController(opcoes, recursos) {
    this.opcoes = opcoes;
    this.recursos = recursos;
    this.exibirEsconderDataDeInicio = bind(this.exibirEsconderDataDeInicio, this);
    this.esconderFiltros = bind(this.esconderFiltros, this);
    this.SubmitGrafico = bind(this.SubmitGrafico, this);
    this.configurarComboGraficos = bind(this.configurarComboGraficos, this);
    FiltroAvancadoGraficosEstatisticosController.__super__.constructor.call(this, this.opcoes, this.recursos);
    this.configurarComboGraficos();
    this.configurarBinds();
    this.esconderFiltros();
    this.exibirEsconderDataDeInicio();
  }

  FiltroAvancadoGraficosEstatisticosController.prototype.configurarBinds = function() {
    $('#fecharFiltroGraficos').on('click', (function(_this) {
      return function(e) {
        return $(_this.opcoes.Contexto).toggle();
      };
    })(this));
    $('#btnFiltroAvancado').on('click', (function(_this) {
      return function(e) {
        return $(_this.opcoes.Contexto).toggle();
      };
    })(this));
    $('.js-grafico', this.opcoes.Contexto).unbind('click').click(this.SubmitGrafico);
    return $("#Grafico_Nome", this.opcoes.Contexto).data('autocompleter').setOnSelected(this.exibirEsconderDataDeInicio);
  };

  FiltroAvancadoGraficosEstatisticosController.prototype.configurarComboGraficos = function() {
    return setCombo(this.opcoes.Contexto, "#Grafico_Nome");
  };

  FiltroAvancadoGraficosEstatisticosController.prototype.SubmitGrafico = function() {
    var dados;
    dados = $(this.opcoes.Contexto).find(":input").serialize();
    return $as.Onegreen.GraficosEstatisticos.RetornarGrafico.get(dados).success((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  FiltroAvancadoGraficosEstatisticosController.prototype.esconderFiltros = function() {
    $('#filtrobase-projeto', this.opcoes.Contexto).hide();
    return $('#filtrobase-licenca', this.opcoes.Contexto).hide();
  };

  FiltroAvancadoGraficosEstatisticosController.prototype.exibirEsconderDataDeInicio = function() {
    var desabilitarDataDeInicio, textoComboGrafico;
    textoComboGrafico = $("#Grafico_Nome", this.opcoes.Contexto).val();
    desabilitarDataDeInicio = textoComboGrafico === this.recursos.LicencasObtidasDentroDoCusto || textoComboGrafico === this.recursos.EstudosDentroDoPrazo || textoComboGrafico === this.recursos.LicencasObtidasDentroDoPrazo || textoComboGrafico === this.recursos.CondicionantesDentroDoPrazo;
    if (desabilitarDataDeInicio) {
      return $("#DataInicio").parent().closest('div').hide();
    } else {
      return $("#DataInicio").parent().closest('div').show();
    }
  };

  return FiltroAvancadoGraficosEstatisticosController;

})(window.FiltroAvancadoBaseController);
