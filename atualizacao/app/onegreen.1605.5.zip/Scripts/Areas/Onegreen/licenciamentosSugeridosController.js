﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.licenciamentosSugeridosController = (function() {
  function licenciamentosSugeridosController() {
    this.reloadLicenciamentoSugerido = bind(this.reloadLicenciamentoSugerido, this);
    $("[data-MoverLicenciamentoParaCima]").click(this.moverLicenciamentoParaCima);
    $("[data-MoverLicenciamentoParaBaixo]").click(this.moverLicenciamentoParaBaixo);
  }

  licenciamentosSugeridosController.prototype.moverLicenciamentoParaCima = function() {
    return $as.Onegreen.ClassificacoesDoLicenciamentoAmbiental.MoverLicenciamentoSugeridoParaCima.post({
      idDaClassificacao: $(this).attr("data-classificacao"),
      idDoTipoDeLicenca: $(this).attr("data-tipoDeLicenca")
    }).success((function(_this) {
      return function(data) {
        return $("#licenciamentosSugeridos").html(data);
      };
    })(this));
  };

  licenciamentosSugeridosController.prototype.moverLicenciamentoParaBaixo = function() {
    return $as.Onegreen.ClassificacoesDoLicenciamentoAmbiental.MoverLicenciamentoSugeridoParaBaixo.post({
      idDaClassificacao: $(this).attr("data-classificacao"),
      idDoTipoDeLicenca: $(this).attr("data-tipoDeLicenca")
    }).success((function(_this) {
      return function(data) {
        return $("#licenciamentosSugeridos").html(data);
      };
    })(this));
  };

  licenciamentosSugeridosController.prototype.reloadLicenciamentoSugerido = function(idDaClassificacao, idDoTipoDeLicenca) {
    return $as.Onegreen.ClassificacoesDoLicenciamentoAmbiental.ReloadLicenciamentoSugerido.post({
      idDaClassificacao: idDaClassificacao,
      idDoTipoDeLicenca: idDoTipoDeLicenca
    }).success((function(_this) {
      return function(data) {
        $("#licenciamentosSugeridos").html(data);
        return window.ClassificacaoDoLicenciamentoAmbientalController.configurarComboTipoDeLicenca();
      };
    })(this));
  };

  return licenciamentosSugeridosController;

})();
