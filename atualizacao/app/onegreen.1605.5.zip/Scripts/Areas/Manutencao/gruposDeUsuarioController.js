﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.gruposDeUsuarioController = (function() {
  function gruposDeUsuarioController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.OcultarSubordinadas = bind(this.OcultarSubordinadas, this);
    this.ExibirSubordinadas = bind(this.ExibirSubordinadas, this);
    this.ExibirOcultarSubordinadas = bind(this.ExibirOcultarSubordinadas, this);
    this.fecharGruposDeUsuario = bind(this.fecharGruposDeUsuario, this);
    this.vincularUsuario = bind(this.vincularUsuario, this);
    this.carregarUnidadesDoGrupo = bind(this.carregarUnidadesDoGrupo, this);
    this.vincularUnidadeGerencial = bind(this.vincularUnidadeGerencial, this);
    this.carregarUnidades = bind(this.carregarUnidades, this);
    this.carregarUsuarios = bind(this.carregarUsuarios, this);
    this.carregarPlanoDeGestaoAtual = bind(this.carregarPlanoDeGestaoAtual, this);
    this.bindChecks = bind(this.bindChecks, this);
    this.salvar = bind(this.salvar, this);
    this.carregarBinds = bind(this.carregarBinds, this);
    this.loadComboUsuarios = bind(this.loadComboUsuarios, this);
    this.aoSelecionarUsuario = bind(this.aoSelecionarUsuario, this);
    this.loadComboUnidades = bind(this.loadComboUnidades, this);
    this.aoSelecionarUnidade = bind(this.aoSelecionarUnidade, this);
    this.loadCombos = bind(this.loadCombos, this);
    window.redimensionarModalLateral();
    this.botaoFechar = $("#btn-Fechar", this.contexto);
    this.carregarPlanoDeGestaoAtual();
    this.carregarBinds();
    this.loadCombos();
    this.bindChecks();
    $("[rel=tooltip]").tooltip();
  }

  gruposDeUsuarioController.prototype.loadCombos = function() {
    this.loadComboUnidades();
    return this.loadComboUsuarios();
  };

  gruposDeUsuarioController.prototype.aoSelecionarUnidade = function() {
    return $("#btn-adicionar-unidade", this.contexto).removeClass("disabled");
  };

  gruposDeUsuarioController.prototype.loadComboUnidades = function() {
    return setCombo(this.contexto, "#UnidadeGerencial_Nome", this.aoSelecionarUnidade);
  };

  gruposDeUsuarioController.prototype.aoSelecionarUsuario = function() {
    return $("#btn-adicionar-usuario", this.contexto).removeClass("disabled");
  };

  gruposDeUsuarioController.prototype.loadComboUsuarios = function() {
    return setCombo(this.contexto, "#Usuario_Nome", this.aoSelecionarUsuario);
  };

  gruposDeUsuarioController.prototype.carregarBinds = function() {
    this.botaoFechar.click(this.fecharGruposDeUsuario);
    $("#btn-adicionar-unidade", this.contexto).click(this.vincularUnidadeGerencial);
    $("#btn-adicionar-usuario", this.contexto).click(this.vincularUsuario);
    return $("#Nome", this.contexto).change(this.salvar);
  };

  gruposDeUsuarioController.prototype.salvar = function() {
    var dados;
    dados = $("#formGrupoDeUsuario input", this.contexto).serialize();
    return $as.Manutencao.GruposDeUsuario.Edit.post(dados).done((function(_this) {
      return function(data) {
        if (data.success) {
          GrupoDeUsuario.reload();
          return $(".validation-summary-errors ul", _this.contexto).remove();
        } else {
          return $("#main-modal").html(data);
        }
      };
    })(this));
  };

  gruposDeUsuarioController.prototype.bindChecks = function() {
    return $('#tabUG-content').find(':checkbox').click((function(_this) {
      return function() {
        var idDaUnidade;
        idDaUnidade = $( this ).data('unidade');
        return $as.Manutencao.GruposDeUsuario.AlterarPermissaoDeAlteracao.post({
          idDoGrupo: _this.options.idDoGrupo,
          idUnidade: idDaUnidade
        });
      };
    })(this));
  };

  gruposDeUsuarioController.prototype.carregarPlanoDeGestaoAtual = function() {
    return $as.API.PlanosDeGestao.ObterInformacoesDoPlanoDeGestaoAtual.get().success((function(_this) {
      return function(data) {
        return $("#PlanoDeGestaoNome", _this.contexto).html(data.nome);
      };
    })(this));
  };

  gruposDeUsuarioController.prototype.carregarUsuarios = function() {
    return $as.Manutencao.GruposDeUsuario.UsuariosDoGrupo.get({
      idDoGrupo: this.options.idDoGrupo
    }).success((function(_this) {
      return function(data) {
        return $("#tabUsuario-content", "#tab-content").empty().html(data);
      };
    })(this));
  };

  gruposDeUsuarioController.prototype.carregarUnidades = function() {
    return $as.Manutencao.GruposDeUsuario.UnidadesPorGrupoDeUsuario.get({
      idDoGrupo: this.options.idDoGrupo
    }).success((function(_this) {
      return function(data) {
        $("#tabUG-content", "#tab-content").empty().html(data);
        return _this.bindChecks();
      };
    })(this));
  };

  gruposDeUsuarioController.prototype.vincularUnidadeGerencial = function() {
    if ($('#UnidadeGerencial_Id').val() !== '') {
      return $as.Manutencao.GruposDeUsuario.VincularUnidadeGerencial.post({
        idDoGrupo: this.options.idDoGrupo,
        idDaUnidadeGerencial: $("#UnidadeGerencial_Id", this.contexto).val(),
        incluirSubordinadas: $("input[name=IncluirSubordinadas]:checked", this.contexto).length > 0,
        podeAlterar: $("input[name=PodeAlterar]:checked", this.contexto).length > 0
      }).success((function(_this) {
        return function(data) {
          return _this.carregarUnidadesDoGrupo();
        };
      })(this));
    }
  };

  gruposDeUsuarioController.prototype.carregarUnidadesDoGrupo = function() {
    return $as.Manutencao.GruposDeUsuario.UnidadesPorGrupoDeUsuario.get({
      idDoGrupo: this.options.idDoGrupo
    }).done((function(_this) {
      return function(data) {
        $("#tabUG-content", "#tab-content").empty().html(data);
        return _this.bindChecks();
      };
    })(this));
  };

  gruposDeUsuarioController.prototype.vincularUsuario = function() {
    if ($('#Usuario_Id').val() !== '') {
      return $as.Manutencao.GruposDeUsuario.VincularUsuario.post({
        idDoGrupo: this.options.idDoGrupo,
        idDoUsuario: $("#Usuario_Id", this.contexto).val()
      }).success((function(_this) {
        return function(data) {
          $("#tabUsuario-content", "#tab-content").empty().html(data);
          return $(_this.contexto).find('#Usuario_Nome').data('autocompleter').reset();
        };
      })(this));
    }
  };

  gruposDeUsuarioController.prototype.fecharGruposDeUsuario = function() {
    this.botaoFechar.tooltip('hide');
    return $('#main-modal').empty();
  };

  gruposDeUsuarioController.prototype.ExibirOcultarSubordinadas = function(el, idDaUnidade) {
    var elemento;
    elemento = $(el);
    if (elemento.hasClass("fa-plus-square")) {
      return this.ExibirSubordinadas(elemento, idDaUnidade);
    } else {
      return this.OcultarSubordinadas(elemento.parent().parent(), idDaUnidade);
    }
  };

  gruposDeUsuarioController.prototype.ExibirSubordinadas = function(elemento, idDaUnidade) {
    $("[data-pai='" + idDaUnidade + "']").removeClass('none');
    return elemento.removeClass("fa-plus-square").addClass("fa-minus-square");
  };

  gruposDeUsuarioController.prototype.OcultarSubordinadas = function(elemento, idDaUnidade) {
    if (idDaUnidade !== void 0) {
      $("[data-pai='" + idDaUnidade + "']").each((function(_this) {
        return function(i, e) {
          var idUnidade;
          $(e).addClass('none');
          idUnidade = $(e).data('idunidade');
          return _this.OcultarSubordinadas($(e), idUnidade);
        };
      })(this));
      return elemento.find('i').removeClass("fa-minus-square").addClass("fa-plus-square");
    }
  };

  gruposDeUsuarioController.aoCriar = function(data) {
    switch (data.data.FormaDeSalvar) {
      case "Salvar":
        gruposDeUsuarioController.reload();
        return $('#main-modal').empty();
      case "SalvarEAdicionarNovo":
        gruposDeUsuarioController.reload();
        return $as.Manutencao.GruposDeUsuario.Create.get().done(function(data) {
          return $("#main-modal").html(data);
        });
      case "SalvarEAdicionarDetalhes":
        gruposDeUsuarioController.reload();
        return $as.Manutencao.GruposDeUsuario.Edit.get({
          id: data.data.Id
        }).done(function(data) {
          return $("#main-modal").html(data);
        });
    }
  };

  gruposDeUsuarioController.reload = function() {
    return $as.Manutencao.GruposDeUsuario.Index.get().done(function(data) {
      return $("#main").html(data);
    });
  };

  return gruposDeUsuarioController;

})();
