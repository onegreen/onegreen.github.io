﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.EPM || (this.EPM = {});

window.EPM.meuPainelController = (function() {
  function meuPainelController(options) {
    this.options = options;
    this.carregarModalStatusAcoes = bind(this.carregarModalStatusAcoes, this);
  }

  meuPainelController.prototype.carregarModalStatusAcoes = function(status) {
    window.FiltroFarolDeProjeto.StatusAtividade = status;
    return $as.Atividades.Atividades.ListaAcoesDoUsuarioPorStatus.get(window.FiltroFarolDeProjeto).success((function(_this) {
      return function(data) {
        return window.GetDiv('status-acoes-container').html(data);
      };
    })(this));
  };

  return meuPainelController;

})();
