﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.mapeamentosDeObjetosController = (function() {
  function mapeamentosDeObjetosController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.configurarGuide = bind(this.configurarGuide, this);
    this.adicionarNovaSolucaoComFiltro = bind(this.adicionarNovaSolucaoComFiltro, this);
    this.configurarComboDeSolucaoDeProblema = bind(this.configurarComboDeSolucaoDeProblema, this);
    this.configurarComboDeClassificacao = bind(this.configurarComboDeClassificacao, this);
    this.configurarComboDeUnidadeGerencial = bind(this.configurarComboDeUnidadeGerencial, this);
    this.configurarComboDePlanoDeGestao = bind(this.configurarComboDePlanoDeGestao, this);
    this.configurarVinculoDeSolucaoDeProblemas = bind(this.configurarVinculoDeSolucaoDeProblemas, this);
    this.configurarBloqueioDosCombosDoVinculoDeSolucaoDeProblemas = bind(this.configurarBloqueioDosCombosDoVinculoDeSolucaoDeProblemas, this);
    this.carregarComboIndicador = bind(this.carregarComboIndicador, this);
    this.configurarEstiloDoObjeto = bind(this.configurarEstiloDoObjeto, this);
    this.configurarIndicador = bind(this.configurarIndicador, this);
    this.comboIndicador;
    this.comboUnidadeIndicador;
    if (this.options.EIndicador) {
      this.configurarIndicador();
    }
    if (this.options.EObjetivoEstrategico) {
      this.configurarObjetivoEstrategico();
    }
    this.configurarEstiloDoObjeto();
    this.configurarGuide();
    this.contextoVinculo = '#vincularsolucaodeproblemas-modal';
    this.tipoDoCombo = {
      PlanoDeGestao: 0,
      UnidadeGerencial: 1,
      Classificacao: 2,
      SolucaoDeProblema: 3
    };
  }

  mapeamentosDeObjetosController.prototype.configurarIndicador = function() {
    var onSelect;
    $('#adicionarindicador-modal').window({
      width: 810
    });
    $("#close-modal-adicionarindicador").click((function(_this) {
      return function() {
        return $("[dataguide]").attr("dataguide", "create-edit-mapa");
      };
    })(this));
    onSelect = (function(_this) {
      return function() {
        if (_this.comboIndicador) {
          return _this.comboIndicador.reset();
        }
      };
    })(this);
    this.comboUnidadeIndicador = setCombo(this.contexto, '#nomeUnidade', onSelect);
    setCombo(this.contexto, '#MapaVinculado_Nome');
    return this.carregarComboIndicador();
  };

  mapeamentosDeObjetosController.prototype.configurarObjetivoEstrategico = function() {
    $('#adicionarobjetivoestrategico-modal').window({
      width: 810,
      height: 500
    });
    $("#close-modal-adicionarobjetivoestrategico").click((function(_this) {
      return function() {
        return $("[dataguide]").attr("dataguide", "create-edit-mapa");
      };
    })(this));
    setCombo(this.contexto, '#ObjetivoEstrategico_Descricao');
    return setCombo(this.contexto, '#MapaVinculado_Nome');
  };

  mapeamentosDeObjetosController.prototype.configurarEstiloDoObjeto = function() {
    $('#Forma-Farol', this.contexto).click(function() {
      $('label', '#corDoTexto').removeAttr('disabled');
    });
    $('#Forma-Circulo', this.contexto).click(function() {
      $('label', '#corDoTexto').attr('disabled', 'disabled');
    });
    return $('#Forma-Retangulo', this.contexto).click(function() {
      $('label', '#corDoTexto').attr('disabled', 'disabled');
    });
  };

  mapeamentosDeObjetosController.prototype.carregarComboIndicador = function() {
    var idDaUnidadeGerencial, idPlanoGestao, parametros;
    idDaUnidadeGerencial = function() {
      if ($('#idUnidade').val() === '') {
        return 0;
      } else {
        return $('#idUnidade').val();
      }
    };
    idPlanoGestao = this.options.IdDoPlanoDeGestao;
    parametros = {
      idUnidadeGerencial: idDaUnidadeGerencial,
      idPlanoGestao: idPlanoGestao,
      somenteAtivos: true
    };
    this.comboIndicador = Results.api.setComboIndicador(this.contexto, '#Indicador_Nome', null, parametros);
  };

  mapeamentosDeObjetosController.prototype.configurarBloqueioDosCombosDoVinculoDeSolucaoDeProblemas = function(tipoDoCombo) {
    switch (tipoDoCombo) {
      case this.tipoDoCombo.PlanoDeGestao:
        $('#UnidadeGerencialFiltro', this.contextoVinculo).attr('disabled', 'disabled').val('');
        $('#UnidadeGerencialFiltroBtn', this.contextoVinculo).attr('disabled', 'disabled');
        $('#ClassificacaoAplicada_Descricao', this.contextoVinculo).attr('disabled', 'disabled').val('');
        $('#ClassificacaoAplicada_DescricaoBtn', this.contextoVinculo).attr('disabled', 'disabled');
        $('#SolucaoPorObjeto_SolucaoDeProblema_Descricao', this.contextoVinculo).attr('disabled', 'disabled').val('');
        return $('#SolucaoPorObjeto_SolucaoDeProblema_DescricaoBtn', this.contextoVinculo).attr('disabled', 'disabled');
      case this.tipoDoCombo.UnidadeGerencial:
        $('#UnidadeGerencialFiltro', this.contextoVinculo).removeAttr('disabled').val('');
        $('#UnidadeGerencialFiltroBtn', this.contextoVinculo).removeAttr('disabled');
        $('#IdDaUnidadeGerencial', this.contextoVinculo).val('');
        $('#ClassificacaoAplicada_Descricao', this.contextoVinculo).attr('disabled', 'disabled').val('');
        $('#ClassificacaoAplicada_DescricaoBtn', this.contextoVinculo).attr('disabled', 'disabled');
        $('#ClassificacaoAplicada_Id', this.contextoVinculo).val('');
        $('#SolucaoPorObjeto_SolucaoDeProblema_Descricao', this.contextoVinculo).attr('disabled', 'disabled').val('');
        $('#SolucaoPorObjeto_SolucaoDeProblema_DescricaoBtn', this.contextoVinculo).attr('disabled', 'disabled');
        return $('#SolucaoPorObjeto_SolucaoDeProblema_Id', this.contextoVinculo).val('');
      case this.tipoDoCombo.Classificacao:
        $('#UnidadeGerencialFiltro', this.contextoVinculo).removeAttr('disabled');
        $('#UnidadeGerencialFiltroBtn', this.contextoVinculo).removeAttr('disabled');
        $('#ClassificacaoAplicada_Descricao', this.contextoVinculo).removeAttr('disabled').val('');
        $('#ClassificacaoAplicada_DescricaoBtn', this.contextoVinculo).removeAttr('disabled');
        $('#ClassificacaoAplicada_Id', this.contextoVinculo).val('');
        $('#SolucaoPorObjeto_SolucaoDeProblema_Descricao', this.contextoVinculo).attr('disabled', 'disabled').val('');
        $('#SolucaoPorObjeto_SolucaoDeProblema_DescricaoBtn', this.contextoVinculo).attr('disabled', 'disabled');
        return $('#SolucaoPorObjeto_SolucaoDeProblema_Id', this.contextoVinculo).val('');
      case this.tipoDoCombo.SolucaoDeProblema:
        $('#UnidadeGerencialFiltro', this.contextoVinculo).removeAttr('disabled');
        $('#UnidadeGerencialFiltroBtn', this.contextoVinculo).removeAttr('disabled');
        $('#ClassificacaoAplicada_Descricao', this.contextoVinculo).removeAttr('disabled');
        $('#ClassificacaoAplicada_DescricaoBtn', this.contextoVinculo).removeAttr('disabled');
        $('#SolucaoPorObjeto_SolucaoDeProblema_Descricao', this.contextoVinculo).removeAttr('disabled').val('');
        $('#SolucaoPorObjeto_SolucaoDeProblema_DescricaoBtn', this.contextoVinculo).removeAttr('disabled');
        return $('#SolucaoPorObjeto_SolucaoDeProblema_Id', this.contextoVinculo).val('');
    }
  };

  mapeamentosDeObjetosController.prototype.configurarVinculoDeSolucaoDeProblemas = function() {
    this.configurarComboDePlanoDeGestao();
    return $('#NomeDoPlanoDeGestao', this.contextoVinculo).on("change", (function(_this) {
      return function(e) {
        if ($(e.delegateTarget).val().trim() === "") {
          return _this.configurarBloqueioDosCombosDoVinculoDeSolucaoDeProblemas(_this.tipoDoCombo.PlanoDeGestao);
        }
      };
    })(this));
  };

  mapeamentosDeObjetosController.prototype.configurarComboDePlanoDeGestao = function() {
    this.configurarBloqueioDosCombosDoVinculoDeSolucaoDeProblemas(this.tipoDoCombo.PlanoDeGestao);
    return setCombo(this.contextoVinculo, '#NomeDoPlanoDeGestao', this.configurarComboDeUnidadeGerencial);
  };

  mapeamentosDeObjetosController.prototype.configurarComboDeUnidadeGerencial = function() {
    var parametros;
    this.configurarBloqueioDosCombosDoVinculoDeSolucaoDeProblemas(this.tipoDoCombo.UnidadeGerencial);
    parametros = {
      idDoPlanoDeGestao: $('#IdDoPlanoDeGestao', this.contextoVinculo).val()
    };
    return setCombo(this.contextoVinculo, '#UnidadeGerencialFiltro', this.configurarComboDeClassificacao, parametros);
  };

  mapeamentosDeObjetosController.prototype.configurarComboDeClassificacao = function() {
    this.configurarBloqueioDosCombosDoVinculoDeSolucaoDeProblemas(this.tipoDoCombo.Classificacao);
    return setCombo(this.contextoVinculo, '#ClassificacaoAplicada_Descricao', this.configurarComboDeSolucaoDeProblema);
  };

  mapeamentosDeObjetosController.prototype.configurarComboDeSolucaoDeProblema = function() {
    var parametros;
    this.configurarBloqueioDosCombosDoVinculoDeSolucaoDeProblemas(this.tipoDoCombo.SolucaoDeProblema);
    parametros = {
      idDaUnidade: $('#IdDaUnidadeGerencial', this.contextoVinculo).val(),
      idDaClassificacao: $('#ClassificacaoAplicada_Id', this.contextoVinculo).val()
    };
    return setCombo(this.contextoVinculo, '#SolucaoPorObjeto_SolucaoDeProblema_Descricao', null, parametros);
  };

  mapeamentosDeObjetosController.prototype.recarregarSolucoesDeProblemasPorObjeto = function(idDoMapeamento) {
    return $as.Performance.MapeamentosDeObjetos.ListarSoluoesDeProblemasPorObjeto.get({
      idDoMapeamento: idDoMapeamento
    }).done(function(data) {
      return $('#solucoesPorObjeto-container', '#adicionarobjetivoestrategico-modal').empty().html(data);
    });
  };

  mapeamentosDeObjetosController.prototype.reload = function(json) {
    if (json.data.formaDeSalvar === 'SalvarEAdicionarDetalhes') {
      return $as.Performance.MapeamentosDeObjetos.Edit.get({
        id: json.data.idDoObjetivo
      }).done(function(data) {
        window.MapaDeObjetos.reload(json.data.idDoMapa, true);
        return $('#main-modal').html(data);
      });
    } else {
      return window.MapaDeObjetos.reload(json.data.idDoMapa, json.data.animarItem);
    }
  };

  mapeamentosDeObjetosController.prototype.vincularSolucaoDeProblemas = function(formaDeSalvar) {
    var form;
    $('#close-modal-vincularsolucaodeproblemas').click();
    form = $('#formVincularSolucaoDeProblemas', this.contextoVinculo);
    return $as.Performance.MapeamentosDeObjetos.VincularSolucaoDeProblemas.post(form.serialize()).done((function(_this) {
      return function(data) {
        if (data.success) {
          _this.recarregarSolucoesDeProblemasPorObjeto(data.data.idDoMapeamento);
          if (formaDeSalvar === 'SalvarEAdicionarNovo') {
            return _this.adicionarNovaSolucaoComFiltro(data.data);
          }
        } else {
          return $('#create-edit-solucaoPorObjeto').html(data);
        }
      };
    })(this));
  };

  mapeamentosDeObjetosController.prototype.adicionarNovaSolucaoComFiltro = function(filtro) {
    return $as.Performance.MapeamentosDeObjetos.VincularSolucaoDeProblemas.get({
      idDoMapeamento: filtro.idDoMapeamento
    }).done((function(_this) {
      return function(data) {
        var $modal;
        $modal = $(data);
        $modal.find('#IdDoPlanoDeGestao').val(filtro.idDoPlanoDeGestao);
        $modal.find('#NomeDoPlanoDeGestao').val(filtro.nomeDoPlanoDeGestao);
        $modal.find('#IdDaUnidadeGerencial').val(filtro.idDaUnidadeGerencial);
        $modal.find('#UnidadeGerencialFiltro').val(filtro.nomeDaUnidadeGerencial);
        return $('#create-edit-solucaoPorObjeto').html($modal);
      };
    })(this));
  };

  mapeamentosDeObjetosController.prototype.configurarGuide = function() {
    if (this.options.EIndicador) {
      return $("[dataguide]").attr("dataguide", "indicadores-do-mapa");
    } else {
      return $("[dataguide]").attr("dataguide", "objetivo-estrategico");
    }
  };

  return mapeamentosDeObjetosController;

})();
