﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.graficoDeToleranciaController = (function() {
  function graficoDeToleranciaController(contexto, grafico, posicaoDeMelhor, toleranciaAmarelaSuperior, toleranciaAmarelaInferior, toleranciaVerdeSuperior, toleranciaVerdeInferior, toleranciaAzul) {
    this.contexto = contexto;
    this.grafico = grafico;
    this.rederizarGrafico = bind(this.rederizarGrafico, this);
    this.renderizar = bind(this.renderizar, this);
    this.construirSeries = bind(this.construirSeries, this);
    this.obterDados = bind(this.obterDados, this);
    this.$contexto = $(this.contexto);
    this.$grafico = $(this.grafico, this.contexto);
    this.$posicaoDeMelhor = $(posicaoDeMelhor, this.contexto).val();
    this.valorAmareloSuperior = this.converterDecimal($(toleranciaAmarelaSuperior, this.contexto).val());
    this.valorAmareloInferior = this.converterDecimal($(toleranciaAmarelaInferior, this.contexto).val());
    this.valorVerdeSuperior = this.converterDecimal($(toleranciaVerdeSuperior, this.contexto).val());
    this.valorVerdeInferior = this.converterDecimal($(toleranciaVerdeInferior, this.contexto).val());
    this.valorAzul = this.converterDecimal($(toleranciaAzul, this.contexto).val());
    this.toleranciaAzulZerada = this.valorAzul === 0;
    this.toleranciaAmarelaSuperiorZerada = this.valorAmareloSuperior === 0;
    this.toleranciaVerdeSuperiorZerada = this.valorVerdeSuperior === 0;
  }

  graficoDeToleranciaController.prototype.obterDados = function(analisarMetaInferior) {
    this.toleranciaAzul = this.valorAzul;
    this.toleranciaVerdeSuperior = this.valorVerdeSuperior + this.valorAzul;
    this.toleranciaAmarelaSuperior = this.valorAmareloSuperior > this.valorVerdeSuperior ? this.valorAmareloSuperior - this.valorVerdeSuperior : 0;
    this.toleranciaVermelhaSuperior = this.valorVerdeSuperior < this.valorAmareloSuperior ? 100 - this.valorAmareloSuperior : 100 - this.valorVerdeSuperior;
    this.tamanhoMaximo = this.toleranciaAzul + this.toleranciaVerdeSuperior + this.toleranciaAmarelaSuperior + this.toleranciaVermelhaSuperior;
    console.log(this.toleranciaAzul);
    if (this.toleranciaAzulZerada) {
      this.tamanhoMaximo = 110;
    }
    this.valorTooltipVermelhoSuperior = this.toleranciaVermelhaSuperior;
    this.valorTooltipAmareloSuperior = this.toleranciaVermelhaSuperior + this.toleranciaAmarelaSuperior;
    this.valorTooltipVerdeSuperior = this.toleranciaVermelhaSuperior + this.toleranciaAmarelaSuperior + this.toleranciaVerdeSuperior;
    if (analisarMetaInferior) {
      this.toleranciaVerdeInferior = this.valorVerdeInferior;
      this.toleranciaAmarelaInferior = this.valorAmareloInferior > this.valorVerdeInferior ? this.valorAmareloInferior - this.valorVerdeInferior : 0;
      this.toleranciaVermelhaInferior = this.valorVerdeInferior < this.valorAmareloInferior ? 100 - this.valorAmareloInferior : 100 - this.valorVerdeInferior;
      if (this.toleranciaVermelhaInferior === 100) {
        this.toleranciaVermelhaInferior = 99;
        this.toleranciaVerdeInferior = 1;
      }
      this.valorTooltipVermelhoInferior = this.toleranciaVermelhaInferior;
      this.valorTooltipAmareloInferior = this.toleranciaVermelhaInferior + this.toleranciaAmarelaInferior;
      return this.valorTooltipVerdeInferior = this.toleranciaVermelhaInferior + this.toleranciaAmarelaInferior + this.toleranciaVerdeInferior;
    }
  };

  graficoDeToleranciaController.prototype.construirSeries = function(analisarMetaInferior) {
    var series;
    if (analisarMetaInferior) {
      series = [
        {
          name: 'VermelhoSuperior',
          color: '#E31B23',
          showInLegend: false,
          data: [this.toleranciaVermelhaSuperior],
          tooltipText: this.valorTooltipVermelhoSuperior + "% ---| 0%"
        }, {
          name: 'AmareloSuperior',
          color: '#E8E434',
          showInLegend: false,
          data: [this.toleranciaAmarelaSuperior],
          tooltipText: this.valorTooltipAmareloSuperior + "% ---| " + this.toleranciaVermelhaSuperior + "%"
        }, {
          name: 'VerdeSuperior',
          color: '#46A546',
          showInLegend: false,
          data: [this.toleranciaVerdeSuperior],
          tooltipText: this.valorTooltipVerdeSuperior + "% ---| " + (this.toleranciaAmarelaSuperior + this.toleranciaVermelhaSuperior) + "%"
        }, {
          name: 'VermelhoInferior',
          color: '#E31B23',
          showInLegend: false,
          data: [-this.toleranciaVermelhaInferior],
          tooltipText: "0% |--- " + this.valorTooltipVermelhoInferior + "%"
        }, {
          name: 'AmareloInferior',
          color: '#E8E434',
          showInLegend: false,
          data: [-this.toleranciaAmarelaInferior],
          tooltipText: this.toleranciaVermelhaInferior + "% |--- " + this.valorTooltipAmareloInferior + "%"
        }, {
          name: 'VerdeInferior',
          color: '#46A546',
          showInLegend: false,
          data: [-this.toleranciaVerdeInferior],
          tooltipText: (this.toleranciaAmarelaInferior + this.toleranciaVermelhaInferior) + "% |--- " + this.valorTooltipVerdeInferior + "%"
        }
      ];
    } else {
      series = [];
      series.push({
        name: 'Azul',
        color: '#0064CD',
        showInLegend: false,
        data: [this.tamanhoMaximo],
        tooltipText: (this.toleranciaAmarelaSuperior + this.toleranciaVermelhaSuperior + this.toleranciaVerdeSuperior) + "% |--- <i class='sw-infinito'></i>"
      });
      series.push({
        name: 'VerdeSuperior',
        color: '#46A546',
        showInLegend: false,
        data: [this.toleranciaVerdeSuperior],
        tooltipText: (this.toleranciaAmarelaSuperior + this.toleranciaVermelhaSuperior) + "% |--- " + this.valorTooltipVerdeSuperior + "%"
      });
      if (this.toleranciaAzulZerada) {
        series[series.length - 1].data = [this.tamanhoMaximo];
        series[series.length - 1].tooltipText = (this.toleranciaAmarelaSuperior + this.toleranciaVermelhaSuperior) + "% |--- <i class='sw-infinito'></i>";
      }
      series.push({
        name: 'AmareloSuperior',
        color: '#E8E434',
        showInLegend: false,
        data: [this.toleranciaAmarelaSuperior],
        tooltipText: this.toleranciaVermelhaSuperior + "% |--- " + this.valorTooltipAmareloSuperior + "%"
      });
      if (this.toleranciaVerdeSuperiorZerada) {
        series[series.length - 1].tooltipText = this.toleranciaVermelhaSuperior + "% |--- 99,999...%";
      }
      series.push({
        name: 'VermelhoSuperior',
        color: '#E31B23',
        showInLegend: false,
        data: [this.toleranciaVermelhaSuperior],
        tooltipText: "0% |--- " + this.valorTooltipVermelhoSuperior + "%"
      });
      if (!this.toleranciaAzulZerada && this.toleranciaAmarelaSuperiorZerada && this.toleranciaVerdeSuperiorZerada) {
        series[series.length - 1].tooltipText = "0% |--- 99,999...%";
      }
    }
    return {
      Series: series
    };
  };

  graficoDeToleranciaController.prototype.renderizar = function(analisarMetaInferior) {
    var chart;
    Highcharts.setOptions(window.defaultTheme);
    window.defaultTheme.setBackGround();
    chart = this.$grafico.highcharts({
      chart: {
        type: 'column',
        inverted: true,
        backgroundColor: '#FFF'
      },
      title: {
        text: ''
      },
      xAxis: analisarMetaInferior ? [
        {
          categories: ['LI'],
          reversed: false,
          labels: {
            step: 1
          }
        }, {
          categories: ['LS'],
          reversed: false,
          opposite: true,
          linkedTo: 0,
          labels: {
            step: 1
          }
        }
      ] : {
        labels: {
          enabled: false
        }
      },
      yAxis: analisarMetaInferior ? {
        min: -100,
        max: 100,
        title: {
          text: resourceJsonCommom.SimboloPercentualDeAtingimento
        },
        labels: {
          formatter: function() {
            if (this.value <= 0) {
              return 100 + this.value;
            }
            return 100 - (Math.abs(this.value));
          }
        }
      } : {
        min: 0,
        max: this.tamanhoMaximo,
        title: {
          text: resourceJsonCommom.SimboloPercentualDeAtingimento
        }
      },
      tooltip: {
        enabled: true,
        useHTML: true,
        formatter: function() {
          return '<b>' + this.series.options.tooltipText;
        },
        positioner: function() {
          return {
            x: 0,
            y: 0
          };
        }
      },
      credits: {
        enabled: false
      },
      plotOptions: {
        column: {
          stacking: 'normal'
        }
      },
      series: this.configuracoes.Series
    });
    if (this.$posicaoDeMelhor !== 'Faixa' && this.$posicaoDeMelhor !== 'MelhorNoPonto') {
      return $('[text-anchor=middle]', this.contexto).last().text("...");
    }
  };

  graficoDeToleranciaController.prototype.rederizarGrafico = function() {
    var analisarMetaInferior;
    analisarMetaInferior = this.$posicaoDeMelhor === 'Faixa' || this.$posicaoDeMelhor === 'MelhorNoPonto' ? true : false;
    this.obterDados(analisarMetaInferior);
    this.configuracoes = this.construirSeries(analisarMetaInferior);
    return this.renderizar(analisarMetaInferior);
  };

  graficoDeToleranciaController.prototype.converterDecimal = function(valor) {
    return parseFloat(valor.replace(",", "."));
  };

  return graficoDeToleranciaController;

})();
