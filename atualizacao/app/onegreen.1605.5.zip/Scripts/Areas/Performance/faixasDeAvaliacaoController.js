﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.faixasDeAvaliacaoController = (function() {
  function faixasDeAvaliacaoController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.bindMetods = bind(this.bindMetods, this);
    $('#faixas-modal').window();
    this.bindMetods();
  }

  faixasDeAvaliacaoController.prototype.bindMetods = function() {
    return window.FaixaDeAvaliacao = {
      reload: (function(_this) {
        return function() {
          return $as.Performance.FaixasDeAvaliacao.Index.get({
            idDoPai: _this.options.IdDoPai
          }).success(function(data) {
            return $('#FaixasDeAvaliacao-container').html(data);
          });
        };
      })(this),
      initializeColorPicker: (function(_this) {
        return function() {
          return $(_this.contexto).find('#Cor').colorpicker({
            history: false,
            displayIndicator: false,
            exibirOpcaoFarol: false,
            exibirSomenteAsCoresPadroes: false
          });
        };
      })(this)
    };
  };

  return faixasDeAvaliacaoController;

})();
