﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.desdobramentoDeItensController = (function() {
  function desdobramentoDeItensController(contexto, options, resource) {
    this.contexto = contexto;
    this.options = options;
    this.resource = resource;
    this.reload = bind(this.reload, this);
    this.create = bind(this.create, this);
  }

  desdobramentoDeItensController.prototype.create = function() {
    return $('#btn-adicionar-desdobramento', this.contexto).click();
  };

  desdobramentoDeItensController.prototype.reload = function() {
    return $as.Performance.DesdobramentosDeItens.Index.get({
      idDoPai: this.options.idDoIndicador
    }).success((function(_this) {
      return function(data) {
        $(_this.contexto).html(data);
        if (window.PropriedadesDoIndicadorController !== null) {
          return window.PropriedadesDoIndicadorController.exibirMensagemParaCarregarSeNecessario();
        }
      };
    })(this));
  };

  return desdobramentoDeItensController;

})();
