﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.filtroAvancadoDeIndicadoresController = (function() {
  filtroAvancadoDeIndicadoresController.origem;

  function filtroAvancadoDeIndicadoresController(opcoes1, recursos) {
    this.opcoes = opcoes1;
    this.recursos = recursos;
    this.setarFiltroPadrao = bind(this.setarFiltroPadrao, this);
    this.manipularCamposPorFrequencia = bind(this.manipularCamposPorFrequencia, this);
    this.loadComboMeses = bind(this.loadComboMeses, this);
    this.redimensionarDiv = bind(this.redimensionarDiv, this);
    this.loadComboTiposDeIndicador = bind(this.loadComboTiposDeIndicador, this);
    this.loadComboAreaDeResultados = bind(this.loadComboAreaDeResultados, this);
    this.loadComboUnidadeGerencial = bind(this.loadComboUnidadeGerencial, this);
    this.loadComboPlanoDeGestao = bind(this.loadComboPlanoDeGestao, this);
    this.ConfigurarScroll = bind(this.ConfigurarScroll, this);
    this.contexto = "#containerFiltroAvancadoIndicador";
    this.loadComboPlanoDeGestao();
    this.loadComboUnidadeGerencial();
    this.loadComboAreaDeResultados();
    this.loadComboTiposDeIndicador();
    $("#NomeDoIndicador", this.contexto).focus();
    $("#btnLimpar", this.contexto).click(this.setarFiltroPadrao);
    $("[name=Frequencia]", this.contexto).click(this.manipularCamposPorFrequencia);
    $("#fecharFiltroAvancado", this.contexto).click(function() {
      return $("#containerFiltroAvancadoIndicador").closest('li').removeClass("open");
    });
    $("#menuFiltroAvancado").click(function() {
      return $("#containerFiltroAvancadoIndicador").closest('li').addClass("open");
    });
    if (filtroAvancadoDeIndicadoresController.origem === Results.api.Origem.Planilha) {
      $('#divFormaVisualizacao', this.contexto).show();
      this.loadComboMeses();
    }
    this.ConfigurarScroll();
  }

  filtroAvancadoDeIndicadoresController.prototype.ConfigurarScroll = function() {
    var api;
    api = $("#divScroll-filtro-avancado").data("jsp");
    if (api) {
      api.destroy();
    }
    return $("#divScroll-filtro-avancado").jScrollPane({
      allowPageScroll: false
    });
  };

  filtroAvancadoDeIndicadoresController.prototype.loadComboPlanoDeGestao = function() {
    var opcoes, select;
    select = (function(_this) {
      return function(inputCombo) {
        $('#NomeDaUnidade', _this.contexto).val("");
        return $('#IdDaUnidade', _this.contexto).val("");
      };
    })(this);
    opcoes = {
      contextId: this.contexto,
      elementId: "#ExercicioDoPlanoDeGestao",
      onSelected: select,
      container: 'body'
    };
    return setComboJSON(opcoes);
  };

  filtroAvancadoDeIndicadoresController.prototype.loadComboUnidadeGerencial = function() {
    var opcoes, parametros;
    parametros = {
      idDoPlanoDeGestao: (function(_this) {
        return function() {
          return $("#IdDoPlanoDeGestao", _this.contexto).val();
        };
      })(this)
    };
    opcoes = {
      contextId: this.contexto,
      elementId: "#NomeDaUnidade",
      parameters: parametros,
      container: 'body'
    };
    return setComboJSON(opcoes);
  };

  filtroAvancadoDeIndicadoresController.prototype.loadComboAreaDeResultados = function() {
    var opcoes;
    opcoes = {
      contextId: this.contexto,
      elementId: "#NomeDaAreaDeResultado",
      container: 'body',
      defaultOption: filtroAvancadoDeIndicadoresController.origem === Results.api.Origem.Farol ? {
        Key: "",
        Value: "(" + this.recursos.Todas + ")"
      } : void 0
    };
    return setComboJSON(opcoes);
  };

  filtroAvancadoDeIndicadoresController.prototype.loadComboTiposDeIndicador = function() {
    var $combo, $divCombo, TiposDeIndicadorViewModel, customizeMultiSelectDescriptionName, divScroll, onSelect;
    TiposDeIndicadorViewModel = {
      TiposDeIndicador: ko.observableArray(this.opcoes.TiposDeIndicadorSelecionados),
      removeItem: (function(_this) {
        return function(tipoDeIndicador) {
           this .TiposDeIndicador.remove(tipoDeIndicador);
          return _this.redimensionarDiv();
        };
      })(this)
    };
    window.TiposDeIndicadorViewModel = TiposDeIndicadorViewModel;
    ko.applyBindings(TiposDeIndicadorViewModel, $('#tiposdeindicador_itens')[0]);
    $combo = $("#ListagemTiposDeIndicadorCombo");
    $divCombo = $combo.parents("div.autocompleter");
    divScroll = $("#divScroll-filtro-avancado");
    onSelect = (function(_this) {
      return function() {
        return _this.redimensionarDiv();
      };
    })(this);
    customizeMultiSelectDescriptionName = (function(_this) {
      return function(json, item, callback) {
        return $as.API.TiposDeIndicador.ObterSiglaPorId.get({
          id: json["Id"]
        }, {
          global: false
        }).success(function(data) {
          json[item] = data;
          return callback();
        });
      };
    })(this);
    return $combo.autocompleter($divCombo.attr("data-url"), {
      elementToClick: "#ListagemTiposDeIndicadorComboBtn",
      multiSelectArray: TiposDeIndicadorViewModel.TiposDeIndicador,
      multiSelectElement: "#tiposdeindicador_itens",
      container: 'body',
      onSelected: function() {
        return onSelect();
      },
      customizeMultiSelectDescriptionName: customizeMultiSelectDescriptionName
    });
  };

  filtroAvancadoDeIndicadoresController.prototype.redimensionarDiv = function() {
    var apiScroll, divScroll;
    divScroll = $("#divScroll-filtro-avancado");
    apiScroll = divScroll.data().jsp;
    apiScroll.reinitialise();
    apiScroll.scrollToBottom();
    return $('.jspHorizontalBar').hide();
  };

  filtroAvancadoDeIndicadoresController.prototype.loadComboMeses = function() {
    var opcoes;
    opcoes = {
      contextId: this.contexto,
      elementId: "#NomeDoMes",
      container: 'body'
    };
    return setComboJSON(opcoes);
  };

  filtroAvancadoDeIndicadoresController.prototype.manipularCamposPorFrequencia = function(event) {
    var frequencia;
    frequencia = $(event.delegateTarget).val();
    if (!filtroAvancadoDeIndicadoresController.origem === Results.api.Origem.Planilha) {
      return this.habilitarDesabilitarFormaVisualizacao(frequencia);
    }
  };

  filtroAvancadoDeIndicadoresController.prototype.habilitarDesabilitarFormaVisualizacao = function(frequencia) {
    switch (frequencia) {
      case 'Mensal':
        $('#divFormaVisualizacao', this.contexto).show();
        break;
      case 'Semanal':
        $('#divFormaVisualizacao', this.contexto).hide();
        break;
      case 'Diaria':
        $('#divFormaVisualizacao', this.contexto).hide();
    }
    return this.redimensionarDiv();
  };

  filtroAvancadoDeIndicadoresController.prototype.setarFiltroPadrao = function() {
    return $as.Performance.FiltroDeIndicadores.LimparFiltro.get().success(function(filtro) {
      $("#containerFiltroAvancadoIndicador").html(filtro);
      return $("#containerFiltroAvancadoIndicador").closest("li.dropdown").addClass("open");
    });
  };

  return filtroAvancadoDeIndicadoresController;

})();
