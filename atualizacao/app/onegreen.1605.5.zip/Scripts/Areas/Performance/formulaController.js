﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.formulaController = (function(superClass) {
  extend(formulaController, superClass);

  function formulaController(view, options) {
    var configurarFormula;
    this.view = view;
    this.options = options;
    this.aoCancelar = bind(this.aoCancelar, this);
    this.aoSalvar = bind(this.aoSalvar, this);
    formulaController.__super__.constructor.call(this, this.view, null);
    configurarFormula = new window.configurarFormulaController(this.view);
  }

  formulaController.prototype.aoSalvar = function(data) {
    if (Secao) {
      Secao.reload();
      return $as.Manutencao.Secoes.Edit.get({
        id: this.options.idSecao
      }).done((function(_this) {
        return function(data) {
          return $('#add-secao-container').html(data);
        };
      })(this));
    }
  };

  formulaController.prototype.aoCancelar = function() {
    var $secaoContainer;
    $secaoContainer = $('#secao-modal');
    $("#origens-container", $secaoContainer).hide();
    $('#detalhes-secao-container', $secaoContainer).show();
    $("#secao-modal-footer", $secaoContainer).show();
    return $secaoContainer.show();
  };

  return formulaController;

})(window.baseController);
