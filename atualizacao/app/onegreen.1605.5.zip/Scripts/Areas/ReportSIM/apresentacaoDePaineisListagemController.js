﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.apresentacaoDePaineisListagemController = (function(superClass) {
  extend(apresentacaoDePaineisListagemController, superClass);

  function apresentacaoDePaineisListagemController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.excluir = bind(this.excluir, this);
    this.loadIndex = bind(this.loadIndex, this);
    apresentacaoDePaineisListagemController.__super__.constructor.call(this, this.view, this.model);
    this.loadIndex();
  }

  apresentacaoDePaineisListagemController.prototype.loadIndex = function() {
    this.get('.js-ExcluirApresentacao').unbind('click').click((function(_this) {
      return function(event) {
        return Confirmacao.mostrar("", function() {
          return _this.excluir($(event.delegateTarget));
        });
      };
    })(this));
    return window.MarcarMenuSuperior("#lnkApresentacoes");
  };

  apresentacaoDePaineisListagemController.prototype.excluir = function(element) {
    return $as.ReportSIM.ApresentacoesDePaineis.Delete.post({
      id: $(element).attr('data-id')
    }).done((function(_this) {
      return function(data) {
        return $(element).closest('tr').remove();
      };
    })(this));
  };

  return apresentacaoDePaineisListagemController;

})(window.baseController);
