﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.relatoriosSlideController = (function(superClass) {
  extend(relatoriosSlideController, superClass);

  function relatoriosSlideController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.resizeGraficos = bind(this.resizeGraficos, this);
    this.transicaoAtutomaticaSlides = bind(this.transicaoAtutomaticaSlides, this);
    this.submeterData = bind(this.submeterData, this);
    this.visualizarUltimoItem = bind(this.visualizarUltimoItem, this);
    this.visualizarPrimeiroItem = bind(this.visualizarPrimeiroItem, this);
    this.visualizarItemAnterior = bind(this.visualizarItemAnterior, this);
    this.visualizarProximoItem = bind(this.visualizarProximoItem, this);
    this.ativarBotoesDeNavegacao = bind(this.ativarBotoesDeNavegacao, this);
    this.toggleTransicaoAutomatica = bind(this.toggleTransicaoAutomatica, this);
    this.avancarVisualizacaoEm = bind(this.avancarVisualizacaoEm, this);
    this.ativarGeleria = bind(this.ativarGeleria, this);
    this.ativarGaleriaSeNecessario = bind(this.ativarGaleriaSeNecessario, this);
    this.visualizarItem = bind(this.visualizarItem, this);
    this.mudarSimpartPeloTeclado = bind(this.mudarSimpartPeloTeclado, this);
    this.load = bind(this.load, this);
    relatoriosSlideController.__super__.constructor.call(this, this.view);
    this.load();
  }

  relatoriosSlideController.prototype.load = function() {
    var calendario;
    this.IndiceVisivel = 0;
    this.QuantidadeDeItens = -1;
    this.PodeMudarOItem = true;
    this.MostradorSlideAtual = $("#MostradorSlideAtual");
    this.ativarBotoesDeNavegacao();
    this.PassarAtutomaticamente = false;
    this.QuantidadeDeSegundosParaTransicao = 10;
    calendario = this.get('#Calendario');
    calendario.datepicker({
      changeYear: true,
      showOn: "focus"
    });
    calendario.change(this.submeterData);
    calendario.keydown((function(_this) {
      return function(event) {
        return event.stopPropagation();
      };
    })(this));
    this.Slides = this.get(".ApresentacaoContainer");
    this.Slides.hide();
    this.QuantidadeDeItens = this.Slides.length;
    this.visualizarPrimeiroItem();
    this.MostradorSlideAtual.val(1);
    this.MostradorSlideAtual.change((function(_this) {
      return function(event) {
        var item;
        item = parseInt($(event.delegateTarget).val()) - 1;
        return _this.visualizarItem(item);
      };
    })(this));
    this.transicaoAtutomaticaSlides();
    return this.resizeGraficos();
  };

  relatoriosSlideController.prototype.mudarSimpartPeloTeclado = function(event) {
    var tecla;
    tecla = event.keyCode;
    switch (tecla) {
      case 38:
        return this.visualizarPrimeiroItem();
      case 40:
        return this.visualizarUltimoItem();
      case 32:
      case 39:
        return this.visualizarProximoItem();
      case 37:
        return this.visualizarItemAnterior();
    }
  };

  relatoriosSlideController.prototype.visualizarItem = function(item) {
    if (item < 0) {
      item = 0;
    }
    if (item > this.QuantidadeDeItens) {
      item = this.QuantidadeDeItens;
    }
    if (this.PodeMudarOItem) {
      this.PodeMudarOItem = false;
      return $(this.Slides[this.IndiceVisivel]).fadeOut(400, (function(_this) {
        return function() {
          $(_this.Slides[item]).fadeIn();
          _this.IndiceVisivel = item;
          _this.MostradorSlideAtual.val(_this.IndiceVisivel + 1);
          _this.PodeMudarOItem = true;
          return _this.resizeGraficos();
        };
      })(this));
    }
  };

  relatoriosSlideController.prototype.ativarGaleriaSeNecessario = function(simpart) {
    if (simpart.attr("usarGalleria") === 'True' && simpart.attr("carregado") !== 'True') {
      return this.ativarGeleria(simpart);
    }
  };

  relatoriosSlideController.prototype.ativarGeleria = function(simpart) {
    var galeria;
    galeria = $(".galleria", simpart);
    if (galeria.length > 0) {
      galeria.galleria({
        responsive: true,
        imageCrop: false,
        debug: false
      });
    }
    return simpart.attr("carregado", "True");
  };

  relatoriosSlideController.prototype.avancarVisualizacaoEm = function(quandtidade) {
    var novoIndice;
    novoIndice = this.IndiceVisivel + quandtidade;
    if (novoIndice >= 0 && novoIndice <= this.QuantidadeDeItens - 1) {
      return this.visualizarItem(novoIndice);
    }
  };

  relatoriosSlideController.prototype.toggleTransicaoAutomatica = function() {
    this.get("#ToggleTransicaoAutomatica i").toggleClass("icon-play");
    this.get("#ToggleTransicaoAutomatica i").toggleClass("icon-pause");
    this.get("#BarraDeTransicaoAutomatica").toggle();
    return this.PassarAtutomaticamente = !this.PassarAtutomaticamente;
  };

  relatoriosSlideController.prototype.ativarBotoesDeNavegacao = function() {
    this.get("#VisualizarUltimoSlide").click(this.visualizarUltimoItem);
    this.get("#AvancarSlide").click(this.visualizarProximoItem);
    this.get("#VoltarSlide").click(this.visualizarItemAnterior);
    this.get("#VisualizarPrimeiroSlide").click(this.visualizarPrimeiroItem);
    this.get("#ToggleTransicaoAutomatica").click(this.toggleTransicaoAutomatica);
    return $("body").keydown(this.mudarSimpartPeloTeclado);
  };

  relatoriosSlideController.prototype.visualizarProximoItem = function() {
    return this.avancarVisualizacaoEm(1);
  };

  relatoriosSlideController.prototype.visualizarItemAnterior = function() {
    return this.avancarVisualizacaoEm(-1);
  };

  relatoriosSlideController.prototype.visualizarPrimeiroItem = function() {
    return this.visualizarItem(0);
  };

  relatoriosSlideController.prototype.visualizarUltimoItem = function() {
    return this.visualizarItem(this.QuantidadeDeItens - 1);
  };

  relatoriosSlideController.prototype.submeterData = function() {
    return this.get("#submeterNovaData").click();
  };

  relatoriosSlideController.prototype.transicaoAtutomaticaSlides = function() {
    var timeout;
    timeout = 1000 * this.QuantidadeDeSegundosParaTransicao;
    if (this.PassarAtutomaticamente) {
      if (this.IndiceVisivel + 1 < this.QuantidadeDeItens) {
        this.visualizarProximoItem();
      } else {
        this.visualizarPrimeiroItem();
      }
    }
    this.get("#BarraDeTransicaoAutomatica").animate({
      width: '100%'
    }, timeout, (function(_this) {
      return function() {
        return $("#BarraDeTransicaoAutomatica").css("width", "0%");
      };
    })(this));
    return setTimeout(this.transicaoAtutomaticaSlides, timeout);
  };

  relatoriosSlideController.prototype.resizeGraficos = function() {
    return $(window).resize();
  };

  return relatoriosSlideController;

})(window.baseController);
