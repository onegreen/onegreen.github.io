﻿window.filtroUGEPlanoDeGestao = (function() {
  function filtroUGEPlanoDeGestao() {}

  filtroUGEPlanoDeGestao.contexto = '';

  filtroUGEPlanoDeGestao.configurar = function(contexto, onSelectUG, onSelectPlaGes) {
    filtroUGEPlanoDeGestao.contexto = contexto ? contexto : '#filtro-ug-topo';
    filtroUGEPlanoDeGestao.loadComboUnidadeGerencial(onSelectUG);
    filtroUGEPlanoDeGestao.loadDropdownPlanoDeGestao(onSelectPlaGes);
    filtroUGEPlanoDeGestao.configurarToggle();
    $("[rel=tooltip]", filtroUGEPlanoDeGestao.contexto).tooltip({
      placement: 'bottom'
    });
  };

  filtroUGEPlanoDeGestao.loadDropdownPlanoDeGestao = function(reload) {
    return filtroUGEPlanoDeGestao.dropdownPlanoDeGestao = new dropdownPlanoDeGestao(filtroUGEPlanoDeGestao.contexto, {
      aoSelecionar: function(idDoPlanoDeGestao) {
        if (reload) {
          return reload(idDoPlanoDeGestao);
        }
      }
    });
  };

  filtroUGEPlanoDeGestao.loadComboUnidadeGerencial = function(reload) {
    var onSelect, parametros;
    onSelect = function(inputCombo) {
      var labelUG;
      labelUG = $("#labelFiltroUG", this.contexto);
      $("#divFiltroUG", this.contexto).fadeOut({
        complete: function() {
          return setTimeout(function() {
            labelUG.children().text($('#NomeDaUnidade', this.contexto).val());
            return labelUG.show();
          }, 10);
        }
      });
      $("#divFiltroPlaGes", this.contexto).fadeOut({
        complete: function() {
          return $("#labelFiltroPlanoGestao", this.contexto).text($('#ExercicioDoPlanoDeGestao', this.contexto).val()).show();
        }
      });
      if (reload) {
        return reload(inputCombo.val());
      }
    };
    parametros = {
      idDoPlanoDeGestao: function() {
        return $("#IdDoPlanoDeGestao", filtroUGEPlanoDeGestao.contexto).val();
      }
    };
    filtroUGEPlanoDeGestao.comboUnidade = setCombo(filtroUGEPlanoDeGestao.contexto, '#NomeDaUnidade', onSelect, parametros, null, null, null, null, true);
    filtroUGEPlanoDeGestao.comboUnidade.setSelectOnTypeArrow(false);
    return filtroUGEPlanoDeGestao.treeview = new treeviewUnidades(filtroUGEPlanoDeGestao.contexto, {
      unidadeSelecionada: $('#IdDaUnidade', filtroUGEPlanoDeGestao.contexto).val(),
      aoSelecionar: function(unidade) {
        if (reload) {
          return reload(unidade.id);
        }
      }
    });
  };

  filtroUGEPlanoDeGestao.configurarToggle = function() {
    $("#labelFiltroUG", filtroUGEPlanoDeGestao.contexto).click(function(e) {
      e.stopPropagation();
      return filtroUGEPlanoDeGestao.toggleUG(true);
    });
    $("#labelFiltroPlanoGestao", filtroUGEPlanoDeGestao.contexto).click(function(e) {
      e.stopPropagation();
      return filtroUGEPlanoDeGestao.togglePlages(true);
    });
    $("#divFiltroPlaGes, #divFiltroUG", filtroUGEPlanoDeGestao.contexto).click(function(e) {
      return e.stopPropagation();
    });
    return $('body').click(function(e) {
      return filtroUGEPlanoDeGestao.toggleFiltroUGPlages(false);
    });
  };

  filtroUGEPlanoDeGestao.toggleFiltroUGPlages = function(exibir) {
    filtroUGEPlanoDeGestao.toggleUG(exibir);
    return filtroUGEPlanoDeGestao.togglePlages(exibir);
  };

  filtroUGEPlanoDeGestao.toggleUG = function(exibir) {
    if (exibir) {
      $("#labelFiltroUG", this.contexto).hide();
      $("#divFiltroPlaGes", this.contexto).fadeOut({
        complete: function() {
          return $("#labelFiltroPlanoGestao", this.contexto).show();
        }
      });
      $("#divFiltroUG", this.contexto).fadeIn({
        complete: function() {
          return $('#NomeDaUnidade', this.contexto).focus();
        }
      });
      return this.treeview.abrir();
    } else {
      $("#divFiltroUG", this.contexto).fadeOut({
        complete: function() {
          return $("#labelFiltroUG", this.contexto).show();
        }
      });
      return this.treeview.fechar();
    }
  };

  filtroUGEPlanoDeGestao.togglePlages = function(exibir) {
    if (exibir) {
      $("#labelFiltroPlanoGestao", this.contexto).hide();
      $("#divFiltroUG", this.contexto).fadeOut({
        complete: function() {
          return $("#labelFiltroUG", this.contexto).show();
        }
      });
      $("#divFiltroPlaGes", this.contexto).fadeIn();
      return this.dropdownPlanoDeGestao.abrir();
    } else {
      $("#divFiltroPlaGes", this.contexto).fadeOut({
        complete: function() {
          return $("#labelFiltroPlanoGestao", this.contexto).show();
        }
      });
      return this.dropdownPlanoDeGestao.fechar();
    }
  };

  return filtroUGEPlanoDeGestao;

})();
