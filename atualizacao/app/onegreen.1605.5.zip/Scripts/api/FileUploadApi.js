﻿var FileUpload;

FileUpload = (function() {
  function FileUpload() {}

  FileUpload.elements = {};

  FileUpload.getElements = function(context) {
    if (!context || context === "") {
      context = '#upload-container';
    }
    if (!this.elements.lenght) {
      this.elements.context = context;
      this.elements.uploadContainer = $('#upload-container');
      this.elements.inputFile = $('#file-upload', context);
      this.elements.inputLabel = $('#file-label', context);
      this.elements.filesContainer = $('#js-upload-list');
      this.elements.fileSelectCallback = this.elements.inputFile.data('file-select-callback');
      this.elements.fileUploadCallback = this.elements.inputFile.data('file-upload-callback');
      this.elements.uploadOnSelect = this.elements.inputFile.data('upload-on-select');
      this.elements.unobtrusiveUpload = this.elements.inputFile.data('unobtrusive-upload');
      this.elements.dragAndDrop = this.elements.inputFile.data('drag-and-drop');
      this.elements.entityType = this.elements.inputFile.data('entity');
      this.elements.setHidden = this.elements.inputFile.data('set-hidden');
      this.elements.setDescription = this.elements.inputFile.data('set-description');
      this.elements.useTemp = this.elements.inputFile.data('use-temp');
      this.elements.url = this.elements.inputFile.data('url-upload');
      return this.elements;
    } else {
      return this.elements;
    }
  };

  FileUpload.fileinputChange = function() {
    var $element, context, fileName, newFile, removeUniqueFile;
    context = FileUpload.elements.context;
    if (FileUpload.elements.inputFile.val() !== '') {
      fileName = FileUpload.elements.inputFile.val().split('/').pop().split('\\').pop();
    } else {
      fileName = FileUpload.elements.inputFile.files[0].name;
    }
    newFile = "<div id='uniqueFile' class='upload-list-item flex backgroundPadrao pam prs mbm'> <span class='flex-1 prm etc'>" + fileName + "</span> <a id='removeUniqueFile' class='mostrar center cursor-pointer flex align-v-center no-text-decoration'> <i class='fa fa-close'></i> </a> </div>";
    $element = $(newFile).prependTo('#js-upload-list');
    $element.addClass('ready');
    $('.upload-drag-drop', context).addClass('inactive');
    removeUniqueFile = $('#removeUniqueFile', '#uniqueFile');
    removeUniqueFile.click(function() {
      FileUpload.elements.filesContainer.empty();
      $('.upload-drag-drop', context).removeClass('inactive');
      FileUpload.elements.inputFile.val("");
      $("#" + FileUpload.elements.setHidden, context).val('');
      $("#" + FileUpload.elements.setDescription, context).val('');
      return FileUpload.elements.uploadContainer.removeClass('dragging');
    });
    if (FileUpload.elements.setDescription) {
      $("#" + FileUpload.elements.setDescription, context).val(fileName.replace(/\.[^.]+$/, ''));
    }
    if (FileUpload.elements.setHidden) {
      $("#" + FileUpload.elements.setHidden, context).val(fileName);
    }
    if (!FileUpload.elements.uploadOnSelect && FileUpload.elements.fileSelectCallback) {
      eval(FileUpload.elements.fileSelectCallback);
    }
    if (!FileUpload.elements.unobtrusiveUpload) {
      return FileUpload.executeUpload(FileUpload.elements.url, FileUpload.elements.entityType, FileUpload.elements.inputFile, FileUpload.elements.fileUploadCallback, FileUpload.elements.setHidden, FileUpload.elements.useTemp);
    }
  };

  FileUpload.configure = function(context) {
    $('#upload-container').click(function() {
      return $('#file-upload').click();
    });
    return this.configureOnSelect(context);
  };

  FileUpload.configureOnSelect = function(context) {
    FileUpload.getElements(context);
    FileUpload.elements.uploadContainer.on('dragenter', function(e) {
      e.stopPropagation();
      return e.preventDefault();
    });
    FileUpload.elements.uploadContainer.on('dragover', function(e) {
      e.stopPropagation();
      e.preventDefault();
      return FileUpload.elements.uploadContainer.addClass('dragging');
    });
    FileUpload.elements.uploadContainer.on('dragleave', function(e) {
      e.stopPropagation();
      e.preventDefault();
      return FileUpload.elements.uploadContainer.removeClass('dragging');
    });
    FileUpload.elements.uploadContainer.on('drop', function(e) {
      var name;
      e.preventDefault();
      name = e.originalEvent.dataTransfer.files[0].name;
      FileUpload.elements.inputFile.files = e.originalEvent.dataTransfer.files;
      return FileUpload.fileinputChange();
    });
    if (!FileUpload.elements.unobtrusiveUpload) {
      FileUpload.elements.url = FileUpload.elements.inputFile.data('url');
    }
    return FileUpload.elements.inputFile.change(function() {
      return FileUpload.fileinputChange();
    });
  };

  FileUpload.upload = function(callback) {
    var fileUploadCallback;
    if (!callback) {
      fileUploadCallback = FileUpload.elements.inputFile.data('file-upload-callback');
    } else {
      fileUploadCallback = callback;
    }
    FileUpload.elements.entityType = FileUpload.elements.inputFile.data('entity');
    return this.executeUpload(FileUpload.elements.url, FileUpload.elements.entityType, FileUpload.elements.inputFile, fileUploadCallback, FileUpload.elements.setHidden);
  };

  FileUpload.executeUpload = function(url, entityType, inputFile, callback, setHidden, useTemp) {
    var files, formdata, i;
    inputFile = inputFile[0];
    formdata = new FormData();
    formdata.append('folder', entityType);
    if (useTemp) {
      formdata.append('useTemp', useTemp);
    }
    files = FileUpload.getFiles();
    if (files) {
      i = 0;
      while (i < files.length) {
        formdata.append(files[i].name, files[i]);
        i++;
      }
    }
    return this.uploadRequest(url, formdata, callback, setHidden);
  };

  FileUpload.uploadRequest = function(urlUpload, formdata, callback, setHidden) {
    return $.ajax({
      url: urlUpload,
      data: formdata,
      contentType: false,
      processData: false,
      type: 'POST',
      success: function(data) {
        if (data.success) {
          $("#" + setHidden).val(data.data.fileName);
          if (callback) {
            return callback(data.data.fileName);
          }
        }
      }
    });
  };

  FileUpload.getFormData = function(form) {
    var files, formInputs, formdata, i, input, inputKey, inputValue, j, len;
    formdata = new FormData();
    formInputs = $(form).find('input[type!=file]');
    for (inputValue = j = 0, len = formInputs.length; j < len; inputValue = ++j) {
      inputKey = formInputs[inputValue];
      input = $(inputKey);
      formdata.append(input.attr('name'), input.attr('value'));
    }
    if (FileUpload.elements.inputFile) {
      files = FileUpload.getFiles();
    } else {
      files = $(form).find('input[type=file]')[0].files;
    }
    if (files) {
      i = 0;
      while (i < files.length) {
        formdata.append(files[i].name, files[i]);
        i++;
      }
    } else {
      $("#" + FileUpload.elements.setHidden).val('');
      $("#" + FileUpload.elements.setDescription).val('');
    }
    return formdata;
  };

  FileUpload.getFiles = function() {
    var files;
    files = null;
    if (FileUpload.elements.inputFile.val() !== '') {
      files = FileUpload.elements.inputFile[0].files;
    } else {
      files = FileUpload.elements.inputFile.files;
    }
    return files;
  };

  return FileUpload;

})();
