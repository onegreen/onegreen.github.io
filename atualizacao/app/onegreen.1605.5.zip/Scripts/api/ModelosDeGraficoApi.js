﻿var GraficoDeIndicador,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.ModelosDeGrafico || (this.ModelosDeGrafico = {});

GraficoDeIndicador = (function() {
  function GraficoDeIndicador(container1, callbackAfterPrint) {
    this.container = container1;
    this.callbackAfterPrint = callbackAfterPrint;
    this.configurarImpressaoDoGrafico = bind(this.configurarImpressaoDoGrafico, this);
    this.get = bind(this.get, this);
    this.selecionarModelo = bind(this.selecionarModelo, this);
    this.selecionarForma = bind(this.selecionarForma, this);
    this.zoomNoGrafico = bind(this.zoomNoGrafico, this);
    this.imprimirGrafico = bind(this.imprimirGrafico, this);
    this.aoCarregarViewComControles = bind(this.aoCarregarViewComControles, this);
    this.buscarDados = bind(this.buscarDados, this);
    this.loadViewComControles = bind(this.loadViewComControles, this);
    this.loadViewSemControles = bind(this.loadViewSemControles, this);
    this.actionParaOTipo = bind(this.actionParaOTipo, this);
    this.buildFancyBox = bind(this.buildFancyBox, this);
    this.setTitle = bind(this.setTitle, this);
    this.renderOnWindow = bind(this.renderOnWindow, this);
    this.removerTodosControles = bind(this.removerTodosControles, this);
    this.renderWithControls = bind(this.renderWithControls, this);
    this.renderWithoutControls = bind(this.renderWithoutControls, this);
    this.render = bind(this.render, this);
    this.Configuracao = bind(this.Configuracao, this);
    this.setData = bind(this.setData, this);
    this.setBase = bind(this.setBase, this);
    this.container = $(this.container);
    this.series;
    this.configuracao;
    this.comControles;
  }

  GraficoDeIndicador.prototype.setBase = function(idIndicador, IdDoIndicadorBase, IdDoItem1, IdDoItem2, IdDoItem3, IdDoItem4, IdDoItem5, IdDoItem6, frequencia, idModelo, formaDeVisualizacao, tipoDeDesdobramento, ocorrencia, ordem, virtual, destacarOcorrencia, idDoPlanoDeGestao, idDaUnidade) {
    this.idIndicador = idIndicador;
    this.IdDoIndicadorBase = IdDoIndicadorBase;
    this.IdDoItem1 = IdDoItem1;
    this.IdDoItem2 = IdDoItem2;
    this.IdDoItem3 = IdDoItem3;
    this.IdDoItem4 = IdDoItem4;
    this.IdDoItem5 = IdDoItem5;
    this.IdDoItem6 = IdDoItem6;
    this.frequencia = frequencia;
    this.idModelo = idModelo;
    this.formaDeVisualizacao = formaDeVisualizacao;
    this.tipoDeDesdobramento = tipoDeDesdobramento;
    this.ocorrencia = ocorrencia;
    this.ordem = ordem;
    this.virtual = virtual;
    this.destacarOcorrencia = destacarOcorrencia;
    this.idDoPlanoDeGestao = idDoPlanoDeGestao;
    this.idDaUnidade = idDaUnidade;
    this.base = {
      idIndicador: this.idIndicador,
      idDoIndicadorBase: this.IdDoIndicadorBase,
      idDoItem1: this.IdDoItem1,
      idDoItem2: this.IdDoItem2,
      idDoItem3: this.IdDoItem3,
      idDoItem4: this.IdDoItem4,
      idDoItem5: this.IdDoItem5,
      idDoItem6: this.IdDoItem6,
      frequencia: this.frequencia,
      ocorrencia: this.ocorrencia,
      idModelo: this.idModelo,
      ordem: this.ordem,
      formaDeVisualizacao: this.formaDeVisualizacao,
      tipoDeDesdobramento: this.tipoDeDesdobramento,
      virtual: this.virtual,
      destacarOcorrencia: this.destacarOcorrencia,
      idDoPlanoDeGestao: this.idDoPlanoDeGestao,
      idDaUnidade: this.idDaUnidade
    };
    return this.buscarDados();
  };

  GraficoDeIndicador.prototype.setData = function(base, grafico, series) {
    this.base = $.extend({}, base);
    this.configuracao = $.extend({}, grafico);
    this.series = series;
    return this.withControls = true;
  };

  GraficoDeIndicador.prototype.Configuracao = function(configuracao) {
    return this.configuracao = configuracao;
  };

  GraficoDeIndicador.prototype.render = function(withControls) {
    this.withControls = withControls;
    if (withControls) {
      this.loadViewComControles();
    } else {
      this.loadViewSemControles();
    }
    if (this.configuracao) {
      if (this.series && this.series.length > 0) {
        return ModelosDeGrafico.api.build(this.get('.js-grafico-container'), this.configuracao, this.series);
      } else {
        this.get('.js-grafico-container').height(50);
        return this.get('.js-grafico-container').html(resourceJsonCommom.EsteGraficoNaoPossuiSecoesPortantoNaoPodeSerExibido);
      }
    } else {
      this.get('.js-grafico-container').height(50);
      return this.get('.js-grafico-container').html(resourceJsonCommom.NaoExisteModeloDeGraficoDisponivelParaEsteIndicador);
    }
  };

  GraficoDeIndicador.prototype.renderWithoutControls = function() {
    return this.render(false);
  };

  GraficoDeIndicador.prototype.renderWithControls = function() {
    return this.render(true);
  };

  GraficoDeIndicador.prototype.removerTodosControles = function() {
    return this.get('.controles-grafico').hide();
  };

  GraficoDeIndicador.prototype.renderOnWindow = function(withControls) {
    this.buildFancyBox();
    this.withControls = withControls;
    if (withControls) {
      this.loadViewComControles();
    } else {
      this.loadViewSemControles();
    }
    this.get('#botao-zoom-grafico').remove();
    return ModelosDeGrafico.api.build(this.get('.js-grafico-container'), this.configuracao, this.series);
  };

  GraficoDeIndicador.prototype.setTitle = function() {
    if (this.configuracao) {
      return $('[data-nomemodelo]', this.container).html(this.configuracao.titulo);
    }
  };

  GraficoDeIndicador.prototype.buildFancyBox = function() {
    $.facebox({
      div: '#zoom-grafico-container',
      fullscreen: true
    });
    this.container = $('#facebox .content');
    return this.window = true;
  };

  GraficoDeIndicador.prototype.actionParaOTipo = function() {
    if (this.base.virtual) {
      return $as.Performance.Graficos.GraficoDoIndicadorVirtual;
    } else {
      switch (this.base.tipoDeDesdobramento) {
        case 'Hierarquico':
          return $as.Performance.Graficos.GraficoDoIndicadorComparativoHierarquico;
        case 'Dimensoes':
          return $as.Performance.Graficos.GraficoDoIndicadorComparativoDimensoes;
        default:
          return $as.Performance.Graficos.GraficoDoIndicadorEvolucao;
      }
    }
  };

  GraficoDeIndicador.prototype.loadViewSemControles = function() {
    return $as.Performance.Graficos.GraficosSemControles.get(this.base, {
      async: false
    }).done((function(_this) {
      return function(html) {
        $(_this.container).html(html);
        _this.aoCarregarViewComControles();
        if (_this.window) {
          _this.get('#botao-zoom-grafico').remove();
          return _this.get('.js-grafico-container').css({
            width: window.innerWidth * 0.8,
            height: window.innerHeight * 0.8
          });
        }
      };
    })(this));
  };

  GraficoDeIndicador.prototype.loadViewComControles = function() {
    return $as.Performance.Graficos.GraficosComControles.get(this.base, {
      async: false
    }).done((function(_this) {
      return function(html) {
        $(_this.container).html(html);
        _this.aoCarregarViewComControles();
        if (_this.window) {
          _this.get('#botao-zoom-grafico').remove();
          return _this.get('.js-grafico-container').css({
            width: window.innerWidth * 0.8,
            height: window.innerHeight * 0.8
          });
        }
      };
    })(this));
  };

  GraficoDeIndicador.prototype.buscarDados = function() {
    return this.actionParaOTipo().get(this.base, {
      async: false
    }).done((function(_this) {
      return function(configuracao) {
        if (configuracao) {
          _this.configuracao = ModelosDeGrafico.api.getConfig(configuracao.grafico);
          return _this.series = configuracao.series;
        }
      };
    })(this));
  };

  GraficoDeIndicador.prototype.aoCarregarViewComControles = function() {
    this.get('[rel=tooltip]').tooltip();
    this.get('.js-selecao-modelo [data-id]').unbind('click').click(this.selecionarModelo);
    if (this.series && this.series.length > 0) {
      this.get('#selecao-forma').unbind('change').change(this.selecionarForma);
      this.get('#botao-zoom-grafico').unbind('click').click(this.zoomNoGrafico);
      this.get('#imprimirGrafico').unbind('click').click(this.imprimirGrafico);
    } else {
      this.get('.js-selecao-forma label').hide();
      this.get('#botao-zoom-grafico').hide();
      this.get('#imprimirGrafico').hide();
    }
    if (this.zoom) {
      return this.zoom.aoCarregarViewComControles();
    }
  };

  GraficoDeIndicador.prototype.imprimirGrafico = function() {
    return $as.Performance.Graficos.GerarPDF.post($('.js-form-imprimir', this.container).serialize()).done((function(_this) {
      return function(data) {
        var $span, chart, chartHtml, color, el, i, img, j, k, legendaCustomizada, len, modal, ref, ref1, results, serie, text;
        modal = $('#main-modal');
        modal.empty().html(data);
        chart = ModelosDeGrafico.api.build($('.js-svg-grafico', modal), _this.configuracao, _this.series);
        chartHtml = $('.highcharts-container', modal);
        chartHtml.find('.highcharts-tooltip').remove();
        legendaCustomizada = chartHtml.find('div.highcharts-legend-item');
        for (i = j = 0, ref = legendaCustomizada.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
          $span = $(legendaCustomizada[i]).find('span');
          color = $span.css('color');
          text = $span.text();
          img = $span.find('img');
          if (img.length) {
            $($('g.highcharts-legend-item')[i]).children().attr('visibility', 'visible');
          }
          el = "<text x='21' y='15' style='color:" + color + ";font-size:12px;font-weight:normal;cursor:pointer;fill:" + color + ";' text-anchor='start' zIndex='2'>" + text + "</text>";
          $($('g.highcharts-legend-item')[i]).append(el);
          chartHtml.find('div.highcharts-legend').remove();
        }
        $('form', modal).submit(function() {
          return $('.js-input-svg', modal).val(chartHtml.html());
        });
        ref1 = chart.series;
        results = [];
        for (k = 0, len = ref1.length; k < len; k++) {
          serie = ref1[k];
          results.push(serie.show());
        }
        return results;
      };
    })(this));
  };

  GraficoDeIndicador.prototype.zoomNoGrafico = function() {
    this.zoom = new GraficoDeIndicador('#facebox .content');
    this.zoom.setData(this.base, this.configuracao, this.series);
    this.zoom.renderOnWindow(this.withControls);
    return this.zoom.setTitle();
  };

  GraficoDeIndicador.prototype.selecionarForma = function(event) {
    var eYTD, forma;
    eYTD = this.get('#selecao-forma').is(":checked");
    if (eYTD) {
      forma = this.get('#FormaDeVisualizacao-Acumulado').val();
    } else {
      forma = this.get('#FormaDeVisualizacao-Apurado').val();
    }
    this.base.formaDeVisualizacao = forma;
    this.buscarDados();
    this.render(this.withControls);
    return this.setTitle();
  };

  GraficoDeIndicador.prototype.selecionarModelo = function(event) {
    var id, link, nome;
    link = $(event.currentTarget);
    id = link.data('id');
    nome = link.text();
    if (id) {
      this.get('#TipoDeDesdobramento').val(link.data('tipo'));
      this.get('#Ordem').val(link.data('ordem'));
      this.base.ordem = link.data('ordem');
      this.base.tipoDeDesdobramento = link.data('tipo');
      this.base.idModelo = id;
      this.buscarDados();
      this.renderWithControls();
      return this.setTitle();
    }
  };

  GraficoDeIndicador.prototype.get = function(selector) {
    return $(selector, this.container);
  };

  GraficoDeIndicador.prototype.configurarImpressaoDoGrafico = function() {
    return $('#imprimirGrafico').click((function(_this) {
      return function() {
        return _this.imprimirGrafico();
      };
    })(this));
  };

  GraficoDeIndicador.alterarFormaDeExibicao = function(elemento) {
    if ($(elemento).hasClass('js-sem-controle') && $(elemento).closest('#facebox').length === 0) {
      return $('#selecao-forma', elemento).click();
    }
  };

  return GraficoDeIndicador;

})();

ModelosDeGrafico.api = (function() {
  function api() {}

  api.backgroundColors = {
    Default: "default",
    Dark: "dark",
    Texture: "texture"
  };

  api.build = function(container, config, series) {
    var chart, fontSize, hasAxiY1, hasAxiY2, hasAxisY1, hasAxisY2, i, j, k, l, legendAlign, legendColor, legendLayout, legendVAlign, m, pointFormat, ref, ref1, ref2, ref3, shared;
    if (config == null) {
      return;
    }
    if (config.bgColor === 'default') {
      Highcharts.setOptions(window.defaultTheme);
      window.defaultTheme.setBackGround();
    } else if (config.bgColor === 'dark') {
      Highcharts.setOptions(window.darkTheme);
      window.darkTheme.setBackGround();
    } else if (config.bgColor === 'texture') {
      Highcharts.setOptions(window.textureTheme);
      window.textureTheme.setBackGround();
    } else if (config.bgColor === 'transparent') {
      Highcharts.setOptions(window.transparentTheme);
      window.transparentTheme.setBackGround();
    } else {
      Highcharts.setOptions(window.defaultTheme);
      window.defaultTheme.setBackGround();
    }
    hasAxiY1 = false;
    hasAxiY2 = false;
    for (i = j = 0, ref = series.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
      if (series[i].yAxis === 0) {
        hasAxisY1 = true;
      }
      if (series[i].yAxis === 1) {
        hasAxisY2 = true;
      }
    }
    if (hasAxisY2 && !hasAxisY1) {
      for (i = k = 0, ref1 = series.length; 0 <= ref1 ? k < ref1 : k > ref1; i = 0 <= ref1 ? ++k : --k) {
        if (series[i].yAxis === 1) {
          series[i].yAxis = 0;
        }
      }
    }
    config.yAxis = [];
    fontSize = config.zoom ? '16px' : '12px';
    legendLayout = config.abaixo ? 'horizontal' : 'vertical';
    legendAlign = config.abaixo ? 'center' : 'right';
    legendVAlign = config.abaixo ? 'bottom' : 'middle';
    legendColor = config.bgColor === api.backgroundColors.Dark ? '#ffffff' : '#000001';
    shared = true;
    pointFormat = '<span style="color: {series.color}">{point.descricao}</span></br>';
    if (config.tooltipNotShared) {
      shared = false;
    }
    if (hasAxisY1) {
      config.yAxis.push({
        title: {
          text: config.nomeEixoY1,
          style: {
            fontSize: fontSize
          }
        },
        gridLineWidth: config.showGriX,
        labels: {
          style: {
            fontSize: fontSize
          }
        }
      });
    }
    if (hasAxisY2) {
      config.yAxis.push({
        opposite: true,
        title: {
          text: config.nomeEixoY2,
          style: {
            fontSize: fontSize
          }
        },
        gridLineWidth: config.showGriX,
        labels: {
          style: {
            fontSize: fontSize
          }
        }
      });
    }
    if ($('html').attr('lang') === 'pt') {
      Highcharts.setOptions({
        lang: {
          decimalPoint: ',',
          thousandsSep: '.'
        }
      });
    } else {
      Highcharts.setOptions({
        lang: {
          decimalPoint: '.',
          thousandsSep: ','
        }
      });
    }
    config.xAxis.labels = {
      style: {
        fontSize: fontSize
      }
    };
    chart = new Highcharts.Chart({
      chart: {
        renderTo: $(container)[0],
        type: config.type,
        borderColor: '#ddd'
      },
      title: {
        text: ' ',
        x: -20,
        style: {
          fontSize: fontSize
        }
      },
      subtitle: {
        text: config.subtitulo,
        x: -20
      },
      xAxis: config.xAxis,
      yAxis: config.yAxis,
      tooltip: {
        shared: shared,
        useHTML: true,
        pointFormat: pointFormat,
        style: {
          fontSize: fontSize
        }
      },
      legend: {
        layout: legendLayout,
        align: legendAlign,
        verticalAlign: legendVAlign,
        useHTML: config.temFarol,
        labelFormatter: function() {
          var legenda;
          legenda = this.name;
          if (this.options.isFarol) {
            legenda = '<img src="' + CompleteHostAdress + '/Content/Image/farolGrafico.png" heigth="15px" width="15px"></img> ' + this.name;
          }
          return legenda;
        },
        itemStyle: {
          fontSize: fontSize,
          color: legendColor,
          fontWeight: 'normal'
        }
      },
      credits: {
        enabled: false
      },
      plotOptions: {
        series: {
          animation: {
            duration: 1500
          },
          marker: {
            states: {
              hover: {
                enabled: true,
                lineWidth: 0
              }
            }
          },
          stacking: config.stacking
        },
        area: {
          stacking: config.stacking,
          lineWidth: 1,
          marker: {
            lineWidth: 1
          }
        },
        pie: {
          allowPointSelect: true,
          cursor: 'pointer',
          dataLabels: {
            enabled: false
          },
          showInLegend: true
        }
      },
      events: {
        afterPrint: api.callbackAfterPrint
      }
    });
    for (i = l = 0, ref2 = series.length; 0 <= ref2 ? l < ref2 : l > ref2; i = 0 <= ref2 ? ++l : --l) {
      chart.addSeries(series[i]);
    }
    if (hasAxisY1 && (chart.yAxis[0] != null)) {
      chart.yAxis[0].setExtremes(config.y1minValue, null);
    }
    if (hasAxisY2 && (chart.yAxis[1] != null)) {
      chart.yAxis[1].setExtremes(config.y2minValue, null);
    }
    if (hasAxisY2 && !hasAxisY1) {
      for (i = m = 0, ref3 = series.length; 0 <= ref3 ? m < ref3 : m > ref3; i = 0 <= ref3 ? ++m : --m) {
        series[i].yAxis = 1;
      }
    }
    $(chart.series).each(function(i, serie) {
      if (serie.options.isFarol && (serie.legendSymbol != null)) {
        return serie.legendSymbol.hide();
      }
    });
    return chart;
  };

  api.getConfig = function(options) {
    var config;
    config = {};
    if (options.plotBand == null) {
      options.plotBand = {};
    }
    config.titulo = options.titulo;
    config.bgColor = options.bgColor;
    config.unit = options.unit;
    config.nomeEixoY1 = options.nomeEixoY1;
    config.nomeEixoY2 = options.nomeEixoY2;
    config.showGriX = options.showGriX;
    config.stacking = options.stacking;
    config.type = options.type;
    config.abaixo = options.legendaAbaixo === 'Abaixo';
    config.zoom = options.zoom;
    config.frequencia = options.frequencia;
    config.xAxis = {
      type: 'category',
      title: {
        text: options.nomeEixoY
      },
      plotBands: [
        {
          color: options.plotBand.color,
          from: options.plotBand.from,
          to: options.plotBand.to
        }
      ],
      gridLineWidth: options.showGriY
    };
    config.y1minValue = options.y1minValue;
    config.y2minValue = options.y2minValue;
    config.tooltipNotShared = options.tooltipNotShared;
    config.temFarol = options.temFarol;
    return config;
  };

  return api;

})();
