﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.indicadorPorObjetoController = (function() {
  function indicadorPorObjetoController(contexto, opcoes) {
    var idUnidade;
    this.contexto = contexto;
    this.opcoes = opcoes;
    this.adicionarNovoIndicadorComFiltro = bind(this.adicionarNovoIndicadorComFiltro, this);
    this.carregarComboDeIndicadores = bind(this.carregarComboDeIndicadores, this);
    this.loadComboIndicador = bind(this.loadComboIndicador, this);
    this.loadComboUnidadeGerencial = bind(this.loadComboUnidadeGerencial, this);
    $(this.contexto).window();
    this.loadComboUnidadeGerencial();
    $("input[alt=integer]", this.contexto).setMask();
    idUnidade = $('#UnidadeGerencial_Id', "#indicadorporobjeto-modal").val();
    if (idUnidade) {
      this.carregarComboDeIndicadores(idUnidade);
    }
  }

  indicadorPorObjetoController.prototype.loadComboUnidadeGerencial = function() {
    var aoSelecionar;
    aoSelecionar = (function(_this) {
      return function(input) {
        $("#Indicador_Id", _this.contexto).val('');
        $("#Indicador_Nome", _this.contexto).val('');
        return _this.loadComboIndicador($(input).val());
      };
    })(this);
    return setCombo(this.contexto, '#UnidadeGerencial_SiglaAtual', aoSelecionar);
  };

  indicadorPorObjetoController.prototype.loadComboIndicador = function(idUnidadeGerencial, idPlanoGestao) {
    return this.carregarComboDeIndicadores(idUnidadeGerencial);
  };

  indicadorPorObjetoController.prototype.carregarComboDeIndicadores = function(idUnidadeGerencial) {
    return Results.api.setComboIndicador(this.contexto, '#Indicador_Nome', null, {
      idUnidadeGerencial: idUnidadeGerencial
    });
  };

  indicadorPorObjetoController.prototype.reload = function() {
    return indicadorPorObjetoController.reload();
  };

  indicadorPorObjetoController.reload = function(idDoPai) {
    return $as.Performance.IndicadoresPorObjeto.Index.get({
      idDoPai: idDoPai || $("#MapeamentoDoObjeto_Id", "#indicadorporobjeto-modal").val()
    }).success(function(data) {
      return $("#indicadores-panel").html(data);
    });
  };

  indicadorPorObjetoController.prototype.vincularIndicador = function(formaDeSalvar) {
    var form;
    $('#btn-Cancelar', '#indicadorporobjeto-modal').click();
    form = $('#formVincularIndicador');
    return $as.Performance.IndicadoresPorObjeto.Create.post(form.serialize()).done((function(_this) {
      return function(data) {
        if (data.success) {
          _this.reload(data.data.idDoMApeamento);
          if (formaDeSalvar === 'SalvarEAdicionarNovo') {
            return _this.adicionarNovoIndicadorComFiltro(data.data);
          }
        } else {
          return $('#modal-indicadores-objetivo-estrategico').html(data);
        }
      };
    })(this));
  };

  indicadorPorObjetoController.prototype.adicionarNovoIndicadorComFiltro = function(filtro) {
    return $as.Performance.IndicadoresPorObjeto.Create.get({
      idDoPai: filtro.idDoMapeamento
    }).done((function(_this) {
      return function(data) {
        var $modal;
        $modal = $(data);
        $modal.find('#UnidadeGerencial_Id').val(filtro.idDaUnidadeGerencial);
        $modal.find('#UnidadeGerencial_SiglaAtual').val(filtro.nomeDaUnidadeGerencial);
        return $('#modal-indicadores-objetivo-estrategico').html($modal);
      };
    })(this));
  };

  return indicadorPorObjetoController;

})();
