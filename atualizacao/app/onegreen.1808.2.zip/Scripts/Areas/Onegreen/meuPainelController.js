﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.meuPainelController = (function(superClass) {
  extend(meuPainelController, superClass);

  function meuPainelController(options, recursos) {
    this.options = options;
    this.recursos = recursos;
    this.carregarTela = bind(this.carregarTela, this);
    this.configurarReprogramacoesToggle = bind(this.configurarReprogramacoesToggle, this);
    this.atualizarFiltro = bind(this.atualizarFiltro, this);
    this.configurarVoltar = bind(this.configurarVoltar, this);
    this.carregarReprogramacoesPendentes = bind(this.carregarReprogramacoesPendentes, this);
    this.loadEmpreendimentos = bind(this.loadEmpreendimentos, this);
    this.loadSolicitacoes = bind(this.loadSolicitacoes, this);
    this.carregarModalStatusCondicionantes = bind(this.carregarModalStatusCondicionantes, this);
    this.carregarModalStatusAcoes = bind(this.carregarModalStatusAcoes, this);
    this.configurarFiltroDeTarefas = bind(this.configurarFiltroDeTarefas, this);
    this.loadTarefas = bind(this.loadTarefas, this);
    this.loadFluxoEmpreendimento = bind(this.loadFluxoEmpreendimento, this);
    this.loadComboUsuarios = bind(this.loadComboUsuarios, this);
    meuPainelController.__super__.constructor.call(this, this.options, this.recursos);
    this.configuraAplicarFiltro();
    this.atualizarFiltro();
    if (this.options.setComboUsuarios) {
      this.loadComboUsuarios();
    }
    this.carregarTela();
    this.configurarVoltar();
  }

  meuPainelController.prototype.loadComboUsuarios = function() {
    return $('#NomeDoUsuario').autocompleter(this.options.urlComboUsuarios, {
      loadOnDemand: true,
      elementToClick: "#NomeDoUsuarioBtn",
      keyElement: "#IdDoUsuario"
    });
  };

  meuPainelController.prototype.loadFluxoEmpreendimento = function() {
    $('#fluxo-empreendimento-container').html(this.ajaxLoader);
    return $as.Onegreen.Empreendimentos.FluxoEmpreendimento.get({
      idUnidade: FiltroPainel.IdUnidadeGerencial,
      incluirSubordinadas: FiltroPainel.IncluirSubordinadas,
      idUsuario: FiltroPainel.IdDoUsuario
    }).success((function(_this) {
      return function(data) {
        $('#fluxo-empreendimento-container').html(data);
        return $("[rel=tooltip]").tooltip();
      };
    })(this));
  };

  meuPainelController.prototype.loadTarefas = function() {
    $('#tarefas-grafico-container, #tarefas-tabela-container').html(this.ajaxLoader);
    return $as.Onegreen.AtividadesDaLicenca.TarefasPeloResponsavel.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#tarefas-grafico-container").html($(data).filter("#grafico-tarefas"));
        $("#tarefas-tabela-container").html($(data).filter("#tabela-tarefas"));
        $("[rel=tooltip]").tooltip();
        $("[rel=popover]").popover({
          placement: "top"
        });
        $("[id^=Percentual].btn-warning").prevAll().addClass("btn-warning");
        return setTimeout(function() {
          Atividades.api.boot();
          return _this.configurarFiltroDeTarefas();
        }, 500);
      };
    })(this));
  };

  meuPainelController.prototype.configurarFiltroDeTarefas = function() {
    $("#tarefas-que-designei", "#tarefas-tabela-container").unbind("click").bind("click", (function(_this) {
      return function(evento) {
        $("label", "#tarefas-tabela-container").removeClass("btn-warning");
        $(evento.delegateTarget).addClass("btn-warning");
        return $("a[data-idusuario]", "#tarefas-tabela-container").each(function() {
          if ($( this ).data("idusuario") === FiltroPainel.IdDoUsuario) {
            return $( this ).parents("li").hide();
          } else {
            return $( this ).parents("li").show();
          }
        });
      };
    })(this));
    $("#tarefas-ambos", "#tarefas-tabela-container").unbind("click").bind("click", (function(_this) {
      return function(evento) {
        $("label", "#tarefas-tabela-container").removeClass("btn-warning");
        $(evento.delegateTarget).addClass("btn-warning");
        return $("li", "#tarefas-tabela-container").show();
      };
    })(this));
    return $("#tarefas-sob-minha-responsabilidade", "#tarefas-tabela-container").unbind("click").bind("click", (function(_this) {
      return function(evento) {
        $("label", "#tarefas-tabela-container").removeClass("btn-warning");
        $(evento.delegateTarget).addClass("btn-warning");
        return $("a[data-idusuario]", "#tarefas-tabela-container").each(function() {
          if ($( this ).data("idusuario") === FiltroPainel.IdDoUsuario) {
            return $( this ).parents("li").show();
          } else {
            return $( this ).parents("li").hide();
          }
        });
      };
    })(this));
  };

  meuPainelController.prototype.carregarModalStatusAcoes = function(status) {
    window.FiltroPainel.StatusAtividade = status;
    return $as.Onegreen.AtividadesDaLicenca.ListaAcoesDoUsuarioPorStatus.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        return window.GetDiv('status-acoes-container').html(data);
      };
    })(this));
  };

  meuPainelController.prototype.carregarModalStatusCondicionantes = function(status) {
    window.FiltroPainel.StatusAtividade = status;
    return $as.Onegreen.AtividadesDaLicenca.ListaCondicionantesDoUsuarioPorStatus.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        return window.GetDiv('status-acoes-container').html(data);
      };
    })(this));
  };

  meuPainelController.prototype.loadSolicitacoes = function() {
    $('#solicitacoesLicenciamento-container').html(this.ajaxLoader);
    return $as.Onegreen.SolicitacoesDeLicenciamento.ListarPeloResponsavel.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#solicitacoesLicenciamento-container").html(data);
        $("[rel=tooltip]").tooltip();
        return $("[rel=popover]").popover({
          placement: "top"
        });
      };
    })(this));
  };

  meuPainelController.prototype.loadEmpreendimentos = function() {
    $('#empreendimentos-grafico-container, #empreendimentos-tabela-container').html(this.ajaxLoader);
    return $as.Onegreen.Empreendimentos.EmpreendimentosPeloResponsavel.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#empreendimentos-grafico-container").html($(data).filter("#grafico-empreendimentos"));
        $("#empreendimentos-tabela-container").html($(data).filter("#tabela-empreendimentos"));
        return $("[rel=tooltip]").tooltip();
      };
    })(this));
  };

  meuPainelController.prototype.carregarReprogramacoesPendentes = function() {
    return $as.Atividades.Atividades.CarregarReprogramacoesPendentes.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#reprogramacoesPendentes").html(data);
        return $(".js-reprogramacoes-toggle").click(_this.configurarReprogramacoesToggle);
      };
    })(this));
  };

  meuPainelController.prototype.configurarVoltar = function() {
    return window.VoltarERecarregar = (function(_this) {
      return function() {
        return $as.Onegreen.Painel.Index.post().success(function(data) {
          return $('#main').html(data);
        });
      };
    })(this);
  };

  meuPainelController.prototype.atualizarFiltro = function() {
    $("#IdDoUsuario").val(this.options.idDoUsuario);
    return window.FiltroPainel = {
      IdUnidadeGerencial: "",
      NomeUnidadeGerencial: '(' + this.recursos.Todas + ')',
      IdDoUsuario: this.options.idDoUsuario,
      IncluirSubordinadas: true
    };
  };

  meuPainelController.prototype.configurarReprogramacoesToggle = function(evento) {
    $(evento.currentTarget).hasClass("btn-warning");
    $(".js-reprogramacoes-toggle").removeClass("btn-warning");
    $(evento.currentTarget).addClass("btn-warning");
    return $("#reprogramacoes-pendentes-container, #reprogramacoes-solicitadas-container").toggle();
  };

  meuPainelController.prototype.carregarTela = function() {
    this.ajaxLoader = '<div class="center"><img alt="" src="' + this.options.imgGraph + '"/></div>';
    this.loadComboUnidadeGerencial();
    $("[rel=tooltip]").tooltip();
    return window.MarcarMenuSuperior("#lnkMeuPainel");
  };

  return meuPainelController;

})(window.painelBaseController);
