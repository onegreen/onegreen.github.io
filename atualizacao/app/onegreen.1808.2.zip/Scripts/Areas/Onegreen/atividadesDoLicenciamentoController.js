﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.atividadesDoLicenciamentoController = (function() {
  function atividadesDoLicenciamentoController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.configurarComboDeAtividade = bind(this.configurarComboDeAtividade, this);
    $(this.contexto).window();
    this.configurarComboDeAtividade();
    $("input[type=radio]", "#outrasatividades-input-container").on("click", this.configurarComboDeAtividade);
  }

  atividadesDoLicenciamentoController.prototype.configurarComboDeAtividade = function() {
    var parametros;
    parametros = {
      idTipoEmpreendimento: this.options.idTipoEmpreendimento,
      tipoAtividade: $("input[type=radio]:checked", "#outrasatividades-input-container").val(),
      idLegislacao: this.options.idLegislacao
    };
    return setCombo(this.contexto, "#AtividadeParaRegularizacao_Descricao", null, parametros);
  };

  return atividadesDoLicenciamentoController;

})();
