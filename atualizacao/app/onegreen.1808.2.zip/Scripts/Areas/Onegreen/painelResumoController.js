﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.painelResumoController = (function(superClass) {
  extend(painelResumoController, superClass);

  function painelResumoController(options, recursos) {
    this.options = options;
    this.recursos = recursos;
    this.configurarVoltar = bind(this.configurarVoltar, this);
    this.atualizarFiltro = bind(this.atualizarFiltro, this);
    this.loadTarefas = bind(this.loadTarefas, this);
    this.loadEmpreendimentos = bind(this.loadEmpreendimentos, this);
    this.loadEstudos = bind(this.loadEstudos, this);
    this.carregarTela = bind(this.carregarTela, this);
    painelResumoController.__super__.constructor.call(this, this.options, this.recursos);
    this.configuraAplicarFiltro();
    this.atualizarFiltro();
    this.carregarTela();
    this.configurarVoltar();
  }

  painelResumoController.prototype.carregarTela = function() {
    this.ajaxLoader = '<div class="center"><img alt="" src="' + this.options.imgGraph + '"/></div>';
    this.loadComboUnidadeGerencial();
    $("[rel=tooltip]").tooltip();
    return $("#menu-superior li").removeClass("active");
  };

  painelResumoController.prototype.loadEstudos = function() {
    $('#estudos-container').html(this.ajaxLoader);
    return $as.Onegreen.EstudosDaLicenca.EstudosNaoConcretizados.get(window.FiltroMeuPainel).success((function(_this) {
      return function(data) {
        $("#estudos-container").html(data);
        return $("[rel=popover]").popover({
          placement: "top"
        });
      };
    })(this));
  };

  painelResumoController.prototype.loadEmpreendimentos = function() {
    window.FiltroPainel.IdDoUsuario = null;
    $('#empreendimentos-grafico-container, #empreendimentos-tabela-container').html(this.ajaxLoader);
    return $as.Onegreen.Empreendimentos.EmpreendimentosPeloResponsavel.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#empreendimentos-grafico-container").html($(data).filter("#grafico-empreendimentos"));
        $("#empreendimentos-tabela-container").html($(data).filter("#tabela-empreendimentos"));
        return $("[rel=tooltip]").tooltip();
      };
    })(this));
  };

  painelResumoController.prototype.loadTarefas = function() {
    window.FiltroPainel.IdDoUsuario = null;
    $('#tarefas-grafico-container, #tarefas-tabela-container').html(this.ajaxLoader);
    return $as.Onegreen.AtividadesDaLicenca.TarefasPorUnidade.get(window.FiltroPainel).success((function(_this) {
      return function(data) {
        $("#tarefas-grafico-container").html($(data).filter("#grafico-tarefas"));
        $("#tarefas-tabela-container").html($(data).filter("#tabela-tarefas"));
        $("#filtro-de-tarefas", "#tarefas-tabela-container").hide();
        $("[rel=tooltip]").tooltip();
        $("[rel=popover]").popover({
          placement: "top"
        });
        $("[id^=Percentual].btn-warning").prevAll().addClass("btn-warning");
        return setTimeout(function() {
          return Atividades.api.boot();
        }, 500);
      };
    })(this));
  };

  painelResumoController.prototype.atualizarFiltro = function() {
    return window.FiltroPainel = {
      IdUnidadeGerencial: "",
      NomeUnidadeGerencial: '(' + this.recursos.Todas + ')',
      IdDoUsuario: "",
      IncluirSubordinadas: true
    };
  };

  painelResumoController.prototype.configurarVoltar = function() {
    return window.VoltarERecarregar = (function(_this) {
      return function() {
        return $as.Onegreen.PainelResumo.Index.post().success(function(data) {
          return $('#main').html(data);
        });
      };
    })(this);
  };

  return painelResumoController;

})(window.painelBaseController);
