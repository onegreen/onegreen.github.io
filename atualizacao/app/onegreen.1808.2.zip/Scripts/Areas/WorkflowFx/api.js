﻿this.WorkflowFx || (this.WorkflowFx = {});

WorkflowFx.api = (function() {
  function api() {}

  api.atividadeAtual;

  api.reloadEstadoAtual = function(idDaEntidade, tipoDaEntidade, nomeDaEntidade) {
    if (idDaEntidade) {
      return $as.WorkflowFx.WorkflowEngine.RetornarEstadoAtual.get({
        idDaEntidade: idDaEntidade,
        tipoDaEntidade: tipoDaEntidade
      }).success(function(data) {
        return $("#atividade-workflow-container-" + nomeDaEntidade + '-' + idDaEntidade).replaceWith(data);
      });
    }
  };

  api.reloadCaminhoOtimo = function(idDaAtividade, idDaEntidade, tipoDaEntidade) {
    return WorkflowFx.caminhoOtimo.reload(idDaAtividade, idDaEntidade, tipoDaEntidade, 'Popover', true);
  };

  api.executarAtividadeConfirm = function(element, nomeDaAcao, opcoes) {
    var confirm;
    if (nomeDaAcao === 'Reativar') {
      return $as.Onegreen.Empreendimentos.PermitirReativarProjeto.post({}).success(function(data) {
        var confirm;
        if (data.error) {
          return window.modalAlert(data.message);
        } else {
          confirm = $(element).data("ajax-confirm");
          if (confirm) {
            return window.modalConfirm(confirm, function() {
              return api.executarAtividadeNoFluxo(nomeDaAcao, opcoes);
            });
          } else {
            return executarAtividadeNoFluxo(nomeDaAcao, opcoes);
          }
        }
      });
    } else {
      confirm = $(element).data("ajax-confirm");
      if (confirm) {
        return window.modalConfirm(confirm, function() {
          return api.executarAtividadeNoFluxo(nomeDaAcao, opcoes);
        });
      } else {
        return api.executarAtividadeNoFluxo(nomeDaAcao, opcoes);
      }
    }
  };

  api.executarAtividadeNoFluxo = function(nomeDaAcao, opcoes) {
    if (window.CallPreExecucaoDoFluxo) {
      return window.CallPreExecucaoDoFluxo(function() {
        return api.executarAcaoDoWorkflow(nomeDaAcao, opcoes);
      });
    } else {
      return api.executarAcaoDoWorkflow(nomeDaAcao, opcoes);
    }
  };

  api.executarAcaoDoWorkflow = function(nomeDaAcao, opcoes) {
    return $as.WorkflowFx.WorkflowEngine.ExecutarAtividade.post({
      mensagem: nomeDaAcao,
      id: opcoes.IdDaEntidade,
      entityType: opcoes.TipoDaEntidade,
      retornarEstadoAtual: opcoes.RetornarEstadoAtual
    }).success(function(data) {
      var containeres;
      if (window.RecarregarFluxoDoMeuPainel) {
        window.RecarregarFluxoDoMeuPainel();
      }
      if ($(opcoes.UpdateContainerId)) {
        containeres = $("[id='" + opcoes.UpdateContainerId.replace('#', '') + "']");
        containeres.map(function() {
          return $(this).replaceWith($(data));
        });
      }
      return api.executarCallBackDaExecucao();
    });
  };

  api.exibirJustificativa = function(mensagemDeConfirmacao, nomeDaAcao, opcoes) {
    return $as.WorkflowFx.WorkflowEngine.Justificativa.get({
      mensagemDeConfirmacao: mensagemDeConfirmacao,
      mensagem: nomeDaAcao,
      idDaEntidade: opcoes.IdDaEntidade,
      entityType: opcoes.TipoDaEntidade,
      retornarEstadoAtual: opcoes.RetornarEstadoAtual,
      updateContainer: opcoes.UpdateContainerId
    }).success(function(data) {
      return window.GetDiv("justificativa-modal-container").html(data);
    });
  };

  api.executarAcaoComJustificativa = function(data) {
    var containeres;
    if (data.success) {
      containeres = $("[id='" + data.data.updateContainer.replace('#', '') + "']");
      containeres.map(function() {
        return $(this).replaceWith($(data.data.html));
      });
      return api.executarCallBackDaExecucao();
    }
  };

  api.carregarAcoesDoEstadoAtual = function(botao, idDaAtividade, idDaEntidade, tipoDaEntidade, nomeDaEntidade, exibirMensagensADireita) {
    var $botao, $container;
    $botao = $(botao);
    $container = $botao.closest('#atividade-workflow-container-' + nomeDaEntidade + '-' + idDaEntidade);
    if (!$container.data("carregado")) {
      return $as.WorkflowFx.WorkflowEngine.AcoesDoEstadoAtual.get({
        idDaAtividade: idDaAtividade,
        idDaEntidade: idDaEntidade,
        tipoDaEntidade: tipoDaEntidade,
        exibirMensagensADireita: exibirMensagensADireita
      }).success(function(data) {
        $container.append(data).addClass("open").data("carregado", "true");
      });
    }
  };

  api.executarCallBackDaExecucao = function() {
    api.atualizarCascata();
    if (window.CallbackDaExecucaoDoFluxo) {
      return window.CallbackDaExecucaoDoFluxo();
    }
  };

  api.atualizarCascata = function() {
    var el, elementos, funcao, i, len;
    elementos = $('[data-workflow-cascade]', '#main');
    if (elementos.length) {
      for (i = 0, len = elementos.length; i < len; i++) {
        el = elementos[i];
        funcao = $(el).data('workflow-cascade-function');
        window.getFunctionFromString(funcao).apply(null, []);
      }
    }
  };

  return api;

})();
