﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.usuariosNaoCorporativoController = (function() {
  function usuariosNaoCorporativoController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.alterarAcesso = bind(this.alterarAcesso, this);
    this.loadComboUG = bind(this.loadComboUG, this);
    this.reload = bind(this.reload, this);
    this.bindAlterarAcesso = bind(this.bindAlterarAcesso, this);
    $('[rel=tooltip]').tooltip();
    this.loadComboUG();
    this.bindAlterarAcesso();
  }

  usuariosNaoCorporativoController.prototype.bindAlterarAcesso = function() {
    return $(this.contexto).find('.js-alterarSistema').click((function(_this) {
      return function() {
        return _this.alterarAcesso($( this ));
      };
    })(this));
  };

  usuariosNaoCorporativoController.prototype.reload = function() {
    return $as.Manutencao.Usuarios.Index.get().success((function(_this) {
      return function(data) {
        return $("#usuarios-nao-corporativo-container").html(data);
      };
    })(this));
  };

  usuariosNaoCorporativoController.prototype.loadComboUG = function() {
    return $("#UnidadeGerencial_SiglaAtual").autocompleter($as.API.UnidadeGerencial.RetornarComboUnidades.url, {
      loadOnDemand: false,
      elementToClick: "#UnidadeGerencial_SiglaAtual",
      keyElement: "#UnidadeGerencial_Id"
    });
  };

  usuariosNaoCorporativoController.prototype.alterarAcesso = function($el) {
    return $as.Manutencao.Usuarios.AlterarAcessoAoSistema.post({
      idDoUsuario: $el.data('iddousuario'),
      sistema: $el.data('sistema')
    }).done((function(_this) {
      return function(data) {
        if (data.data.alterado) {
          if ($el.attr('data-possui') === '1') {
            $el.attr('data-possui', '0');
            $el.removeClass('c-secundaria');
            return $el.addClass('c-cinza');
          } else {
            $el.attr('data-possui', '1');
            $el.removeClass('c-cinza');
            return $el.addClass('c-secundaria');
          }
        } else {
          return window.MostrarMensagemAviso(data.data.mensagem);
        }
      };
    })(this));
  };

  return usuariosNaoCorporativoController;

})();
