﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.gruposPorUsuarioController = (function() {
  function gruposPorUsuarioController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.reloadGruposPorUsuario = bind(this.reloadGruposPorUsuario, this);
    this.adicionarGrupoDeUsuarios = bind(this.adicionarGrupoDeUsuarios, this);
    this.aoSelecionarGrupo = bind(this.aoSelecionarGrupo, this);
    setCombo(this.contexto, "#GrupoDeUsuario_Nome", this.aoSelecionarGrupo);
  }

  gruposPorUsuarioController.prototype.aoSelecionarGrupo = function() {
    return $("#btnAdicionarGrupo", this.contexto).removeClass("disabled");
  };

  gruposPorUsuarioController.prototype.adicionarGrupoDeUsuarios = function() {
    if ($("#GrupoDeUsuario_Id", this.contexto).val() !== "") {
      return $as.Manutencao.GruposDeUsuario.VincularUsuarioAoGrupo.post({
        idDoUsuario: this.options.idDoUsuario,
        idDoGrupo: $("#GrupoDeUsuario_Id", this.contexto).val()
      }).done((function(_this) {
        return function(data) {
          return _this.reloadGruposPorUsuario();
        };
      })(this));
    }
  };

  gruposPorUsuarioController.prototype.reloadGruposPorUsuario = function() {
    return $as.API.GruposDeUsuario.GruposPorUsuario.get({
      idDoUsuario: this.options.idDoUsuario
    }).done((function(_this) {
      return function(data) {
        return $('#gruposPorUsuario-container').html(data);
      };
    })(this));
  };

  return gruposPorUsuarioController;

})();
