﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.LogDeAcessoController = (function() {
  function LogDeAcessoController(options, recursos) {
    this.options = options;
    this.recursos = recursos;
    this.setComboUnidadeGerencial = bind(this.setComboUnidadeGerencial, this);
    this.setComboUsuarios();
    this.setComboUnidadeGerencial();
  }

  LogDeAcessoController.prototype.setComboUsuarios = function() {
    var defaultOption;
    defaultOption = {
      Key: "",
      Value: "(" + this.recursos.Todos + ")"
    };
    return setCombo(this.options.Contexto, "#Usuario_Nome", null, null, null, null, defaultOption);
  };

  LogDeAcessoController.prototype.setComboUnidadeGerencial = function() {
    var defaultOption;
    defaultOption = {
      Key: "",
      Value: "(" + this.recursos.Todas + ")"
    };
    return setCombo(this.options.Contexto, "#UnidadeGerencialNome", null, null, null, null, defaultOption);
  };

  return LogDeAcessoController;

})();
