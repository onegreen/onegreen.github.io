﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.meuPainelController = (function() {
  function meuPainelController(options1) {
    this.options = options1;
    this.fecharSolucaoDeProblema = bind(this.fecharSolucaoDeProblema, this);
    this.configurarAncoras = bind(this.configurarAncoras, this);
    this.marcarPercentualDeConclusaoToggle = bind(this.marcarPercentualDeConclusaoToggle, this);
    this.carregarModalStatusAcoes = bind(this.carregarModalStatusAcoes, this);
    this.defineFiltro = bind(this.defineFiltro, this);
    this.configuraCheckSubordinadas = bind(this.configuraCheckSubordinadas, this);
    this.aplicarFiltro = bind(this.aplicarFiltro, this);
    this.carregarFarolProjeto = bind(this.carregarFarolProjeto, this);
    this.adicionarValorUGNoFiltro = bind(this.adicionarValorUGNoFiltro, this);
    this.adicionarValorDoFiltroNosCombos = bind(this.adicionarValorDoFiltroNosCombos, this);
    this.carregarComboDeUnidadeGerencial = bind(this.carregarComboDeUnidadeGerencial, this);
    this.carregarMinhasAcoes = bind(this.carregarMinhasAcoes, this);
    this.carregarReprogramacoesPendentes = bind(this.carregarReprogramacoesPendentes, this);
    this.carregarSolucoes = bind(this.carregarSolucoes, this);
    this.carregarFluxoDoMeuPainel = bind(this.carregarFluxoDoMeuPainel, this);
    this.configurarReprogramacoesToggle = bind(this.configurarReprogramacoesToggle, this);
    this.loadFunctions = bind(this.loadFunctions, this);
    window.FecharSolucaoDeProblema = this.fecharSolucaoDeProblema;
    this.defineFiltro(this.loadFunctions);
  }

  meuPainelController.prototype.loadFunctions = function() {
    this.carregarComboDeUnidadeGerencial();
    this.carregarMinhasAcoes();
    this.carregarSolucoes();
    this.carregarReprogramacoesPendentes();
    this.carregarFluxoDoMeuPainel();
    $("[rel=tooltip]").tooltip();
    $("[rel=popover]").popover();
    this.configurarAncoras();
    this.reprogramacoesToggle = $(".js-reprogramacoes-toggle").click(this.configurarReprogramacoesToggle);
    window.MarcarMenuSuperior("#lnkMeuPainel");
    return this.adicionarValorDoFiltroNosCombos();
  };

  meuPainelController.prototype.configurarReprogramacoesToggle = function(evento) {
    this.reprogramacoesToggle.removeClass("btn-warning");
    $(evento.currentTarget).addClass("btn-warning");
    return $("#reprogramacoes-pendentes-container, #reprogramacoes-solicitadas-container").toggle();
  };

  meuPainelController.prototype.carregarFluxoDoMeuPainel = function() {
    return $as.Melhorias.SolucoesDeProblemas.FluxoSolucoesSobMinhaInteracao.get(window.FiltroMeuPainel).success((function(_this) {
      return function(data) {
        return $("#fluxoDasSolucoesSobMinhaInteracao").html(data);
      };
    })(this));
  };

  meuPainelController.prototype.carregarSolucoes = function(status) {
    return $as.Melhorias.SolucoesDeProblemas.SolucoesMeuPainel.get(window.FiltroMeuPainel).success((function(_this) {
      return function(data) {
        $("#projetos-container").html(data);
        return $("#totalizador-projetos").html($(data).filter("#contador-totalizador-projetos").html());
      };
    })(this));
  };

  meuPainelController.prototype.carregarReprogramacoesPendentes = function() {
    return $as.Atividades.Atividades.CarregarReprogramacoesPendentes.get().success((function(_this) {
      return function(data) {
        $("#reprogramacoesPendentes").html(data);
        return $("#totalizador-reprogramacoes-pendentes").html($(data).filter("#contador-totalizador-reprogramacoes").html());
      };
    })(this));
  };

  meuPainelController.prototype.carregarMinhasAcoes = function() {
    return $as.Atividades.Atividades.FiltrarPeloResponsavel.get(window.FiltroMeuPainel).success((function(_this) {
      return function(data) {
        $("#atividades-grafico-container").html($(data).filter("#graficostatus-atividades").html());
        $("#totalizador-acoes").html($(data).filter("#graficostatus-atividades").find("#contador-totalizador-acoes").html());
        $("#atividades-tabela-container").html($(data).filter("#tabela-atividades").html());
        $("[rel=popover]").popover({
          placement: 'top'
        });
        $("[rel=tooltip]").tooltip();
        return $("[id^=Percentual].btn-warning").prevAll().addClass("btn-warning");
      };
    })(this));
  };

  meuPainelController.prototype.carregarComboDeUnidadeGerencial = function() {
    var parametros;
    parametros = {};
    $('#UnidadeGerencialNome').autocompleter(this.options.UrlAutoCompleterUnidadeGerencial, {
      loadOnDemand: true,
      elementToClick: "#UnidadeGerencialNomeBtn",
      keyElement: "#IdUnidadeGerencial",
      defaultOption: {
        Key: "",
        Value: this.options.ValueDefaultParaCampoFeminino
      }
    });
    return $('#UnidadeGerencialNome').data("autocompleter").setParameters(parametros);
  };

  meuPainelController.prototype.adicionarValorDoFiltroNosCombos = function() {
    $("#IdUnidadeGerencial").val(window.FiltroMeuPainel.IdUnidadeGerencial);
    $("#UnidadeGerencialNome").val(window.FiltroMeuPainel.UnidadeGerencialNome);
    if (window.FiltroMeuPainel.IncluirSubordinadas) {
      return $("#IncluirSubordinadasMeuPainel").attr("checked", "checked");
    } else {
      return $("#IncluirSubordinadasMeuPainel").removeAttr("checked");
    }
  };

  meuPainelController.prototype.adicionarValorUGNoFiltro = function() {
    window.FiltroMeuPainel.IdUnidadeGerencial = $("#IdUnidadeGerencial").val();
    window.FiltroMeuPainel.UnidadeGerencialNome = $("#UnidadeGerencialNome").val();
    return window.FiltroMeuPainel.IncluirSubordinadas = $("#IncluirSubordinadasMeuPainel").attr("checked") !== void 0;
  };

  meuPainelController.prototype.carregarFarolProjeto = function() {
    return $as.Melhorias.Painel.Index.get.success((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  meuPainelController.prototype.aplicarFiltro = function(e) {
    e.preventDefault();
    this.adicionarValorUGNoFiltro();
    $as.Melhorias.Painel.SalvarFiltro.post(window.FiltroMeuPainel);
    this.carregarMinhasAcoes();
    this.carregarSolucoes();
    return this.carregarFluxoDoMeuPainel();
  };

  meuPainelController.prototype.configuraCheckSubordinadas = function() {
    return $("#IncluirSubordinadasMeuPainel").click((function(_this) {
      return function(e) {
        return window.FiltroMeuPainel.IncluirSubordinadas = $("#IncluirSubordinadasMeuPainel").attr("checked") !== void 0;
      };
    })(this));
  };

  meuPainelController.prototype.defineFiltro = function(func) {
    var options, solucaoController;
    options = {
      UrlFiltroDefault: this.options.UrlFiltroDefault,
      UrlComboUnidadeGerencial: this.options.UrlComboUnidadeGerencial,
      ComboUnidadeGerencialDefault: {
        Key: "",
        Value: this.options.ValueDefaultParaCampoMasculino
      },
      aplicarFiltro: this.aplicarFiltro
    };
    return solucaoController = new window.Melhorias.filtroPainelController(options, func);
  };

  meuPainelController.prototype.carregarModalStatusAcoes = function(status) {
    window.FiltroMeuPainel.StatusAtividade = status;
    return $as.Atividades.Atividades.ListaAcoesDoUsuarioPorStatus.get(window.FiltroMeuPainel).success((function(_this) {
      return function(data) {
        return window.GetDiv('status-acoes-container').html(data);
      };
    })(this));
  };

  meuPainelController.prototype.marcarPercentualDeConclusaoToggle = function(element) {
    var $percentualAtual;
    $percentualAtual = $(element);
    $percentualAtual.nextAll($('#PercentualDeConclusaoToggle')).removeClass("btn-warning");
    $percentualAtual.prevAll($('#PercentualDeConclusaoToggle')).addClass("btn-warning");
    return $percentualAtual.addClass("btn-warning");
  };

  meuPainelController.prototype.configurarAncoras = function() {
    return $(".js-ancorasMeuPainel a").each((function(_this) {
      return function(index, array) {
        var ancora;
        ancora = $($(".js-ancorasMeuPainel a")[index]);
        if (!(ancora.attr('href') === void 0)) {
          return ancora.click(function() {
            var offsetTarget;
            offsetTarget = function() {
              return $(ancora.attr("href")).offset();
            };
            return $("html, body").animate({
              scrollTop: offsetTarget().top - 140
            }, 800);
          });
        }
      };
    })(this));
  };

  meuPainelController.prototype.fecharSolucaoDeProblema = function() {
    $as.Melhorias.Painel.Index.get().success(function(data) {
      $("#main").html(data);
    });
  };

  return meuPainelController;

})();
