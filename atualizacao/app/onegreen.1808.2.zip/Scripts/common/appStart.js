﻿$(function() {
  $.ajaxSettings.traditional = true;
  $.valHooks.textarea = {
    get: function(elem) {
      return elem.value.replace(/\r?\n/g, "\r\n");
    }
  };
});


/*
N�O SEI AINDA SE ISSO VAI FICAR AQUI
 */

window.marcarTodos = function(elementoOrigem) {
  var checked, checks, elem, table;
  elem = elementoOrigem;
  table = elem.parents("table");
  checks = $("[type=checkbox]", table);
  checked = elem.attr("checked") === "checked";
  if (checked) {
    return checks.attr("checked", "checked");
  } else {
    return checks.removeAttr("checked");
  }
};

window.marcarTodosSemTable = function(elementoOrigem) {
  var checked, checks, elem, table;
  elem = elementoOrigem;
  table = elem.parents(".listagemTabular");
  checks = $("[type=checkbox]", table);
  checked = elem.attr("checked") === "checked";
  if (checked) {
    return checks.attr("checked", "checked");
  } else {
    return checks.removeAttr("checked");
  }
};

window.onerror = function(message, url, line, column, error) {
  $as.Javascript.Log.post({
    message: message,
    url: url,
    line: line,
    column: column
  });
};

$(function() {
  $(document).on("click", ".marcar-todos", function(e) {
    marcarTodos($(this));
  });
  $(document).on("click", ".marcar-todos-sem-table", function(e) {
    marcarTodosSemTable($(this));
  });
});


/*
END
 */
