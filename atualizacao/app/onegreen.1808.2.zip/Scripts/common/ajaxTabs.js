﻿this.AjaxTab = (function() {
  function AjaxTab() {}

  AjaxTab.BindTabs = function(contexto) {
    AjaxTab.contexto = contexto;
    return $('.js-ajax-tab[data-href]', AjaxTab.contexto).on('click', function() {
      var $tab, $target, url;
      $tab = $(this);
      if ($tab.data('ajaxtabrender') === void 0) {
        $target = $($tab.attr('href'));
        url = $tab.data('href');
        return $.ajax({
          url: url,
          dataType: 'html',
          success: function(html) {
            $target.html(html);
            return $tab.data('ajaxtabrender', true);
          }
        });
      }
    });
  };

  return AjaxTab;

})();
