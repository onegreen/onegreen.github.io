﻿$(function() {
  $('#mostrarFormCadastrar').click(function() {
    $('#entrar').hide();
    return $('#cadastrar').show();
  });
  return $('#mostrarFormEntrar').click(function() {
    $('#entrar').show();
    return $('#cadastrar').hide();
  });
});
