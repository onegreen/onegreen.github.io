﻿window.modalAlert = function(msg, fn) {
  $(".modal-body", "#alert-modal-container").html("<p>" + msg + "</p>");
  $("#executar-acao", "#alert-modal-container").unbind('click').click(fn);
  $("#alert-modal-container").window();
};
