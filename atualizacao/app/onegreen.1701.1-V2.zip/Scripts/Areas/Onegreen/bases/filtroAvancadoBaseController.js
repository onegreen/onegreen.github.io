﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.FiltroAvancadoBaseController = (function() {
  function FiltroAvancadoBaseController(opcoes, recursos) {
    this.opcoes = opcoes;
    this.recursos = recursos;
    this.configurarDatePickers = bind(this.configurarDatePickers, this);
    this.SetOpcaoPadraoCombo = bind(this.SetOpcaoPadraoCombo, this);
    this.limparComboLicencas = bind(this.limparComboLicencas, this);
    this.limparComboTipologia = bind(this.limparComboTipologia, this);
    this.camposDependentesLegislacao = bind(this.camposDependentesLegislacao, this);
    this.camposDependentesLicencaAmbiental = bind(this.camposDependentesLicencaAmbiental, this);
    this.configurarComboTipologias = bind(this.configurarComboTipologias, this);
    this.configurarComboLegislacoes = bind(this.configurarComboLegislacoes, this);
    this.configurarComboTiposDeLicencas = bind(this.configurarComboTiposDeLicencas, this);
    this.configurarComboResponsaveis = bind(this.configurarComboResponsaveis, this);
    this.configurarComboLicencasAmbientais = bind(this.configurarComboLicencasAmbientais, this);
    this.configurarComboProjetos = bind(this.configurarComboProjetos, this);
    this.configurarComboEnderecos = bind(this.configurarComboEnderecos, this);
    this.configurarComboUnidades = bind(this.configurarComboUnidades, this);
    this.configurarComboUnidades();
    this.configurarComboEnderecos();
    this.configurarComboTipologias();
    this.configurarComboLegislacoes();
    this.configurarComboTiposDeLicencas();
    this.configurarComboProjetos();
    this.configurarComboLicencasAmbientais();
    this.configurarComboResponsaveis();
    this.configurarDatePickers();
    this.camposDependentesLegislacao();
    this.camposDependentesLicencaAmbiental();
  }

  FiltroAvancadoBaseController.prototype.configurarComboUnidades = function() {
    setCombo(this.opcoes.Contexto, '#UnidadeGerencialNome');
    return this.SetOpcaoPadraoCombo("#UnidadeGerencialNome", {
      Key: "",
      Value: "(" + this.recursos.Todas + ")"
    });
  };

  FiltroAvancadoBaseController.prototype.configurarComboEnderecos = function() {
    return setCombo(this.opcoes.Contexto, '#EnderecoNome');
  };

  FiltroAvancadoBaseController.prototype.configurarComboProjetos = function() {
    if (!this.opcoes.hideProjeto) {
      return setCombo(this.opcoes.Contexto, '#NomeProjeto', this.camposDependentesLicencaAmbiental);
    }
  };

  FiltroAvancadoBaseController.prototype.configurarComboLicencasAmbientais = function() {
    var parametros;
    parametros = {
      idDoEmpreendimento: $('#Empreendimento').val()
    };
    return setCombo(this.opcoes.Contexto, '#LicencaAmbientalNome', null, parametros);
  };

  FiltroAvancadoBaseController.prototype.configurarComboResponsaveis = function() {
    return setCombo(this.opcoes.Contexto, '#ResponsavelNome');
  };

  FiltroAvancadoBaseController.prototype.configurarComboTiposDeLicencas = function() {
    return setCombo(this.opcoes.Contexto, '#TipoDeLicencaNome');
  };

  FiltroAvancadoBaseController.prototype.configurarComboLegislacoes = function() {
    return setCombo(this.opcoes.Contexto, '#LegislacaoAmbientalNome', this.camposDependentesLegislacao);
  };

  FiltroAvancadoBaseController.prototype.configurarComboTipologias = function() {
    var parametros;
    parametros = {
      ideLegislacao: $('#LegislacaoAmbiental').val()
    };
    return setCombo(this.opcoes.Contexto, '#TipodeEmpreendimentoNome', null, parametros);
  };

  FiltroAvancadoBaseController.prototype.camposDependentesLicencaAmbiental = function() {
    var empreendimentoSelecionado;
    empreendimentoSelecionado = $('#Empreendimento').val() !== null && $('#Empreendimento').val() !== 0 && $('#Empreendimento').val() !== void 0 && $('#Empreendimento').val() !== '';
    if (empreendimentoSelecionado) {
      this.configurarComboLicencasAmbientais();
    } else {
      this.limparComboLicencas();
    }
    return $('#LicencaAmbientalNome').data('autocompleter').disableElseEnable(!empreendimentoSelecionado);
  };

  FiltroAvancadoBaseController.prototype.camposDependentesLegislacao = function() {
    var legislacaoSelecionada;
    legislacaoSelecionada = $('#LegislacaoAmbiental').val() !== null && $('#LegislacaoAmbiental').val() !== 0 && $('#LegislacaoAmbiental').val() !== void 0 && $('#LegislacaoAmbiental').val() !== '';
    if (legislacaoSelecionada) {
      this.configurarComboTipologias();
    } else {
      this.limparComboTipologia();
    }
    return $('#TipodeEmpreendimentoNome').data('autocompleter').disableElseEnable(!legislacaoSelecionada);
  };

  FiltroAvancadoBaseController.prototype.limparComboTipologia = function() {
    $('#TipoDeEmpreendimento').val('');
    return $('#TipodeEmpreendimentoNome').val('');
  };

  FiltroAvancadoBaseController.prototype.limparComboLicencas = function() {
    $('#LicencaAmbiental').val('');
    return $('#LicencaAmbientalNome').val('');
  };

  FiltroAvancadoBaseController.prototype.SetOpcaoPadraoCombo = function(idCombo, opcao) {
    return $(idCombo, this.opcoes.Contexto).data("autocompleter").setOpcaoPadrao(opcao);
  };

  FiltroAvancadoBaseController.prototype.configurarDatePickers = function() {
    $('.date-picker', this.opcoes.Contexto).datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      autoclose: true,
      language: Globalize.culture($("html").attr("lang")).name
    });
    $("#DataInicio", this.opcoes.Contexto).change((function(_this) {
      return function() {
        var startDate;
        $("#DataFim", _this.opcoes.Contexto).datepicker('setStartDate');
        if ($("#DataInicio").val().trim() !== "") {
          if ($("#DataFim", _this.opcoes.Contexto).val() === '') {
            $("#DataFim", _this.opcoes.Contexto).val($("#DataInicio", _this.opcoes.Contexto).val());
          }
          startDate = $("#DataInicio", _this.opcoes.Contexto).data('datepicker').getFormattedDate();
          $("#DataFim", _this.opcoes.Contexto).datepicker('setStartDate', startDate);
          return $("#DataFim", _this.opcoes.Contexto).datepicker('show');
        }
      };
    })(this));
    $("#DataFim", this.opcoes.Contexto).change((function(_this) {
      return function() {
        var endDate;
        $("#DataInicio", _this.opcoes.Contexto).datepicker('setEndDate');
        if ($("#DataFim").val().trim() !== "") {
          if ($("#DataInicio", _this.opcoes.Contexto).val() === '') {
            $("#DataInicio", _this.opcoes.Contexto).val($("#DataFim", _this.opcoes.Contexto).val());
          }
          endDate = $("#DataFim", _this.opcoes.Contexto).data('datepicker').getFormattedDate();
          return $("#DataInicio", _this.opcoes.Contexto).datepicker('setEndDate', endDate);
        }
      };
    })(this));
  };

  return FiltroAvancadoBaseController;

})();
