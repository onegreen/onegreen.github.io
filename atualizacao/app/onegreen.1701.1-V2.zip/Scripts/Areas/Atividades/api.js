﻿this.Atividades || (this.Atividades = {});

Atividades.api = (function() {
  function api() {}

  api.boot = function() {
    api.configurarCallbackPopoverPaineis();
    return $('.js-buscar-informacoes-atividade').unbind('click').bind('click', api.exibirPopoverListagemReduzida);
  };

  api.obterViewDaAtividade = function(idDaAtividade) {
    return $(api.obterNomeDaViewDaAtividade(idDaAtividade));
  };

  api.obterNomeDaViewDaAtividade = function(idDaAtividade) {
    return "#tela-Atividade-" + idDaAtividade;
  };

  api.atualizarReferencias = function(idDaAtividade, atualizarSuperior, ativarSubtarefas) {
    var atividades, atividadesPainel, containerEditAtividade, exibirSubTarefas, manterExpandido, partialEditAtividade, partials, recarregarAtividade, viewAtividade;
    atividades = $("[data-atividade=" + idDaAtividade + "]");
    atividadesPainel = $("[data-atividade-painel=" + idDaAtividade + "]");
    viewAtividade = api.obterViewDaAtividade(idDaAtividade);
    exibirSubTarefas = true;
    manterExpandido = false;
    atualizarSuperior = atualizarSuperior === void 0 ? true : atualizarSuperior;
    if (viewAtividade.length) {
      if (viewAtividade.data('fullscreen')) {
        containerEditAtividade = $("#main");
        partialEditAtividade = "view-atividade-full";
      } else {
        containerEditAtividade = $("#box-create-edit-atividade");
        partialEditAtividade = "view-atividade";
      }
    }
    if (atividades.length || atividadesPainel.length || viewAtividade.length) {
      partials = [];
      recarregarAtividade = $as.Atividades.Atividades.RecarregarAtividade.get;
      if (viewAtividade.length) {
        partials.push(partialEditAtividade);
      }
      if (atividades.length) {
        partials.push("atividade");
        partials.push('subtarefas-atividade');
        exibirSubTarefas = atividades.data('exibir-subtarefas');
        manterExpandido = atividades.data('exibir-expandido');
      }
      if (atividadesPainel.length) {
        partials.push("atividade-painel");
        exibirSubTarefas = atividades.data('exibir-subtarefas');
        manterExpandido = atividades.data('exibir-expandido');
      }
      return recarregarAtividade({
        idDaAtividade: idDaAtividade,
        partials: partials,
        exibirSubTarefas: exibirSubTarefas,
        manterExpandido: manterExpandido
      }).success(function(data) {
        var $atividadeAtualizada, $data, $subtarefas, collapsed, ordenar;
        $data = $(data);
        if (viewAtividade.length) {
          $atividadeAtualizada = $data.find("[data-partial=view-atividade]");
          if (ativarSubtarefas) {
            $subtarefas = $data.find("[data-partial=subtarefas-atividade]");
            $atividadeAtualizada.find('#subtarefas-container').html($subtarefas.html());
            $atividadeAtualizada.find('.nav-tabs li').removeClass('active');
            $atividadeAtualizada.find('#subtarefas-tab').closest('li').addClass('active');
            $atividadeAtualizada.find('.tab-content div').removeClass('active');
            $atividadeAtualizada.find('#subtarefas-container').addClass('active').addClass('in');
          }
          containerEditAtividade.html($atividadeAtualizada.html());
        }
        collapsed = $("#desdobrar-" + idDaAtividade, $("#smart-container-" + idDaAtividade)).hasClass('fa-minus-square');
        ordenar = $(".ordenar", "#smart-container-" + idDaAtividade).is(':visible');
        if ($data.find('#id-atividade-superior').length && atualizarSuperior) {
          api.notificarMudanca($data.find('#id-atividade-superior').val());
        }
        api.atualizarStatus($("[data-partial='atividade']", $data), idDaAtividade);
        api.atualizarStatus($("[data-partial='atividade-painel']", $data), idDaAtividade);
        api.atualizarPartial(atividades, "atividade", $data);
        if (collapsed) {
          $("#desdobrar-" + idDaAtividade).removeClass("fa-plus-square").addClass("fa-minus-square");
        }
        if (ordenar) {
          $(".ordenar", "#smart-container-" + idDaAtividade).toggle();
        }
        api.atualizarPartial(atividadesPainel, "atividade-painel", $data);
        if ($('.js-Esconder-Icone-Informacoes').length) {
          $('.js-buscar-informacoes-atividade').hide();
        } else {
          $('.js-buscar-informacoes-atividade').unbind('click').bind('click', api.exibirPopoverListagemReduzida);
          $('.js-buscar-informacoes-atividade').show();
        }
        $('[rel=tooltip]').tooltip();
        return Atividades.api.boot();
      });
    }
  };

  api.atualizarLogsDaTarefa = function(idDaAtividade) {
    var containerEditAtividade, fullScreen, partials, recarregarAtividade, viewAtividade;
    partials = [];
    recarregarAtividade = $as.Atividades.Atividades.RecarregarAtividade.get;
    partials.push("logs-atividade");
    viewAtividade = api.obterViewDaAtividade(idDaAtividade);
    fullScreen = viewAtividade.data('fullscreen');
    if (fullScreen) {
      containerEditAtividade = $("#main");
      partials.push("view-atividade-full");
      partials.push("cabecalho-atividade");
    } else {
      partials.push("atividade");
      partials.push("atividade-painel");
    }
    return recarregarAtividade({
      idDaAtividade: idDaAtividade,
      partials: partials
    }).success(function(data) {
      var container;
      if (data) {
        api.atualizarPartial($('#eventos-atividade'), "logs-atividade", $(data));
        if (!fullScreen) {
          api.atualizarPartial($("#smart-container-" + idDaAtividade + "[data-id='" + idDaAtividade + "']"), "atividade", $(data));
          api.atualizarPartial($("#smart-container-" + idDaAtividade), "atividade", $(data));
          api.atualizarPartial($("[data-atividade-painel=" + idDaAtividade + "]"), "atividade-painel", $(data));
        }
        container = $("#tela-Atividade-" + idDaAtividade);
        return container.data("controller").configurarMostrarDetalhesDeEventos();
      }
    });
  };

  api.atualizarPartial = function(element, partialName, $data) {
    var idDaAtividade, newElementHtml, newElementObject, options;
    if (element.length) {
      newElementHtml = $("[data-partial=" + partialName + "]", $data).html();
      newElementObject = $($.parseHTML(newElementHtml));
      element.replaceWith(newElementHtml);
      options = newElementObject.data('options');
      idDaAtividade = newElementObject.data('id');
      if (options && options.atividadeExcluida) {
        $("#container-subTarefas-" + idDaAtividade).remove();
      }
      api.removerSelecaoDaLinhaEEsconderBotaoDeReprogramacao(element, $data);
      return setTimeout(function() {
        $("[rel=tooltip]", "#" + element.attr("id")).tooltip();
        return api.boot();
      }, 200);
    }
  };

  api.removerSelecaoDaLinhaEEsconderBotaoDeReprogramacao = function(element, $data) {
    var btnReprogramar;
    if ($data.find(".farol-atividade-concluida").length || $data.find(".farol-atividade-concluidacomatraso").length) {
      btnReprogramar = element.attr('data-toggle-display');
      element.removeAttr('data-toggle-display').removeClass('selecionado');
      if (!$(element).parent().parent().find('tr.selecionado').length) {
        return $(btnReprogramar).addClass('none');
      }
    }
  };

  api.configurarCallbackPopoverPaineis = function() {
    return $("body").on("click", "tr[data-atividade-painel]", function(event) {
      var $el, evt, idDaAtividade, placement, tag, urlDetalhesAtividade;
      evt = event || window.event;
      tag = evt.target.tagName || evt.srcElement.tagName;
      if (tag === 'A') {
        return;
      }
      $(".popover").remove();
      $el = $(evt.currentTarget);
      idDaAtividade = $el.data("atividade-painel");
      urlDetalhesAtividade = $el.parent().data("url-detalhes-atividade");
      placement = 'right';
      if ($el.parent().data("placement")) {
        placement = $el.parent().data("placement");
      }
      if (urlDetalhesAtividade) {
        return $.get(urlDetalhesAtividade, {
          idDaAtividade: idDaAtividade
        }).done(function(data) {
          var $data, callPopover, content, title;
          $data = $(data);
          title = $data.find("#detalhes-atividade-title").html();
          content = $data.find("#detalhes-atividade-content").html();
          callPopover = function() {
            $el.popover({
              trigger: 'manual',
              html: true,
              title: title + '<span class="fr cursor-pointer" onclick="popover.close($(this))"><i class="fa fa-times fa-1"></i></span>',
              content: content,
              placement: placement
            });
            $el.popover('show');
          };
          setTimeout(callPopover, 200);
        });
      }
    });
  };

  api.exibirPopoverListagemReduzida = function(event) {
    var $el, evt, idDaAtividade, placement, tag, urlDetalhesAtividade;
    evt = event || window.event;
    tag = evt.target.tagName || evt.srcElement.tagName;
    if (tag === 'A') {
      return;
    }
    $(".popover").remove();
    $el = $(evt.currentTarget);
    placement = 'bottom';
    if ($el.closest('[data-placement-popover]').data("placement-popover")) {
      placement = $el.closest('[data-placement-popover]').data("placement-popover");
    }
    idDaAtividade = $el.closest('.js-base-tarefa').data("atividade-painel");
    urlDetalhesAtividade = $el.data("url-detalhes-atividade");
    if (urlDetalhesAtividade) {
      return $.get(urlDetalhesAtividade, {
        idDaAtividade: idDaAtividade
      }).done(function(data) {
        var $data, callPopover, content, title;
        $data = $(data);
        title = $data.find("#detalhes-atividade-title").html();
        content = $data.find("#detalhes-atividade-content").html();
        callPopover = function() {
          $el.popover({
            trigger: 'manual',
            html: true,
            title: title + '<span class="fr cursor-pointer" onclick="popover.close($(this))"><i class="fa fa-times fa-1"></i></span>',
            content: content,
            placement: placement
          });
          $el.popover('show');
        };
        setTimeout(callPopover, 200);
      });
    }
  };

  api.atualizarExecucao = function(idDaAtividade) {
    var viewAtividade;
    api.notificarMudanca(idDaAtividade);
    viewAtividade = api.obterViewDaAtividade(idDaAtividade);
    if (!(viewAtividade.css('display') === 'none' || viewAtividade.css('display') === void 0)) {
      return api.reload(idDaAtividade);
    }
  };

  api.notificarMudanca = function(idDaAtividade, atualizarSuperior, ativarSubtarefas) {
    api.atualizarReferencias(idDaAtividade, atualizarSuperior, ativarSubtarefas);
    api.atualizarCascata(idDaAtividade);
    return api.verificarExigenciaDeNotificacao(idDaAtividade);
  };

  api.atualizarCascata = function(idDaAtividade) {
    var atividadesPainel, ele, elementosParaRecarregar, execute, i, len, parentCascade, results;
    atividadesPainel = $("[data-atividade-painel=" + idDaAtividade + "]");
    if (!atividadesPainel.length) {
      atividadesPainel = $("[data-atividade=" + idDaAtividade + "]");
    }
    atividadesPainel.trigger('atualizar', [atividadesPainel, idDaAtividade, atividadesPainel.data('plano-de-acao')]);
    parentCascade = $(atividadesPainel.parents('[data-atividade-cascade]'));
    if (parentCascade.length) {
      elementosParaRecarregar = $(parentCascade.data('atividade-cascade'));
      execute = function(elemento) {
        if (elemento.data("controller")) {
          elemento.data("controller").reload();
        }
        if (elemento.data("cascade-function")) {
          return eval(elemento.data("cascade-function"));
        }
      };
      results = [];
      for (i = 0, len = elementosParaRecarregar.length; i < len; i++) {
        ele = elementosParaRecarregar[i];
        results.push(execute($(ele)));
      }
      return results;
    }
  };

  api.openRecentAdded = function(data) {
    Atividades.PlanoDeAcao.api.reload(data.data.idPlanoDeAcao, data.data.ideObj);
    return api.reload(data.data.id);
  };

  api.reloadListagemRecentAdded = function(data) {
    return Atividades.PlanoDeAcao.api.reload(data.data.idPlanoDeAcao, null);
  };

  api.reload = function(idDaAtividade) {
    return $as.Atividades.Atividades.Edit.get({
      id: idDaAtividade
    }).done(function(data) {
      return $("#box-create-edit-atividade").html(data);
    });
  };

  api.atualizarTransferenciaDeResponsabilidade = function(idDaAtividade) {
    var container;
    container = $("#tela-Atividade-" + idDaAtividade);
    return container.data("controller").atualizarTransferenciaDeResponsabilidade();
  };

  api.exibirOcultarSubAtividades = function(idDaAtividade, listarSomenteAtivas, elemento) {
    var containerAtividade;
    elemento = $(elemento);
    containerAtividade = elemento.closest("#smart-container-" + idDaAtividade);
    if (!containerAtividade.parent().find('.container-subtarefas').length) {
      return $as.Atividades.Atividades.ListarSubAtividades.get({
        idDaAtividade: idDaAtividade,
        listarSomenteAtivas: listarSomenteAtivas
      }).done(function(data) {
        $('.container-subtarefas', containerAtividade.parent()).remove();
        containerAtividade.after(data);
        containerAtividade.next().attr('id', "container-subTarefas-" + idDaAtividade).attr('data-tarefa-superior', idDaAtividade).attr('class', 'container-subtarefas');
        elemento.removeClass("fa-plus-square js-close").addClass("fa-minus-square js-open");
        elemento.addClass('collapseSubAtividade');
        if ($(".ordenar", containerAtividade).is(':visible')) {
          $(".ordenar", "#container-subTarefas-" + idDaAtividade).toggle();
        }
        return $('[rel=tooltip]').tooltip();
      });
    } else {
      elemento.removeClass("fa-minus-square js-open").addClass("fa-plus-square js-close");
      return $('.container-subtarefas', $(containerAtividade).parent()).remove();
    }
  };

  api.atualizarExibicaoDeSubAtividades = function(idDaAtividadeSuperior) {
    var container;
    container = $("#container-subTarefas-" + idDaAtividadeSuperior);
    return $as.Atividades.Atividades.ListarSubAtividades.get({
      idDaAtividade: idDaAtividadeSuperior
    }).done((function(_this) {
      return function(data) {
        container.empty().append(data);
        if ($(".ordenar", "#smart-container-" + idDaAtividadeSuperior).is(':visible')) {
          return $(".ordenar", "#container-subTarefas-" + idDaAtividadeSuperior).toggle();
        }
      };
    })(this));
  };

  api.atualizarAtivarDesativar = function(idDaAtividade) {
    var atividade, containerPlanoDeAcao, containerSubtarefas, exibirExpandido, idDaTerefaSuperior, liPai, subAtividades;
    atividade = "#smart-container-" + idDaAtividade;
    liPai = $(atividade).parent();
    containerSubtarefas = $("[id*='container-subTarefas']", liPai);
    containerPlanoDeAcao = $(atividade).closest("[id^=globalPlanoDeAcao]");
    idDaTerefaSuperior = $("[data-atividade=" + idDaAtividade + "]").data('atividade-superior');
    if (idDaTerefaSuperior > 0) {
      $("[data-atividade=" + idDaTerefaSuperior + "]").attr('data-exibir-expandido', 'true');
    }
    if ($(atividade).data('exibir-subtarefas') === 'False') {
      $("[id^=smart-container]", containerPlanoDeAcao).attr('data-exibir-expandido', 'False');
      subAtividades = $("[data-atividade-superior=" + idDaAtividade + "]");
      api.atualizarSubTarefas(subAtividades, false, true);
    } else {
      exibirExpandido = $("#container-subTarefas-" + idDaAtividade).length > 0;
      $(atividade).attr('data-exibir-expandido', exibirExpandido);
      subAtividades = $("[data-atividade]", containerSubtarefas);
      api.atualizarSubTarefas(subAtividades, true, false);
    }
    return api.notificarMudanca(idDaAtividade);
  };

  api.atualizarSubTarefas = function(atividades, exibirExpandido, atualizarNivelInferior) {
    var data, i, len, results;
    results = [];
    for (i = 0, len = atividades.length; i < len; i++) {
      data = atividades[i];
      results.push((function() {
        var idDaAtividade, subAtividades;
        idDaAtividade = $(data).data('atividade');
        exibirExpandido = $("#container-subTarefas-" + idDaAtividade).length > 0;
        $("#smart-container-" + idDaAtividade).attr('data-exibir-expandido', exibirExpandido);
        api.notificarMudanca(idDaAtividade, false, true);
        if (atualizarNivelInferior) {
          subAtividades = $("[data-atividade-superior=" + idDaAtividade + "]");
          return api.atualizarSubTarefas(subAtividades, exibirExpandido, false);
        }
      })());
    }
    return results;
  };

  api.calcularNumeroDeDocumentosEmEventos = function(idDaAtividade) {
    return $as.Atividades.Atividades.NumeroDeDocumentosDosEventos.get({
      idDaAtividade: idDaAtividade
    }).done(function(data) {
      return $('#documentosEventos').html(data);
    });
  };

  api.smartTransferenciaDeResponsabilidade = function(idDaAtividade, contexto) {
    var idDoPlanoDeAcao, idsDasAtividades, smartContainer;
    smartContainer = $("#smart-container-" + idDaAtividade, contexto);
    idDoPlanoDeAcao = $('#PlanoDeAcao_Id', smartContainer).val();
    idsDasAtividades = [];
    idsDasAtividades.push(idDaAtividade);
    return $as.Atividades.PlanosDeAcao.TransferirResponsabilidadePorAtividade.get({
      idsDasAtividades: idsDasAtividades,
      idDoPlanoDeAcao: idDoPlanoDeAcao,
      funcaoReload: "Atividades.api.notificarMudanca(" + idDaAtividade + ")"
    }).done(function(data) {
      return $("#main-modal").html(data);
    });
  };

  api.smartInicioPrevisto = function(idDaAtividade, elemento, endDate) {
    var contexto, options;
    contexto = elemento.closest("#smart-container-" + idDaAtividade);
    options = $(contexto).data('options');
    if (options.utilizaReprogramacao || options.atividadePossuiReprogramacaoPendente) {
      if (!options.atividadePeriodica) {
        return api.executarReprogramacaoDoInicioPrevisto(options, idDaAtividade);
      }
    } else {
      return api.executarSmartPicker(elemento, '#inicio-picker-container', contexto, idDaAtividade, '#smart-inicio-previsto', '#InicioPrevisto', api.atualizarInicioPrevisto, null, endDate);
    }
  };

  api.smartFimPrevisto = function(idDaAtividade, elemento, startDate) {
    var contexto, options;
    contexto = elemento.closest("#smart-container-" + idDaAtividade);
    options = $(contexto).data('options');
    if (options.utilizaReprogramacao || options.atividadePossuiReprogramacaoPendente) {
      if (!options.atividadePeriodica) {
        return api.executarReprogramacaoDoFimPrevisto(options, idDaAtividade);
      }
    } else if (!options.atividadePeriodica) {
      return api.executarSmartPicker(elemento, '#fim-picker-container', contexto, idDaAtividade, '#smart-fim-previsto', '#FimPrevisto', api.atualizarFimPrevisto, startDate, null);
    }
  };

  api.smartIniciarAtividade = function(idDaAtividade) {
    return $as.Atividades.Atividades.Executar.get({
      id: idDaAtividade
    }).done(function(data) {
      return $("#main-modal").html(data);
    });
  };

  api.smartExecutarAtividade = function(idDaAtividade) {
    return $as.Atividades.Atividades.Executar.get({
      id: idDaAtividade,
      percentualConcluido: options.percentualConcluido
    }).done(function(data) {
      return $("#main-modal").html(data);
    });
  };

  api.configurarToggleSmartPicker = function() {
    $('body').find('[id="smart-inicio-previsto"]').click(function(e) {
      return e.stopPropagation();
    });
    $('body').find('[id="smart-fim-previsto"]').click(function(e) {
      return e.stopPropagation();
    });
    $('#modal-smart-picker .pam').click(function(e) {
      return e.stopPropagation();
    });
    return $('body').click(function(e) {
      if (e.target.id !== 'smart-inicio-previsto') {
        $('.container-modal-smart-picker').remove();
        return $('.modal-smart-picker').remove();
      }
    });
  };

  api.executarSmartPicker = function(elementoDeContexto, container, contexto, idDaAtividade, elementoDisparo, hidden, funcao, startDate, endDate) {
    var modal, modalAplicar, picker;
    elementoDeContexto = elementoDeContexto.parents("#box-date-smart-control");
    if ($('.modal-smart-picker', elementoDeContexto).is(":visible")) {
      $('.container-modal-smart-picker').remove();
      $('.modal-smart-picker').remove();
    } else {
      $('.container-modal-smart-picker').remove();
      $('.modal-smart-picker').remove();
      $('body').append("<div id='container-modal-smart-picker' class='container-modal-smart-picker'> <div class='modal-smart bottom modal-smart-picker' style='z-index:9999; width:250px; display:none' id='modal-smart-picker'> <img src='" + CompleteHostAdress + "/Content/img/smartControls-up.png' class='seta-up' /> <div class='pam'> <div class='date' id='date-smart-picker'> </div> </div> </div> </div>");
      modal = '#modal-smart-picker';
      picker = '#date-smart-picker';
      modalAplicar = $(modal);
      $(container, elementoDeContexto).empty().html(modalAplicar);
      modalAplicar.show();
      $(picker).attr('data-date', $(hidden).val());
      $(picker).empty();
      $(picker, $(modal)).datepicker({
        autoclose: true
      });
      if (startDate) {
        $(picker, $(modal)).datepicker('setStartDate', startDate);
      }
      if (endDate) {
        $(picker, $(modal)).datepicker('setEndDate', endDate);
      }
      $(picker, $(modal)).on("changeDate", function(e) {
        $(hidden, elementoDeContexto).val($(picker, $(modal)).data('datepicker').getFormattedDate());
        funcao(elementoDeContexto, idDaAtividade);
        modalAplicar.hide();
        $('#container-modal-smart-picker').empty().html(modalAplicar);
        $(container, elementoDeContexto).empty();
        $('.container-modal-smart-picker').remove();
        return $('.modal-smart-picker').remove();
      });
    }
    return api.configurarToggleSmartPicker();
  };

  api.atualizarInicioPrevisto = function(elementoDeContexto, idDaAtividade) {
    return $as.Atividades.Atividades.AtualizarInicioPrevisto.post({
      idDaAtividade: idDaAtividade,
      inicioPrevisto: $('#InicioPrevisto', elementoDeContexto).val()
    }).done(function(data) {
      swIntercom('Mudou o inicio previsto da tarefa');
      return api.notificarMudanca(idDaAtividade);
    });
  };

  api.atualizarFimPrevisto = function(elementoDeContexto, idDaAtividade) {
    return $as.Atividades.Atividades.AtualizarFimPrevisto.post({
      idDaAtividade: idDaAtividade,
      fimPrevisto: $('#FimPrevisto', elementoDeContexto).val()
    }).done(function(data) {
      swIntercom('Mudou o inicio previsto da tarefa');
      return api.notificarMudanca(idDaAtividade);
    });
  };

  api.executarReprogramacaoDoInicioPrevisto = function(options, idDaAtividade) {
    if (!options.bloquearReprogramacaoDoInicioPrevisto || options.atividadePossuiReprogramacaoPendente) {
      if (options.atividadePossuiReprogramacaoPendente) {
        api.executarExibicaoDeReprogramacaoPendente(idDaAtividade);
      } else {
        api.executarSolicitacaoDeReprogramacao(idDaAtividade);
      }
    }
  };

  api.executarReprogramacaoDoFimPrevisto = function(options, idDaAtividade) {
    if (!options.bloquearReprogramacaoDoFimPrevisto || options.atividadePossuiReprogramacaoPendente) {
      if (options.atividadePossuiReprogramacaoPendente) {
        return api.executarExibicaoDeReprogramacaoPendente(idDaAtividade);
      } else {
        return api.executarSolicitacaoDeReprogramacao(idDaAtividade);
      }
    }
  };

  api.executarSolicitacaoDeReprogramacao = function(idDaAtividade) {
    var idsDasAtividades;
    idsDasAtividades = [];
    idsDasAtividades.push(idDaAtividade);
    return $as.Atividades.Atividades.Reprogramar.get({
      idsDasAtividades: idsDasAtividades,
      recarregarAtividade: true
    }).done(function(data) {
      return $("#main-modal").html(data);
    });
  };

  api.executarExibicaoDeReprogramacaoPendente = function(idDaAtividade) {
    return $as.Atividades.Atividades.ExibirReprogramacaoPendente.get({
      idDaAtividade: idDaAtividade
    }).done(function(data) {
      return $("#main-modal").html(data);
    });
  };

  api.configurarSmartPicker = function() {
    $('#container-modal-smart-picker').html($('#modal-smart-picker'));
    return $('#modal-smart-picker').hide();
  };

  api.atualizarStatus = function(contexto, idDaAtividade) {
    var options, smartContainer;
    options = $("#smart-container-" + idDaAtividade, contexto).data('options');
    smartContainer = $("#smart-container-" + idDaAtividade).closest('.borda-lateral');
    if (options) {
      if (options.atividadeAtrasada) {
        smartContainer.removeClass('no-prazo').addClass('atrasada');
      } else {
        smartContainer.removeClass('atrasada').addClass('no-prazo');
      }
      if (options.atividadeExcluida) {
        return smartContainer.addClass('desativada');
      } else {
        return smartContainer.removeClass('desativada');
      }
    }
  };

  api.configurarControleDePercentualDeConclusao = function() {
    $("button", $("#btn-progresso")).mouseover(function() {
      $(this).prevAll().addClass("no-prazo");
    });
    $("button", $("#btn-progresso")).mouseout(function() {
      $(this).prevAll().removeClass("no-prazo");
      $("#btn-progresso .ativa:last").prevAll().addClass("no-prazo");
    });
    $("button", $("#btn-progresso")).click(function(e) {
      e.preventDefault();
      $("#PercentuaConcluido").val($(this).data("value"));
      $("#btn-progresso .ativa:last").removeClass("principal");
      $(this).nextAll().removeClass("ativa");
      $(this).addClass("ativa");
      $(this).prevAll().addClass("ativa");
      $("#btn-progresso .ativa:last").addClass("principal");
      $("#btn-progresso .principal").nextAll().removeClass("no-prazo");
    });
    return $("#btn-progresso .ativa:last").prevAll().addClass("no-prazo");
  };

  api.atualizarEAdicionarSubAtividade = function(json) {
    var idAtividade, idAtividadeParaAtualizar, idAtividadeSuperior, idPlanoAcao, update;
    idPlanoAcao = json.data.idPlanoDeAcao;
    idAtividadeSuperior = json.data.idAtividadeSuperior;
    idAtividade = json.data.id;
    idAtividadeParaAtualizar = idAtividadeSuperior !== 0 ? idAtividadeSuperior : idAtividade;
    update = json.data.update;
    api.notificarMudanca(idAtividadeParaAtualizar, null, true);
    api.atualizarExibicaoDeSubAtividades(idAtividadeParaAtualizar);
    Atividades.PlanoDeAcao.api.reload(json.data.idPlanoDeAcao, json.data.ideObj);
    if (json.data.formaDeSalvar === 1) {
      return api.criarSubAtividade(idPlanoAcao, idAtividadeSuperior, update);
    }
  };

  api.criarSubAtividade = function(idPlanoAcao, idAtividadeSuperior, update) {
    return $as.Atividades.Atividades.CreateSubAtividade.get({
      idPlanoAcao: idPlanoAcao,
      idAtividadeSuperior: idAtividadeSuperior
    }).done(function(data) {
      return $(update).html(data);
    });
  };

  api.verificarExigenciaDeNotificacao = function(idDaAtividade) {
    return $as.Atividades.PlanosDeAcao.ExigenciaDeNotificao.post({
      idAtividade: idDaAtividade
    }).done(function(data) {
      if (data) {
        return api.mostrarExigenciaDeNotificao(data);
      }
    });
  };

  api.mostrarExigenciaDeNotificao = function(data) {
    var btns, time;
    btns = [];
    time = (data.ComandosDeNotificao.length > 0 ? false : 10000);
    $(data.ComandosDeNotificao).each(function(index, element) {
      return btns.push({
        addClass: element.CssBotao,
        text: element.NomeBotao,
        onClick: function(noty) {
          noty.close();
          if (element.RouteName) {
            return $.ajax({
              type: "POST",
              url: element.RouteName,
              data: element.RouteValues
            }).done(function(result) {
              return $(Atividades.api).trigger("mostrarExigenciaDeNotificao", [result]);
            });
          }
        }
      });
    });
    showBottomNoty(data.MensagemDeNotificacao, time, (btns.length > 0 ? btns : null));
    if (data.ResultValues) {
      return $(Atividades.api).trigger("mostrarExigenciaDeNotificao", [data.ResultValues]);
    }
  };

  return api;

})();

Atividades.api.boot();
