﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.itensDoProgramaDeResultadosController = (function() {
  function itensDoProgramaDeResultadosController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.metodosDoCRUD = bind(this.metodosDoCRUD, this);
    this.metodosDoCRUD();
  }

  itensDoProgramaDeResultadosController.prototype.metodosDoCRUD = function() {
    return window.ItemDoProgramaDeResultados = {
      create: (function(_this) {
        return function() {
          return $as.ItensDoProgramaDeResultados.Create.get({
            idDoPai: _this.options.IdDoPai,
            formaDeCalculoDeRemuneracaoVariavel: $("input[name=FormaDeCalculoDeRemuneracaoVariavel]", _this.contexto).val()
          }).success(function(data) {
            return window.GetDiv("ItensDoProgramaDeResultados-modal-container").html(data);
          });
        };
      })(this),
      reload: (function(_this) {
        return function() {
          return $as.ItensDoProgramaDeResultados.Index.get({
            idDoPai: _this.options.IdDoPai
          }).success(function(data) {
            $('#ItensDoProgramaDeResultados-container').html(data);
            return window.programasDeResultadosController.exibirItensDoProgramaDeResultadosPorFormaDeCalculo(parseInt($("input[name=FormaDeCalculoDeRemuneracaoVariavel]", _this.contexto).val()));
          });
        };
      })(this)
    };
  };

  return itensDoProgramaDeResultadosController;

})();
