﻿$(function() {
  var culture;
  if (Globalize) {
    culture = Globalize.culture($("html").attr("lang"));
    $.fn.datepicker.defaults = {
      language: culture.name
    };
  }
});
