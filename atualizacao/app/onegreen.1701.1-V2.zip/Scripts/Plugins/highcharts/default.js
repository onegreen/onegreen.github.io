﻿window.defaultTheme = {
    setBackGround: function () {
        // Add the background image to the container
        Highcharts.wrap(Highcharts.Chart.prototype, 'getContainer', function (proceed) {
            proceed.call(this);
            this.container.style.background = '';
        });
    },
    chart: {
        backgroundColor: '#fff',
        borderWidth: 0,
        plotBackgroundColor: '#fff',
        plotShadow: false,
        plotBorderColor: '#333',
        plotBorderWidth: 0,
        borderColor: '#ffcc00',
        style: {fontFamily: "'Unica One', sans-serif"}
    },
    title: {
        style: {
            color: 'black',//#3E576F',
            fontSize: '20px'
            
        }
    },
    subtitle: {
        style: {
            color: '#333',
        }
    },
    tooltip: {
        borderWidth: 0
    },
    xAxis: {
        gridLineWidth: 0,
        gridLineColor: '#707073',
        lineColor: '#707073',
        tickColor: '#707073',
        labels: {
            style: {
                color: '#666',
                cursor: 'default',
                fontSize: '11px',
                lineHeight: '14px'
            }
        },
        title: {
            style: {
                color: '#333',
                fontWeight: 'bold'
            }
        },
        minorGridLineColor: '#333',
    },
    yAxis: {
        gridLineColor: '#707073',
        minorTickInterval: null,
        labels: {
            style: {
                color: '#666',
                cursor: 'default',
                fontSize: '11px',
                lineHeight: '14px'
            }
        },
        lineColor: '#707073',
        minorGridLineColor: '#333',
        lineWidth: 1,
        tickWidth: 1,
        tickColor: '#707073',
        tickWidth: 1,
        
        title: {
            style: {
                color: '#333',
                fontWeight: 'bold'
            }
        }
    },
    tooltip: {
        backgroundColor: 'rgba(255, 255, 255, 0.85)',
        style: {
            color: '#333'
        }
    },
    plotOptions: {
        series: {
            shadow: false,
            dataLabels: {
                color: '#000'
            },
            marker: {
                lineColor: '#333'
            }
        },
        boxplot: {
            fillColor: '#333'
        },
        candlestick: {
            lineColor: 'white'
        },
        errorbar: {
            color: 'white'
        }
    },
    legend: {
        itemStyle: {
            color: '#999',
            fontSize: '12px'
        },
        itemHoverStyle: {
            color: 'black'
        },
        itemHiddenStyle: {
            color: '#CCC'
        }
    },
    credits: {
        style: {
            color: '#666'
        }
    },
    labels: {
        style: {
            color: '#3E576F'
        }
    },
    drilldown: {
        activeAxisLabelStyle: {
            color: '#F0F0F3'
        },
        activeDataLabelStyle: {
            color: '#F0F0F3'
        }
    },


    navigation: {
        buttonOptions: {
            theme: {
                stroke: '#000'
            }
        }
    },
    // scroll charts
    rangeSelector: {
        buttonTheme: {
            fill: '#505053',
            stroke: '#000000',
            style: {
                color: '#CCC'
            },
            states: {
                hover: {
                    fill: '#707073',
                    stroke: '#000000',
                    style: {
                        color: 'white'
                    }
                },
                select: {
                    fill: '#000003',
                    stroke: '#000000',
                    style: {
                        color: 'white'
                    }
                }
            }
        },
        inputBoxBorderColor: '#505053',
        inputStyle: {
            backgroundColor: '#333',
            color: 'silver'
        },
        labelStyle: {
            color: 'silver'
        }
    },

    navigator: {
        handles: {
            backgroundColor: '#666',
            borderColor: '#AAA'
        },
        outlineColor: '#CCC',
        maskFill: 'rgba(255,255,255,0.1)',
        series: {
            color: '#7798BF',
            lineColor: '#A6C7ED'
        },
        xAxis: {
            gridLineColor: '#505053'
        }
    },

    scrollbar: {
        barBackgroundColor: '#808083',
        barBorderColor: '#808083',
        buttonArrowColor: '#CCC',
        buttonBackgroundColor: '#606063',
        buttonBorderColor: '#606063',
        rifleColor: '#FFF',
        trackBackgroundColor: '#404043',
        trackBorderColor: '#404043'
    },

    // special colors for some of the
    legendBackgroundColor: 'rgba(0, 0, 0, 0.5)',
    background2: '#505053',
    dataLabelsColor: '#000',
    textColor: '#C0C0C0',
    contrastTextColor: '#F0F0F3',
    maskColor: 'rgba(255,255,255,0.3)'
};
