﻿var maxlength;

this.maxlength || (this.maxlength = {});

maxlength = (function() {
  function maxlength() {}

  maxlength.teclasNoASCIIFirefox = ["Right", "Left", "Backspace", "Del", "ArrowRight", "ArrowLeft", "ArrowUp", "ArrowDown", "Backspace", "Delete", "Tab", "PageUp", "PageDown", "Home", "End"];

  maxlength.newLineCharacterRegexMatch = /\r?\n|\r/g;

  maxlength.verificarTamanhoTexto = function(el) {
    var currtentTextLength, maxLength, new_text, regexResult, text;
    maxLength = el.attr("data-val-length-max");
    text = el.val();
    currtentTextLength = text.length;
    regexResult = text.match(maxlength.newLineCharacterRegexMatch);
    if (regexResult) {
      currtentTextLength += regexResult.length;
    }
    if (currtentTextLength > maxLength) {
      new_text = text.substr(0, maxLength - (regexResult ? regexResult.length : 0));
      el.val(new_text);
    }
  };

  maxlength.limitarTextArea = function(el, e) {
    var code, currentText, currtentTextLength, maxLength, regexResult;
    if (maxlength.teclasNoASCIIFirefox.contains(e.originalEvent.key)) {
      return true;
    }
    maxLength = el.attr("data-val-length-max");
    currentText = el.val();
    currtentTextLength = currentText.length;
    regexResult = currentText.match(maxlength.newLineCharacterRegexMatch);
    if (regexResult) {
      currtentTextLength += regexResult.length;
      $('#lblQtdBreakLines').text(regexResult.length);
    }
    code = e.keyCode || e.which;
    if (code === 13) {
      currtentTextLength += 2;
    } else {
      currtentTextLength += 1;
    }
    return currtentTextLength <= maxLength;
  };

  return maxlength;

})();

$(function() {
  $(document).on("focus", ":input[data-val=true]", function() {
    var el, maxLength, message;
    el = $(this);
    message = el.attr("data-val-length");
    if (message) {
      maxLength = el.attr("data-val-length-max");
      if (maxLength) {
        return el.attr("maxlength", maxLength);
      }
    }
  });
  $(document).on('focus', "textarea[data-val-length-max]", function(e) {
    var $el;
    $el = $(this);
    $el.focusout(function() {
      maxlength.verificarTamanhoTexto($el);
    });
    return $el.keypress(function(e) {
      return maxlength.limitarTextArea($el, e);
    });
  });
  if ($.browser.msie && parseInt($.browser.version, 10) === 8) {
    return $(document).on('keyup', 'textarea[maxlength]', function(e) {
      var maxLength, textarea;
      textarea = $(this).val();
      maxLength = parseInt($(this).attr('maxlength'));
      if (textarea.length > maxLength) {
        $(this).val(textarea.substr(0, maxLength));
        $(this).change();
        return false;
      }
      return true;
    });
  }
});
