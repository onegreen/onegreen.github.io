﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

this.farolController = (function(superClass) {
  extend(farolController, superClass);

  function farolController(options, resource) {
    var dados;
    this.options = options;
    this.resource = resource;
    this.removerDaVisao = bind(this.removerDaVisao, this);
    this.imprimirPdf = bind(this.imprimirPdf, this);
    this.retaurarFilhasDoFarol = bind(this.retaurarFilhasDoFarol, this);
    this.restaurarVisao = bind(this.restaurarVisao, this);
    this.restaurarDesdobramentos = bind(this.restaurarDesdobramentos, this);
    this.comutarFrequencia = bind(this.comutarFrequencia, this);
    this.identarLinha = bind(this.identarLinha, this);
    this.toggleDesdobramentos = bind(this.toggleDesdobramentos, this);
    this.toggleAgrupamento = bind(this.toggleAgrupamento, this);
    this.ativarAgrupamentos = bind(this.ativarAgrupamentos, this);
    this.loadComboUnidadeGerencial = bind(this.loadComboUnidadeGerencial, this);
    this.configurarDatePickerFarolSemanal = bind(this.configurarDatePickerFarolSemanal, this);
    this.configurarDatePickerFarolDiario = bind(this.configurarDatePickerFarolDiario, this);
    this.recarregarFarolMensal = bind(this.recarregarFarolMensal, this);
    this.recarregarFarolDiarioSemanal = bind(this.recarregarFarolDiarioSemanal, this);
    this.mudarFarolParaASemana = bind(this.mudarFarolParaASemana, this);
    this.mudarFarolParaODia = bind(this.mudarFarolParaODia, this);
    this.mudarFarolParaASemanaAnterior = bind(this.mudarFarolParaASemanaAnterior, this);
    this.mudarFarolParaAProximaSemana = bind(this.mudarFarolParaAProximaSemana, this);
    this.mudarFarolParaODiaAnterior = bind(this.mudarFarolParaODiaAnterior, this);
    this.mudarFarolParaOProximoDia = bind(this.mudarFarolParaOProximoDia, this);
    this.configurarFiltroDeIndicador = bind(this.configurarFiltroDeIndicador, this);
    this.esconderDesdobramentos = bind(this.esconderDesdobramentos, this);
    this.esconderDesdobramento = bind(this.esconderDesdobramento, this);
    this.ajustarLinhas = bind(this.ajustarLinhas, this);
    this.eliminarSeparadorRedundantes = bind(this.eliminarSeparadorRedundantes, this);
    this.eliminarInformacoesRedundantes = bind(this.eliminarInformacoesRedundantes, this);
    this.alterarEstado = bind(this.alterarEstado, this);
    this.adicionarLinha = bind(this.adicionarLinha, this);
    this.alterarBotaoDesdobramento = bind(this.alterarBotaoDesdobramento, this);
    this.extrairEssencialParaDesdobramento = bind(this.extrairEssencialParaDesdobramento, this);
    this.construirNovaVisao = bind(this.construirNovaVisao, this);
    this.retornarVisao = bind(this.retornarVisao, this);
    this.adicionarVisao = bind(this.adicionarVisao, this);
    this.desdobrar = bind(this.desdobrar, this);
    this.fecharMenuDesdobramento = bind(this.fecharMenuDesdobramento, this);
    this.carregarMenuDesdobramentos = bind(this.carregarMenuDesdobramentos, this);
    this.ativarDesdobramentos = bind(this.ativarDesdobramentos, this);
    this.comparar = bind(this.comparar, this);
    this.aplicarValoresFarolMensal = bind(this.aplicarValoresFarolMensal, this);
    this.aplicarFarolDiarioSemanalNaLinha = bind(this.aplicarFarolDiarioSemanalNaLinha, this);
    this.aplicarIndicadorDeItensVinculados = bind(this.aplicarIndicadorDeItensVinculados, this);
    this.retornarInfinitoOuValor = bind(this.retornarInfinitoOuValor, this);
    this.aplicarPercentuaisNaLinha = bind(this.aplicarPercentuaisNaLinha, this);
    this.aplicarValoresFarolDiarioSemanal = bind(this.aplicarValoresFarolDiarioSemanal, this);
    this.desdobramentosExecutados = bind(this.desdobramentosExecutados, this);
    this.obterValoresMes = bind(this.obterValoresMes, this);
    this.configurarComutadorDeOcorrenciaSemanal = bind(this.configurarComutadorDeOcorrenciaSemanal, this);
    this.configurarComutadorDeOcorrenciaDiario = bind(this.configurarComutadorDeOcorrenciaDiario, this);
    this.loadIndex = bind(this.loadIndex, this);
    this.resizeGraficoDeIndicadoresSemMeta = bind(this.resizeGraficoDeIndicadoresSemMeta, this);
    this.eventoResizeGraficoDeIndicadoresSemMeta = bind(this.eventoResizeGraficoDeIndicadoresSemMeta, this);
    this.fixarAreaDeResultados = bind(this.fixarAreaDeResultados, this);
    this.binds = bind(this.binds, this);
    farolController.__super__.constructor.call(this, this.options);
    this.binds();
    window.MarcarMenuSuperior("#lnkFarolDeIndicador");
    this.options.mesSelecionado = this.options.MesSelecionado;
    this.linhaSelecionada;
    this.ComutadorDeFrequencia = $("#TabelaCabecalhoFarol .js-comutador-frequencia");
    this.loadIndex();
    this.configurarFiltroDeIndicador();
    this.compararCom = this.options.CompararCom;
    this.compararDe = this.options.CompararDe;
    this.farolAcumulado = false;
    this.farolTendencia = false;
    window.filtroUGEPlanoDeGestao.configurar('#filtro-ug-topo', window.farolController.alterarUnidade, window.farolController.alterarPlanoDeGestao);
    window.filtroAvancadoDeIndicadoresController.origem = Results.api.Origem.Farol;
    if (this.options.IdDoIndicadorParaAbrir != null) {
      dados = $('.js-farol').filter("[data-idindicador=" + this.options.IdDoIndicadorParaAbrir + "]").data();
      dados = this.normalizarDadosDaLinha(dados);
      Results.api.exibirDetalhesDoIndicador(dados, this.options.mesSelecionado);
    }
    $("[ rel='tooltip']").tooltip();
    this.visao = new Array();
    this.VisaoAplicada = this.options.VisaoAplicada;
    this.restaurarDesdobramentos(this.VisaoAplicada);
    this.restaurarVisao(this.VisaoAplicada, this.visao);
    this.retaurarFilhasDoFarol();
  }

  farolController.prototype.binds = function() {
    $(document).on('show.bs.dropdown', (function(_this) {
      return function(event) {
        return _this.fecharMenuDesdobramento(event);
      };
    })(this));
    $(document).on("click", (function(_this) {
      return function(event) {
        return _this.fecharMenuDesdobramento(event);
      };
    })(this));
    $(window).resize(this.eventoResizeGraficoDeIndicadoresSemMeta);
    $('#ImprimirPdf').click(this.imprimirPdf);
    return $(".js-fixar-area", this.options.Contexto).click(this.fixarAreaDeResultados);
  };

  farolController.prototype.fixarAreaDeResultados = function(event) {
    var elemento;
    elemento = $(event.delegateTarget);
    return $as.Performance.FiltroDeIndicadores.MudarAreaDeResultados.post({
      idDaAreaDeResultados: elemento.data('area-id'),
      nomeDaAreaDeResultado: elemento.data('area-nome'),
      removerDoFiltro: elemento.find('i').hasClass('desafixar')
    }).done((function(_this) {
      return function(data) {
        if (data.success) {
          return window.reload();
        }
      };
    })(this));
  };

  farolController.prototype.eventoResizeGraficoDeIndicadoresSemMeta = function() {
    if (this.timeOut) {
      clearTimeout(this.timeOut);
    }
    return this.timeOut = setTimeout(this.resizeGraficoDeIndicadoresSemMeta, 200);
  };

  farolController.prototype.resizeGraficoDeIndicadoresSemMeta = function() {
    var divs, grafico, i, j, k, len, ref, ref1, results;
    divs = $('#ContextoDaTabelaFarol').find('.js-grafico-acompanhamento-real');
    if (divs.length > 0) {
      for (i = j = 0, ref = divs.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
        $(divs[i]).height($(divs[i]).parent().height());
      }
      ref1 = this.graficos;
      results = [];
      for (k = 0, len = ref1.length; k < len; k++) {
        grafico = ref1[k];
        results.push(grafico.reflow());
      }
      return results;
    }
  };

  farolController.prototype.loadIndex = function() {
    $("#semanalAcumulada, #diariaAcumulada", this.ComutadorDeFrequencia).remove();
    $('#TabelaCabecalhoFarol .js-comparar').find('li').unbind('click').click(this.comparar);
    this.ComutadorDeFrequencia.find("li").unbind('click').click(this.comutarFrequencia);
    this.ativarDesdobramentos();
    this.ativarAgrupamentos();
    return this.estado = {};
  };

  farolController.prototype.configurarComutadorDeOcorrenciaDiario = function() {
    $("#proximoDia").click(this.mudarFarolParaOProximoDia);
    $("#diaAnterior").click(this.mudarFarolParaODiaAnterior);
    return this.configurarDatePickerFarolDiario();
  };

  farolController.prototype.configurarComutadorDeOcorrenciaSemanal = function() {
    $("#proximaSemana").click(this.mudarFarolParaAProximaSemana);
    $("#semanaAnterior").click(this.mudarFarolParaASemanaAnterior);
    return this.configurarDatePickerFarolSemanal();
  };

  farolController.prototype.obterValoresMes = function(event) {
    this.options.mesSelecionado = $(event.delegateTarget).data("mes");
    swIntercom('Mudou o Mês no Farol', {
      mes: this.options.mesSelecionado
    });
    return $as.Performance.FiltroDeIndicadores.MudarOcorrencia.post({
      ocorrencia: this.options.mesSelecionado
    }).done(this.recarregarFarolMensal);
  };

  farolController.prototype.desdobramentosExecutados = function() {
    var desdobramentos, key, ref, visao;
    desdobramentos = new Array();
    ref = this.estado;
    for (key in ref) {
      visao = ref[key];
      desdobramentos.push({
        IdIndicador: visao.IdIndicador,
        IdIndicadorBase: visao.IdIndicadorBase,
        IdUnidade: visao.IdUnidade,
        IdIndicadorDeOrigem: visao.IdIndicadorDeOrigem,
        Tipo: visao.Tipo,
        IdTipoDeDesdobramento: visao.IdTipoDeDesdobramento,
        DimensaoADesdobrar: visao.DimensaoADesdobrar,
        Dimensao1: visao.Dimensao1,
        Dimensao2: visao.Dimensao2,
        Dimensao3: visao.Dimensao3,
        Dimensao4: visao.Dimensao4,
        Dimensao5: visao.Dimensao5,
        Dimensao6: visao.Dimensao6
      });
    }
    return desdobramentos;
  };

  farolController.prototype.aplicarValoresFarolDiarioSemanal = function(valores) {
    $(".js-farol").each((function(_this) {
      return function() {
        var linhaCompararCom, linhaCompararDe, meta, metaAcumulada, valor;
        linhaCompararDe = $( this );
        if (linhaCompararDe.attr('id')) {
          linhaCompararCom = linhaCompararDe.next();
          valor = valores[linhaCompararDe.data('referencia')];
          if (!valor) {
            valor = {
              TextoReal: "-",
              TextoRealAcumulado: "-",
              TextoMeta: "-",
              TextoMetaAcumulado: "-",
              TextoPercentual: "-",
              TextoMetaInferior: "-",
              TextoMetaSuperior: "-",
              TextoRealizadoRitmo: "-",
              TextoMetaRitmo: "-",
              TextoPercentualTendencia: "-"
            };
          }
          $('.js-farol-real', linhaCompararDe).html(valor.TextoReal);
          $('.js-farol-real-acumulado', linhaCompararDe).html(valor.TextoRealAcumulado);
          $('.js-farol-real-ritmo', linhaCompararDe).html(valor.TextoRealizadoRitmo);
          $('.js-farol-meta-ritmo', linhaCompararCom).html(valor.TextoMetaRitmo);
          $('.js-tipoValorDe', linhaCompararDe).html(_this.options.TiposDeValor[_this.compararDe]);
          if (linhaCompararCom.data('entrefaixas')) {
            $('.js-tipoValorCom', linhaCompararCom).html(_this.options.TiposDeValor.Meta);
            meta = valor.TextoMetaInferior + "<br/>" + valor.TextoMetaSuperior;
            metaAcumulada = valor.TextoMetaInferiorAcumulado + "<br/>" + valor.TextoMetaSuperiorAcumulado;
          } else {
            if (linhaCompararDe.data('aceitacenario') && (_this.compararCom === "Programado" || _this.compararCom === 'Projetado')) {
              $('.js-tipoValorCom', linhaCompararCom).html(_this.options.TiposDeValor[_this.compararCom]);
            } else if (!['LimiteInferior', 'LimiteSuperior', 'Minimo', 'MaxDesafio'].contains(_this.compararCom)) {
              $('.js-tipoValorCom', linhaCompararCom).html(_this.options.TiposDeValor[_this.compararCom]);
            } else {
              $('.js-tipoValorCom', linhaCompararCom).html(_this.options.TiposDeValor.Meta);
            }
            meta = valor.TextoMeta;
            metaAcumulada = valor.TextoMetaAcumulado;
          }
          $('.js-farol-meta', linhaCompararCom).html(meta);
          $('.js-farol-meta-acumulado', linhaCompararCom).html(metaAcumulada);
          _this.aplicarFarolDiarioSemanalNaLinha($('.js-farol-real', linhaCompararDe), valor.Farois["Farol"].substring(1));
          _this.aplicarFarolDiarioSemanalNaLinha($('.js-farol-real-acumulado', linhaCompararDe), valor.Farois["FarolAcumulado"].substring(1));
          _this.aplicarFarolDiarioSemanalNaLinha($('.js-farol-real-ritmo', linhaCompararDe), valor.Farois["FarolRitmo"].substring(1));
          _this.aplicarPercentuaisNaLinha($(".popover-percentual-js", linhaCompararDe), valor);
          return _this.aplicarIndicadorDeItensVinculados($('.js-farol-real', linhaCompararDe), valor);
        }
      };
    })(this));
    $("[ rel='tooltip']").tooltip();
    return this.configurarBindDetalhesIndicador($('#ContextoDaTabelaFarol'));
  };

  farolController.prototype.aplicarPercentuaisNaLinha = function(elemento, valor) {
    return elemento.data("vp", this.retornarInfinitoOuValor(valor.TextoVariacaoPercentual)).data("vpa", this.retornarInfinitoOuValor(valor.TextoVariacaoPercentualAcumulado)).data("pa", this.retornarInfinitoOuValor(valor.TextoPercentualDeAtingimento)).data("paa", this.retornarInfinitoOuValor(valor.TextoPercentualDeAtingimentoAcumulado)).data("vpt", this.retornarInfinitoOuValor(valor.TextoVariacaoPercentualTendencia)).data("pat", this.retornarInfinitoOuValor(valor.TextoPercentualDeAtingimentoTendencia));
  };

  farolController.prototype.retornarInfinitoOuValor = function(valor) {
    if (valor.indexOf("-999") !== -1) {
      return "<i class='sw-infinito'></i>";
    } else {
      return valor;
    }
  };

  farolController.prototype.aplicarIndicadorDeItensVinculados = function(elemento, valor) {
    var icone;
    icone = '<a data-abapadrao="comentarios" class="js-exibir-detalhes-indicador-mensal"> <i rel="tooltip" title="" class="sw-caret  cursor-pointer" data-original-title="' + this.resource.ItensVinculados + '"></i> </a>';
    if (valor.Farois["Farol"].substring(0, 1) > 0 && !valor.Virtual) {
      return elemento.append(icone);
    }
  };

  farolController.prototype.aplicarFarolDiarioSemanalNaLinha = function(elemento, farol) {
    elemento.removeClass('meta-vermelha meta-amarela meta-verde meta-azul meta-neutra');
    switch (farol) {
      case "0":
        return elemento.addClass('meta-vermelha');
      case "1":
        return elemento.addClass('meta-amarela');
      case "2":
        return elemento.addClass('meta-verde');
      case "3":
        return elemento.addClass('meta-azul');
      case "9":
        return elemento.addClass('meta-neutra');
    }
  };

  farolController.prototype.aplicarValoresFarolMensal = function(valores) {
    var farol, j, len, linha, linhas, referencia, results, textoMeta, textoReal, valor;
    linhas = $('.js-farol');
    if (this.farolTendencia) {
      $('#TabelaCabecalhoFarol').find('#toggleReal').addClass('none');
      $('#TabelaCabecalhoFarol').find('#toggleTendencia').removeClass('none');
    } else {
      $('#TabelaCabecalhoFarol').find('#toggleReal').removeClass('none');
      $('#TabelaCabecalhoFarol').find('#toggleTendencia').addClass('none');
    }
    results = [];
    for (j = 0, len = linhas.length; j < len; j++) {
      linha = linhas[j];
      linha = $(linha);
      valor = valores[linha.data('referencia')];
      if (!valor) {
        valor = {
          TextoReal: "-",
          TextoMeta: "-",
          TextoPercentual: "-",
          TextoMetaInferior: "-",
          TextoMetaSuperior: "-"
        };
      }
      textoReal;
      textoMeta;
      if (this.farolTendencia) {
        textoReal = valor.TextoRealizadoRitmo;
      } else {
        textoReal = valor.TextoReal;
      }
      if ($('.js-farol-meta', linha).data('entrefaixas')) {
        if (this.farolTendencia) {
          textoMeta = "" + valor.TextoMetaInferiorDaTendencia + "<br/>" + valor.TextoMetaSuperiorDaTendencia;
        } else {
          textoMeta = "" + valor.TextoMetaInferior + "<br/>" + valor.TextoMetaSuperior;
        }
      } else {
        if (this.farolTendencia) {
          textoMeta = valor.TextoMetaRitmo;
        } else {
          textoMeta = valor.TextoMeta;
        }
      }
      if (this.farolTendencia) {
        $('.js-farol-percentual', linha).html(valor.PercentualTendenciaEhInfinito ? "<i class='sw-infinito'></i>" : valor.TextoPercentualTendencia);
      } else {
        $('.js-farol-percentual', linha).html(valor.PercentualEhInfinito ? "<i class='sw-infinito'></i>" : valor.TextoPercentual);
      }
      $('.js-farol-real', linha).html(textoReal);
      $('.js-farol-meta', linha).html(textoMeta);
      if (!valor.PossuiApenasReal) {
        results.push((function() {
          var ref, results1;
          ref = valor.Farois;
          results1 = [];
          for (referencia in ref) {
            farol = ref[referencia];
            $(".js-valor-" + referencia + " .js-cor-farol", linha).attr('class', "sw-farol0" + (farol.substring(1)) + " font14 va-middle js-cor-farol");
            $('.js-farol-acumulado .js-cor-farol', linha).attr('class', "sw-farol0" + (valor.Farois['FarolAcumulado'].substring(1)) + " font14 va-middle js-cor-farol");
            results1.push($('.js-farol-ritmo .js-cor-farol', linha).attr('class', "sw-farol0" + (valor.Farois['FarolRitmo'].substring(1)) + " font14 va-middle js-cor-farol"));
          }
          return results1;
        })());
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  farolController.prototype.comparar = function(event) {
    var parametros, tipo;
    tipo = $(event.delegateTarget).data('tipo');
    parametros = {
      compararDe: $(event.delegateTarget).data("compararde") || $(".js-labelpercentual").data('compararde'),
      compararCom: $(event.delegateTarget).data("compararcom") || $(".js-labelpercentual").data('compararcom'),
      cenario: $(event.delegateTarget).data("cenario"),
      mes: this.options.mesSelecionado,
      desdobramentos: this.desdobramentosExecutados(),
      farolAcumulado: this.farolAcumulado
    };
    this.compararCom = parametros.compararCom ? parametros.compararCom : this.compararCom;
    this.compararDe = parametros.compararDe ? parametros.compararDe : this.compararDe;
    return $as.Performance.FarolDeIndicadores.Comparar.postJson(JSON.stringify(parametros)).done((function(_this) {
      return function(resultado) {
        if (_this.options.Frequencia === 'Mensal') {
          _this.aplicarValoresFarolMensal(resultado);
          $(".js-labelpercentual").data('compararde', _this.compararDe).data('compararcom', _this.compararCom);
        } else {
          _this.aplicarValoresFarolDiarioSemanal(resultado);
        }
        $(".js-label" + tipo).html($(event.delegateTarget).data("label"));
        return swIntercom('Mudou a forma de comparação no Farol', {
          compararCom: _this.compararCom,
          comparaDe: _this.comparaDe
        });
      };
    })(this));
  };

  farolController.prototype.ativarDesdobramentos = function() {
    $('.js-menu-desdobramentos').unbind('click').click(this.carregarMenuDesdobramentos);
    return $('.js-esconder-desdobramentos').unbind('click').click(this.esconderDesdobramento);
  };

  farolController.prototype.carregarMenuDesdobramentos = function(event) {
    var botao, containerMenu, informacoes;
    botao = $(event.delegateTarget);
    informacoes = this.normalizarDadosDaLinha(botao.closest('.js-farol').data());
    containerMenu = $('.js-container-desdobramentos', botao.closest('.js-menu-desdobramentos-container'));
    containerMenu.hide();
    if ($('li', containerMenu).length) {
      return containerMenu.html('');
    } else {
      return $as.Performance.FarolDeIndicadores.MenuParaDesdobramentos.get(informacoes).done((function(_this) {
        return function(html) {
          containerMenu.html(html);
          $('.js-desdobrar-indicador').unbind('click').click(_this.desdobrar);
          _this.ativarDesdobramentos();
          if ($('.js-desdobrar-indicador', containerMenu).length === 1) {
            $('.js-desdobrar-indicador a', containerMenu).click();
          } else {
            containerMenu.show();
          }
          return swIntercom('Tentativa de desdobramento');
        };
      })(this));
    }
  };

  farolController.prototype.fecharMenuDesdobramento = function(event) {
    var botao;
    if (!($(event.target).hasClass("js-container-desdobramentos") || $(event.target).parent().hasClass("js-desdobrar-indicador"))) {
      botao = $('.js-container-desdobramentos[style]:visible').parent().children('.js-menu-desdobramentos');
      return botao.click();
    }
  };

  farolController.prototype.desdobrar = function(event) {
    var botao, informacoes, linhaSelecionada;
    botao = $(event.delegateTarget);
    linhaSelecionada = botao.closest('.js-farol');
    informacoes = this.normalizarDadosDaLinha(linhaSelecionada.data());
    informacoes.IdTipoDeDesdobramento = botao.data('item');
    informacoes.Tipo = botao.data('tipo');
    informacoes.DimensaoADesdobrar = botao.data('dimensao');
    informacoes.ExibirTendencia = $('#TabelaCabecalhoFarol').data('tendencia') === 'True';
    informacoes.FarolAcumulado = this.farolAcumulado;
    return $as.Performance.FarolDeIndicadores.DesdobrarIndicador.get(informacoes).done((function(_this) {
      return function(html) {
        var menu, visao;
        html = $($.parseHTML(html));
        if (!_this.options.TiposDeDesdobramentoQueNaoOcultamInformacoes.contains(informacoes.TipoDeDesdobramento)) {
          html = _this.eliminarInformacoesRedundantes(informacoes, html);
        }
        visao = _this.alterarEstado(informacoes, html, linhaSelecionada);
        _this.adicionarLinha(html, linhaSelecionada, visao.Hierarquia + 1);
        _this.alterarBotaoDesdobramento(botao);
        _this.ativarDesdobramentos();
        if (!(_this.farolAcumulado || _this.farolTendencia)) {
          _this.marcarColunasDoMesSelecionado();
        } else {
          if (_this.farolAcumulado) {
            $('#ContextoDaTabelaFarol .js-tabela-farol').find('.js-farol-acumulado').addClass('selecionado');
          } else if (_this.farolTendencia) {
            $('#ContextoDaTabelaFarol .js-tabela-farol').find('.js-farol-ritmo').addClass('selecionado');
          }
        }
        $('#ContextoDaTabelaFarol').find('.js-tabela-farol').find('tr').unbind('click').click(_this.selecionarLinha);
        _this.configurarGraficos(html);
        menu = $('.js-container-desdobramentos', botao.closest('.js-menu-desdobramentos-container'));
        menu.html('');
        menu.hide();
        _this.ativarMenuIndicador();
        $("[ rel='tooltip']").tooltip();
        _this.adicionarVisao(linhaSelecionada, informacoes, html);
        linhaSelecionada.trigger('aoDesdobrar', [linhaSelecionada, html]);
        swIntercom('Desdobrou um indicador', {
          tipo: informacoes.Tipo,
          dimensao: informacoes.DimensaoADesdobrar
        });
      };
    })(this));
  };

  farolController.prototype.adicionarVisao = function(linha, desdobramento, html) {
    var info, j, len, linhaFilha, results;
    info = this.retornarVisao(linha.attr('id'), this.visao);
    if (!info) {
      info = this.construirNovaVisao(linha);
      this.visao.push(info);
    }
    info.Desdobramento = this.extrairEssencialParaDesdobramento(desdobramento);
    results = [];
    for (j = 0, len = html.length; j < len; j++) {
      linhaFilha = html[j];
      linhaFilha = $(linhaFilha);
      if (linhaFilha.is('tr') && linhaFilha.attr('id')) {
        results.push(info.Desdobramento.Farois.push(this.construirNovaVisao(linhaFilha)));
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  farolController.prototype.retornarVisao = function(guid, visoes) {
    var info, j, len, visao;
    for (j = 0, len = visoes.length; j < len; j++) {
      visao = visoes[j];
      if (visao.GUID === guid) {
        return visao;
      }
      if (visao.Desdobramento && visao.Desdobramento.Farois) {
        info = this.retornarVisao(guid, visao.Desdobramento.Farois);
        if (info) {
          return info;
        }
      }
    }
    return false;
  };

  farolController.prototype.construirNovaVisao = function(linha) {
    return {
      GUID: linha.attr('id'),
      IdIndicador: linha.data('idindicador'),
      IdDoIndicadorBase: linha.data('idindicadorbase'),
      Referencia: linha.data('referencia'),
      Desdobramento: null
    };
  };

  farolController.prototype.extrairEssencialParaDesdobramento = function(desdobramento) {
    return {
      Dimensao1: desdobramento.Dimensao1,
      Dimensao2: desdobramento.Dimensao2,
      Dimensao3: desdobramento.Dimensao3,
      Dimensao4: desdobramento.Dimensao4,
      Dimensao5: desdobramento.Dimensao5,
      Dimensao6: desdobramento.Dimensao6,
      DimensaoADesdobrar: desdobramento.DimensaoADesdobrar,
      IdTipoDeDesdobramento: desdobramento.IdTipoDeDesdobramento,
      IdIndicador: desdobramento.IdIndicador,
      IdIndicadorBase: desdobramento.IdIndicadorBase,
      IdIndicadorDeOrigem: desdobramento.IdIndicadorDeOrigem,
      IdUnidade: desdobramento.IdUnidade,
      Tipo: desdobramento.Tipo,
      TipoDeDesdobramento: desdobramento.TipoDeDesdobramento,
      Farois: new Array()
    };
  };

  farolController.prototype.alterarBotaoDesdobramento = function(botao) {
    var botaoDesdobrar, botaoEsconder, pai;
    pai = botao.closest('.js-menu-desdobramentos-container');
    botaoDesdobrar = $('.js-menu-desdobramentos', pai);
    botaoEsconder = $('.js-esconder-desdobramentos', pai);
    botaoDesdobrar.hide();
    return botaoEsconder.show();
  };

  farolController.prototype.adicionarLinha = function(html, linhaSelecionada, hierarquia) {
    var identificadorDaLinha, tabela;
    html.data('hierarquia', hierarquia);
    html.attr('data-hierarquia', hierarquia);
    html.addClass('linha-desdobrada-farol');
    this.identarLinha(html, hierarquia);
    tabela = linhaSelecionada.closest("table");
    identificadorDaLinha = linhaSelecionada.data("identificadordalinha");
    linhaSelecionada = $("[data-identificadordalinha=" + identificadorDaLinha + "]:last", tabela);
    linhaSelecionada.after(html);
    return this.configurarBindDetalhesIndicador(html);
  };

  farolController.prototype.alterarEstado = function(informacoes, html, linhaSelecionada) {
    var j, len, linha, visao;
    visao = informacoes;
    visao.Id = linhaSelecionada.attr('id');
    visao.Filhas = new Array();
    for (j = 0, len = html.length; j < len; j++) {
      linha = html[j];
      linha = $(linha);
      if (linha.is('tr') && linha.attr('id')) {
        linha = this.eliminarSeparadorRedundantes(linha);
        visao.Filhas.push(linha.attr('id'));
      }
    }
    this.estado["" + visao.Id] = visao;
    return visao;
  };

  farolController.prototype.eliminarInformacoesRedundantes = function(informacoes, html) {
    var farol, j, len, nomeDoIndicador, partesDoNome, ref;
    $("[data-idunidade=" + informacoes.IdUnidade + "]", $(html)).remove();
    $("[data-idunidade=" + window.FiltroAvancadoDeIndicador.IdDaUnidade + "]", $(html)).remove();
    $("span[data-unidadedemedida='" + informacoes.UnidadeDeMedida + "']", $(html)).remove();
    nomeDoIndicador = $("[data-idindicadorbase=" + informacoes.IdIndicadorBase + "]", $(html));
    if (nomeDoIndicador.length > 0) {
      $("[data-tipoindicador]", $(html)).remove();
      nomeDoIndicador.hide();
    }
    $("[data-tipoindicador=" + informacoes.IdIndicadorBase + informacoes.SiglaDoTipoDeIndicador + "]", $(html)).remove();
    $("i.sw-" + (informacoes.SinalMelhor.toLowerCase()), $(html)).remove();
    $("[data-iddimensao=" + informacoes.Dimensao1 + "]", $(html)).remove();
    $("[data-iddimensao=" + informacoes.Dimensao2 + "]", $(html)).remove();
    $("[data-iddimensao=" + informacoes.Dimensao3 + "]", $(html)).remove();
    $("[data-iddimensao=" + informacoes.Dimensao4 + "]", $(html)).remove();
    $("[data-iddimensao=" + informacoes.Dimensao5 + "]", $(html)).remove();
    $("[data-iddimensao=" + informacoes.Dimensao6 + "]", $(html)).remove();
    ref = $(html).filter('.js-farol');
    for (j = 0, len = ref.length; j < len; j++) {
      farol = ref[j];
      farol = $(farol);
      partesDoNome = $('.js-parte-nome-indicador', farol);
      if (partesDoNome.length === 1) {
        partesDoNome.show();
      }
    }
    return html;
  };

  farolController.prototype.eliminarSeparadorRedundantes = function(tr) {
    if ($("span[data-iddimensao]", tr).length <= 1) {
      $("span.separadorDimensao", tr).remove();
    }
    if ($("span[data-tipoindicador]", tr).next().length === 0) {
      $("span.separadorTipo", tr).remove();
    }
    return tr;
  };

  farolController.prototype.ajustarLinhas = function(contexto) {
    $('.tabela-desdobramento-farol .js-farol').unbind('click').click(this.selecionarLinha);
    $('.tabela-desdobramento-farol', contexto).css('border', 'none');
    $('.tabela-desdobramento-farol td:first', contexto).css('border-left', 'none');
    $('.tabela-desdobramento-farol td:last', contexto).css('border-right', 'none');
    $('.tabela-desdobramento-farol tr:first', contexto).css('border-top', 'none');
    return $('.tabela-desdobramento-farol tr:last', contexto).css('border-bottom', 'none');
  };

  farolController.prototype.esconderDesdobramento = function(event) {
    var botao, filha, id, j, len, linha, ref;
    botao = $(event.delegateTarget);
    linha = $(event.delegateTarget).closest('tr');
    id = linha.attr('id');
    ref = this.estado[id].Filhas;
    for (j = 0, len = ref.length; j < len; j++) {
      filha = ref[j];
      this.esconderDesdobramentos(filha);
    }
    this.estado[id].Filhas = new Array();
    botao.hide();
    $("#desdobramento-" + id).remove();
    $('.js-menu-desdobramentos', botao.parent()).show();
    this.removerDaVisao(id, this.visao);
    return linha.trigger('aoEsconderDesdobramento', [linha]);
  };

  farolController.prototype.esconderDesdobramentos = function(id) {
    var filha, j, len, ref;
    if (this.estado[id]) {
      ref = this.estado[id].Filhas;
      for (j = 0, len = ref.length; j < len; j++) {
        filha = ref[j];
        this.esconderDesdobramentos(filha);
      }
    }
    return $("[data-identificadordalinha=" + id + "]").remove();
  };

  farolController.prototype.configurarFiltroDeIndicador = function() {
    return window.FiltroAvancadoDeIndicador = this.options.FiltroAvancado;
  };

  farolController.prototype.mudarFarolParaOProximoDia = function() {
    return $as.Performance.FiltroDeIndicadores.ProximoDia.post().done(this.recarregarFarolDiarioSemanal);
  };

  farolController.prototype.mudarFarolParaODiaAnterior = function() {
    return $as.Performance.FiltroDeIndicadores.DiaAnterior.post().done(this.recarregarFarolDiarioSemanal);
  };

  farolController.prototype.mudarFarolParaAProximaSemana = function() {
    return $as.Performance.FiltroDeIndicadores.ProximaSemana.post().done(this.recarregarFarolDiarioSemanal);
  };

  farolController.prototype.mudarFarolParaASemanaAnterior = function() {
    return $as.Performance.FiltroDeIndicadores.SemanaAnterior.post().done(this.recarregarFarolDiarioSemanal);
  };

  farolController.prototype.mudarFarolParaODia = function() {
    return $as.Performance.FiltroDeIndicadores.MudarDia.post({
      dataDoFiltro: $('#DataDoFiltro').val()
    }).done(this.recarregarFarolDiarioSemanal);
  };

  farolController.prototype.mudarFarolParaASemana = function() {
    return $as.Performance.FiltroDeIndicadores.MudarSemana.post({
      dataDoFiltro: $('#DataDoFiltro').val()
    }).done(this.recarregarFarolDiarioSemanal);
  };

  farolController.prototype.recarregarFarolDiarioSemanal = function(data) {
    var parametros;
    if (this.options.Frequencia === 'Diaria') {
      $('#data-farol-diario-container').html(data);
      this.configurarComutadorDeOcorrenciaDiario();
      this.options.mesSelecionado = $('#data-farol-diario-container').find('#diaSelecionado').val();
      this.options.NumeroDoMes = $('#data-farol-diario-container').find('#numeroDoMes').val();
    } else {
      $('#data-farol-semanal-container').html(data);
      this.configurarComutadorDeOcorrenciaSemanal();
      this.options.mesSelecionado = $('#data-farol-semanal-container').find('#semanaSelecionada').val();
    }
    parametros = this.desdobramentosExecutados();
    return $as.Performance.FarolDeIndicadores.RecarregarFarolDiarioSemanal.postJson(JSON.stringify(parametros)).done(this.aplicarValoresFarolDiarioSemanal);
  };

  farolController.prototype.recarregarFarolMensal = function(data) {
    var parametros;
    parametros = {
      desdobramentos: this.desdobramentosExecutados(),
      farolAcumulado: this.farolAcumulado
    };
    return $as.Performance.FarolDeIndicadores.RecarregarFarolMensal.postJson(JSON.stringify(parametros)).done(this.aplicarValoresFarolMensal);
  };

  farolController.prototype.configurarDatePickerFarolDiario = function() {
    var onChangeFunction;
    onChangeFunction = (function(_this) {
      return function() {
        return _this.mudarFarolParaODia();
      };
    })(this);
    return $('#date-picker-diario-farol').click(function() {
      return DatePickerCustom.setDatePickerCustom('date-picker-diario-farol', 'data-farol-diario-container', 'DataDoFiltro', onChangeFunction, $('#DataDoFiltro').val(), window.FiltroAvancadoDeIndicador.DataInicioLimite, window.FiltroAvancadoDeIndicador.DataFinalLimite);
    });
  };

  farolController.prototype.configurarDatePickerFarolSemanal = function() {
    var onChangeFunction;
    onChangeFunction = (function(_this) {
      return function() {
        return _this.mudarFarolParaASemana();
      };
    })(this);
    return $('#date-picker-semanal-farol').click(function() {
      DatePickerCustom.setDatePickerCustom('date-picker-semanal-farol', 'data-farol-semanal-container', 'DataDoFiltro', onChangeFunction, $('#DataDoFiltro').val(), window.FiltroAvancadoDeIndicador.DataInicioLimite, window.FiltroAvancadoDeIndicador.DataFinalLimite, true);
      return $('#date-smart-picker', '#modal-smart-picker').datepicker('setDaysOfWeekDisabled', []);
    });
  };

  farolController.prototype.loadComboUnidadeGerencial = function() {
    var funcao;
    funcao = function() {
      return window.farolController.atualizarFarol();
    };
    return setCombo('#farol-indicadores', '#NomeDaUnidade', funcao);
  };

  farolController.prototype.ativarAgrupamentos = function() {
    return $('.js-menu-agrupamento').unbind('click').click(this.toggleAgrupamento);
  };

  farolController.prototype.toggleAgrupamento = function(e) {
    var $element, $icone, $table, abrindo, agruparPor, j, len, linha, ref;
    $element = $(e.delegateTarget);
    $icone = $("i", $element);
    $table = $element.closest('table');
    agruparPor = $element.closest('tr').data('agruparpor');
    abrindo = false;
    if ($icone.hasClass('fa-plus-square')) {
      $icone.removeClass('fa-plus-square');
      $icone.addClass('fa-minus-square');
      abrindo = true;
    } else {
      $icone.removeClass('fa-minus-square');
      $icone.addClass('fa-plus-square');
    }
    ref = $("tr.js-agrupamento-" + agruparPor + ".js-farol", $table);
    for (j = 0, len = ref.length; j < len; j++) {
      linha = ref[j];
      linha = $(linha);
      this.identarLinha(linha, linha.data('hierarquia'));
      this.toggleDesdobramentos(linha, $table);
    }
    if (abrindo) {
      console.log(abrindo);
      return this.resizeGraficoDeIndicadoresSemMeta();
    }
  };

  farolController.prototype.toggleDesdobramentos = function(linha, table) {
    var filha, id, j, len, ref, results;
    linha.toggle();
    id = linha.attr('id');
    if (this.estado[id]) {
      ref = this.estado[id].Filhas;
      results = [];
      for (j = 0, len = ref.length; j < len; j++) {
        filha = ref[j];
        results.push(this.toggleDesdobramentos($("#" + filha, table)));
      }
      return results;
    }
  };

  farolController.prototype.identarLinha = function(linha, hierarquia) {
    var margin;
    margin = 30 * hierarquia;
    return $('.js-nome-farol', linha).css('padding-left', margin + "px");
  };

  farolController.alterarUnidade = function(idDaUnidade) {
    return $as.Performance.FiltroDeIndicadores.MudarUnidadeGerencial.post({
      idDaUnidade: idDaUnidade
    }, {
      global: false
    }).done(function(data) {
      swIntercom('Mudou de unidade pelo Farol');
      return window.reload();
    });
  };

  farolController.alterarPlanoDeGestao = function(idDoPlanoDeGestao) {
    return $as.Performance.FiltroDeIndicadores.MudarPlanoDeGestao.post({
      idDoPlanoDeGestao: idDoPlanoDeGestao
    }, {
      global: false
    }).done(function(data) {
      swIntercom('Mudou de plano de gestão pelo Farol');
      return window.reload();
    });
  };

  farolController.prototype.comutarFrequencia = function(event) {
    var $elemento, formaDeVisualizacao, frequencia;
    $elemento = $(event.delegateTarget);
    frequencia = $elemento.data('frequencia');
    formaDeVisualizacao = $elemento.data('visualizacao');
    return $as.Performance.FiltroDeIndicadores.MudarFrequencia.post({
      frequencia: frequencia,
      formaDeVisualizacao: formaDeVisualizacao
    }, {
      global: false
    }).done(function(data) {
      swIntercom('Mudou de frequencia pelo Farol', {
        frequencia: frequencia
      });
      return window.reload();
    });
  };

  farolController.recarregarFarol = function() {
    return $as.Performance.FarolDeIndicadores.Index.get().success(function(data) {
      return $("#main").html(data);
    });
  };

  farolController.prototype.restaurarDesdobramentos = function(visoes) {
    var j, len, results, visao;
    results = [];
    for (j = 0, len = visoes.length; j < len; j++) {
      visao = visoes[j];
      if (visao.Desdobramento && visao.Desdobramento.GUID) {
        this.estado[visao.Desdobramento.GUID] = visao.Desdobramento;
        this.estado[visao.Desdobramento.GUID].Filhas = new Array();
        if (visao.Desdobramento.Farois) {
          results.push(this.restaurarDesdobramentos(visao.Desdobramento.Farois));
        } else {
          results.push(void 0);
        }
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  farolController.prototype.restaurarVisao = function(visoes, visaoPai) {
    var farol, j, len, visao;
    if (!visaoPai) {
      visaoPai = this.visao;
    }
    for (j = 0, len = visoes.length; j < len; j++) {
      visao = visoes[j];
      if (visao.Desdobramento && visao.Desdobramento.GUID) {
        farol = {
          GUID: visao.Desdobramento.GUID,
          Desdobramento: $.extend({}, visao.Desdobramento, {
            Farois: new Array()
          }),
          IdDoIndicadorBase: visao.IdDoIndicadorBase,
          IdIndicador: visao.IdIndicador,
          Referencia: visao.Referencia
        };
        visaoPai.push(farol);
        if (visao.Desdobramento.Farois) {
          this.restaurarVisao(visao.Desdobramento.Farois, farol.Desdobramento.Farois);
        }
      }
    }
  };

  farolController.prototype.retaurarFilhasDoFarol = function() {
    var farol, guidpai, j, len, ref, results;
    ref = $('.js-farol');
    results = [];
    for (j = 0, len = ref.length; j < len; j++) {
      farol = ref[j];
      farol = $(farol);
      guidpai = farol.data('guidpai');
      if (this.estado[guidpai]) {
        results.push(this.estado[guidpai].Filhas.push(farol.attr('id')));
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  farolController.prototype.imprimirPdf = function() {
    var $form, $hidden;
    $form = $('#form-imprimiPdf');
    $hidden = $form.find('#desdobramentos');
    $hidden.val(JSON.stringify(this.visao));
    swIntercom('Imprimiu o Farol');
    return $form.submit();
  };

  farolController.prototype.removerDaVisao = function(guid, visoes, ehFilho) {
    var j, len, visao;
    for (j = 0, len = visoes.length; j < len; j++) {
      visao = visoes[j];
      if (visao.GUID === guid) {
        if (ehFilho) {
          visao.Desdobramento = null;
        } else {
          visoes.remove(visao);
        }
      }
      if (visao.Desdobramento && visao.Desdobramento.Farois) {
        this.removerDaVisao(guid, visao.Desdobramento.Farois, true);
      }
    }
  };

  return farolController;

})(window.farolBaseController);
