﻿var flag = false;
function marcarTodos() {
    var elem = $(event.srcElement);
    var table = elem.parents("table");
    var checks = $("[type=checkbox]", table);
    flag = !flag;
    checks.attr("checked", flag);
}

function LoadWindow(hostAddress, ide) {
    var lUrl = hostAddress + "MetodoSolucao/FraMetSol.aspx?openModule=1&Link=True&IdeSolPrb=" + ide;

    LoadWindowByLink(lUrl, false);
}

function LoadWindowByModule(hostAddress, IdeModule, IdeUni, IdePlaGes) {
    var lUrl = hostAddress + "/Default.aspx?openModule=" + IdeModule;

    if (IdeUni > 0)
        lUrl += "&ideUni=" + IdeUni;

    if (IdePlaGes > 0)
        lUrl += "&idePlaGes=" + IdePlaGes;

    LoadWindowByLink(lUrl, true);
}

function LoadWindowByLink(pUrl, showShortcuts) {
    $("#loadWindow").remove();

    var posUrl = pUrl.indexOf('/Default.aspx?');
    var lUrl = pUrl.substr(0, posUrl);

    var lIdeUni = 0;
    var lIdePlaGes = 0;

    if (pUrl.indexOf("ideUni") > -1) {
        var posIdeUni = pUrl.indexOf('ideUni');
        lIdeUni = pUrl.substr(posIdeUni+7, 13);
    }

    if (pUrl.indexOf("idePlaGes") > -1) {
        var posIdePlaGes = pUrl.indexOf('idePlaGes');
        lIdePlaGes = pUrl.substr(posIdePlaGes+10, 13);
    }

    var metSol = (pUrl.indexOf("MetodoSolucao") > -1 ? true : false);
    var lTop = document.documentElement.scrollTop + (metSol ? 0 : 140);
    var left = 0;

    var loadWindowWidth = document.documentElement.clientWidth + 8;
    var loadWindowHeight = document.documentElement.clientHeight - (metSol ? 0 : 150);

    $("html").css("overflow", "hidden");

    var createDivLoadWindow = "";
    if(showShortcuts)
        createDivLoadWindow = '<div id="loadWindow"><div style="text-align: center;"><span onClick="LoadWindowByModule(\'' + lUrl + '\', 1110000000003, top.loadWindowFrame.actualIdeSpr, ' + lIdePlaGes + ')">Planilha</span><span onClick="LoadWindowByModule(\'' + lUrl + '\', 1110000000007, top.loadWindowFrame.actualIdeSpr, ' + lIdePlaGes + ')">Farol</span><span onClick="LoadWindowByModule(\'' + lUrl + '\', 1110000000005, top.loadWindowFrame.actualIdeSpr, ' + lIdePlaGes + ')">Gráficos</span><img style="position:absolute; top:0; right:0; background-color: #e0edde;" id="imgFramePortal" src="../Content/Image/ImgNaoAplic.gif" /></div><iframe id="loadWindowFrame" frameborder="no" WIDTH="100%" height="' + (loadWindowHeight) + 'px" scrolling="no" marginheight="0" marginwidth="0"></iframe></div>';
    else
        createDivLoadWindow = '<div id="loadWindow"><img style="position:absolute; top:0; right:0; background-color: #e0edde;" id="imgFramePortal" src="../Content/Image/ImgNaoAplic.gif" /><iframe id="loadWindowFrame" frameborder="no" WIDTH="100%" height="' + (loadWindowHeight) + 'px" scrolling="no" marginheight="0" marginwidth="0"></iframe></div>';

    $(createDivLoadWindow).appendTo('body');

    if (pUrl.indexOf("openModule") > -1)
        pUrl += "&ParentFrame=loadWindowFrame";

    $("#loadWindowFrame").attr("src", pUrl);
    $("#imgFramePortal").click(function () {
        $("#loadWindow").remove();
        $("html").css("overflow", "");
    });

    $('#loadWindow').width(loadWindowWidth).height(loadWindowHeight).css("left", left).css("top", lTop);
}

function LoadWindowByLink2(pUrl) {
    $("#loadWindow").remove();

    var posUrl = pUrl.indexOf('/Default.aspx?');
    var lUrl = pUrl.substr(0, posUrl);

    var lIdeUni = 0;
    var lIdePlaGes = 0;

    if (pUrl.indexOf("ideUni") > -1) {
        var posIdeUni = pUrl.indexOf('ideUni');
        lIdeUni = pUrl.substr(posIdeUni + 7, 13);
    }

    if (pUrl.indexOf("idePlaGes") > -1) {
        var posIdePlaGes = pUrl.indexOf('idePlaGes');
        lIdePlaGes = pUrl.substr(posIdePlaGes + 10, 13);
    }

    var lTop = document.documentElement.scrollTop + 140;
    var left = 0;

    var loadWindowWidth = document.documentElement.clientWidth + 8;
    var loadWindowHeight = document.documentElement.clientHeight - 150;

    $("html").css("overflow", "hidden");

    var createDivLoadWindow = '<div id="loadWindow"><img id="imgFramePortal" src="../../Content/Image/ImgNaoAplic.gif" /><iframe id="loadWindowFrame" frameborder="no" WIDTH="100%" height="' + (loadWindowHeight - 25) + 'px" scrolling="no" marginheight="0" marginwidth="0"></iframe></div>';

    $(createDivLoadWindow).appendTo('body');
    $("#loadWindowFrame").attr("src", pUrl);
    $("#imgFramePortal").click(function () {
        $("#loadWindow").remove();
        $("html").css("overflow", "");
    });

    $('#loadWindow').width(loadWindowWidth).height(loadWindowHeight).css("left", left).css("top", lTop);
}

function GetSrcForSolucoesDeProblema26(idAcompanhamento, Frequencia, dia, mes, ano, endereco26, NaoMostrarFechar) {
    var url = endereco26 + "SIG/FrmShowSolPrbTip.aspx?Call=Farol&ExternCaller=" + externCaller + "&IdeAco=" + idAcompanhamento + "&Frequencia=" + Frequencia + "&Dia=" + dia + "&Mes=" + mes + "&Ano=" + ano;

    if (NaoMostrarFechar != undefined && NaoMostrarFechar)
        url = url + "&NaoMostrarFechar=true"
    
    return url;
}

function MostrarDivSolucoesDeProblemas(idAcompanhamento, Frequencia, dia, mes, ano, endereco26) {
   divSolucoesDeProblemas = document.getElementById("DivSolucoesDeProblemas");
   if (divSolucoesDeProblemas != null)
      divSolucoesDeProblemas.parentNode.removeChild(divSolucoesDeProblemas);
    $('<div class="FakeToolTipMetSolPrb" id="DivSolucoesDeProblemas"><iframe id="FrmSolucaoDeProblema" frameborder="no" WIDTH="100%" height="100%" scrolling="no" marginheight="0" marginwidth="0"></iframe></div>').appendTo('body');

    var enderecoSolucaoProblema = GetSrcForSolucoesDeProblema26(idAcompanhamento, Frequencia, dia, mes, ano, endereco26);
    $("#FrmSolucaoDeProblema").attr("src", enderecoSolucaoProblema);
}



function ExecutarClick() { }

$(function () {
    $('#loadingStatus').ajaxStart(function () { $(this).fadeIn(); });
    $('#loadingStatus').ajaxStop(function () { $(this).fadeOut(); });
    $('body').ajaxError(function (e, jqxhr, settings, exception) { alert(exception); });
    if(externCaller)
        $('body').ajaxSuccess(function () { $.validator.unobtrusive.parse($(this)); });
});

jQuery(function ($) {
    $.datepicker.regional['pt-BR'] = {
        closeText: 'Fechar',
        prevText: '&#x3c;Anterior',
        nextText: 'Pr&oacute;ximo&#x3e;',
        currentText: 'Hoje',
        monthNames: ['Janeiro', 'Fevereiro', 'Mar&ccedil;o', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
        monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
        dayNames: ['Domingo', 'Segunda-feira', 'Ter&ccedil;a-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sabado'],
        dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'],
        dayNamesMin: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'],
        weekHeader: 'Sm',
        dateFormat: 'dd/mm/yy',
        firstDay: 0,
        isRTL: false,
        showMonthAfterYear: false,
        yearSuffix: ''
    };
    $.datepicker.setDefaults($.datepicker.regional['pt-BR']);
});

$(function () { $("nav.jd_menu").jdMenu(); });

function posicionarModal() {
    $('#modal .close').click(function (event) {
        (event.preventDefault) ? event.preventDefault() : event.returnValue = false;
        $(this).parents('#modal').fadeOut('fast');
        $('#modalShadow').hide();// .fadeOut('fast');
    });
    $('#modal .executeClose').click(function (event) {
        $(this).parents('#modal').fadeOut('fast');
        $('#modalShadow').hide();//.fadeOut('fast');
    });
    sb_windowTools.updateDimensions();
    $('#modalShadow').css({ height: sb_windowTools.pageDimensions.pageHeight() });
    $('#modal')
            .css({
                top: (sb_windowTools.pageDimensions.windowHeight() / 2) - $('#modal').outerHeight() / 2 + 'px',
                left: (sb_windowTools.pageDimensions.windowWidth() / 2) - $('#modal').outerWidth() / 2 + 'px'
            });

    $('#modalShadow').show(); // fadeIn('slow');
    $('#modal').fadeIn('slow');
    $('.alerta a').focus();
}

$(function () {
    $(":input[data-val=true]").live("focus", function () {
        var el = $(this);
        var message = el.attr("data-val-length");

        if (message !== undefined) {
            var maxLength = el.attr("data-val-length-max");

            if (maxLength !== undefined)
                el.attr("maxlength", maxLength);
        }
    });
});