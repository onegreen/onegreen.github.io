﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.baseController = (function() {
  function baseController(view, model) {
    var stopPropagation;
    this.view = view;
    this.model = model;
    this.setTimePicker = bind(this.setTimePicker, this);
    this.setDatePicker = bind(this.setDatePicker, this);
    this.model = ko.mapping.fromJS(this.model);
    ko.applyBindings(this, $(this.view)[0]);
    this.setMasks();
    this.esconderCampos();
    stopPropagation = function(event) {
      return event.stopPropagation();
    };
    $("[data-toedit=true]", this.view).click(stopPropagation);
  }

  baseController.prototype.edit = function(data, event) {
    var el;
    event.stopPropagation();
    el = $(event.delegateTarget);
    return this.internalEdit(el);
  };

  baseController.prototype.internalEdit = function(el) {
    var elementToWrite, field, keydown, labelDisplay, labelEmpty;
    el.hide();
    elementToWrite = this.get(el.attr('data-edit'));
    elementToWrite.show();
    labelDisplay = this.get(el.attr('data-edit') + '-display');
    labelEmpty = this.get(el.attr('data-edit') + '-empty');
    labelDisplay.hide();
    labelEmpty.hide();
    if (!elementToWrite.is(":input")) {
      field = $(":input:first[type!=hidden]", elementToWrite);
    } else {
      field = elementToWrite;
    }
    field.focus();
    field.one('blur', function(event) {
      if (elementToWrite.is(":input")) {
        elementToWrite.hide();
        if (field.val().length > 0 && labelDisplay !== null) {
          labelDisplay.show();
          return labelEmpty.hide();
        } else if (field.val().length === 0 && labelEmpty !== null) {
          labelEmpty.show();
          return labelDisplay.hide();
        }
      }
    });
    if (!elementToWrite.is(":input")) {
      $(this.view).one('click', function(event) {
        elementToWrite.hide();
        if (field.val().length > 0 && labelDisplay !== null) {
          labelDisplay.show();
          return labelEmpty.hide();
        } else if (field.val().length === 0 && labelEmpty !== null) {
          labelEmpty.show();
          return labelDisplay.hide();
        }
      });
    }
    keydown = function(event) {
      if (event.which === 9) {
        elementToWrite.hide();
        return el.show();
      }
    };
    if (elementToWrite.is(":input")) {
      return elementToWrite.on('keydown.agenda', keydown);
    } else if (elementToWrite.has(":input[type!=hidden]")) {
      return $(":input[type!=hidden]", elementToWrite).last().one('keydown', keydown);
    }
  };

  baseController.prototype.clear = function() {
    var el;
    el = $(event.target);
    return this.internalClear(el);
  };

  baseController.prototype.internalClear = function(el) {
    eval("this.model." + el.attr('data-clear') + "('')");
    return this.toogleElements("#" + el.attr('data-clear'), true);
  };

  baseController.prototype.esconderCampos = function() {
    $("[data-toEdit=true]", this.view).hide();
    return $("[data-toEdit=true]", this.view).trigger("hide");
  };

  baseController.prototype.fechar = function() {
    return ko.cleanNode($(this.view)[0]);
  };

  baseController.prototype.toogleElements = function(elementId, condition) {
    if (condition) {
      (this.get(elementId + "-empty")).show();
      (this.get(elementId + "-display")).hide();
      return (this.get(elementId)).hide();
    } else {
      (this.get(elementId + "-empty")).hide();
      (this.get(elementId + "-display")).show();
      return (this.get(elementId)).hide();
    }
  };

  baseController.prototype.get = function(selector) {
    return $(selector, this.view);
  };

  baseController.prototype.setMasks = function() {
    return $("input[data-mask]", this.view).each(function() {
      var input;
      input = $(this);
      return input.setMask(input.data('mask'));
    });
  };

  baseController.prototype.setDatePicker = function(propertyName) {
    return (this.get("#" + propertyName + "-input")).datepicker({
      showOn: "element",
      elementTrigger: "#" + propertyName + "-input-trigger",
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true
    });
  };

  baseController.prototype.setTimePicker = function(propertyName) {
    return (this.get("#" + propertyName + "-input")).timePicker({
      startTime: "06:00",
      endTime: "22:00",
      show24Hours: true,
      step: 30
    });
  };

  return baseController;

})();
