﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.FerramentaDeGraficoController = (function() {
  function FerramentaDeGraficoController(view, options) {
    this.view = view;
    this.options = options;
    this.configurarDatePickerFarolMensal = bind(this.configurarDatePickerFarolMensal, this);
    this.configurarDatePickerFarolSemana = bind(this.configurarDatePickerFarolSemana, this);
    this.configurarDatePickerFarolDiario = bind(this.configurarDatePickerFarolDiario, this);
    this.configurarDatepicker = bind(this.configurarDatepicker, this);
    this.desabilitarOcorrencia = bind(this.desabilitarOcorrencia, this);
    this.desabilitarFrequencias = bind(this.desabilitarFrequencias, this);
    this.desabilitarComboModelos = bind(this.desabilitarComboModelos, this);
    this.desabilitarComboIndicador = bind(this.desabilitarComboIndicador, this);
    this.desabilitarComboUnidades = bind(this.desabilitarComboUnidades, this);
    this.desabilitarCampos = bind(this.desabilitarCampos, this);
    this.carregarModelos = bind(this.carregarModelos, this);
    this.carregarComutadorDeFrequencias = bind(this.carregarComutadorDeFrequencias, this);
    this.carregarComboDeIndicadores = bind(this.carregarComboDeIndicadores, this);
    this.carregarComboDeUnidades = bind(this.carregarComboDeUnidades, this);
    this.carregarComboDePlanoDeGestao = bind(this.carregarComboDePlanoDeGestao, this);
    this.carregarComboDePlanoDeGestao();
    this.carregarComboDeUnidades();
    this.carregarComboDeIndicadores();
    if (this.options.edicao) {
      this.carregarModelos();
      this.configurarDatepicker();
    } else {
      this.desabilitarCampos();
    }
    $(this.view).window();
  }

  FerramentaDeGraficoController.prototype.carregarComboDePlanoDeGestao = function() {
    var onSelectPlanoDeGestao;
    onSelectPlanoDeGestao = (function(_this) {
      return function() {
        return _this.desabilitarCampos();
      };
    })(this);
    return setCombo(this.view, "#NomeDoPlanoDeGestao", onSelectPlanoDeGestao);
  };

  FerramentaDeGraficoController.prototype.carregarComboDeUnidades = function() {
    var onSelectUnidade, parameters;
    onSelectUnidade = (function(_this) {
      return function() {
        _this.desabilitarComboIndicador();
        _this.desabilitarFrequencias();
        _this.desabilitarOcorrencia(true);
        return _this.desabilitarComboModelos();
      };
    })(this);
    parameters = {
      idPlanoGestao: (function(_this) {
        return function() {
          return $('#IdDoPlano	DeGestao', _this.view).val();
        };
      })(this)
    };
    return setCombo(this.view, "#SiglaDaUnidade", onSelectUnidade, parameters);
  };

  FerramentaDeGraficoController.prototype.carregarComboDeIndicadores = function() {
    var onSelectIndicador, parameters;
    onSelectIndicador = (function(_this) {
      return function() {
        _this.desabilitarFrequencias();
        _this.desabilitarOcorrencia(true);
        _this.carregarComutadorDeFrequencias();
        return _this.desabilitarComboModelos();
      };
    })(this);
    parameters = {
      idPlanoGestao: (function(_this) {
        return function() {
          return $('#IdDoPlanoDeGestao', _this.view).val();
        };
      })(this),
      idUnidadeGerencial: (function(_this) {
        return function() {
          return $('#IdDaUnidade', _this.view).val();
        };
      })(this)
    };
    return Results.api.setComboIndicador(this.view, "#NomeDoIndicador", onSelectIndicador, parameters);
  };

  FerramentaDeGraficoController.prototype.carregarComutadorDeFrequencias = function() {
    return $as.Performance.Indicadores.ObterFrequenciasAplicaveis.get({
      idDoIndicador: $('#IdDoIndicador', this.view).val()
    }).done((function(_this) {
      return function(frequencia) {
        if (frequencia.EDiario) {
          $('#EDiario', _this.view).val('true');
          $('#Frequencia-Diaria', _this.view).removeAttr('disabled').change(function() {
            _this.carregarModelos();
            _this.desabilitarOcorrencia(false);
            return _this.configurarDatepicker();
          });
        }
        if (frequencia.ESemanal) {
          $('#ESemanal', _this.view).val('true');
          $('#Frequencia-Semanal', _this.view).removeAttr('disabled').change(function() {
            _this.carregarModelos();
            _this.desabilitarOcorrencia(false);
            return _this.configurarDatepicker();
          });
        }
        if (frequencia.EMensal) {
          $('#EMensal', _this.view).val('true');
          return $('#Frequencia-Mensal', _this.view).removeAttr('disabled').change(function() {
            _this.carregarModelos();
            _this.desabilitarOcorrencia(false);
            return _this.configurarDatepicker();
          });
        }
      };
    })(this));
  };

  FerramentaDeGraficoController.prototype.carregarModelos = function() {
    if ($("#IdDoIndicador", this.view).val() !== '' && $('[name=Frequencia]:checked', this.view).val()) {
      $as.Performance.FarolDeIndicadores.ModelosDeGraficosParaSelecaoDaFerramenta.get({
        idDoIndicador: $("#IdDoIndicador", this.view).val(),
        frequencia: $('[name=Frequencia]:checked', this.view).val()
      }).done((function(_this) {
        return function(html) {
          $('#graficos-selecao', _this.view).html('').append($(html).find('li'));
          $('#btn-modelo', _this.view).removeAttr('disabled');
          return $('#graficos-selecao', _this.view).find('a').click(function() {
            $('#IdDoModelo', _this.view).val($( this ).data('id'));
            $('#Ordem', _this.view).val($( this ).data('ordem'));
            $('#TipoDeDesdobramento', _this.view).val($( this ).data('tipo'));
            $('#NomeDoModelo', _this.view).val($( this ).data('nome'));
            return $('#nomeModeloSelecionado', _this.view).text($( this ).data('nome'));
          });
        };
      })(this));
    } else {
      this.desabilitarComboModelos();
    }
  };

  FerramentaDeGraficoController.prototype.desabilitarCampos = function() {
    this.desabilitarComboIndicador();
    this.desabilitarFrequencias();
    this.desabilitarOcorrencia(true);
    return this.desabilitarComboModelos();
  };

  FerramentaDeGraficoController.prototype.desabilitarComboUnidades = function() {
    var bloquear, id;
    id = $('#IdDoPlanoDeGestao', this.view).val();
    bloquear = id === '';
    $("#SiglaDaUnidade", this.view).val('');
    $("#IdDaUnidade", this.view).val('');
    return $("#SiglaDaUnidade", this.view).data('autocompleter').disableElseEnable(bloquear);
  };

  FerramentaDeGraficoController.prototype.desabilitarComboIndicador = function() {
    var bloquear, id;
    id = $('#IdDaUnidade', this.view).val();
    bloquear = id === '';
    $("#NomeDoIndicador", this.view).val('');
    $("#IdDoIndicador", this.view).val('');
    return $("#NomeDoIndicador", this.view).data('autocompleter').disableElseEnable(bloquear);
  };

  FerramentaDeGraficoController.prototype.desabilitarComboModelos = function() {
    $('#btn-modelo', this.view).attr('disabled', 'disabled');
    $('#IdDoModelo', this.view).val('');
    $('#Ordem', this.view).val('');
    $('#TipoDeDesdobramento', this.view).val('');
    $('#NomeDoModelo', this.view).val('');
    return $('#nomeModeloSelecionado', this.view).text($('#nomeModeloSelecionado', this.view).data('selecione'));
  };

  FerramentaDeGraficoController.prototype.desabilitarFrequencias = function() {
    var bloquear, id;
    id = $('#IdDoIndicador', this.view).val();
    bloquear = id === '';
    $('#Frequencia-Diaria', this.view).attr('disabled', 'disabled').removeAttr('checked');
    $('#Frequencia-Semanal', this.view).attr('disabled', 'disabled').removeAttr('checked');
    $('#Frequencia-Mensal', this.view).attr('disabled', 'disabled').removeAttr('checked');
    return dataToggle.activateBtnToggle();
  };

  FerramentaDeGraficoController.prototype.desabilitarOcorrencia = function(bloquear) {
    var $ocorrencia;
    $ocorrencia = $("#Ocorrencia", this.view);
    $ocorrencia.val('');
    if ($ocorrencia.datepicker) {
      $ocorrencia.datepicker('remove');
    }
    if (bloquear) {
      return $ocorrencia.attr('disabled', 'disabled');
    }
  };

  FerramentaDeGraficoController.prototype.configurarDatepicker = function() {
    var frequencia;
    frequencia = $('[name=Frequencia]:checked', this.view).val();
    $("#Ocorrencia", this.view).removeAttr('disabled');
    if (frequencia === 'Diaria') {
      return this.configurarDatePickerFarolDiario();
    } else if (frequencia === 'Mensal') {
      return this.configurarDatePickerFarolMensal();
    } else {
      return this.configurarDatePickerFarolSemana();
    }
  };

  FerramentaDeGraficoController.prototype.configurarDatePickerFarolDiario = function(idInput) {
    return $("#Ocorrencia", this.view).datepicker({
      orientation: "top auto",
      autoclose: true,
      forceParse: true,
      startDate: this.options.startDate,
      endDate: this.options.endDate,
      calendarWeeks: false
    });
  };

  FerramentaDeGraficoController.prototype.configurarDatePickerFarolSemana = function(idInput) {
    return $("#Ocorrencia", this.view).datepicker({
      orientation: "top auto",
      autoclose: true,
      forceParse: true,
      startDate: this.options.startDate,
      endDate: this.options.endDate,
      calendarWeeks: true,
      daysOfWeekDisabled: "1,2,3,4,5,6"
    });
  };

  FerramentaDeGraficoController.prototype.configurarDatePickerFarolMensal = function(idInput) {
    return $("#Ocorrencia", this.view).datepicker({
      orientation: "top auto",
      autoclose: true,
      forceParse: true,
      startDate: this.options.startDate,
      endDate: this.options.endDate,
      calendarWeeks: false,
      minViewMode: 'months',
      maxViewMode: 'months'
    });
  };

  return FerramentaDeGraficoController;

})();
