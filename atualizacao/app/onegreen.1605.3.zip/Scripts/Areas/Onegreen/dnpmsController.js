﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.dnpmsController = (function() {
  function dnpmsController(options) {
    this.options = options;
    this.limparComboMunicipio = bind(this.limparComboMunicipio, this);
    this.bloquearDesbloquearComboMunicipio = bind(this.bloquearDesbloquearComboMunicipio, this);
    this.loadComboMunicipios = bind(this.loadComboMunicipios, this);
    this.loadComboEstados = bind(this.loadComboEstados, this);
    this.loadComboUsuarios = bind(this.loadComboUsuarios, this);
    this.loadComboUnidadeGerencial = bind(this.loadComboUnidadeGerencial, this);
    this.loadComboSituacoesDNPM = bind(this.loadComboSituacoesDNPM, this);
    this.contexto = "#main";
    this.loadComboUnidadeGerencial();
    this.loadComboUsuarios();
    this.loadComboEstados();
    this.loadComboMunicipios();
    this.loadComboSituacoesDNPM();
    this.bloquearDesbloquearComboMunicipio();
    $("input[alt=integer_4]").setMask();
    $("input[alt=date]").setMask();
    $(".date").datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true
    });
  }

  dnpmsController.prototype.loadComboSituacoesDNPM = function() {
    return setCombo(this.contexto, '#SituacaoDNPM_Descricao');
  };

  dnpmsController.prototype.loadComboUnidadeGerencial = function() {
    return setCombo(this.contexto, '#UnidadeGerencial_Nome');
  };

  dnpmsController.prototype.loadComboUsuarios = function() {
    return setCombo(this.contexto, '#ResponsavelTecnico_Nome');
  };

  dnpmsController.prototype.loadComboEstados = function() {
    var oldIdeEstado;
    oldIdeEstado = $("#Municipio_Estado_Id").val();
    return $("#Municipio_Estado_Nome").autocompleter(this.options.urlComboEstado, {
      loadOnDemand: false,
      elementToClick: "#Municipio_Estado_NomeBtn",
      keyElement: "#Municipio_Estado_Id",
      onSelected: (function(_this) {
        return function(valueInput) {
          if (oldIdeEstado !== valueInput.val()) {
            oldIdeEstado = valueInput.val();
            _this.limparComboMunicipio();
          }
          return _this.bloquearDesbloquearComboMunicipio();
        };
      })(this)
    });
  };

  dnpmsController.prototype.loadComboMunicipios = function() {
    var parametros;
    parametros = {
      ideEstado: (function(_this) {
        return function() {
          return $('#Municipio_Estado_Id').val();
        };
      })(this)
    };
    return setCombo(this.contexto, '#Municipio_Nome', null, parametros);
  };

  dnpmsController.prototype.bloquearDesbloquearComboMunicipio = function() {
    if ($('#Municipio_Estado_Id').val() === "") {
      return $('#Municipio_Nome').data('autocompleter').disable();
    } else {
      return $('#Municipio_Nome').data('autocompleter').enable();
    }
  };

  dnpmsController.prototype.limparComboMunicipio = function() {
    $("#Municipio_Id").val("");
    $("#Municipio_Nome").val("");
    return this.loadComboMunicipios();
  };

  return dnpmsController;

})();
