﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.ParticipantesDoProjetoController = (function() {
  function ParticipantesDoProjetoController(options, resource) {
    this.options = options;
    this.resource = resource;
    this.serializar = bind(this.serializar, this);
    this.excluirConfirmado = bind(this.excluirConfirmado, this);
    this.excluirSelecionados = bind(this.excluirSelecionados, this);
    this.excluirParticipante = bind(this.excluirParticipante, this);
    this.carregarComboFuncoes = bind(this.carregarComboFuncoes, this);
    this.carregarComboUsuario = bind(this.carregarComboUsuario, this);
    this.IdsExclusaoParticipantes = null;
    this.carregarComboFuncoes();
    if (this.options.FuncoesFaltantes > 0) {
      $('#Titulo-participantes').append('<i class="swicon-alerta mls mts" id="alertaDeparticipantes" data-original-title="' + this.options.TextoFuncoes + '"></i>');
      $('#alertaDeparticipantes').tooltip();
    }
    popoverUsuario.on('#participantes-table');
    $("#ListaDePariticipantes div .cardParticipante").on({
      click: (function(_this) {
        return function(e) {
          return $(e.currentTarget).toggleClass('selecionado');
        };
      })(this)
    });
    $("#selecionarTodos").click((function(_this) {
      return function() {
        $("#ListaDePariticipantes div .cardParticipante").click();
        if ($("#ListaDePariticipantes div .cardParticipante.selecionado").length) {
          return $('#selecionarTodos a').text(_this.resource.DesmarcarSelecionados);
        } else {
          return $('#selecionarTodos a').text(_this.resource.SelecionarTodos);
        }
      };
    })(this));
    $("#dropdownParticipante").click((function(_this) {
      return function() {
        if ($("#ListaDePariticipantes div .cardParticipante.selecionado").length) {
          return $('#excluirSelecionados').removeClass("disabled");
        } else {
          return $('#excluirSelecionados').addClass("disabled");
        }
      };
    })(this));
  }

  ParticipantesDoProjetoController.prototype.carregarComboUsuario = function(idDaFuncao) {
    var parametros;
    $("#NovoUsuario #Usuario_Nome").autocompleter(this.options.UrlComboUsuario, {
      loadOnDemand: false,
      keyElement: '#Usuario_Id',
      selectOnTypeArrow: false,
      onSelected: null
    });
    parametros = {
      idDaFuncao: (function(_this) {
        return function() {
          return idDaFuncao;
        };
      })(this)
    };
    return $("#NovoUsuario #Usuario_Nome").data("autocompleter").setParameters(parametros);
  };

  ParticipantesDoProjetoController.prototype.carregarComboFuncoes = function() {
    var parametros;
    $("#NovoUsuario #Funcao_Nome").autocompleter(this.options.UrlComboFuncao, {
      loadOnDemand: false,
      keyElement: '#Funcao_Id',
      selectOnTypeArrow: false,
      onSelected: (function(_this) {
        return function(input) {
          return _this.carregarComboUsuario($("#NovoUsuario #Funcao_Id").val());
        };
      })(this)
    });
    parametros = {
      idMetodo: (function(_this) {
        return function() {
          return $("#Metodo_Id").val();
        };
      })(this)
    };
    return $("#NovoUsuario #Funcao_Nome").data("autocompleter").setParameters(parametros);
  };

  ParticipantesDoProjetoController.prototype.excluirParticipante = function(el) {
    var hidden;
    hidden = $('[name=Ids]', $(el).parent());
    return this.excluirSelecionados(hidden);
  };

  ParticipantesDoProjetoController.prototype.excluirSelecionados = function(ids) {
    if (!ids) {
      this.IdsExclusaoParticipantes = $("#ListaDePariticipantes .selecionado [type=hidden]");
    } else {
      this.IdsExclusaoParticipantes = ids;
    }
    if (this.IdsExclusaoParticipantes.length) {
      return window.modalConfirm(this.resource.DesejaExcluirOsRegistrosSelecionados, this.excluirConfirmado);
    }
  };

  ParticipantesDoProjetoController.prototype.excluirConfirmado = function() {
    return $as.EPM.Participantes.DeleteMany.post(this.serializar(this.IdsExclusaoParticipantes));
  };

  ParticipantesDoProjetoController.prototype.serializar = function(valores) {
    var i, j, ref, serialized, valor;
    serialized = '';
    for (j = i = 0, ref = valores.length; i <= ref; j = i += 1) {
      valor = $(valores[j]);
      serialized = serialized + valor.attr('name') + '=' + valor.val() + '&';
    }
    serialized = serialized.substring(0, serialized.length - 1);
    return serialized;
  };

  return ParticipantesDoProjetoController;

})();
