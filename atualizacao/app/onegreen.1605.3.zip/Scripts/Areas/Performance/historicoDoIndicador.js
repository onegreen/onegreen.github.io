﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.historicoDoIndicador = (function() {
  function historicoDoIndicador(view, opcoes, resources) {
    this.view = view;
    this.opcoes = opcoes;
    this.resources = resources;
    this.recarregarComboDeIndicadores = bind(this.recarregarComboDeIndicadores, this);
    this.configurarComboIndicador = bind(this.configurarComboIndicador, this);
    this.configurarComboUnidades = bind(this.configurarComboUnidades, this);
    this.$view = $(this.view);
    this.configurarComboUnidades();
    this.configurarComboIndicador();
  }

  historicoDoIndicador.prototype.configurarComboUnidades = function() {
    return setCombo(this.view, '#NomeDaUnidadeGerencial', this.recarregarComboDeIndicadores);
  };

  historicoDoIndicador.prototype.configurarComboIndicador = function() {
    var parameters;
    parameters = {
      idDaUnidadeGerencial: $('#IdDaUnidadeGerencial', this.$view).val(),
      idDoIndicador: $('#idDoIndicador', this.$view).val()
    };
    return Results.api.setComboIndicador(this.view, '#NomeDoIndicadorHistorico', null, parameters);
  };

  historicoDoIndicador.prototype.recarregarComboDeIndicadores = function() {
    $('#IdDoIndicadorHistorico').val('');
    $('#NomeDoIndicadorHistorico').val(this.resources.SelecionarIndicador);
    return this.configurarComboIndicador();
  };

  historicoDoIndicador.recarregarHistorico = function(idDoIndicador) {
    return $as.Performance.HistoricoDoIndicador.CarregarHistoricoDeIndicador.get({
      idDoIndicador: idDoIndicador
    }).done(function(data) {
      return $('#historico-indicador-container').html(data);
    });
  };

  return historicoDoIndicador;

})();
