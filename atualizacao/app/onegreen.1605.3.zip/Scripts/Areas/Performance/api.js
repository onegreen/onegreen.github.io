﻿this.Results || (this.Results = {});

Results.api = (function() {
  function api() {}

  api.Origem = {
    Farol: 0,
    Planilha: 1
  };

  api.exibirDetalhesDoIndicador = function(informacoes, mesSemanaDia, abaDeDetalhesPadrao) {
    var parametros;
    parametros = {
      IdDoIndicador: informacoes.IdIndicador,
      IdDoIndicadorBase: informacoes.IdIndicadorBase,
      IdDoItem1: informacoes.Dimensao1,
      IdDoItem2: informacoes.Dimensao2,
      IdDoItem3: informacoes.Dimensao3,
      IdDoItem4: informacoes.Dimensao4,
      IdDoItem5: informacoes.Dimensao5,
      IdDoItem6: informacoes.Dimensao6,
      IdDoPlanoDeGestao: informacoes.IdDoPlanoDeGestao,
      FormaDeVisualizacao: informacoes.FormaDeVisualizacao || 'Apurado',
      IdDaUnidade: informacoes.IdUnidade,
      Frequencia: informacoes.Frequencia,
      NumeroDoMes: informacoes.NumeroDoMes,
      MesSemanaDia: mesSemanaDia
    };
    return $as.Performance.DetalhesDoIndicador.Index.post(parametros).done(function(data) {
      var containerDetalhes;
      containerDetalhes = window.GetDiv("box-create-edit-indicador");
      containerDetalhes.html(data);
      return api.exibirAbaEspecificaDeDetalhesDoIndicador(abaDeDetalhesPadrao, containerDetalhes);
    });
  };

  api.exibirDetalhesPorIdDoIndicador = function(idDoIndicador, ocorrencia, frequencia, abaDeDetalhesPadrao) {
    return $as.Performance.DetalhesDoIndicador.IndexPorIndicador.get({
      IdDoIndicador: idDoIndicador,
      ocorrencia: ocorrencia,
      frequencia: frequencia
    }).done(function(data) {
      var containerDetalhes;
      containerDetalhes = window.GetDiv("box-create-edit-indicador");
      containerDetalhes.html(data);
      return api.exibirAbaEspecificaDeDetalhesDoIndicador(abaDeDetalhesPadrao, containerDetalhes);
    });
  };

  api.exibirDetalhesPorIdDoIndicadorComMesSemanaDia = function(idDoIndicador, mesSemanaDia, frequencia, abaDeDetalhesPadrao) {
    return $as.Performance.DetalhesDoIndicador.IndexPorIndicadorComMesSemanaDia.get({
      IdDoIndicador: idDoIndicador,
      mesSemanaDia: mesSemanaDia,
      frequencia: frequencia
    }).done(function(data) {
      var containerDetalhes;
      containerDetalhes = window.GetDiv("box-create-edit-indicador");
      containerDetalhes.html(data);
      return api.exibirAbaEspecificaDeDetalhesDoIndicador(abaDeDetalhesPadrao, containerDetalhes);
    });
  };

  api.adicionarIndicador = function(idDoIndicador) {
    return $as.Performance.Indicadores.AdicionarIndicador.get({
      idDaAtividade: idDoIndicador
    }).done(function(data) {
      return $("#main-modal").html(data);
    });
  };

  api.exibirAbaEspecificaDeDetalhesDoIndicador = function(aba, container) {
    if (aba === 'solucoes') {
      return $('[data-toggle=tab][href=#solucoes-tab-content]', container).click();
    } else if (aba === 'comentarios') {
      return $('[data-toggle=tab][href=#comentarios-tab-content]', container).click();
    } else if (aba === 'tarefas') {
      return $('[data-toggle=tab][href=#tarefas-tab-content]', container).click();
    }
  };

  api.setComboIndicadorBase = function(contextId, elementId, onSelected, parameters, podeCriarIndicadorBase) {
    elementId = !(elementId === void 0 || elementId === null) ? elementId : '#IndicadorBase_Nome';
    return this.setComboIndicador(contextId, elementId, onSelected, parameters, podeCriarIndicadorBase);
  };

  api.setComboIndicador = function(contextId, elementId, onSelected, parameters, createOptionIfNotExists) {
    var opcoes;
    opcoes = {
      contextId: contextId,
      elementId: !(elementId === void 0 || elementId === null) ? elementId : '#Indicador_Nome',
      onSelected: onSelected,
      dataType: 'html',
      parameters: parameters,
      createOptionIfNotExists: createOptionIfNotExists
    };
    return setComboJSON(opcoes);
  };

  api.verificarSeExisteConsolidacaoDoUsuarioEmAndamento = function() {
    return setTimeout(function() {
      return $as.Performance.Consolidacoes.VerificarSeExisteConsolidacaoDoUsuarioEmAndamento.get(null).done(function(data) {
        if (data) {
          $('#status-da-consolidacao').show();
          return Results.api.atualizarStatusDaConsolidacao();
        }
      }, 2000);
    });
  };

  api.iniciarConsolidacao = function() {
    $('#status-da-consolidacao').show();
    return setTimeout(Results.api.atualizarStatusDaConsolidacao, 2000);
  };

  api.atualizarStatusDaConsolidacao = function() {
    return $.ajax({
      url: $as.Performance.Consolidacoes.ObterAndamentoDaConsolidacao.url,
      method: 'GET',
      global: false,
      success: function(data) {
        var btns;
        if (data.completo == null) {
          $('#status-da-consolidacao').html(data);
          return setTimeout(Results.api.atualizarStatusDaConsolidacao, 1000);
        } else {
          btns = [
            {
              addClass: 'btn btn-primary',
              text: data.textoRecarregar,
              onClick: (function(_this) {
                return function($noty) {
                  $noty.close();
                  return window.reload(true);
                };
              })(this)
            }, {
              addClass: 'btn btn-default',
              text: data.textoAgoraNao,
              onClick: (function(_this) {
                return function($noty) {
                  return $noty.close();
                };
              })(this)
            }
          ];
          $('#status-da-consolidacao').hide();
          return showBottomNoty(data.textoConsolidacaoConluida, 15000, btns);
        }
      }
    });
  };

  api.carregarMenuDocumentos = function(el) {
    var botao, container, listaDeDocumentos, listagemAberta;
    botao = $(el);
    container = botao.closest('.js-container-listagem-documentos');
    listaDeDocumentos = $('.js-listagem-documentos', container);
    listagemAberta = container.hasClass('open');
    if (!listagemAberta) {
      return $as.Documentos.DocumentosVinculados.DocumentosDoIndicadorEmLista.get({
        idDoIndicador: botao.data("idindicador")
      }).success(function(data) {
        return listaDeDocumentos.html(data);
      });
    }
  };

  api.carregarDocumentosMapaDeObjetos = function(el, id, idAgregador) {
    var botao, container, listaDeDocumentos, listagemAberta;
    botao = $(el);
    container = botao.parent();
    listaDeDocumentos = $('.js-listagem-documentos', container);
    listagemAberta = container.hasClass('open');
    if (!listagemAberta) {
      return $as.Documentos.DocumentosVinculados.DocumentosDoMapaDeObjetosEmLista.get({
        idDoMapaDeObjetos: id,
        idAgregador: idAgregador,
        podeAlterarOsArquivos: true
      }).success(function(data) {
        return listaDeDocumentos.html(data);
      });
    }
  };

  api.exibindoMensagem = false;

  api.mostarMensagemParaCarregarSeNecessario = function(resource, tela) {
    var btns;
    if (tela.houveAlteracao && !this.exibindoMensagem) {
      btns = [
        {
          addClass: 'btn btn-primary',
          text: resource.SimRecarregarAgora,
          onClick: (function(_this) {
            return function($noty) {
              $noty.close();
              _this.exibindoMensagem = false;
              tela.houveAlteracao = false;
              return window.reload(true);
            };
          })(this)
        }, {
          addClass: 'btn btn-default',
          text: resource.AgoraNao,
          onClick: (function(_this) {
            return function($noty) {
              _this.exibindoMensagem = false;
              tela.houveAlteracao = false;
              return $noty.close();
            };
          })(this)
        }
      ];
      this.exibindoMensagem = true;
      return showBottomNoty(resource.VoceFezAlteracoesQuePodemRefletirNasInformacoesApresentadasGostariaDeRecarregarATela, 15000, btns);
    }
  };

  api.mostarMensagemRecarregarFarol = function(resource) {
    var btns;
    if (!api.exibindoMensagem) {
      btns = [
        {
          addClass: 'btn btn-primary',
          text: resource.SimRecarregarAgora,
          onClick: function($noty) {
            $noty.close();
            api.exibindoMensagem = false;
            return window.reload(true);
          }
        }, {
          addClass: 'btn btn-default',
          text: resource.AgoraNao,
          onClick: function($noty) {
            api.exibindoMensagem = false;
            return $noty.close();
          }
        }
      ];
      showBottomNoty(resource.VoceFezAlteracoesQuePodemRefletirNasInformacoesApresentadasGostariaDeRecarregarATela, 15000, btns);
      return api.exibindoMensagem = true;
    }
  };

  return api;

})();
