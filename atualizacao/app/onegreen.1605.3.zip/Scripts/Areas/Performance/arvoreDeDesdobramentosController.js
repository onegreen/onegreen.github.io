﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.arvoreDeDesdobramentosController = (function() {
  function arvoreDeDesdobramentosController(options, contexto1) {
    this.options = options;
    this.contexto = contexto1;
    this.recarregar = bind(this.recarregar, this);
    this.configurarDatePicker = bind(this.configurarDatePicker, this);
    this.proximaOcorrencia = bind(this.proximaOcorrencia, this);
    this.configurarComutadorDeOcorrencia = bind(this.configurarComutadorDeOcorrencia, this);
    this.obterConfiguracaoDeExibicao = bind(this.obterConfiguracaoDeExibicao, this);
    this.exibirOcultarValores = bind(this.exibirOcultarValores, this);
    this.salvarConfiguracoesDeExibicao = bind(this.salvarConfiguracoesDeExibicao, this);
    this.carregarTodosGraficos = bind(this.carregarTodosGraficos, this);
    this.alterarIconeGraficoTabela = bind(this.alterarIconeGraficoTabela, this);
    this.desabilitarProgramadoProjetadoTendencia = bind(this.desabilitarProgramadoProjetadoTendencia, this);
    this.exibirTodosGraficos = bind(this.exibirTodosGraficos, this);
    this.carregarGrafico = bind(this.carregarGrafico, this);
    this.getConfiguracoesDoGrafico = bind(this.getConfiguracoesDoGrafico, this);
    this.removeConfiguracoesDeGraficos = bind(this.removeConfiguracoesDeGraficos, this);
    this.addConfiguracoesDeGraficos = bind(this.addConfiguracoesDeGraficos, this);
    this.eliminarSeparadorRedundantes = bind(this.eliminarSeparadorRedundantes, this);
    this.eliminarInformacoesRedundantes = bind(this.eliminarInformacoesRedundantes, this);
    this.fecharMenuDesdobramento = bind(this.fecharMenuDesdobramento, this);
    this.normalizarDadosDaLinha = bind(this.normalizarDadosDaLinha, this);
    this.alterarBotaoDesdobramento = bind(this.alterarBotaoDesdobramento, this);
    this.ativarDesdobramentos = bind(this.ativarDesdobramentos, this);
    this.esconderDesdobramento = bind(this.esconderDesdobramento, this);
    this.desdobrar = bind(this.desdobrar, this);
    this.carregarMenuDesdobramentos = bind(this.carregarMenuDesdobramentos, this);
    this.loadFuncionalidadesBox = bind(this.loadFuncionalidadesBox, this);
    this.bindDetalhesDoIndicador = bind(this.bindDetalhesDoIndicador, this);
    this.controleApuradoAcumuladoGrafico = bind(this.controleApuradoAcumuladoGrafico, this);
    this.binds = bind(this.binds, this);
    this.alterarPlanoDeGestao = bind(this.alterarPlanoDeGestao, this);
    this.alterarUnidade = bind(this.alterarUnidade, this);
    this.fecharTooltip = bind(this.fecharTooltip, this);
    this.contexto = $(this.contexto);
    this.farolAcumulado = false;
    this.ocorrencia = this.contexto.find('#DataDaOcorrencia');
    this.mesDaOcorrencia = this.contexto.find('#mesDaOcorrencia');
    this.idDoIndicador = this.contexto.find('#idDoIndicador').val();
    this.formaDeVisualizacao = 'Apurado';
    this.arvoreContainer = this.contexto.find('.arvore-grafica');
    this.configuracoesContainer = this.contexto.find('.js-configuracoes-exibicao');
    this.graficos = [];
    this.charts = [];
    this.addConfiguracoesDeGraficos(this.options.grafico);
    this.valoresExibicao = this.contexto.find('.js-valores-exibicao');
    this.botaoExibirGraficos = this.contexto.find('#exibir-graficos');
    this.labelExibirGraficos = this.botaoExibirGraficos.parent();
    this.botaoExibirTabela = this.contexto.find('#exibir-tabela');
    this.labelExibirTabela = this.botaoExibirTabela.parent();
    this.inputApurado = $('[data-valor="apurado"]', this.contexto);
    this.labelApurado = $('[data-valor="apurado"]', this.contexto).parent();
    this.inputAcumulado = $('[data-valor="acumulado"]', this.contexto);
    this.labelAcumulado = $('[data-valor="acumulado"]', this.contexto).parent();
    $('#btnVoltar', this.contexto).click((function(_this) {
      return function() {
        return window.location = window.location;
      };
    })(this));
    if (this.botaoExibirGraficos.is(':checked')) {
      this.exibirTodosGraficos(true, this.contexto, null, false);
    } else {
      this.exibirTodosGraficos(false, this.contexto, null, false);
    }
    this.botaoExibirTabela.on('click', (function(_this) {
      return function() {
        return _this.exibirTodosGraficos(false, _this.contexto, null, false);
      };
    })(this));
    $('.js-grafico', this.contexo).mouseleave((function(_this) {
      return function(e) {
        return _this.fecharTooltip(e.currentTarget);
      };
    })(this));
    this.binds();
    this.configurarComutadorDeOcorrencia();
    window.reload = this.recarregar;
    window.filtroUGEPlanoDeGestao.configurar('#filtro-ug-topo', this.alterarUnidade, this.alterarPlanoDeGestao);
  }

  arvoreDeDesdobramentosController.prototype.fecharTooltip = function(el) {
    var i, j, pointer, ref;
    for (i = j = 0, ref = this.charts.length; 0 <= ref ? j <= ref : j >= ref; i = 0 <= ref ? ++j : --j) {
      if ((this.charts[i] != null) && (this.charts[i].tooltip != null)) {
        this.charts[i].tooltip.hide();
        pointer = this.charts[i].pointer;
        if (pointer != null) {
          pointer.reset();
        }
      }
    }
  };

  arvoreDeDesdobramentosController.prototype.alterarUnidade = function(idDaUnidade) {
    return $as.Performance.FiltroDeIndicadores.MudarUnidadeGerencial.post({
      idDaUnidade: idDaUnidade
    }, {
      global: false
    }).done(function(data) {
      return window.location.reload(true);
    });
  };

  arvoreDeDesdobramentosController.prototype.alterarPlanoDeGestao = function(idDoPlanoDeGestao) {
    return $as.Performance.FiltroDeIndicadores.MudarPlanoDeGestao.post({
      idDoPlanoDeGestao: idDoPlanoDeGestao
    }, {
      global: false
    }).done(function(data) {
      return window.location.reload(true);
    });
  };

  arvoreDeDesdobramentosController.prototype.binds = function() {
    this.ativarDesdobramentos(this.contexto);
    this.loadFuncionalidadesBox(this.contexto);
    $('.js-forma-exibicao').find('input').on('change', (function(_this) {
      return function(e) {
        _this.arvoreContainer.toggleClass('arvore-horizontal arvore-vertical');
        return _this.salvarConfiguracoesDeExibicao(e);
      };
    })(this));
    this.valoresExibicao.find('label').on('click', (function(_this) {
      return function(e) {
        var checkedApuradoAcumulado, checkedTabelaGrafico, input, label;
        label = $(e.currentTarget);
        input = $(label).find('input');
        checkedApuradoAcumulado = $('.js-apurado-acumulado').find('input:checked');
        checkedTabelaGrafico = $('.js-tabela-grafico').find('input:checked');
        if (checkedApuradoAcumulado.length === 1 && checkedApuradoAcumulado.val() === input.val()) {
          e.preventDefault();
          return;
        }
        if (label.parent().hasClass('js-apurado-acumulado') && _this.botaoExibirGraficos.parent().hasClass('active')) {
          return _this.controleApuradoAcumuladoGrafico(input.data('valor'), e);
        }
      };
    })(this));
    this.valoresExibicao.find('input').on('change', this.salvarConfiguracoesDeExibicao);
    $(document).on('show.bs.dropdown', (function(_this) {
      return function(event) {
        return _this.fecharMenuDesdobramento(event);
      };
    })(this));
    $(document).on("click", (function(_this) {
      return function(event) {
        return _this.fecharMenuDesdobramento(event);
      };
    })(this));
    return this.bindDetalhesDoIndicador(this.contexto);
  };

  arvoreDeDesdobramentosController.prototype.controleApuradoAcumuladoGrafico = function(chart, e) {
    if (chart === 'apurado') {
      $(this.inputApurado.data('target')).toggle(true);
      $(this.inputAcumulado.data('target')).toggle(false);
      this.labelAcumulado.removeClass('active btn-warning');
      this.inputAcumulado.removeAttr('checked');
      this.labelApurado.addClass('active btn-warning');
      this.inputApurado.attr('checked', 'checked');
      this.salvarConfiguracoesDeExibicao(e);
    } else {
      $(this.inputApurado.data('target')).toggle(false);
      $(this.inputAcumulado.data('target')).toggle(true);
      this.labelApurado.removeClass('active btn-warning');
      this.inputApurado.removeAttr('checked');
      this.labelAcumulado.addClass('active btn-warning');
      this.inputAcumulado.attr('checked', 'checked');
      this.salvarConfiguracoesDeExibicao(e);
    }
    return this.exibirTodosGraficos(true, this.contexto, chart, false);
  };

  arvoreDeDesdobramentosController.prototype.bindDetalhesDoIndicador = function($contexto) {
    return $contexto.find('.js-exibir-detalhes-indicador').click((function(_this) {
      return function(e) {
        var dados, elemento, tabPadrao;
        elemento = $(e.currentTarget);
        tabPadrao = elemento.data('tabdetalhes');
        dados = elemento.closest('.js-farol').data();
        dados = _this.normalizarDadosDaLinha(dados);
        return Results.api.exibirDetalhesDoIndicador(dados, _this.mesDaOcorrencia.val(), tabPadrao);
      };
    })(this));
  };

  arvoreDeDesdobramentosController.prototype.loadFuncionalidadesBox = function(contexto) {
    return $(contexto).find('.switch-content').each((function(_this) {
      return function() {
        return $(this ).on('click', function() {
          var $botao, boxSelecionado, graficoContainer, item, tipo;
          $botao = $( this );
          item = $botao.closest('.entry-content-wrap');
          if ($botao.hasClass('view-table')) {
            item.addClass('view-table').removeClass('view-bars');
          } else {
            item.addClass('view-bars').removeClass('view-table');
          }
          if ($botao.data('chart') === 'acumulado') {
            $botao.toggleClass('view-acumulado view-table');
            $('.switch-content[data-chart="apurado"]', contexto).removeClass('view-table').addClass('view-apurado');
          } else {
            $botao.toggleClass('view-apurado view-table');
            $('.switch-content[data-chart="acumulado"]', contexto).removeClass('view-table').addClass('view-acumulado');
          }
          if (item.hasClass('view-bars')) {
            boxSelecionado = $botao.closest('.js-farol');
            graficoContainer = boxSelecionado.find('.js-grafico');
            tipo = $botao.data('chart');
            if (!graficoContainer.data('carregado') || graficoContainer.data('chart') !== tipo) {
              graficoContainer.data('carregado', true);
              graficoContainer.data('chart', tipo);
              return _this.carregarGrafico(graficoContainer, boxSelecionado.attr('id'), $botao.data('chart'));
            }
          }
        });
      };
    })(this));
  };

  arvoreDeDesdobramentosController.prototype.carregarMenuDesdobramentos = function(event) {
    var botao, boxSelecionado, containerMenu, informacoes;
    botao = $(event.delegateTarget);
    boxSelecionado = botao.closest('.js-farol');
    informacoes = this.normalizarDadosDaLinha(boxSelecionado.data());
    containerMenu = $('.js-container-desdobramentos', botao.closest('.js-menu-desdobramentos-container'));
    if (!botao.closest('.js-menu-desdobramentos-container').hasClass('open')) {
      return $as.Performance.FarolDeIndicadores.MenuParaDesdobramentos.get(informacoes).done((function(_this) {
        return function(html) {
          var itensDoMenu;
          containerMenu.html(html);
          itensDoMenu = containerMenu.find('.js-desdobrar-indicador');
          itensDoMenu.unbind('click').on('click', _this.desdobrar);
          if (itensDoMenu.length === 1) {
            return itensDoMenu.find('a').click();
          } else {
            return containerMenu.show();
          }
        };
      })(this));
    }
  };

  arvoreDeDesdobramentosController.prototype.desdobrar = function(event) {
    var botao, branch, informacoes, linhaSelecionada;
    $('.js-container-desdobramentos[style]:visible').hide();
    botao = $(event.delegateTarget);
    linhaSelecionada = botao.closest('.js-farol');
    informacoes = this.normalizarDadosDaLinha(linhaSelecionada.data());
    informacoes.IdTipoDeDesdobramento = botao.data('item');
    informacoes.Tipo = botao.data('tipo');
    informacoes.DimensaoADesdobrar = botao.data('dimensao');
    informacoes.FarolAcumulado = this.farolAcumulado;
    informacoes.ocorrencia = this.ocorrencia.val();
    informacoes.formaDeVisualizacao = this.formaDeVisualizacao;
    informacoes.configuracaoDeExibicao = this.obterConfiguracaoDeExibicao();
    branch = linhaSelecionada.closest('.js-pai').find('.branch');
    return $as.Performance.ArvoreDeDesdobramentos.DesdobrarIndicador.get(informacoes).done((function(_this) {
      return function(data) {
        var html;
        _this.addConfiguracoesDeGraficos(data.configuracoesDosGraficos);
        html = data.html;
        html = $($.parseHTML(html));
        if (!_this.options.TiposDeDesdobramentoQueNaoOcultamInformacoes.contains(informacoes.TipoDeDesdobramento)) {
          _this.eliminarInformacoesRedundantes(informacoes, html);
        }
        branch.html(html);
        _this.alterarBotaoDesdobramento(botao);
        _this.ativarDesdobramentos(branch);
        _this.loadFuncionalidadesBox(branch);
        _this.exibirTodosGraficos(linhaSelecionada.find('.view-bars').length, branch, linhaSelecionada.find('.js-grafico').data('chart'), true);
        _this.bindDetalhesDoIndicador(branch);
        branch.prev('.js-farol').removeClass('noleaf');
        return $('.js-grafico', _this.contexo).unbind('mouseleave').mouseleave(function(e) {
          return _this.fecharTooltip(e.currentTarget);
        });
      };
    })(this));
  };

  arvoreDeDesdobramentosController.prototype.esconderDesdobramento = function(event) {
    var botao, branch, item, j, len, ref;
    botao = $(event.delegateTarget);
    botao.closest('.js-menu-desdobramentos-container').find('.js-container-desdobramentos').empty();
    branch = botao.closest('.js-pai').find('.branch');
    branch.prev('.js-farol').addClass('noleaf');
    ref = branch.find('.entry-separator');
    for (j = 0, len = ref.length; j < len; j++) {
      item = ref[j];
      this.removeConfiguracoesDeGraficos($(item).attr('id'), false);
    }
    branch.html('');
    this.alterarBotaoDesdobramento(botao);
    return this.ativarDesdobramentos(this.contexto);
  };

  arvoreDeDesdobramentosController.prototype.ativarDesdobramentos = function(contexto) {
    $(contexto).find('.js-menu-desdobramentos').unbind('click').on('click', this.carregarMenuDesdobramentos);
    return $(contexto).find('.js-esconder-desdobramentos').unbind('click').on('click', this.esconderDesdobramento);
  };

  arvoreDeDesdobramentosController.prototype.alterarBotaoDesdobramento = function(botao) {
    var botaoContainer, botoesDesdobrar;
    botaoContainer = botao.closest('.js-menu-desdobramentos-container');
    botoesDesdobrar = $('.js-menu-desdobramentos, .js-esconder-desdobramentos', botaoContainer);
    return botoesDesdobrar.toggleClass('none');
  };

  arvoreDeDesdobramentosController.prototype.normalizarDadosDaLinha = function(dados) {
    return {
      Dimensao1: dados.dimensao1,
      Dimensao2: dados.dimensao2,
      Dimensao3: dados.dimensao3,
      Dimensao4: dados.dimensao4,
      Dimensao5: dados.dimensao5,
      Dimensao6: dados.dimensao6,
      GuidPai: dados.guidpai,
      Hierarquia: dados.hierarquia,
      IdentificadorDaLinha: dados.identificadordalinha,
      IdIndicador: dados.idindicador,
      IdIndicadorBase: dados.idindicadorbase,
      IdUnidade: dados.idunidade,
      IdUnidadeRelacionada: dados.idunidaderelacionada,
      IdIndicadorDeOrigem: dados.idindicadordeorigem,
      PossuiApenasReal: dados.possuiapenasreal,
      Referencia: dados.referencia,
      SiglaDoTipoDeIndicador: dados.sigladotipodeindicador,
      SinalMelhor: dados.sinalmelhor,
      TipoDeDesdobramento: dados.tipodedesdobramento,
      UnidadeDeMedida: dados.unidadedemedida,
      IdDoPlanoDeGestao: dados.iddoplanodegestao,
      FormaDeVisualizacao: dados.formadevisualizacao,
      Frequencia: this.options.Frequencia,
      NumeroDoMes: this.mesDaOcorrencia.val()
    };
  };

  arvoreDeDesdobramentosController.prototype.fecharMenuDesdobramento = function(event) {
    if (!($(event.target).hasClass("js-container-desdobramentos") || $(event.target).parent().hasClass("js-desdobrar-indicador"))) {
      return $('.js-container-desdobramentos[style]:visible').hide();
    }
  };

  arvoreDeDesdobramentosController.prototype.eliminarInformacoesRedundantes = function(informacoes, html) {
    var farol, j, len, partesDoNome, ref;
    $("span[data-idunidade=" + informacoes.IdUnidade + "]", $(html)).remove();
    $("span[data-unidadedemedida='" + informacoes.UnidadeDeMedida + "']", $(html)).remove();
    $("span[data-idindicadorbase=" + informacoes.IdIndicadorBase + "]", $(html)).hide();
    $("[data-tipoindicador=" + informacoes.IdIndicadorBase + informacoes.SiglaDoTipoDeIndicador + "]", $(html)).remove();
    $("i.sw-" + (informacoes.SinalMelhor.toLowerCase()), $(html)).remove();
    $("[data-iddimensao=" + informacoes.Dimensao1 + "]", $(html)).remove();
    $("[data-iddimensao=" + informacoes.Dimensao2 + "]", $(html)).remove();
    $("[data-iddimensao=" + informacoes.Dimensao3 + "]", $(html)).remove();
    $("[data-iddimensao=" + informacoes.Dimensao4 + "]", $(html)).remove();
    $("[data-iddimensao=" + informacoes.Dimensao5 + "]", $(html)).remove();
    $("[data-iddimensao=" + informacoes.Dimensao6 + "]", $(html)).remove();
    if (informacoes.TipoDeDesdobramento === 2) {
      $("[data-tipoindicador]", $(html)).remove();
    }
    ref = $(html).find('.js-farol');
    for (j = 0, len = ref.length; j < len; j++) {
      farol = ref[j];
      farol = $(farol);
      this.eliminarSeparadorRedundantes(farol);
      partesDoNome = $('.js-parte-nome-indicador', farol);
      if (partesDoNome.length === 1) {
        partesDoNome.show();
      }
    }
    return html;
  };

  arvoreDeDesdobramentosController.prototype.eliminarSeparadorRedundantes = function(tr) {
    if ($("span[data-iddimensao]", tr).length <= 1) {
      $("span.separadorDimensao", tr).remove();
    }
    if ($("span[data-tipoindicador]", tr).next().length === 0) {
      $("span.separadorTipo", tr).remove();
    }
    return tr;
  };

  arvoreDeDesdobramentosController.prototype.addConfiguracoesDeGraficos = function(lista) {
    var item, j, len;
    for (j = 0, len = lista.length; j < len; j++) {
      item = lista[j];
      this.graficos.push(item);
    }
  };

  arvoreDeDesdobramentosController.prototype.removeConfiguracoesDeGraficos = function(idElemento, removerApenasChart) {
    var fn;
    fn = function(item) {
      return item.idElemento === idElemento;
    };
    if (!removerApenasChart) {
      this.graficos.removeByCondition(fn);
    }
    this.charts.removeByCondition(fn);
    return Highcharts.charts.removeByCondition(fn);
  };

  arvoreDeDesdobramentosController.prototype.getConfiguracoesDoGrafico = function(idElemento) {
    return $.grep(this.graficos, (function(_this) {
      return function(e) {
        return e.idElemento === idElemento;
      };
    })(this));
  };

  arvoreDeDesdobramentosController.prototype.carregarGrafico = function(container, idElement, tipo) {
    var chart, configuracao, grafico;
    if (tipo === 'apurado') {
      configuracao = this.getConfiguracoesDoGrafico(idElement)[0].valoresApurado;
    } else {
      configuracao = this.getConfiguracoesDoGrafico(idElement)[0].valoresAcumulado;
    }
    grafico = ModelosDeGrafico.api.getConfig(configuracao.grafico);
    chart = ModelosDeGrafico.api.build(container, grafico, configuracao.series);
    chart.idElemento = idElement;
    this.removeConfiguracoesDeGraficos(idElement, true);
    return this.charts.push(chart);
  };

  arvoreDeDesdobramentosController.prototype.exibirTodosGraficos = function(exibir, contexto, chart, desdobrando) {
    if (exibir) {
      $(contexto).find('.entry-content-wrap').removeClass('view-table').addClass('view-bars');
      this.carregarTodosGraficos(chart, desdobrando);
      if ($('.js-apurado-acumulado', this.contexto).find('input:checked').length > 1) {
        this.labelAcumulado.removeClass('active btn-warning');
        this.inputAcumulado.removeAttr('checked');
      }
      if (!desdobrando) {
        this.desabilitarProgramadoProjetadoTendencia(true);
      }
      return this.alterarIconeGraficoTabela(chart, contexto);
    } else {
      $(contexto).find('.entry-content-wrap').removeClass('view-bars').addClass('view-table');
      this.alterarIconeGraficoTabela('tabela', contexto);
      if (!desdobrando) {
        return this.desabilitarProgramadoProjetadoTendencia(false);
      }
    }
  };

  arvoreDeDesdobramentosController.prototype.desabilitarProgramadoProjetadoTendencia = function(desabilitar) {
    if (desabilitar === true) {
      return $('.js-valores-tabela label', this.contexto).attr('disabled', 'disabled');
    } else {
      return $('.js-valores-tabela label', this.contexto).removeAttr('disabled');
    }
  };

  arvoreDeDesdobramentosController.prototype.alterarIconeGraficoTabela = function(chart, contexto) {
    var tipo;
    tipo = $('.js-apurado-acumulado', this.contexto).find('.active').length > 1 ? 'apurado' : $('.js-apurado-acumulado', this.contexto).find('.active input').data('valor');
    tipo = chart !== null ? chart : tipo;
    contexto = contexto || this.contexto;
    if (tipo === 'apurado') {
      $(".switch-content[data-chart='apurado']", contexto).addClass('view-table').removeClass('view-apurado');
      return $(".switch-content[data-chart='acumulado']", contexto).removeClass('view-table').addClass('view-acumulado');
    } else if (tipo === 'acumulado') {
      $(".switch-content[data-chart='apurado']", contexto).removeClass('view-table').addClass('view-apurado');
      return $(".switch-content[data-chart='acumulado']", contexto).addClass('view-table').removeClass('view-acumulado');
    } else {
      $(".switch-content[data-chart='apurado']", contexto).removeClass('view-table').addClass('view-apurado');
      return $(".switch-content[data-chart='acumulado']", contexto).removeClass('view-table').addClass('view-acumulado');
    }
  };

  arvoreDeDesdobramentosController.prototype.carregarTodosGraficos = function(chart, desdobrando) {
    var graficoContainer, item, j, len, ref, tipo;
    ref = this.graficos;
    for (j = 0, len = ref.length; j < len; j++) {
      item = ref[j];
      if ($("#" + item.idElemento).find('.entry-content-wrap').hasClass('view-bars')) {
        graficoContainer = $("#" + item.idElemento).find('.js-grafico');
        tipo = $('.js-apurado-acumulado', this.contexto).find('.active').length > 1 ? 'apurado' : $('.js-apurado-acumulado', this.contexto).find('.active input').data('valor');
        tipo = chart !== null ? chart : tipo;
        if (!graficoContainer.data('carregado') || (graficoContainer.data('chart') !== tipo && !desdobrando)) {
          graficoContainer.data('carregado', true);
          graficoContainer.data('chart', tipo);
          this.carregarGrafico(graficoContainer, item.idElemento, tipo);
        }
      }
    }
  };

  arvoreDeDesdobramentosController.prototype.salvarConfiguracoesDeExibicao = function(e) {
    var $input, configValores;
    if (e !== null) {
      $input = $(e.currentTarget);
      if (!['Horizontal', 'Vertical'].contains($input.val())) {
        this.exibirOcultarValores($input);
      }
    }
    configValores = this.obterConfiguracaoDeExibicao();
    if (this.idDoIndicador !== "") {
      return $as.Performance.ArvoreDeDesdobramentos.SalvarConfiguracoesDeExibicao.post({
        idDoIndicador: this.idDoIndicador,
        exibicaoDeValores: configValores,
        formaDeDesdobramento: this.contexto.find('.js-forma-exibicao input:checked').val()
      }, {
        global: false
      }).done((function(_this) {
        return function(data) {};
      })(this));
    }
  };

  arvoreDeDesdobramentosController.prototype.exibirOcultarValores = function($input) {
    var target;
    if ($input.data('target') === '.js-mostrar-grafico') {
      return this.exibirTodosGraficos($input.is(':checked'), this.contexto, null, false);
    } else {
      target = $input.data('target');
      return $(target).toggle($input.is(':checked'));
    }
  };

  arvoreDeDesdobramentosController.prototype.obterConfiguracaoDeExibicao = function() {
    var configValores;
    configValores = 0;
    this.configuracoesContainer.find('input[type=checkbox]:checked, input[type=radio]:checked').each(function(index, input) {
      if (!isNaN(parseInt($(input).val()))) {
        configValores += parseInt($(input).val());
      }
    });
    return configValores;
  };

  arvoreDeDesdobramentosController.prototype.configurarComutadorDeOcorrencia = function() {
    $("#proximoMes", this.contexto).click((function(_this) {
      return function() {
        return _this.proximaOcorrencia(1);
      };
    })(this));
    $("#mesAnterior", this.contexto).click((function(_this) {
      return function() {
        return _this.proximaOcorrencia(-1);
      };
    })(this));
    return this.configurarDatePicker();
  };

  arvoreDeDesdobramentosController.prototype.proximaOcorrencia = function(salto) {
    return $as.Performance.ArvoreDeDesdobramentos.ObterProximaOcorrencia.post({
      ocorrencia: this.ocorrencia.val(),
      salto: salto
    }, {
      global: false
    }).done((function(_this) {
      return function(data) {
        _this.ocorrencia.val(data);
        return _this.recarregar();
      };
    })(this));
  };

  arvoreDeDesdobramentosController.prototype.configurarDatePicker = function() {
    return $('#date-picker-mensal', this.contexto).click((function(_this) {
      return function() {
        return DatePickerCustom.setDatePickerCustom('date-picker-mensal', 'comutador-frequencia-container', 'DataDaOcorrencia', _this.recarregar, $('#DataDaOcorrencia').val(), _this.options.DataInicioLimite, _this.options.DataFinalLimite, false, 'months');
      };
    })(this));
  };

  arvoreDeDesdobramentosController.prototype.recarregar = function() {
    var dados;
    dados = this.contexto.find('.js-farol:first').data();
    dados.ocorrencia = this.ocorrencia.val();
    return $as.Performance.ArvoreDeDesdobramentos.Index.post(dados).done((function(_this) {
      return function(data) {
        return $('#main').html(data);
      };
    })(this));
  };

  return arvoreDeDesdobramentosController;

})();
