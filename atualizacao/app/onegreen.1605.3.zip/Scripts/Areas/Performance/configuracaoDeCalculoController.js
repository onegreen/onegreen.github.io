﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  slice = [].slice,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

this.configuracaoDeCalculoController = (function() {
  function configuracaoDeCalculoController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.configurarFormula = bind(this.configurarFormula, this);
    this.salvarEConfigurarFormula = bind(this.salvarEConfigurarFormula, this);
    this.salvar = bind(this.salvar, this);
    this.atualizarFormula = bind(this.atualizarFormula, this);
    this.liberarCheckbox = bind(this.liberarCheckbox, this);
    this.bloquearCheckbox = bind(this.bloquearCheckbox, this);
    this.exibirElementos = bind(this.exibirElementos, this);
    this.esconderElementos = bind(this.esconderElementos, this);
    this.configurarExibicaoDeCamposPorTipoDeCalculo = bind(this.configurarExibicaoDeCamposPorTipoDeCalculo, this);
    this.ativarExibicaoDeCamposPorTipoDeCalculo = bind(this.ativarExibicaoDeCamposPorTipoDeCalculo, this);
    this.binds = bind(this.binds, this);
    $(this.contexto).window({
      width: '700px'
    });
    this.recursos = this.options.recursos;
    this.loadDropDownTipoDeCalculo();
    this.loadComboModelosDeConsulta();
    this.binds();
    $("[rel=tooltip]", this.contexto).tooltip();
    setTimeout((function(_this) {
      return function() {
        return $(_this.contexto).on('hidden.bs.modal', function() {
          return $( this ).parent().empty();
        });
      };
    })(this), 50);
  }

  configuracaoDeCalculoController.prototype.binds = function() {
    $('#TipoDeCalculo-dropdown li', this.contexto).click(this.ativarExibicaoDeCamposPorTipoDeCalculo);
    return $("#editar-formula", this.contexto).click(this.salvar);
  };

  configuracaoDeCalculoController.prototype.ativarExibicaoDeCamposPorTipoDeCalculo = function(event) {
    var tipoDeCalculo;
    tipoDeCalculo = $(event.delegateTarget).attr('value');
    $('input[type=checkbox]:checked', this.contexto).click();
    this.liberarCheckbox('#FrequenciasAplicaveisApurado_Mensal', '#FrequenciasAplicaveisApurado_Semanal', '#FrequenciasAplicaveisApurado_Diaria');
    this.exibirElementos('#divisao-por-zero', '#calculos-incompletos', '#formula', 'label[for=Aplicacao_Tendencia]', '#extracao');
    return this.configurarExibicaoDeCamposPorTipoDeCalculo(tipoDeCalculo);
  };

  configuracaoDeCalculoController.prototype.configurarExibicaoDeCamposPorTipoDeCalculo = function(tipoDeCalculo) {
    switch (tipoDeCalculo) {
      case 14:
        this.bloquearCheckbox('#FrequenciasAplicaveisApurado_Mensal', '#FrequenciasAplicaveisApurado_Semanal', '#FrequenciasAplicaveisApurado_Diaria');
        this.esconderElementos('#divisao-por-zero', '#calculos-incompletos', '#formula', 'label[for=Aplicacao_Tendencia]', '#extracao');
        break;
      case 12:
        this.bloquearCheckbox('#FrequenciasAplicaveisApurado_Diaria');
        this.esconderElementos('#divisao-por-zero', '#formula', '#extracao');
        break;
      case 11:
        this.bloquearCheckbox('#FrequenciasAplicaveisApurado_Diaria');
        this.esconderElementos('#divisao-por-zero', '#calculos-incompletos', '#formula', '#extracao');
        break;
      case 3:
        this.esconderElementos('#divisao-por-zero', '#calculos-incompletos', '#formula', 'label[for=Aplicacao_Tendencia]');
        break;
      case 2:
        this.esconderElementos('#extracao');
    }
  };

  configuracaoDeCalculoController.prototype.esconderElementos = function() {
    var elemento, elementos, i, len;
    elementos = 1 <= arguments.length ? slice.call(arguments, 0) : [];
    for (i = 0, len = elementos.length; i < len; i++) {
      elemento = elementos[i];
      elemento = $("" + (elemento.trim()), this.contexto);
      elemento.hide();
    }
  };

  configuracaoDeCalculoController.prototype.exibirElementos = function() {
    var elemento, elementos, i, len;
    elementos = 1 <= arguments.length ? slice.call(arguments, 0) : [];
    for (i = 0, len = elementos.length; i < len; i++) {
      elemento = elementos[i];
      elemento = $("" + (elemento.trim()), this.contexto);
      elemento.show();
    }
  };

  configuracaoDeCalculoController.prototype.bloquearCheckbox = function() {
    var campo, campos, checkbox, i, len;
    campos = 1 <= arguments.length ? slice.call(arguments, 0) : [];
    for (i = 0, len = campos.length; i < len; i++) {
      campo = campos[i];
      checkbox = $("" + (campo.trim()), this.contexto);
      checkbox.parent('label').addClass('disabled');
      checkbox.attr('disabled', 'disabled');
    }
  };

  configuracaoDeCalculoController.prototype.liberarCheckbox = function() {
    var campo, campos, checkbox, i, len;
    campos = 1 <= arguments.length ? slice.call(arguments, 0) : [];
    for (i = 0, len = campos.length; i < len; i++) {
      campo = campos[i];
      checkbox = $("" + (campo.trim()), this.contexto);
      checkbox.parent('label').removeClass('disabled');
      checkbox.removeAttr('disabled');
    }
  };

  configuracaoDeCalculoController.prototype.loadDropDownTipoDeCalculo = function() {
    return setDropDown(this.contexto, '#TipoDeCalculo-dropdown');
  };

  configuracaoDeCalculoController.prototype.loadComboModelosDeConsulta = function() {
    return setCombo(this.contexto, '#ModeloDeConsulta_Nome');
  };

  configuracaoDeCalculoController.reload = function(idDoIndicador) {
    return $as.Performance.ConfiguracoesDeCalculo.Index.get({
      idDoPai: idDoIndicador
    }).success(function(data) {
      $('#calculos-container', '#calculos-panel').html(data);
      return $('[rel=tooltip]').tooltip();
    });
  };

  configuracaoDeCalculoController.aoAlterarModoDeExibicaoDasConfiguracoes = function(ocultarConfiguracoes) {
    if (ocultarConfiguracoes) {
      $('#btn-ocultar-excluidas', '#calculos-panel').show();
      $('#btn-exibir-excluidas', '#calculos-panel').hide();
    } else {
      $('#btn-ocultar-excluidas', '#calculos-panel').hide();
      $('#btn-exibir-excluidas', '#calculos-panel').show();
    }
    return $('[rel=tooltip]').tooltip();
  };

  configuracaoDeCalculoController.prototype.atualizarFormula = function(formula) {
    $("#editar-formula", this.contexto).text(formula);
    return $(this.contexto).find("#TextoDaFormula").val(formula);
  };

  configuracaoDeCalculoController.prototype.salvar = function(event) {
    if ($(event.currentTarget).data('salvar')) {
      this.salvarEConfigurarFormula();
    } else {
      this.configurarFormula();
    }
  };

  configuracaoDeCalculoController.prototype.salvarEConfigurarFormula = function() {
    var dados;
    dados = $('form', this.contexto).serialize();
    return $as.Performance.ConfiguracoesDeCalculo.Create.post(dados).done((function(_this) {
      return function(res) {
        var idDaConfiguracao;
        idDaConfiguracao = res.data.id;
        configuracaoDeCalculoController.reload(_this.options.idDoIndicador);
        return $as.Performance.ConfiguracoesDeCalculo.Edit.get({
          id: idDaConfiguracao
        }).done(function(data) {
          $("#main-modal").html(data);
          return _this.configurarFormula(idDaConfiguracao);
        });
      };
    })(this));
  };

  configuracaoDeCalculoController.prototype.configurarFormula = function(idDaConfiguracao) {
    return $as.Performance.ConfiguracoesDeCalculo.ConfigurarFormula.get({
      id: idDaConfiguracao || $("#Id", this.contexto).val()
    }).done((function(_this) {
      return function(html) {
        return window.GetDiv("box-configurar-formula").html(html);
      };
    })(this));
  };

  configuracaoDeCalculoController.configurarFormula = (function(superClass) {
    extend(configurarFormula, superClass);

    function configurarFormula(view) {
      var configurarFormula;
      this.view = view;
      this.aoExcluirItem = bind(this.aoExcluirItem, this);
      this.gerarTexto = bind(this.gerarTexto, this);
      this.formulaMediaNaoNulos = bind(this.formulaMediaNaoNulos, this);
      this.formulaMediaDosItens = bind(this.formulaMediaDosItens, this);
      this.formulaSomaDosItens = bind(this.formulaSomaDosItens, this);
      this.alterarFormaDeCalculo = bind(this.alterarFormaDeCalculo, this);
      this.aoSalvar = bind(this.aoSalvar, this);
      this.reloadItens = bind(this.reloadItens, this);
      configurarFormula = new window.configurarFormulaController(this.view, this.alterarFormaDeCalculo, this.gerarTexto);
      (this.get('#btn-somaItens')).click(this.alterarFormaDeCalculo);
      (this.get('#btn-mediaItens')).click(this.alterarFormaDeCalculo);
      (this.get('#btn-mediaNaoNulos')).click(this.alterarFormaDeCalculo);
    }

    configurarFormula.prototype.reloadItens = function() {
      return $("#itens-da-configuracao-container").load($as.Performance.ItensDaConfiguracaoDeCalculo.Index.url, {
        idDoPai: $(this.view).find("#Id").val()
      });
    };

    configurarFormula.prototype.aoSalvar = function(data) {
      var textoDaFormula;
      if (data.data.textoDaFormula === '') {
        textoDaFormula = window.ConfiguracaoDeCalculo.recursos.CliqueAquiParaDefinirAFormulaParaOCalculo;
      } else {
        textoDaFormula = data.data.textoDaFormula;
      }
      window.ConfiguracaoDeCalculo.atualizarFormula(textoDaFormula);
      return this.reloadItens();
    };

    configurarFormula.prototype.alterarFormaDeCalculo = function(e) {
      var $el, descricao, forma;
      $el = $(e.currentTarget);
      forma = $el.data('forma');
      descricao;
      switch (forma) {
        case 'SomaDosItens':
          descricao = this.formulaSomaDosItens();
          break;
        case 'MediaDosItens':
          descricao = this.formulaMediaDosItens();
          break;
        case "MediaDosItensNaoNulos":
          descricao = this.formulaMediaNaoNulos();
      }
      return $('#TextoDaFormula', this.view).val(descricao);
    };

    configurarFormula.prototype.formulaSomaDosItens = function() {
      var formula;
      formula = '';
      $("#itens-da-configuracao-container tr.mostrar-hover", this.view).map((function(_this) {
        return function(index, item) {
          var descricaoItem;
          descricaoItem = '[Item ' + $(item).data('ord') + ']';
          if (index > 0) {
            descricaoItem = "+" + descricaoItem;
          }
          return formula += descricaoItem;
        };
      })(this));
      return formula;
    };

    configurarFormula.prototype.formulaMediaDosItens = function() {
      var count, formula;
      formula = '';
      count = $("#itens-da-configuracao-container tr.mostrar-hover", this.view).length;
      if (count > 0) {
        formula = '(' + this.formulaSomaDosItens() + ')' + ' / ' + count;
      }
      return formula;
    };

    configurarFormula.prototype.formulaMediaNaoNulos = function() {
      var count, formula;
      formula = '';
      count = $("#itens-da-configuracao-container tr.mostrar-hover", this.view).length;
      if (count > 0) {
        formula = '(' + this.formulaSomaDosItens() + ')' + ' / [NOT NULL ITENS]';
      }
      return formula;
    };

    configurarFormula.prototype.gerarTexto = function(el) {
      var $el, ord;
      $el = $(el).closest('tr');
      ord = $el.data('ord');
      return "[Item " + ord + "]";
    };

    configurarFormula.prototype.aoExcluirItem = function() {
      return $("form", this.view).submit();
    };

    return configurarFormula;

  })(window.baseController);

  return configuracaoDeCalculoController;

})();
