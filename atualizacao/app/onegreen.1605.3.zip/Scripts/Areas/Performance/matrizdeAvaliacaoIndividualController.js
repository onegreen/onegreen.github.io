﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.matrizDeAvaliacaoIndividualController = (function() {
  function matrizDeAvaliacaoIndividualController(contexto) {
    this.contexto = contexto;
    this.configurarScroll = bind(this.configurarScroll, this);
    $('[rel=tooltip]').tooltip();
    this.listaAvaliacao = $('.matriz-avaliacao-esq');
    this.listaPontuacao = $('.matriz-avaliacao-dir');
    this.configurarScroll();
  }

  matrizDeAvaliacaoIndividualController.prototype.configurarScroll = function() {
    var listaPontuacao, mousewheelevt, onScroll;
    if (!/Firefox/i.test(navigator.userAgent)) {
      this.listaAvaliacao.scroll((function(_this) {
        return function(data) {
          return _this.scrollLista(data, _this.listaPontuacao);
        };
      })(this));
    }
    this.listaPontuacao.scroll((function(_this) {
      return function(data) {
        return _this.scrollLista(data, _this.listaAvaliacao);
      };
    })(this));
    mousewheelevt = /Firefox/i.test(navigator.userAgent) ? "DOMMouseScroll" : "mousewheel";
    listaPontuacao = this.listaPontuacao;
    onScroll = function(e) {
      var scroll;
      scroll = listaPontuacao.scrollTop() + (-e.wheelDelta || e.detail * 40);
      return listaPontuacao.scrollTop(scroll);
    };
    if (this.listaPontuacao.length > 0) {
      if (document.attachEvent) {
        return this.listaAvaliacao[0].attachEvent("on" + mousewheelevt, function(e) {
          return onScroll(e);
        });
      } else if (document.addEventListener) {
        return this.listaAvaliacao[0].addEventListener(mousewheelevt, function(e) {
          return onScroll(e);
        }, false);
      }
    }
  };

  matrizDeAvaliacaoIndividualController.prototype.scrollLista = function(data, lista) {
    return lista.scrollTop(data.target.scrollTop);
  };

  return matrizDeAvaliacaoIndividualController;

})();
