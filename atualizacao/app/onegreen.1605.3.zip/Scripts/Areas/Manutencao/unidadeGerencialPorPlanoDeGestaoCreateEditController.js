﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.unidadeGerencialPorPlanoDeGestaoCreateEditController = (function() {
  function unidadeGerencialPorPlanoDeGestaoCreateEditController(options) {
    this.options = options;
    this.aoSalvar = bind(this.aoSalvar, this);
    this.loadFunctions = bind(this.loadFunctions, this);
    this.configurarMisssaoEVisao = bind(this.configurarMisssaoEVisao, this);
    this.desvincularAoPlanoDeGestao = bind(this.desvincularAoPlanoDeGestao, this);
    this.vincularAoPlanoDeGestao = bind(this.vincularAoPlanoDeGestao, this);
    this.mudarUnidadePorPlanoDeGestao = bind(this.mudarUnidadePorPlanoDeGestao, this);
    this.marcarPlanoDeGestao = bind(this.marcarPlanoDeGestao, this);
    this.carregarComboUnidadeSubordinada = bind(this.carregarComboUnidadeSubordinada, this);
    this.carregarComboEstado = bind(this.carregarComboEstado, this);
    this.carregarComboResponsavel = bind(this.carregarComboResponsavel, this);
    this.contexto = "#unidade-modal";
    $("#PlanoDeGestaoId").val($("input[type=hidden]#IdPlanoDeGestao").val());
    this.loadFunctions();
    $('#btn-desvincular').on('click', (function(_this) {
      return function(e) {
        return _this.desvincularAoPlanoDeGestao();
      };
    })(this));
    $("#btn-Fechar").click(function(e) {
      return $("#unidadegerencialporplanodegestao-modal-container").html("");
    });
    $("#btn-salvar", "#unidade-modal").on("click", (function(_this) {
      return function(e) {
        return $("#form-unidade-gerencial-por-plano-de-gestao", _this.contexto).submit();
      };
    })(this));
    $("#listaExercicios li").css("width", "110px");
    $("#Sigla").focus();
  }

  unidadeGerencialPorPlanoDeGestaoCreateEditController.prototype.carregarComboResponsavel = function() {
    return setCombo(this.contexto, '#UsuarioNome');
  };

  unidadeGerencialPorPlanoDeGestaoCreateEditController.prototype.carregarComboEstado = function() {
    return setCombo(this.contexto, '#EstadoSigla');
  };

  unidadeGerencialPorPlanoDeGestaoCreateEditController.prototype.carregarComboUnidadeSubordinada = function() {
    return setCombo(this.contexto, '#UnidadeSuperiorSigla', null, {
      idDaUnidadeSubordinada: this.options.idDaUnidadeGerencial,
      idDoPlanoDeGestao: $("input[type=hidden]#IdPlanoDeGestao").val()
    });
  };

  unidadeGerencialPorPlanoDeGestaoCreateEditController.prototype.marcarPlanoDeGestao = function() {
    var index, planoDeGestao;
    planoDeGestao = $("#" + this.options.planoDeGestao, "#listaExercicios");
    index = planoDeGestao.parent().parent().index();
    planoDeGestao.parent().addClass("active");
    return $('#listaExercicios').data('movingBoxes').change(index + 1);
  };

  unidadeGerencialPorPlanoDeGestaoCreateEditController.prototype.mudarUnidadePorPlanoDeGestao = function(el) {
    var idDoPlanoDeGestao;
    $("#listaExercicios li div").removeClass("active");
    $(el).parent().addClass("active");
    idDoPlanoDeGestao = $(el).attr("id");
    $("#PlanoDeGestaoId").val(idDoPlanoDeGestao);
    return $.ajax({
      type: "GET",
      url: this.options.edit,
      data: {
        idDaUnidade: this.options.idDaUnidadeGerencial,
        idDoPlanoDeGestao: idDoPlanoDeGestao
      },
      success: (function(_this) {
        return function(data) {
          $("#divFormCadastro").html($("#divFormCadastro", data).html());
          if ($("#vincularAoPlanoDeGestao", data).attr("id") === null || $("#vincularAoPlanoDeGestao", data).attr("id") === void 0) {
            $("#btn-salvar", _this.contexto).show();
            $("#btn-desvincular", _this.contexto).show();
            return _this.loadFunctions();
          } else {
            $("#btn-salvar", _this.contexto).hide();
            return $("#btn-desvincular", _this.contexto).hide();
          }
        };
      })(this)
    });
  };

  unidadeGerencialPorPlanoDeGestaoCreateEditController.prototype.vincularAoPlanoDeGestao = function() {
    var idDaUnidade, idDoPlanoDeGestao;
    idDoPlanoDeGestao = $("#listaExercicios li div.active a").attr("id");
    idDaUnidade = this.options.idDaUnidadeGerencial;
    return $.ajax({
      type: 'GET',
      url: this.options.vincularAoPlanoDeGestao,
      data: {
        idDaUnidadeGerencial: idDaUnidade,
        idDoPlanoDeGestao: idDoPlanoDeGestao
      },
      success: (function(_this) {
        return function(data) {
          $("#divFormCadastro").html($("#divFormCadastro", data).html());
          $("#btn-salvar", _this.contexto).show();
          $("#btn-desvincular", _this.contexto).show();
          if ($("#vincularAoPlanoDeGestao", data).attr("id") === null || $("#vincularAoPlanoDeGestao", data).attr("id") === void 0) {
            return _this.loadFunctions();
          }
        };
      })(this)
    });
  };

  unidadeGerencialPorPlanoDeGestaoCreateEditController.prototype.desvincularAoPlanoDeGestao = function() {
    var idDaUnidade, idDoPlanoDeGestao;
    idDoPlanoDeGestao = $("#listaExercicios li div.active a").attr("id");
    idDaUnidade = this.options.idDaUnidadeGerencial;
    return $.ajax({
      type: 'POST',
      url: $as.Manutencao.UnidadeGerencialPorPlanoDeGestao.DesvincularAoPlanoDeGestao.url,
      data: {
        idUnidade: $('#Id', this.contexto).val()
      },
      success: (function(_this) {
        return function() {
          return $('#listaExercicios li.current a', _this.contexto).click();
        };
      })(this)
    });
  };

  unidadeGerencialPorPlanoDeGestaoCreateEditController.prototype.configurarMisssaoEVisao = function() {
    $("#missao-fora-do-form", this.contexto).val($("#Missao", this.contexto).val());
    $("#visao-fora-do-form", this.contexto).val($("#Visao", this.contexto).val());
    $("#missao-fora-do-form", this.contexto).change((function(_this) {
      return function() {
        return $("#Missao", _this.contexto).val($("#missao-fora-do-form", _this.contexto).val());
      };
    })(this));
    return $("#visao-fora-do-form", this.contexto).change((function(_this) {
      return function() {
        return $("#Visao", _this.contexto).val($("#visao-fora-do-form", _this.contexto).val());
      };
    })(this));
  };

  unidadeGerencialPorPlanoDeGestaoCreateEditController.prototype.loadFunctions = function() {
    setTimeout(redimensionarModalLateral, 0);
    this.carregarComboResponsavel();
    this.carregarComboUnidadeSubordinada();
    this.carregarComboEstado();
    return this.configurarMisssaoEVisao();
  };

  unidadeGerencialPorPlanoDeGestaoCreateEditController.prototype.aoSalvar = function(data) {
    var callback, idDaUnidadeGerencial;
    if (data.success) {
      if (data.novoRegistro) {
        callback = function() {
          return $as.Manutencao.UnidadeGerencialPorPlanoDeGestao.Edit.get({
            idDaUnidade: data.idDaUnidade,
            idDoPlanoDeGestao: data.idDoPlanoDeGestao
          }).done(function(html) {
            return $('#unidadegerencialporplanodegestao-modal-container').html(html);
          });
        };
        return window.UnidadeGerencialPorPlanoGestao.reload(callback);
      } else {
        idDaUnidadeGerencial = $('#Id', this.contexto).val();
        $as.Manutencao.UnidadeGerencialPorPlanoDeGestao.ItemListagem.get({
          id: idDaUnidadeGerencial
        }).done((function(_this) {
          return function(data) {
            var elemento, nivel;
            elemento = $("#unidade-" + idDaUnidadeGerencial);
            elemento.html(data);
            nivel = elemento.data('nivel');
            elemento.find('td').removeClass('espacamento-hierarquia-0');
            return elemento.find('td').addClass("espacamento-hierarquia-" + nivel);
          };
        })(this));
        return $('#unidadegerencialporplanodegestao-modal-container').html(data.data);
      }
    } else {
      return $('#unidadegerencialporplanodegestao-modal-container').html(data.data);
    }
  };

  return unidadeGerencialPorPlanoDeGestaoCreateEditController;

})();
