﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.graficosDeIndicadorPainelController = (function(superClass) {
  extend(graficosDeIndicadorPainelController, superClass);

  function graficosDeIndicadorPainelController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.recarregarTemplate = bind(this.recarregarTemplate, this);
    this.reload = bind(this.reload, this);
    this.ativarEventos = bind(this.ativarEventos, this);
    this.parametrosComuns = bind(this.parametrosComuns, this);
    this.encontrarElementos = bind(this.encontrarElementos, this);
    this.mostrarModalDeEdicao = bind(this.mostrarModalDeEdicao, this);
    this.load = bind(this.load, this);
    graficosDeIndicadorPainelController.__super__.constructor.call(this, this.view, this.model, this.options);
  }

  graficosDeIndicadorPainelController.prototype.load = function() {
    this.encontrarElementos();
    this.ativarEventos();
    this.resolverRelacionamentosNosCards();
    $(this.view).closest("form").attr("action", this.options.FormURL);
    this.get('.js-BotoesDoCartao').removeClass("hide").addClass("mostrar");
    this.get('#indicativos-comentarios-planodeacao').hide();
    return this.definirBloqueios();
  };

  graficosDeIndicadorPainelController.prototype.mostrarModalDeEdicao = function() {
    return $as.ReportSIM.Paineis.AdicionarGrafico.get({
      idDoPainel: this.IdDoPainel.val(),
      referenciaNoTemplate: this.options.referenciaNoTemplate
    }).done((function(_this) {
      return function(html) {
        return $("#main-modal").html(html);
      };
    })(this));
  };

  graficosDeIndicadorPainelController.prototype.encontrarElementos = function() {
    graficosDeIndicadorPainelController.__super__.encontrarElementos.apply(this, arguments);
    this.IdDoPainel = $('#idDoPainel');
    return this.painelTemplate = $('#painel-template');
  };

  graficosDeIndicadorPainelController.prototype.parametrosComuns = function() {
    return '&idDoPainel=' + this.IdDoPainel.val() + '&referenciaNoTemplate=' + this.options.referenciaNoTemplate;
  };

  graficosDeIndicadorPainelController.prototype.ativarEventos = function() {
    graficosDeIndicadorPainelController.__super__.ativarEventos.apply(this, arguments);
    return this.get(".js-RemoverCartao").unbind("click").bind("click", edicaoDashboard.tentarExcluirItem);
  };

  graficosDeIndicadorPainelController.prototype.reload = function() {
    edicaoDashboard.load();
    return this.load();
  };

  graficosDeIndicadorPainelController.prototype.recarregarTemplate = function() {
    return edicaoDashboard.reload();
  };

  return graficosDeIndicadorPainelController;

})(window.SIMPartsDeIndicador);
