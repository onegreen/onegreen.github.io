﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.regraDeValidacaoController = (function() {
  function regraDeValidacaoController(options) {
    this.options = options;
    this.reload = bind(this.reload, this);
  }

  regraDeValidacaoController.prototype.reload = function(idDoIndicador) {
    return $as.Performance.RegrasDeValidacao.Index.get({
      idDoIndicador: idDoIndicador
    }).success((function(_this) {
      return function(data) {
        return $("#validacoes-container").html(data);
      };
    })(this));
  };

  return regraDeValidacaoController;

})();
