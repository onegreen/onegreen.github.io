﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.indicadoresController = (function() {
  function indicadoresController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.ajustarFormaDeAcumulo = bind(this.ajustarFormaDeAcumulo, this);
    this.configurarFormaDeAcumulo = bind(this.configurarFormaDeAcumulo, this);
    this.aoFechar = bind(this.aoFechar, this);
    this.carregarAgrupamentoDeDimensoes = bind(this.carregarAgrupamentoDeDimensoes, this);
    this.carregarFormulaDeAcumuloAoSelecionarIndicadorBase = bind(this.carregarFormulaDeAcumuloAoSelecionarIndicadorBase, this);
    this.carregarAreaDeResultado = bind(this.carregarAreaDeResultado, this);
    this.configurarComboIndicadorBase = bind(this.configurarComboIndicadorBase, this);
    this.aoSelecionarIndicadorBase = bind(this.aoSelecionarIndicadorBase, this);
    this.toggleBotaoConfigurarDimensoes = bind(this.toggleBotaoConfigurarDimensoes, this);
    this.habilitarConfiguracaoDeDimensoes = bind(this.habilitarConfiguracaoDeDimensoes, this);
    this.aoCriarIndicador = bind(this.aoCriarIndicador, this);
    this.loadCombosItensDeDimensao = bind(this.loadCombosItensDeDimensao, this);
    this.loadCombosAdicao = bind(this.loadCombosAdicao, this);
    this.desabilitarCampos = bind(this.desabilitarCampos, this);
    this.$view = $(this.contexto);
    this.$view.window({
      width: 750
    });
    this.loadCombosAdicao();
    this.formasDeAcumulo = $("#formas-de-acumulo", this.$view);
    $('#close-modal-indicador').bind('click', (function(_this) {
      return function(event) {
        return _this.aoFechar();
      };
    })(this));
    this.habilitarConfiguracaoDeDimensoes();
    this.configurarFormaDeAcumulo();
    if (!this.options.podeAlterarOsDadosDoIndicador) {
      this.desabilitarCampos();
    }
  }

  indicadoresController.prototype.desabilitarCampos = function() {
    if (this.options.podeAlterarOAgrupamento) {
      $("#createEdit-indicador-container", this.$view).find(':input').attr('disabled', 'disabled');
      $('#Agrupamento', this.$view).removeAttr('disabled');
      $('#Id', this.$view).removeAttr('disabled');
      $('#AgrupamentoBtn', this.$view).removeAttr('disabled');
      return $('#formEditIndicador').attr('action', $as.Performance.Indicadores.EditAgrupamento.url);
    } else {
      $("#createEdit-indicador-container", this.$view).find(':input').attr('disabled', 'disabled');
      return $("#salvarIndicador", this.$view).attr('disabled', 'disabled');
    }
  };

  indicadoresController.prototype.loadCombosAdicao = function() {
    setCombo(this.contexto, '#TipoDeIndicador_Nome');
    setCombo(this.contexto, '#AreaDeResultados_Nome');
    setCombo(this.contexto, '#Responsavel_Nome');
    setCombo(this.contexto, '#Agrupamento');
    this.configurarComboIndicadorBase();
    return this.loadCombosItensDeDimensao();
  };

  indicadoresController.prototype.loadCombosItensDeDimensao = function() {
    var combos;
    combos = $('.comboDimensao', this.contexto);
    return $.map(combos, (function(_this) {
      return function(n) {
        var idCombo;
        idCombo = '#' + $(n).attr('id');
        return setCombo(_this.contexto, idCombo);
      };
    })(this));
  };

  indicadoresController.prototype.aoCriarIndicador = function(data) {
    if (data.success) {
      $("#main").load(window.location.href);
      propriedadesDoIndicadorController.recarregar(data.data.id);
      return this.aoFechar();
    }
  };

  indicadoresController.prototype.configurarDimensoes = function() {
    var formIndicador;
    $('.js-validar-duplicidade', this.contexto).val(false);
    formIndicador = $('form', this.contexto).serialize();
    console.log(formIndicador);
    return $as.Performance.Indicadores.ConfigurarDimensoes.post(formIndicador).done((function(_this) {
      return function(data) {
        _this.aoFechar();
        return $('#main-modal').html(data);
      };
    })(this));
  };

  indicadoresController.prototype.habilitarConfiguracaoDeDimensoes = function() {
    var habilitarConfiguracoesDeDimensao;
    if ($('#IndicadorBase_Id', this.contexto).val() !== '' && $('#IndicadorBase_Id', this.contexto).val() !== '0') {
      if (this.indicadorBase) {
        habilitarConfiguracoesDeDimensao = this.indicadorBase.HabilitarConfiguracoesDeDimensao;
        return this.toggleBotaoConfigurarDimensoes(habilitarConfiguracoesDeDimensao);
      } else {
        return $as.Performance.Indicadores.HabilitarConfiguracaoDeDimensoes.get({
          idDoIndicadorBase: $('#IndicadorBase_Id', this.contexto).val()
        }).done((function(_this) {
          return function(data) {
            habilitarConfiguracoesDeDimensao = data.habilitarConfiguracoesDeDimensao;
            return _this.toggleBotaoConfigurarDimensoes(habilitarConfiguracoesDeDimensao);
          };
        })(this));
      }
    }
  };

  indicadoresController.prototype.toggleBotaoConfigurarDimensoes = function(habilitarConfiguracoesDeDimensao) {
    if (habilitarConfiguracoesDeDimensao) {
      return $('#btnConfigurarDimensoes', this.contexto).show();
    } else {
      return $('#btnConfigurarDimensoes', this.contexto).hide();
    }
  };

  indicadoresController.prototype.aoSelecionarIndicadorBase = function(idDoIndicadorBase) {
    return $as.Performance.Indicadores.ObterInformacoesDoIndicadorBase.get({
      idDoIndicadorBase: idDoIndicadorBase
    }).done((function(_this) {
      return function(data) {
        _this.indicadorBase = data;
        _this.habilitarConfiguracaoDeDimensoes();
        _this.carregarAreaDeResultado();
        _this.carregarFormulaDeAcumuloAoSelecionarIndicadorBase();
        return _this.carregarAgrupamentoDeDimensoes();
      };
    })(this));
  };

  indicadoresController.prototype.configurarComboIndicadorBase = function() {
    var onSelected;
    onSelected = (function(_this) {
      return function(input) {
        return _this.aoSelecionarIndicadorBase(input.val());
      };
    })(this);
    return Results.api.setComboIndicadorBase(this.contexto, null, onSelected, {}, this.options.podeCriarIndicadorBase);
  };

  indicadoresController.prototype.carregarAreaDeResultado = function() {
    $("#AreaDeResultados_Id", this.contexto).val(this.indicadorBase.IdDaAreaDeResultado);
    return $("#AreaDeResultados_Nome", this.contexto).val(this.indicadorBase.NomeDaAreaDeResultado);
  };

  indicadoresController.prototype.carregarFormulaDeAcumuloAoSelecionarIndicadorBase = function() {
    var formaDeAcumuloAutomatica;
    if (this.indicadorBase.FormaDeAcumuloAutomaticoDoIndicadorBase) {
      formaDeAcumuloAutomatica = resourceJsonCommom[this.indicadorBase.FormaDeAcumuloAutomaticoDoIndicadorBase];
    } else {
      formaDeAcumuloAutomatica = resourceJsonCommom[this.indicadorBase.FormaDeAcumuloAutomaticoDaUnidadeMedida];
    }
    $("#FormaDeAcumuloAutomatico-default", this.formasDeAcumulo).click();
    return $("#label-forma-de-acumulo-automatico", this.$view).text("(" + formaDeAcumuloAutomatica + ")");
  };

  indicadoresController.prototype.carregarAgrupamentoDeDimensoes = function() {
    return $("#labelFormaDeAcumulo", this.$view).text(this.indicadorBase.AgrupamentoDeDimensoes);
  };

  indicadoresController.prototype.aoFechar = function() {
    this.$view.window("hide");
    this.$view.parent().empty();
    return false;
  };

  indicadoresController.prototype.configurarFormaDeAcumulo = function() {
    return $('.autoSaveFormaDeAcumulo', this.view).click(this.ajustarFormaDeAcumulo);
  };

  indicadoresController.prototype.ajustarFormaDeAcumulo = function(evento) {
    var botao, valor;
    botao = $(evento.currentTarget);
    valor = botao.attr("option");
    $('#AgrupamentoDeDimensoes', this.view).val(botao.attr("option"));
    return $('#labelFormaDeAcumulo', this.view).text(botao.text());
  };

  return indicadoresController;

})();
