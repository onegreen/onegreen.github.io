﻿var base;

this.Atividades || (this.Atividades = {});

(base = this.Atividades).PlanoDeAcao || (base.PlanoDeAcao = {});

Atividades.PlanoDeAcao.api = (function() {
  function api() {}

  api.reload = function(idDoPlanoDeAcao, ideObj) {
    var container, containerID;
    container = ideObj ? $("#container-plano-acao" + idDoPlanoDeAcao + "objeto-" + ideObj) : $("#container-plano-acao" + idDoPlanoDeAcao);
    containerID = ideObj ? ideObj : idDoPlanoDeAcao;
    if (container.length) {
      if (container.data("controller")) {
        container.data("controller").reload();
      } else if (container.data("function-reload")) {
        eval(container.data("function-reload"));
      }
    }
    api.atualizarCascata(idDoPlanoDeAcao);
    return api.reiniciarAdicao(idDoPlanoDeAcao, containerID);
  };

  api.atualizarFiltroDeStatus = function(idDoPlanoDeAcao) {
    return $as.Atividades.PlanosDeAcao.DefinirFiltroDeStatusDasAtividades.get({
      idDoPlanoDeAcao: idDoPlanoDeAcao
    }).done((function(_this) {
      return function(data) {
        return $("#container-filtro-status-" + idDoPlanoDeAcao).html(data);
      };
    })(this));
  };

  api.reiniciarAdicao = function(idDoPlanoDeAcao, containerID) {
    var contexto;
    contexto = $("[id=adicaoSimplificada-" + idDoPlanoDeAcao + "][data-container-id=" + containerID + "]");
    $('.input-validation-error').removeClass('input-validation-error');
    $(".error").removeClass("error");
    $('.validation-summary-errors').remove();
    $('#OQue', contexto).val('');
    $('#InicioPrevistoNovaTarefa', contexto).val('');
    $('#FimPrevistoNovaTarefa', contexto).val('');
    $("#FimPrevistoNovaTarefa", contexto).datepicker('setStartDate');
    $("#InicioPrevistoNovaTarefa", contexto).datepicker('setEndDate');
  };

  api.iniciarResponsavel = function(nomeResponsavelTerceiro) {
    if (nomeResponsavelTerceiro) {
      $('#divUsuario').hide();
      return $('#divUsuarioTerceiro').show();
    } else {
      $('#divUsuario').show();
      return $('#divUsuarioTerceiro').hide();
    }
  };

  api.filtrarPlanoDeAco = function(elemento) {
    var contexto, id;
    id = elemento.data('id');
    contexto = "#globalPlanoDeAcao-" + id;
    return $("#filtro-" + id, contexto).toggle('fast');
  };

  api.ordenarPlanoDeAco = function(elemento) {
    var id;
    id = elemento.data('id');
    return $(".ordenar", "#container-plano-acao" + id).toggle();
  };

  api.relatorioDeCumprimento = function(idDoPlanoDeAcao, somentePrincipais) {
    return $as.Atividades.PlanosDeAcao.RelatorioDeCumprimento.get({
      idDoPlanoDeAcao: idDoPlanoDeAcao,
      somentePrincipais: somentePrincipais
    }).success(function(data) {
      window.GetDiv('popoverrelatoriodecumprimentomodel-modal-container').html(data);
      return $('#popoverrelatoriodecumprimentomodel-modal').window();
    });
  };

  api.manterOrdenacao = function(idDoPlanoDeAcao) {
    if ($(".ordenar", "#container-plano-acao" + idDoPlanoDeAcao).is(':visible')) {
      return $(".ordenar", "#container-plano-acao" + idDoPlanoDeAcao).toggle();
    }
  };

  api.atualizarCascata = function(idDoPlanoDeAcao) {
    var ele, elementosParaRecarregar, execute, i, len, parentCascade, planosPainel, results;
    planosPainel = $("[data-plano-de-acao-painel=" + idDoPlanoDeAcao + "]");
    if (!planosPainel.length) {
      planosPainel = $("[data-plano-de-acao=" + idDoPlanoDeAcao + "]");
    }
    parentCascade = $(planosPainel.parents("[data-plano-de-acao-cascade]"));
    if (parentCascade.length) {
      elementosParaRecarregar = $(parentCascade.data("plano-de-acao-cascade"));
      execute = function(elemento) {
        if (elemento.data("controller")) {
          elemento.data("controller").reload();
        }
        if (elemento.data("cascade-function")) {
          return eval(elemento.data("cascade-function"));
        }
      };
      results = [];
      for (i = 0, len = elementosParaRecarregar.length; i < len; i++) {
        ele = elementosParaRecarregar[i];
        results.push(execute($(ele)));
      }
      return results;
    }
  };

  api.criarTarefa = function(idDoPlanoDeAcao, containerID, urlCombo, elemento, exibirTarefa) {
    var formTarefa;
    formTarefa = elemento.closest('form').serialize();
    return $as.Atividades.Atividades.CreateAtividade.post(formTarefa).done((function(_this) {
      return function(data) {
        if (data.success) {
          if (exibirTarefa) {
            Atividades.api.openRecentAdded(data);
          } else {
            Atividades.PlanoDeAcao.api.reload(data.data.idPlanoDeAcao, data.data.ideObj);
          }
          Atividades.api.notificarMudanca(data.data.id);
          return swIntercom('Criou uma tarefa - simplificada');
        } else {
          $("[id=adicaoSimplificada-" + idDoPlanoDeAcao + "][data-container-id=" + containerID + "]").html(data);
          Atividades.PlanoDeAcao.api.configurarComboResponsavel(idDoPlanoDeAcao, '#NomeDoResponsavel', urlCombo, containerID);
          _this.configurarDatePickers(idDoPlanoDeAcao, containerID);
          return $('[rel=tooltip]').tooltip();
        }
      };
    })(this));
  };

  api.configurarComboResponsavel = function(idDoPlanoDeAcao, elemento, urlComboResponsavel, containerID, eCorporativo) {
    var contexto, objeto, option, textoUsuario;
    contexto = $("[id=adicaoSimplificada-" + idDoPlanoDeAcao + "][data-container-id=" + containerID + "]");
    eCorporativo = contexto.find('#novaTarefa-container').data('corporativo');
    objeto = $('.js-informacoesComplementaresNovaTarefa').data('objeto');
    if (eCorporativo) {
      textoUsuario = resourceJsonCommom.InserirNovoUsuario;
      option = {
        Value: "<a id onclick='window.planoDeAcao.inserirResponsavelTerceiro(" + idDoPlanoDeAcao + "," + containerID + "," + '"#NomeDoResponsavel"' + "); return false;'>" + textoUsuario + "</a>"
      };
    }
    return $(elemento, contexto).autocompleter(urlComboResponsavel, {
      createOptionIfNotExists: eCorporativo ? false : true,
      loadOnDemand: true,
      elementToClick: "#NomeDoResponsavelDaTarefa" + objeto + "Btn",
      keyElement: "#Responsavel_Id-" + idDoPlanoDeAcao + "-" + containerID,
      parameters: {
        limitarPorUnidade: true
      },
      actionOption: eCorporativo ? option : null,
      evaluateActionOption: false
    });
  };

  api.configurarDatePickers = function(idDoPlanoDeAcao, containerID) {
    var contexto, inputFim, inputInicio;
    contexto = $("[id=adicaoSimplificada-" + idDoPlanoDeAcao + "][data-container-id=" + containerID + "]");
    $('.date-picker', contexto).datepicker({
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      autoclose: true,
      language: Globalize.culture($("html").attr("lang")).name
    });
    inputInicio = $("#InicioPrevistoNovaTarefa", contexto);
    inputFim = $("#FimPrevistoNovaTarefa", contexto);
    inputInicio.change(function() {
      var startDate;
      inputFim.datepicker('setStartDate');
      if (inputInicio.val().trim() !== "") {
        if (inputFim.val() === '') {
          inputFim.val(inputInicio.val());
        }
        startDate = inputInicio.data('datepicker').getFormattedDate();
        return inputFim.datepicker('setStartDate', startDate);
      }
    });
    inputFim.change(function() {
      var endDate;
      inputInicio.datepicker('setEndDate');
      if (inputFim.val().trim() !== "") {
        if (inputInicio.val() === '') {
          inputInicio.val(inputFim.val());
        }
      }
      endDate = inputFim.data('datepicker').getFormattedDate();
      if (inputFim.val() !== '') {
        return inputInicio.datepicker('setEndDate', endDate);
      }
    });
  };

  return api;

})();
