﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.observacoesController = (function() {
  function observacoesController(options) {
    this.options = options;
    this.documentoAdicionado = bind(this.documentoAdicionado, this);
    this.apagarDocumento = bind(this.apagarDocumento, this);
    this.abrirAdicionarDocumentoModal = bind(this.abrirAdicionarDocumentoModal, this);
    this.salvarVinculoDocumentos = bind(this.salvarVinculoDocumentos, this);
    this.abrirVincularDocumentoModal = bind(this.abrirVincularDocumentoModal, this);
  }

  observacoesController.prototype.criarDivNoBody = function(idDiv) {
    if ($('#' + idDiv).length === 0) {
      return $("body").append("<div id=" + idDiv + "></div>");
    }
  };

  observacoesController.prototype.abrirVincularDocumentoModal = function(id) {
    this.criarDivNoBody('vincularDocumento-modal-container');
    return $.get(this.options.abrirVincularDocumentoModalUrl, (function(_this) {
      return function(data) {
        return $('#vincularDocumento-modal-container').html(data);
      };
    })(this));
  };

  observacoesController.prototype.salvarVinculoDocumentos = function() {
    return $as.Onegreen.Observacoes.VincularDocumentos.post($('[name=IdDocumentos]:checked', '#documentos-table tbody').serialize() + '&' + $('[name=IdDocumentos]', '#observacoes-modal').serialize()).success((function(_this) {
      return function(data) {
        return $('#documentos-container', '#observacoes-modal').html(data);
      };
    })(this));
  };

  observacoesController.prototype.abrirAdicionarDocumentoModal = function() {
    return window.GetDiv('documentosempreendimento-modal-container').load(this.options.abrirAdicionarDocumentoModalUrl);
  };

  observacoesController.prototype.apagarDocumento = function(idDocumento) {
    return $as.Onegreen.Observacoes.ApagarDocumento.post($('[name=IdDocumentos]', '#observacoes-modal').serialize() + '&idDocumento=' + idDocumento).success((function(_this) {
      return function(data) {
        return $('#documentos-container', '#observacoes-modal').html(data);
      };
    })(this));
  };

  observacoesController.prototype.documentoAdicionado = function(idDocumento) {
    return $as.Onegreen.Observacoes.VincularDocumentos.post($('[name=IdDocumentos]', '#observacoes-modal').serialize() + '&' + 'IdDocumentos=' + idDocumento).success((function(_this) {
      return function(data) {
        return $('#documentos-container', '#observacoes-modal').html(data);
      };
    })(this));
  };

  return observacoesController;

})();
