﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.unidadesPorUsuarioController = (function() {
  function unidadesPorUsuarioController(options) {
    this.options = options;
    this.aoSelecionarUnidade = bind(this.aoSelecionarUnidade, this);
    this.AlterarPermissaoDeAlteracao = bind(this.AlterarPermissaoDeAlteracao, this);
    this.BindChecks = bind(this.BindChecks, this);
    this.AtualizarUnidades = bind(this.AtualizarUnidades, this);
    this.VincularUnidadeGerencial = bind(this.VincularUnidadeGerencial, this);
    this.ConfigurarComboUnidadeGerencial = bind(this.ConfigurarComboUnidadeGerencial, this);
    this.OcultarSubordinadas = bind(this.OcultarSubordinadas, this);
    this.ExibirSubordinadas = bind(this.ExibirSubordinadas, this);
    this.ExibirOcultarSubordinadas = bind(this.ExibirOcultarSubordinadas, this);
    if (this.options.permitirEdicao) {
      this.ConfigurarComboUnidadeGerencial();
    }
    this.BindChecks();
    $('[rel=tooltip]').tooltip();
  }

  unidadesPorUsuarioController.prototype.ExibirOcultarSubordinadas = function(el, idDaUnidade) {
    var elemento;
    elemento = $(el);
    if (elemento.hasClass("fa-plus-square")) {
      return this.ExibirSubordinadas(elemento, idDaUnidade);
    } else {
      return this.OcultarSubordinadas(elemento.parent().parent(), idDaUnidade);
    }
  };

  unidadesPorUsuarioController.prototype.ExibirSubordinadas = function(elemento, idDaUnidade) {
    $("[data-pai='" + idDaUnidade + "']").removeClass('none');
    return elemento.removeClass("fa-plus-square").addClass("fa-minus-square");
  };

  unidadesPorUsuarioController.prototype.OcultarSubordinadas = function(elemento, idDaUnidade) {
    if (idDaUnidade !== void 0) {
      $("[data-pai='" + idDaUnidade + "']").each((function(_this) {
        return function(i, e) {
          var idUnidade;
          $(e).addClass('none');
          idUnidade = $(e).data('idunidade');
          return _this.OcultarSubordinadas($(e), idUnidade);
        };
      })(this));
      return elemento.find('i').removeClass("fa-minus-square").addClass("fa-plus-square");
    }
  };

  unidadesPorUsuarioController.prototype.ConfigurarComboUnidadeGerencial = function() {
    return $('#UnidadeGerencialNome').autocompleter(this.options.urlRetornarComboUnidades, {
      loadOnDemand: false,
      elementToClick: "#UnidadeGerencialNomeBtn",
      keyElement: "#IdUnidadeGerencial",
      onSelected: (function(_this) {
        return function() {
          return _this.aoSelecionarUnidade();
        };
      })(this),
      parameters: {
        idDoUsuario: this.options.idDoUsuario
      }
    });
  };

  unidadesPorUsuarioController.prototype.VincularUnidadeGerencial = function() {
    if ($("#IdUnidadeGerencial").val() !== "") {
      return $.ajax({
        type: "POST",
        url: this.options.urlVincularUnidadeGerencial,
        data: {
          idUsuario: this.options.idDoUsuario,
          idUnidadeGerencial: $("#IdUnidadeGerencial").val(),
          incluirSubordinadas: $("input[name=IncluirSubordinadas]:checked").length > 0,
          podeAlterar: $("input[name=PodeAlterar]:checked").length > 0
        },
        success: (function(_this) {
          return function(html) {
            return _this.AtualizarUnidades();
          };
        })(this)
      });
    }
  };

  unidadesPorUsuarioController.prototype.AtualizarUnidades = function() {
    return $.get(this.options.urlAtualizarUnidades, {
      idUsuario: this.options.idDoUsuario
    }, (function(_this) {
      return function(data) {
        $('#unidadesPorUsuario').html(data);
        return _this.BindChecks();
      };
    })(this));
  };

  unidadesPorUsuarioController.prototype.BindChecks = function() {
    return $('.alterarPermissao').click((function(_this) {
      return function() {
        var id;
        id = $( this ).data('unidade');
        return _this.AlterarPermissaoDeAlteracao(id);
      };
    })(this));
  };

  unidadesPorUsuarioController.prototype.AlterarPermissaoDeAlteracao = function(idDaUnidade) {
    return $.post(this.options.urlAlterarPermissaoDeAlteracao, {
      idUsuario: this.options.idDoUsuario,
      idUnidade: idDaUnidade
    });
  };

  unidadesPorUsuarioController.prototype.aoSelecionarUnidade = function() {
    return $("#btnAdicionarUnidade", this.contexto).removeClass("disabled");
  };

  return unidadesPorUsuarioController;

})();
