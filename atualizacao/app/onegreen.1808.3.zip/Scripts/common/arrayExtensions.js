﻿if (!Array.prototype.indexOf) {
  Array.prototype.indexOf = function(element) {
    var item, j, len;
    for (j = 0, len = this.length; j < len; j++) {
      item = this[j];
      if (item === element) {
        return _i;
      }
    }
    return -1;
  };
}

if (!Array.prototype.remove) {
  Array.prototype.remove = function(element) {
    var i;
    i = this.indexOf(element);
    this.splice(i, 1);
    return this;
  };
}

if (!Array.prototype.contains) {
  Array.prototype.contains = function(element) {
    var i;
    i = this.indexOf(element);
    return i !== -1;
  };
}

Array.prototype.removeByCondition = function(condition) {
  var find, item, j, k, len, len1, search;
  search = new Array();
  find = false;
  for (j = 0, len = this.length; j < len; j++) {
    item = this[j];
    if (condition(item)) {
      search.push(item);
    }
  }
  find = search.length > 0;
  for (k = 0, len1 = search.length; k < len1; k++) {
    item = search[k];
    this.remove(item);
  }
  return find;
};
