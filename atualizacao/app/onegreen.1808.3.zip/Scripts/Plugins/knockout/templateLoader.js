(function() {
  (function($) {
    return $.extend({
      loadTemplate: function(url, template) {
        if ($("#" + template).length > 0) {
          return;
        }
        return $.ajax({
          url: url,
          async: false,
          success: function(data) {
            return $("<script id=\"" + template + "\" type=\"text/x-jquery-tmpl\">" + data + "</script>").appendTo('body');
          }
        });
      }
    });
  })(window.jQuery);
}).call(this);