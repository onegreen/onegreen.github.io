﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.apresentacaoDaSolucao = (function() {
  function apresentacaoDaSolucao() {
    this.transformarEmSomenteLeitura = bind(this.transformarEmSomenteLeitura, this);
    this.get = bind(this.get, this);
    this.visualizarUltimoItem = bind(this.visualizarUltimoItem, this);
    this.visualizarPrimeiroItem = bind(this.visualizarPrimeiroItem, this);
    this.visualizarItemAnterior = bind(this.visualizarItemAnterior, this);
    this.visualizarProximoItem = bind(this.visualizarProximoItem, this);
    this.ativarBotoesDeNavegacao = bind(this.ativarBotoesDeNavegacao, this);
    this.avancarVisualizacaoEm = bind(this.avancarVisualizacaoEm, this);
    this.marcarNavegacao = bind(this.marcarNavegacao, this);
    this.mostrarItem = bind(this.mostrarItem, this);
    this.visualizarItem = bind(this.visualizarItem, this);
    this.mudarSimpartPeloTeclado = bind(this.mudarSimpartPeloTeclado, this);
    this.configurarInformacoesDoSlide = bind(this.configurarInformacoesDoSlide, this);
    this.aoSelecionarAncora = bind(this.aoSelecionarAncora, this);
    this.alterarSlidePeloMostrador = bind(this.alterarSlidePeloMostrador, this);
    this.analisarInput = bind(this.analisarInput, this);
    this.slide = bind(this.slide, this);
    this.esconderDica = bind(this.esconderDica, this);
    this.slide();
    this.transformarEmSomenteLeitura();
    $('[rel=popover]').popover({
      trigger: 'manual',
      html: true
    }).click(function(e) {
      return $(this).popover('show');
    });
    $('.js-facebox').facebox();
    $(window).resize($.facebox.rescaleImage);
    setTimeout(this.esconderDica, 2000);
    $('body').click(function() {
      return $('#mensagemInicial').hide();
    });
  }

  apresentacaoDaSolucao.prototype.esconderDica = function() {
    return $('#mensagemInicial').fadeOut('slow');
  };

  apresentacaoDaSolucao.prototype.slide = function() {
    this.indiceVisivel = 0;
    this.quantidadeDeItens = -1;
    this.podeMudarOItem = true;
    this.passarAtutomaticamente = false;
    this.quantidadeDeSegundosParaTransicao = 10;
    this.contexto = $('#apresentacao-container');
    this.mostradorSlideAtual = this.get('#MostradorSlideAtual');
    this.slides = this.get('.js-slide');
    this.configurarInformacoesDoSlide();
    this.slides.hide();
    this.ativarBotoesDeNavegacao();
    this.quantidadeDeItens = this.slides.length;
    this.get('#TotalDeSlides').html(this.quantidadeDeItens);
    this.ultimoIndice = this.quantidadeDeItens - 1;
    this.get('.js-slide-ancora').unbind('click').click(this.aoSelecionarAncora);
    this.visualizarPrimeiroItem();
    this.mostradorSlideAtual.val(1);
    this.mostradorSlideAtual.change(this.alterarSlidePeloMostrador);
    return this.mostradorSlideAtual.keypress(this.analisarInput);
  };

  apresentacaoDaSolucao.prototype.analisarInput = function(event) {
    if (event.keyCode === 13) {
      this.alterarSlidePeloMostrador(event);
    }
    if (isNaN(String.fromCharCode(event.which))) {
      return false;
    }
  };

  apresentacaoDaSolucao.prototype.alterarSlidePeloMostrador = function(event) {
    var valor;
    valor = $(event.delegateTarget).val();
    if (!isNaN(valor)) {
      return this.visualizarItem(parseInt(valor) - 1);
    } else {
      return $(event.delegateTarget).val(this.indiceVisivel + 1);
    }
  };

  apresentacaoDaSolucao.prototype.aoSelecionarAncora = function(event) {
    var indice, seletor;
    seletor = $(event.delegateTarget).data('seletor');
    indice = this.get(seletor).data('indice');
    event.stopPropagation();
    return this.visualizarItem(indice);
  };

  apresentacaoDaSolucao.prototype.configurarInformacoesDoSlide = function() {
    var i, indice, len, ref, results, slide;
    indice = 0;
    ref = this.slides;
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      slide = ref[i];
      slide = $(slide);
      slide.attr('data-indice', indice);
      results.push(indice++);
    }
    return results;
  };

  apresentacaoDaSolucao.prototype.mudarSimpartPeloTeclado = function(event) {
    var tecla;
    tecla = event.keyCode;
    switch (tecla) {
      case 36:
        return this.visualizarPrimeiroItem();
      case 35:
        return this.visualizarUltimoItem();
      case 32:
      case 39:
        return this.visualizarProximoItem();
      case 37:
        return this.visualizarItemAnterior();
    }
  };

  apresentacaoDaSolucao.prototype.visualizarItem = function(item) {
    if (item < 0) {
      item = 0;
    }
    if (item > this.ultimoIndice) {
      item = this.ultimoIndice;
    }
    if (this.podeMudarOItem) {
      this.podeMudarOItem = false;
      return $(this.slides[this.indiceVisivel]).fadeOut(400, (function(_this) {
        return function() {
          return _this.mostrarItem(item);
        };
      })(this));
    }
  };

  apresentacaoDaSolucao.prototype.mostrarItem = function(item) {
    var slide;
    slide = $(this.slides[item]);
    slide.fadeIn();
    this.indiceVisivel = item;
    this.mostradorSlideAtual.val(this.indiceVisivel + 1);
    this.podeMudarOItem = true;
    this.marcarNavegacao(slide);
    return $("body").scrollTop(0);
  };

  apresentacaoDaSolucao.prototype.marcarNavegacao = function(slide) {
    var ancora, i, id, len, pai, ref, results;
    id = slide.attr('id');
    ancora = $(".js-slide-ancora[data-seletor=#" + id + "]");
    $('.js-slide-ancora').removeClass('active');
    ancora.addClass('active');
    ref = ancora.parents('.js-slide-ancora');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      pai = ref[i];
      results.push($(pai).addClass('active'));
    }
    return results;
  };

  apresentacaoDaSolucao.prototype.avancarVisualizacaoEm = function(quandtidade) {
    var novoIndice;
    novoIndice = this.indiceVisivel + quandtidade;
    if (novoIndice >= 0 && novoIndice <= this.quantidadeDeItens - 1) {
      return this.visualizarItem(novoIndice);
    }
  };

  apresentacaoDaSolucao.prototype.ativarBotoesDeNavegacao = function() {
    this.get("#VisualizarUltimoSlide").click(this.visualizarUltimoItem);
    this.get("#AvancarSlide").click(this.visualizarProximoItem);
    this.get("#VoltarSlide").click(this.visualizarItemAnterior);
    this.get("#VisualizarPrimeiroSlide").click(this.visualizarPrimeiroItem);
    this.get("#ToggleTransicaoAutomatica").click(this.toggleTransicaoAutomatica);
    return $("body").keydown(this.mudarSimpartPeloTeclado);
  };

  apresentacaoDaSolucao.prototype.visualizarProximoItem = function() {
    return this.avancarVisualizacaoEm(1);
  };

  apresentacaoDaSolucao.prototype.visualizarItemAnterior = function() {
    return this.avancarVisualizacaoEm(-1);
  };

  apresentacaoDaSolucao.prototype.visualizarPrimeiroItem = function() {
    return this.visualizarItem(0);
  };

  apresentacaoDaSolucao.prototype.visualizarUltimoItem = function() {
    return this.visualizarItem(this.quantidadeDeItens - 1);
  };

  apresentacaoDaSolucao.prototype.get = function(seletor) {
    return $(seletor, this.contexto);
  };

  apresentacaoDaSolucao.prototype.transformarEmSomenteLeitura = function() {
    var i, len, link, ref, results;
    $('.js-plano-de-acao img').remove();
    $('.cursor-pointer', '#solucaodeproblema-container').removeClass('cursor-pointer');
    $('input', '#container-apresentacao').remove();
    $('.js-plano-de-acao a').removeAttr('href');
    $('.js-plano-de-acao a').removeAttr('onclick');
    $('.adicionar').parent().remove();
    $('.btn', '#solucoesdeproblemas-table').remove();
    $('.direita', '#solucoesdeproblemas-table').remove();
    ref = $('a', '.js-solucoes-vinculadas');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      link = ref[i];
      link = $(link);
      results.push(link.replaceWith("<span>" + (link.text()) + "</span>"));
    }
    return results;
  };

  return apresentacaoDaSolucao;

})();
