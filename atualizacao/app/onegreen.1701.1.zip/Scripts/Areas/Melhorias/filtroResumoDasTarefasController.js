﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.Melhorias || (this.Melhorias = {});

window.Melhorias.filtroResumoDasTarefasController = (function() {
  function filtroResumoDasTarefasController(options) {
    this.options = options;
    this.retornarFiltroCorrente = bind(this.retornarFiltroCorrente, this);
    this.aoCarregarAgrupadoPorEtapas = bind(this.aoCarregarAgrupadoPorEtapas, this);
    this.defineFiltros = bind(this.defineFiltros, this);
    this.esconderCombos = bind(this.esconderCombos, this);
    this.exibirEsconderCamposFiltroEtapa = bind(this.exibirEsconderCamposFiltroEtapa, this);
    this.aoSelecionarAgrupamento = bind(this.aoSelecionarAgrupamento, this);
    this.bindExibirEsconderEtapa = bind(this.bindExibirEsconderEtapa, this);
    this.exibirEsconderEtapa = bind(this.exibirEsconderEtapa, this);
    this.localizarElementos = bind(this.localizarElementos, this);
    this.loadComboOrigem = bind(this.loadComboOrigem, this);
    this.bloquearDesbloquearComboMetodo = bind(this.bloquearDesbloquearComboMetodo, this);
    this.loadComboMetodos = bind(this.loadComboMetodos, this);
    this.loadComboClassificacao = bind(this.loadComboClassificacao, this);
    this.loadComboUsuarioComAcoesOuAcessoAProjetos = bind(this.loadComboUsuarioComAcoesOuAcessoAProjetos, this);
    this.limparComboUsuario = bind(this.limparComboUsuario, this);
    this.loadComboDeUnidadeGerencial = bind(this.loadComboDeUnidadeGerencial, this);
    this.ConfigureErrors = bind(this.ConfigureErrors, this);
    this.CarregarFiltrosCoffee = bind(this.CarregarFiltrosCoffee, this);
    this.defineFiltros();
    $('.js-agrupar-por input').change(this.aoSelecionarAgrupamento);
    $('.js-tipo-filtro input').change(this.bindExibirEsconderEtapa);
    $('.js-carregar-solucoes').unbind('click').click(this.aoCarregarAgrupadoPorEtapas);
    this.agrupandoPor = 'Unidade';
    this.localizarElementos();
    this.CarregarFiltrosCoffee();
    this.exibirEsconderEtapa($('.js-tipo-filtro input:checked').val());
  }

  filtroResumoDasTarefasController.prototype.CarregarFiltrosCoffee = function() {
    this.loadComboDeUnidadeGerencial();
    this.loadComboUsuarioComAcoesOuAcessoAProjetos();
    this.loadComboClassificacao();
    this.loadComboMetodos();
    this.loadComboOrigem();
    this.bloquearDesbloquearComboMetodo();
    return this.ConfigureErrors();
  };

  filtroResumoDasTarefasController.prototype.ConfigureErrors = function() {
    $("[rel=tooltip]").tooltip();
    return $("[rel=popover]").popover({
      html: true
    });
  };

  filtroResumoDasTarefasController.prototype.loadComboDeUnidadeGerencial = function() {
    var $combo, $divCombo, _this;
    $divCombo = $('.js-unidadegerencial');
    $combo = $('#UnidadeGerencialNome', $divCombo);
    _this = this;
    return $combo.autocompleter($divCombo.attr("data-url"), {
      loadOnDemand: true,
      elementToClick: "#UnidadeGerencialNomeBtn",
      keyElement: "#IdUnidadeGerencial",
      parameters: {},
      onSelected: function() {
        _this.limparComboUsuario();
        return _this.loadComboUsuarioComAcoesOuAcessoAProjetos();
      }
    });
  };

  filtroResumoDasTarefasController.prototype.limparComboUsuario = function() {
    $("#IdResponsavel").val('');
    return $("#ResponsavelNome").val(this.options.RecursoTodos);
  };

  filtroResumoDasTarefasController.prototype.loadComboUsuarioComAcoesOuAcessoAProjetos = function() {
    var $combo, $divCombo;
    $divCombo = $('.js-responsavel');
    $combo = $('#ResponsavelNome', $divCombo);
    return $combo.autocompleter($divCombo.attr("data-url"), {
      loadOnDemand: true,
      elementToClick: "#ResponsavelNomeBtn",
      keyElement: "#IdResponsavel",
      parameters: (function(_this) {
        return function() {
          return _this.retornarFiltroCorrente();
        };
      })(this),
      defaultOption: {
        Key: '',
        Value: this.options.RecursoTodos
      },
      abrirParaCima: true
    });
  };

  filtroResumoDasTarefasController.prototype.loadComboClassificacao = function() {
    var $combo, $divCombo;
    $divCombo = $('.js-classificacao');
    $combo = $('#ClassificacaoNome', $divCombo);
    return $combo.autocompleter($divCombo.attr("data-url"), {
      loadOnDemand: true,
      elementToClick: "#ClassificacaoNomeBtn",
      keyElement: "#IdClassificacao",
      defaultOption: {
        Key: '',
        Value: this.options.RecursoTodos
      },
      onSelected: (function(_this) {
        return function() {
          $("#IdMetodo").val('');
          $("#MetodoNome").val(_this.options.RecursoTodos);
          return _this.bloquearDesbloquearComboMetodo();
        };
      })(this)
    });
  };

  filtroResumoDasTarefasController.prototype.loadComboMetodos = function() {
    var $combo, $divCombo;
    $divCombo = $('.js-metodo');
    $combo = $('#MetodoNome', $divCombo);
    return $combo.autocompleter($divCombo.attr("data-url"), {
      loadOnDemand: true,
      elementToClick: "#MetodoNomeBtn",
      keyElement: "#IdMetodo",
      parameters: {
        idDaClassificacao: (function(_this) {
          return function() {
            return $('.js-classificacao #IdClassificacao').val();
          };
        })(this)
      },
      defaultOption: {
        Key: '',
        Value: this.options.RecursoTodos
      },
      onSelected: (function(_this) {
        return function(valueInput) {
          return window.FiltroResumo.IdMetodo = valueInput.val();
        };
      })(this)
    });
  };

  filtroResumoDasTarefasController.prototype.bloquearDesbloquearComboMetodo = function() {
    if ($('#IdClassificacao').val() === '') {
      return $('#MetodoNome').data('autocompleter').disable();
    } else {
      return $('#MetodoNome').data('autocompleter').enable();
    }
  };

  filtroResumoDasTarefasController.prototype.loadComboOrigem = function() {
    var $combo, $divCombo;
    $divCombo = $('.js-origem');
    $combo = $('#OrigemNome', $divCombo);
    return $combo.autocompleter($divCombo.attr("data-url"), {
      loadOnDemand: true,
      elementToClick: "#OrigemNomeBtn",
      keyElement: "#IdOrigem",
      defaultOption: {
        Key: '',
        Value: this.options.RecursoTodos
      },
      onSelected: (function(_this) {
        return function(valueInput) {
          return window.FiltroResumo.IdOrigem = valueInput.val();
        };
      })(this)
    });
  };

  filtroResumoDasTarefasController.prototype.localizarElementos = function() {
    return this.labelAgruparPorEtapa = $('#AgruparPor-Etapa').parent('label');
  };

  filtroResumoDasTarefasController.prototype.exibirEsconderEtapa = function(eProjeto) {
    var agruparPorUnidade;
    if (eProjeto === 'True') {
      this.labelAgruparPorEtapa.show('fast');
    } else {
      agruparPorUnidade = $('#AgruparPor-Unidade');
      this.labelAgruparPorEtapa.hide('fast');
      if (this.agrupandoPor === 'Etapa') {
        this.labelAgruparPorEtapa.removeClass('active btn-warning');
        agruparPorUnidade.parent('label').addClass('active btn-warning');
        agruparPorUnidade.attr('checked', 'checked');
        $('input', this.labelAgruparPorEtapa).removeAttr('checked');
      }
    }
    return this.exibirEsconderCamposFiltroEtapa($('.js-agrupar-por input:checked'));
  };

  filtroResumoDasTarefasController.prototype.bindExibirEsconderEtapa = function(event) {
    return this.exibirEsconderEtapa($(event.delegateTarget).val());
  };

  filtroResumoDasTarefasController.prototype.aoSelecionarAgrupamento = function(event) {
    return this.exibirEsconderCamposFiltroEtapa($(event.delegateTarget));
  };

  filtroResumoDasTarefasController.prototype.exibirEsconderCamposFiltroEtapa = function(input) {
    this.agrupandoPor = input.val();
    return this.esconderCombos(this.agrupandoPor !== 'Etapa');
  };

  filtroResumoDasTarefasController.prototype.esconderCombos = function(esconder) {
    if (esconder) {
      $('.js-metodo').hide('fast');
      $("#IdMetodo").val('');
      $("#MetodoNome").val(this.options.RecursoTodos);
      $('.js-origem').hide('fast');
      $("#IdOrigem").val('');
      return $("#OrigemNome").val(this.options.RecursoTodas);
    } else {
      $('.js-metodo').show('fast');
      return $('.js-origem').show('fast');
    }
  };

  filtroResumoDasTarefasController.prototype.defineFiltros = function() {
    var filtroResumo;
    filtroResumo = window.FiltroResumo;
    if (filtroResumo === void 0) {
      return $.ajax({
        url: this.options.UrlFiltroDefault,
        async: false,
        success: function(filtro) {
          return window.FiltroResumo = {
            IdUnidadeGerencial: filtro.IdUnidadeGerencial,
            UnidadeGerencialNome: filtro.UnidadeGerencialNome,
            IncluirSubordinadas: filtro.IncluirSubordinadas,
            StatusAtividade: filtro.StatusAtividade,
            StatusSolucao: filtro.StatusSolucao,
            IdResponsavel: filtro.IdResponsavel,
            ResponsavelNome: filtro.ResponsavelNome,
            DataInicio: filtro.DataInicio,
            DataFim: filtro.DataFim,
            IdClassificacao: filtro.IdClassificacao,
            IdMetodo: filtro.IdMetodo,
            MetodoNome: filtro.MetodoNome,
            IdOrigem: filtro.IdOrigem,
            OrigemNome: filtro.OrigemNome,
            ClassificacaoNome: filtro.ClassificacaoNome,
            EhProjeto: filtro.EhProjeto
          };
        }
      });
    }
  };

  filtroResumoDasTarefasController.prototype.aoCarregarAgrupadoPorEtapas = function(event) {
    var filtro;
    filtro = this.retornarFiltroCorrente();
    filtro.IdUnidadeGerencial = $(event.delegateTarget).closest('tr').data('unidade');
    filtro.AtrasadaNaEtapa = $(event.delegateTarget).data('atrasado');
    filtro.IdDaFase = $(event.delegateTarget).data('fase');
    return $as.Melhorias.SolucoesDeProblemas.CarregarSolucoesResumo.postJson(JSON.stringify(filtro)).done(function(html) {
      $('#main-modal').html(html);
      return $('#main-modal').window({
        width: '750px'
      });
    });
  };

  filtroResumoDasTarefasController.prototype.retornarFiltroCorrente = function() {
    var filtro;
    filtro = {};
    filtro.IdUnidadeGerencial = $("#DivResumoAcoes-Container #IdUnidadeGerencial").val();
    filtro.IdClassificacao = $("#DivResumoAcoes-Container #IdClassificacao").val();
    filtro.ClassificacaoNome = $("#DivResumoAcoes-Container #ClassificacaoNome").val();
    filtro.IdMetodo = $("#DivResumoAcoes-Container #IdMetodo").val();
    filtro.MetodoNome = $("#DivResumoAcoes-Container #MetodoNome").val();
    filtro.IdOrigem = $("#DivResumoAcoes-Container #IdOrigem").val();
    filtro.OrigemNome = $("#DivResumoAcoes-Container #OrigemNome").val();
    filtro.IncluirSubordinadas = false;
    filtro.DataInicio = $("#DivResumoAcoes-Container #DataInicio").val();
    filtro.DataFim = $("#DivResumoAcoes-Container #DataFim").val();
    filtro.IdResponsavel = $("#DivResumoAcoes-Container #IdResponsave").val();
    filtro.ResponsavelNome = $("#DivResumoAcoes-Container #ResponsavelNom").val();
    return filtro;
  };

  return filtroResumoDasTarefasController;

})();
