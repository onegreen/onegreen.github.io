﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.indicadoresBaseController = (function() {
  function indicadoresBaseController(contexto, options, resource) {
    this.contexto = contexto;
    this.options = options;
    this.resource = resource;
    this.graficoDeTolerancia = bind(this.graficoDeTolerancia, this);
    this.aoSelecionarUnidadeMedida = bind(this.aoSelecionarUnidadeMedida, this);
    this.atualizarValorPrecisao = bind(this.atualizarValorPrecisao, this);
    this.somarPrecisao = bind(this.somarPrecisao, this);
    this.funcoesFacilitadorDimensao = bind(this.funcoesFacilitadorDimensao, this);
    this.funcoesFacilitadorAreaDeResultado = bind(this.funcoesFacilitadorAreaDeResultado, this);
    this.funcoesFacilitadorUnidadeMedida = bind(this.funcoesFacilitadorUnidadeMedida, this);
    this.loadAllComboDimensoes = bind(this.loadAllComboDimensoes, this);
    this.loadComboAreaDeResultado = bind(this.loadComboAreaDeResultado, this);
    this.loadComboUnidadeMedida = bind(this.loadComboUnidadeMedida, this);
    this.atualizarGraficoDeTolerancias = bind(this.atualizarGraficoDeTolerancias, this);
    $(this.contexto).window({
      width: '900px'
    });
    this.precisao = $("#CasasDecimais");
    this.precisaoMaxima = 9;
    this.precisaoMinima = 0;
    $(this.contexto).find("input[alt=percent]").setMask();
    $(this.contexto).find("input[alt=decimal]").setMask();
    this.atualizarValorPrecisao(0, parseInt(this.precisao.val()));
    $(this.contexto).find("input[alt=integer]").setMask();
    $(this.contexto).find("input[alt=time]").setMask();
    $(this.contexto).find("input[alt=day]").setMask({
      mask: '99',
      maxLength: 2
    });
    this.loadComboAreaDeResultado();
    this.loadComboUnidadeMedida();
    this.loadAllComboDimensoes();
    this.funcoesFacilitadorUnidadeMedida();
    this.funcoesFacilitadorAreaDeResultado();
    this.funcoesFacilitadorDimensao();
    this.configurarControleDePrecisao();
    this.atualizarGraficoDeTolerancias();
    indicadoresBaseController.manipularToleranciasPorSinalDeMelhor(this.options.sinalDeMelhor);
    $("#sinalDeMelhor input").click(this.bindClickSinalDeMelhor);
    $("#sinalDeMelhor input").click(this.graficoDeTolerancia);
    $("#abaPropriedadesPadrao", this.contexto).on("shown.bs.tab", this.graficoDeTolerancia);
    $("#configuracoesAvancadasContainer", this.contexto).on("shown.bs.collapse", this.graficoDeTolerancia);
    $("[rel='tooltip']").tooltip();
    $("#PercentualDeToleranciaAzul").change(this.graficoDeTolerancia);
    $("#PercentualDeToleranciaAmereloInferior").change(this.graficoDeTolerancia);
    $("#PercentualDeToleranciaVerdeInferior").change(this.graficoDeTolerancia);
    $("#PercentualDeToleranciaAmereloSuperior").change(this.graficoDeTolerancia);
    $("#PercentualDeToleranciaVerdeSuperior").change(this.graficoDeTolerancia);
  }

  indicadoresBaseController.prototype.atualizarGraficoDeTolerancias = function() {
    return setTimeout((function(_this) {
      return function() {
        return _this.graficoDeTolerancia();
      };
    })(this), 200);
  };

  indicadoresBaseController.prototype.loadComboUnidadeMedida = function() {
    return setCombo(this.contexto, '#UnidadeMedida_Nome', this.aoSelecionarUnidadeMedida);
  };

  indicadoresBaseController.prototype.loadComboAreaDeResultado = function() {
    return setCombo(this.contexto, '#AreaDeResultados_Nome');
  };

  indicadoresBaseController.prototype.loadAllComboDimensoes = function() {
    $('#Dimensao1_Nome').removeAttr('data-val-required');
    $('#Dimensao2_Nome').removeAttr('data-val-required');
    $('#Dimensao3_Nome').removeAttr('data-val-required');
    $('#Dimensao4_Nome').removeAttr('data-val-required');
    $('#Dimensao5_Nome').removeAttr('data-val-required');
    $('#Dimensao6_Nome').removeAttr('data-val-required');
    setCombo(this.contexto, '#Dimensao1_Nome');
    setCombo(this.contexto, '#Dimensao2_Nome');
    setCombo(this.contexto, '#Dimensao3_Nome');
    setCombo(this.contexto, '#Dimensao4_Nome');
    setCombo(this.contexto, '#Dimensao5_Nome');
    return setCombo(this.contexto, '#Dimensao6_Nome');
  };

  indicadoresBaseController.prototype.funcoesFacilitadorUnidadeMedida = function() {
    return window.UnidadeMedida = {
      reload: (function(_this) {
        return function() {
          $("#close-modal-unidademedida").click();
          return _this.loadComboUnidadeMedida();
        };
      })(this),
      create: (function(_this) {
        return function() {
          return $("#UnidadeMedida_NomeAppendBtn").click();
        };
      })(this)
    };
  };

  indicadoresBaseController.prototype.funcoesFacilitadorAreaDeResultado = function() {
    return window.AreaDeResultados = {
      reload: (function(_this) {
        return function() {
          $("#close-modal-areaderesultado").click();
          return _this.loadComboAreaDeResultado();
        };
      })(this),
      create: (function(_this) {
        return function() {
          return $("#AreaDeResultados_NomeAppendBtn").click();
        };
      })(this)
    };
  };

  indicadoresBaseController.prototype.funcoesFacilitadorDimensao = function() {
    return window.Dimensao = {
      reload: (function(_this) {
        return function() {
          $("#close-modal-dimensao").click();
          return _this.loadAllComboDimensoes();
        };
      })(this),
      create: (function(_this) {
        return function() {
          return $("#Dimensao1_NomeAppendBtn").click();
        };
      })(this)
    };
  };

  indicadoresBaseController.prototype.bindClickSinalDeMelhor = function() {
    return indicadoresBaseController.manipularToleranciasPorSinalDeMelhor($(this).val());
  };

  indicadoresBaseController.manipularToleranciasPorSinalDeMelhor = function(sinalDeMelhor) {
    switch (sinalDeMelhor) {
      case 'ParaCima':
        return indicadoresBaseController.toggleTolerancia(false);
      case 'ParaBaixo':
        return indicadoresBaseController.toggleTolerancia(false);
      case 'MelhorNoPonto':
        return indicadoresBaseController.toggleTolerancia(true);
      case 'Faixa':
        return indicadoresBaseController.toggleTolerancia(true);
    }
  };

  indicadoresBaseController.toggleTolerancia = function(exibirTolerancias) {
    if (exibirTolerancias) {
      $("#PercentualDeToleranciaAzul").parent().hide();
      $("#PercentualDeToleranciaAmereloInferior").parent().show();
      $("#PercentualDeToleranciaVerdeInferior").parent().show();
      $("#PercentualDeToleranciaAmereloSuperior").nextAll("label").show();
      $("#PercentualDeToleranciaVerdeSuperior").nextAll("label").show();
      return $('#aceitaCenario-Container').hide();
    } else {
      $("#PercentualDeToleranciaAzul").parent().show();
      $("#PercentualDeToleranciaAmereloInferior").parent().hide();
      $("#PercentualDeToleranciaVerdeInferior").parent().hide();
      $("#PercentualDeToleranciaAmereloSuperior").nextAll("label").hide();
      $("#PercentualDeToleranciaVerdeSuperior").nextAll("label").hide();
      return $('#aceitaCenario-Container').show();
    }
  };

  indicadoresBaseController.prototype.configurarControleDePrecisao = function() {
    var controleDePrecisao;
    controleDePrecisao = $('#controleDePrecisao');
    $('.js-somar', controleDePrecisao).click((function(_this) {
      return function() {
        return _this.somarPrecisao(1, _this.precisaoMaxima);
      };
    })(this));
    return $('.js-subtrair', controleDePrecisao).click((function(_this) {
      return function() {
        return _this.somarPrecisao(-1, _this.precisaoMinima);
      };
    })(this));
  };

  indicadoresBaseController.prototype.somarPrecisao = function(mais, limite) {
    var valorAtual;
    valorAtual = parseInt(this.precisao.val());
    if (valorAtual !== limite && !isNaN(valorAtual)) {
      return this.atualizarValorPrecisao(mais, valorAtual);
    }
  };

  indicadoresBaseController.prototype.atualizarValorPrecisao = function(mais, valorAtual) {
    var qtd, txt;
    qtd = valorAtual + mais;
    if (qtd === 0) {
      txt = '###.##0';
    } else {
      txt = '###.##0,';
    }
    txt = txt + window.repeatString('0', qtd);
    this.precisao.val(qtd);
    return $('#QntQcasasDecimais').val(txt);
  };

  indicadoresBaseController.prototype.aoSelecionarUnidadeMedida = function(el) {
    return $as.Performance.IndicadoresBase.ObterFormaDeAcumuloAutomaticoDaUnidade.get({
      IdUnidadeMedida: el[0].value
    }).done((function(_this) {
      return function(data) {
        return $("#label-forma-de-acumulo-automatico").html(data);
      };
    })(this));
  };

  indicadoresBaseController.prototype.graficoDeTolerancia = function() {
    var grafico;
    grafico = new graficoDeToleranciaController(this.contexto, "#graficoDeTolerancia-container", "#sinalDeMelhor input:checked", "#PercentualDeToleranciaAmereloSuperior", "#PercentualDeToleranciaAmereloInferior", "#PercentualDeToleranciaVerdeSuperior", "#PercentualDeToleranciaVerdeInferior", "#PercentualDeToleranciaAzul");
    return grafico.rederizarGrafico();
  };

  return indicadoresBaseController;

})();
