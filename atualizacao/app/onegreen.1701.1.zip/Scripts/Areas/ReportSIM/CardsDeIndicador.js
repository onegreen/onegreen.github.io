﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.cardsDeIndicadorController = (function(superClass) {
  extend(cardsDeIndicadorController, superClass);

  function cardsDeIndicadorController(view, model, options) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.retornarCartao = bind(this.retornarCartao, this);
    this.editarCartao = bind(this.editarCartao, this);
    this.editar = bind(this.editar, this);
    this.adicionar = bind(this.adicionar, this);
    this.construirPreview = bind(this.construirPreview, this);
    this.ReferenciaLista = "Cards";
    cardsDeIndicadorController.__super__.constructor.call(this, this.view, this.model, this.options);
  }

  cardsDeIndicadorController.prototype.construirPreview = function() {
    var indicador;
    indicador = this.construirJSONItem();
    if (this.EPossivelGerarPreviewPara(indicador)) {
      return $as.ReportSIM.SIMParts.CartaoDeIndicadorParaVinculo.get(indicador).done((function(_this) {
        return function(html) {
          _this.ContainerDoPreview.html(html);
          return _this.configurarEdicaoDoCartao();
        };
      })(this));
    }
  };

  cardsDeIndicadorController.prototype.adicionar = function(fecharModal) {
    this.ItensContainer.append(this.get("#PreviewDoCartao").html());
    showBottomNoty(Resource.NovoCartaoAdcionado);
    this.aoAlterarContianer();
    return this.construirPreview();
  };

  cardsDeIndicadorController.prototype.editar = function() {
    var cardAntigo, cardNovo, ordem;
    ordem = $('.js-OrdemItemDeIndicador', this.get("#PreviewDoCartao")).val();
    cardAntigo = $(".js-OrdemItemDeIndicador[value='" + ordem + "']", this.ItensContainer).closest('.js-ItemDeIndicador');
    cardNovo = $('.js-ItemDeIndicador', this.get("#PreviewDoCartao"));
    cardAntigo.replaceWith(cardNovo);
    showBottomNoty(Resource.CartaoAlterado);
    this.aoAlterarContianer();
    return this.fecharModal();
  };

  cardsDeIndicadorController.prototype.editarCartao = function(event) {
    var card;
    card = this.retornarCartao(event);
    return $as.ReportSIM.SIMParts.EditCartaoDeIndicador.get(card).done((function(_this) {
      return function(html) {
        _this.abrirModal(html);
        _this.ativarEventosModal(_this.editar);
        return _this.configurarEdicaoDoCartao();
      };
    })(this));
  };

  cardsDeIndicadorController.prototype.retornarCartao = function(event) {
    var card, cartao;
    cartao = $(event.delegateTarget).closest('.js-ItemDeIndicador');
    card = {
      idCartao: $(".js-IdDoCartao", cartao).val(),
      ordem: $(".js-OrdemItemDeIndicador", cartao).val(),
      formaDeVisualizacao: $(".js-FormaDeVisualizacaoDoCartao", cartao).val(),
      frequencia: $(".js-FrequenciaDoCartao", cartao).val(),
      atraso: $(".js-AtrasoDoCartao", cartao).val(),
      idIndicador: $(".js-IndicadorSelecionado", cartao).val(),
      IndicadorReferencia: this.IdIndicador,
      mostrarData: $(".js-MostarData", cartao).val(),
      descricao: $(".js-NomeDoCartao", cartao).val()
    };
    return card;
  };

  return cardsDeIndicadorController;

})(window.SIMPartsDeIndicador);
