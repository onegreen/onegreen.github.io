﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.relatoriosDisplayController = (function(superClass) {
  extend(relatoriosDisplayController, superClass);

  function relatoriosDisplayController(view, model, options, resource) {
    this.view = view;
    this.model = model;
    this.options = options;
    this.resource = resource;
    this.aoEnviarEmail = bind(this.aoEnviarEmail, this);
    this.IE8Rack = bind(this.IE8Rack, this);
    this.aoMarcarFavorito = bind(this.aoMarcarFavorito, this);
    this.configurarMenu = bind(this.configurarMenu, this);
    this.enviarPorEmail = bind(this.enviarPorEmail, this);
    this.changeDate = bind(this.changeDate, this);
    this.setupDatePicker = bind(this.setupDatePicker, this);
    this.load = bind(this.load, this);
    relatoriosDisplayController.__super__.constructor.call(this, this.view, this.model);
    this.contexto = this.view;
    window.MarcarMenuSuperior("#lnkPagina");
    this.load();
    this.get('#enviarPaginaPorEmail').click(this.enviarPorEmail);
    this.configurarMenu();
    window.DashboardsUtil.DefinirReloadParaPaginaPrincipalDaUg();
  }

  relatoriosDisplayController.prototype.load = function() {
    this.setupDatePicker();
    this.get("[title]").tooltip();
    return $("[rel=tooltip]").tooltip();
  };

  relatoriosDisplayController.prototype.setupDatePicker = function() {
    $('#SelecionarData').click((function(_this) {
      return function() {
        return DatePickerCustom.setDatePickerCustom('SelecionarData', 'picker-container', 'DataDoRelatorio', _this.changeDate, $('#DataDoRelatorio').val());
      };
    })(this));
  };

  relatoriosDisplayController.prototype.changeDate = function(dateText) {
    var data;
    data = this.get('#DataDoRelatorio').val();
    return window.location = (this.model.dateChangeUrl()) + "?id=" + (this.model.Id()) + "&data=" + data;
  };

  relatoriosDisplayController.prototype.enviarPorEmail = function() {
    var data;
    data = {
      id: this.model.Id(),
      data: this.get('#DataDoRelatorio').val()
    };
    return $as.ReportSIM.Relatorios.EnviarRelatorioPorEmail.post(data).done((function(_this) {
      return function(resultado) {
        return showBottomNoty(resultado.data.mensagem, 2000, null);
      };
    })(this));
  };

  relatoriosDisplayController.prototype.configurarMenu = function() {
    this.get('#container-anterioraotitulo').html($('#dl-menu-pagina'));
    this.get('#dl-menu-pagina').show();
    this.get('.dl-menuwrapper').dlmenu({
      backLabel: this.resource.Voltar,
      animationClasses: {
        classin: 'dl-animate-in-2',
        classout: 'dl-animate-out-2'
      }
    });
    return this.IE8Rack();
  };

  relatoriosDisplayController.prototype.aoMarcarFavorito = function() {
    var parent;
    $('#marcarFavorito i', this.contexto).toggleClass('fa-star-o').toggleClass('fa-star').toggleClass('c-laranja');
    if ($('#marcarFavorito i', this.contexto).hasClass('fa-star')) {
      parent = $('#marcarFavorito');
      parent.attr('data-original-title', parent.data('desmarcar-favorito'));
    } else {
      parent = $('#marcarFavorito');
      parent.attr('data-original-title', parent.data('marcar-favorito'));
    }
    return $as.ReportSIM.Relatorios.MenuDeRelatoriosParaSelecao.get().done((function(_this) {
      return function(data) {
        return _this.contexto.find('#menu-relatorio-para-selecao').replaceWith(data);
      };
    })(this));
  };

  relatoriosDisplayController.prototype.IE8Rack = function() {
    var menu;
    menu = $('#dl-menu-pagina .dl-menu').hide();
    menu.hide();
    $('#dl-menu-pagina .dl-trigger').click((function(_this) {
      return function() {
        return menu.show();
      };
    })(this));
    return $('body').click((function(_this) {
      return function() {
        return menu.hide();
      };
    })(this));
  };

  relatoriosDisplayController.prototype.aoEnviarEmail = function(data) {
    return showBottomNoty(data.data.mensagem, 2000, null);
  };

  return relatoriosDisplayController;

})(window.baseController);
