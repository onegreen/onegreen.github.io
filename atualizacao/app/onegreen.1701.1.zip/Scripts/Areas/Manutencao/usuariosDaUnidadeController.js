﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.usuariosDaUnidadeController = (function() {
  function usuariosDaUnidadeController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.reload = bind(this.reload, this);
    this.alterarPermissaoDeAlteracao = bind(this.alterarPermissaoDeAlteracao, this);
    this.configurarBinds = bind(this.configurarBinds, this);
    this.loadComboUsuarios = bind(this.loadComboUsuarios, this);
    this.loadComboUsuarios();
    this.configurarBinds();
  }

  usuariosDaUnidadeController.prototype.loadComboUsuarios = function() {
    return setCombo(this.contexto, '#NomeDoUsuario');
  };

  usuariosDaUnidadeController.prototype.configurarBinds = function() {
    return $("input[type=checkbox]", "#listagem-usuario-da-unidade").click(this.alterarPermissaoDeAlteracao);
  };

  usuariosDaUnidadeController.prototype.alterarPermissaoDeAlteracao = function(elemento) {
    var usuario;
    usuario = $(elemento.delegateTarget);
    return $as.Manutencao.UsuariosDaUnidade.AlterarPermissaoDeAlteracao.post({
      idDoUsuario: usuario.data("usuario"),
      idDaUnidadeGerencial: this.options.idDaUnidadeGerencial
    }).success((function(_this) {
      return function(data) {
        return _this.reload();
      };
    })(this));
  };

  usuariosDaUnidadeController.prototype.reload = function() {
    return $as.Manutencao.UsuariosDaUnidade.Reload.get({
      idDaUnidadeGerencial: this.options.idDaUnidadeGerencial
    }).success((function(_this) {
      return function(data) {
        $("#listagem-usuario-da-unidade", _this.contexto).html(data);
        $("#NomeDoUsuario", _this.contexto).val("");
        $("#IdDoUsuario", _this.contexto).val("");
        $("#IncluirSubordinadas", _this.contexto).removeAttr("checked");
        $("#PodeAlterar", _this.contexto).removeAttr("checked");
        _this.loadComboUsuarios();
        return _this.configurarBinds();
      };
    })(this));
  };

  return usuariosDaUnidadeController;

})();
