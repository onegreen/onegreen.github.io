﻿var IndicadorDeErro;

this.IndicadorDeErro || {};

IndicadorDeErro = (function() {
  function IndicadorDeErro() {}

  IndicadorDeErro.errorClass = "input-validation-error";

  IndicadorDeErro.adicionarErroNosCampos = function(lisComErros, contexto) {
    var campo, element, i, len, ref, results;
    IndicadorDeErro.removerErroDosCampos();
    ref = $(lisComErros);
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      element = ref[i];
      campo = $(element).data('field-id');
      results.push(IndicadorDeErro.marcarComErro(campo));
    }
    return results;
  };

  IndicadorDeErro.adicionarErroNosCamposDeData = function(idsPropriedadesDeData, lisComErros, contexto) {
    var i, id, idsComErro, len, results;
    idsComErro = $(lisComErros).map(function() {
      return $(this).data('field-id');
    });
    results = [];
    for (i = 0, len = idsPropriedadesDeData.length; i < len; i++) {
      id = idsPropriedadesDeData[i];
      if ($.inArray(id, idsComErro) >= 0) {
        IndicadorDeErro.marcarComErro(id, contexto);
        IndicadorDeErro.marcarComErro(id + "_Date", contexto);
        results.push(IndicadorDeErro.marcarComErro(id + "_Time", contexto));
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  IndicadorDeErro.forcarAdicionarErroNoCampo = function(idDoCampo, idDaPropriedadeComErro, lisComErros, contexto) {
    var idsComErro;
    idsComErro = $(lisComErros).map(function() {
      return $(this).data('field-id');
    });
    if ($.inArray(idDaPropriedadeComErro, idsComErro) >= 0) {
      return IndicadorDeErro.marcarComErro(idDoCampo, contexto);
    }
  };

  IndicadorDeErro.marcarComErro = function(idDoCampo, contexto) {
    var campo;
    if (!contexto) {
      campo = $("#" + idDoCampo);
    } else {
      campo = $("#" + idDoCampo, $("" + contexto));
    }
    if (!campo.hasClass(IndicadorDeErro.errorClass)) {
      return campo.addClass(IndicadorDeErro.errorClass);
    }
  };

  IndicadorDeErro.removerErroDosCampos = function() {
    var divError;
    divError = 'div.form-group.error';
    $("input." + IndicadorDeErro.errorClass, divError).removeClass(IndicadorDeErro.errorClass);
    return $(divError).removeClass('error');
  };

  return IndicadorDeErro;

})();
