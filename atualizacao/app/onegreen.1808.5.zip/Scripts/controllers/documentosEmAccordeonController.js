﻿window.documentosEmAccordeonController = (function() {
  var teste;

  function documentosEmAccordeonController(options) {
    var contexto, idAgregador, idDocumento;
    this.options = options;
    documentosEmAccordeonController.__super__.constructor.call(this, this.options);
    contexto = $("#documentoEmAccordeon-" + this.options.id);
    idAgregador = void 0;
    idDocumento = void 0;
  }

  documentosEmAccordeonController.prototype.criarDivNoBody = function(idDiv) {
    if ($('#' + idDiv).length === 0) {
      return $("body").append("<div id=" + idDiv + "></div>");
    }
  };

  documentosEmAccordeonController.prototype.fecharTelaDocumento = function() {
    var divAdd;
    divAdd = $("#addDocumento-modal-container", contexto);
    return divAdd.Animatef({
      height: "0px"
    }, function() {
      return divAdd.html("");
    });
  };

  documentosEmAccordeonController.prototype.abrirModalAdicionarDocumento = function() {
    return $.ajax({
      url: this.options.adicionarDocumentoUrl,
      data: {
        updateTargetId: "AgregadorUpdate-" + this.options.id
      },
      success: function(html) {
        return successAbrirDocumento(html);
      }
    });
  };

  teste = function(stringF) {
    return alert(stringF);
  };

  documentosEmAccordeonController.prototype.abrirModalEditarDocumento = function(id) {
    return $.ajax({
      url: this.options.editarDocumentoUrl,
      data: {
        id: id,
        updateTargetId: "AgregadorUpdate-" + this.options.id
      },
      success: function(html) {
        return successAbrirDocumento(html);
      }
    });
  };

  documentosEmAccordeonController.prototype.successAbrirDocumento = function(html) {
    var divAdd;
    divAdd = $("#addDocumento-modal-container", contexto);
    return divAdd.animate({
      height: "220px"
    }, function() {
      divAdd.html(html);
      return $("#btnFecharDocumento", contexto).click(fecharTelaDocumento);
    });
  };

  documentosEmAccordeonController.prototype.recarregarDocumentos = function(id, updateTargetId) {
    return $.ajax({
      url: this.options.recarregarDocumentosUrl,
      data: {
        id: id,
        updateTargetId: "AgregadorUpdate-" + this.options.id
      },
      success: function(html) {
        return $("#AgregadorUpdate-" + this.options.id).parent().html(html);
      }
    });
  };

  documentosEmAccordeonController.prototype.apagarDocumento = function(idAgre, idDoc) {
    var idAgregador, idDocumento;
    idAgregador = idAgre;
    idDocumento = idDoc;
    return $("#Excluir-Agregador").find("#modalConfirmarJavascript").window("show");
  };

  documentosEmAccordeonController.prototype.excluirDocumento = function() {
    return $.ajax({
      url: this.options.excluirDocumentoUrl,
      data: {
        idAgregador: idAgregador,
        idDocumento: idDocumento,
        updateTargetId: "AgregadorUpdate-" + this.options.id
      }
    });
  };

  return documentosEmAccordeonController;

})();
