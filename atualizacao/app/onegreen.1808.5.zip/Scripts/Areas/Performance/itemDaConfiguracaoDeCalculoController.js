﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

window.itemDaConfiguracaoDeCalculoController = (function(superClass) {
  extend(itemDaConfiguracaoDeCalculoController, superClass);

  function itemDaConfiguracaoDeCalculoController(view, options) {
    this.view = view;
    this.options = options;
    this.selecionarTipoDoItem = bind(this.selecionarTipoDoItem, this);
    this.aoSalvar = bind(this.aoSalvar, this);
    this.configurarCombos = bind(this.configurarCombos, this);
    this.comboIndicador;
    this.comboUnidade;
    this.comboOrigem;
    this.configurarCombos();
    $(this.view).window({
      height: 250
    });
    $('#close-modal-createedititemformula').click((function(_this) {
      return function() {
        return window.configurarFormulaDeCalculo.reloadItens();
      };
    })(this));
    $('.js-tipo-item', this.view).click(this.selecionarTipoDoItem);
  }

  itemDaConfiguracaoDeCalculoController.prototype.configurarCombos = function() {
    var onSelectIndicador, onSelectUG, parameters;
    this.comboOrigem = setCombo(this.view, "#Origem_Nome");
    onSelectUG = (function(_this) {
      return function(input) {
        var disable;
        disable = $(input).val() === '';
        _this.comboIndicador.reset();
        return _this.comboIndicador.disableElseEnable(disable);
      };
    })(this);
    this.comboUnidade = setCombo(this.view, '#UnidadeGerencial_SiglaAtual', onSelectUG);
    onSelectIndicador = (function(_this) {
      return function(input) {
        var $origensContainer, disable, idDoIndicador;
        $origensContainer = _this.get('#origensDoItem');
        idDoIndicador = $(input).val();
        disable = idDoIndicador === '';
        if (disable) {
          return $origensContainer.html('');
        } else {
          return $as.Performance.ItensDaConfiguracaoDeCalculo.SelecaoDeOrigens.get({
            idDoIndicador: idDoIndicador,
            origem: 'Padrao'
          }).done(function(html) {
            return $origensContainer.html(html);
          });
        }
      };
    })(this);
    parameters = {
      idUnidadeGerencial: (function(_this) {
        return function() {
          return _this.comboUnidade.value();
        };
      })(this)
    };
    this.comboIndicador = Results.api.setComboIndicador(this.view, '#NomeDoIndicador', onSelectIndicador, parameters);
    if (this.comboIndicador) {
      return this.comboIndicador.disableElseEnable(this.comboUnidade.value() === '');
    }
  };

  itemDaConfiguracaoDeCalculoController.prototype.aoSalvar = function(data) {
    return window.configurarFormulaDeCalculo.reloadItens();
  };

  itemDaConfiguracaoDeCalculoController.prototype.selecionarTipoDoItem = function(evento) {
    var botao, indice, origem;
    botao = $(evento.currentTarget);
    indice = botao.data('index');
    origem = botao.data('origem');
    $('#labelTipo', this.view).text(botao.text());
    if (indice < 0) {
      $('#IdDoIndicador', '#comboIndicador').val(indice);
      $('#comboIndicador', this.view).hide();
      $('#origensDoItem').hide();
      $('.validation-summary-errors', this.view).remove();
      return $('.error', this.view).removeClass('error');
    } else {
      $('#IdDoIndicador', '#comboIndicador').val('');
      $('#comboIndicador', this.view).show();
      return $('#origensDoItem', this.view).show();
    }
  };

  return itemDaConfiguracaoDeCalculoController;

})(window.baseController);
