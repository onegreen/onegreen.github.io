﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

this.operacaoNoSistemaPorGrupoDeUsuarioController = (function() {
  function operacaoNoSistemaPorGrupoDeUsuarioController(contexto, options) {
    this.contexto = contexto;
    this.options = options;
    this.loadComboRegrasDoSistema = bind(this.loadComboRegrasDoSistema, this);
    this.aoSelecionarRegra = bind(this.aoSelecionarRegra, this);
    $(this.contexto).window();
    this.loadComboRegrasDoSistema();
  }

  operacaoNoSistemaPorGrupoDeUsuarioController.prototype.aoSelecionarRegra = function() {
    return $as.API.OperacoesNoSistema.ObterOpcoesDaOperacaoNoSistemaPorGrupoDeUsuario.get({
      id: $("#RegraDoSistema_Id", this.contexto).val()
    }).success((function(_this) {
      return function(data) {
        return $("#container-opcoes-da-operacao", _this.contexto).html(data);
      };
    })(this));
  };

  operacaoNoSistemaPorGrupoDeUsuarioController.prototype.loadComboRegrasDoSistema = function() {
    return setCombo(this.contexto, "#RegraDoSistema_Nome", this.aoSelecionarRegra);
  };

  return operacaoNoSistemaPorGrupoDeUsuarioController;

})();
