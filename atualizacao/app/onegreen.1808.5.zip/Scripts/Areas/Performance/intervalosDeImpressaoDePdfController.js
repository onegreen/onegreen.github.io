﻿var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

window.intervalosDeImpressaoDePdfController = (function() {
  function intervalosDeImpressaoDePdfController(view, options) {
    this.view = view;
    this.options = options;
    this.validaSemanal = bind(this.validaSemanal, this);
    this.validaDiaria = bind(this.validaDiaria, this);
    this.isValid = bind(this.isValid, this);
    this.options.inicio.on('change', (function(_this) {
      return function() {
        var valor;
        valor = parseInt(_this.options.inicio.val());
        return _this.isValid(valor, true);
      };
    })(this));
    this.options.fim.on('change', (function(_this) {
      return function() {
        var valor;
        valor = parseInt(_this.options.fim.val());
        return _this.isValid(valor, false);
      };
    })(this));
  }

  intervalosDeImpressaoDePdfController.prototype.isValid = function(valor, isInicio) {
    switch (this.options.frequencia) {
      case 'semanal':
        valor = this.validaSemanal(valor, isInicio);
        break;
      case 'diaria':
        valor = this.validaDiaria(valor, isInicio);
    }
    if (isInicio) {
      this.options.inicio.val(valor);
      return this.options.fim.val(valor + 11);
    } else {
      this.options.fim.val(valor);
      return this.options.inicio.val(valor - 11);
    }
  };

  intervalosDeImpressaoDePdfController.prototype.validaDiaria = function(valor, isInicio) {
    if (isInicio && (valor <= 1 || valor > this.options.dias - 11)) {
      return 1;
    } else if (!isInicio && (valor <= 12 || valor > this.options.dias)) {
      return 12;
    }
    return valor;
  };

  intervalosDeImpressaoDePdfController.prototype.validaSemanal = function(valor, isInicio) {
    if (isInicio && (valor <= 1 || valor > this.options.semanas - 11)) {
      return 1;
    } else if (!isInicio && valor <= 12 || valor > this.options.semanas) {
      return 12;
    }
    return valor;
  };

  return intervalosDeImpressaoDePdfController;

})();
