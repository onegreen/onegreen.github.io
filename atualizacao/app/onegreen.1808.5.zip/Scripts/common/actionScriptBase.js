﻿this.asf = function(action, url, controllerName) {
  url = url + action;
  controllerName[action] = {
    url: url,
    get: function(data, opcoes) {
      var opcoesDefault, settings;
      opcoesDefault = {
        type: 'GET',
        data: data,
        url: url
      };
      settings = opcoes ? $.extend({}, opcoes, opcoesDefault) : opcoesDefault;
      return $.ajax(settings);
    },
    postJson: function(data, opcoes) {
      var opcoesDefault, settings;
      opcoesDefault = {
        type: 'POST',
        data: data,
        url: url,
        contentType: 'application/json'
      };
      settings = opcoes ? $.extend({}, opcoes, opcoesDefault) : opcoesDefault;
      return $.ajax(settings);
    },
    post: function(data, opcoes) {
      var opcoesDefault, settings;
      opcoesDefault = {
        type: 'POST',
        data: data,
        url: url
      };
      settings = opcoes ? $.extend({}, opcoes, opcoesDefault) : opcoesDefault;
      return $.ajax(settings);
    },
    postFormData: function(formData, opcoes) {
      var opcoesDefault, settings;
      opcoesDefault = {
        type: 'POST',
        data: formData,
        url: url,
        processData: false,
        contentType: false
      };
      settings = opcoes ? $.extend({}, opcoes, opcoesDefault) : opcoesDefault;
      return $.ajax(settings);
    }
  };
};
