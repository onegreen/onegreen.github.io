

print ('CASO 302')
GO
/* Criando estrutura para permitir criação de Tags */
/*********************************************************/
/*********************   CASO 302  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20180319-302')
BEGIN
/*==============================================================*/
	DECLARE @lOrd INT
	BEGIN

		SELECT @lOrd = MAX(ORD) + 1
		  FROM TREGSIS
		 WHERE TIP = 1
		 
		INSERT INTO TREGSIS (IDEMOD, CODINT, NME, ORD, TIP, UPDTME)
			 SELECT IDEMOD, 'Remover tags do cadastro', 'Remover tags do cadastro', @lOrd, 1, GETDATE()
			   FROM TMOD
			  WHERE MODNME = 'Onegreen'

	END	
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TCMPTAG                                               */
	/*==============================================================*/
	CREATE TABLE TCMPTAG (
	   IDECMPTAG            DECIMAL(13)          IDENTITY(1110000000000,1),
	   UPDTME               DATETIME             NOT NULL
	)

	ALTER TABLE TCMPTAG
	   ADD CONSTRAINT TCMPTAG_PK PRIMARY KEY (IDECMPTAG)
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TTAGAMB                                               */
	/*==============================================================*/
	CREATE TABLE TTAGAMB (
	   IDETAGAMB            DECIMAL(13)          IDENTITY(1110000000000, 1),
	   IDEEMP               DECIMAL(13)          NULL,
	   NME                  NVARCHAR(100)        NOT NULL,
	   UPDTME               DATETIME             NOT NULL
	)

	ALTER TABLE TTAGAMB
	   ADD CONSTRAINT TTAGAMB_PK PRIMARY KEY (IDETAGAMB)

	/*==============================================================*/
	/* INDEX: TEPM2TTAGAMB_FK                                       */
	/*==============================================================*/
	CREATE INDEX TEPM2TTAGAMB_FK ON TTAGAMB (
	IDEEMP ASC
	)

	ALTER TABLE TTAGAMB
	   ADD CONSTRAINT TEMP2TTAGAMB_FK FOREIGN KEY (IDEEMP)
		  REFERENCES TEMP (IDEEMP)
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TCMPTAGAMB                                            */
	/*==============================================================*/
	CREATE TABLE TCMPTAGAMB (
	   IDECMPTAG            DECIMAL(13)          NULL,
	   IDETAGAMB            DECIMAL(13)          NULL
	)

	ALTER TABLE TCMPTAGAMB
	   ADD CONSTRAINT TCMPTAG2TCMPTAGAMB_FK FOREIGN KEY (IDECMPTAG)
		  REFERENCES TCMPTAG (IDECMPTAG)

	ALTER TABLE TCMPTAGAMB
	   ADD CONSTRAINT TTAGAMB2TCMPTAGAMB_FK FOREIGN KEY (IDETAGAMB)
		  REFERENCES TTAGAMB (IDETAGAMB)
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TEPRLICAMB                                            */
	/*==============================================================*/
	ALTER TABLE TEPRLICAMB
		ADD IDECMPTAG DECIMAL(13) NULL
	
	/*==============================================================*/
	/* INDEX: TCMPTAG2TEPRLICAMB_FK                                 */
	/*==============================================================*/
	CREATE INDEX TCMPTAG2TEPRLICAMB_FK ON TEPRLICAMB (
	IDECMPTAG ASC
	)

	ALTER TABLE TEPRLICAMB
	   ADD CONSTRAINT TCMPTAG2TEPRLICAMB_FK FOREIGN KEY (IDECMPTAG)
		  REFERENCES TCMPTAG (IDECMPTAG)
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TLICAMB                                               */
	/*==============================================================*/
	ALTER TABLE TLICAMB
		ADD IDECMPTAG DECIMAL(13) NULL
	
	/*==============================================================*/
	/* INDEX: TCMPTAG2TLICAMB_FK                                    */
	/*==============================================================*/
	CREATE INDEX TCMPTAG2TLICAMB_FK ON TLICAMB (
	IDECMPTAG ASC
	)

	ALTER TABLE TLICAMB
	   ADD CONSTRAINT TCMPTAG2TLICAMB_FK FOREIGN KEY (IDECMPTAG)
		  REFERENCES TCMPTAG (IDECMPTAG)
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TPACTAR                                               */
	/*==============================================================*/
	ALTER TABLE TPACTAR
		ADD IDECMPTAG DECIMAL(13) NULL
	
	/*==============================================================*/
	/* INDEX: TCMPTAG2TPACTAR_FK                                    */
	/*==============================================================*/
	CREATE INDEX TCMPTAG2TPACTAR_FK ON TPACTAR (
	IDECMPTAG ASC
	)

	ALTER TABLE TPACTAR
	   ADD CONSTRAINT TCMPTAG2TPACTAR_FK FOREIGN KEY (IDECMPTAG)
		  REFERENCES TCMPTAG (IDECMPTAG)
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TESTLICAMB                                               */
	/*==============================================================*/
	ALTER TABLE TESTLICAMB
		ADD IDECMPTAG DECIMAL(13) NULL
	
	/*==============================================================*/
	/* INDEX: TCMPTAG2TESTLICAMB_FK                                 */
	/*==============================================================*/
	CREATE INDEX TCMPTAG2TESTLICAMB_FK ON TESTLICAMB (
	IDECMPTAG ASC
	)

	ALTER TABLE TESTLICAMB
	   ADD CONSTRAINT TCMPTAG2TESTLICAMB_FK FOREIGN KEY (IDECMPTAG)
		  REFERENCES TCMPTAG (IDECMPTAG)
/*==============================================================*/
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180319-302', GETDATE())
END
GO



/*********************************************************/
/*********************** CASO 306 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 306'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20180329-306')
BEGIN

	exec sp_ModifyColumn 'TORG', 'SIG', 'NVARCHAR(30)', 1, ''' '''
		
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180329-306', GETDATE())
	
END
GO



print ('CASO 309')
GO
/* Criando permissão total para às tarefas */
/*********************************************************/
/*********************   CASO 309  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20180402-309')
BEGIN
/*==============================================================*/
	DECLARE @lOrd INT
	BEGIN

		SELECT @lOrd = MAX(ORD) + 1
		  FROM TREGSIS
		 WHERE TIP = 2
		 
		INSERT INTO TREGSIS (IDEMOD, CODINT, NME, ORD, TIP, UPDTME)
			 SELECT IDEMOD, 'Permissão total às tarefas_Onegreen', 'Permissão total às tarefas', @lOrd, 2, GETDATE()
			   FROM TMOD
			  WHERE MODNME = 'Onegreen'

	END	
/*==============================================================*/
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180402-309', GETDATE())
END
GO



print ('CASO 285')
GO
/* Criando regra para propagação da reprogramação da Validade das Licenças para Tarefas */
/*********************************************************/
/*********************   CASO 285  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20180403-285')
BEGIN
/*==============================================================*/
	DECLARE @lOrd INT
	BEGIN

		SELECT @lOrd = MAX(ORD) + 1
		  FROM TREGSIS
		 WHERE TIP = 2
		 
		INSERT INTO TREGSIS (IDEMOD, CODINT, NME, ORD, TIP, UPDTME)
			 SELECT IDEMOD, 'Propagar reprogramação da Validade das Licenças para Tarefas / Condicionantes_Onegreen', 'Propagar reprogramação da Validade das Licenças para Tarefas / Condicionantes', @lOrd, 2,  GETDATE()
			   FROM TMOD
			  WHERE MODNME = 'Onegreen'

	END	
/*==============================================================*/

	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180403-285', GETDATE())
END
GO



print ('CASO 271')
GO
/* Atualização no usuário do Onegreen  */
/*********************************************************/
/*********************   CASO 271  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20180404-271')
BEGIN
/*==============================================================*/

	UPDATE TUSU SET SUPADM = 0
	UPDATE TUSU SET SUPADM = 1 WHERE UPPER(NME) = 'ONEGREEN'

/*==============================================================*/

	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180404-271', GETDATE())
END
GO



print ('CASO 320')
GO
/* Criando permissão total para às tarefas */
/*********************************************************/
/*********************   CASO 320  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20180504-320')
BEGIN
/*==============================================================*/
	BEGIN

		ALTER TABLE TESTLICAMB ALTER COLUMN IDECONEMPRESESTAMB DECIMAL(13) NULL
		
		ALTER TABLE TESTLICAMB
		   ADD CONSTRAINT TCONEMPRESESTAMB2TEST_FK FOREIGN KEY (IDECONEMPRESESTAMB)
			  REFERENCES TCONEMPRESESTAMB (IDECONEMPRESESTAMB)

		ALTER TABLE TESTLICAMB
		   ADD CONSTRAINT TLICAMB2TESTLICAMB_FK FOREIGN KEY (IDELICAMB)
			  REFERENCES TLICAMB (IDELICAMB)

		ALTER TABLE TESTLICAMB
		   ADD CONSTRAINT TTIPEST2TEST_FK FOREIGN KEY (IDETIPESTLICAMB)
			  REFERENCES TTIPESTLICAMB (IDETIPESTLICAMB)

	END	
/*==============================================================*/
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180504-320', GETDATE())
END
GO



PRINT ('CASO 339')
GO

/* Adicionando coluna para data limite para renovação */
/*********************************************************/
/**********************   CASO 339  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '10280621-339')
BEGIN
	
/*==============================================================*/
  
		/*==============================================================*/
		/* TABLE: TLICAMB                                       		*/
		/*==============================================================*/
		ALTER TABLE TLICAMB ADD DATLIMREN DATETIME NULL
		
		ALTER TABLE TLICAMB ADD DATLIMRENMAN DECIMAL(1) NOT NULL DEFAULT 0
		
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('10280621-339', GETDATE())
END
GO



print ('CASO 345')
GO
/* Criando coluna para data do histórico */
/*********************************************************/
/*********************   CASO 345  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20180710-345')
BEGIN
/*==============================================================*/
	BEGIN

		ALTER TABLE TOBSLICAMB ADD DATOBS DATETIME NULL
		
		EXEC('UPDATE TOBSLICAMB SET DATOBS = DAT')
	END	
/*==============================================================*/
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180710-345', GETDATE())
END
GO



/*==============================================================*/
/* ATUALIZAÇÃO DA VERSÃO DO BANCO DE DADOS                      */
/*==============================================================*/

DECLARE @LVERSION DATETIME,
		@VERSAO   NVARCHAR(10)
SET @LVERSION = CAST('20180801' AS DATETIME)
SET @VERSAO = '1808.1'
IF EXISTS(SELECT VRS FROM TVRS WHERE VRS = @LVERSION AND NUMVRS = @VERSAO)
   UPDATE TVRS SET DTATBL = GETDATE() WHERE VRS = @LVERSION AND NUMVRS = @VERSAO;
ELSE
    INSERT INTO TVRS (VRS, DTATBL , NUMVRS) VALUES (@LVERSION, GETDATE() , @VERSAO);
GO

BEGIN
PRINT '1808.1'
END
GO

