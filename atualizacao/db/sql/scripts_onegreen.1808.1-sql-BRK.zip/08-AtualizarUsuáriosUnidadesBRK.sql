

DECLARE @mmo NVARCHAR(4000);
BEGIN

	IF NOT EXISTS(SELECT 1 FROM TUSU WHERE UPPER(SIG) = 'ILUDMILLA')
	BEGIN
		INSERT INTO TUSU (SIG, NME, PWD, EML, IDEEMP, LAN, ESTCIV, SXO, STT, UPDTME, SUPADM, SAL, TMEZNE, VIR, RCBEML, TRMUSO, EXCCARCHF, TLAINI) VALUES ('iludmilla', 'Ingrid Ludmila Rangel Barbosa ', '8D5A966B9E6FEF336E55CA78D359C2429A783A4E626492328030E6508673CF530C473F765D315A588642AF69F362CA6A1275024B0C6992763A72DC326C43924D', 'iludmilla@brkambiental.com.br', 1110000000001, 'pt-BR', 0, 0, 1, GETDATE(), 0, 'Zko3UxYBxNd20PsSGv1XBibjuKivr2CM1iaUQqIXnb4=', 'E. South America Standard Time', 0, 1, 1, 0, 0);
	END
	
	IF NOT EXISTS(SELECT 1 FROM TUSU WHERE UPPER(SIG) = 'MSMOTA')
	BEGIN
		INSERT INTO TUSU (SIG, NME, PWD, EML, IDEEMP, LAN, ESTCIV, SXO, STT, UPDTME, SUPADM, SAL, TMEZNE, VIR, RCBEML, TRMUSO, EXCCARCHF, TLAINI) VALUES ('msmota', 'Mônica Silva Mota', '8D7396639E45EF316E72CA37D363C2699A733A4E6247924C806AE6338634CF440C673F395D6B5A4C8677AF55F359CA4D1266026D0C4992483A64DC316C759244', 'msmota@brkambiental.com.br', 1110000000001, 'pt-BR', 0, 0, 1, GETDATE(), 0, 'scE1r7cisNGLj34Dg9kLwUYMfmIHd1uD5M7/f2lsq8E=', 'E. South America Standard Time', 0, 1, 1, 0, 0);
	END
	
	IF NOT EXISTS(SELECT 1 FROM TUSU WHERE UPPER(SIG) = 'CAMILATAVARES')
	BEGIN
		INSERT INTO TUSU (SIG, NME, PWD, EML, IDEEMP, LAN, ESTCIV, SXO, STT, UPDTME, SUPADM, SAL, TMEZNE, VIR, RCBEML, TRMUSO, EXCCARCHF, TLAINI) VALUES ('camilatavares', 'Camila Tavares', '8D5396509E4FEF496E61CA41D331C2739A353A4B624492758057E6518674CF380C413F555D525A30866BAF63F357CA54125802730C4992643A63DC716C439239', 'camilatavares@brkambiental.com.br', 1110000000001, 'pt-BR', 0, 0, 1, GETDATE(), 0, 'SPOIaA1s5KDuWQt8AUR0kcWTXsIdcqC9izdddZvjAEA=', 'E. South America Standard Time', 0, 1, 1, 0, 0);
	END


END

update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Ambiental / TO-PA') where sig not in ('Analicecarvalho', 'Dcardoso', 'faustodeassis', 'mcapra', 'mlcunha', 'ocmartins');
update tusu set ideuniger = (select ideuni from tuni where sig = 'AP5') where sig = 'iaraalmeida';
update tusu set ideuniger = (select ideuni from tuni where sig = 'AP5') where sig = 'leonardobenatte';
update tusu set ideuniger = (select ideuni from tuni where sig = 'AP5') where sig = 'icaro';
update tusu set ideuniger = (select ideuni from tuni where sig = 'AP5') where sig = 'dmoura';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Aquapolo') where sig = 'alinepaiva';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Aquapolo') where sig = 'iaramachado';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Aquapolo') where sig = 'soliveira';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Aquapolo') where sig = 'radovan';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Aquapolo') where sig = 'fsbarbosa';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Blumenau') where sig = 'vscruz';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Blumenau') where sig = 'mcspiess';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Blumenau') where sig = 'tlopes';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Blumenau') where sig = 'fernandocabral';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Blumenau') where sig = 'fricardo';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Cachoeiro de Itapemirim') where sig = 'pbreda';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Cachoeiro de Itapemirim') where sig = 'jfabre';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Cachoeiro de Itapemirim') where sig = 'jordano';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Cachoeiro de Itapemirim') where sig = 'lfsamuel';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Cachoeiro de Itapemirim') where sig = 'vleao';
update tusu set ideuniger = (select ideuni from tuni where sig = 'DAT') where sig = 'francineflores';
update tusu set ideuniger = (select ideuni from tuni where sig = 'DAT') where sig = 'cleitonscholl';
update tusu set ideuniger = (select ideuni from tuni where sig = 'DAT') where sig = 'jadisonjafe';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Goiás') where sig = 'danyella';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Goiás') where sig = 'celiodamasio';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Goiás') where sig = 'jozielandrade';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Goiás') where sig = 'ruycesar';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Goiás') where sig = 'pedrogobbo';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Goiás') where sig = 'lucianoteles';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Goiás') where sig = 'carlaurbanek';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Goiás') where sig = 'marcoshenrique';
update tusu set ideuniger = (select ideuni from tuni where sig = 'UVR Grajaú') where sig = 'paulasilva';
update tusu set ideuniger = (select ideuni from tuni where sig = 'UVR Grajaú') where sig = 'barel';
update tusu set ideuniger = (select ideuni from tuni where sig = 'UVR Grajaú') where sig = 'marcosnunes';
update tusu set ideuniger = (select ideuni from tuni where sig = 'UVR Grajaú') where sig = 'lmuniz';
update tusu set ideuniger = (select ideuni from tuni where sig = 'UVR Grajaú') where sig = 'jelison';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Jaguaribe') where sig = 'mchagas';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Jaguaribe') where sig = 'marceloguerra';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Jaguaribe') where sig = 'ricardocerqueira';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Jaguaribe') where sig = 'psamonteiro';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Jaguaribe') where sig = 'pedrochinelis';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Jeceaba') where sig = 'macosta';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Jeceaba') where sig = 'mconde';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Jeceaba') where sig = 'bcunha';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Jeceaba') where sig = 'marcovieira';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Jeceaba') where sig = 'cmlbarbosa';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Ambiental Limeira') where sig = 'Angelicarodrigues';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Ambiental Limeira') where sig = 'ekrambeck';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Macaé') where sig = 'iludmilla';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Macaé') where sig = 'bernardomelo';
update tusu set ideuniger = (select ideuni from tuni where sig = 'Saneaqua ') where sig = 'joicemartins';
update tusu set ideuniger = (select ideuni from tuni where sig = 'Saneaqua ') where sig = 'lronconi';
update tusu set ideuniger = (select ideuni from tuni where sig = 'Saneaqua ') where sig = 'rnascimento';
update tusu set ideuniger = (select ideuni from tuni where sig = 'Saneaqua ') where sig = 'brunaloreto';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Manso ') where sig = 'paolasilva';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Manso ') where sig = 'rpagni';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Manso ') where sig = 'marceloisoni';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Manso ') where sig = 'marcosmendanha';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Manso ') where sig = 'fabiogomes';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Maranhão') where sig = 'lucaspsilva';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Maranhão') where sig = 'ricardom';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Maranhão') where sig = 'pauloroberto';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Maranhão') where sig = 'gleysontrindade';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Maranhão') where sig = 'cregis';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Mauá') where sig = 'thlima';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Mauá') where sig = 'pizidorio';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Mauá') where sig = 'ycaro';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Mauá') where sig = 'bgravata';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Mauá') where sig = 'tsantana';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Porto Ferreira') where sig = 'mbosso';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Porto Ferreira') where sig = 'alemfelipe';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Porto Ferreira') where sig = 'rl';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Porto Ferreira') where sig = 'azampieri';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Rio Claro') where sig = 'fmangili';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Rio Claro') where sig = 'diogeneslyra';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Rio Claro') where sig = 'alexandreleite';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Rio Claro') where sig = 'tiagobruzasco';
update tusu set sig = 'jludmilla' where sig = 'jludmilla ';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Rio das Ostras') where sig = 'jludmilla ';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Rio das Ostras') where sig = 'Isilveira';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'lucascs';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'georg';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'rmarinho';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'rbatista';
update tusu set sig = 'filippoleite' where sig = ' filippoleite';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'filippoleite';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'modesto';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'breno';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'viviannribeiro';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'lleite';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'fbsilva';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'rodrigoaraujo';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'brunofarias';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'brenocarvalho';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'phcalm';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK RMR PE') where sig = 'jnunes';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Santa Gertrudes') where sig = 'Lrosseto';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Santa Gertrudes') where sig = 'Nfaustino';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Santa Gertrudes') where sig = 'choliveira';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Sumaré') where sig = 'Mferes';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Sumaré') where sig = 'Rlange';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Uruguaiana') where sig = 'hdantas';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Uruguaiana') where sig = 'joceleia';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Uruguaiana') where sig = 'mmjesus';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Uruguaiana') where sig = 'palhares';
update tusu set ideuniger = (select ideuni from tuni where sig = 'BRK Uruguaiana') where sig = 'jfernando';
