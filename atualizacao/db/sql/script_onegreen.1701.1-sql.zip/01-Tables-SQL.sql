

print ('CASO 15')
GO
/* Adicionando coluna de empresa na tabela de estados */
/*********************************************************/
/**********************   CASO 15  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160218-15')
BEGIN
	
/*==============================================================*/
  
	ALTER TABLE TESTPRV ADD IDEEMP DECIMAL(13) NULL

	/*==============================================================*/
	/* INDEX: TEMP2TESTPRV_FK                                       */
	/*==============================================================*/
	CREATE INDEX TEMP2TESTPRV_FK ON TESTPRV (
	IDEEMP ASC
	)

	ALTER TABLE TESTPRV
	   ADD CONSTRAINT TEMP2TESTPRV_FK FOREIGN KEY (IDEEMP)
		  REFERENCES TEMP (IDEEMP)
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160218-15', GETDATE())
END
GO


DECLARE @lIdeEmp DECIMAL(13)
BEGIN

	SELECT @lIdeEmp = IDEEMP 
	  FROM TTIPLICREGAMB
	 GROUP BY IDEEMP 


	  UPDATE TESTPRV SET IDEEMP = @lIdeEmp
	  UPDATE TWKF SET IDEEMP = @lIdeEmp

END
GO



print ('CASO 16')
GO
/* Criando Tabela de Atividades do licenciamento */
/*********************************************************/
/**********************   CASO 16  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160218-16')
BEGIN
	
/*==============================================================*/
  
	/*==============================================================*/
	/* TABLE: TATVEPRLICAMB                                         */
	/*==============================================================*/
	CREATE TABLE TATVEPRLICAMB (
	   IDEATVEPRLICAMB      DECIMAL(13)          IDENTITY(1110000000000,1),
	   IDEEPRLICAMB         DECIMAL(13)          NULL,
	   IDELICAMB            DECIMAL(13)          NULL,
	   IDEATVREGLICAMB      DECIMAL(13)          NOT NULL,
	   IDESIMFRM            DECIMAL(13)          NOT NULL,
	   DES                  NVARCHAR(150)        NOT NULL,
	   UPDTME               DATETIME             NOT NULL
	)

	ALTER TABLE TATVEPRLICAMB
	   ADD CONSTRAINT PK_TATVEPRLICAMB PRIMARY KEY (IDEATVEPRLICAMB)

	/*==============================================================*/
	/* INDEX: TATVREGLICAMB2TATVEPRLICAMB_FK                        */
	/*==============================================================*/
	CREATE INDEX TATVREGLICAMB2TATVEPRLICAMB_FK ON TATVEPRLICAMB (
	IDEATVREGLICAMB ASC
	)

	/*==============================================================*/
	/* INDEX: TSIMFRM2TATVEPRLICAMB_FK                              */
	/*==============================================================*/
	CREATE INDEX TSIMFRM2TATVEPRLICAMB_FK ON TATVEPRLICAMB (
	IDESIMFRM ASC
	)

	/*==============================================================*/
	/* INDEX: TEPRLICAMB2TATVEPRLICAMB_FK                           */
	/*==============================================================*/
	CREATE INDEX TEPRLICAMB2TATVEPRLICAMB_FK ON TATVEPRLICAMB (
	IDEEPRLICAMB ASC
	)

	/*==============================================================*/
	/* INDEX: TLICAMB2TATVEPRLICAMB_FK                              */
	/*==============================================================*/
	CREATE INDEX TLICAMB2TATVEPRLICAMB_FK ON TATVEPRLICAMB (
	IDELICAMB ASC
	)

	ALTER TABLE TATVEPRLICAMB
	   ADD CONSTRAINT TATVREGLICAMB2TATVEPRLICAMB_FK FOREIGN KEY (IDEATVREGLICAMB)
		  REFERENCES TATVREGLICAMB (IDEATVREGLICAMB)

	ALTER TABLE TATVEPRLICAMB
	   ADD CONSTRAINT TEPRLICAMB2TATVEPRLICAMB_FK FOREIGN KEY (IDEEPRLICAMB)
		  REFERENCES TEPRLICAMB (IDEEPRLICAMB)

	ALTER TABLE TATVEPRLICAMB
	   ADD CONSTRAINT TLICAMB2TATVEPRLICAMB_FK FOREIGN KEY (IDELICAMB)
		  REFERENCES TLICAMB (IDELICAMB)

	ALTER TABLE TATVEPRLICAMB
	   ADD CONSTRAINT TSIMFRM2TATVEPRLICAMB_FK FOREIGN KEY (IDESIMFRM)
		  REFERENCES TSIMFRM (IDESIMFRM)
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160218-16', GETDATE())
END
GO



print ('CASO 37')
GO
/* Adicionar campos na TTIPLICAMB para permitir Renova��o e Prazo Limite para Renova��o */
/*********************************************************/
/**********************   CASO 37  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160218-37')
BEGIN
	
/*==============================================================*/
  
   ALTER TABLE TTIPLICAMB ADD PMTRNV DECIMAL(1) NOT NULL DEFAULT 1
   
   ALTER TABLE TTIPLICAMB ADD PRZLMTRNV INT NULL
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160218-37', GETDATE())
END
GO



print ('CASO 45')
GO
/* Adicionar campo TLAINI na tabela TUSU para tela inicial por usu�rio */
/*********************************************************/
/**********************   CASO 45  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160218-45')
BEGIN
	
/*==============================================================*/
  
   ALTER TABLE TUSU ADD TLAINI DECIMAL(1) NULL 
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160218-45', GETDATE())
END
GO



print ('CASO 73')
GO

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160418-73')
BEGIN
	
/*==============================================================*/
  
UPDATE tRegSis SET CODINT = 'Criar e alterar Projetos / Empreendimentos de Licenciamento_Onegreen' where Nme = 'Criar e alterar Projetos / Empreendimentos de Licenciamento'
UPDATE tRegSis SET CODINT = 'Criar e alterar Licen�as Ambientais_Onegreen' where Nme = 'Criar e alterar Licen�as Ambientais'
UPDATE tRegSis SET CODINT = 'Criar e alterar Condicionantes das Licen�as_Onegreen' where Nme = 'Criar e alterar Condicionantes das Licen�as'
UPDATE tRegSis SET CODINT = 'Criar e alterar Estudos das Licen�as_Onegreen' where Nme = 'Criar e alterar Estudos das Licen�as'
UPDATE tRegSis SET CODINT = 'Aprovar solicita��es de licenciamento do Meio Ambiente_Onegreen' where Nme = 'Aprovar solicita��es de licenciamento do Meio Ambiente'
UPDATE tRegSis SET CODINT = 'Excluir/Alterar Execu��es e Excluir Coment�rios de Tarefas_Onegreen' where Nme = 'Excluir/Alterar Execu��es e Excluir Coment�rios de Tarefas'
UPDATE tRegSis SET CODINT = 'Desativar ou Reativar Tarefas_Onegreen' where Nme = 'Desativar ou Reativar Tarefas'
UPDATE tRegSis SET CODINT = 'Criar e alterar Tarefas das Licen�as_Onegreen' where Nme = 'Criar e alterar Tarefas das Licen�as'
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160418-73', GETDATE())
END
GO



print ('CASO 74')
GO

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160418-74')
BEGIN
	
/*==============================================================*/
  
UPDATE tlogace SET Prd = 'Onegreen' WHERE Prd = 'Sigma'
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160418-74', GETDATE())
END
GO



print ('CASO 76')
GO

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160419-76')
BEGIN
	
/*==============================================================*/
  
UPDATE tPlaAco SET Typ = 'PortalSIM.Domain.LicenciamentoAmbiental.PlanoDeAcaoDoOnegreen' WHERE Typ = 'PortalSIM.Domain.LicenciamentoAmbiental.PlanoDeAcaoDoSigma'
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160419-76', GETDATE())
END
GO



print ('CASO 78')
GO

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160425-78')
BEGIN
	
/*==============================================================*/
  
UPDATE tCfgSetIte SET Vlr = 'OnegreenRoute' where Chv = 'DefaultRoute'
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160425-78', GETDATE())
END
GO



print ('CASO 79')
GO

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160427-79')
BEGIN
	
/*==============================================================*/
  
UPDATE tMod SET ModNme = 'Onegreen' where ModNme = 'SIGMA'
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160427-79', GETDATE())
END
GO



/*********************************************************/
/*********************** CASO 102 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 102'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160520-102')
BEGIN

	IF EXISTS (SELECT 1
					 FROM SYSCOLUMNS
					WHERE ID = OBJECT_ID('TLOGACE')
					  AND UPPER(NAME) = 'IDNSEC')
	BEGIN
		
		EXEC SP_DROPCOLUMN 'TLOGACE', 'IDNSEC'

	END


	IF EXISTS (SELECT 1
					 FROM SYSCOLUMNS
					WHERE ID = OBJECT_ID('TLOGACE')
					  AND UPPER(NAME) = 'INPUSU')
	BEGIN
			
		EXEC SP_DROPCOLUMN 'TLOGACE', 'INPUSU'

	END
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160520-102', GETDATE())
END
GO



/*********************************************************/
/*********************** CASO 104 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 104'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160520-104')
BEGIN

	IF EXISTS (SELECT 1
			FROM  SYSCOLUMNS
			WHERE  ID = OBJECT_ID('TATVREGLICAMB')
			AND UPPER(NAME) = 'IDEPRTLICAMB'
			AND ISNULLABLE = 0)
	BEGIN
		IF EXISTS (SELECT 1
				FROM DBO.SYSREFERENCES R JOIN DBO.SYSOBJECTS O ON (O.ID = R.CONSTID AND O.TYPE = 'F')
				WHERE R.FKEYID = OBJECT_ID('TATVREGLICAMB') AND O.NAME = 'TPRTLICAMB2TATVREGLICAMB_FK')
			ALTER TABLE TATVREGLICAMB DROP CONSTRAINT TPRTLICAMB2TATVREGLICAMB_FK
		
		IF EXISTS (SELECT 1
				 FROM SYSINDEXES
				WHERE ID    = OBJECT_ID('TATVREGLICAMB')
				  AND NAME  = 'TPRTLICAMB2TATVREGLICAMB_FK'
				  AND INDID > 0
				  AND INDID < 255)
			DROP INDEX TATVREGLICAMB.TPRTLICAMB2TATVREGLICAMB_FK

		EXEC SP_MODIFYCOLUMN 'TATVREGLICAMB','IDEPRTLICAMB','DECIMAL(13)',0, 'NULL'

		EXEC('CREATE INDEX TPRTLICAMB2TATVREGLICAMB_FK ON TATVREGLICAMB (
				IDEPRTLICAMB ASC
				)')
		
		EXEC('ALTER TABLE TATVREGLICAMB
				   ADD CONSTRAINT TPRTLICAMB2TATVREGLICAMB_FK FOREIGN KEY (IDEPRTLICAMB)
					  REFERENCES TPRTLICAMB (IDEPRTLICAMB)')
	END
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160520-104', GETDATE())
END
GO



/*********************************************************/
/*********************** CASO 109 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 109'
END
GO

DECLARE @lIdeWkfAtv		DECIMAL(13),
		@lIdeWkfAtvNxt	DECIMAL(13)
BEGIN

	IF NOT EXISTS (SELECT 1
					 FROM TSQLUPD
					WHERE COD = '20160524-109')
	BEGIN

		IF NOT EXISTS (select 1 from twkfaca where msgcnf = 'Deseja realmente reativar o projeto?')
		BEGIN

			UPDATE TWKFATV SET TYP = 'PortalSIM.Domain.WorkflowFx.Tarefa' 
			 WHERE IDEWKFATV = (SELECT ATV.IDEWKFATV
								  FROM TWKFATV ATV
								 INNER JOIN TWKFFAS FAS ON FAS.IDEWKFFAS = ATV.IDEWKFFAS
								 INNER JOIN TWKF WKF ON WKF.IDEWKF = FAS.IDEWKF
								 WHERE TYPTIP = 'PortalSIM.Domain.LicenciamentoAmbiental.Empreendimento'
								   AND ATV.NME = 'Cancelamento')

			SELECT @lIdeWkfAtv = ATV.IDEWKFATV
			  FROM TWKFATV ATV
			 INNER JOIN TWKFFAS FAS ON FAS.IDEWKFFAS = ATV.IDEWKFFAS
			 INNER JOIN TWKF WKF ON WKF.IDEWKF = FAS.IDEWKF
			 WHERE TYPTIP = 'PortalSIM.Domain.LicenciamentoAmbiental.Empreendimento'
			   AND ATV.NME = 'Cancelamento'

			SELECT @lIdeWkfAtvNxt = ATV.IDEWKFATV
			  FROM TWKFATV ATV
			 INNER JOIN TWKFFAS FAS ON FAS.IDEWKFFAS = ATV.IDEWKFFAS
			 INNER JOIN TWKF WKF ON WKF.IDEWKF = FAS.IDEWKF
			 WHERE TYPTIP = 'PortalSIM.Domain.LicenciamentoAmbiental.Empreendimento'
			   AND ATV.NME = 'Elaborar Empreendimento'

		   
			INSERT INTO TWKFACA (IDEWKFATV,IDEWKFATVNXT,ORD,NME,MSGCNF,ACERES,ICOLFT,ICORGT,BTNCSS,UPDTME,DES,EXGJUS,NMEEXB,RTADET,ACEVERESTVAL) 
						 VALUES (@lIdeWkfAtv, @lIdeWkfAtvNxt, 0, 'Reativar', 'Deseja realmente reativar o projeto?', NULL, 'icon-chevron-right icon-white', NULL, 'btn-danger', getdate(), 'Reativar', 0, NULL, NULL, 'ValidarUsuarioRequisitante')


			UPDATE TWKFACA SET RTADET = '{"Area":"Onegreen","Controller":"SolicitacoesDeLicenciamento","Action":"AoAprovarUmaSolicitacaoDeLicenciamento"}' WHERE UPPER(NME) LIKE 'APROVAR SOLICITAÇÃO'

		END
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160524-109', GETDATE())

	END
END
GO

print ('CASO 119')
GO
/* Adicionando coluna de valor previsto na tabela de estudos da licença */
/*********************************************************/
/**********************   CASO 119  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160628-119')
BEGIN
	
/*==============================================================*/
  
	ALTER TABLE TESTLICAMB ADD VALPRE FLOAT NULL
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160628-119', GETDATE())
END
GO

IF EXISTS (SELECT 1
			 FROM TESTLICAMB
		    WHERE VALPRE IS NULL)
BEGIN
	UPDATE TESTLICAMB SET VALPRE = VAL WHERE VALPRE IS NULL
END
GO

/*********************************************************/
/*********************** CASO 130 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 130'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160823-130')
BEGIN

	IF EXISTS (SELECT 1
					 FROM SYSCOLUMNS
					WHERE ID = OBJECT_ID('TIDS')
					  AND UPPER(NAME) = 'UPDTME')
	BEGIN
		EXEC SP_MODIFYCOLUMN 'tIds','UpdTme','datetime', 0, 'null'
	END
	ELSE
	BEGIN
		ALTER TABLE TIDS ADD UPDTME DATETIME NULL
	END
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160823-130', GETDATE())
END
GO



/*********************************************************/
/*********************** CASO 133 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 133'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160913-133')
BEGIN

	DROP INDEX TATVREGLICAMB.TPRTLICAMB2TATVREGLICAMB_FK

	ALTER TABLE TATVREGLICAMB DROP CONSTRAINT TPRTLICAMB2TATVREGLICAMB_FK

	EXEC SP_MODIFYCOLUMN 'TATVREGLICAMB','IDEPRTLICAMB','DECIMAL(13)', 0, 'null'

	create index TPRTLICAMB2TATVREGLICAMB_FK on TATVREGLICAMB (
		IDEPRTLICAMB ASC
	)

	ALTER TABLE TATVREGLICAMB ADD CONSTRAINT TPRTLICAMB2TATVREGLICAMB_FK FOREIGN KEY (IDEPRTLICAMB) REFERENCES TPRTLICAMB(IDEPRTLICAMB)
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160913-133', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 137 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 137'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-137')
BEGIN

	ALTER TABLE TDOCVIN DROP CONSTRAINT FK_TDOCVIN_TUNIPLAGE_TUNIPLAG

	ALTER TABLE TCICAVLDES DROP CONSTRAINT TPLAGES2TCICAVLDES_FK
	
	ALTER TABLE TPGRRST DROP CONSTRAINT TPLAGES2TPGRRST_FK
	
	DROP INDEX TPGRRST.TPLAGES2TPGRRST_FK
	
	ALTER TABLE TVIS DROP CONSTRAINT TPLAGES2TVIS_FK
	
	DROP INDEX TVIS.TPLAGES2TVIS_FK
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-137', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 138 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 138'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-138')
BEGIN

	ALTER TABLE TVIS DROP COLUMN IDEPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-138', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 140 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 140'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-140')
BEGIN

	DROP INDEX TPRMRELFAR.TPLAGES2TPRMRELFAR_FK

	ALTER TABLE TPRMRELFAR DROP COLUMN IDEPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-140', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 141 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 141'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-141')
BEGIN

	DROP INDEX TPLAGESTIPACOIND.TPLAGES2TPLAGESTIPACOIND_FK

	ALTER TABLE TPLAGESTIPACOIND DROP COLUMN IDEPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-141', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 142 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 142'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-142')
BEGIN

	DROP INDEX TPLAGESOBJEST.TPLAGES2TPLAGESOBJEST_FK

	ALTER TABLE TPLAGESOBJEST DROP COLUMN IDEPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-142', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 143 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 143'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-143')
BEGIN

	DROP INDEX TPLAGESNTAREMVAR.TPLAGES2TPLAGESNTAREMVAR_FK

	ALTER TABLE TPLAGESNTAREMVAR DROP COLUMN IDEPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-143', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 144 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 144'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-144')
BEGIN

	DROP INDEX TPGRRST.TPGRRST2TGRUUSU_FK

	ALTER TABLE TPGRRST DROP COLUMN IDEPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-144', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 145 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 145'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-145')
BEGIN

	DROP INDEX TPAGMNU.TPLAGES2TPAGMNU_FK

	ALTER TABLE TPAGMNU DROP COLUMN IDEPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-145', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 146 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 146'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-146')
BEGIN

	ALTER TABLE TMAP DROP COLUMN IDEPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-146', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 147 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 147'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-147')
BEGIN

	ALTER TABLE TLOGSNC DROP COLUMN IDEPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-147', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 148 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 148'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-148')
BEGIN
	
	DROP INDEX TINDPLAGESNTAREMVAR.TPLAGES2TINDPLAGESNTAREMVAR_FK

	ALTER TABLE TINDPLAGESNTAREMVAR DROP COLUMN IDEPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-148', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 149 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 149'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-149')
BEGIN

	DROP INDEX TDTAMNG.TPLAGES2TDTAMNG_FK

	ALTER TABLE TDTAMNG DROP COLUMN IDEPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-149', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 150 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 150'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-150')
BEGIN

	ALTER TABLE TCICAVLDES DROP COLUMN IDEPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-150', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 151 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 151'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160926-151')
BEGIN
	
	DROP INDEX TDOCVIN.TUNIPLAGES2TDOCVIN_FK

	ALTER TABLE TDOCVIN DROP COLUMN IDEUNIPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160926-151', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 155 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 155'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160930-155')
BEGIN
	DECLARE @lOrd INT
	BEGIN

		SELECT @lOrd = MAX(ORD) + 1
		  FROM TREGSIS
		 WHERE TIP = 1
		 
		INSERT INTO TREGSIS (IDEMOD, CODINT, NME, ORD, TIP, UPDTME)
			 SELECT IDEMOD, 'Alterar Metas nos Gr�ficos', 'Alterar Metas nos Gr�ficos', @lOrd, 1, GETDATE()
			   FROM TMOD
			  WHERE MODNME = 'Onegreen'

	END	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160930-155', GETDATE())
END
GO



/*********************************************************/
/*********************** CASO 173 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 173'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20161019-173')
BEGIN
	
/*==============================================================*/
  
	ALTER TABLE TUNI ADD IDEFLESYS DECIMAL(13) NULL

	/*==============================================================*/
	/* INDEX: TFLESYS2TUNI_FK                                       */
	/*==============================================================*/
	CREATE INDEX TFLESYS2TUNI_FK ON TUNI (
		IDEFLESYS ASC
	)

	ALTER TABLE TUNI
	   ADD CONSTRAINT TFLESYS2TUNI_FK FOREIGN KEY (IDEFLESYS)
		  REFERENCES TFLESYS (IDEFLESYS)
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20161019-173', GETDATE())
END
GO

UPDATE TUNI SET IDEFLESYS = PLAGES.IDEFLESYS FROM
	(SELECT IDEFLESYS, IDEUNI 
		FROM TUNIPLAGES) PLAGES
	WHERE TUNI.IDEUNI = PLAGES.IDEUNI



/*********************************************************/
/*********************** CASO 159 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 159'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20161020-159')
BEGIN

	DROP INDEX TACO.TPLAGES2TACO_FK

	DROP INDEX TACO.TACO_X1

	ALTER TABLE TACO DROP COLUMN IDEPLAGES
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20161020-159', GETDATE())
	
END
GO

print ('CASO 168')
GO

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20161208-168')
BEGIN
	
/*==============================================================*/
  
UPDATE TDOCLICAMB SET DES = DOCVIN.DES FROM(SELECT IDEFLESYS, DES FROM TDOCVIN) DOCVIN WHERE TDOCLICAMB.IDEFLESYS = DOCVIN.IDEFLESYS
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20161208-168', GETDATE())
END
GO

 
/*********************************************************/
/*********************** CASO 186 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 186'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170130-186')
BEGIN

	ALTER TABLE TLICAMB ADD CSTMAN DECIMAL(1) NOT NULL DEFAULT 0
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170130-186', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 194 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 194'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20161231-194')
BEGIN

	DECLARE cUnidades CURSOR FOR SELECT uni.IDEUNI,uni.IDESPR,uni.IDEUSU,uni.SIG,uni.NME,uni.IDEFLESYS 
								   FROM TUNIPLAGES uni 
								  INNER JOIN TPLAGES GES ON UNI.IDEPLAGES = GES.IDEPLAGES
								  WHERE GES.EXR = (SELECT MAX(EXR) 
													 FROM TPLAGES 
													WHERE TPLAGES.EXR <= DATEPART(YEAR, GETDATE()) 
								    AND IDEEMP = (SELECT IDEEMP FROM TTIPLICREGAMB GROUP BY IDEEMP)
									AND ATV <>  0)


    DECLARE @lIdeUni	decimal(13),
			@lIdeSpr	decimal(13),
			@lIdeUsu	decimal(13),
			@lIdeFleSys	decimal(13),
			@lSig		nvarchar(100),
			@lNme		nvarchar(100)
		
	
  
	OPEN cUnidades
	FETCH NEXT FROM cUnidades INTO @lIdeUni,@lIdeSpr,@lIdeUsu,@lSig,@lNme,@lIdeFleSys
	WHILE @@FETCH_STATUS = 0
	BEGIN 
		
		UPDATE TUNI SET IDESPR = @lIdeSpr, IDEUSU = @lIdeUsu, IDEFLESYS = @lIdeFleSys, SIG = @lSig, NME = @lNme WHERE IDEUNI = @lIdeUni
		
		FETCH NEXT FROM cUnidades INTO @lIdeUni,@lIdeSpr,@lIdeUsu,@lSig,@lNme,@lIdeFleSys
	END
	
	UPDATE TLICAMB set CSTMAN = 1

	CLOSE cUnidades
	DEALLOCATE cUnidades

	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20161231-194', GETDATE())
END
GO
	
	
/*==============================================================*/
/* ATUALIZA��O DA VERS�O DO BANCO DE DADOS                      */
/*==============================================================*/

DECLARE @LVERSION DATETIME,
		@VERSAO   NVARCHAR(10)
SET @LVERSION = CAST('20170201' AS DATETIME)
SET @VERSAO = '1701.1'
IF EXISTS(SELECT VRS FROM TVRS WHERE VRS = @LVERSION AND NUMVRS = @VERSAO)
   UPDATE TVRS SET DTATBL = GETDATE() WHERE VRS = @LVERSION AND NUMVRS = @VERSAO;
ELSE
    INSERT INTO TVRS (VRS, DTATBL , NUMVRS) VALUES (@LVERSION, GETDATE() , @VERSAO);
GO

BEGIN
PRINT '1701.1'
END
GO

