IF EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[ATIVIDADES_ResumoDasTarefas]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ATIVIDADES_ResumoDasTarefas]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* Fun��o     : [ATIVIDADES_ResumoDasTarefas]
   Prop�sito  : Retorna os Status das Tarefas sob a Responsabilidade de uma Unidade Gerencial e/ou suas subordinadas at� o 3o n�vel
   Par�metros : pIdeUni-Identificador da Unidade Gerencial
                pSub-Indica se o relat�rio deve retornar dados apenas da UG selecionada ou de suas subordinadas at� o 3o n�vel
                pIdePlaGes-Identificador do Plano de Gest�o corrente
                pIdePlaGesFiltro-Identificador do Plano de Gest�o selecionado no filtro (pode ser nulo)
                pPerPrevIni-Per�odo de In�cio para filtar a Data de fim previsto definido pelo Usu�rio (pode ser nulo)
                pPerPrevFin-Per�odo de T�rmino  para filtar a Data de fim previsto definido pelo usu�rio (pode ser nulo)
				pPerReaIni-Per�odo de In�cio para filtar a Data de fim realizado definido pelo Usu�rio (pode ser nulo)
                pPerReaFin-Per�odo de T�rmino  para filtar a Data de fim realizado definido pelo usu�rio (pode ser nulo)
                pIdeUsu-Identificador do Usu�rio respons�vel pelas Solu��es de Problema ou pelas A��es
                pIdeTipAgd-Tipo de Agendamento sob o qual ser� feita a pesquisa
				pCls-Classifica��o sob as quais ser� feita a pesquisa
				pIdeUsuLogado-Identificador do Usu�rio Logado para saber quais unidades o mesmo possui acesso
				pExcel-Indica se o relat�rio � para gera��o de Excel
				pSistema-Indica para qual sistema o relat�rio ser� emitido

   Cria��o    : 21/09/2015*/

CREATE PROCEDURE [dbo].[ATIVIDADES_ResumoDasTarefas](
	@pIdeUni					DECIMAL(13),
	@pSub						INT,
	@pIdePlaGes					DECIMAL(13),
	@pPerIni					DATETIME,
	@pPerFin					DATETIME,
	@pIdeUsu					DECIMAL(13),
	@pIdeUsuLogado				DECIMAL(13),
	@pIdeEprLicAmb				DECIMAL(13),
	@pIdeLegAmb					DECIMAL(13),
	@pIdeTipLicRegAmb			DECIMAL(13),
	@pIdeTipLicAmb				DECIMAL(13),
	@pExcel						INT,
	@exibirCronogramaDeProjeto	INT,
	@exibirCondicionantes		INT,
	@exibirOrientacoes			INT,
	@exibirProgramasAmbientais	INT,
	@exibirCompensatorias		INT,
	@exibirNotificacoes 		INT
) 
AS
	DECLARE
		@lLvl							INT,
		@lHoje							VARCHAR(50),
		@proximoAno						VARCHAR(50),
		@lPerIni						DATETIME,
        @lPerFin						DATETIME,
		@lStrQuery						VARCHAR(8000),
        @lCondicaoEmpreendimentos		VARCHAR(1000),
        @lCondicaoLicencas				VARCHAR(1000),

		@lOrd							INT,
		@lSig							VARCHAR(50),
		@lIdeUni						DECIMAL(13),
		@id								INT,
        @lCriados						INT,
		@lPlanejadasNoPrazo				INT,
		@lPlanejadasAtrasada			INT,
		@lEmExecucaoNoPrazo				INT,
		@lEmExecucaoAtrasada			INT,
		@lFinalizadaNoPrazo				INT,
		@lFinalizadaAtrasada			INT,

		@lCalculoSubtotal				INT,
		@lTotalCriados					INT,
		@lTotalPlanejadasNoPrazo		INT,
		@lTotalPlanejadasAtrasada		INT,
		@lTotalEmExecucaoNoPrazo		INT,
		@lTotalEmExecucaoAtrasada		INT,
		@lTotalFinalizadaNoPrazo		INT,
		@lTotalFinalizadaAtrasada		INT,

		@lSubTotalCriados				INT,
		@lSubTotalPlanejadasNoPrazo		INT,
		@lSubTotalPlanejadasAtrasada	INT,
		@lSubTotalEmExecucaoNoPrazo		INT,
		@lSubTotalEmExecucaoAtrasada	INT,
		@lSubTotalFinalizadaNoPrazo		INT,
		@lSubTotalFinalizadaAtrasada	INT,
		
		@lError							INT

	DECLARE @Dados TABLE (	ORD                    INT, 
							NMEUSU                 VARCHAR(100),
							IDEUSU                 DECIMAL(13),
							SIG                    VARCHAR(75),
							IDEUNI                 DECIMAL(13),
							Criadas                INT, 
							PlanejadasNoPrazo      INT,
							PlanejadasAtrasada     INT,
							EmExecucaoNoPrazo      INT,
							EmExecucaoAtrasada     INT, 
							FinalizadaNoPrazo      INT, 
							FinalizadaAtrasada     INT)
BEGIN
    SET NOCOUNT ON
	SET @lPerIni = NULL
    SET @lPerFin = NULL
	
    SET @lCondicaoLicencas = ''
	SET @lCondicaoEmpreendimentos = ''
	SET @lHoje = 'CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), GETDATE(), 121) + ''', 121)'
	SET @proximoAno =  CONVERT(VARCHAR, CAST(DATEPART(YEAR , GETDATE()) + 1  AS VARCHAR(4)) + '-01-01', 121)
	
	IF @pSub = 0 OR @pIdeUni IS NULL
        SET @lLvl = 1
    ELSE
        SET @lLvl = 3

	IF NOT @pPerIni IS NULL
        SET @lPerIni = @pPerIni

    IF NOT @pPerFin IS NULL
        SET @lPerFin = @pPerFin 

		IF NOT @pIdeEprLicAmb IS NULL
		SET @lCondicaoEmpreendimentos = @lCondicaoEmpreendimentos +
			' AND TEPRLICAMB.IDEEPRLICAMB = ' + CAST(@pIdeEprLicAmb AS VARCHAR(13))	
		
	IF NOT @pIdeLegAmb IS NULL
		SET @lCondicaoEmpreendimentos = @lCondicaoEmpreendimentos +
			' AND TEPRLICAMB.IDELEGAMB = ' + CAST(@pIdeLegAmb AS VARCHAR(13))
		
	IF NOT @pIdeTipLicRegAmb IS NULL
		SET @lCondicaoEmpreendimentos = @lCondicaoEmpreendimentos +
			' AND TEPRLICAMB.IDETIPLICREGAMB = ' + CAST(@pIdeTipLicRegAmb AS VARCHAR(13))
	
	IF NOT @pIdeTipLicAmb IS NULL
		SET @lCondicaoLicencas = @lCondicaoLicencas +
			' AND VPLAACOINF.IDETIPLICAMB = '+ CAST(@pIdeTipLicAmb AS VARCHAR(13))
			
	SET @lStrQuery = 
		'SELECT
			VUNIARV.ORD,
			VUNIARV.SIG,
			VUNIARV.IDEUNI,
			VUNIARV.LVL,
			COUNT(VPACTAR.IDEPACTAR) Criadas,

			SUM (
				CASE
					WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE >= ' + @lHoje + ' THEN
						1
					ELSE 
						0
					END
			) PlanejadasNoPrazo,

			SUM (
				CASE
					WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE < ' + @lHoje + ' THEN
						1
					ELSE 
						0
					END
			) PlanejadasAtrasada,

			SUM (
				CASE
					WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (dbo.PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, GETDATE())) <= VPACTAR.PERCON THEN 
						1
					ELSE
						0
					END
			) EmExecucaoNoPrazo,

			SUM (
				CASE
					WHEN VPACTAR.INIREA IS NOT NULL AND  VPACTAR.FIMREA IS NULL AND  (dbo.PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, GETDATE())) > VPACTAR.PERCON THEN 
						1
					ELSE 
						0
					END
			) EmExecucaoAtrasada,

			SUM(
				CASE
					WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA <= VPACTAR.FIMPRE THEN 
						1
					ELSE 
						0
					END
			) FinalizadaNoPrazo,

			SUM(
				CASE
					WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA > VPACTAR.FIMPRE THEN 
						1
					ELSE 
						0
					END
			) FinalizadaAtrasada '
	
	IF NOT @pIdeUni IS NULL
		BEGIN
				SET @lStrQuery = @lStrQuery + 
				' FROM (
						SELECT 
							LUNI.* 
						FROM 
							dbo.DefinirArvoreSubordinadas(' + CAST(@pIdeUni AS VARCHAR(13)) + ', ' + CAST(@pIdePlaGes AS VARCHAR(13)) + ') LUNI 
						INNER JOIN (
								SELECT 
									IDEUNI 
								FROM 
									dbo.RetornarUnidadesPorUsuario(' + CAST(@pIdeUsuLogado AS VARCHAR(13)) + ', ' + CAST(@pIdePlaGes AS VARCHAR(13)) + ')
							) TUSUUNI ON LUNI.IDEUNI = TUSUUNI.IDEUNI WHERE LVL <= ' + CAST(@lLvl AS VARCHAR) + ' 
						) VUNIARV '
		END
	ELSE
		BEGIN
			SET @lStrQuery = @lStrQuery + 
				' FROM (
						SELECT 
							UNIUSU.*, 
							0 LVL 
						FROM 
							dbo.RetornarUnidadesPorUsuario(' + CAST(@pIdeUsuLogado AS VARCHAR(13)) + ', ' +  CAST(@pIdePlaGes AS VARCHAR(13)) + ') UNIUSU
						) VUNIARV'
		END
	
	SET @lStrQuery = @lStrQuery + 
	'  	INNER JOIN 
			(
					SELECT 
						NULL IDETIPLICAMB,
						TEPRLICAMB.IDEPLAACO, 
						NULL IDEPLAACONTF, 
						NULL IDEPLAACOCMP, 
						NULL IDEPLAACOPRGAMB, 
						NULL IDEPLAACOCND, 
						NULL IDEPLAACOORIBAS, 
						IDEUNI 
					FROM TEPRLICAMB
						WHERE TEPRLICAMB.IDEUNI IS NOT NULL ' + @lCondicaoEmpreendimentos + '
				UNION 
					SELECT 
						TLICAMB.IDETIPLICAMB, 
						NULL IDEPLAACO, 
						TLICAMB.IDEPLAACONTF, 
						TLICAMB.IDEPLAACOCMP, 
						TLICAMB.IDEPLAACOPRGAMB, 
						TLICAMB.IDEPLAACOCND, 
						TLICAMB.IDEPLAACOORIBAS, 
						IDEUNI 
					FROM TLICAMB 
						INNER JOIN TEPRLICAMB ON TLICAMB.IDEEPRLICAMB = TEPRLICAMB.IDEEPRLICAMB
						' + @lCondicaoEmpreendimentos + '
			) VPLAACOINF 
				ON VPLAACOINF.IDEUNI = VUNIARV.IDEUNI
						' + @lCondicaoLicencas + '
		LEFT JOIN TPLAACO 
			ON	(
					' + CAST(@exibirCronogramaDeProjeto AS VARCHAR(13)) + '  <> 0 AND
					TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACO
				)
				OR
				(
					' + CAST(@exibirNotificacoes AS VARCHAR(13)) + '  <> 0 AND
					TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACONTF
				)
				OR 
				(
					' + CAST(@exibirCompensatorias AS VARCHAR(13)) + ' <> 0 AND
					TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOCMP	
				)
				OR 
				(
					' + CAST(@exibirProgramasAmbientais AS VARCHAR(13)) + ' <> 0 AND
					TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOPRGAMB	
				)
				OR 
				(
					' + CAST(@exibirOrientacoes AS VARCHAR(13)) + ' <> 0 AND
					TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOORIBAS	
				)
				OR 
				(
					' + CAST(@exibirCondicionantes AS VARCHAR(13)) + ' <> 0 AND
					TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOCND	
				) '
		
	SET @lStrQuery = @lStrQuery + 
		' LEFT JOIN (SELECT
					TPACTAR.IDEPLAACO,
					TPACTAR.IDEPACTAR,
					TPACTAR.IDEFER,
					TPACTAR.ACAREC,
					TPACTAR.IDEUSURES,
					TPACTAR.INIPRE,
					TPACTAR.INIREA,
					TPACTAR.FIMPRE,
					TPACTAR.FIMREA,
					TPACTAR.PRXEXCREC,
					TPACTAR.FREREC,
					TPACTAR.DURHRA,
					TPACTAR.PERCON
				FROM TPACTAR
				WHERE TPACTAR.DEL = 0 '
		

	IF @pPerIni IS NOT NULL AND @pPerFin IS NOT NULL
		SET @lStrQuery = @lStrQuery + 
			' AND 
				(
					TPACTAR.INIPRE <= CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), @pPerFin, 121) + ''', 121) AND TPACTAR.FIMPRE >=  CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), @pPerIni, 121) + ''', 121)
				) '
    
	IF NOT @pIdeUsu IS NULL
		SET @lStrQuery = @lStrQuery + 
			' AND TPACTAR.IDEUSURES = ' + CAST(@pIdeUsu AS VARCHAR(13))

	SET @lStrQuery = @lStrQuery + 
				' 
					GROUP BY	TPACTAR.IDEPACTAR,
							TPACTAR.IDEFER,
							TPACTAR.ACAREC,
							TPACTAR.IDEUSURES,
							TPACTAR.INIPRE,
							TPACTAR.INIREA,
							TPACTAR.FIMPRE,
							TPACTAR.FIMREA,
							TPACTAR.PRXEXCREC,
							TPACTAR.IDEPLAACO,
							TPACTAR.FREREC,
							TPACTAR.DURHRA,
							TPACTAR.PERCON) VPACTAR
					ON TPLAACO.IDEPLAACO = VPACTAR.IDEPLAACO
				GROUP BY	VUNIARV.SIG,
							VUNIARV.IDEUNI,
							VUNIARV.ORD,
							VUNIARV.LVL
				ORDER BY VUNIARV.ORD, VUNIARV.SIG'
	
    SET @lStrQuery = 'DECLARE CursorRelatorio CURSOR GLOBAL FAST_FORWARD READ_ONLY FOR ' + @lStrQuery
	
	EXEC(@lStrQuery)

	SELECT @lError = @@ERROR
	
	IF @lError <> 0
		BEGIN
			GOTO erroResumoDasTarefas	
		END

    SET @lCalculoSubtotal = 0
    SET @id = 1
	SET @lTotalCriados = 0
    SET @lTotalPlanejadasNoPrazo = 0
	SET @lTotalPlanejadasAtrasada = 0
	SET @lTotalEmExecucaoNoPrazo = 0
	SET @lTotalEmExecucaoAtrasada = 0
	SET @lTotalFinalizadaNoPrazo = 0
	SET @lTotalFinalizadaAtrasada = 0

    SET @lSubTotalCriados = 0
    SET @lSubTotalPlanejadasNoPrazo = 0
	SET @lSubTotalPlanejadasAtrasada = 0
	SET @lSubTotalEmExecucaoNoPrazo = 0
	SET @lSubTotalEmExecucaoAtrasada = 0
	SET @lSubTotalFinalizadaNoPrazo = 0
	SET @lSubTotalFinalizadaAtrasada = 0

	OPEN CursorRelatorio
		FETCH CursorRelatorio INTO @lOrd, @lSig, @lIdeUni, @lLvl, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada

	WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @lLvl = 2
				BEGIN
					IF @lCalculoSubtotal = 2  AND @pExcel = 0
						BEGIN
			                SET @id = @id + 1
							INSERT @Dados (ORD, SIG, IDEUNI, Criadas, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@id + 1, '      Subtotal', -2, @lSubTotalCriados, @lSubTotalPlanejadasNoPrazo, @lSubTotalPlanejadasAtrasada, @lSubTotalEmExecucaoNoPrazo, @lSubTotalEmExecucaoAtrasada, @lSubTotalFinalizadaNoPrazo, @lSubTotalFinalizadaAtrasada)
						END
					SET @lCalculoSubtotal = 1   
					SET @lSubTotalCriados = @lCriados
					SET @lSubTotalPlanejadasNoPrazo = @lPlanejadasNoPrazo
					SET @lSubTotalPlanejadasAtrasada = @lPlanejadasAtrasada
					SET @lSubTotalEmExecucaoNoPrazo = @lEmExecucaoNoPrazo
					SET @lSubTotalEmExecucaoAtrasada = @lEmExecucaoAtrasada
					SET @lSubTotalFinalizadaNoPrazo = @lFinalizadaNoPrazo
					SET @lSubTotalFinalizadaAtrasada = @lFinalizadaAtrasada 
					SET @id = @id + 1	
				END
	        ELSE IF @lLvl = 3
				BEGIN
					SET @lCalculoSubtotal = 2   
					SET @lSubTotalCriados = @lSubTotalCriados + @lCriados
					SET @lSubTotalPlanejadasNoPrazo = @lSubTotalPlanejadasNoPrazo + @lPlanejadasNoPrazo
					SET @lSubTotalPlanejadasAtrasada = @lSubTotalPlanejadasAtrasada + @lPlanejadasAtrasada
					SET @lSubTotalEmExecucaoNoPrazo = @lSubTotalEmExecucaoNoPrazo + @lEmExecucaoNoPrazo
					SET @lSubTotalEmExecucaoAtrasada = @lSubTotalEmExecucaoAtrasada + @lEmExecucaoAtrasada
					SET @lSubTotalFinalizadaNoPrazo = @lSubTotalFinalizadaNoPrazo + @lFinalizadaNoPrazo
					SET @lSubTotalFinalizadaAtrasada = @lSubTotalFinalizadaAtrasada + @lFinalizadaAtrasada 
				END

			SET @lTotalCriados = @lTotalCriados + @lCriados
			SET @lTotalPlanejadasNoPrazo = @lTotalPlanejadasNoPrazo + @lPlanejadasNoPrazo
			SET @lTotalPlanejadasAtrasada = @lTotalPlanejadasAtrasada + @lPlanejadasAtrasada
			SET @lTotalEmExecucaoNoPrazo = @lTotalEmExecucaoNoPrazo + @lEmExecucaoNoPrazo
			SET @lTotalEmExecucaoAtrasada = @lTotalEmExecucaoAtrasada + @lEmExecucaoAtrasada
			SET @lTotalFinalizadaNoPrazo = @lTotalFinalizadaNoPrazo + @lFinalizadaNoPrazo
			SET @lTotalFinalizadaAtrasada = @lTotalFinalizadaAtrasada + @lFinalizadaAtrasada 
			SET @id = @id + 1
			
			INSERT @Dados (ORD, SIG, IDEUNI, Criadas, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@id + 1, @lSig, @lIdeUni, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada)
			FETCH CursorRelatorio INTO @lOrd, @lSig, @lIdeUni, @lLvl, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada
		END

	CLOSE CursorRelatorio
	DEALLOCATE CursorRelatorio

    SET @id = @id + 1

	IF (@pSub <> 0 AND @pExcel = 0) OR @pIdeUni IS NULL
    BEGIN
        IF @lCalculoSubtotal = 2
            INSERT @Dados (ORD, SIG, IDEUNI, Criadas, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@id + 1, '      Subtotal', -2, @lSubTotalCriados, @lSubTotalPlanejadasNoPrazo, @lSubTotalPlanejadasAtrasada, @lSubTotalEmExecucaoNoPrazo, @lSubTotalEmExecucaoAtrasada, @lSubTotalFinalizadaNoPrazo, @lSubTotalFinalizadaAtrasada)

        INSERT @Dados (ORD, SIG, IDEUNI, Criadas, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@id + 2, 'Total', -1, @lTotalCriados, @lTotalPlanejadasNoPrazo, @lTotalPlanejadasAtrasada, @lTotalEmExecucaoNoPrazo, @lTotalEmExecucaoAtrasada, @lTotalFinalizadaNoPrazo, @lTotalFinalizadaAtrasada)
    END

    SELECT  NEWID() Id, * FROM @Dados

	erroResumoDasTarefas:
END

GO


IF EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[ATIVIDADES_ResumoDasTarefasPorUsuario]') AND type IN (N'P', N'PC')) 
DROP PROCEDURE [dbo].[ATIVIDADES_ResumoDasTarefasPorUsuario]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[ATIVIDADES_ResumoDasTarefasPorUsuario](
	@pIdeUni					DECIMAL(13),
	@pSub						INT,
	@pIdePlaGes					DECIMAL(13),
	@pPerIni					DATETIME,
	@pPerFin					DATETIME,
	@pIdeUsu					DECIMAL(13),
	@pIdeUsuLogado				DECIMAL(13),
	@pIdeEprLicAmb				DECIMAL(13),
	@pIdeLegAmb					DECIMAL(13),
	@pIdeTipLicRegAmb			DECIMAL(13),
	@pIdeTipLicAmb				DECIMAL(13),
	@pExcel						INT,
	@exibirCronogramaDeProjeto	INT,
	@exibirCondicionantes		INT,
	@exibirOrientacoes			INT,
	@exibirProgramasAmbientais	INT,
	@exibirCompensatorias		INT,
	@exibirNotificacoes 		INT
) 
AS 
	DECLARE @lStrQuery						VARCHAR(8000),
			@lHoje							VARCHAR(50),
			@proximoAno						VARCHAR(50),
			@lLvl							INT,
			@lPerIni						DATETIME,
			@lPerFin						DATETIME,
			@lCondicaoEmpreendimentos		VARCHAR(1000),
			@lCondicaoLicencas				VARCHAR(1000),

			@lTotal							INT,
            @lOrdemGrupoUsuario				FLOAT,
            @lCalculoSubtotal				INT,

            @lOrd							INT,
            @lSig							VARCHAR(50),
            @lIdeUni						DECIMAL(13),
            @lCriados						INT,
			@lPlanejadasNoPrazo				INT,
			@lPlanejadasAtrasada			INT,
			@lEmExecucaoNoPrazo				INT,
			@lEmExecucaoAtrasada			INT,
			@lFinalizadaNoPrazo				INT,
			@lFinalizadaAtrasada			INT,

			@lTotalCriados					INT,
			@lTotalPlanejadasNoPrazo		INT,
			@lTotalPlanejadasAtrasada		INT,
			@lTotalEmExecucaoNoPrazo		INT,
			@lTotalEmExecucaoAtrasada		INT,
			@lTotalFinalizadaNoPrazo		INT,
			@lTotalFinalizadaAtrasada		INT,

			@lSubTotalCriados				INT,
			@lSubTotalPlanejadasNoPrazo		INT,
			@lSubTotalPlanejadasAtrasada	INT,
			@lSubTotalEmExecucaoNoPrazo		INT,
			@lSubTotalEmExecucaoAtrasada	INT,
			@lSubTotalFinalizadaNoPrazo		INT,
			@lSubTotalFinalizadaAtrasada	INT,

            @lNmeUsu						VARCHAR(100),
            @lIdeUsu						DECIMAL(13),
            @lLastNmeUsu					VARCHAR(100),
            @lLastIdeUsu					DECIMAL(13),

			@lError							INT

	DECLARE @Dados TABLE (ORD                   BIGINT, 
						NMEUSU					VARCHAR(100),
						IDEUSU					DECIMAL(13),
						SIG						VARCHAR(75),
						IDEUNI					DECIMAL(13),
						Criadas					INT, 
						PlanejadasNoPrazo		INT,
						PlanejadasAtrasada		INT,
						EmExecucaoNoPrazo		INT,
						EmExecucaoAtrasada		INT, 
						FinalizadaNoPrazo		INT, 
						FinalizadaAtrasada		INT)


	DECLARE @Dados2 TABLE (ORD                  FLOAT, 
						NMEUSU					VARCHAR(100),
						IDEUSU					DECIMAL(13),
						SIG						VARCHAR(75),
						IDEUNI					DECIMAL(13),
						Criadas					INT, 
						PlanejadasNoPrazo		INT,
						PlanejadasAtrasada		INT,
						EmExecucaoNoPrazo		INT,
						EmExecucaoAtrasada		INT, 
						FinalizadaNoPrazo		INT, 
						FinalizadaAtrasada		INT)
	BEGIN
		SET NOCOUNT ON

		SET @lPerIni = NULL
		SET @lPerFin = NULL
		SET @lCondicaoLicencas = ''
		SET @lCondicaoEmpreendimentos = ''
		SET @lCalculoSubtotal = 0
	    SET @lOrdemGrupoUsuario = 1
		SET @lHoje = 'CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), GETDATE(), 121) + ''', 121)'
		SET @proximoAno =  CONVERT(VARCHAR, CAST(DATEPART(YEAR , GETDATE()) + 1  AS VARCHAR(4)) + '-01-01', 121)
		
		IF @pSub = 0 OR @pIdeUni IS NULL
			SET @lLvl = 1
		ELSE
			SET @lLvl = 3

		IF NOT @pPerIni IS NULL
			SET @lPerIni = @pPerIni

		IF NOT @pPerFin IS NULL
			SET @lPerFin = @pPerFin 

		IF NOT @pIdeEprLicAmb IS NULL
			SET @lCondicaoEmpreendimentos = @lCondicaoEmpreendimentos +
			' AND TEPRLICAMB.IDEEPRLICAMB = ' + CAST(@pIdeEprLicAmb AS VARCHAR(13))	
		
		IF NOT @pIdeLegAmb IS NULL
			SET @lCondicaoEmpreendimentos = @lCondicaoEmpreendimentos +
				' AND TEPRLICAMB.IDELEGAMB = ' + CAST(@pIdeLegAmb AS VARCHAR(13))
		
		IF NOT @pIdeTipLicRegAmb IS NULL
			SET @lCondicaoEmpreendimentos = @lCondicaoEmpreendimentos +
				' AND TEPRLICAMB.IDETIPLICREGAMB = ' + CAST(@pIdeTipLicRegAmb AS VARCHAR(13))
	
		IF NOT @pIdeTipLicAmb IS NULL
			SET @lCondicaoLicencas = @lCondicaoLicencas +
				' AND VPLAACOINF.IDETIPLICAMB = '+ CAST(@pIdeTipLicAmb AS VARCHAR(13))

		SET @lStrQuery = 'SELECT
								VUNIARV.ORD,
								TUSU.NME,
								TUSU.IDEUSU,
								LTRIM(VUNIARV.SIG) SIG,
								VUNIARV.IDEUNI,
								COUNT(VPACTAR.IDEPACTAR) Criadas,
								
								SUM(CASE
										WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE >= ' + @lHoje + ' THEN 
											1
										ELSE 
											0
									END) PlanejadasNoPrazo,

								SUM(CASE
										WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE < ' + @lHoje + ' THEN 
											1
										ELSE 
											0
									END) PlanejadasAtrasada,

								SUM(CASE
										WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (dbo.PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, GETDATE())) <= VPACTAR.PERCON THEN 
											1
										ELSE 
											0
									END) EmExecucaoNoPrazo,

								SUM(CASE
										WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (dbo.PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, GETDATE())) > VPACTAR.PERCON THEN 
											1
										ELSE 
											0
									END) EmExecucaoAtrasada,

								SUM(CASE
										WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA <= VPACTAR.FIMPRE THEN 
											1
										ELSE
											0
									END) FinalizadaNoPrazo,

								SUM(CASE
										WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA > VPACTAR.FIMPRE THEN 
											1
										ELSE 
											0
									END) FinalizadaAtrasada '
		
		SET @lStrQuery = @lStrQuery + ' FROM (	SELECT
													LUNI.*
												FROM 
													dbo.DefinirArvoreSubordinadas(' + CAST(@pIdeUni AS VARCHAR(13)) + ', ' + CAST(@pIdePlaGes AS VARCHAR(13)) + ') LUNI
												INNER JOIN (SELECT
																IDEUNI
															FROM dbo.RetornarUnidadesPorUsuario(' + CAST(@pIdeUsuLogado AS VARCHAR(13)) + ', ' + CAST(@pIdePlaGes AS VARCHAR(13)) + ')
															) TUSUUNI
													ON LUNI.IDEUNI = TUSUUNI.IDEUNI
														WHERE LVL <= ' + CAST(@lLvl AS VARCHAR) + ') VUNIARV '

		
	SET @lStrQuery = @lStrQuery + '  	INNER JOIN 
												(
														SELECT 
															NULL IDETIPLICAMB,
															TEPRLICAMB.IDEPLAACO, 
															NULL IDEPLAACONTF, 
															NULL IDEPLAACOCMP, 
															NULL IDEPLAACOPRGAMB, 
															NULL IDEPLAACOCND, 
															NULL IDEPLAACOORIBAS, 
															IDEUNI 
														FROM TEPRLICAMB
															WHERE TEPRLICAMB.IDEUNI IS NOT NULL ' + @lCondicaoEmpreendimentos + '
													UNION 
														SELECT 
															TLICAMB.IDETIPLICAMB,
															NULL IDEPLAACO, 
															TLICAMB.IDEPLAACONTF, 
															TLICAMB.IDEPLAACOCMP, 
															TLICAMB.IDEPLAACOPRGAMB, 
															TLICAMB.IDEPLAACOCND, 
															TLICAMB.IDEPLAACOORIBAS, 
															IDEUNI 
														FROM TLICAMB 
															INNER JOIN TEPRLICAMB ON TLICAMB.IDEEPRLICAMB = TEPRLICAMB.IDEEPRLICAMB
															' + @lCondicaoEmpreendimentos + '
												) VPLAACOINF 
													ON VPLAACOINF.IDEUNI = VUNIARV.IDEUNI 
														' + @lCondicaoLicencas + '
											LEFT JOIN TPLAACO 
												ON	(
														' + CAST(@exibirCronogramaDeProjeto AS VARCHAR(13)) + '  <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACO
													)
													OR
													(
														' + CAST(@exibirNotificacoes AS VARCHAR(13)) + '  <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACONTF
													)
													OR 
													(
														' + CAST(@exibirCompensatorias AS VARCHAR(13)) + ' <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOCMP	
													)
													OR 
													(
														' + CAST(@exibirProgramasAmbientais AS VARCHAR(13)) + ' <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOPRGAMB	
													)
													OR 
													(
														' + CAST(@exibirOrientacoes AS VARCHAR(13)) + ' <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOORIBAS	
													)
													OR 
													(
														' + CAST(@exibirCondicionantes AS VARCHAR(13)) + ' <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOCND	
													) '

		SET @lStrQuery = @lStrQuery + ' INNER JOIN (SELECT
											TPACTAR.FREREC,
											TPACTAR.IDEPLAACO,
											TPACTAR.IDEPACTAR,
											TPACTAR.IDEFER,
											TPACTAR.ACAREC,
											TPACTAR.IDEUSURES,
											TPACTAR.INIPRE,
											TPACTAR.INIREA,
											TPACTAR.FIMPRE,
											TPACTAR.FIMREA,
											TPACTAR.PRXEXCREC,
											TPACTAR.DURHRA,
											TPACTAR.PERCON
										FROM TPACTAR
										INNER JOIN TPLAACO
											ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
										WHERE TPACTAR.DEL = 0 '
		
	IF @pPerIni IS NOT NULL AND @pPerFin IS NOT NULL
		SET @lStrQuery = @lStrQuery + 
			' AND 
				(
					TPACTAR.INIPRE <= CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), @pPerFin, 121) + ''', 121) AND TPACTAR.FIMPRE >=  CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), @pPerIni, 121) + ''', 121)
				) '							

		IF NOT @pIdeUsu IS NULL
			BEGIN
				SET @lStrQuery = @lStrQuery + 
					' AND TPACTAR.IDEUSURES = ' + CAST(@pIdeUsu AS VARCHAR(13))
			END

		SET @lStrQuery = @lStrQuery + ' GROUP BY	TPACTAR.IDEPACTAR,
													TPACTAR.IdePlaAco,
													TPACTAR.IDEFER,
													TPACTAR.ACAREC,
													TPACTAR.IDEUSURES,
													TPACTAR.NMEUSURES,
													TPACTAR.INIPRE,
													TPACTAR.INIREA,
													TPACTAR.FIMPRE,
													TPACTAR.FIMREA,
													TPACTAR.PRXEXCREC,
													TPACTAR.FREREC,
													TPACTAR.PERCON,
													TPACTAR.DURHRA) VPACTAR
											ON TPLAACO.IDEPLAACO = VPACTAR.IDEPLAACO
										INNER JOIN TUSU
											ON VPACTAR.IDEUSURES = TUSU.IDEUSU
										GROUP BY	TUSU.NME,
													VUNIARV.SIG,
													VUNIARV.IDEUNI,
													TUSU.IDEUSU,
													VUNIARV.ORD
										ORDER BY TUSU.NME, VUNIARV.SIG'

		SET @lStrQuery = 'DECLARE CursorRelatorio CURSOR GLOBAL FAST_FORWARD READ_ONLY FOR ' + @lStrQuery

		EXEC(@lStrQuery)

		SELECT @lError = @@ERROR
		
		IF @lError <> 0
			BEGIN
				GOTO erroRelatorio
			END
		
		SET @lTotalCriados = 0
		SET @lTotalPlanejadasNoPrazo = 0
		SET @lTotalPlanejadasAtrasada = 0
		SET @lTotalEmExecucaoNoPrazo = 0
		SET @lTotalEmExecucaoAtrasada = 0
		SET @lTotalFinalizadaNoPrazo = 0
		SET @lTotalFinalizadaAtrasada = 0
		SET @lLastNmeUsu = ''
		SET @lLastIdeUsu = 0
		SET @lSubTotalCriados = 0
		SET @lSubTotalPlanejadasNoPrazo = 0
		SET @lSubTotalPlanejadasAtrasada = 0
		SET @lSubTotalEmExecucaoNoPrazo = 0
		SET @lSubTotalEmExecucaoAtrasada = 0
		SET @lSubTotalFinalizadaNoPrazo = 0
		SET @lSubTotalFinalizadaAtrasada = 0
		
		OPEN CursorRelatorio
			FETCH CursorRelatorio INTO @lOrd, @lNmeUsu, @lIdeUsu, @lSig, @lIdeUni, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada
				WHILE @@FETCH_STATUS = 0
					BEGIN
						IF @lNmeUsu <> @lLastNmeUsu AND @lLastNmeUsu <> ''
							BEGIN
								INSERT @Dados (ORD, NMEUSU, IDEUSU, SIG, IDEUNI, Criadas, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@lOrdemGrupoUsuario * 10000, @lLastNmeUsu, @lLastIdeUsu, '', 0, @lSubTotalCriados, @lSubTotalPlanejadasNoPrazo, @lSubTotalPlanejadasAtrasada, @lSubTotalEmExecucaoNoPrazo, @lSubTotalEmExecucaoAtrasada, @lSubTotalFinalizadaNoPrazo, @lSubTotalFinalizadaAtrasada)

								SET @lSubTotalCriados = 0
								SET @lSubTotalPlanejadasNoPrazo = 0
								SET @lSubTotalPlanejadasAtrasada = 0
								SET @lSubTotalEmExecucaoNoPrazo = 0
								SET @lSubTotalEmExecucaoAtrasada = 0
								SET @lSubTotalFinalizadaNoPrazo = 0
								SET @lSubTotalFinalizadaAtrasada = 0

								SET @lOrdemGrupoUsuario = @lOrdemGrupoUsuario + 1
							END
					
						INSERT @Dados (ORD, NMEUSU, IDEUSU, SIG, IDEUNI, Criadas, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@lOrdemGrupoUsuario * 10000 + @lOrd, @lNmeUsu, @lIdeUsu, @lSig, @lIdeUni, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada)

						SET @lLastNmeUsu = @lNmeUsu
						SET @lLastIdeUsu = @lIdeUsu

						SET @lSubTotalCriados = @lSubTotalCriados + @lCriados
						SET @lSubTotalPlanejadasNoPrazo = @lSubTotalPlanejadasNoPrazo + @lPlanejadasNoPrazo
						SET @lSubTotalPlanejadasAtrasada = @lSubTotalPlanejadasAtrasada + @lPlanejadasAtrasada
						SET @lSubTotalEmExecucaoNoPrazo = @lSubTotalEmExecucaoNoPrazo + @lEmExecucaoNoPrazo
						SET @lSubTotalEmExecucaoAtrasada = @lSubTotalEmExecucaoAtrasada + @lEmExecucaoAtrasada
						SET @lSubTotalFinalizadaNoPrazo = @lSubTotalFinalizadaNoPrazo + @lFinalizadaNoPrazo
						SET @lSubTotalFinalizadaAtrasada = @lSubTotalFinalizadaAtrasada + @lFinalizadaAtrasada 

						SET @lTotalCriados = @lTotalCriados + @lCriados
						SET @lTotalPlanejadasNoPrazo = @lTotalPlanejadasNoPrazo + @lPlanejadasNoPrazo
						SET @lTotalPlanejadasAtrasada = @lTotalPlanejadasAtrasada + @lPlanejadasAtrasada
						SET @lTotalEmExecucaoNoPrazo = @lTotalEmExecucaoNoPrazo + @lEmExecucaoNoPrazo
						SET @lTotalEmExecucaoAtrasada = @lTotalEmExecucaoAtrasada + @lEmExecucaoAtrasada
						SET @lTotalFinalizadaNoPrazo = @lTotalFinalizadaNoPrazo + @lFinalizadaNoPrazo
						SET @lTotalFinalizadaAtrasada = @lTotalFinalizadaAtrasada + @lFinalizadaAtrasada  

						FETCH CursorRelatorio INTO @lOrd, @lNmeUsu, @lIdeUsu, @lSig, @lIdeUni, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada
				END
		
		CLOSE CursorRelatorio
		DEALLOCATE CursorRelatorio
		
		IF @lSubTotalCriados > 0
			INSERT @Dados (ORD, NMEUSU, IDEUSU, SIG, IDEUNI, Criadas, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@lOrdemGrupoUsuario * 10000, @lLastNmeUsu, @lLastIdeUsu, '', 0, @lSubTotalCriados, @lSubTotalPlanejadasNoPrazo, @lSubTotalPlanejadasAtrasada, @lSubTotalEmExecucaoNoPrazo, @lSubTotalEmExecucaoAtrasada, @lSubTotalFinalizadaNoPrazo, @lSubTotalFinalizadaAtrasada)
		
		SET @lOrdemGrupoUsuario = @lOrdemGrupoUsuario + 1

		SET @lOrd = 1

		DECLARE CursorRelatorioOrderNivel1 CURSOR GLOBAL FAST_FORWARD READ_ONLY FOR SELECT * FROM @Dados WHERE (CAST(Ord AS FLOAT)) / 10000 = Ord / 10000 ORDER BY NMEUSU

		OPEN CursorRelatorioOrderNivel1
			FETCH CursorRelatorioOrderNivel1 INTO @lOrdemGrupoUsuario, @lNmeUsu, @lIdeUsu, @lSig, @lIdeUni, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada
				WHILE @@FETCH_STATUS = 0
					BEGIN
						IF @pExcel = 0
							BEGIN
								INSERT @Dados2 (ORD, NMEUSU, IDEUSU, SIG, IDEUNI, Criadas, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@lOrd, @lNmeUsu, @lIdeUsu, '', 0, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada)
								SET @lOrd = @lOrd + 1
							END
			
						DECLARE CursorRelatorioOrderNivel2 CURSOR GLOBAL FAST_FORWARD READ_ONLY FOR SELECT * FROM @Dados WHERE Ord BETWEEN @lOrdemGrupoUsuario + 1 AND @lOrdemGrupoUsuario + 9999 ORDER BY Criadas DESC
							OPEN CursorRelatorioOrderNivel2
								FETCH CursorRelatorioOrderNivel2 INTO @lOrdemGrupoUsuario, @lNmeUsu, @lIdeUsu, @lSig, @lIdeUni, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada
									WHILE @@FETCH_STATUS = 0
										BEGIN
											INSERT @Dados2 (ORD, NMEUSU, IDEUSU, SIG, IDEUNI, Criadas, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@lOrd, @lNmeUsu, @lIdeUsu, @lSig, @lIdeUni, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada)
											SET @lOrd = @lOrd + 1
											FETCH CursorRelatorioOrderNivel2 INTO @lOrdemGrupoUsuario, @lNmeUsu, @lIdeUsu, @lSig, @lIdeUni, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada
										END
						CLOSE CursorRelatorioOrderNivel2
				        DEALLOCATE CursorRelatorioOrderNivel2
						FETCH CursorRelatorioOrderNivel1 INTO @lOrdemGrupoUsuario, @lNmeUsu, @lIdeUsu, @lSig, @lIdeUni, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada
					END
		
		CLOSE CursorRelatorioOrderNivel1
		DEALLOCATE CursorRelatorioOrderNivel1
		
		IF @pExcel = 0 AND @lTotalCriados > 0
	        INSERT @Dados2 (ORD, NMEUSU, IDEUSU, SIG, IDEUNI, Criadas, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@lOrdemGrupoUsuario * 100001, 'Total', -1, 'Total', 0, @lTotalCriados, @lTotalPlanejadasNoPrazo, @lTotalPlanejadasAtrasada, @lTotalEmExecucaoNoPrazo, @lTotalEmExecucaoAtrasada, @lTotalFinalizadaNoPrazo, @lTotalFinalizadaAtrasada)

		SELECT  NEWID() Id, * FROM @Dados2

		erroRelatorio:
	END
	

GO




/****** Object:  StoredProcedure [dbo].[COPIA_PlanoDeGestao]    Script Date: 10/13/2009 11:46:27 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[COPIA_PlanoDeGestao]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[COPIA_PlanoDeGestao]
/****** Object:  StoredProcedure [dbo].[COPIA_PlanoDeGestao]    Script Date: 11/13/2009 11:20:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: COPIA_PlanoDeGestao
   Prop�sito   : Efetuar a c�pia de todos os acompanhamentos de um ano para outro
   Par�metros  : pIdePlaGesOri-Plano de Gest�o de origem
                 pIdePlaGesDst-Plano de Gest�o de destino
                 pDesdobramentos-Indica se � para ser feita a c�pia do Desdobramento ou n�o
                 pFormaDeCalculo-Indica se � para ser feita a c�pia das Formas de C�lculo ou n�o
                 pModeloDeGraficos-Indica se � para ser feita a c�pia dos Modelos de Gr�fico ou n�o
                 pGraficosConfiguraveis-Indica se � para ser feita a c�pia dos Gr�ficos Configurados ou n�o
                 pPkIdentificator-Iniciais das Pk's que ser�o criadas
   Cria��o     : 02/01/2006 - mar
   �ltima Alt. : 09/12/2015 - fcs
*/
CREATE PROCEDURE [dbo].[COPIA_PlanoDeGestao]
               (@pIdePlaGesOri DECIMAL(13),
                @pIdePlaGesDst DECIMAL(13),
                @pDesdobramentos INT,
                @pFormaDeCalculo INT,
                @pModeloDeGraficos INT,
                @pGraficosConfiguraveis INT,
                @pPkIdentificator VARCHAR(3))
AS
BEGIN
    SET NOCOUNT ON
    CREATE TABLE #TempCopiaAco (NMEACOORI VARCHAR(1000), NMEACODST VARCHAR(1000), TIPERR DECIMAL(1))

    DECLARE @lIdeUni            DECIMAL(13),
            @lIdeAco            DECIMAL(13),
            @lCurrIdeAco        DECIMAL(13),
            @lIdeAcoRel         DECIMAL(13),
            @lCurrIdeAcoRel     DECIMAL(13),
            @lIDEPLAGES         DECIMAL(13),
            @lIDEIND            DECIMAL(13),
            @lIDEITEETD1        DECIMAL(13),
            @lIDEITEETD2        DECIMAL(13),
            @lIDEITEETD3        DECIMAL(13),
            @lIDEITEETD4        DECIMAL(13),
            @lIDEITEETD5        DECIMAL(13),
            @lIDEITEETD6        DECIMAL(13),
            @lNewIdeFaixas      DECIMAL(13),
            @lLIMINF            FLOAT,
            @lMIN               FLOAT,
            @lMET               FLOAT,
            @lMAX               FLOAT,
            @lLIMSUP            FLOAT

    EXEC dbo.COPIA_TodasUnidadesAno @pIdePlaGesOri, @pIdePlaGesDst, @pPkIdentificator

    DECLARE CursorAcompanhamentos CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
        SELECT TACO.IDEACO, TACO.IDEUNI
          FROM TACO
               INNER JOIN (SELECT TUNI.IDEUNI
                             FROM TUNITYP
                                  INNER JOIN TUNI ON TUNITYP.IDEUNITYP = TUNI.IDEUNITYP
                                  INNER JOIN TUNIPLAGES ON TUNI.IDEUNI = TUNIPLAGES.IDEUNI
                            WHERE TUNITYP.TYP = 1
                              AND TUNIPLAGES.IDEPLAGES = @pIdePlaGesOri) VUNIPLAGES ON TACO.IDEUNI = VUNIPLAGES.IDEUNI
         WHERE TACO.IDEPLAGES  = @pIdePlaGesOri AND TACO.STT = 0

    OPEN CursorAcompanhamentos
    FETCH NEXT FROM CursorAcompanhamentos INTO @lIdeAco, @lIdeUni
    WHILE @@FETCH_STATUS = 0
    BEGIN       
        EXEC dbo.COPIA_Acompanhamentos @lIdeAco, @pIdePlaGesDst, @lIdeUni, 3, @pModeloDeGraficos, @pGraficosConfiguraveis, 0, 0, 1, @pPkIdentificator
        FETCH NEXT FROM CursorAcompanhamentos INTO @lIdeAco, @lIdeUni
    END
    CLOSE CursorAcompanhamentos
    DEALLOCATE CursorAcompanhamentos

    --Copia de Formas de Calculo e Desdobramentos
    IF (@pDesdobramentos + @pFormaDeCalculo <> 0)
    BEGIN
        DECLARE CursorAcompanhamentos CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
            SELECT TACO.IDEACO, TACO.IDEUNI
              FROM TACO
                   INNER JOIN (SELECT TUNI.IDEUNI
                                 FROM TUNITYP
                                      INNER JOIN TUNI ON TUNITYP.IDEUNITYP = TUNI.IDEUNITYP
                                      INNER JOIN TUNIPLAGES ON TUNI.IDEUNI = TUNIPLAGES.IDEUNI
                                WHERE TUNITYP.TYP = 1
                                  AND TUNIPLAGES.IDEPLAGES = @pIdePlaGesOri) VUNIPLAGES ON TACO.IDEUNI = VUNIPLAGES.IDEUNI
             WHERE TACO.IDEPLAGES  = @pIdePlaGesOri

        OPEN CursorAcompanhamentos
        FETCH NEXT FROM CursorAcompanhamentos INTO @lIdeAco, @lIdeUni
        WHILE @@FETCH_STATUS = 0
        BEGIN       
            EXEC dbo.COPIA_Acompanhamentos @lIdeAco, @pIdePlaGesDst, @lIdeUni, 0, 0, 0, @pDesdobramentos, @pFormaDeCalculo, 1, @pPkIdentificator
            FETCH NEXT FROM CursorAcompanhamentos INTO @lIdeAco, @lIdeUni
        END
        CLOSE CursorAcompanhamentos
        DEALLOCATE CursorAcompanhamentos
    END

    DECLARE CursorAcoRel CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
        SELECT TACO.IDEUNI, TACO.IDEIND, TACO.IDEITEETD1, TACO.IDEITEETD2, TACO.IDEITEETD3, TACO.IDEITEETD4, TACO.IDEITEETD5, TACO.IDEITEETD6, TACO.IDEACOREL
          FROM TACO
               INNER JOIN (SELECT TACO.IDEACO
                             FROM TACO
                                  INNER JOIN TUNI ON TACO.IDEUNI = TUNI.IDEUNI
                                  INNER JOIN TUNITYP ON TUNI.IDEUNITYP = TUNITYP.IDEUNITYP
                            WHERE TUNITYP.TYP = 1) VACOUNI ON TACO.IDEACOREL = VACOUNI .IDEACO
               INNER JOIN (SELECT TUNI.IDEUNI
                             FROM TUNITYP
                                  INNER JOIN TUNI ON TUNITYP.IDEUNITYP = TUNI.IDEUNITYP
                                  INNER JOIN TUNIPLAGES ON TUNI.IDEUNI = TUNIPLAGES.IDEUNI
                            WHERE TUNITYP.TYP = 1
                              AND TUNIPLAGES.IDEPLAGES = @pIdePlaGesOri) VUNIPLAGES ON TACO.IDEUNI = VUNIPLAGES.IDEUNI
         WHERE TACO.IDEPLAGES  = @pIdePlaGesOri

    OPEN CursorAcoRel
    FETCH NEXT FROM CursorAcoRel INTO @lIDEUNI, @lIDEIND, @lIDEITEETD1, @lIDEITEETD2, @lIDEITEETD3, @lIDEITEETD4, @lIDEITEETD5, @lIDEITEETD6, @lCurrIdeAcoRel
    WHILE @@FETCH_STATUS = 0
    BEGIN

        SELECT @lIdeAco = MAX(IdeAco)
          FROM tAco
         WHERE tAco.IdeUni = @lIDEUNI
           AND tAco.IdePlaGes = @pIdePlaGesDst
           AND ISNULL(tAco.IdeInd, 0) = ISNULL(@lIDEIND, 0)
           AND ISNULL(tAco.IdeIteEtd1, 0) = ISNULL(@lIDEITEETD1, 0)
           AND ISNULL(tAco.IdeIteEtd2, 0) = ISNULL(@lIDEITEETD2, 0)
           AND ISNULL(tAco.IdeIteEtd3, 0) = ISNULL(@lIDEITEETD3, 0)
           AND ISNULL(tAco.IdeIteEtd4, 0) = ISNULL(@lIDEITEETD4, 0)
           AND ISNULL(tAco.IdeIteEtd5, 0) = ISNULL(@lIDEITEETD5, 0)
           AND ISNULL(tAco.IdeIteEtd6, 0) = ISNULL(@lIDEITEETD6, 0)

        IF @lIdeAco IS NOT NULL
        BEGIN
            SELECT @lIDEUNI = IDEUNI,
                   @lIDEIND = IDEIND,
                   @lIDEITEETD1 = IDEITEETD1,
                   @lIDEITEETD2 = IDEITEETD2,
                   @lIDEITEETD3 = IDEITEETD3,
                   @lIDEITEETD4 = IDEITEETD4,
                   @lIDEITEETD5 = IDEITEETD5,
                   @lIDEITEETD6 = IDEITEETD6
              FROM TACO
             WHERE TACO.IDEACO = @lCurrIdeAcoRel
            
            SELECT @lIdeAcoRel = MAX(IdeAco)
              FROM tAco
             WHERE tAco.IdeUni = @lIDEUNI
               AND tAco.IdePlaGes = @pIdePlaGesDst
               AND ISNULL(tAco.IdeInd, 0) = ISNULL(@lIDEIND, 0)
               AND ISNULL(tAco.IdeIteEtd1, 0) = ISNULL(@lIDEITEETD1, 0)
               AND ISNULL(tAco.IdeIteEtd2, 0) = ISNULL(@lIDEITEETD2, 0)
               AND ISNULL(tAco.IdeIteEtd3, 0) = ISNULL(@lIDEITEETD3, 0)
               AND ISNULL(tAco.IdeIteEtd4, 0) = ISNULL(@lIDEITEETD4, 0)
               AND ISNULL(tAco.IdeIteEtd5, 0) = ISNULL(@lIDEITEETD5, 0)
               AND ISNULL(tAco.IdeIteEtd6, 0) = ISNULL(@lIDEITEETD6, 0)

            UPDATE TACO SET IDEACOREL = @lIdeAcoRel WHERE IDEACO = @lIdeAco
        END

        FETCH NEXT FROM CursorAcoRel INTO @lIDEUNI, @lIDEIND, @lIDEITEETD1, @lIDEITEETD2, @lIDEITEETD3, @lIDEITEETD4, @lIDEITEETD5, @lIDEITEETD6, @lCurrIdeAcoRel
    END
    CLOSE CursorAcoRel
    DEALLOCATE CursorAcoRel

    /*DECLARE CursorFaixas CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
        SELECT IDEIND,
               LIMINF,
               MIN,
               MET,
               MAX,
               LIMSUP
          FROM TINDPLAGESNTAREMVAR
         WHERE IDEPLAGES = @pIdePlaGesOri
         ORDER BY IDEIND

    OPEN CursorFaixas
    FETCH NEXT FROM CursorFaixas INTO @lIDEIND, @lLIMINF, @lMIN, @lMET, @lMAX, @lLIMSUP
    WHILE @@FETCH_STATUS = 0
    BEGIN

        EXEC GetTableIde 'tIndPlaGesNtaRemVar', 1, @pPkIdentificator, @lNewIdeFaixas OUTPUT
        INSERT INTO TINDPLAGESNTAREMVAR (IDEINDPLAGESNTAREMVAR, IDEPLAGES, IDEIND, LIMINF, MIN, MET, MAX, LIMSUP, UPDTME)
                                 VALUES (@lNewIdeFaixas, @pIdePlaGesDst, @lIDEIND, @lLIMINF, @lMIN, @lMET, @lMAX, @lLIMSUP, GETDATE())

        FETCH NEXT FROM CursorFaixas INTO @lIDEIND, @lLIMINF, @lMIN, @lMET, @lMAX, @lLIMSUP
    END
    CLOSE CursorFaixas
    DEALLOCATE CursorFaixas*/
    
    SELECT * FROM #TempCopiaAco

END
GO




/****** Object:  StoredProcedure [dbo].[COPIA_PlanoDeGestao30]    Script Date: 10/13/2009 11:46:27 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[COPIA_PlanoDeGestao30]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[COPIA_PlanoDeGestao30]
/****** Object:  StoredProcedure [dbo].[COPIA_PlanoDeGestao30]    Script Date: 11/13/2009 11:20:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: COPIA_PlanoDeGestao30
   Prop�sito   : Efetuar a c�pia de todos os acompanhamentos de um ano para outro
   Par�metros  : pIdePlaGesOri-Plano de Gest�o de origem
                 pIdePlaGesDst-Plano de Gest�o de destino
                 pDesdobramentos-Indica se � para ser feita a c�pia do Desdobramento ou n�o
                 pFormaDeCalculo-Indica se � para ser feita a c�pia das Formas de C�lculo ou n�o
                 pModeloDeGraficos-Indica se � para ser feita a c�pia dos Modelos de Gr�fico ou n�o
                 pGraficosConfiguraveis-Indica se � para ser feita a c�pia dos Gr�ficos Configurados ou n�o
                 pPkIdentificator-Iniciais das Pk's que ser�o criadas
   Cria��o     : 02/01/2006 - mar
   �ltima Alt. : 09/12/2015 - fcs
*/
CREATE PROCEDURE [dbo].[COPIA_PlanoDeGestao30]
               (@pIdePlaGesOri DECIMAL(13),
                @pIdePlaGesDst DECIMAL(13),
                @pDesdobramentos INT,
                @pFormaDeCalculo INT,
                @pModeloDeGraficos INT,
				@pCopiarVisoes INT)
AS
BEGIN
    SET NOCOUNT ON
    CREATE TABLE #TempCopiaAco (NMEACOORI VARCHAR(1000), NMEACODST VARCHAR(1000), TIPERR DECIMAL(1))

    DECLARE @lIdeUni            DECIMAL(13),
            @lIdeAco            DECIMAL(13),
            @lCurrIdeAco        DECIMAL(13),
            @lIdeAcoRel         DECIMAL(13),
            @lCurrIdeAcoRel     DECIMAL(13),
            @lIDEPLAGES         DECIMAL(13),
            @lIDEIND            DECIMAL(13),
            @lIDEITEETD1        DECIMAL(13),
            @lIDEITEETD2        DECIMAL(13),
            @lIDEITEETD3        DECIMAL(13),
            @lIDEITEETD4        DECIMAL(13),
            @lIDEITEETD5        DECIMAL(13),
            @lIDEITEETD6        DECIMAL(13),
            @lNewIdeFaixas      DECIMAL(13),
            @lLIMINF            FLOAT,
            @lMIN               FLOAT,
            @lMET               FLOAT,
            @lMAX               FLOAT,
            @lLIMSUP            FLOAT

    EXEC dbo.COPIA_TodasUnidadesAno30 @pIdePlaGesOri, @pIdePlaGesDst

    DECLARE CursorAcompanhamentos CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
        SELECT TACO.IDEACO, TACO.IDEUNI
          FROM TACO
               INNER JOIN (SELECT TUNI.IDEUNI
                             FROM TUNITYP
                                  INNER JOIN TUNI ON TUNITYP.IDEUNITYP = TUNI.IDEUNITYP
                                  INNER JOIN TUNIPLAGES ON TUNI.IDEUNI = TUNIPLAGES.IDEUNI
                            WHERE TUNITYP.TYP = 1
                              AND TUNIPLAGES.IDEPLAGES = @pIdePlaGesOri) VUNIPLAGES ON TACO.IDEUNI = VUNIPLAGES.IDEUNI
         WHERE TACO.IDEPLAGES  = @pIdePlaGesOri AND TACO.STT = 0

    OPEN CursorAcompanhamentos
    FETCH NEXT FROM CursorAcompanhamentos INTO @lIdeAco, @lIdeUni
    WHILE @@FETCH_STATUS = 0
    BEGIN       
        EXEC dbo.COPIA_Acompanhamentos30 @lIdeAco, @pIdePlaGesDst, @lIdeUni, 3, @pModeloDeGraficos, 0, 0, 1
        FETCH NEXT FROM CursorAcompanhamentos INTO @lIdeAco, @lIdeUni
    END
    CLOSE CursorAcompanhamentos
    DEALLOCATE CursorAcompanhamentos

	--Copia vis�es
	IF @pCopiarVisoes <> 0
		EXEC dbo.COPIA_TodasVisoesAno30 @pIdePlaGesOri, @pIdePlaGesDst

    --Copia de Formas de Calculo e Desdobramentos
    IF (@pDesdobramentos + @pFormaDeCalculo <> 0)
    BEGIN
        DECLARE CursorAcompanhamentos CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
            SELECT TACO.IDEACO, TACO.IDEUNI
              FROM TACO
                   INNER JOIN (SELECT TUNI.IDEUNI
                                 FROM TUNITYP
                                      INNER JOIN TUNI ON TUNITYP.IDEUNITYP = TUNI.IDEUNITYP
                                      INNER JOIN TUNIPLAGES ON TUNI.IDEUNI = TUNIPLAGES.IDEUNI
                                WHERE TUNITYP.TYP = 1
                                  AND TUNIPLAGES.IDEPLAGES = @pIdePlaGesOri) VUNIPLAGES ON TACO.IDEUNI = VUNIPLAGES.IDEUNI
             WHERE TACO.IDEPLAGES  = @pIdePlaGesOri

        OPEN CursorAcompanhamentos
        FETCH NEXT FROM CursorAcompanhamentos INTO @lIdeAco, @lIdeUni
        WHILE @@FETCH_STATUS = 0
        BEGIN       
            EXEC dbo.COPIA_Acompanhamentos30 @lIdeAco, @pIdePlaGesDst, @lIdeUni, 0, 0, @pDesdobramentos, @pFormaDeCalculo, 1
            FETCH NEXT FROM CursorAcompanhamentos INTO @lIdeAco, @lIdeUni
        END
        CLOSE CursorAcompanhamentos
        DEALLOCATE CursorAcompanhamentos
    END

    DECLARE CursorAcoRel CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
        SELECT TACO.IDEUNI, TACO.IDEIND, TACO.IDEITEETD1, TACO.IDEITEETD2, TACO.IDEITEETD3, TACO.IDEITEETD4, TACO.IDEITEETD5, TACO.IDEITEETD6, TACO.IDEACOREL
          FROM TACO
               INNER JOIN (SELECT TACO.IDEACO
                             FROM TACO
                                  INNER JOIN TUNI ON TACO.IDEUNI = TUNI.IDEUNI
                                  INNER JOIN TUNITYP ON TUNI.IDEUNITYP = TUNITYP.IDEUNITYP
                            WHERE TUNITYP.TYP = 1) VACOUNI ON TACO.IDEACOREL = VACOUNI .IDEACO
               INNER JOIN (SELECT TUNI.IDEUNI
                             FROM TUNITYP
                                  INNER JOIN TUNI ON TUNITYP.IDEUNITYP = TUNI.IDEUNITYP
                                  INNER JOIN TUNIPLAGES ON TUNI.IDEUNI = TUNIPLAGES.IDEUNI
                            WHERE TUNITYP.TYP = 1
                              AND TUNIPLAGES.IDEPLAGES = @pIdePlaGesOri) VUNIPLAGES ON TACO.IDEUNI = VUNIPLAGES.IDEUNI
         WHERE TACO.IDEPLAGES  = @pIdePlaGesOri

    OPEN CursorAcoRel
    FETCH NEXT FROM CursorAcoRel INTO @lIDEUNI, @lIDEIND, @lIDEITEETD1, @lIDEITEETD2, @lIDEITEETD3, @lIDEITEETD4, @lIDEITEETD5, @lIDEITEETD6, @lCurrIdeAcoRel
    WHILE @@FETCH_STATUS = 0
    BEGIN

        SELECT @lIdeAco = MAX(IdeAco)
          FROM tAco
         WHERE tAco.IdeUni = @lIDEUNI
           AND tAco.IdePlaGes = @pIdePlaGesDst
           AND ISNULL(tAco.IdeInd, 0) = ISNULL(@lIDEIND, 0)
           AND ISNULL(tAco.IdeIteEtd1, 0) = ISNULL(@lIDEITEETD1, 0)
           AND ISNULL(tAco.IdeIteEtd2, 0) = ISNULL(@lIDEITEETD2, 0)
           AND ISNULL(tAco.IdeIteEtd3, 0) = ISNULL(@lIDEITEETD3, 0)
           AND ISNULL(tAco.IdeIteEtd4, 0) = ISNULL(@lIDEITEETD4, 0)
           AND ISNULL(tAco.IdeIteEtd5, 0) = ISNULL(@lIDEITEETD5, 0)
           AND ISNULL(tAco.IdeIteEtd6, 0) = ISNULL(@lIDEITEETD6, 0)

        IF @lIdeAco IS NOT NULL
        BEGIN
            SELECT @lIDEUNI = IDEUNI,
                   @lIDEIND = IDEIND,
                   @lIDEITEETD1 = IDEITEETD1,
                   @lIDEITEETD2 = IDEITEETD2,
                   @lIDEITEETD3 = IDEITEETD3,
                   @lIDEITEETD4 = IDEITEETD4,
                   @lIDEITEETD5 = IDEITEETD5,
                   @lIDEITEETD6 = IDEITEETD6
              FROM TACO
             WHERE TACO.IDEACO = @lCurrIdeAcoRel
            
            SELECT @lIdeAcoRel = MAX(IdeAco)
              FROM tAco
             WHERE tAco.IdeUni = @lIDEUNI
               AND tAco.IdePlaGes = @pIdePlaGesDst
               AND ISNULL(tAco.IdeInd, 0) = ISNULL(@lIDEIND, 0)
               AND ISNULL(tAco.IdeIteEtd1, 0) = ISNULL(@lIDEITEETD1, 0)
               AND ISNULL(tAco.IdeIteEtd2, 0) = ISNULL(@lIDEITEETD2, 0)
               AND ISNULL(tAco.IdeIteEtd3, 0) = ISNULL(@lIDEITEETD3, 0)
               AND ISNULL(tAco.IdeIteEtd4, 0) = ISNULL(@lIDEITEETD4, 0)
               AND ISNULL(tAco.IdeIteEtd5, 0) = ISNULL(@lIDEITEETD5, 0)
               AND ISNULL(tAco.IdeIteEtd6, 0) = ISNULL(@lIDEITEETD6, 0)

            UPDATE TACO SET IDEACOREL = @lIdeAcoRel WHERE IDEACO = @lIdeAco
        END

        FETCH NEXT FROM CursorAcoRel INTO @lIDEUNI, @lIDEIND, @lIDEITEETD1, @lIDEITEETD2, @lIDEITEETD3, @lIDEITEETD4, @lIDEITEETD5, @lIDEITEETD6, @lCurrIdeAcoRel
    END
    CLOSE CursorAcoRel
    DEALLOCATE CursorAcoRel
    
    SELECT * FROM #TempCopiaAco

END
GO



IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[COPIA_TodasUnidadesAno]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[COPIA_TodasUnidadesAno]
/****** Object:  StoredProcedure [dbo].[COPIA_TodasUnidadesAno]    Script Date: 11/13/2009 11:20:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: COPIA_TodasUnidadesAno
   Prop�sito   : Efetuar a c�pia de todas as unidades de um plano de gest�o para outro
   Par�metros  : pExrOri-Exerc�cio de origem das informa��es
                 pExtDst-Exerc�cio de destino das informa��es
                 pPkIdentificator-Iniciais das Pk's que ser�o criadas
   Cria��o     : 03/01/2009 - gtv
   �ltima Alt. : 14/12/2010 - rangel */

CREATE PROCEDURE [dbo].[COPIA_TodasUnidadesAno](@pIdePlaGesOri decimal(13), @pIdePlaGesDst decimal(13), @pPkIdentificator VARCHAR(3))
AS
BEGIN
DECLARE @lIdeUniPlaGes  DECIMAL(13),
		@lIdeUni DECIMAL(13),
		@lSig VARCHAR(25),
		@lNme VARCHAR(45),
		@lIdeSpr DECIMAL(13),
		@lIdeUsu DECIMAL(13),
		@lIdeUniOpe DECIMAL(13),
		
		@lDiaDbl DECIMAL(38),
		@lDiaHbl DATETIME,
		@lDiaBlq NVARCHAR(800),
		@lSemDbl DECIMAL(38),
		@lSemHbl DATETIME,
		@lSemBlq NVARCHAR(120),
		@lMenDbl DECIMAL(38),
		@lMenHbl DATETIME,
		@lMenBlq NVARCHAR(30),
		@lBlqSub INT,
		@lBlqAtv INT

	DECLARE CursorPlaGes CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR 
		SELECT IDEUNI, SIG, NME, IDESPR, IDEUSU, IDEUNIOPE, DIADBL, DIAHBL, DIABLQ, SEMDBL, SEMHBL, SEMBLQ, MENDBL, MENHBL, MENBLQ, BLQSUB, BLQATV
		  FROM TUNIPLAGES 
		 WHERE TUNIPLAGES.IDEPLAGES = @pIdePlaGesOri

	OPEN CursorPlaGes
	FETCH NEXT FROM CursorPlaGes INTO @lIdeUni, @lSig , @lNme, @lIdeSpr, @lIdeUsu, @lIdeUniOpe, @lDiaDbl, @lDiaHbl, @lDiaBlq, @lSemDbl, @lSemHbl, @lSemBlq, @lMenDbl, @lMenHbl, @lMenBlq, @lBlqSub, @lBlqAtv
	WHILE @@FETCH_STATUS = 0	
	BEGIN			
	
		SELECT @lIdeUniPlaGes = IDEUNIPLAGES
		  FROM TUNIPLAGES
		 WHERE TUNIPLAGES.IDEUNI = @lIdeUni
		   AND TUNIPLAGES.IDEPLAGES = @pIdePlaGesDst

		IF @@ROWCOUNT = 0
		BEGIN
            INSERT INTO TUNIPLAGES (IDEUNI, IDEPLAGES, SIG, NME, IDESPR, IDEUSU, IDEUNIOPE, DIADBL, DIAHBL, DIABLQ, SEMDBL, SEMHBL, SEMBLQ, MENDBL, MENHBL, MENBLQ, BLQSUB, BLQATV, UPDTME)
                            VALUES (@lIdeUni, @pIdePlaGesDst, @lSig, @lNme, @lIdeSpr, @lIdeUsu, @lIdeUniOpe, @lDiaDbl, @lDiaHbl, @lDiaBlq, @lSemDbl, @lSemHbl, @lSemBlq, @lMenDbl, @lMenHbl, @lMenBlq, @lBlqSub, @lBlqAtv, GETDATE());
		END
        
		FETCH NEXT FROM CursorPlaGes INTO @lIdeUni, @lSig , @lNme, @lIdeSpr, @lIdeUsu, @lIdeUniOpe, @lDiaDbl, @lDiaHbl, @lDiaBlq, @lSemDbl, @lSemHbl, @lSemBlq, @lMenDbl, @lMenHbl, @lMenBlq, @lBlqSub, @lBlqAtv
	END
	CLOSE CursorPlaGes
	DEALLOCATE CursorPlaGes
END
GO

IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[COPIA_TodasUnidadesAno30]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[COPIA_TodasUnidadesAno30]
/****** Object:  StoredProcedure [dbo].[COPIA_TodasUnidadesAno30]    Script Date: 11/13/2009 11:20:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: COPIA_TodasUnidadesAno30
   Prop�sito   : Efetuar a c�pia de todas as unidades de um plano de gest�o para outro
   Par�metros  : pExrOri-Exerc�cio de origem das informa��es
                 pExtDst-Exerc�cio de destino das informa��es
                 pPkIdentificator-Iniciais das Pk's que ser�o criadas
   Cria��o     : 03/01/2009 - gtv
   �ltima Alt. : 14/12/2010 - rangel */

CREATE PROCEDURE [dbo].[COPIA_TodasUnidadesAno30](@pIdePlaGesOri decimal(13), @pIdePlaGesDst decimal(13))
AS
BEGIN
DECLARE @lIdeUniPlaGes  DECIMAL(13),
		@lIdeUni DECIMAL(13),
		@lSig VARCHAR(25),
		@lNme VARCHAR(45),
		@lIdeSpr DECIMAL(13),
		@lIdeUsu DECIMAL(13),
		@lIdeUniOpe DECIMAL(13),
		
		@lDiaDbl DECIMAL(38),
		@lDiaHbl DATETIME,
		@lDiaBlq NVARCHAR(800),
		@lSemDbl DECIMAL(38),
		@lSemHbl DATETIME,
		@lSemBlq NVARCHAR(120),
		@lMenDbl DECIMAL(38),
		@lMenHbl DATETIME,
		@lMenBlq NVARCHAR(30),
		@lBlqSub INT,
		@lBlqAtv INT

	DECLARE CursorPlaGes CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR 
		SELECT IDEUNI, SIG, NME, IDESPR, IDEUSU, IDEUNIOPE, DIADBL, DIAHBL, DIABLQ, SEMDBL, SEMHBL, SEMBLQ, MENDBL, MENHBL, MENBLQ, BLQSUB, BLQATV
		  FROM TUNIPLAGES 
		 WHERE TUNIPLAGES.IDEPLAGES = @pIdePlaGesOri

	OPEN CursorPlaGes
	FETCH NEXT FROM CursorPlaGes INTO @lIdeUni, @lSig , @lNme, @lIdeSpr, @lIdeUsu, @lIdeUniOpe, @lDiaDbl, @lDiaHbl, @lDiaBlq, @lSemDbl, @lSemHbl, @lSemBlq, @lMenDbl, @lMenHbl, @lMenBlq, @lBlqSub, @lBlqAtv
	WHILE @@FETCH_STATUS = 0	
	BEGIN			
	
		SELECT @lIdeUniPlaGes = IDEUNIPLAGES
		  FROM TUNIPLAGES
		 WHERE TUNIPLAGES.IDEUNI = @lIdeUni
		   AND TUNIPLAGES.IDEPLAGES = @pIdePlaGesDst

		IF @@ROWCOUNT = 0
		BEGIN
            INSERT INTO TUNIPLAGES (IDEUNI, IDEPLAGES, SIG, NME, IDESPR, IDEUSU, IDEUNIOPE, DIADBL, DIAHBL, DIABLQ, SEMDBL, SEMHBL, SEMBLQ, MENDBL, MENHBL, MENBLQ, BLQSUB, BLQATV, UPDTME)
                            VALUES (@lIdeUni, @pIdePlaGesDst, @lSig, @lNme, @lIdeSpr, @lIdeUsu, @lIdeUniOpe, @lDiaDbl, @lDiaHbl, @lDiaBlq, @lSemDbl, @lSemHbl, @lSemBlq, @lMenDbl, @lMenHbl, @lMenBlq, @lBlqSub, @lBlqAtv, GETDATE());
		END
        
		FETCH NEXT FROM CursorPlaGes INTO @lIdeUni, @lSig , @lNme, @lIdeSpr, @lIdeUsu, @lIdeUniOpe, @lDiaDbl, @lDiaHbl, @lDiaBlq, @lSemDbl, @lSemHbl, @lSemBlq, @lMenDbl, @lMenHbl, @lMenBlq, @lBlqSub, @lBlqAtv
	END
	CLOSE CursorPlaGes
	DEALLOCATE CursorPlaGes
END
GO


IF  EXISTS (SELECT * FROM sysobjects WHERE ID = OBJECT_ID(N'[dbo].[DATAMINING_GenerateTemporaryData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DATAMINING_GenerateTemporaryData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* Procedimento : DATAMINING_GenerateTemporaryData
   Prop�sito    : Gera um conjunto de registros tempor�rios que ser�o usados para efetuar um LEFT JOIN com as informa��es que est�o sendo extra�das/consolidadas
   Par�metros   : (nenhum)
   Retorno      : (nenhum)
   Cria��o      : 19/07/2003 - mar
   �ltima Alt.  : 23/02/2005 - mar */

CREATE  PROCEDURE [dbo].[DATAMINING_GenerateTemporaryData]
AS
    DECLARE @lDataInicial       DATETIME
    DECLARE @lDataFinal     DATETIME
    DECLARE @lBegWek        DECIMAL(1)
    DECLARE @lFstDayMon     DECIMAL(1)
    DECLARE @lContComandos      DECIMAL
BEGIN
    --SET NOCOUNT ON 
    
    SET @lDataInicial = CAST('1990-01-01' AS DATETIME)
    SET @lDataFinal = CAST('2025-12-31' AS DATETIME)
    SET @lContComandos = 0
    
    BEGIN TRANSACTION
    
    WHILE @lDataInicial <= @lDataFinal
    BEGIN
        IF DATEPART(dw, @lDataInicial) = 1
            SET @lBegWek = -1
        ELSE
            SET @lBegWek = 0

        IF DATEPART(dd, @lDataInicial) = 1
        BEGIN
            SET @lFstDayMon = -1
            IF DATEPART(mm, @lDataInicial) = 1
                SET @lBegWek = -1
        END     
        ELSE
            SET @lFstDayMon = 0

        INSERT INTO TTMPDTAMNG (OCO, BEGWEK, FSTDAYMON) VALUES (@lDataInicial, @lBegWek, @lFstDayMon)
        SET @lContComandos = @lContComandos + 1

        IF @lContComandos >= 1000
        BEGIN
            COMMIT TRANSACTION
            BEGIN TRANSACTION
            SET @lContComandos = 0
        END

        SET @lDataInicial = @lDataInicial + 1
    END

    COMMIT TRANSACTION

    RETURN

END
GO




/****** Object:  StoredProcedure [dbo].[ExtrairXmlField]    Script Date: 10/21/2008 14:48:32 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[ExtrairXmlField]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ExtrairXmlField]
GO
/****** Object:  StoredProcedure [dbo].[ExtrairXmlField]    Script Date: 10/21/2008 14:48:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO

CREATE PROCEDURE [dbo].[ExtrairXmlField](@pTableName VARCHAR(30), @pIdeTbl DECIMAL(13))
AS
    DECLARE @lInLineXmlCursor VARCHAR(1000),
                @lIdeTbl          DECIMAL(13),
                @lTblMmo          VARCHAR(8000)
BEGIN
    IF @pIdeTbl = 0
        SET @lInLineXmlCursor = 'DECLARE CursorXml CURSOR GLOBAL FORWARD_ONLY READ_ONLY FOR SELECT Ide' + SUBSTRING(@pTableName, 2, LEN(@pTableName)) + ', ' + SUBSTRING(@pTableName, 2, LEN(@pTableName)) +  'Mmo FROM ' + @pTableName
    ELSE
        SET @lInLineXmlCursor = 'DECLARE CursorXml CURSOR GLOBAL FORWARD_ONLY READ_ONLY FOR SELECT Ide' + SUBSTRING(@pTableName, 2, LEN(@pTableName)) + ', ' + SUBSTRING(@pTableName, 2, LEN(@pTableName)) +  'Mmo FROM ' + @pTableName + ' WHERE Ide' + SUBSTRING(@pTableName, 2, LEN(@pTableName)) + ' = ' + CAST(@pIdeTbl AS VARCHAR)

    EXEC (@lInLineXmlCursor)

    IF (CURSOR_STATUS('local', 'CursorXml') > -2)
    BEGIN
        CLOSE CursorXml
        DEALLOCATE CursorXml
    END

    PRINT 'BEGIN'
    PRINT '   DECLARE @lMmo VARCHAR(8000)'
    PRINT ''

    OPEN CursorXml
    FETCH CursorXml INTO @lIdeTbl, @lTblMmo
    WHILE @@FETCH_STATUS = 0
    BEGIN
        PRINT '   SET @lMmo = ''' + @lTblMmo + ''''
        PRINT ''
        PRINT '   UPDATE ' + @pTableName + ' SET ' + SUBSTRING(@pTableName, 2, LEN(@pTableName)) +  'Mmo = @lMmo WHERE Ide' + SUBSTRING(@pTableName, 2, LEN(@pTableName)) + ' = ' + CAST(@lIdeTbl AS VARCHAR)
        PRINT ''
        FETCH CursorXml INTO @lIdeTbl, @lTblMmo
    END

    PRINT 'END'

    CLOSE CursorXml
    DEALLOCATE CursorXml

END
GO




/****** Object:  StoredProcedure [dbo].[GetTableIde]    Script Date: 10/21/2008 14:48:48 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[GetTableIde]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetTableIde]
GO
/****** Object:  StoredProcedure [dbo].[GetTableIde]    Script Date: 10/21/2008 14:48:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* Procedimento : GetTableIde
   Prop�sito    : Retorna o identificador que deve ser usado em uma nova linha que est� sendo inserida em uma tabela
   Par�metros   : @pTableName-Nome da tabela a ter seu Ide gerado
                  @pIncremento-De quanto ser� incrementado o ID
                  @pPkIdentificator-N�meros iniciais a serem agregados � chave gerada
   Retorno      : @mReturnIde-Novo identificador da tabela
   Cria��o      : 14/06/2003 - mar
   �ltima Alt.  : 28/09/2010 - rangel */

CREATE PROCEDURE [dbo].[GetTableIde]
                           (@pTableName VARCHAR(31), 
                            @pIncremento INTEGER, 
                            @pPkIdentificator VARCHAR(3), 
                            @mReturnIde DECIMAL(13) OUTPUT)
AS
BEGIN
    DECLARE @lError         INT,
        @lRowCount      INT,
                @lNewIde        INT

    SET @lRowCount = 0

        WHILE @lRowCount = 0
        BEGIN
        SELECT @lNewIde = ISNULL(TIDS.NEWIDE, 1)
          FROM TIDS
         WHERE UPPER(TIDS.TBLNME) = @pTableName

        SELECT @lError = @@ERROR, @lRowCount = @@ROWCOUNT

        IF @lError <> 0
        BEGIN
            SET @mReturnIde = -1
            RETURN
        END 

        IF @lRowCount = 0
        BEGIN
             SET @lNewIde = 1

             INSERT INTO TIDS (TBLNME, NEWIDE) VALUES (@pTableName, @lNewIde)
        END

        UPDATE TIDS SET NEWIDE = @lNewIde + @pIncremento WHERE TBLNME = @pTableName AND NEWIDE = @lNewIde

        SELECT @lError = @@ERROR, @lRowCount = @@ROWCOUNT

        IF @lError <> 0
        BEGIN
            SET @mReturnIde = -1
            RETURN
        END 
    END

    SET @mReturnIde = CAST(@pPkIdentificator + '0000000000' AS DECIMAL(13)) + @lNewIde

    RETURN

END
GO



IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[INTEGRIDADE_DESMARCARACOANT]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[INTEGRIDADE_DESMARCARACOANT]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: INTEGRIDADE_DESMARCARACOANT
   Propósito   : 
   Parâmetros  : 
   Retorno     : 
   Criação     : 
   Última Alt. : 
*/
CREATE PROCEDURE [dbo].[INTEGRIDADE_DESMARCARACOANT]
   (@pIdeAco decimal(13),
    @pIdeAnt decimal(13))
AS
BEGIN
    DECLARE @lDia DATETIME,
            @lSemIni DATETIME,
            @lSemFim DATETIME,
            @lMesIni DATETIME,
            @lMesFim DATETIME,
            @lExisteDia int,
            @lExisteSemana int,
            @lExisteMes int
    
    SET @lDia = (SELECT TANT.DAT
                   FROM TANT
                  WHERE TANT.IDEANT = @pIdeAnt)
    
    
    SET @lSemIni = DATEADD(DAY, (DATEPART(WeekDay, @lDia) * (-1)) + 1, @lDia)
    SET @lSemFim = @lSemIni + 6;
    SET @lMesIni = CAST(CONVERT(VARCHAR(6), @lDia, 112) + '01' AS DATETIME)
    SET @lMesFim = DATEADD(MONTH, 1, @lMesIni) - 1  

    if YEAR(@lSemIni) <> YEAR(@lDia)
        SET @lSemIni = CAST(CONVERT(VARCHAR(4), @lDia, 112) + '0101' AS DATETIME)
        
    if YEAR(@lSemIni) <> YEAR(@lSemFim)
        SET @lSemFim = @lMesFim

    SET @lExisteDia = (SELECT COUNT(*)
                         FROM TACOANT INNER JOIN TANT ON TACOANT.IDEANT = TANT.IDEANT
                        WHERE TACOANT.IDEACO = @pIdeAco
                          AND TACOANT.DEL = 0
                          AND TANT.DAT = @lDia
                          AND TANT.DEL = 0)


    if @lExisteDia = 0
         UPDATE TVALACO SET FLGANT = 0, UPDTME = GETDATE()
          WHERE IDEACO = @pIdeAco
            AND OCO = @lDia
            AND FRE = 3
            AND FLGANT <> 0
    
                        
    SET @lExisteSemana = (SELECT COUNT(*)
                           FROM TACOANT INNER JOIN TANT ON TACOANT.IDEANT = TANT.IDEANT
                          WHERE TACOANT.IDEACO = @pIdeAco
                            AND TACOANT.DEL = 0
                            AND TANT.DAT BETWEEN @lSemIni AND @lSemFim
                            AND TANT.DEL = 0)

    if @lExisteSemana = 0 
         UPDATE TVALACO SET FLGANT = 0, UPDTME = GETDATE()
          WHERE IDEACO = @pIdeAco
            AND OCO = @lSemIni
            AND FRE = 2
            AND FLGANT <> 0


    SET @lExisteMes = (SELECT COUNT(*)
                        FROM TACOANT INNER JOIN TANT ON TACOANT.IDEANT = TANT.IDEANT
                       WHERE TACOANT.IDEACO = @pIdeAco
                         AND TACOANT.DEL = 0
                         AND TANT.DAT BETWEEN @lMesIni AND @lMesFim
                         AND TANT.DEL = 0)

    if @lExisteMes = 0
         UPDATE TVALACO SET FLGANT = 0, UPDTME = GETDATE()
          WHERE IDEACO = @pIdeAco
            AND OCO = @lMesIni
            AND FRE = 1
            AND FLGANT <> 0

END

GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[INTEGRIDADE_DESMARCARANT]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[INTEGRIDADE_DESMARCARANT]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: INTEGRIDADE_DESMARCARANT
   Propósito   : 
   Parâmetros  : 
   Retorno     : 
   Criação     : 
   Última Alt. : 
*/
CREATE PROCEDURE [dbo].[INTEGRIDADE_DESMARCARANT]
   (@pIdeAnt decimal(13),
    @pData datetime)
AS
BEGIN
    DECLARE @lDia DATETIME,
            @lSemIni DATETIME,
            @lSemFim DATETIME,
            @lMesIni DATETIME,
            @lMesFim DATETIME,
            @lExisteDia int,
            @lExisteSemana int,
            @lExisteMes int,
            @lIdeAco decimal(13),
            @lIdeAcoAnt decimal(13)
    
    DECLARE cursor_tacoant CURSOR FOR
          select TACOANT.IDEACOANT,
                  TACOANT.IDEACO                  
             from TACOANT
            where TACOANT.IDEANT = @pIdeAnt            
    
    
    SET @lDia = @pData  
    SET @lSemIni = DATEADD(DAY, (DATEPART(WeekDay, @lDia) * (-1)) + 1, @lDia)
    SET @lSemFim = @lSemIni + 6;
    SET @lMesIni = CAST(CONVERT(VARCHAR(6), @lDia, 112) + '01' AS DATETIME)
    SET @lMesFim = DATEADD(MONTH, 1, @lMesIni) - 1  

    if YEAR(@lSemIni) <> YEAR(@lDia)
        SET @lSemIni = CAST(CONVERT(VARCHAR(4), @lDia, 112) + '0101' AS DATETIME)
        
    if YEAR(@lSemIni) <> YEAR(@lSemFim)
        SET @lSemFim = @lMesFim


    OPEN cursor_tacoant

    FETCH NEXT FROM cursor_tacoant INTO @lIdeAcoAnt, @lIdeAco
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
    
    SET @lExisteDia = (SELECT COUNT(*) 
                         FROM TACOANT INNER JOIN TANT ON TANT.IDEANT = TACOANT.IDEANT
                        WHERE TACOANT.IDEACOANT <> @lIdeAcoAnt
                          AND TACOANT.IDEACO = @lIdeAco
                          AND TACOANT.DEL = 0
                          AND TANT.DAT = @lDia
                          AND TANT.DEL = 0)


    if @lExisteDia = 0
         UPDATE TVALACO SET FLGANT = 0, UPDTME = GETDATE()
          WHERE IDEACO = @lIdeAco
            AND OCO = @lDia
            AND FRE = 3
            AND FLGANT <> 0;
                        
    SET @lExisteSemana = (SELECT COUNT(*)
      FROM TACOANT INNER JOIN TANT ON TANT.IDEANT = TACOANT.IDEANT
     WHERE TACOANT.IDEACOANT <> @lIdeAcoAnt
       AND TACOANT.IDEACO =@lIdeAco
       AND TACOANT.DEL = 0
       AND TANT.DAT BETWEEN @lSemIni AND @lSemFim
       AND TANT.DEL = 0)

    if @lExisteSemana = 0
         UPDATE TVALACO SET FLGANT = 0, UPDTME = GETDATE()
          WHERE IDEACO = @lIdeAco
            AND OCO = @lSemIni
            AND FRE = 2
            AND FLGANT <> 0;

    SET @lExisteMes = (SELECT COUNT(*)
                       FROM TACOANT INNER JOIN TANT ON TANT.IDEANT = TACOANT.IDEANT
                      WHERE TACOANT.IDEACOANT <> @lIdeAcoAnt
                        AND TACOANT.IDEACO = @lIdeAco
                        AND TACOANT.DEL = 0             
                        AND TANT.DAT BETWEEN @lMesIni AND @lMesFim
                        AND TANT.DEL = 0)

    if @lExisteMes = 0
         UPDATE TVALACO SET FLGANT = 0, UPDTME = GETDATE()
          WHERE IDEACO = @lIdeAco
            AND OCO = @lMesIni
            AND FRE = 1
            AND FLGANT <> 0;
    
    FETCH NEXT FROM cursor_tacoant INTO @lIdeAcoAnt, @lIdeAco   

    END
    
    close cursor_tacoant
    deallocate cursor_tacoant
END

GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[INTEGRIDADE_DESMARCARVINCULOSSOLPRB]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[INTEGRIDADE_DESMARCARVINCULOSSOLPRB]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: INTEGRIDADE_DESMARCARVINCULOSSOLPRBxx
   Propósito   : 
   Parâmetros  : 
   Retorno     : 
   Criação     : 
   Última Alt. : 
*/
CREATE PROCEDURE [dbo].[INTEGRIDADE_DESMARCARVINCULOSSOLPRB]
   (@pIdeSolPrb decimal(13))
AS
BEGIN
    DECLARE @lExisteSolPrb int,
            @lExisteShwPlaMet int,
            @lIdeSolprb decimal(13),
            @lIdeAco decimal(13),
            @lFre int,
            @lOco datetime
    
    DECLARE cursor_tsolprbaco CURSOR FOR
        select TSOLPRBACO.IDESOLPRB,
               TSOLPRBACO.IDEACO,
               TSOLPRBACO.FRE,
               TSOLPRBACO.OCO
          from TSOLPRBACO
         where TSOLPRBACO.IDESOLPRB = @pIdeSolPrb;
    
    OPEN cursor_tsolprbaco

    FETCH NEXT FROM cursor_tsolprbaco INTO @lIdeSolprb, @lIdeAco, @lFre, @lOco

    WHILE @@FETCH_STATUS = 0
    BEGIN
    
        
    SET @lExisteSolPrb = (SELECT COUNT(*)
                           FROM TSOLPRBACO INNER JOIN TSOLPRB ON TSOLPRB.IDESOLPRB = TSOLPRBACO.IDESOLPRB
                          WHERE TSOLPRB.ETP < 90
                            AND TSOLPRBACO.IDESOLPRB <> @lIdeSolprb
                            AND TSOLPRBACO.IDEACO = @lIdeAco
                            AND TSOLPRBACO.FRE = @lFre
                            AND TSOLPRBACO.OCO = @lOco)
                           
   if @lExisteSolPrb = 0
        UPDATE TVALACO 
           SET FLGSOLPRB = 0
         WHERE IDEACO = @lIdeAco
           AND FRE = @lFre
           AND OCO = @lOco
           AND FLGSOLPRB <> 0
           
           
       SET @lExisteShwPlaMet = (SELECT COUNT(*)
                                  FROM TSOLPRBACO INNER JOIN TSOLPRB ON TSOLPRB.IDESOLPRB = TSOLPRBACO.IDESOLPRB
                                 WHERE TSOLPRB.ETP < 90
                                   AND TSOLPRBACO.IDESOLPRB <> @lIdeSolprb
                                   AND TSOLPRBACO.IDEACO = @lIdeAco
                                   AND TSOLPRBACO.SHWPLAMET <> 0)
          
            
       if @lExisteShwPlaMet = 0
            UPDATE TACO SET FLGPLAMET = 0, UPDTME = GETDATE() WHERE TACO.IDEACO = @lIdeAco AND TACO.FLGPLAMET <> 0     
    
    FETCH NEXT FROM cursor_tsolprbaco INTO @lIdeSolprb, @lIdeAco, @lFre, @lOco
    END;
    close cursor_tsolprbaco
    deallocate cursor_tsolprbaco
END


GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[INTEGRIDADE_DESMARCARVINCULOSSOLPRBACO]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[INTEGRIDADE_DESMARCARVINCULOSSOLPRBACO]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: INTEGRIDADE_DESMARCARVINCULOSSOLPRBACO
   Propósito   : 
   Parâmetros  : 
   Retorno     : 
   Criação     : 
   Última Alt. : 
*/
CREATE PROCEDURE [dbo].[INTEGRIDADE_DESMARCARVINCULOSSOLPRBACO]
   (@pIdeAco decimal(13),
    @pFre int,
    @pOco datetime)
AS
BEGIN
    DECLARE @lExisteSolPrb bit
     
     SET @lExisteSolPrb = (select COUNT(IDESOLPRBACO)
                            from TSOLPRBACO
                           where TSOLPRBACO.IDEACO = @pIdeAco
                             and TSOLPRBACO.SHWPLAMET <> 0);

       if @lExisteSolPrb = 0 
       begin 
            UPDATE TACO SET FLGPLAMET = 0, UPDTME = GETDATE() WHERE TACO.IDEACO = @pIdeAco AND TACO.FLGPLAMET <> 0;
       end    
        
       SET @lExisteSolPrb = (select count(*)
                               from TSOLPRBACO
                              where TSOLPRBACO.IDEACO = @pIdeAco
                                and TSOLPRBACO.FRE = @pFre
                                and TSOLPRBACO.OCO = @pOco)

       if @lExisteSolPrb = 0
           UPDATE TVALACO
              SET FLGSOLPRB = 0,
                  UPDTME = GETDATE()
            WHERE TVALACO.IDEACO = @pIdeAco
              AND TVALACO.FRE = @pFre
              AND TVALACO.OCO = @pOco
              AND TVALACO.FLGSOLPRB <> 0;          

END

GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[INTEGRIDADE_MARCARACOANT]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[INTEGRIDADE_MARCARACOANT]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: INTEGRIDADE_MARCARACOANT
   Propósito   : 
   Parâmetros  : 
   Retorno     : 
   Criação     : 
   Última Alt. : 
*/
CREATE PROCEDURE [dbo].[INTEGRIDADE_MARCARACOANT]
   (@pIdeAco decimal(13),
    @pData datetime)
AS
BEGIN
    DECLARE @lDia DATETIME,
            @lSem DATETIME,
            @lMes DATETIME
    
    SET @lDia = @pData;
    SET @lSem = DATEADD(DAY, (DATEPART(WeekDay, @lDia) * (-1)) + 1, @lDia)
    SET @lMes = CAST(CONVERT(VARCHAR(6), @lDia, 112) + '01' AS DATETIME)

    if YEAR(@lSem) <> YEAR(@lDia)
        SET @lSem = CAST(CONVERT(VARCHAR(4), @lDia, 112) + '0101' AS DATETIME)

    UPDATE TVALACO SET FLGANT = 1, UPDTME = GETDATE()
      WHERE IDEACO = @pIdeAco
        AND FLGANT = 0
        AND ((OCO = @lDia AND FRE = 3 AND FLGANT = 0)
         OR ( OCO = @lSem AND FRE = 2 AND FLGANT = 0)
         OR ( OCO = @lMes AND FRE = 1 AND FLGANT = 0));        

END

GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[INTEGRIDADE_MARCARANT]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[INTEGRIDADE_MARCARANT]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: INTEGRIDADE_MARCARANT
   Propósito   : 
   Parâmetros  : 
   Retorno     : 
   Criação     : 
   Última Alt. : 
*/
CREATE PROCEDURE [dbo].[INTEGRIDADE_MARCARANT]
   (@pIdeAnt decimal(13),
    @pData datetime)
AS
BEGIN
    DECLARE @lDia DATETIME,
            @lSem DATETIME,         
            @lMes DATETIME
    
    SET @lDia = @pData
    SET @lSem = DATEADD(DAY, (DATEPART(WeekDay, @lDia) * (-1)) + 1, @lDia)
    SET @lMes = CAST(CONVERT(VARCHAR(6), @lDia, 112) + '01' AS DATETIME)

    if YEAR(@lSem) <> YEAR(@lDia)
        SET @lSem = CAST(CONVERT(VARCHAR(4), @lDia, 112) + '0101' AS DATETIME)      
    
    UPDATE TVALACO SET FLGANT = 1, UPDTME = GETDATE()
        WHERE IDEACO IN (SELECT TACOANT.IDEACO FROM TACOANT WHERE TACOANT.IDEANT = @pIdeAnt AND TACOANT.DEL = 0)
          AND OCO = @lDia
          AND FRE = 3
          AND FLGANT = 0

   UPDATE TVALACO SET FLGANT = 1, UPDTME = GETDATE()
    WHERE IDEACO IN (SELECT TACOANT.IDEACO FROM TACOANT WHERE TACOANT.IDEANT = @pIdeAnt AND TACOANT.DEL = 0)
      AND OCO = @lSem
      AND FRE = 2
      AND FLGANT = 0

   UPDATE TVALACO SET FLGANT = 1, UPDTME = GETDATE()
    WHERE IDEACO IN (SELECT TACOANT.IDEACO FROM TACOANT WHERE TACOANT.IDEANT = @pIdeAnt AND TACOANT.DEL = 0)
      AND OCO = @lMes
      AND FRE = 1
      AND FLGANT = 0
END

GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[INTEGRIDADE_MARCARPLAMET]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[INTEGRIDADE_MARCARPLAMET]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: INTEGRIDADE_MARCARPLAMET
   Propósito   : 
   Parâmetros  : 
   Retorno     : 
   Criação     : 
   Última Alt. : 
*/
CREATE PROCEDURE [dbo].[INTEGRIDADE_MARCARPLAMET]
    @pIdeAco decimal(13)
AS
BEGIN
    UPDATE TACO SET FLGPLAMET = 1, UPDTME = GETDATE() WHERE TACO.IDEACO = @pIdeAco AND TACO.FLGPLAMET = 0;
END

GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[INTEGRIDADE_MARCARSOLPRB]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[INTEGRIDADE_MARCARSOLPRB]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: INTEGRIDADE_MARCARSOLPRB
   Propósito   : 
   Parâmetros  : 
   Retorno     : 
   Criação     : 
   Última Alt. : 
*/
CREATE PROCEDURE [dbo].[INTEGRIDADE_MARCARSOLPRB]
   (@pIdeAco decimal(13),
    @pFre int,
    @pOco datetime)
AS
BEGIN   
    UPDATE TVALACO
           SET FLGSOLPRB = 1, 
               UPDTME = GETDATE() 
         WHERE TVALACO.IDEACO = @pIdeAco 
           AND TVALACO.FRE = @pFre 
           AND TVALACO.OCO = @pOco 
           AND TVALACO.FLGSOLPRB = 0
END

GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[INTEGRIDADE_MARCARVINCULOSSOLPRB]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[INTEGRIDADE_MARCARVINCULOSSOLPRB]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: INTEGRIDADE_MARCARVINCULOSSOLPRB
   Propósito   : 
   Parâmetros  : 
   Retorno     : 
   Criação     : 
   Última Alt. : 
*/
CREATE PROCEDURE [dbo].[INTEGRIDADE_MARCARVINCULOSSOLPRB]
   (@pIdeSolPrb decimal(13))
AS
BEGIN
    DECLARE @lIdeSolprb decimal(13),
            @lIdeAco decimal(13),
            @lFre int,
            @lOco datetime
    
    DECLARE cursor_tsolprbaco CURSOR FOR
        select TSOLPRBACO.IDESOLPRB,
               TSOLPRBACO.IDEACO,
               TSOLPRBACO.FRE,
               TSOLPRBACO.OCO
          from TSOLPRBACO
         where TSOLPRBACO.IDESOLPRB = @pIdeSolPrb;
    
    OPEN cursor_tsolprbaco

    FETCH NEXT FROM cursor_tsolprbaco INTO @lIdeSolprb, @lIdeAco, @lFre, @lOco

    WHILE @@FETCH_STATUS = 0
    BEGIN
                           
    UPDATE TVALACO 
       SET FLGSOLPRB = 1,
           UPDTME = GETDATE()
     WHERE IDEACO = @lIdeAco
       AND FRE = @lFre
       AND OCO = @lOco
       AND FLGSOLPRB = 0;

 
    UPDATE TACO SET FLGPLAMET = 1, UPDTME = GETDATE() WHERE TACO.IDEACO = @lIdeAco AND TACO.FLGPLAMET = 0;
 
    
    FETCH NEXT FROM cursor_tsolprbaco INTO @lIdeSolprb, @lIdeAco, @lFre, @lOco
    END;
    close cursor_tsolprbaco
    deallocate cursor_tsolprbaco
END

GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[MANUTENCAO_AddUniUsu]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[MANUTENCAO_AddUniUsu]
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[MANUTENCAO_AddUniUsu](@pIdeUni DECIMAL,
                                             @pIdeSpr DECIMAL,
                                             @pPropagarPermissaoDeAcesso INT,
                                                        @pIdeEmp DECIMAL,
                                                        @pPkIdentificator VARCHAR(3),
                                                        @pSisNme VARCHAR(3))
AS
DECLARE @lIdeUsu DECIMAL,
          @lContador INT,
          @lUpdDta INT

BEGIN
    DECLARE CursorUsuariosUnidades
        CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR

    SELECT vUsuUni.IdeUsu, MAX(vUsuUni.UpdDta) UpdDta
      FROM (SELECT DISTINCT tUsuSis.IdeUsu, 1 UpdDta
                      FROM tUsuSis INNER JOIN tUsu ON tUsuSis.IdeUsu = tUsu.IdeUsu 
                                   INNER JOIN tSis ON tUsuSis.IdeSis = tSis.IdeSis
                     WHERE (tUsuSis.Niv = 1 AND tUsu.IdeEmp = @pIdeEmp AND tSis.IntNme = @pSisNme)
            UNION
            SELECT DISTINCT tUsuUni.IdeUsu, CASE WHEN tUsuUni.UpdDta = 0 THEN 0 ELSE 1 END UpdDta
                       FROM tUsuUni
			     INNER JOIN tUsu ON tUsuUni.IdeUsu = tUsu.IdeUsu
                        WHERE tUsuUni.IdeUni = @pIdeSpr
                          AND @pSisNme = 'SIG'
                      AND @pPropagarPermissaoDeAcesso = 1) vUsuUni
                 GROUP BY vUsuUni.IdeUsu

   SELECT @lContador = COUNT(DISTINCT vUsuUni.IdeUsu)
      FROM (SELECT DISTINCT tUsuSis.IdeUsu, 1 UpdDta
                      FROM tUsuSis INNER JOIN tUsu ON tUsuSis.IdeUsu = tUsu.IdeUsu 
                                   INNER JOIN tSis ON tUsuSis.IdeSis = tSis.IdeSis
                     WHERE (tUsuSis.Niv = 1 AND tUsu.IdeEmp = @pIdeEmp AND tSis.IntNme = @pSisNme)
            UNION
            SELECT DISTINCT tUsuUni.IdeUsu, CASE WHEN tUsuUni.UpdDta = 0 THEN 0 ELSE 1 END UpdDta
                       FROM tUsuUni
			     INNER JOIN tUsu ON tUsuUni.IdeUsu = tUsu.IdeUsu
                        WHERE tUsuUni.IdeUni = @pIdeSpr
                          AND @pSisNme = 'SIG'
                      AND @pPropagarPermissaoDeAcesso = 1) vUsuUni                 

    OPEN CursorUsuariosUnidades
    FETCH CursorUsuariosUnidades INTO @lIdeUsu, @lUpdDta
    WHILE @@FETCH_STATUS = 0
    BEGIN
        INSERT INTO tUsuUni(IdeUsu, IdeUni, UpdDta, UpdTme) VALUES(@lIdeUsu, @pIdeUni, @lUpdDta, GETDATE())
        FETCH CursorUsuariosUnidades INTO @lIdeUsu, @lUpdDta
    END
    CLOSE CursorUsuariosUnidades
    DEALLOCATE CursorUsuariosUnidades
END
GO




/****** Object:  StoredProcedure [dbo].[MANUTENCAO_AdicionarParticipantesUnidades]    Script Date: 01/21/2011 15:57:53 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[MANUTENCAO_AdicionarParticipantesUnidades]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[MANUTENCAO_AdicionarParticipantesUnidades]
GO
/****** Object:  StoredProcedure [dbo].[MANUTENCAO_AdicionarParticipantesUnidades]    Script Date: 01/21/2011 15:57:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[MANUTENCAO_AdicionarParticipantesUnidades](@pIdeUni          DECIMAL,
                                                                  @pIdeUsu          DECIMAL,
                                                                  @pIdeUniTyp       DECIMAL,
                                                                  @pIdeEmp          DECIMAL,
                                                                  @pDtaEnt          DATETIME,
                                                                  @pFun             INT,
                                                                  @pStt             INT,
                                                                  @pPkIdentificator VARCHAR)
AS
DECLARE @lIdeUni DECIMAL(13),
        @lIdePar DECIMAL(13),
        @lCount  INT

BEGIN   
   DECLARE CursorUnidades
   CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
    SELECT tUni.IdeUni
      FROM tUni 
      WHERE tUni.IdeUniTyp = @pIdeUniTyp 
        AND tUni.IdeEmp = @pIdeEmp
    
    IF @pIdeUni = 0 
    BEGIN
        OPEN CursorUnidades
        FETCH CursorUnidades INTO @lIdeUni
        WHILE @@FETCH_STATUS = 0
        BEGIN

            SELECT @lCount = COUNT(1) FROM tPar WHERE tPar.ideuni = @lIdeUni AND tPar.IdeUsu = @pIdeUsu AND tPar.Fun = @pFun
            IF @lCount = 0 
            BEGIN
                EXEC [dbo].[GetTableIde] 'tPar', 1, @pPkIdentificator, @lIdePar OUTPUT
                INSERT INTO tPar(IdePar, IdeUni, IdeUsu, Fun, DatEnt, Stt, UpdTme) VALUES(@lIdePar, @lIdeUni, @pIdeUsu, @pFun, @pDtaEnt, @pStt, GETDATE())
            END
            
            SET @lCount = 0 
        FETCH CursorUnidades INTO @lIdeUni
        END
        
        CLOSE CursorUnidades
        DEALLOCATE CursorUnidades
    END
    ELSE
    BEGIN
        SELECT @lCount = COUNT(1) FROM tPar WHERE tPar.ideuni = @pIdeUni AND tPar.IdeUsu = @pIdeUsu AND tPar.Fun = @pFun
        IF @lCount = 0 
        BEGIN
            EXEC [dbo].[GetTableIde] 'tPar', 1, @pPkIdentificator, @lIdePar OUTPUT
            INSERT INTO tPar(IdePar, IdeUni, IdeUsu, Fun, DatEnt, Stt, UpdTme) VALUES(@lIdePar, @pIdeUni, @pIdeUsu, @pFun, @pDtaEnt, @pStt, GETDATE())
        END
    END
END
GO




/****** Object:  StoredProcedure [dbo].[MANUTENCAO_AdicionarUnidades]    Script Date: 02/11/2009 10:59:52 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[MANUTENCAO_AdicionarUnidades]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[MANUTENCAO_AdicionarUnidades]
GO
/****** Object:  StoredProcedure [dbo].[MANUTENCAO_AdicionarUnidades]    Script Date: 02/11/2009 10:59:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[MANUTENCAO_AdicionarUnidades](@pIdeUni DECIMAL,
                                                     @pIdeUsu DECIMAL,
                                                     @pUpdDta BIT,
                                                     @pIdeUniTyp DECIMAL,
                                                     @pIdeEmp DECIMAL,
                                                     @pSubordinadas BIT,
                                                     @pIdePlaGes DECIMAL)
AS
DECLARE @lIdeUniAce DECIMAL,
        @lIdeUniUsu DECIMAL


BEGIN

    IF @pIdeUni = 0
    BEGIN
        IF @pIdePlaGes = 0
        BEGIN
            DECLARE CursorUnidades
            CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
            SELECT tUni.IdeUni IdeUniAce,
                   vUsuUni.IdeUni IdeUniUsu
              FROM tUni LEFT JOIN (SELECT IdeUni FROM tUsuUni WHERE IdeUsu = @pIdeUsu) vUsuUni ON tUni.IdeUni = vUsuUni.IdeUni
             WHERE tUni.IdeUniTyp = @pIdeUniTyp 
               AND tUni.IdeEmp = @pIdeEmp
        END
        ELSE
        BEGIN
            DECLARE CursorUnidades
            CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
            SELECT tUniPlaGes.IdeUni IdeUniAce,
                   vUsuUni.IdeUni IdeUniUsu
              FROM tUniPlaGes LEFT JOIN (SELECT IdeUni FROM tUsuUni WHERE IdeUsu = @pIdeUsu) vUsuUni ON tUniPlaGes.IdeUni = vUsuUni.IdeUni
                             INNER JOIN tUni ON tUni.IdeUni = tUniPlaGes.IdeUni
             WHERE tUniPlaGes.IdePlaGes = @pIdePlaGes
               AND tUni.IdeUniTyp = @pIdeUniTyp 
               AND tUni.IdeEmp = @pIdeEmp
        END
    END
    ELSE
    BEGIN
        IF @pSubordinadas <> 0
        BEGIN
            DECLARE CursorUnidades
            CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
            SELECT tUniPlaGes.IdeUni IdeUniAce,
                   vUsuUni.IdeUni IdeUniUsu
              FROM tUniPlaGes LEFT JOIN (SELECT IdeUni FROM tUsuUni WHERE IdeUsu = @pIdeUsu) vUsuUni ON tUniPlaGes.IdeUni = vUsuUni.IdeUni
             WHERE tUniPlaGes.IdePlaGes = @pIdePlaGes
               AND tUniPlaGes.IdeUni IN (SELECT IdeUni FROM dbo.DefinirArvoreSubordinadas(@pIdeUni, @pIdePlaGes))
        END
    END

    IF @pIdeUni = 0 OR (@pIdeUni <> 0 AND @pSubordinadas <> 0)
    BEGIN
        OPEN CursorUnidades
        FETCH CursorUnidades INTO @lIdeUniAce, @lIdeUniUsu
        WHILE @@FETCH_STATUS = 0
        BEGIN

            IF @lIdeUniUsu IS NOT NULL
            BEGIN
                UPDATE tUsuUni SET UpdDta = @pUpdDta, UpdTme = GETDATE() WHERE IdeUsu = @pIdeUsu AND IdeUni = @lIdeUniUsu
            END
            ELSE
            BEGIN
                INSERT INTO tUsuUni(IdeUsu, IdeUni, UpdDta, UpdTme) VALUES(@pIdeUsu, @lIdeUniAce, @pUpdDta, GETDATE())
            END

            FETCH CursorUnidades INTO @lIdeUniAce, @lIdeUniUsu
        END
        CLOSE CursorUnidades
        DEALLOCATE CursorUnidades
    END
	 ELSE IF EXISTS (SELECT IdeUsu FROM tUsuUni WHERE IdeUsu = @pIdeUsu AND IdeUni = @pIdeUni)
		 UPDATE tUsuUni SET UpdDta = @pUpdDta, UpdTme = GETDATE() WHERE IdeUsu = @pIdeUsu AND IdeUni = @pIdeUni	
	 ELSE
     BEGIN
		 INSERT INTO tUsuUni(IdeUsu, IdeUni, UpdDta, UpdTme) VALUES(@pIdeUsu, @pIdeUni, @pUpdDta, GETDATE())
     END

END
GO


 

IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[MANUTENCAO_AdicionarUnidadesGruUsu]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[MANUTENCAO_AdicionarUnidadesGruUsu]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[MANUTENCAO_AdicionarUnidadesGruUsu](@pIdeUni DECIMAL,
                                                            @pIdeGruUsu DECIMAL,
                                                            @pUpdDta BIT,
                                                            @pIdeUniTyp DECIMAL,
                                                            @pIdeEmp DECIMAL,
                                                            @pSubordinadas BIT,
                                                            @pIdePlaGes DECIMAL)
AS
DECLARE @lIdeUniAce DECIMAL,
        @lIdeUniGruUsu DECIMAL


BEGIN

    IF @pIdeUni = 0
    BEGIN
        IF @pIdePlaGes = 0
        BEGIN
            DECLARE CursorUnidadesGruUsu
            CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
            SELECT tUni.IdeUni IdeUniAce,
                   vGruUsuUni.IdeUni IdeUniGruUsu
              FROM tUni LEFT JOIN (SELECT IdeUni FROM tGruUsuUni WHERE IdeGruUsu = @pIdeGruUsu) vGruUsuUni ON tUni.IdeUni = vGruUsuUni.IdeUni
               AND tUni.IdeUniTyp = @pIdeUniTyp 
               AND tUni.IdeEmp = @pIdeEmp
        END
        ELSE
        BEGIN
            DECLARE CursorUnidadesGruUsu
            CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
            SELECT tUniPlaGes.IdeUni IdeUniAce,
                   vGruUsuUni.IdeUni IdeUniGruUsu
              FROM tUniPlaGes LEFT JOIN (SELECT IdeUni FROM tGruUsuUni WHERE IdeGruUsu = @pIdeGruUsu) vGruUsuUni ON tUniPlaGes.IdeUni = vGruUsuUni.IdeUni
                             INNER JOIN tUni ON tUni.IdeUni = tUniPlaGes.IdeUni
               WHERE tUniPlaGes.IdePlaGes = @pIdePlaGes
               AND tUni.IdeUniTyp = @pIdeUniTyp 
               AND tUni.IdeEmp = @pIdeEmp
        END
    END
    ELSE
    BEGIN
        IF @pSubordinadas <> 0
        BEGIN
            DECLARE CursorUnidadesGruUsu
            CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
            SELECT tUniPlaGes.IdeUni IdeUniAce,
                   vGruUsuUni.IdeUni IdeUniUsu
              FROM tUniPlaGes LEFT JOIN (SELECT IdeUni FROM tGruUsuUni WHERE IdeGruUsu = @pIdeGruUsu) vGruUsuUni ON tUniPlaGes.IdeUni = vGruUsuUni.IdeUni
             WHERE tUniPlaGes.IdePlaGes = @pIdePlaGes
               AND tUniPlaGes.IdeUni IN (SELECT IdeUni FROM dbo.DefinirArvoreSubordinadas(@pIdeUni, @pIdePlaGes))
        END
    END

    IF @pIdeUni = 0 OR (@pIdeUni <> 0 AND @pSubordinadas <> 0)
    BEGIN
        OPEN CursorUnidadesGruUsu
        FETCH CursorUnidadesGruUsu INTO @lIdeUniAce, @lIdeUniGruUsu
        WHILE @@FETCH_STATUS = 0
        BEGIN

            IF @lIdeUniGruUsu IS NOT NULL
            BEGIN
                UPDATE tGruUsuUni SET UpdDta = @pUpdDta, UpdTme = GETDATE() WHERE IdeGruUsu = @pIdeGruUsu AND IdeUni = @lIdeUniGruUsu
            END
            ELSE
            BEGIN
                INSERT INTO tGruUsuUni(IdeGruUsu, IdeUni, UpdDta, UpdTme) VALUES(@pIdeGruUsu, @lIdeUniAce, @pUpdDta, GETDATE())
            END

            FETCH CursorUnidadesGruUsu INTO @lIdeUniAce, @lIdeUniGruUsu
        END
        CLOSE CursorUnidadesGruUsu
        DEALLOCATE CursorUnidadesGruUsu
    END
    ELSE
    BEGIN
		IF NOT EXISTS (SELECT IdeGruUsu FROM tGruUsuUni WHERE IdeGruUsu = @pIdeGruUsu AND IdeUni = @pIdeUni)
			INSERT INTO tGruUsuUni(IdeGruUsu, IdeUni, UpdDta, UpdTme) VALUES(@pIdeGruUsu, @pIdeUni, @pUpdDta, GETDATE())
    END
END
GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[MANUTENCAO_AtualizaTIDS]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[MANUTENCAO_AtualizaTIDS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: MANUTENCAO_AtualizaTIDS
   Prop�sito   : Atualizar coluna NewIde da tabela tIds
   Par�metros  : pPkIdentificator-Iniciais das Pk's que ser�o criadas
   Retorno     : (nenhum)
   Cria��o     : 17/12/2009 - rangel
   �ltima Alt. : 16/12/2010 - rangel */

CREATE PROCEDURE [dbo].[MANUTENCAO_AtualizaTIDS] (@pPkIdentificator VARCHAR(3))
AS

DECLARE @lTableName VARCHAR(50),
        @lExiste INT,
        @lIdeName VARCHAR(50),
        @lQuery VARCHAR(2000)

DECLARE CursorTables CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
    SELECT UPPER(TBLNME) TblNme FROM tIds ORDER BY TblNme

OPEN CursorTables
FETCH NEXT FROM CursorTables INTO @lTableName
WHILE @@fetch_status = 0
BEGIN
    SET @lIdeName = 'IDE' + substring(@lTableName, 2, len(@lTableName))
    SELECT @lExiste = COUNT(*) FROM syscolumns WHERE id = object_id(@lTableName) AND UPPER(name) = @lIdeName    
    IF @lExiste <> 0
    BEGIN
        SET @lQuery = 'DECLARE @lMaxIde DECIMAL(13)
                       BEGIN
                         SELECT @lMaxIde = ISNULL(MAX(' + @lIdeName + ')+1, 0) FROM ' + @lTableName + ' WHERE ' + @lIdeName + ' LIKE ' + char(39) + @pPkIdentificator + '__________' + char(39) + '
                         IF @lMaxIde <> 0
                         BEGIN
                           UPDATE tIds
                           SET NewIde = @lMaxIde - ' + @pPkIdentificator + '0000000000
                           WHERE UPPER(TblNme) = ' + char(39) + @lTableName + char(39) + '
                         END
                         ELSE
                         BEGIN
                           DELETE tIds WHERE UPPER(TblNme) = ' + char(39) + @lTableName + char(39) + '
                         END
                       END'
        EXEC (@lQuery)
    END
    ELSE
    BEGIN
        DELETE tIds WHERE TblNme = @lTableName
    END

    FETCH NEXT FROM CursorTables INTO @lTableName
END
CLOSE CursorTables
DEALLOCATE CursorTables
GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[MANUTENCAO_GerenciarRegrasPorGruUsu]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].MANUTENCAO_GerenciarRegrasPorGruUsu
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* 
Procedimento: MANUTENCAO_GerenciarRegrasPorUsuario
Prop�sito   : Fazer o gerenciamento das regras do sistema do Grupo de Usu�rio adicionando ou removendo de acordo com o acesso
Par�metros  : pIdeUni - Identificador da UG
			  pIdeUniTyp - Tipo da Unidade
			  pIdeGruUsu - Identificador do Grupo de Usu�rio
			  pIdeRegSis - Identificador da regra
              pIdePlaGes- Identificador do Plano de Gest�o   			  
              pIdeEmp - Identificador da Empresa         
              pSubordinadas -Incluir ou n�o as UG's subordinadas
			  pAcesso - Permiss�o da regra
Cria��o     : 12/07/2013 - Eduardo C�sar/ Luiz Carneiro
*/
CREATE PROCEDURE MANUTENCAO_GerenciarRegrasPorGruUsu(@pIdeUni			DECIMAL(13),
										@pIdeUniTyp		DECIMAL(13),
										@pIdeGruUsu			DECIMAL(13),
										@pIdeRegSis		DECIMAL(13),
										@pIdePlaGes		DECIMAL(13),
										@pIdeEmp			DECIMAL(13),
										@pSubordinadas	INT,
										@pAcesso			INT)
	AS
	DECLARE @lIdeGruUsuUni DECIMAL(13)

    DECLARE CursorUnidades CURSOR GLOBAL FAST_FORWARD READ_ONLY FOR 
	SELECT IdeGruUsuUni
	  FROM tGruUsuUni
	 INNER JOIN tUni ON tGruUsuUni.IdeUni = tUni.IdeUni
	 INNER JOIN tUniPlaGes ON tUniPlaGes.IdeUni = tUni.IdeUni
	 WHERE tGruUsuUni.IdeGruUsu = @pIdeGruUsu
	   AND tUniPlaGes.IdePlaGes = @pIdePlaGes
	   AND tUni.IdeUniTyp = @pIdeUniTyp
	   AND tUni.IdeEmp = @pIdeEmp
	   AND (@pIdeUni IS NULL 
			OR ((@pSubordinadas = 0 AND tGruUsuUni.IdeUni = @pIdeUni ) OR (@pSubordinadas <> 0 AND tGruUsuUni.IdeUni IN (SELECT IDEUNI FROM dbo.DefinirArvoreSubordinadas(@pIdeUni, @pIdePlaGes)))))
	   AND ((@pAcesso <> 0 AND NOT EXISTS (SELECT 1 FROM tGruUsuUniRegSis WHERE tGruUsuUniRegSis.IdeRegSis = @pIdeRegSis AND tGruUsuUniRegSis.IdeGruUsuUni = tGruUsuUni.IdeGruUsuUni))
			OR
			(@pAcesso = 0 AND EXISTS (SELECT 1 FROM tGruUsuUniRegSis WHERE tGruUsuUniRegSis.IdeRegSis = @pIdeRegSis AND tGruUsuUniRegSis.IdeGruUsuUni = tGruUsuUni.IdeGruUsuUni)));


   BEGIN
		OPEN CursorUnidades
		FETCH CursorUnidades INTO @lIdeGruUsuUni
		WHILE @@FETCH_STATUS = 0
		BEGIN		             
			IF @pAcesso = 0
				DELETE tGruUsuUniRegSis where tGruUsuUniRegSis.IdeGruUsuUni = @lIdeGruUsuUni AND tGruUsuUniRegSis.IdeRegSis = @pIdeRegSis
			ELSE
				INSERT INTO tGruUsuUniRegSis(IdeGruUsuUni, IdeRegSis) values (@lIdeGruUsuUni, @pIdeRegSis)
			FETCH CursorUnidades INTO @lIdeGruUsuUni		
		END 
		CLOSE CursorUnidades
		DEALLOCATE CursorUnidades
    END
GO



IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[MANUTENCAO_GerenciarRegrasPorUsuario]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[MANUTENCAO_GerenciarRegrasPorUsuario]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* 
Procedimento: MANUTENCAO_GerenciarRegrasPorUsuario
Prop�sito   : Fazer o gerenciamento das regras do sistema do Usu�rio adicionando ou removendo de acordo com o acesso
Par�metros  : pIdeUni - Identificador da UG
			  pIdeUniTyp - Tipo da Unidade
			  pIdeUsu - Identificador do Usu�rio
			  pIdeRegSis - Identificador da regra
              pIdePlaGes- Identificador do Plano de Gest�o   			  
              pIdeEmp - Identificador da Empresa         
              pSubordinadas -Incluir ou n�o as UG's subordinadas
			  pAcesso - Permiss�o da regra
Cria��o     : 12/07/2013 - Eduardo C�sar/ Luiz Carneiro
*/
CREATE PROCEDURE MANUTENCAO_GerenciarRegrasPorUsuario(@pIdeUni			DECIMAL(13),
										@pIdeUniTyp		DECIMAL(13),
										@pIdeUsu			DECIMAL(13),
										@pIdeRegSis		DECIMAL(13),
										@pIdePlaGes		DECIMAL(13),
										@pIdeEmp			DECIMAL(13),
										@pSubordinadas	INT,
										@pAcesso			INT)
	AS
	DECLARE @lIdeUni DECIMAL(13)

    DECLARE CursorUnidades CURSOR GLOBAL FAST_FORWARD READ_ONLY FOR 
    SELECT IdeUsuUni
	  FROM tUsuUni
	 INNER JOIN tUni ON tUsuUni.IdeUni = tUni.IdeUni
	 INNER JOIN tUniPlaGes ON tUniPlaGes.IdeUni = tUni.IdeUni
	 WHERE tUsuUni.IdeUsu = @pIdeUsu
	   AND tUniPlaGes.IdePlaGes = @pIdePlaGes
	   AND tUni.IdeUniTyp = @pIdeUniTyp
	   AND tUni.IdeEmp = @pIdeEmp
	   AND (@pIdeUni IS NULL 
			OR ((@pSubordinadas = 0 AND tUsuUni.IdeUni = @pIdeUni ) OR (@pSubordinadas <> 0 AND tUsuUni.IdeUni IN (SELECT IDEUNI FROM dbo.DefinirArvoreSubordinadas(@pIdeUni, @pIdePlaGes)))))
	   AND ((@pAcesso <> 0 AND NOT EXISTS (SELECT 1 FROM tUsuUniRegSis WHERE tUsuUniRegSis.IdeRegSis = @pIdeRegSis AND tUsuUniRegSis.IdeUsuUni = tUsuUni.IdeUsuUni))
			OR
			(@pAcesso = 0 AND EXISTS (SELECT 1 FROM tUsuUniRegSis WHERE tUsuUniRegSis.IdeRegSis = @pIdeRegSis AND tUsuUniRegSis.IdeUsuUni = tUsuUni.IdeUsuUni)))
	BEGIN
		OPEN CursorUnidades
		FETCH CursorUnidades INTO @lIdeUni
		WHILE @@FETCH_STATUS = 0
		BEGIN		             
			IF @pAcesso = 0
				DELETE tUsuUniRegSis where tUsuUniRegSis.IdeUsuUni = @lIdeUni AND tUsuUniRegSis.IdeRegSis = @pIdeRegSis
			ELSE
				INSERT INTO tUsuUniRegSis(IdeUsuUni, IdeRegSis) values (@lIdeUni, @pIdeRegSis)
			FETCH CursorUnidades INTO @lIdeUni		
		END 
		CLOSE CursorUnidades
		DEALLOCATE CursorUnidades
    END
GO



/****** Object:  StoredProcedure [dbo].[RELATORIOS_RelStatusAcoes]    Script Date: 10/21/2008 14:49:13 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RELATORIOS_RelStatusAcoes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[RELATORIOS_RelStatusAcoes]
GO
/****** Object:  StoredProcedure [dbo].[RELATORIOS_RelStatusAcoes]    Script Date: 10/21/2008 14:49:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* Função     : RELATORIOS_RelStatusAcoes
   Propósito  : Retorna os Status das Acoes sob a Responsabilidade de uma Unidade Gerencial e/ou suas subordinadas até o 3o nível
   Parâmetros : pIdeUni-Identificador da Unidade Gerencial
                pSub-Indica se o relatório deve retornar dados apenas da UG selecionada ou de suas subordinadas até o 3o nível
                pIdePlaGes-Identificador do Plano de Gestão corrente
                pIdePlaGesFiltro-Identificador do Plano de Gestão selecionado no filtro (pode ser nulo)
                pPerIni-Período de Início definido pelo Usuário (pode ser nulo)
                pPerFin-Período de Término definido pelo usuário (pode ser nulo)
                pIdeUsu-Identificador do Usuário responsável pelas Soluções de Problema ou pelas Ações
                pCls-Classificação sob as quais será feita a pesquisa
   Criação    : 22/11/2010 - mar
   Última Alt.: 22/11/2010 - mar */

CREATE PROCEDURE [dbo].[RELATORIOS_RelStatusAcoes]
                           (@pIdeUni          DECIMAL(13),
                            @pSub             INT,
                            @pIdePlaGes       DECIMAL(13),
                            @pIdePlaGesFiltro DECIMAL(13),
                            @pPerIni          DATETIME,
                            @pPerFin          DATETIME,
                            @pIdeUsu          DECIMAL(13),
                            @pCls             DECIMAL(13),
                            @pIsAdministrador INT,
                            @pIdeUsuLogado    DECIMAL(13),
                            @pExcel           INT,
                            @pPortalSim30     INT)
AS
    DECLARE @lLvl                   INT,
            @lPerIni                DATETIME,
            @lPerFin                DATETIME,
            
            @lHoje                  VARCHAR(50),
    
            @lStrQuery              VARCHAR(8000),
            @lCondicaoAcoes1        VARCHAR(1000),
            @lCondicaoAcoes2        VARCHAR(1000),
            
            @lCalculoSubtotal       INT,

            @lOrd                   INT,
            @lSig                   VARCHAR(50),
            @lIdeUni                DECIMAL(13),
            @lCriados               INT,
            @lAgingMonths           INT,
            @lEmAberto              INT,
            @lReprogramadas         INT,
            @lEmAndamento           INT,
            @lEmAtraso              INT,
            @lConcluidos            INT, 

            @lTotalCriados          INT,
            @lTotalAgingMonths      INT,
            @lTotalEmAberto         INT,
            @lTotalReprogramadas    INT,
            @lTotalEmAndamento      INT,
            @lTotalEmAtraso         INT,
            @lTotalConcluidos       INT, 

            @lSubTotalCriados       INT,
            @lSubTotalAgingMonths   INT,
            @lSubTotalEmAberto      INT,
            @lSubTotalReprogramadas INT,
            @lSubTotalEmAndamento   INT,
            @lSubTotalEmAtraso      INT,
            @lSubTotalConcluidos    INT, 

            @lError         INT

   DECLARE @Dados TABLE (ORD                    INT, 
                         NMEUSU                 VARCHAR(100),
                         IDEUSU                 DECIMAL(13),
                         SIG                    VARCHAR(75),
                         IDEUNI                 DECIMAL(13),
                         TOT                    INT, 
                         Criados                INT, 
                         AgingMonths            INT,
                         EmAberto               INT,
                         Reprogramadas          INT,
                         EmAndamento            INT, 
                         EmAtraso               INT, 
                         Concluidos             INT)
BEGIN
    SET NOCOUNT ON
    
    SET @lPerIni = NULL
    SET @lPerFin = NULL

    SET @lStrQuery = ''
    SET @lCondicaoAcoes1 = ''
    SET @lCondicaoAcoes2 = ''
    
    SET @lCalculoSubtotal = 0
    
    SET @lHoje = 'CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), GETDATE(), 121) + ''', 121)'
    
    IF @pSub = 0
        SET @lLvl = 1
    ELSE
        SET @lLvl = 3
  
    IF NOT @pIdePlaGesFiltro IS NULL
    BEGIN
        SELECT @lPerIni = CONVERT(datetime, CAST(TPLAGES.EXR AS VARCHAR(4)) + '-01-01', 121)
          FROM TPLAGES
         WHERE TPLAGES.IDEPLAGES = @pIdePlaGesFiltro
         
        SET @lPerFin = DATEADD(day, -1, DATEADD(year, 1, @lPerIni))
    END
    
    IF NOT @pPerIni IS NULL
        SET @lPerIni = @pPerIni

    IF NOT @pPerFin IS NULL
        SET @lPerFin = @pPerFin 

    IF @pCls <> 0
    BEGIN       
        IF LEN(@lCondicaoAcoes2) > 0
            SET @lCondicaoAcoes2 = @lCondicaoAcoes2 + ' AND '
        
       IF @pPortalSim30 = 0
         SET @lCondicaoAcoes2 = @lCondicaoAcoes2 +        'TSOLPRB.CLS = ' + CAST(@pCls AS VARCHAR)
       ELSE
         SET @lCondicaoAcoes2 = @lCondicaoAcoes2 +        'TSOLPRB.IDECLS = ' + CAST(@pCls AS VARCHAR)
    END
    
    BEGIN
        IF LEN(@lCondicaoAcoes2) > 0
            SET @lCondicaoAcoes2 = @lCondicaoAcoes2 + ' AND '
        
        IF @pPortalSim30 = 0
           SET @lCondicaoAcoes2 = @lCondicaoAcoes2 +         'TSOLPRB.TYP = ''PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblemaAntiga'' ';
        ELSE
           SET @lCondicaoAcoes2 = @lCondicaoAcoes2 +         'TSOLPRB.TYP = ''PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'' ';
    END

	SET @lCondicaoAcoes2 = @lCondicaoAcoes2 +         ' AND TSOLPRB.DATCNC IS NULL ';

    IF NOT @lPerIni IS NULL
    BEGIN
        SET @lCondicaoAcoes1 = @lCondicaoAcoes1 + ' AND (TPACTAR.INIPRE BETWEEN CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), @lPerIni, 121) + ''', 121) AND CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), @lPerFin, 121) + ''', 121) '
		SET @lCondicaoAcoes1 = @lCondicaoAcoes1 + ' OR TPACTAR.FIMPRE BETWEEN CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), @lPerIni, 121) + ''', 121) AND CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), @lPerFin, 121) + ''', 121) '
		SET @lCondicaoAcoes1 = @lCondicaoAcoes1 + ' OR (TPACTAR.INIPRE < CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), @lPerIni, 121) + ''', 121) AND TPACTAR.FIMPRE > CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), @lPerFin, 121) + ''', 121))) '
    END
    
    IF NOT @pIdeUsu IS NULL
    BEGIN
        SET @lCondicaoAcoes1 = @lCondicaoAcoes1 + ' AND TPACTAR.IDEUSURES = ' + CAST(@pIdeUsu AS VARCHAR(13))
    END

    SET @lStrQuery =              'SELECT VUNIARV.ORD, '
    SET @lStrQuery = @lStrQuery +        'VUNIARV.SIG, '
    SET @lStrQuery = @lStrQuery +        'VUNIARV.IDEUNI, '
    SET @lStrQuery = @lStrQuery +        'VUNIARV.LVL, '
    SET @lStrQuery = @lStrQuery +        'COUNT(VPACTAR.IDEPACTAR) Criados, '
    SET @lStrQuery = @lStrQuery +        '0 AgingMonths, '
    
    IF @pPortalSim30 = 0
    BEGIN
        SET @lStrQuery = @lStrQuery +   'SUM(VPACTAR.NUMREP) Reprogramadas, '
        SET @lStrQuery = @lStrQuery +   'SUM(CASE WHEN (VPACTAR.INIPRE IS NULL OR (VPACTAR.INIPRE >= ' + @lHoje + ' AND VPACTAR.INIREA IS NULL)) AND VPACTAR.FIMPRE >= ' + @lHoje + ' AND VPACTAR.FIMREA IS NULL THEN 1 ELSE 0 END) EmAberto, '
        SET @lStrQuery = @lStrQuery +   'SUM(CASE WHEN (VPACTAR.ACAREC = 0 AND NOT VPACTAR.INIPRE IS NULL AND NOT VPACTAR.INIREA IS NULL AND VPACTAR.FIMPRE >= ' + @lHoje + ' AND VPACTAR.FIMREA IS NULL) OR (VPACTAR.ACAREC <> 0 AND VPACTAR.PRXEXCREC >= ' + @lHoje + ' AND VPACTAR.FIMREA IS NULL) THEN 1 ELSE 0 END) EmAndamento, '
        SET @lStrQuery = @lStrQuery +   'SUM(CASE WHEN (VPACTAR.INIPRE < ' + @lHoje + ' AND VPACTAR.INIREA IS NULL AND VPACTAR.FIMREA IS NULL) OR (VPACTAR.ACAREC = 0 AND VPACTAR.FIMPRE < ' + @lHoje + ' AND VPACTAR.FIMREA IS NULL) OR (VPACTAR.ACAREC <> 0 AND VPACTAR.PRXEXCREC < ' + @lHoje + ' AND VPACTAR.FIMREA IS NULL) THEN 1 ELSE 0 END) EmAtraso, '
        SET @lStrQuery = @lStrQuery +   'SUM(CASE WHEN NOT VPACTAR.FIMREA IS NULL THEN 1 ELSE 0 END) Concluidos '
    END
    ELSE
    BEGIN
        SET @lStrQuery = @lStrQuery +   'SUM(VPACTAR.NUMREP) Reprogramadas,
                                         SUM(CASE WHEN VPACTAR.STATUS = 1 THEN 1 ELSE 0 END) EmAberto,
                                         SUM(CASE WHEN VPACTAR.STATUS = 2 THEN 1 ELSE 0 END) EmAndamento,
                                         SUM(CASE WHEN VPACTAR.STATUS = 3 THEN 1 ELSE 0 END) EmAtraso,
                                         SUM(CASE WHEN VPACTAR.STATUS = 4 OR VPACTAR.STATUS = 5 THEN 1 ELSE 0 END) Concluidos '
    END
   IF NOT @pIdeUni IS NULL
      BEGIN 
        SET @lStrQuery = @lStrQuery +   'FROM ( SELECT LUNI.* FROM dbo.DefinirArvoreSubordinadas(' + CAST(@pIdeUni AS VARCHAR(13)) + ', ' + CAST(@pIdePlaGes AS VARCHAR(13)) + ') LUNI '
        SET @lStrQuery = @lStrQuery +   '      INNER JOIN (SELECT IDEUNI FROM RetornarUnidadesPorUsuario(' + CAST(@pIdeUsuLogado AS VARCHAR(13)) + ', ' + CAST(@pIdePlaGes AS VARCHAR(13)) + ')) TUSUUNI ON LUNI.IDEUNI = TUSUUNI.IDEUNI WHERE LVL <= ' + CAST(@lLvl AS VARCHAR) + ' ) VUNIARV '
      END
   ELSE
      SET @lStrQuery = @lStrQuery +   'FROM ( SELECT IDEUNI, SIG,  ORD, 0 LVL FROM RetornarUnidadesPorUsuario(' + CAST(@pIdeUsuLogado AS VARCHAR(13)) + ', ' + CAST(@pIdePlaGes AS VARCHAR(13)) + ')) VUNIARV '

   IF @pPortalSim30 = 0
      BEGIN
         SET @lStrQuery = @lStrQuery +     'LEFT JOIN (SELECT * FROM TSOLPRB '
         SET @lStrQuery = @lStrQuery +     'WHERE TSOLPRB.ETP <> 90 '
        
         IF LEN(@lCondicaoAcoes2) > 0
            SET @lStrQuery = @lStrQuery +     ' AND ' + @lCondicaoAcoes2    
        
         SET @lStrQuery = @lStrQuery +           ') TSOLPRB ON VUNIARV.IDEUNI = TSOLPRB.IDEUNI '

         SET @lStrQuery = @lStrQuery + ' LEFT JOIN (SELECT tFer.IdeFer, tFer.Nme, tSolPrbPas.IdeSolPrb, TSOLPRBPAS.IDESOLPRBPAS
                                                      FROM tFer 
                                                   INNER JOIN tSolPrbPas ON tFer.IdeSolPrbPas = tSolPrbPas.IdeSolPrbPas 
                                                   WHERE tFer.TipFer = 32 
                                                   UNION 
                                                   SELECT tFer.IdeFer, tFer.Nme, tSolPrb.IdeSolPrb, TFER.IDESOLPRBPAS 
                                                   FROM tSolPrb 
                                                   INNER JOIN tLinRac ON tSolPrb.IdeSolPrb = tLinRac.IdeSolPrb 
                                                   INNER JOIN tRac ON tRac.IdeLinRac = tLinRac.IdeLinRac 
                                                   INNER JOIN tFer ON tFer.IdeRac = tRac.IdeRac 
                                                   WHERE tFer.TipFer = 32) tFer ON TSOLPRB.IdeSolPrb = TFER.IdeSolPrb '

         SET @lStrQuery = @lStrQuery + ' LEFT JOIN (SELECT TPACTAR.IDEPACTAR, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.INIPRE, 
                                          TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, COUNT(TPACTARREP.IDEPACTARREP) NUMREP
                                          FROM TPACTAR
                                          LEFT JOIN TPACTARREP ON TPACTAR.IDEPACTAR = TPACTARREP.IDEPACTAR
                                          WHERE TPACTAR.DEL = 0
                                          AND tPacTar.FimPre IS NOT NULL ' + @lCondicaoAcoes1 + '
                                          GROUP BY TPACTAR.IDEPACTAR, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.INIPRE, 
                                          TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC) VPACTAR ON TFER.IDEFER = VPACTAR.IDEFER '
        END
    ELSE
        BEGIN
            SET @lStrQuery = @lStrQuery +  ' LEFT JOIN 
											 (SELECT TSOLPRB.IDESOLPRB, TSOLPRB.IDEUNI 
												FROM TSOLPRB
												WHERE TSOLPRB.ETP <> 90'
            IF LEN(@lCondicaoAcoes2) > 0
                SET @lStrQuery = @lStrQuery + ' AND ' + @lCondicaoAcoes2

			SET @lStrQuery = @lStrQuery +  ' ) TSOLPRB ON VUNIARV.IDEUNI = TSOLPRB.IDEUNI'

            SET @lStrQuery = @lStrQuery + ' LEFT JOIN TSOLPRBPAS ON TSOLPRBPAS.IDESOLPRB = TSOLPRB.IDESOLPRB
                                            LEFT JOIN TFER ON TFER.IDESOLPRBPAS = TSOLPRBPAS.IDESOLPRBPAS
                                            LEFT JOIN (SELECT TPACTAR.IDEPACTAR, TPACTAR.IDEPLAACO, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.INIPRE, 
                                            TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, COUNT(TPACTARREP.IDEPACTARREP) NUMREP,
                                            dbo.DefinirStatusAcao(TPACTAR.IDEPACTAR, GETDATE()) STATUS
                                             FROM TPACTAR
                                             INNER JOIN TPLAACO ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
                                             LEFT JOIN TPACTARREP ON TPACTAR.IDEPACTAR = TPACTARREP.IDEPACTAR
                                             WHERE TPACTAR.DEL = 0
                                             AND tPacTar.FimPre IS NOT NULL ' + @lCondicaoAcoes1 + '
                                             GROUP BY TPACTAR.IDEPACTAR, TPACTAR.IDEPLAACO, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.INIPRE, 
                                             TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC) VPACTAR ON TFER.IDEPLAACO = VPACTAR.IDEPLAACO '
        END

    SET @lStrQuery = @lStrQuery + ' GROUP BY VUNIARV.SIG, VUNIARV.IDEUNI, VUNIARV.ORD, VUNIARV.LVL '
    SET @lStrQuery = @lStrQuery + ' ORDER BY VUNIARV.ORD, VUNIARV.SIG '

    SET @lStrQuery = 'DECLARE CursorRelatorio CURSOR GLOBAL FAST_FORWARD READ_ONLY FOR ' + @lStrQuery

    EXEC (@lStrQuery)
    SELECT @lError = @@ERROR
    IF @lError <> 0
    BEGIN
        GOTO errRelatorioProjetos
    END

    SET @lTotalCriados = 0
    SET @lTotalAgingMonths = 0
    SET @lTotalEmAberto = 0
    SET @lTotalEmAndamento = 0
    SET @lTotalEmAtraso = 0
    SET @lTotalConcluidos = 0

    OPEN CursorRelatorio
    FETCH CursorRelatorio INTO @lOrd, @lSig, @lIdeUni, @lLvl, @lCriados, @lAgingMonths, @lReprogramadas, @lEmAberto, @lEmAndamento, @lEmAtraso, @lConcluidos 
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @lLvl = 2
        BEGIN
            IF @lCalculoSubtotal = 2 AND @pExcel = 0
            BEGIN
                INSERT @Dados (ORD, SIG, IDEUNI, TOT, Criados, AgingMonths, EmAberto, Reprogramadas, EmAndamento, EmAtraso, Concluidos) VALUES (@lOrd + 1, '      Subtotal', 2, -1, @lSubTotalCriados, 0, @lSubTotalEmAberto, @lReprogramadas, @lSubTotalEmAndamento, @lSubTotalEmAtraso, @lSubTotalConcluidos)
            END

            SET @lCalculoSubtotal = 1   
            
            SET @lSubTotalCriados = @lCriados
            SET @lSubTotalAgingMonths = 0
            SET @lSubTotalEmAberto = @lEmAberto
            SET @lReprogramadas = @lReprogramadas
            SET @lSubTotalEmAndamento = @lEmAndamento
            SET @lSubTotalEmAtraso = @lEmAtraso
            SET @lSubTotalConcluidos = @lConcluidos 
        END
        ELSE IF @lLvl = 3
        BEGIN
            SET @lCalculoSubtotal = 2   

            SET @lSubTotalCriados = @lSubTotalCriados + @lCriados
            SET @lSubTotalAgingMonths = 0
            SET @lSubTotalEmAberto = @lSubTotalEmAberto + @lEmAberto
            SET @lSubTotalReprogramadas = @lSubTotalReprogramadas + @lReprogramadas
            SET @lSubTotalEmAndamento = @lSubTotalEmAndamento + @lEmAndamento
            SET @lSubTotalEmAtraso = @lSubTotalEmAtraso + @lEmAtraso
            SET @lSubTotalConcluidos = @lSubTotalConcluidos + @lConcluidos 
        END

        SET @lTotalCriados = @lTotalCriados + @lCriados
        SET @lTotalAgingMonths = 0
        SET @lTotalEmAberto = @lTotalEmAberto + @lEmAberto
        SET @lTotalReprogramadas = @lTotalReprogramadas + @lReprogramadas
        SET @lTotalEmAndamento = @lTotalEmAndamento + @lEmAndamento
        SET @lTotalEmAtraso = @lTotalEmAtraso + @lEmAtraso
        SET @lTotalConcluidos = @lTotalConcluidos + @lConcluidos 

        INSERT @Dados (ORD, SIG, IDEUNI, TOT, Criados, AgingMonths, EmAberto, Reprogramadas, EmAndamento, EmAtraso, Concluidos) VALUES (@lOrd, @lSig, @lIdeUni, 0, @lCriados, @lAgingMonths, @lEmAberto, @lReprogramadas, @lEmAndamento, @lEmAtraso, @lConcluidos)

        FETCH CursorRelatorio INTO @lOrd, @lSig, @lIdeUni, @lLvl, @lCriados, @lAgingMonths, @lReprogramadas, @lEmAberto, @lEmAndamento, @lEmAtraso, @lConcluidos
    END
    CLOSE CursorRelatorio
    DEALLOCATE CursorRelatorio

    IF @pSub <> 0 AND @pExcel = 0
    BEGIN
        IF @lCalculoSubtotal = 2
            INSERT @Dados (ORD, SIG, IDEUNI, TOT, Criados, AgingMonths, EmAberto, Reprogramadas, EmAndamento, EmAtraso, Concluidos) VALUES (@lOrd + 1, '      Subtotal', -1, 2, @lSubTotalCriados, 0, @lSubTotalEmAberto, @lSubTotalReprogramadas, @lSubTotalEmAndamento, @lSubTotalEmAtraso, @lSubTotalConcluidos)

        INSERT @Dados (ORD, SIG, IDEUNI, TOT, Criados, AgingMonths, EmAberto, Reprogramadas, EmAndamento, EmAtraso, Concluidos) VALUES (@lOrd + 1, 'Total', -1, 1, @lTotalCriados, 0, @lTotalEmAberto, @lTotalReprogramadas, @lTotalEmAndamento, @lTotalEmAtraso, @lTotalConcluidos)
        
    END

    SELECT  NEWID() Id, * FROM @Dados

errRelatorioProjetos:

END
GO




/****** Object:  StoredProcedure [dbo].[RELATORIOS_RelStatusAcoes30]    Script Date: 10/21/2008 14:49:13 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RELATORIOS_RelStatusAcoes30]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[RELATORIOS_RelStatusAcoes30]
GO
/****** Object:  StoredProcedure [dbo].[RELATORIOS_RelStatusAcoes30]    Script Date: 10/21/2008 14:49:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* Função     : RELATORIOS_RelStatusAcoes30
   Propósito  : Retorna os Status das Acoes sob a Responsabilidade de uma Unidade Gerencial e/ou suas subordinadas até o 3o nível
   Parâmetros : pIdeUni-Identificador da Unidade Gerencial
                pSub-Indica se o relatório deve retornar dados apenas da UG selecionada ou de suas subordinadas até o 3o nível
                pIdePlaGes-Identificador do Plano de Gestão corrente
                pIdePlaGesFiltro-Identificador do Plano de Gestão selecionado no filtro (pode ser nulo)
                pPerIni-Período de Início definido pelo Usuário (pode ser nulo)
                pPerFin-Período de Término definido pelo usuário (pode ser nulo)
                pIdeUsu-Identificador do Usuário responsável pelas Soluções de Problema ou pelas Ações
                pCls-Classificação sob as quais será feita a pesquisa
   Criação    : 22/11/2010 - mar
   Última Alt. : 02/09/2015 - fcs */

CREATE PROCEDURE [dbo].[RELATORIOS_RelStatusAcoes30]
                           (@pIdeUni          DECIMAL(13),
                            @pSub             INT,
                            @pIdePlaGes       DECIMAL(13),
                            @pIdePlaGesFiltro DECIMAL(13),
                            @pPerIni          DATETIME,
                            @pPerFin          DATETIME,
                            @pIdeUsu          DECIMAL(13),
                            @pCls             DECIMAL(13),
                            @pIsAdministrador INT,
                            @pIdeUsuLogado    DECIMAL(13),
                            @pExcel           INT)
AS
    DECLARE @lLvl                   INT,
            @lPerIni                DATETIME,
            @lPerFin                DATETIME,
            
            @lHoje                  VARCHAR(50),
    
            @lStrQuery              VARCHAR(8000),
            @lCondicaoAcoes1        VARCHAR(1000),
            @lCondicaoAcoes2        VARCHAR(1000),
            
            @lCalculoSubtotal       INT,

            @lOrd                   INT,
            @lSig                   VARCHAR(50),
            @lIdeUni                DECIMAL(13),
            @lCriados               INT,
         	@lPlanejadasNoPrazo  INT,
			@lPlanejadasAtrasada INT,
			@lEmExecucaoNoPrazo  INT,
			@lEmExecucaoAtrasada INT,
			@lFinalizadaNoPrazo  INT,
			@lFinalizadaAtrasada INT,

			@lTotalCriados       INT,
			@lTotalPlanejadasNoPrazo  INT,
			@lTotalPlanejadasAtrasada INT,
			@lTotalEmExecucaoNoPrazo  INT,
			@lTotalEmExecucaoAtrasada INT,
			@lTotalFinalizadaNoPrazo  INT,
			@lTotalFinalizadaAtrasada INT,

			@lSubTotalCriados        INT,
			@lSubTotalPlanejadasNoPrazo   INT,
			@lSubTotalPlanejadasAtrasada  INT,
			@lSubTotalEmExecucaoNoPrazo   INT,
			@lSubTotalEmExecucaoAtrasada  INT,
			@lSubTotalFinalizadaNoPrazo   INT,
			@lSubTotalFinalizadaAtrasada  INT,

            @lError         INT

   DECLARE @Dados TABLE (ORD                    INT, 
                         NMEUSU                 VARCHAR(100),
                         IDEUSU                 DECIMAL(13),
                         SIG                    VARCHAR(75),
                         IDEUNI                 DECIMAL(13),
                         Criados                INT, 
                         PlanejadasNoPrazo      INT,
                         PlanejadasAtrasada     INT,
                         EmExecucaoNoPrazo      INT,
                         EmExecucaoAtrasada     INT, 
                         FinalizadaNoPrazo      INT, 
                         FinalizadaAtrasada     INT)
BEGIN
    SET NOCOUNT ON
    
    SET @lPerIni = NULL
    SET @lPerFin = NULL

    SET @lStrQuery = ''
    SET @lCondicaoAcoes1 = ''
    SET @lCondicaoAcoes2 = ''
    
    SET @lCalculoSubtotal = 0
    
    SET @lHoje = 'CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), GETDATE(), 121) + ''', 121)'
    
    IF @pSub = 0
        SET @lLvl = 1
    ELSE
        SET @lLvl = 3
  
    IF NOT @pIdePlaGesFiltro IS NULL
    BEGIN
        SELECT @lPerIni = CONVERT(datetime, CAST(TPLAGES.EXR AS VARCHAR(4)) + '-01-01', 121)
          FROM TPLAGES
         WHERE TPLAGES.IDEPLAGES = @pIdePlaGesFiltro
         
        SET @lPerFin = DATEADD(day, -1, DATEADD(year, 1, @lPerIni))
    END
    
    IF NOT @pPerIni IS NULL
        SET @lPerIni = @pPerIni

    IF NOT @pPerFin IS NULL
        SET @lPerFin = @pPerFin 

    IF @pCls <> 0
    BEGIN       
        IF LEN(@lCondicaoAcoes2) > 0
            SET @lCondicaoAcoes2 = @lCondicaoAcoes2 + ' AND '
       
         SET @lCondicaoAcoes2 = @lCondicaoAcoes2 +        'TSOLPRB.IDECLS = ' + CAST(@pCls AS VARCHAR)
    END
    BEGIN
        IF LEN(@lCondicaoAcoes2) > 0
            SET @lCondicaoAcoes2 = @lCondicaoAcoes2 + ' AND '
        
           SET @lCondicaoAcoes2 = @lCondicaoAcoes2 +         'TSOLPRB.TYP = ''PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'' ';
    END

	SET @lCondicaoAcoes2 = @lCondicaoAcoes2 +         ' AND TSOLPRB.DATCNC IS NULL ';

    IF NOT @lPerIni IS NULL
    BEGIN
        SET @lCondicaoAcoes1 = @lCondicaoAcoes1 + ' AND TPACTAR.FIMPRE BETWEEN CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), @lPerIni, 121) + ''', 121) AND CONVERT(DATETIME, ''' + CONVERT(VARCHAR(10), @lPerFin, 121) + ''', 121) '
    END
    
    IF NOT @pIdeUsu IS NULL
    BEGIN
        SET @lCondicaoAcoes1 = @lCondicaoAcoes1 + ' AND TPACTAR.IDEUSURES = ' + CAST(@pIdeUsu AS VARCHAR(13))
    END

    SET @lStrQuery =              'SELECT VUNIARV.ORD, '
    SET @lStrQuery = @lStrQuery +        'VUNIARV.SIG, '
    SET @lStrQuery = @lStrQuery +        'VUNIARV.IDEUNI, '
	SET @lStrQuery = @lStrQuery +        'VUNIARV.LVL, '
    SET @lStrQuery = @lStrQuery +        'COUNT(VPACTAR.IDEPACTAR) Criados, '
	SET @lStrQuery = @lStrQuery +        'SUM(CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE >= ' + @lHoje + ' THEN 1 ELSE 0 END) PlanejadasNoPrazo, '
	SET @lStrQuery = @lStrQuery +        'SUM(CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE < ' + @lHoje + ' THEN 1 ELSE 0 END) PlanejadasAtrasada, '
	SET @lStrQuery = @lStrQuery +        'SUM(CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (dbo.PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, GETDATE())) <= VPACTAR.PERCON THEN 1 ELSE 0 END) EmExecucaoNoPrazo, '
	SET @lStrQuery = @lStrQuery +        'SUM(CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (dbo.PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, GETDATE())) > VPACTAR.PERCON THEN 1 ELSE 0 END) EmExecucaoAtrasada, '
	SET @lStrQuery = @lStrQuery +        'SUM(CASE WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA <= VPACTAR.FIMPRE THEN 1 ELSE 0 END) FinalizadaNoPrazo, '
	SET @lStrQuery = @lStrQuery +        'SUM(CASE WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA > VPACTAR.FIMPRE THEN 1 ELSE 0 END) FinalizadaAtrasada '
    
   IF NOT @pIdeUni IS NULL
      BEGIN 
        SET @lStrQuery = @lStrQuery +   'FROM ( SELECT LUNI.* FROM dbo.DefinirArvoreSubordinadas(' + CAST(@pIdeUni AS VARCHAR(13)) + ', ' + CAST(@pIdePlaGes AS VARCHAR(13)) + ') LUNI '
        SET @lStrQuery = @lStrQuery +   '      INNER JOIN (SELECT IDEUNI FROM RetornarUnidadesPorUsuario(' + CAST(@pIdeUsuLogado AS VARCHAR(13)) + ', ' + CAST(@pIdePlaGes AS VARCHAR(13)) + ')) TUSUUNI ON LUNI.IDEUNI = TUSUUNI.IDEUNI WHERE LVL <= ' + CAST(@lLvl AS VARCHAR) + ' ) VUNIARV '
      END
   ELSE
      SET @lStrQuery = @lStrQuery +   'FROM ( SELECT IDEUNI, SIG,  ORD, 0 LVL FROM RetornarUnidadesPorUsuario(' + CAST(@pIdeUsuLogado AS VARCHAR(13)) + ', ' + CAST(@pIdePlaGes AS VARCHAR(13)) + ')) VUNIARV '

   
	SET @lStrQuery = @lStrQuery +  ' LEFT JOIN 
										(SELECT TSOLPRB.IDESOLPRB, TSOLPRB.IDEUNI 
										FROM TSOLPRB
										WHERE TSOLPRB.ETP <> 90'
	IF LEN(@lCondicaoAcoes2) > 0
		SET @lStrQuery = @lStrQuery + ' AND ' + @lCondicaoAcoes2

	SET @lStrQuery = @lStrQuery +  ' ) TSOLPRB ON VUNIARV.IDEUNI = TSOLPRB.IDEUNI'

	SET @lStrQuery = @lStrQuery + ' LEFT JOIN TSOLPRBPAS ON TSOLPRBPAS.IDESOLPRB = TSOLPRB.IDESOLPRB
									LEFT JOIN TFER ON TFER.IDESOLPRBPAS = TSOLPRBPAS.IDESOLPRBPAS
									LEFT JOIN (SELECT TPACTAR.FREREC, TPACTAR.IDEPACTAR, TPACTAR.IDEPLAACO, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.INIPRE, 
									TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, TPACTAR.PERCON, TPACTAR.DURHRA
										FROM TPACTAR
										INNER JOIN TPLAACO ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
										WHERE TPACTAR.DEL = 0
										AND tPacTar.FimPre IS NOT NULL ' + @lCondicaoAcoes1 + '
										GROUP BY TPACTAR.IDEPACTAR, TPACTAR.IDEPLAACO, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.INIPRE, 
										TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, TPACTAR.FREREC, TPACTAR.PERCON, TPACTAR.DURHRA) VPACTAR ON TFER.IDEPLAACO = VPACTAR.IDEPLAACO '
    SET @lStrQuery = @lStrQuery + ' GROUP BY VUNIARV.SIG, VUNIARV.IDEUNI, VUNIARV.ORD, VUNIARV.LVL '
    SET @lStrQuery = @lStrQuery + ' ORDER BY VUNIARV.ORD, VUNIARV.SIG '
	
    SET @lStrQuery = 'DECLARE CursorRelatorio CURSOR GLOBAL FAST_FORWARD READ_ONLY FOR ' + @lStrQuery

    EXEC (@lStrQuery)
    SELECT @lError = @@ERROR
    IF @lError <> 0
    BEGIN
        GOTO errRelatorioProjetos
    END

    SET @lTotalCriados = 0
    SET @lTotalPlanejadasNoPrazo = 0
	SET @lTotalPlanejadasAtrasada = 0
	SET @lTotalEmExecucaoNoPrazo = 0
	SET @lTotalEmExecucaoAtrasada = 0
	SET @lTotalFinalizadaNoPrazo = 0
	SET @lTotalFinalizadaAtrasada = 0

    SET @lSubTotalCriados = 0
    SET @lSubTotalPlanejadasNoPrazo = 0
	SET @lSubTotalPlanejadasAtrasada = 0
	SET @lSubTotalEmExecucaoNoPrazo = 0
	SET @lSubTotalEmExecucaoAtrasada = 0
	SET @lSubTotalFinalizadaNoPrazo = 0
	SET @lSubTotalFinalizadaAtrasada = 0

    OPEN CursorRelatorio
	FETCH CursorRelatorio INTO @lOrd, @lSig, @lIdeUni, @lLvl, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @lLvl = 2
        BEGIN
            IF @lCalculoSubtotal = 2 AND @pExcel = 0
            BEGIN
                INSERT @Dados (ORD, SIG, IDEUNI, Criados, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@lOrd + 1, '      Subtotal', 2, @lSubTotalCriados, @lSubTotalPlanejadasNoPrazo, @lSubTotalPlanejadasAtrasada, @lSubTotalEmExecucaoNoPrazo, @lSubTotalEmExecucaoAtrasada, @lSubTotalFinalizadaNoPrazo, @lSubTotalFinalizadaAtrasada)
            END

            SET @lCalculoSubtotal = 1   
            
            SET @lSubTotalCriados = @lCriados
			SET @lSubTotalPlanejadasNoPrazo = @lPlanejadasNoPrazo
            SET @lSubTotalPlanejadasAtrasada = @lPlanejadasAtrasada
            SET @lSubTotalEmExecucaoNoPrazo = @lEmExecucaoNoPrazo
            SET @lSubTotalEmExecucaoAtrasada = @lEmExecucaoAtrasada
            SET @lSubTotalFinalizadaNoPrazo = @lFinalizadaNoPrazo
            SET @lSubTotalFinalizadaAtrasada = @lFinalizadaAtrasada 
        END
        ELSE IF @lLvl = 3
        BEGIN
            SET @lCalculoSubtotal = 2   

            SET @lSubTotalCriados = @lSubTotalCriados + @lCriados
			SET @lSubTotalPlanejadasNoPrazo = @lSubTotalPlanejadasNoPrazo + @lPlanejadasNoPrazo
            SET @lSubTotalPlanejadasAtrasada = @lSubTotalPlanejadasAtrasada + @lPlanejadasAtrasada
            SET @lSubTotalEmExecucaoNoPrazo = @lSubTotalEmExecucaoNoPrazo + @lEmExecucaoNoPrazo
            SET @lSubTotalEmExecucaoAtrasada = @lSubTotalEmExecucaoAtrasada + @lEmExecucaoAtrasada
            SET @lSubTotalFinalizadaNoPrazo = @lSubTotalFinalizadaNoPrazo + @lFinalizadaNoPrazo
            SET @lSubTotalFinalizadaAtrasada = @lSubTotalFinalizadaAtrasada + @lFinalizadaAtrasada 
        END

        SET @lTotalCriados = @lTotalCriados + @lCriados
		SET @lTotalPlanejadasNoPrazo = @lTotalPlanejadasNoPrazo + @lPlanejadasNoPrazo
        SET @lTotalPlanejadasAtrasada = @lTotalPlanejadasAtrasada + @lPlanejadasAtrasada
        SET @lTotalEmExecucaoNoPrazo = @lTotalEmExecucaoNoPrazo + @lEmExecucaoNoPrazo
        SET @lTotalEmExecucaoAtrasada = @lTotalEmExecucaoAtrasada + @lEmExecucaoAtrasada
        SET @lTotalFinalizadaNoPrazo = @lTotalFinalizadaNoPrazo + @lFinalizadaNoPrazo
        SET @lTotalFinalizadaAtrasada = @lTotalFinalizadaAtrasada + @lFinalizadaAtrasada 

		INSERT @Dados (ORD, SIG, IDEUNI, Criados, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@lOrd, @lSig, @lIdeUni, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada)

		FETCH CursorRelatorio INTO @lOrd, @lSig, @lIdeUni, @lLvl, @lCriados, @lPlanejadasNoPrazo, @lPlanejadasAtrasada, @lEmExecucaoNoPrazo, @lEmExecucaoAtrasada, @lFinalizadaNoPrazo, @lFinalizadaAtrasada
    END
    CLOSE CursorRelatorio
    DEALLOCATE CursorRelatorio

    IF @pSub <> 0 AND @pExcel = 0
    BEGIN
        IF @lCalculoSubtotal = 2
            INSERT @Dados (ORD, SIG, IDEUNI, Criados, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@lOrd + 1, '      Subtotal', -1, @lSubTotalCriados, @lSubTotalPlanejadasNoPrazo, @lSubTotalPlanejadasAtrasada, @lSubTotalEmExecucaoNoPrazo, @lSubTotalEmExecucaoAtrasada, @lSubTotalFinalizadaNoPrazo, @lSubTotalFinalizadaAtrasada)

        INSERT @Dados (ORD, SIG, IDEUNI, Criados, PlanejadasNoPrazo, PlanejadasAtrasada, EmExecucaoNoPrazo, EmExecucaoAtrasada, FinalizadaNoPrazo, FinalizadaAtrasada) VALUES (@lOrd + 1, 'Total', -1, @lTotalCriados, @lTotalPlanejadasNoPrazo, @lTotalPlanejadasAtrasada, @lTotalEmExecucaoNoPrazo, @lTotalEmExecucaoAtrasada, @lTotalFinalizadaNoPrazo, @lTotalFinalizadaAtrasada)
        
    END

    SELECT  NEWID() Id, * FROM @Dados

errRelatorioProjetos:

END
GO


IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[sp_AtualizaCollation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_AtualizaCollation]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: sp_AtualizaCollation
   Prop�sito   : Atualiza as colunas cujos Collations est�o fora do padr�o (Default) do Banco de Dados.
   Par�metros  : @pDataBase - Nome da Banco de Dados que deseja atualizar Collations
   Retorno     : (nenhum)
   Cria��o     : 28/12/2009 - rangel
   �ltima Alt. : 12/05/2010 - rangel    */

CREATE PROCEDURE [dbo].[sp_AtualizaCollation] (@pDataBase VARCHAR(60))
AS

DECLARE @Collation VARCHAR(100),
        @TblNme VARCHAR(60),
        @ColNme VARCHAR(60),
        @DtaTpe VARCHAR(60),
        @Nll VARCHAR(10),
        @Query VARCHAR(2000)

SET @Query = 'USE ' + @pDataBase
EXEC (@Query)

BEGIN

EXEC sp_MSForEachTable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'

SET @Collation = CAST((SELECT DATABASEPROPERTYEX(@pDataBase,'Collation')) AS VARCHAR(100))

DECLARE crAterCollation CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
 SELECT TABLE_NAME,
        COLUMN_NAME,       
        CASE WHEN UPPER(DATA_TYPE) IN ('TEXT','NTEXT') THEN DATA_TYPE
             ELSE DATA_TYPE + '(' + CAST(CHARACTER_MAXIMUM_LENGTH AS VARCHAR(4)) + ')' END DTATPE,
        CASE IS_NULLABLE WHEN 'YES' THEN 'NULL' ELSE 'NOT NULL' END IS_NULLABLE
   FROM Information_Schema.Columns
  WHERE COLLATION_NAME IS NOT NULL
    AND COLLATION_NAME <> @Collation
    AND TABLE_NAME LIKE 'T%'
    AND TABLE_NAME NOT IN ('TIDS','TVRS')
    AND TABLE_NAME+' '+COLUMN_NAME NOT IN ('TMSG TBLNME')

OPEN crAterCollation
FETCH FROM crAterCollation INTO @TblNme, @ColNme, @DtaTpe, @Nll
WHILE @@fetch_status=0       
BEGIN
    SET @Query = 'ALTER TABLE ' + @TblNme + ' ALTER COLUMN ' + @ColNme + ' ' + @DtaTpe + ' COLLATE ' + @Collation + ' ' + @Nll
    EXEC (@Query)
    FETCH NEXT FROM crAterCollation INTO @TblNme, @ColNme, @DtaTpe, @Nll
END
CLOSE crAterCollation
DEALLOCATE crAterCollation

EXEC sp_MSForEachTable 'ALTER TABLE ? CHECK CONSTRAINT ALL'

END
GO




/****** Object:  StoredProcedure [dbo].[sp_DropColumn]    Script Date: 10/21/2008 14:49:21 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[sp_DropColumn]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_DropColumn]
GO
/****** Object:  StoredProcedure [dbo].[sp_DropColumn]    Script Date: 10/21/2008 14:49:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: sp_DropColumn
   Prop�sito   : Apaga a coluna de uma tabela, ideal para uso quando a coluna possui valor default, o que dificulta a remo��o no SQLServer
   Par�metros  : pTableName - Nome da Tabela que est� sendo modificada
                 pColumnName - Nome da Coluna que est� sendo modificada
   Retorno     : (nenhum)
   Cria��o     : 17/10/2008 - mar
   �ltima Alt. : 17/10/2008 - mar    */

CREATE PROCEDURE [dbo].[sp_DropColumn] (@pTableName VARCHAR(39), @pColumnName VARCHAR(39))
AS
    DECLARE @lTableId       DECIMAL(13),
            @lDefaultId     DECIMAL(13),
            @lDefaultName   VARCHAR(1000),
            @lStrCommand    VARCHAR(8000)
BEGIN
    SET NOCOUNT ON

    SELECT @lTableId = id FROM sysobjects WHERE [name] = @pTableName AND xtype = 'U'

    SELECT @lDefaultId = cdefault FROM syscolumns WHERE [name] = @pColumnName and id = @lTableId

    SELECT @lDefaultName = name from sysobjects WHERE id = @lDefaultId

    SET @lStrCommand = 'ALTER TABLE ' + @pTableName + CHAR(13) + CHAR(10)
    SET @lStrCommand = @lStrCommand + '   DROP ' + @lDefaultName + CHAR(13) + CHAR(10)      

    EXEC (@lStrCommand)

    SET @lStrCommand = 'ALTER TABLE ' + @pTableName + CHAR(13) + CHAR(10)
    SET @lStrCommand = @lStrCommand + '   DROP COLUMN ' + @pColumnName + CHAR(13) + CHAR(10)

    EXEC (@lStrCommand)

END
GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[sp_ModifyColumn]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_ModifyColumn]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: sp_ModifyColumn
   Prop�sito   : Modifica a coluna de uma tabela, ideal para uso quando a coluna possui valor default, o que dificulta a altera��o no SQLServer
   Par�metros  : pTableName - Nome da Tabela que est� sendo modificada
                 pColumnName - Nome da Coluna que est� sendo modificada
                 pType - Novo tipo do da Coluna
                 pMandatory - 1-Indica que a coluna � mandat�ria (NOT NULL) e 0-N�o mandat�ria (NULL)
                 @pDefaultValue - Valor default, caso seja um valor string abrace-o por '' (aspas duplas)
   Retorno     : (nenhum)
   Cria��o     : 17/10/2008 - mar
   �ltima Alt. : 17/10/2008 - mar    */

CREATE PROCEDURE [dbo].[sp_ModifyColumn] (@pTableName VARCHAR(39), @pColumnName VARCHAR(39), @pType VARCHAR(30), @pMandatory DECIMAL(1), @pDefaultValue AS VARCHAR(100))
AS
    DECLARE @lTableId       DECIMAL(13),
            @lDefaultId     DECIMAL(13),
            @lDefaultName   VARCHAR(1000),
            @lStrCommand    VARCHAR(8000)
BEGIN
    SET NOCOUNT ON

    IF @pMandatory <> 0 AND @pDefaultValue = ''
    BEGIN
        PRINT 'Colunas obrigat�rias devem possuir valor default!'
        RETURN
    END

    SELECT @lTableId = id FROM sysobjects WHERE [name] = @pTableName AND xtype = 'U'

    SELECT @lDefaultId = cdefault FROM syscolumns WHERE [name] = @pColumnName and id = @lTableId

    SELECT @lDefaultName = name from sysobjects WHERE id = @lDefaultId

    SET @lStrCommand = 'ALTER TABLE ' + @pTableName + CHAR(13) + CHAR(10)
    SET @lStrCommand = @lStrCommand + '   ADD NEW' + @pColumnName + ' ' + @pType + CHAR(13) + CHAR(10)

    EXEC (@lStrCommand)

    SET @lStrCommand = 'UPDATE ' + @pTableName + ' SET NEW' + @pColumnName + ' = ' + @pColumnName + CHAR(13) + CHAR(10)

    EXEC (@lStrCommand)

    SET @lStrCommand = 'ALTER TABLE ' + @pTableName + CHAR(13) + CHAR(10)
    SET @lStrCommand = @lStrCommand + '   DROP ' + @lDefaultName + CHAR(13) + CHAR(10)      

    EXEC (@lStrCommand)

    SET @lStrCommand = 'ALTER TABLE ' + @pTableName + CHAR(13) + CHAR(10)
    SET @lStrCommand = @lStrCommand + '   DROP COLUMN ' + @pColumnName + CHAR(13) + CHAR(10)

    EXEC (@lStrCommand)

    SET @lStrCommand = 'ALTER TABLE ' + @pTableName + CHAR(13) + CHAR(10)
    IF @pDefaultValue <> ''
    BEGIN
        IF @pMandatory = 0
            SET @lStrCommand = @lStrCommand + '   ADD ' + @pColumnName + ' ' + @pType + ' NULL DEFAULT ' + @pDefaultValue + CHAR(13) + CHAR(10)
        ELSE
            SET @lStrCommand = @lStrCommand + '   ADD ' + @pColumnName + ' ' + @pType + ' NOT NULL DEFAULT ' + @pDefaultValue + CHAR(13) + CHAR(10)
    END
    ELSE
    BEGIN
        IF @pMandatory = 0
            SET @lStrCommand = @lStrCommand + '   ADD ' + @pColumnName + ' ' + @pType + ' NULL' + CHAR(13) + CHAR(10)
        ELSE
            SET @lStrCommand = @lStrCommand + '   ADD ' + @pColumnName + ' ' + @pType + ' NOT NULL' + CHAR(13) + CHAR(10)
    END

    EXEC (@lStrCommand)

    IF @pDefaultValue <> '' AND @pMandatory = 1
    BEGIN
        SET @lStrCommand = 'UPDATE ' + @pTableName + ' SET NEW' + @pColumnName + ' = ' + @pDefaultValue + ' WHERE NEW' + @pColumnName + ' IS NULL ' + CHAR(13) + CHAR(10)
        EXEC (@lStrCommand)
    END

    SET @lStrCommand = 'UPDATE ' + @pTableName + ' SET ' + @pColumnName + ' = NEW' + @pColumnName + CHAR(13) + CHAR(10)

    EXEC (@lStrCommand)

    SET @lStrCommand = 'ALTER TABLE ' + @pTableName + CHAR(13) + CHAR(10)
    SET @lStrCommand = @lStrCommand + '   DROP COLUMN NEW' + @pColumnName + CHAR(13) + CHAR(10)
    SET @lStrCommand = @lStrCommand + '' + CHAR(13) + CHAR(10)

    EXEC (@lStrCommand)

END
GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[sp_RemoverObjetosAssociados]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_RemoverObjetosAssociados]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: sp_RemoverObjetosAssociados
   Prop�sito   : Criar o script de remo��o dos objetos associados a uma ou mais tabelas do banco
   Par�metros  : pTableName-Nome da tabela que ter� seus objetos removidos, caso seja vazio ser�o removidos os objetos associados a todas tabelas de usu�rio do sistema
                 pDropTable-Indica se � ou n�o para se gerar o script de remo��o da tabela
                 pDropPk-Indica se � ou n�o para se gerar o script de remo��o da PK tabela
                 pDropIndexes-Indica se � ou n�o para se gerar o script de remo��o dos Indices da tabela
                 pDropTriggers-Indica se � ou n�o para se gerar o script de remo��o das Triggers da tabela
   Retorno     : Verdadeiro caso a execu��o das rotinas de extra��o ocorram perfeitamente, falso caso contr�rio
   Cria��o     : 06/02/2005 - mar
   �ltima Alt. : 06/02/2005 - mar    */

CREATE   PROCEDURE [dbo].[sp_RemoverObjetosAssociados](
    @pTableName    VARCHAR(255) = '',
    @pDropTable    DECIMAL(1) = 0,
    @pDropDefaults DECIMAL(1) = 0,
    @pDropPK       DECIMAL(1) = 0,
    @pDropFK       DECIMAL(1) = 0,
    @pDropIndexes  DECIMAL(1) = 0,
    @pDropTriggers DECIMAL(1) = 0)
AS

   DECLARE @parent_id            FLOAT
   DECLARE @parent_name          VARCHAR(255)
   DECLARE @user_name            VARCHAR(50)

   DECLARE @index_name           VARCHAR(255)   

   DECLARE @object_id            FLOAT  
   DECLARE @object_name          VARCHAR(255)   
   DECLARE @object_type          VARCHAR(2) 

   DECLARE @foreign_name     VARCHAR(255)
   DECLARE @parent_foreign_name  VARCHAR(255)   

SET NOCOUNT ON  

/*  
    xtype = 'D'   -- Default Constraints
    xtype = 'FN'  -- Functions
    xtype = 'P'   -- Procedures
    xtype = 'PK'  -- PrimaryKeys
    xtype = 'S'   -- SystemTables
    xtype = 'TR'  -- Triggers
    xtype = 'U'   -- UserTables
    xtype = 'V'   -- Views
*/  

DECLARE TablesCursor CURSOR FOR 
SELECT sysobjects.id,   
       sysobjects.name, 
       sysusers.name UserName   
  FROM (sysobjects INNER JOIN sysusers ON sysobjects.uid = sysusers.uid)    
 WHERE xtype = 'U'  
ORDER BY sysobjects.name    

OPEN TablesCursor   
FETCH NEXT FROM TablesCursor INTO @parent_id, @parent_name, @user_name  
WHILE @@FETCH_STATUS = 0            
BEGIN           
    IF @pTableName = '' OR UPPER(@pTableName) = UPPER(@parent_name)     
    BEGIN       
        IF @pDropIndexes <> 0   
        BEGIN   
            PRINT '/*=================================================='
                        PRINT ' Dropping ' + @parent_name + ' indexes'          
                        PRINT '==================================================*/'            
                        PRINT ' '           

            DECLARE IndexesCursor CURSOR FOR
            SELECT sysindexes.name
              FROM sysindexes
             WHERE sysindexes.id = @parent_id AND 
                               sysindexes.indid > 1 AND             
                               sysindexes.indid < 255 AND               
                           NOT sysindexes.name LIKE '_WA_Sys_%'                 
            ORDER BY sysindexes.name    

            OPEN IndexesCursor  
            FETCH NEXT FROM IndexesCursor INTO @index_name  
            WHILE @@FETCH_STATUS = 0    
            BEGIN   
                PRINT 'drop index [' + @user_name + '].[' + @parent_name + '].[' + @index_name + ']'
                PRINT 'go'

                FETCH NEXT FROM IndexesCursor INTO @index_name
            END 
            CLOSE IndexesCursor 
            DEALLOCATE IndexesCursor    
        END     

        IF @pDropPK + @pDropFK + @pDropTriggers + @pDropDefaults <> 0   
        BEGIN   
            PRINT '/*=================================================='
                        PRINT ' Dropping ' + @parent_name + ' objects'          
                        PRINT '==================================================*/'            
                        PRINT ' '           

            DECLARE ObjectsCursor CURSOR FOR
            SELECT sysobjects.id, 
                   sysobjects.name, 
                   sysobjects.xtype
              FROM sysobjects
             WHERE sysobjects.parent_obj = @parent_id
            ORDER BY sysobjects.xtype, sysobjects.name
            
            OPEN ObjectsCursor          
            FETCH NEXT FROM ObjectsCursor INTO @object_id, @object_name, @object_type           
            WHILE @@FETCH_STATUS = 0            
            BEGIN           
                IF @object_type = 'PK' AND @pDropPK <> 0        
                BEGIN       
                    DECLARE ForeignCursor CURSOR FOR    
                    SELECT rtrim(user_name(ObjectProperty(fkeyid,'ownerid'))), object_name(fkeyid), object_name(constid)    
                      FROM sysreferences WHERE rkeyid = @parent_id ORDER BY 1   
                    OPEN ForeignCursor  
                    FETCH NEXT FROM ForeignCursor INTO @user_name, @parent_foreign_name, @foreign_name  
                    WHILE @@FETCH_STATUS = 0    
                    BEGIN   
                        PRINT 'alter table ' + '[' + @user_name + '].[' + @parent_foreign_name + ']'
                        PRINT '   drop constraint ' + @foreign_name
                        PRINT 'go'
                        FETCH NEXT FROM ForeignCursor INTO @user_name, @parent_foreign_name, @foreign_name
                    END 
                    CLOSE ForeignCursor 
                    DEALLOCATE ForeignCursor    
                    /*DECLARE ForeignCursor CURSOR FOR  
                    SELECT sysobjects.NAME, parentobjects.name  
                                          FROM sysobjects inner join sysobjects parentobjects on sysobjects.parent_obj = parentobjects.id                       
                                         WHERE sysobjects.id IN (SELECT constid FROM sysreferences WHERE rkeyid IN (SELECT id FROM sysindexes WHERE name = @object_name))                       
                    OPEN ForeignCursor  
                    FETCH NEXT FROM ForeignCursor INTO @foreign_name, @parent_foreign_name  
                    WHILE @@FETCH_STATUS = 0    
                    BEGIN   
                        PRINT 'drop index [' + @user_name + '].[' + @parent_foreign_name + '].[' + @foreign_name + ']'
                        PRINT 'go'
                        FETCH NEXT FROM ForeignCursor INTO @foreign_name, @parent_foreign_name
                    END 
                    CLOSE ForeignCursor 
                    DEALLOCATE ForeignCursor    */

                    PRINT 'alter table [' + @user_name + '].[' + @parent_name + ']' 
                    PRINT '   drop constraint ' + @object_name  
                    PRINT 'go'  
                END     

                IF @object_type = 'D' AND @pDropDefaults <> 0       
                BEGIN       

                    PRINT 'alter table [' + @user_name + '].[' + @parent_name + ']' 
                    PRINT '   drop constraint ' + @object_name  
                    PRINT 'go'  
                END     

                IF @object_type = 'F' AND @pDropFK <> 0 
                BEGIN   
                    PRINT 'alter table [' + @user_name + '].[' + @parent_name + ']'
                    PRINT '   drop constraint ' + @object_name
                    PRINT 'go'
                END 

                IF @object_type = 'TR' AND @pDropTriggers <> 0  
                BEGIN   

                    PRINT 'drop trigger [' + @user_name + '].[' + @object_name + ']'
                    PRINT 'go'
                END 

                FETCH NEXT FROM ObjectsCursor INTO @object_id, @object_name, @object_type   
            END     
            CLOSE ObjectsCursor
            DEALLOCATE ObjectsCursor
        END 

        IF @pDropTable <> 0 
        BEGIN   
            PRINT '/*=================================================='
                        PRINT ' Dropping ' + @parent_name + ' table'            
                        PRINT '==================================================*/'            
                        PRINT ' '           
            PRINT 'drop table [' + @user_name + '].[' + @parent_name + ']'
            PRINT 'go'
        END 

                PRINT ' '           
                PRINT ' '           
    END

    FETCH NEXT FROM TablesCursor INTO @parent_id, @parent_name, @user_name
END 
CLOSE TablesCursor  
DEALLOCATE TablesCursor 
GO




/*==============================================================*/
/* ATUALIZA��O DA VERS�O DO BANCO DE DADOS                      */
/*==============================================================*/

DECLARE @LVERSION DATETIME,
		@VERSAO   NVARCHAR(10)
SET @LVERSION = CAST('20170120' AS DATETIME)
SET @VERSAO = '1611.2'
IF EXISTS(SELECT VRS FROM TVRS WHERE VRS = @LVERSION AND NUMVRS = @VERSAO)
   UPDATE TVRS SET DTAPCD = GETDATE() WHERE VRS = @LVERSION AND NUMVRS = @VERSAO;
ELSE
    INSERT INTO TVRS (VRS, DTAPCD , NUMVRS) VALUES (@LVERSION, GETDATE() , @VERSAO);
GO


