

/*********************************************************/
/*********************** CASO 186 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 186'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170130-186')
BEGIN

	ALTER TABLE TLICAMB ADD CSTMAN DECIMAL(1) NOT NULL DEFAULT 0
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170130-186', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 202 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 202'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170320-202')
BEGIN

	exec sp_ModifyColumn 'TDOCLICAMB', 'DES', 'NVARCHAR(250)', 0, 'NULL'
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170320-202', GETDATE())
	
END
GO



PRINT ('CASO 205')
GO
/* CRIANDO TABELA DE ITENS DO PLANO DA EMPRESA */
/*********************************************************/
/**********************   CASO 205  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170404-205')
BEGIN
	
/*==============================================================*/
  
	/*==============================================================*/
	/* TABLE: TATVEPRLICAMB                                         */
	/*==============================================================*/
	CREATE TABLE TPLNCONITEEMP  (
	   IDEPLNCONEMP         DECIMAL(13)                      NOT NULL,
	   CHV                  NVARCHAR(50)                     NOT NULL,
	   VLR                  NVARCHAR(50)                     NOT NULL
	)

	/*==============================================================*/
	/* INDEX: TPLNCONEMP2TPLNCONITEEMP_FK                        */
	/*==============================================================*/
	CREATE INDEX TPLNCONEMP2TPLNCONITEEMP_FK ON TPLNCONITEEMP (
	   IDEPLNCONEMP ASC
	)

	ALTER TABLE TPLNCONITEEMP
	   ADD CONSTRAINT TPLNCONEMP2TPLNCONITEEMP_FK FOREIGN KEY (IDEPLNCONEMP)
		  REFERENCES TPLNCONEMP (IDEPLNCONEMP)
		  ON DELETE CASCADE
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170404-205', GETDATE())
END
GO



PRINT ('CASO 220')
GO

/* Adicionando coluna para possibilitar remoção de atividades dos Relatorios e Graficos */
/*********************************************************/
/**********************   CASO 220  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170508-220')
BEGIN
	
/*==============================================================*/
  
		/*==============================================================*/
		/* TABLE: TPACTAR                                         		*/
		/*==============================================================*/
		ALTER TABLE TPACTAR ADD REMRELGRA DECIMAL(1) NOT NULL DEFAULT 0
		
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170508-220', GETDATE())
END
GO




IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170629-253')
BEGIN

	DECLARE cPlanos CURSOR FOR  SELECT CASE WHEN ACO.IDEPLAACO = LIC.IDEPLAACONTF THEN 1 /* Notificação / Termo */
											WHEN ACO.IDEPLAACO = LIC.IDEPLAACOCMP THEN 2 /* Compensatória */
											WHEN ACO.IDEPLAACO = LIC.IDEPLAACOPRGAMB THEN 3 /* Programa Ambiental */
											WHEN ACO.IDEPLAACO = LIC.IDEPLAACOORIBAS THEN 4 /* Orientação */
											ELSE NULL END VINCULO, ACO.IDEPLAACO
								FROM TPLAACO ACO
								INNER JOIN TLICAMB LIC ON ACO.IDEPLAACO = LIC.IDEPLAACOCMP OR ACO.IDEPLAACO = LIC.IDEPLAACOPRGAMB OR ACO.IDEPLAACO = LIC.IDEPLAACONTF OR ACO.IDEPLAACO = LIC.IDEPLAACOORIBAS

declare @lIdePlaAco decimal(13), 
		@Vinculo int

	OPEN cPlanos
	FETCH NEXT FROM cPlanos INTO @Vinculo, @lIdePlaAco
	WHILE @@FETCH_STATUS = 0
	BEGIN 
		
		IF @Vinculo = 1 
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.NotificacaoDaLicenca', NME = 'Notificações / Termos de Compromisso' WHERE IDEPLAACO = @lIdePlaAco
		ELSE IF @Vinculo = 2 
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.CompensatoriaDaLicenca', NME = 'Compensatórias' WHERE IDEPLAACO = @lIdePlaAco
		ELSE IF @Vinculo = 3 
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.ProgramaAmbientalDaLicenca', NME = 'Programas Ambientais' WHERE IDEPLAACO = @lIdePlaAco
		ELSE IF @Vinculo = 4 
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.OrientacaoDaLicenca', NME = 'Orientações' WHERE IDEPLAACO = @lIdePlaAco
		
		
		FETCH NEXT FROM cPlanos INTO @Vinculo, @lIdePlaAco
	END

	CLOSE cPlanos
	DEALLOCATE cPlanos
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170629-253', GETDATE())
END
GO



PRINT ('CASO 257')
GO

/* Adicionando coluna para descrição do prazo da tarefa */
/*********************************************************/
/**********************   CASO 257  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170804-257')
BEGIN
	
/*==============================================================*/
  
		/*==============================================================*/
		/* TABLE: TPACTAR                                         		*/
		/*==============================================================*/
		ALTER TABLE TPACTAR ADD PRZ NVARCHAR(500) NULL
		
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170804-257', GETDATE())
END
GO



								
/*==============================================================*/
/* ATUALIZAÇÃO DA VERSÃO DO BANCO DE DADOS                      */
/*==============================================================*/

DECLARE @LVERSION DATETIME,
		@VERSAO   NVARCHAR(10)
SET @LVERSION = CAST('20170807' AS DATETIME)
SET @VERSAO = '1708.1'
IF EXISTS(SELECT VRS FROM TVRS WHERE VRS = @LVERSION AND NUMVRS = @VERSAO)
   UPDATE TVRS SET DTATBL = GETDATE() WHERE VRS = @LVERSION AND NUMVRS = @VERSAO;
ELSE
    INSERT INTO TVRS (VRS, DTATBL , NUMVRS) VALUES (@LVERSION, GETDATE() , @VERSAO);
GO

BEGIN
PRINT '1708.1'
END
GO

