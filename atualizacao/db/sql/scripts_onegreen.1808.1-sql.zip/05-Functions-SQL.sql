

IF  EXISTS (SELECT * FROM sysobjects WHERE ID = OBJECT_ID(N'[dbo].[AbreviarDescricao]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[AbreviarDescricao]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[AbreviarDescricao](@pDescricao VARCHAR(1000), @pTamanho INT, @pIniciaisMaiusculas INT)
RETURNS  VARCHAR(100) AS

BEGIN
    DECLARE @lDescricao  VARCHAR(1000),
        @lPosIni     INT,
            @lLastPosIni INT,
        @lNewPosIni  INT
    
    SET @lPosIni = CHARINDEX(' ', @pDescricao, @pTamanho)
    IF @lPosIni > 0
        SET @lDescricao = SUBSTRING(@pDescricao, 1, @lPosIni - 1)
    ELSE
            SET @lDescricao = @pDescricao

    IF @pIniciaisMaiusculas <> 0 AND LEN(@lDescricao) > 0
    BEGIN
        SET @lDescricao = LOWER(@lDescricao)
        SET @lDescricao = UPPER(SUBSTRING(@lDescricao, 1, 1)) + SUBSTRING(@lDescricao, 2, LEN(@lDescricao))

            SET @lPosIni = CHARINDEX(' ', @lDescricao, 2)

        WHILE @lPosIni > 0
        BEGIN
            SET @lLastPosIni = @lPosIni
            SET @lPosIni = CHARINDEX(' ', @lDescricao, @lLastPosIni + 1)

            IF @lPosIni = 0
                SET @lPosIni = LEN(@lDescricao) + 1

            IF @lPosIni - @lLastPosIni <> 3       -- n�o leva para mai�sculas os textos De, Da, etc.
                SET @lDescricao = SUBSTRING(@lDescricao, 1, @lLastPosIni) + UPPER(SUBSTRING(@lDescricao, @lLastPosIni + 1, 1)) + SUBSTRING(@lDescricao, @lLastPosIni + 2, LEN(@lDescricao))
                    SET @lPosIni = CHARINDEX(' ', @lDescricao, @lLastPosIni + 1)
            END
    END

    RETURN @lDescricao

END
GO




/****** Object:  UserDefinedFunction [dbo].[BitCompare]    Script Date: 10/21/2008 16:09:27 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[BitCompare]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[BitCompare]
GO
/****** Object:  UserDefinedFunction [dbo].[BitCompare]    Script Date: 10/21/2008 16:09:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[BitCompare](
    @pBitLength INT, 
    @pCompareValue INT,
    @pIntValue INT
) RETURNS BIT

BEGIN

    DECLARE @lBinIntValue VARCHAR(1000),
            @lBinCompareValue VARCHAR(1000),
            @lCharIntValue CHAR(1),
            @lCharCompareValue CHAR(1),
            @lInti INT 

    SET @lInti = @pBitLength;
    SET @lBinIntValue = [dbo].[To_Binary](@pBitLength, @pIntValue);
    SET @lBinCompareValue = [dbo].[To_Binary](@pBitLength, @pCompareValue);

    WHILE @lInti > 0
    BEGIN
        
        SET @lCharIntValue = SUBSTRING(@lBinIntValue, @lInti, 1);
        SET @lCharCompareValue = SUBSTRING(@lBinCompareValue, @lInti, 1);
        
        IF @lCharIntValue = 1 AND NOT @lCharCompareValue = 1
            RETURN 0;
        
        SET @lInti = @lInti - 1;
    
    END

RETURN 1;
END
GO




/****** Object:  UserDefinedFunction [dbo].[DecodeXml]    Script Date: 02/09/2009 16:23:19 ******/

IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[DecodeXml]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[DecodeXml]

GO
/****** Object:  UserDefinedFunction [dbo].[DecodeXml]    Script Date: 02/09/2009 16:23:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* Procedimento: DecodeXml
   Prop�sito   : Retira o encode de uma string no formato Xml
   Par�metros  : pStrXml-String no formato Xml
                 pField-Campo no formato Xml que ser� devolvido
   Cria��o     : 17/05/2005 - mar
   �ltima Alt. : 20/07/2005 - jul */

CREATE     FUNCTION [dbo].[DecodeXml](@pStrXml VARCHAR(8000), @pField VARCHAR(30))
RETURNS VARCHAR(4000)
AS
BEGIN
    DECLARE @lRetn          VARCHAR(8000),
            @lPosIni        INT,
            @lPosFim        INT,
        @charcode   TINYINT

    IF CHARINDEX('<' + @pField + '>', @pStrXml) > 0
    BEGIN
        SET @lPosIni = CHARINDEX('<' + @pField + '>', @pStrXml)
        SET @lPosFim = CHARINDEX('</' + @pField + '>', @pStrXml)

        SET @lRetn = SUBSTRING(@pStrXml, @lPosIni + LEN('<' + @pField + '>'), @lPosFim - (LEN('<' + @pField + '>') + CHARINDEX('<' + @pField + '>', @pStrXml)))
    END
    ELSE
        SET @lRetn = ''


    
    SET @charcode = 123
    WHILE (@charcode < 255)
    BEGIN
        SET @lRetn = REPLACE(@lRetn, '&amp;#'+ convert(varchar,@charcode) +';', CHAR(@charcode))
        SET @charcode = @charcode + 1
    END
    
    SET @lRetn = REPLACE(@lRetn, '&amp;lt;', '<')
    SET @lRetn = REPLACE(@lRetn, '&amp;gt;', '>')
    SET @lRetn = REPLACE(@lRetn, '&amp;amp;', '&')
    SET @lRetn = REPLACE(@lRetn, '&amp;quot;', '"')
    SET @lRetn = REPLACE(@lRetn, '&amp;euro;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;iexcl;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;cent;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;pound;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;curren;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;yen;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;brvbar;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;sect;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;uml;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;copy;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;ordf;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;laquo;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;not;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;shy;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;reg;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;macr;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;deg;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;plusmn;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;sup2;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;sup3;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;acute;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;micro;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;para;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;middot;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;cedil;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;sup1;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;ordm;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;raquo;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;frac14;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;frac12;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;frac34;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;iquest;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;AElig;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;ETH;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;times;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;Oslash;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;THORN;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;szlig;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;aelig;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;divide;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;oslash;', '�')
    SET @lRetn = REPLACE(@lRetn, '&amp;thorn;', '�')


    RETURN(@lRetn)

END
GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[DefinirArvoreProjetosSubordinados]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[DefinirArvoreProjetosSubordinados]
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER ON
GO

/* Fun��o     : DefinirArvoreProjetosSubordinados
   Prop�sito  : Retornar uma tabela com todos Projetos que comp�em a �rvore de desdobramentos
   Par�metros : pIdeEprLicAmb - Identificador do Projeto
   Cria��o    : 06/04/2015 - erac
   �ltima Alt.:  */ 

CREATE FUNCTION [dbo].[DefinirArvoreProjetosSubordinados](@pIdeEprLicAmb DECIMAL(13))    
RETURNS @retnSub TABLE (IDEEPRLICAMB DECIMAL(13), NME NVARCHAR(60), cont int, LVL INT, IDEEPRLICAMBSUP DECIMAL(13), IDEUNI DECIMAL(13)) 
AS  
BEGIN   
    DECLARE @lRowsAdded INT
    DECLARE @lNivel INT
    DECLARE @lIdeEprLicAmb DECIMAL(13)
	DECLARE @lIdeEprLicAmbRel DECIMAL(13)
    DECLARE @lCont INT
	DECLARE @lNme NVARCHAR(60)
	DECLARE @lIdeUni DECIMAL(13)

	select @lNme = nme, @lIdeEprLicAmbRel = IdeEprLicAmbRel, @lIdeUni = IdeUni  from TEPRLICAMB where IDEEPRLICAMB = @pIdeEprLicAmb
    SET @lNivel = 1
    SET @lCont = 1

      -- vari�vel do tipo tabela que armazena as unidades a serem processadas durante a execu��o da Function    
    DECLARE @Sub TABLE (IDEEPRLICAMB DECIMAL(13) PRIMARY KEY, NME NVARCHAR(60), PROCESSADO TINYINT DEFAULT 0, LVL INT, IDEEPRLICAMBSUP DECIMAL(13), IDEUNI DECIMAL(13))

      -- Adiciona o pr�prio projeto nas tabelas   
    IF @pIdeEprLicAmb IS NOT NULL
        INSERT INTO @Sub (IDEEPRLICAMB, NME, LVL, IDEEPRLICAMBSUP, IDEUNI) VALUES (@pIdeEprLicAmb, @lNme, @lNivel, @lIdeEprLicAmbRel, @lIdeUni)

    SET @lRowsAdded = @@rowcount
      -- Loop enquanto novos projetos s�o adicionados �s tabelas    
    WHILE @lRowsAdded > 0
    BEGIN   
        SET @lNivel = @lNivel + 1

          -- Marca todos os projetos inseridos para serem processados
        UPDATE @Sub SET PROCESSADO = 1 WHERE PROCESSADO = 0

        -- Insere os projetos que s�o subordinados aos marcados como PROCESSADO = 1
        INSERT INTO @Sub
            SELECT EPR.IDEEPRLICAMB,
				   EPR.NME,
				   0,
                   @lNivel,
				   EPR.IDEEPRLICAMBREL,
				   EPR.IDEUNI
            FROM teprlicamb epr
				INNER JOIN @Sub TSPR ON epr.IdeEprLicAmbrel = TSPR.IdeEprLicAmb
            WHERE PROCESSADO = 1

        SET @lRowsAdded = @@rowcount

        -- Marca como PROCESSADO = 2 todos projetos que tiveram os Subordinados adicionados
        UPDATE @Sub SET PROCESSADO = 2 WHERE PROCESSADO = 1
    END 

    DECLARE CursorSub
    CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR SELECT IdeEprLicAmb, NME, LVL, IDEEPRLICAMBSUP, IDEUNI FROM @Sub order by LVL

    OPEN CursorSub
    FETCH CursorSub INTO @lIdeEprLicAmb, @lNme, @lNivel, @lIdeEprLicAmbRel, @lIdeUni
    WHILE @@FETCH_STATUS = 0
    BEGIN   
        INSERT INTO @retnSub VALUES (@lIdeEprLicAmb, @lNme, @lCont, @lNivel, @lIdeEprLicAmbRel, @lIdeUni)

        SET @lCont = @lCont + 1

		FETCH CursorSub INTO @lIdeEprLicAmb, @lNme, @lNivel, @lIdeEprLicAmbRel, @lIdeUni
    END
    CLOSE CursorSub
    DEALLOCATE CursorSub
    
    RETURN  
END
GO


IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[DefinirArvoreSubordinadas]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[DefinirArvoreSubordinadas]
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER ON
GO

/* Fun��o     : DefinirArvoreSubordinadas
   Prop�sito  : Retornar uma tabela com todas as Unidades Gerenciais que comp�em a �rvore de desdobramento da UG m�e na ordem do desdobramento
   Par�metros : pIdeUni-Identificador da Unidade Gerencial M�e
   Cria��o    : 22/03/2005 - mar    
   �ltima Alt.: 15/04/2016 - mar */ 

CREATE FUNCTION [dbo].[DefinirArvoreSubordinadas](@pIdeUni DECIMAL(13))
RETURNS @retnSub TABLE (IDEUNI DECIMAL(13), SIG VARCHAR(100), ORD INT, LVL INT) 
AS  
BEGIN   
    DECLARE @lRowsAdded INT
    DECLARE @lComplementacaoSigla VARCHAR(1000)
    DECLARE @lSigla VARCHAR(50)
    DECLARE @lNivel INT
    DECLARE @lIdeUniTyp DECIMAL(13)
    DECLARE @lIdeUni DECIMAL(13)
    DECLARE @lSig VARCHAR(100)
    DECLARE @lCont INT


    SET @lNivel = 1
    SET @lCont = 1

      -- vari�vel do tipo tabela que armazena as unidades a serem processadas durante a execu��o da Function    
    DECLARE @Sub TABLE (IDEUNI DECIMAL(13) PRIMARY KEY, SIG VARCHAR(100), ORDSIG VARCHAR(1000), PROCESSADO TINYINT DEFAULT 0, LVL INT)  

    SELECT @lSigla = VUNI.SIG, @lComplementacaoSigla = VUNI.SIG + SPACE(50 - LEN(VUNI.SIG)), @lIdeUniTyp = VUNI.IDEUNITYP FROM VUNI WHERE VUNI.IDEUNI = @pIdeUni
      -- Adiciona a pr�pria Unidade Gerencial nas tabelas   
    IF @pIdeUni IS NOT NULL
        INSERT INTO @Sub (IDEUNI, SIG, ORDSIG, LVL) VALUES (@pIdeUni, SPACE((@lNivel - 1) * 3) + @lSigla, @lComplementacaoSigla, @lNivel)   

    SET @lRowsAdded = @@rowcount    
      -- Loop enquanto novas unidades s�o adicionadas �s tabelas    
    WHILE @lRowsAdded > 0   
    BEGIN   
        SET @lNivel = @lNivel + 1

          -- Marca todas as unidades inseridas para serem processadas
        UPDATE @Sub SET PROCESSADO = 1 WHERE PROCESSADO = 0

        -- Insere as unidades que s�o subordinadas �s marcadas como PROCESSADO = 1
        INSERT INTO @Sub 
            SELECT TUNI.IDEUNI,
                   SPACE((@lNivel - 1) * 3) + TUNI.SIG,
                   ISNULL(CAST(TSPR.ORDSIG AS VARCHAR(1000)) COLLATE SQL_Latin1_General_CP1_CI_AS,'') + CAST(TUNI.SIG + SPACE(50 - LEN(TUNI.SIG)) AS VARCHAR(50)) COLLATE SQL_Latin1_General_CP1_CI_AS,
                   0,
                   @lNivel
            FROM TUNI
				INNER JOIN @Sub TSPR ON TUNI.IDESPR = TSPR.IDEUNI
            WHERE PROCESSADO = 1
                AND TUNI.IDEUNITYP = @lIdeUniTyp

        SET @lRowsAdded = @@rowcount

        -- Marca como PROCESSADO = 2 todas as Unidades que tiveram as Subordinadas adicionadas
        UPDATE @Sub SET PROCESSADO = 2 WHERE PROCESSADO = 1
    END 

    DECLARE CursorSub
    CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR SELECT IDEUNI, SIG, LVL FROM @Sub ORDER BY ORDSIG

    OPEN CursorSub
    FETCH CursorSub INTO @lIdeUni, @lSig, @lNivel
    WHILE @@FETCH_STATUS = 0
    BEGIN   
        INSERT INTO @retnSub VALUES (@lIdeUni, @lSig, @lCont, @lNivel)

        SET @lCont = @lCont + 1

        FETCH CursorSub INTO @lIdeUni, @lSig, @lNivel
    END
    CLOSE CursorSub
    DEALLOCATE CursorSub
    
    RETURN  
END
GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[DefinirHorarioAcidente]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[DefinirHorarioAcidente]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* Fun��o      : DefinirHorarioAcidente
   Prop�sito   : Definir o hor�rio do acidente
   Par�metros  : pDatAcd-� a data/hora do acidente
   Retorno     : 0-Madrugada
                 1-Manh�
                 2-Tarde
                 3-Noite
   Cria��o     : 19/03/2007 - mar
   �ltima Alt. : 19/03/2007 - mar    */

CREATE FUNCTION [dbo].[DefinirHorarioAcidente]
                               (@pDatAcd        DATETIME)
RETURNS INT
AS
BEGIN
    DECLARE @lRetn                   INT,
            @lHora                   INT

    SET @lHora = DATEPART(hh, @pDatAcd)

    IF @lHora < 6
       SET @lretn = 0
    ELSE IF @lHora >= 6 AND @lHora < 12
       SET @lretn = 1
    ELSE IF @lHora >= 12 AND @lHora < 18
       SET @lretn = 2
    ELSE IF @lHora >= 18 AND @lHora < 24
       SET @lretn = 3

    RETURN(@lRetn)

END
GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[DefinirStatusAcao]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[DefinirStatusAcao]
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO

/* Fun��o      : DefinirStatusAcao
   Prop�sito   : Definir o Status de uma determinada a��o de um Plano
   Par�metros  : pInicioPrevisto-Data de In�cio Previsto da Tarefa
                     pFinalPrevisto-Data de T�rmino Previsto da Tarefa
                     pInicioRealizado-Data de In�cio Realizado da Tarefa
                     pFinalRealizado-Data de T�rmino Realizado da Tarefa
                     pDataCorrente-Data atual do sistema
   Retorno     : 0 = SemStatus
                     1 =    Planejada
                     2 =    EmExecucao
                     3 =    Atrasada
                     4 =    Concluida
                     5 =    ConcluidaComAtraso
   Cria��o     : 09/08/2005 - mar
   �ltima Alt. : 18/03/2014 - PRB */

CREATE  FUNCTION [dbo].[DefinirStatusAcao](@pIdePlaAco    DECIMAL,
                                                     @pDataCorrente DATETIME)
RETURNS INT
AS
BEGIN
    DECLARE @lRetn                   INT,
            @lSemStatus                INT,
            @lPlanejada                INT,
            @lEmExecucao               INT,
            @lAtrasoRecuperavel        INT,
            @lAtrasada                 INT,
            @lConcluida                INT,
            @lConcluidaComAtraso       INT,
			@lPercentualDeConclusaoPrevisto FLOAT,
			@lPercentualDeConclusao		FLOAT,
			@lPrazoParaExecucao		INT,


            @lInicioPrevisto              DATETIME, 
            @lFinalPrevisto            DATETIME, 
            @lInicioRealizado             DATETIME, 
            @lFinalRealizado              DATETIME,
			@lDataCorrente				DATETIME,
            @lPeriodicidade          INT,
            @lDataProximaExecucao    DATETIME

	SET @lDataCorrente = CAST(CONVERT(VARCHAR(10), @pDataCorrente, 120) AS DATETIME)		-- Tira a hora da data passada como refer�ncia para o c�lculo

    SET @lRetn = 0

    SET @lSemStatus = 0
    SET @lPlanejada = 1
    SET @lEmExecucao = 2
    SET @lAtrasada = 3
    SET @lConcluida = 4
    SET @lConcluidaComAtraso = 5
	SET @lPercentualDeConclusaoPrevisto = 0

    SELECT @lInicioPrevisto  = CASE WHEN tPacTar.IdePacTarRel IS NULL THEN tPacTar.IniPre ELSE tPacTarRel.IniPre END,
            @lFinalPrevisto   = CASE WHEN tPacTar.IdePacTarRel IS NULL THEN tPacTar.FimPre ELSE tPacTarRel.FimPre END,
            @lInicioRealizado = CASE WHEN tPacTar.IdePacTarRel IS NULL THEN tPacTar.IniRea ELSE tPacTarRel.IniRea END,
            @lFinalRealizado  = CASE WHEN tPacTar.IdePacTarRel IS NULL THEN tPacTar.FimRea ELSE tPacTarRel.FimRea END,
            @lPeriodicidade = TPACTAR.FREREC,
            @lDataProximaExecucao = TPACTAR.PRXEXCREC,
			@lPrazoParaExecucao = CASE WHEN tPacTar.INIPRE IS NOT NULL AND tPacTar.FIMPRE IS NOT NULL THEN DATEDIFF(DAY, tPacTar.INIPRE, tPacTar.FIMPRE) + 1 ELSE 0 END,
			@lPercentualDeConclusao = TPACTAR.PERCON
      FROM tPacTar LEFT JOIN tFer ON tPacTar.IdeFer = tFer.IdeFer
                   LEFT JOIN tUniScd ON tPacTar.IdeUniScd = tUniScd.IdeUniScd
                   LEFT JOIN tAtv ON tUniScd.IdeAtv = tAtv.IdeAtv
                   LEFT JOIN tPacTar tPacTarRel ON tPacTar.IdePacTarRel = tPacTarRel.IdePacTar
     WHERE tPacTar.IdePacTar = @pIdePlaAco

    IF NOT @lFinalPrevisto IS NULL
        SET @lFinalPrevisto = @lFinalPrevisto + 1 - 0.00001		-- Como n�o vem mais a hora, pois truncamos a data � meia-noite, vamos deixar de colocar o t�mino �s 23:59:59

	IF @lPeriodicidade = 0 AND @lPrazoParaExecucao > 0
	BEGIN
		SET @lPercentualDeConclusaoPrevisto = CAST(DATEDIFF(DAY, @lInicioPrevisto, GETDATE()) AS FLOAT) / @lPrazoParaExecucao * 100
	END

    IF @lFinalRealizado IS NOT NULL
    BEGIN
        IF @lFinalPrevisto IS NOT NULL
        BEGIN
            IF @lFinalRealizado <= @lFinalPrevisto
                SET @lRetn = @lConcluida
            ELSE
                SET @lRetn = @lConcluidaComAtraso
        END
        ELSE
            SET @lRetn = @lConcluida
    END
    ELSE
    BEGIN
        IF @lInicioPrevisto IS NOT NULL
        BEGIN
            IF @lInicioPrevisto >= @lDataCorrente
            BEGIN
                IF @lInicioRealizado IS NOT NULL
                    SET @lRetn = @lEmExecucao
                ELSE
                    SET @lRetn = @lPlanejada
            END
            ELSE
            BEGIN
                IF @lInicioRealizado IS NOT NULL
                BEGIN
                    IF @lInicioRealizado <= @lInicioPrevisto
                    BEGIN
                        IF @lPeriodicidade = 0 
                        BEGIN
                            IF @lFinalPrevisto IS NOT NULL
                            BEGIN
                                IF @lFinalPrevisto >= @lDataCorrente
                                    SET @lRetn = @lEmExecucao
                                ELSE
                                    SET @lRetn = @lAtrasada
                            END
                        END
                        ELSE
                        BEGIN
                            IF @lDataProximaExecucao IS NULL
                                SET @lRetn = @lAtrasada
                            ELSE IF @lDataProximaExecucao >= @lDataCorrente
                                SET @lRetn = @lEmExecucao
                            ELSE
                                SET @lRetn = @lAtrasada
                        END
                    END
                    ELSE
                    BEGIN
                        IF @lPeriodicidade = 0
                        BEGIN
                            IF @lFinalPrevisto IS NOT NULL
                                IF @lPercentualDeConclusao < @lPercentualDeConclusaoPrevisto
									SET @lRetn = @lAtrasada
								ELSE
									SET @lRetn = @lEmExecucao
                        END
                        ELSE
                        BEGIN
                            IF @lDataProximaExecucao IS NULL
                                SET @lRetn = @lAtrasada
                            ELSE IF @lDataProximaExecucao >= @lDataCorrente
                                SET @lRetn = @lEmExecucao
                            ELSE
                                SET @lRetn = @lAtrasada
                        END
                    END
                END
                ELSE
                BEGIN
                    IF @lFinalPrevisto IS NOT NULL
                        SET @lRetn = @lAtrasada
                END
            END
        END
        ELSE
        BEGIN
           IF @lFinalPrevisto IS NOT NULL
           BEGIN
               IF @lFinalPrevisto >= @lDataCorrente
                  SET @lRetn = @lPlanejada
               ELSE
                  SET @lRetn = @lAtrasada
            END
            ELSE
               SET @lRetn = @lSemStatus
        END
    END

    RETURN(@lRetn)

END
GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[DefinirStatusDaAcao30]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[DefinirStatusDaAcao30]
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO

/* Fun��o      : DefinirStatusDaAcao30
   Prop�sito   : Definir o Status de uma determinada a��o
   Par�metros  : pInicioPrevisto - Data de in�cio previsto
                 pFimPrevisto - Data de fim previsto
                 pInicioRealizado - Data de in�cio realizado
                 pFimRealizado - Data de fim realizado
                 pDataCorrente - Data atual do sistema
   Retorno     : 1 = PlanejadaAtrasada
				 2 = PlanejadaNoPrazo
				 3 = EmAndamentoAtrasada
				 4 = EmAndamentoNoPrazo
				 5 = ConcluidaAtrasada
				 6 = ConcluidaNoPrazo
   Cria��o     : 09/08/2005 - mar
   �ltima Alt. : 02/09/2015 - fcs */

CREATE FUNCTION [dbo].[DefinirStatusDaAcao30](@pIdePlaAco    DECIMAL,
                                               @pDataCorrente DATETIME)
RETURNS INT
AS
BEGIN
    DECLARE @lRetn                    INT,
            @lPlanejadaAtrasada       INT,
            @lPlanejadaNoPrazo        INT,
            @lEmAndamentoAtrasada     INT,
            @lEmAndamentoNoPrazo      INT,
            @lConcluidaAtrasada       INT,
            @lConcluidaNoPrazo        INT,
            @lDurHra                  INT,
			@lPercentualDeConclusaoPrevisto FLOAT,
			@lPercentualDeConclusao		FLOAT,			
			@lPrazoParaExecucao		  INT,


            @lInicioPrevisto         DATETIME, 
            @lFimPrevisto            DATETIME, 
            @lInicioRealizado        DATETIME, 
            @lFimRealizado           DATETIME,
			@lDataCorrente			 DATETIME,
            @lPeriodicidade          INT,
            @lDataProximaExecucao    DATETIME

	SET @lDataCorrente = CAST(CONVERT(VARCHAR(10), @pDataCorrente, 120) AS DATETIME)		-- Tira a hora da data passada como refer�ncia para o c�lculo

    SET @lRetn = 0

    SET @lPlanejadaAtrasada = 1
    SET @lPlanejadaNoPrazo = 2
    SET @lEmAndamentoAtrasada = 3
    SET @lEmAndamentoNoPrazo	= 4
    SET @lConcluidaAtrasada = 5
    SET @lConcluidaNoPrazo = 6
	SET @lPercentualDeConclusaoPrevisto = 0

    SELECT @lInicioPrevisto = tPacTar.IniPre,
            @lFimPrevisto = tPacTar.FimPre,
            @lInicioRealizado = tPacTar.IniRea,
            @lFimRealizado = tPacTar.FimRea,
            @lPeriodicidade = TPACTAR.FREREC,
            @lDataProximaExecucao = TPACTAR.PRXEXCREC,
			@lDurHra = TPACTAR.DURHRA,
			@lPrazoParaExecucao = CASE WHEN tPacTar.INIPRE IS NOT NULL AND tPacTar.FIMPRE IS NOT NULL THEN DATEDIFF(DAY, tPacTar.INIPRE, tPacTar.FIMPRE) + 1 ELSE 0 END,
			@lPercentualDeConclusao = TPACTAR.PERCON
      FROM tPacTar
     WHERE tPacTar.IdePacTar = @pIdePlaAco

    IF NOT @lFimPrevisto IS NULL
        SET @lFimPrevisto = @lFimPrevisto + 1 - 0.00001		-- Como n�o vem mais a hora, pois truncamos a data � meia-noite, vamos deixar de colocar o t�mino �s 23:59:59	

	IF @lFimRealizado IS NOT NULL
	BEGIN
		IF @lFimRealizado <= @lFimPrevisto
			SET @lRetn = @lConcluidaNoPrazo
		ELSE
			SET @lRetn = @lConcluidaAtrasada
	END
	ELSE IF @lInicioRealizado IS NOT NULL
		BEGIN
			SET @lPercentualDeConclusaoPrevisto = dbo.PercentualPrevConclusaoTarefa(@lInicioPrevisto, @lFimPrevisto, @lDurHra, @lPeriodicidade, @pDataCorrente)
			
			IF @lPercentualDeConclusaoPrevisto > @lPercentualDeConclusao
				SET @lRetn = @lEmAndamentoAtrasada
			ELSE
				SET @lRetn = @lEmAndamentoNoPrazo
		END
	ELSE
		BEGIN
			IF @lInicioPrevisto < @lDataCorrente
				SET @lRetn = @lPlanejadaAtrasada
			ELSE
				SET @lRetn = @lPlanejadaNoPrazo
		END

    RETURN @lRetn
END
GO



 
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[DeterminarUltimoIdePlaGesUni]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[DeterminarUltimoIdePlaGesUni]
GO



IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[DeterminarUltimoPlanoGestaoUni]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[DeterminarUltimoPlanoGestaoUni]
GO



/****** Object:  UserDefinedFunction [dbo].[fnSplit]    Script Date: 10/21/2008 16:09:27 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[fnSplit]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[fnSplit]
GO
/****** Object:  UserDefinedFunction [dbo].[fnSplit]    Script Date: 10/21/2008 16:09:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[fnSplit](
    @sInputList VARCHAR(8000) -- List of delimited items
  , @sDelimiter VARCHAR(1) = ',' -- delimiter that separates items
) RETURNS @List TABLE ( ord int, item VARCHAR(8000))

BEGIN
DECLARE @sItem VARCHAR(8000),
  @ordem int = 1

WHILE CHARINDEX(@sDelimiter,@sInputList,0) <> 0
 BEGIN
  
  SELECT
   @sItem=RTRIM(LTRIM(SUBSTRING(@sInputList,1,CHARINDEX(@sDelimiter,@sInputList,0)-1))),
   @sInputList=RTRIM(LTRIM(SUBSTRING(@sInputList,CHARINDEX(@sDelimiter,@sInputList,0)+LEN(@sDelimiter),LEN(@sInputList))))
 
  IF LEN(@sItem) > 0
   INSERT INTO @List SELECT @ordem, @sItem
   
   set @ordem = @ordem + 1
  END

 IF LEN(@sInputList) > 0
  INSERT INTO @List SELECT @ordem, @sInputList -- Put the last item in
 RETURN
END
GO


/****** Object:  UserDefinedFunction [dbo].[fnSplitOnPosition]    Script Date: 10/21/2008 16:09:27 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[fnSplitOnPosition]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].fnSplitOnPosition
GO

/****** Object:  UserDefinedFunction [dbo].[fnSplitOnPosition]    Script Date: 26/09/2012 09:23:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[fnSplitOnPosition](
    @sInputList VARCHAR(8000) -- List of delimited items
  , @sDelimiter VARCHAR(1) = ',' -- delimiter that separates items
  , @pPosition int = 1 -- element position
) RETURNS VARCHAR(8000) AS

BEGIN
DECLARE @sItem VARCHAR(8000),
        @count INT

    SET @count = 1
    SET @sInputList = @sInputList + ';'
    
    WHILE CHARINDEX(@sDelimiter,@sInputList,0) <> 0
    BEGIN
        SELECT
            @sItem=RTRIM(LTRIM(SUBSTRING(@sInputList,1,CHARINDEX(@sDelimiter,@sInputList,0)-1))),
            @sInputList=RTRIM(LTRIM(SUBSTRING(@sInputList,CHARINDEX(@sDelimiter,@sInputList,0)+LEN(@sDelimiter),LEN(@sInputList))))
 
        IF @count = @pPosition
            RETURN @sItem
    
        SET @count = @count + 1
 
    END

RETURN NULL
END
GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[ONEGREEN_RelCumprimentoAcoes]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ONEGREEN_RelCumprimentoAcoes]
GO

/****** Object:  UserDefinedFunction [dbo].[ONEGREEN_RelCumprimentoAcoes]    Script Date: 01/05/2013 10:50:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE FUNCTION [dbo].[ONEGREEN_RelCumprimentoAcoes](@pDatIni DATETIME,
                                                @pDatFim DATETIME, 
                                                @pIdeEmp NUMERIC(13,0), 
                                                @pIdeUni NUMERIC(13,0), 
                                                @pSub3Niv INT, 
                                                @pTipoRelacionamento NVARCHAR(100),
											    @pTipoPrimitivoLicenca INT,
												@pTipoLicencaAmbiental INT,
												@pIdeTipLicAmb NUMERIC(13,0),
												@pTipoEndereco NUMERIC(1,0),
												@pIdeEnd NUMERIC(13,0),
												@pIdeTipLegAmb NUMERIC(13,0),
												@pIdeTipLicRegAmb NUMERIC(13,0),
												@pIdeUsu NUMERIC(13,0),
												@AgendamentoFuturo INT,
												@pIdeEprLicAmb NUMERIC(13,0),
												@pSomenteTarefasPrincipais INT)

     RETURNS @Object_CumprimentoAcoes_Table TABLE(  IDEPACTAREXCRECLOG DECIMAL(13),
                                                    IDEUNI      DECIMAL(13),
													IDEVIN      DECIMAL(13),
                                                    IDEPLAACO   DECIMAL(13),
                                                    IDEPACTAR   DECIMAL(13),
                                                    FREREC      DECIMAL(2),
                                                    INIPRETAR   DATETIME,
                                                    FIMPRETAR   DATETIME,
                                                    DATREF      DATETIME,
                                                    DATREA      DATETIME
                                                )
AS
BEGIN

    DECLARE @IdePacTarExcRecLog DECIMAL(13),
            @IdeUni     DECIMAL(13),
			@IdeVin     DECIMAL(13),
            @IdePlaAco  DECIMAL(13),
            @IdePacTar  DECIMAL(13),
            @IniPre     DATETIME,
            @FimPre     DATETIME,
            @FimRea     DATETIME,
            @ProxExe    DATETIME,
            @FreRec     DECIMAL(2),
            @MaxDatPre  DATETIME,
			@lData_Referencia    DATETIME,
            @lData_Prevista      DATETIME,
            @lData_Realizada     DATETIME,
            @lExists             INT,
            @lDatPreExe DATETIME,
            @lDatUltExe DATETIME

	IF UPPER(@pTipoRelacionamento) = 'CRONOGRAMADOPROJETO'
    BEGIN
        DECLARE CursorAcoes CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
        SELECT  MAX(LOG.IDEPACTAREXCRECLOG),
                UNI.IDEUNI,
				0 IDEVIN,
                PLA.IDEPLAACO, 
                TAR.IDEPACTAR, 
                TAR.INIPRE, 
                TAR.FIMPRE, 
                TAR.FIMREA, 
                TAR.PRXEXCREC, 
                TAR.FREREC, 
                COALESCE(MAX(LOG.DATPRE), TAR.INIPRE) MAXDATPRE
             FROM TEPRLICAMB EPR
             INNER JOIN TPLAACO PLA ON PLA.IDEPLAACO =  EPR.IDEPLAACO
			 INNER JOIN TPACTAR TAR ON PLA.IDEPLAACO =  TAR.IDEPLAACO
             INNER JOIN TUNI UNI ON EPR.IDEUNI = UNI.IDEUNI
             INNER JOIN TTIPLICREGAMB ON TTIPLICREGAMB.IDETIPLICREGAMB = EPR.IDETIPLICREGAMB
             LEFT JOIN TEPRLICAMBEND EPREND ON (EPREND.IDEEPRLICAMB = EPR.IDEEPRLICAMB AND EPREND.TIPEPRLICAMBEND = @pTipoEndereco)
             LEFT JOIN TPACTAREXCRECLOG LOG ON TAR.IDEPACTAR = LOG.IDEPACTAR AND LOG.TYP = 'PortalSIM.Domain.Atividades.Execucao'
            WHERE UNI.IDEEMP = @pIdeEmp
			  AND (@pIdeTipLegAmb IS NULL OR TTIPLICREGAMB.IdeLegAmb = @pIdeTipLegAmb)
			  AND (@pIdeEnd IS NULL OR @pIdeEnd = EPREND.IDEEND)
			  AND (@pIdeTipLicRegAmb IS NULL OR @pIdeTipLicRegAmb = TTIPLICREGAMB.IDETIPLICREGAMB)
			  AND (@pIdeEprLicAmb    IS NULL OR @pIdeEprLicAmb    = EPR.IDEEPRLICAMB)
			  AND (@pIdeUsu IS NULL OR @pIdeUsu = TAR.IDEUSURES)
			  AND (@AgendamentoFuturo = 0 OR TAR.FIMREA IS NULL)
			  AND TAR.Del = 0
			  AND (@pSomenteTarefasPrincipais = 0 OR TAR.REMRELGRA = 0)
                AND (@pIdeUni IS NULL
                    OR ( (@pSub3Niv = 0 AND EPR.IdeUni = @pIdeUni) 
                            OR (@pSub3Niv <> 0 and EPR.IdeUni IN (SELECT IDEUNI FROM [dbo].[DefinirArvoreSubordinadas](@pIdeUni)))))
                AND (   (TAR.FREREC = 0 AND TAR.FIMPRE BETWEEN @pDatIni AND @pDatFim)
                    OR (TAR.FREREC <> 0 AND TAR.INIPRE IS NOT NULL  AND ((TAR.INIPRE BETWEEN @pDatIni AND @pDatFim) 
                                                                        OR (TAR.FIMPRE BETWEEN @pDatIni AND @pDatFim) 
                                                                        OR (TAR.INIPRE < @pDatIni AND TAR.FIMPRE > @pDatFim)
																		OR EXISTS (SELECT TOP 1 IDEPACTAR FROM TPACTAREXCRECLOG WHERE DATPRE BETWEEN @pDatIni AND @pDatFim AND TAR.IDEPACTAR = TPACTAREXCRECLOG.IDEPACTAR)
																		)))
            GROUP BY UNI.IDEUNI, PLA.IDEPLAACO, TAR.IDEPACTAR, TAR.INIPRE, TAR.FIMPRE, TAR.FIMREA, TAR.PRXEXCREC, TAR.FREREC
            ORDER BY TAR.FREREC, TAR.IDEPACTAR, TAR.FIMPRE
    END
	ELSE
	BEGIN
        DECLARE CursorAcoes CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
        SELECT  MAX(LOG.IDEPACTAREXCRECLOG),
                UNI.IDEUNI,
				AMB.IDELICAMB IDEVIN,
                PLA.IDEPLAACO, 
                TAR.IDEPACTAR, 
                TAR.INIPRE, 
                TAR.FIMPRE, 
                TAR.FIMREA, 
                TAR.PRXEXCREC, 
                TAR.FREREC, 
                COALESCE(MAX(LOG.DATPRE), TAR.INIPRE) MAXDATPRE
             FROM TPACTAR TAR
            INNER JOIN TPLAACO PLA ON PLA.IDEPLAACO =  TAR.IDEPLAACO
			INNER JOIN TLICAMB AMB ON ((PLA.IDEPLAACO = AMB.IDEPLAACOCND AND UPPER(@pTipoRelacionamento) = 'CONDICIONANTES') OR 
									   (PLA.IDEPLAACO = AMB.IDEPLAACOCMP AND UPPER(@pTipoRelacionamento) = 'COMPENSATORIAS') OR 
									   (PLA.IDEPLAACO = AMB.IDEPLAACONTF AND UPPER(@pTipoRelacionamento) = 'NOTIFICACOESTERMOSDECOMPRIMISSO') OR 
									   (PLA.IDEPLAACO = AMB.IDEPLAACOORIBAS AND UPPER(@pTipoRelacionamento) = 'ORIENTACOES') OR 
									   (PLA.IDEPLAACO = AMB.IDEPLAACOPRGAMB AND UPPER(@pTipoRelacionamento) = 'PROGRAMASAMBIENTAIS'))
            INNER JOIN TEPRLICAMB EPR ON AMB.IDEEPRLICAMB = EPR.IDEEPRLICAMB 
            INNER JOIN TUNI UNI ON EPR.IDEUNI = UNI.IDEUNI
			INNER JOIN TTIPLICAMB ON TTIPLICAMB.IDETIPLICAMB = AMB.IDETIPLICAMB
            INNER JOIN TTIPLICREGAMB ON TTIPLICREGAMB.IDETIPLICREGAMB = EPR.IDETIPLICREGAMB
             LEFT JOIN TEPRLICAMBEND EPREND ON (EPREND.IDEEPRLICAMB = EPR.IDEEPRLICAMB AND EPREND.TIPEPRLICAMBEND = @pTipoEndereco)
             LEFT JOIN TPACTAREXCRECLOG LOG ON TAR.IDEPACTAR = LOG.IDEPACTAR AND LOG.TYP = 'PortalSIM.Domain.Atividades.Execucao'
            WHERE UNI.IDEEMP = @pIdeEmp
			  AND (@pIdeTipLicAmb IS NULL OR TTIPLICAMB.IDETIPLICAMB = @pIdeTipLicAmb)
			  AND (@pIdeTipLegAmb IS NULL OR TTIPLICREGAMB.IdeLegAmb = @pIdeTipLegAmb)
			  AND (@pIdeEnd IS NULL OR @pIdeEnd = EPREND.IDEEND)
			  AND (@pIdeTipLicRegAmb IS NULL OR @pIdeTipLicRegAmb = TTIPLICREGAMB.IDETIPLICREGAMB)
			  AND (@pIdeEprLicAmb    IS NULL OR @pIdeEprLicAmb    = EPR.IDEEPRLICAMB)
			  AND (@pIdeUsu IS NULL OR @pIdeUsu = TAR.IDEUSURES)
			  AND (@pTipoPrimitivoLicenca IS NULL OR TTIPLICAMB.TIP = @pTipoPrimitivoLicenca)
			  AND (@pTipoLicencaAmbiental IS NULL OR TTIPLICAMB.TIPLIC = @pTipoLicencaAmbiental)
			  AND (@AgendamentoFuturo = 0 OR TAR.FIMREA IS NULL)
		      AND AMB.Stt <> 4 /* Indeferida */
		      AND AMB.Stt <> 5 /* Cancelada */
			  AND TAR.Del = 0
			  AND (@pSomenteTarefasPrincipais = 0 OR TAR.REMRELGRA = 0)
                AND (@pIdeUni IS NULL
                    OR ( (@pSub3Niv = 0 AND EPR.IdeUni = @pIdeUni) 
                            OR (@pSub3Niv <> 0 and EPR.IdeUni IN (SELECT IDEUNI FROM [dbo].[DefinirArvoreSubordinadas](@pIdeUni)))))
                AND (   (TAR.FREREC = 0 AND TAR.FIMPRE BETWEEN @pDatIni AND @pDatFim)
                    OR (TAR.FREREC <> 0 AND TAR.INIPRE IS NOT NULL  AND ((TAR.INIPRE BETWEEN @pDatIni AND @pDatFim) 
                                                                        OR (TAR.FIMPRE BETWEEN @pDatIni AND @pDatFim) 
                                                                        OR (TAR.INIPRE < @pDatIni AND TAR.FIMPRE > @pDatFim)
																		OR EXISTS (SELECT TOP 1 IDEPACTAR FROM TPACTAREXCRECLOG WHERE DATPRE BETWEEN @pDatIni AND @pDatFim AND TAR.IDEPACTAR = TPACTAREXCRECLOG.IDEPACTAR)
																		)))
            GROUP BY UNI.IDEUNI, AMB.IDELICAMB, PLA.IDEPLAACO, TAR.IDEPACTAR, TAR.INIPRE, TAR.FIMPRE, TAR.FIMREA, TAR.PRXEXCREC, TAR.FREREC
            ORDER BY TAR.FREREC, TAR.IDEPACTAR, TAR.FIMPRE
    END

    OPEN CursorAcoes
    FETCH NEXT FROM CursorAcoes INTO @IdePacTarExcRecLog, @IdeUni, @IdeVin, @IdePlaaco, @IdePactar, @IniPre, @FimPre, @FimRea, @ProxExe, @FreRec, @MaxDatPre
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @FreRec = 0
        BEGIN
            SELECT @lData_Referencia = @FimPre,
                   @lData_Prevista = @FimPre,
                   @lData_Realizada = @FimRea

            INSERT INTO @Object_CumprimentoAcoes_Table VALUES(@IdePacTarExcRecLog, @IdeUni, @IdeVin, @IdePlaaco, @IdePactar, @FreRec, @IniPre, @lData_Prevista, @lData_Referencia, @lData_Realizada)
        END
        ELSE
        BEGIN
            SET @lData_Referencia = NULL
			
			DECLARE CursorExecucoesRecursivas CURSOR LOCAL FOR
			SELECT LOG.DATPRE, LOG.ULTEXCREC, MAX(LOG.IDEPACTAREXCRECLOG)
			FROM TPACTAREXCRECLOG LOG
			WHERE   LOG.IDEPACTAR = @IdePacTar
				AND LOG.DATPRE BETWEEN @pDatIni AND @pDatFim
				AND LOG.TYP = 'PortalSIM.Domain.Atividades.Execucao'
			GROUP BY LOG.DATPRE, LOG.ULTEXCREC
			ORDER BY LOG.DATPRE

            OPEN CursorExecucoesRecursivas
            FETCH NEXT FROM CursorExecucoesRecursivas INTO @lDatPreExe, @lDatUltExe, @IdePacTarExcRecLog

            WHILE @@FETCH_STATUS = 0
            BEGIN
                SELECT @lData_Prevista = @FimPre,
                       @lData_Referencia = @lDatPreExe,
                       @lData_Realizada = @lDatUltExe

                INSERT INTO @Object_CumprimentoAcoes_Table VALUES(@IdePacTarExcRecLog, @IdeUni, @IdeVin, @IdePlaaco, @IdePactar, @FreRec, @IniPre, @lData_Prevista, @lData_Referencia, @lData_Realizada)

                FETCH NEXT FROM CursorExecucoesRecursivas INTO @lDatPreExe, @lDatUltExe, @IdePacTarExcRecLog
            END
            CLOSE CursorExecucoesRecursivas
			DEALLOCATE CursorExecucoesRecursivas


           	IF @lData_Referencia IS NULL 
				SET @lData_Referencia = @IniPre

            WHILE (@lData_Referencia <= @pDatFim AND (@AgendamentoFuturo = 1 OR @lData_Referencia <= GETDATE()) AND @lData_Referencia <= @FimPre AND (@lData_Referencia <= @FimRea OR @FimRea IS NULL))
            BEGIN
				

                IF @lData_Referencia >= @pDatIni
                BEGIN
					
                    IF NOT EXISTS(SELECT 1 FROM @Object_CumprimentoAcoes_Table WHERE IDEPACTAR = @IdePacTar AND DATEADD(DD, DATEDIFF(DD, 0, DATREF), 0) = DATEADD(DD, DATEDIFF(DD, 0, @lData_Referencia), 0))
                    BEGIN
                        INSERT INTO @Object_CumprimentoAcoes_Table VALUES(null, @IdeUni, @IdeVin, @IdePlaaco, @IdePactar, @FreRec, @IniPre, @lData_Prevista, @lData_Referencia, NULL)
                    END
                END

                SET @lData_Referencia = CASE @FreRec WHEN 1 /* DiÃ¡rio */      THEN DATEADD(D, 1, @lData_Referencia) 
                                                     WHEN 2 /* Semanal */     THEN DATEADD(D, 7, @lData_Referencia)
                                                     WHEN 3 /* Quinzenal */   THEN DATEADD(D, 15,@lData_Referencia)
                                                     WHEN 4 /* Mensal */      THEN DATEADD(M, 1, @lData_Referencia)
                                                     WHEN 5 /* Bimestral */   THEN DATEADD(M, 2, @lData_Referencia)
                                                     WHEN 6 /* Trimestral */  THEN DATEADD(M, 3, @lData_Referencia)
                                                     WHEN 7 /* Quadrimestral*/THEN DATEADD(M, 4, @lData_Referencia)
                                                     WHEN 8 /* Semestral */   THEN DATEADD(M, 6, @lData_Referencia)
                                                     WHEN 9 /* Anual */       THEN DATEADD(YY, 1, @lData_Referencia)
                                                     WHEN 10 /* Bienal */     THEN DATEADD(YY, 2, @lData_Referencia)
                                                     WHEN 11 /* Trienal */    THEN DATEADD(YY, 3, @lData_Referencia)
										END;
            END

        END
        
        FETCH NEXT FROM CursorAcoes INTO @IdePacTarExcRecLog, @IdeUni, @IdeVin, @IdePlaaco, @IdePactar, @IniPre, @FimPre, @FimRea, @ProxExe, @FreRec, @MaxDatPre
    END
    CLOSE CursorAcoes
    DEALLOCATE CursorAcoes

    RETURN
END

GO



IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[ONEGREEN_RetornarFarolImpOpe]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ONEGREEN_RetornarFarolImpOpe]
GO

/****** Object:  UserDefinedFunction [dbo].[ONEGREEN_RetornarFarolImpOpe]    Script Date: 09/04/2015 11:05:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* Fun��o     : ONEGREEN_RetornarFarolImpOpe
   Prop�sito  : Retorna Farol de Implanta��o e Opera��o de um Projeto com base no Licenciamento Sugerido e Datas Desejo de Implanta��o e Opera��o
   Par�metros : pIdeEprLicAmb	- Identificador do Projeto a ser verificado
			  : pIdeClsLicAmb	- Identificador da Classifica��o do Projeto
			  : pDatIniImp		- Data Desejo de Implanta��o
			  : pDatIniOpe		- Data Desejo de Opera��o
    Cria��o    : 14/06/2013 - Eduardo C�sar
    �ltima Alt.: 09/04/2015 - Eduardo C�sar */

CREATE 
FUNCTION [dbo].[ONEGREEN_RetornarFarolImpOpe](@pIdeEprLicAmb DECIMAL, @pIdeClsLicAmb DECIMAL, @pDatIniImp DATETIME, @pDatIniOpe DATETIME)
RETURNS @RetFarolImpOpe TABLE(  IdeEprLicAmb	DECIMAL(13),
								FarImp			INT,
								FarOpe			INT)
AS
BEGIN

DECLARE	@lOrdemLI			INT,
		@lOrdemLO			INT,
		@lIdeLicAmbLI		DECIMAL(13), 
		@lIdeLicAmbLO		DECIMAL(13),
		@lFarolImplantacao	INT,
		@lFarolOperacao		INT,
		@lDataImplantacao	DATETIME,
		@lDataOperacao		DATETIME,
		@lPrazoObtDoc		INT,
		@lPrazoObt			INT
        
	SET @lDataImplantacao = GETDATE()
	SET @lDataOperacao = GETDATE()
	SET @lFarolOperacao = -1


	
	SELECT @lOrdemLI = LI.ORD
	  FROM (SELECT TOP 1 CLSTIP.ORD
			  FROM TCLSLICAMBTIPLICAMB CLSTIP
			 INNER JOIN TTIPLICAMB TIPLICLI ON (TIPLICLI.IDETIPLICAMB = CLSTIP.IDETIPLICAMB AND (TIPLICLI.TIPLIC = 2 OR TIPLICLI.TIPLIC = 3 OR TIPLICLI.TIPLIC = 7)) /* Tipos de licença de Implantação*/
			 WHERE CLSTIP.IDECLSLICAMB = @pIdeClsLicAmb
			 ORDER BY CLSTIP.ORD) LI
	

	 SELECT @lIdeLicAmbLI = vLicAmbImp.IdeLicAmbImp,
			@lDataImplantacao = COALESCE(vLicAmbImp.DatObtImp, vLicAmbImp.DatPreImp)
		FROM (SELECT tLicAmb.IdeLicAmb IdeLicAmbImp,
					tLicAmb.IdeEprLicAmb,
					tLicAmb.DatPre DatPreImp,
					tLicAmb.DatObt DatObtImp														
				FROM tLicAmb INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
				WHERE tLicAmb.IdeEprLicAmb = @pIdeEprLicAmb
				AND (tTipLicAmb.TipLic = 2 OR tTipLicAmb.TipLic = 3 OR tTipLicAmb.TipLic = 7)  /* LI / RevLI / (LP + LI) */
				AND tLicAmb.Stt <> 4 /* Indeferida */
				AND tLicAmb.Stt <> 5 /* Cancelada */
				) vLicAmbImp
		INNER JOIN (SELECT TOP 1 tLicAmb.IdeEprLicAmb, 
							tLicAmb.IdeLicAmb IdeLicAmb
					FROM tLicAmb INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
					WHERE tLicAmb.IdeEprLicAmb = @pIdeEprLicAmb
						AND (tTipLicAmb.TipLic = 2 OR tTipLicAmb.TipLic = 3 OR tTipLicAmb.TipLic = 7)  /* LI / RevLI / (LP + LI) */ 
						AND tLicAmb.Stt <> 4 /* Indeferida */ 
						AND tLicAmb.Stt <> 5 /* Cancelada */ 
					ORDER BY CASE WHEN tLicAmb.DatObt IS NOT NULL THEN tLicAmb.DatObt ELSE tLicAmb.DatPre END DESC) vUltLicAmbImp ON vUltLicAmbImp.IdeEprLicAmb = vLicAmbImp.IdeEprLicAmb 
																		AND vUltLicAmbImp.IdeLicAmb = vLicAmbImp.IdeLicAmbImp 

	 SELECT @lIdeLicAmbLO = vLicAmbOpe.IdeLicAmbOpe,
			@lDataOperacao = COALESCE(vLicAmbOpe.DatObtImp, vLicAmbOpe.DatPreImp)
		FROM (SELECT tLicAmb.IdeLicAmb IdeLicAmbOpe,
					tLicAmb.IdeEprLicAmb,
					tLicAmb.DatPre DatPreImp,
					tLicAmb.DatObt DatObtImp														
				FROM tLicAmb INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
				WHERE tLicAmb.IdeEprLicAmb = @pIdeEprLicAmb
					AND (tTipLicAmb.TipLic = 4 OR tTipLicAmb.TipLic = 5 OR tTipLicAmb.TipLic = 6)  /* LO / RevLO / LOC */
					AND tLicAmb.Stt <> 4 /* Indeferida */ 
					AND tLicAmb.Stt <> 5 /* Cancelada */ 
				) vLicAmbOpe
		INNER JOIN (SELECT TOP 1 tLicAmb.IdeEprLicAmb, 
							tLicAmb.IdeLicAmb IdeLicAmb
					FROM tLicAmb INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
					WHERE tLicAmb.IdeEprLicAmb = @pIdeEprLicAmb
						AND (tTipLicAmb.TipLic = 4 OR tTipLicAmb.TipLic = 5 OR tTipLicAmb.TipLic = 6)  /* LO / RevLO / LOC */
						AND tLicAmb.Stt <> 4 /* Indeferida */ 
						AND tLicAmb.Stt <> 5 /* Cancelada */ 
					ORDER BY CASE WHEN tLicAmb.DatObt IS NOT NULL THEN tLicAmb.DatObt ELSE tLicAmb.DatPre END DESC) vUltLicAmbOpe ON vUltLicAmbOpe.IdeEprLicAmb = vLicAmbOpe.IdeEprLicAmb 
																		AND vUltLicAmbOpe.IdeLicAmb = vLicAmbOpe.IdeLicAmbOpe 

	SELECT @lOrdemLO = LO.ORD
		FROM (SELECt TOP 1 CLSTIP.ORD 
				FROM TCLSLICAMBTIPLICAMB CLSTIP 
				INNER JOIN TTIPLICAMB TIPLICLI ON (TIPLICLI.IDETIPLICAMB = CLSTIP.IDETIPLICAMB AND (TIPLICLI.TIPLIC = 4 OR TIPLICLI.TIPLIC = 5 OR TIPLICLI.TIPLIC = 6)) /* Tipos de licença de Operação*/
				WHERE CLSTIP.IDECLSLICAMB = @pIdeClsLicAmb
				ORDER BY CLSTIP.ORD) LO


	/* Definindo Farol de Implantação */
	IF @pDatIniImp IS NULL
		SET @lFarolImplantacao = -1
	ELSE
	BEGIN

		IF @lIdeLicAmbLI IS NOT NULL 
		BEGIN				
			IF @lDataImplantacao IS NULL
				SET @lFarolImplantacao = -1
			ELSE
				IF @lDataImplantacao > @pDatIniImp
					SET @lFarolImplantacao = 0
				ELSE
					SET @lFarolImplantacao = 2
		END
		ELSE
		BEGIN 
			IF @lOrdemLI IS NULL OR @lIdeLicAmbLO IS NOT NULL
				SET @lFarolImplantacao = -1
			ELSE
			BEGIN
				SELECT @lPrazoObtDoc = SUM(TIPLIC.PRZOBTDOC), @lPrazoObt = SUM(TIPLIC.PRZOBT)
				  FROM TTIPLICAMB TIPLIC 
				 INNER JOIN TCLSLICAMBTIPLICAMB CLSTIP ON TIPLIC.IDETIPLICAMB = CLSTIP.IDETIPLICAMB
				 WHERE CLSTIP.IDECLSLICAMB = @pIdeClsLicAmb
				   AND TIPLIC.IDETIPLICAMB NOT IN (SELECT IDETIPLICAMB FROM TLICAMB LIC WHERE IDEEPRLICAMB = @pIdeEprLicAmb)
				   AND CLSTIP.ORD <= @lOrdemLI
					
				IF @lDataImplantacao IS NULL
					SET @lDataImplantacao = GETDATE()
				ELSE
					SET @lDataImplantacao = DATEADD(M, @lPrazoObt, GETDATE() + @lPrazoObtDoc)
					
				IF @lDataImplantacao > @pDatIniImp
					SET @lFarolImplantacao = 0
				ELSE
					SET @lFarolImplantacao = 2
			END
		END
	END
	
	/* Definindo Farol de Operação */
		IF @pDatIniOpe IS NULL
			SET @lFarolOperacao = -1
		ELSE
		BEGIN
			IF @lIdeLicAmbLO IS NOT NULL 
			BEGIN
				IF @lDataOperacao IS NULL
					SET @lFarolOperacao = -1
				ELSE
					IF @lDataOperacao > @pDatIniOpe
						SET @lFarolOperacao = 0
					ELSE
						SET @lFarolOperacao = 2
			END
			ELSE
			BEGIN
				IF @lOrdemLO IS NULL
					SET @lFarolOperacao = -1
				ELSE
				BEGIN
					SELECT @lPrazoObtDoc = SUM(TIPLIC.PRZOBTDOC), @lPrazoObt = SUM(TIPLIC.PRZOBT)
					  FROM TTIPLICAMB TIPLIC 
					 INNER JOIN TCLSLICAMBTIPLICAMB CLSTIP ON TIPLIC.IDETIPLICAMB = CLSTIP.IDETIPLICAMB
					 WHERE CLSTIP.IDECLSLICAMB = @pIdeClsLicAmb
					   AND TIPLIC.IDETIPLICAMB NOT IN (SELECT IDETIPLICAMB FROM TLICAMB LIC WHERE IDEEPRLICAMB = @pIdeEprLicAmb)
					   AND CLSTIP.ORD > @lOrdemLI
					   AND CLSTIP.ORD <= @lOrdemLO
					
					
					IF @lDataOperacao IS NULL
						SET @lDataOperacao = @lDataImplantacao
					ELSE
						SET @lDataOperacao = DATEADD(M, @lPrazoObt, @lDataImplantacao + @lPrazoObtDoc)
					
					IF @lDataOperacao > @pDatIniOpe
						SET @lFarolOperacao = 0
					ELSE
						SET @lFarolOperacao = 2
				END
			END
		END
	
		INSERT INTO @RetFarolImpOpe(IdeEprLicAmb, FarImp, FarOpe) VALUES (@pIdeEprLicAmb, @lFarolImplantacao, @lFarolOperacao)

 RETURN
 
END
GO



IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[PercentualConclusaoTarefas]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[PercentualConclusaoTarefas]
GO


/****** Object:  UserDefinedFunction [dbo].[PercentualConclusaoTarefas]    Script Date: 03/10/2016 13:51:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[PercentualConclusaoTarefas]
(
	@pTableName     VARCHAR(30),
	@pIdeTable      DECIMAL(13),
	@pData          DATETIME,
	@pPrevisto      DECIMAL(1)
)
RETURNS FLOAT
AS
BEGIN
	DECLARE @lPer			 FLOAT
	DECLARE @HorasTotais     FLOAT
	DECLARE @HorasAteAgora   FLOAT
	DECLARE @CountTarefas    FLOAT

	IF UPPER(@pTableName) = 'TPLAACO'
	BEGIN
		IF @pPrevisto <> 0
		BEGIN

			SELECT @HorasAteAgora = SUM(dbo.RetornarHorasAteAgora(INIPRE, FIMPRE, DURHRA, FREREC, @pData))  
			FROM TPLAACO
			INNER JOIN TPACTAR ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
			WHERE TPLAACO.IDEPLAACO = @pIdeTable
			AND TPACTAR.DEL = 0
			AND DATEADD(DD, DATEDIFF(DD, 0, TPACTAR.INIPRE), 0) <= @pData
			AND (TPACTAR.IDEPACTARSUP IS NOT NULL OR TPACTAR.TEMSUB = 0)

			SELECT @HorasTotais = SUM(CASE WHEN TPACTAR.DURHRA = 0 OR TPACTAR.DURHRA IS NULL THEN 8 ELSE ABS(TPACTAR.DURHRA) END)
			FROM TPLAACO
			INNER JOIN TPACTAR ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
			WHERE TPLAACO.IDEPLAACO = @pIdeTable
			AND TPACTAR.DEL = 0					
			AND (TPACTAR.IDEPACTARSUP IS NOT NULL OR TPACTAR.TEMSUB = 0)			
				
			SET @lPer = @HorasAteAgora * 100 / @HorasTotais

		END ELSE
		BEGIN

			SELECT @HorasAteAgora = SUM( (CASE WHEN FREREC = 0 THEN PERCOMEXC ELSE PERCON END) / 100 * CASE WHEN DURHRA = 0 OR DURHRA IS NULL THEN 8 ELSE ABS(DURHRA) END)
			from (SELECT max(EXC.PERCON) PERCOMEXC, TPACTAR.PERCON , TPACTAR.DURHRA, TPACTAR.FREREC
			FROM TPLAACO
			INNER JOIN TPACTAR ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
			INNER JOIN TPACTAREXCRECLOG EXC ON TPACTAR.IDEPACTAR = EXC.IDEPACTAR
			WHERE TPLAACO.IDEPLAACO = @pIdeTable
			AND TPACTAR.DEL = 0
			AND ((((DATEADD(DD, DATEDIFF(DD, 0, TPACTAR.FIMPRE), 0) <= @pData AND DATEADD(DD, DATEDIFF(DD, 0, TPACTAR.INIREA), 0) <= @pData) or DATEADD(DD, DATEDIFF(DD, 0, TPACTAR.INIREA), 0) <= @pData) AND TPACTAR.FIMREA IS NULL) OR (((DATEADD(DD, DATEDIFF(DD, 0, TPACTAR.FIMPRE), 0) <= @pData) AND TPACTAR.FIMREA IS NOT NULL)OR(DATEADD(DD, DATEDIFF(DD, 0, TPACTAR.FIMREA), 0) <= @pData)))
			AND DATEADD(DD, DATEDIFF(DD, 0, EXC.ULTEXCREC), 0) <= @pData
			AND TPACTAR.PERCON > 0 -- TAREFAS COM EXECUCOES ANTES MESMO DO INICIO PREVISTO
			AND (TPACTAR.IDEPACTARSUP IS NOT NULL OR TPACTAR.TEMSUB = 0)
			GROUP BY TPACTAR.DEL,TPACTAR.DURHRA, TPACTAR.FREREC,TPACTAR.PERCON, tpactar.IDEPACTAR) X

			SELECT @HorasTotais = SUM(CASE WHEN TPACTAR.DURHRA = 0 OR TPACTAR.DURHRA IS NULL THEN 8 ELSE ABS(TPACTAR.DURHRA) END)
			FROM TPLAACO
			INNER JOIN TPACTAR ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
			WHERE TPLAACO.IDEPLAACO = @pIdeTable
			AND TPACTAR.DEL = 0					
			AND (TPACTAR.IDEPACTARSUP IS NOT NULL OR TPACTAR.TEMSUB = 0)

			SET @lPer = @HorasAteAgora * 100 / @HorasTotais		
					
		END
	END
    ELSE
	BEGIN
		SET @lPer = 0
	END

	IF @lPer > 100
		SET @lPer = 100

    RETURN ROUND(@lPer, 2, 1)
END


GO


IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[PercentualPrevConclusaoTarefa]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[PercentualPrevConclusaoTarefa]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* FUNCAO      : [PercentualPrevConclusaoTarefa]         
   PROPOSITO   : RETORNA O PERCENTUAL PREVISTO DE CONCLUSAO DE UMA TAREFA
   PARAMETROS  : pInicioPrevisto: Inicio Previsto da tarefa
                 pFimPrevisto:  Fim PRevisto da tarefa
                 pDurHra:       Dura��o em horas da tarefa
				 @pFreRec:		Periodicidade da tarefa
                 pData:			DATA DE CORTE DA AN�LISE, OU SEJA, ANALISAR A��ES AT� A DATA X                 
   Criacao      : 02/09/2015 - Flavio
   �ltima Alt.  : 03/09/2015 - erac */
   
CREATE FUNCTION [dbo].[PercentualPrevConclusaoTarefa]
(   
    @pInicioPrevisto          DATETIME,
    @pFimPrevisto             DATETIME,    
    @pDurHra                  INT,
    @pFreRec                  DECIMAL(2),
	@pData                    DATETIME
)RETURNS FLOAT
AS
BEGIN
    DECLARE @lPer					  FLOAT
	DECLARE @HorasTotais              FLOAT
	DECLARE @HorasAteAgora            FLOAT
	DECLARE @lData_Referencia		  DATETIME
	DECLARE @lQtdeExecucoes			  INT

	IF @pInicioPrevisto > @pData
		RETURN 0
	
	IF @pFreRec = 0 
		SET @HorasAteAgora = CASE WHEN @pInicioPrevisto < @pData THEN  ABS((DATEDIFF(day, @pInicioPrevisto, @pData))  * 8) ELSE 0 END
    ELSE 
	BEGIN
		SET @lQtdeExecucoes = 0
		SET @lData_Referencia = @pInicioPrevisto

		WHILE (@lData_Referencia < @pData)
		BEGIN

			SET @lData_Referencia = CASE @pFreRec WHEN 1 /* DiÃ¡rio */   THEN DATEADD(D, 1, @lData_Referencia) 
													WHEN 2 /* Semanal */     THEN DATEADD(D, 7, @lData_Referencia)
													WHEN 3 /* Quinzenal */   THEN DATEADD(D, 15,@lData_Referencia)
													WHEN 4 /* Mensal */      THEN DATEADD(M, 1, @lData_Referencia)
													WHEN 5 /* Bimestral */   THEN DATEADD(M, 2, @lData_Referencia)
													WHEN 6 /* Trimestral */  THEN DATEADD(M, 3, @lData_Referencia)
													WHEN 7 /* Quadrimestral*/THEN DATEADD(M, 4, @lData_Referencia)
													WHEN 8 /* Semestral */   THEN DATEADD(M, 6, @lData_Referencia)
													WHEN 9 /* Anual */       THEN DATEADD(YY, 1, @lData_Referencia)
													WHEN 10 /* Bienal */     THEN DATEADD(YY, 2, @lData_Referencia)
													WHEN 11 /* Trienal */    THEN DATEADD(YY, 3, @lData_Referencia)
									END
			SET @lQtdeExecucoes = @lQtdeExecucoes + 1
		END
		SET @HorasAteAgora = @lQtdeExecucoes * 8
	END
	
	
	SET @HorasTotais = CASE WHEN @pDurHra = 0 OR @pDurHra IS NULL THEN 8 ELSE ABS(@pDurHra) END

	SET @lPer = @HorasAteAgora * 100 / @HorasTotais

	IF @lPer > 100
		SET @lPer = 100

    RETURN ROUND(@lPer, 2, 1)

END
GO


IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarArvore]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarArvore]
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO

/* Fun��o       : RETORNARARVORE            
   Prop�sito    : Retorna todo o caminho referente a uma �rvore (utilizado para tabelas com auto relacionamento)            
   Par�metros   : pTableName-Nome da Tabela         
                : pIdeTable-Ide do registro que ter� sua �rvore montada
                : pSeparador-Separador a ser utilizado na gera��o da String da �rvore
   Cria��o      : 04/12/2005 - mar          
   �ltima Alt.  : 15/04/2016 - Leonardo Lage*/           

CREATE FUNCTION [dbo].[RetornarArvore](@pTableName VARCHAR(30), @pIdeTable DECIMAL(13), @pSeparador VARCHAR(10) = ' - ')
RETURNS VARCHAR(500)            
AS          
BEGIN           
    DECLARE @lretn      VARCHAR(500),
        @lTmpNme    VARCHAR(100),
        @lTmpIde    VARCHAR(13),    
        @lPrimeiro      DECIMAL(1),
        @lIdeSpr    DECIMAL(13),
        @lOldIdeSpr DECIMAL(13),
        @lContador  INT

    SET @lTmpNme = ''           
    SET @lIdeSpr = @pIdeTable           
    SET @lPrimeiro = 1          
    SET @lContador = 0

    IF UPPER(@pTableName) = 'TPCS'          
    BEGIN           
        WHILE NOT @lIdeSpr IS NULL AND @lContador <= 100
        BEGIN       
            SELECT @lTmpNme = Nme, @lIdeSpr = IdeSpr FROM tPcs WHERE IdePcs = @lIdeSpr  
            IF @@ROWCOUNT <> 0
            BEGIN
                IF @lPrimeiro = 1   
                BEGIN   
                    SET @lretn = @lTmpNme
                    SET @lPrimeiro = 0
                END 
                    ELSE            
                    SET @lretn = @lTmpNme + @pSeparador + @lretn    
            END
            ELSE
                SET @lIdeSpr = NULL
            
            SET @lContador = @lContador + 1
        END         
    END         
    ELSE            
    BEGIN               
        IF UPPER(@pTableName) = 'TPCS_IDEPCS'           
        BEGIN           
            WHILE NOT @lIdeSpr IS NULL AND @lContador <= 100
            BEGIN       
                SELECT @lTmpIde = CAST(IdePcs AS VARCHAR(13)), @lIdeSpr = IdeSpr FROM tPcs WHERE IdePcs = @lIdeSpr
                IF @@ROWCOUNT <> 0
                BEGIN
                    IF @lPrimeiro = 1   
                    BEGIN   
                        SET @lretn = @lTmpIde
                        SET @lPrimeiro = 0
                    END 
                        ELSE            
                        SET @lretn = @lTmpIde + @pSeparador + @lretn    
                END
                ELSE
                    SET @lIdeSpr = NULL

                SET @lContador = @lContador + 1
            END         
        END             
        ELSE                
        BEGIN               
            IF UPPER(@pTableName) = 'TUNI'          
            BEGIN           
                WHILE NOT @lIdeSpr IS NULL AND @lContador <= 100
                BEGIN       
                    SET @lOldIdeSpr = @lIdeSpr
                    SELECT @lTmpNme = SIG,
                           @lIdeSpr = IDESPR
                      FROM TUNI
                     WHERE TUNI.IDEUNI = @lOldIdeSpr
                    IF @@ROWCOUNT <> 0
                    BEGIN
                        IF @lPrimeiro = 1
                        BEGIN   
                            SET @lretn = @lTmpNme
                            SET @lPrimeiro = 0
                        END 
                            ELSE        
                        BEGIN   
                            SET @lretn = @lTmpNme + @pSeparador + @lretn
                        END 
                    END
                    ELSE
                        SET @lIdeSpr = NULL

                    SET @lContador = @lContador + 1
                END     
            END 
            ELSE                
            BEGIN               
                IF UPPER(@pTableName) = 'TUNI_IDEUNI'
                BEGIN           
                    WHILE NOT @lIdeSpr IS NULL AND @lContador <= 100
                    BEGIN       
                        SET @lOldIdeSpr = @lIdeSpr
                        SELECT @lTmpIde = IDEUNI, 
                               @lIdeSpr = IDESPR
                          FROM TUNI 
                         WHERE TUNI.IDEUNI = @lOldIdeSpr
                        IF @@ROWCOUNT <> 0
                        BEGIN
                            IF @lPrimeiro = 1
                            BEGIN   
                                SET @lretn = @lTmpIde
                                SET @lPrimeiro = 0
                            END 
                                ELSE        
                            BEGIN   
                                SET @lretn = @lTmpIde + @pSeparador + @lretn
                            END 
                        END
                        ELSE
                            SET @lIdeSpr = NULL

                        SET @lContador = @lContador + 1
                    END
                END
                ELSE
                BEGIN
                    IF UPPER(@pTableName) = 'TPSTPUB'           
                    BEGIN           
                        WHILE NOT @lIdeSpr IS NULL AND @lContador <= 100
                        BEGIN       
                            SELECT @lTmpNme = tPstPub.Nme, @lIdeSpr = IdeSpr FROM tPstPub WHERE IdePstPub = @lIdeSpr
                            IF @@ROWCOUNT <> 0
                            BEGIN
                                IF @lPrimeiro = 1   
                                BEGIN   
                                    SET @lretn = @lTmpNme 
                                    SET @lPrimeiro = 0
                                END 
                                ELSE            
                                    SET @lretn = @lTmpNme + @pSeparador + @lretn    
                            END
                            ELSE
                                SET @lIdeSpr = NULL

                            SET @lContador = @lContador + 1
                        END         
                    END             
                    ELSE
                    BEGIN
                        IF UPPER(@pTableName) = 'TPSTPUB_IDEPSTPUB'
                        BEGIN           
                            WHILE NOT @lIdeSpr IS NULL AND @lContador <= 100
                            BEGIN       
                                SET @lOldIdeSpr = @lIdeSpr
                                SELECT @lTmpIde = CAST(TPSTPUB.IDEPSTPUB AS VARCHAR(13)) ,
                                       @lIdeSpr = TPSTPUB.IDESPR 
                                  FROM TPSTPUB
                                 WHERE TPSTPUB.IDEPSTPUB = @lOldIdeSpr  
                                 
                                IF @@ROWCOUNT <> 0
                                BEGIN
                                    IF @lPrimeiro = 1
                                    BEGIN   
                                        SET @lretn = @lTmpIde
                                        SET @lPrimeiro = 0
                                    END 
                                    ELSE        
                                    BEGIN   
                                        SET @lretn = @lTmpIde + @pSeparador + @lretn
                                    END 
                                END
                                ELSE
                                    SET @lIdeSpr = NULL

                                SET @lContador = @lContador + 1
                            END
                        END
                    END
                END
            END
        END
    END

    RETURN(@lretn)                  
END
GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarArvoreTabela]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarArvoreTabela]
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO

/* Fun��o       : RetornarArvoreTabela
   Prop�sito    : Retorna todos os n�veis superiores de um registro, retornando um campo ORD onde quanto menor o valor, maior o nivel (utilizado para tabelas com auto relacionamento)
   Par�metros   : pTableName-Nome da Tabela         
                : pIdeTable-Ide do registro que ter� sua �rvore montada
   Cria��o      : 14/07/2009 - Eduardo C�sar
   �ltima Alt.  : 15/04/2016 - Leonardo Lage*/

CREATE  FUNCTION [dbo].[RetornarArvoreTabela](@pTableName VARCHAR(30), @pIdeTable DECIMAL(13))
RETURNS @lRetTable table(Ide DECIMAL(13), Nme VARCHAR(100), IdeSpr  DECIMAL(13), Ord INT)
AS          
BEGIN           
    DECLARE @lTmpNme    VARCHAR(100),
            @lTmpIde    VARCHAR(13),    
            @lIdeSpr    DECIMAL(13),        
            @lOldIdeSpr DECIMAL(13),
            @lContador  INT
            

    SET @lTmpNme = ''           
    SET @lIdeSpr = @pIdeTable               
    SET @lContador = 0

    IF UPPER(@pTableName) = 'TPCS'          
    BEGIN           
        WHILE NOT @lIdeSpr IS NULL AND @lContador <= 100
        BEGIN       
            SELECT @lTmpNme = Nme, @lIdeSpr = IdeSpr, @lTmpIde = IdePcs FROM tPcs WHERE IdePcs = @lIdeSpr   
            IF @@ROWCOUNT <> 0
            BEGIN
                INSERT INTO @lRetTable(Ide, Nme, IdeSpr, Ord) values(@lTmpIde, @lTmpNme, @lIdeSpr, @lContador)
            END
            ELSE
                SET @lIdeSpr = NULL
            
            SET @lContador = @lContador + 1
        END         
    END 
    ELSE                
    BEGIN                   
        IF UPPER(@pTableName) = 'TUNI'          
        BEGIN           
            WHILE NOT @lIdeSpr IS NULL AND @lContador <= 100
            BEGIN       
                SET @lOldIdeSpr = @lIdeSpr

                SELECT @lTmpNme = TUNI.SIG, 
                       @lTmpIde = CAST(TUNI.IDEUNI AS VARCHAR(13)),
                       @lIdeSpr = TUNI.IDESPR
                  FROM tUni
                 WHERE TUNI.IDEUNI = @lOldIdeSpr    
                IF @@ROWCOUNT <> 0
                BEGIN
                    INSERT INTO @lRetTable(Ide, Nme, IdeSpr, Ord) values(@lTmpIde, @lTmpNme, @lIdeSpr, @lContador)
                END
                ELSE
                    SET @lIdeSpr = NULL

                SET @lContador = @lContador + 1
            END     
        END 
    END

    BEGIN
        IF UPPER(@pTableName) = 'TUSU'
        BEGIN           
            SELECT @lIdeSpr = (SELECT IDEUSUSUP FROM TUSU WHERE IDEUSU = @pIdeTable)
            WHILE NOT @lIdeSpr IS NULL AND @lContador <= 100
            BEGIN       
                SET @lOldIdeSpr = @lIdeSpr

                SELECT @lTmpNme = TUSU.NME,
                       @lTmpIde = TUSU.IDEUSU,
                       @lIdeSpr = TUSU.IDEUSUSUP
                    FROM tUsu
                    WHERE TUSU.IDEUSU = @lOldIdeSpr
                        AND TUSU.STT <> 0
                IF @@ROWCOUNT <> 0
                BEGIN
                    INSERT INTO @lRetTable(Ide, Nme, IdeSpr, Ord) values(@lTmpIde, @lTmpNme, @lIdeSpr, @lContador)
                END
                ELSE
                    SET @lIdeSpr = NULL

                SET @lContador = @lContador + 1
            END     
        END 
    END

	BEGIN
        IF UPPER(@pTableName) = 'TNORREQ'
        BEGIN           
            SELECT @lIdeSpr = (SELECT IDENORREQSUP FROM TNORREQ WHERE IDENORREQ = @pIdeTable)
            WHILE NOT @lIdeSpr IS NULL AND @lContador <= 100
            BEGIN       
                SET @lOldIdeSpr = @lIdeSpr

                SELECT @lTmpNme = TNORREQ.DES,
                       @lTmpIde = TNORREQ.IDENORREQ,
                       @lIdeSpr = TNORREQ.IDENORREQSUP
                    FROM TNORREQ
                    WHERE TNORREQ.IDENORREQ = @lOldIdeSpr
                IF @@ROWCOUNT <> 0
                BEGIN
                    INSERT INTO @lRetTable(Ide, Nme, IdeSpr, Ord) values(@lTmpIde, @lTmpNme, @lIdeSpr, @lContador)
                END
                ELSE
                    SET @lIdeSpr = NULL

                SET @lContador = @lContador + 1
            END     
        END 
    END

	BEGIN
        IF UPPER(@pTableName) = 'TEPRLICAMB'
        BEGIN           
            SELECT @lIdeSpr = (SELECT IDEEPRLICAMB FROM TEPRLICAMB WHERE IDEEPRLICAMB = @pIdeTable)
            WHILE NOT @lIdeSpr IS NULL AND @lContador <= 100
            BEGIN       
                SET @lOldIdeSpr = @lIdeSpr

                SELECT @lTmpNme = TEPRLICAMB.NME,
                       @lTmpIde = TEPRLICAMB.IDEEPRLICAMB,
                       @lIdeSpr = TEPRLICAMB.IDEEPRLICAMBREL
                    FROM TEPRLICAMB
                    WHERE TEPRLICAMB.IDEEPRLICAMB = @lOldIdeSpr
                IF @@ROWCOUNT <> 0
                BEGIN
                    INSERT INTO @lRetTable(Ide, Nme, IdeSpr, Ord) values(@lTmpIde, @lTmpNme, @lIdeSpr, @lContador)
                END
                ELSE
                    SET @lIdeSpr = NULL

                SET @lContador = @lContador + 1
            END     
        END 
    END
	
    RETURN 
END
GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarEstatisticasCond]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarEstatisticasCond]
GO

/****** Object:  UserDefinedFunction [dbo].[RetornarEstatisticasCond]    Script Date: 06/14/2010 15:01:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Função     : RetornarEstatisticasCond  
   Propósito  : Retorna uma estatística anual das condicionantes
   Parâmetros : pData               - Data que corresponte ao ano a ser pesquisado
			  : pIdeEmp             - Identificador da Empresa
			  : pIdeLegAmb          - Identificador da Legislação Ambiental
			  : pIdeUni             - Identificador da Unidade Gerencial
			  : pIdeTipLicRegAmb    - Identificador do Tipo de Empreendimento
			  : pIdeTipLicAmb       - Identificador do Tipo da Licença
			  : pAmpMod             - Indicador de Ampliação do Empreendimento
			  : pImp                - Indicador de Empreendimento Importante
			  : pSub			    - Indicador de Incluir Subordinadas
   Criação    : 14/06/2010 - Eduardo César
   Última Alt.: 15/04/2016 - Leonardo Lage */

CREATE 
FUNCTION [dbo].[RetornarEstatisticasCond](@pData DATETIME, @pIdeEmp DECIMAL, @pIdeLegAmb DECIMAL, @pIdeUni DECIMAL, @pIdeTipLicRegAmb DECIMAL, @pIdeTipLicAmb DECIMAL, @pAmpMod INT, @pImp INT, @pSub INT)
RETURNS @RetEstatisticas TABLE( Dat     DATETIME,
								QtdCon  INTEGER,
								QtdPos  INTEGER,
								QtdCom  INTEGER)
AS
BEGIN


DECLARE @lAno INT,
		@lDataCorte DATETIME,
		@lAtendido INTEGER,
		@lEmAtendimento INTEGER,
		@lNaoAtendido INTEGER,
		
		@lFreRec INTEGER,
		@lAcaRec INTEGER,
		@lIniPre DATETIME,
		@lIniRea DATETIME,
		@lFimPre DATETIME,
		@lFimRea DATETIME,
		@lUltExcRec DATETIME,
		@lDatPre DATETIME
		
		/*Obtem o ano da data passada por parâmetro*/
		SET @lAno = DATEPART(YEAR, @pData)
		SET @lDataCorte = CAST('01-01-' + CAST(@lAno AS VARCHAR(4)) AS DATETIME)
		SET @lAtendido = 0
		SET @lEmAtendimento = 0
		SET @lNaoAtendido = 0

	WHILE DATEPART(YEAR, @lDataCorte) = @lAno AND @lDataCorte <= GETDATE()
	BEGIN       

		SET @lDataCorte = DATEADD(MONTH, 3, @lDataCorte)

		DECLARE CursorCondicionantes
		CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
		SELECT tPacTar.FreRec,
			   tPacTar.AcaRec,
			   tPacTar.IniPre,
			   tPacTar.IniRea,
			   tPacTar.FimPre,
			   tPacTar.FimRea,
			   vPacTarExcRecLog.UltExcRec,
			   vPacTarExcRecLog.DatPre
		  FROM tEprLicAmb
		 INNER JOIN tTipLicRegAmb on tTipLicRegAmb.IdeTipLicRegAmb = tEprLicAmb.IdeTipLicRegAmb 
		 INNER JOIN tLicAmb ON tLicAmb.IdeEprLicAmb = tEprLicAmb.IdeEprLicAmb
		 INNER JOIN tTipLicAmb ON tTipLicAmb.IdeTipLicAmb = tLicAmb.IdeTipLicAmb
		 INNER JOIN tPacTar ON tPacTar.IdeLicAmbCnd = tLicAmb.IdeLicAmb
		 INNER JOIN tUni ON tUni.IdeUni = tEprLicAmb.IdeUni
		  LEFT JOIN (SELECT tPacTarExcRecLog.IdePacTar, tPacTarExcRecLog.UltExcRec, tPacTarExcRecLog.DatPre
					   FROM (SELECT IdePacTar, MAX(DatPre) DatPre, MAX(UltExcRec) UltExcRec
							   FROM tPacTarExcRecLog
							  WHERE tPacTarExcRecLog.DatPre < @lDataCorte
							  GROUP BY  IdePacTar) vAte
					  INNER JOIN tPacTarExcRecLog ON vAte.IdePacTar = tPacTarExcRecLog.IdePacTar AND vAte.DatPre = tPacTarExcRecLog.DatPre AND vAte.UltExcRec = tPacTarExcRecLog.UltExcRec) vPacTarExcRecLog ON vPacTarExcRecLog.IdePacTar = tPacTar.IdePacTar
		/* INNER JOIN (SELECT tWkfExe.IdeObj, MAX(tWkfExe.DatIni) Dat
					   FROM tWkfExe
					  WHERE tWkfExe.TipObj = 'EmpreendimentoLicenciamentoAmbiental'
						AND tWkfExe.DatIni <= @lDataCorte
					  GROUP BY tWkfExe.IdeObj) vWkf ON vWkf.IdeObj = tEprLicAmb.IdeEprLicAmb
		 INNER JOIN tWkfExe ON tWkfExe.IdeObj = vWkf.IdeObj AND tWkfExe.DatIni = vWkf.Dat AND tWkfExe.TipObj = 'EmpreendimentoLicenciamentoAmbiental'
		 INNER JOIN tWkfAtv ON tWkfAtv.IdeWkfAtv = tWkfExe.IdeWkfAtv
		 INNER JOIN tWkfFas ON tWkfFas.IdeWkfFas = tWkfAtv.IdeWkfFas*/
		 WHERE /*tWkfFas.Nme <> 'cancelado'
		   AND tWkfFas.Nme <> 'desativado'
		   AND EXISTS (SELECT 1
						 FROM tWkfExe
						INNER JOIN tWkfAtv ON tWkfAtv.IdeWkfAtv = tWkfExe.IdeWkfAtv
						INNER JOIN tWkfFas ON tWkfFas.IdeWkfFas = tWkfAtv.IdeWkfFas
						WHERE tWkfExe.TipObj = 'EmpreendimentoLicenciamentoAmbiental'
						  AND tWkfFas.Nme = 'Licenciamento'
						  AND tWkfExe.IdeObj = vWkf.IdeObj)
		   AND */(@pIdeLegAmb IS NULL OR tTipLicRegAmb.IdeLegAmb = @pIdeLegAmb)
		  AND (@pIdeUni IS NULL OR((@pSub = 0 AND tEprLicAmb.IdeUni = @pIdeUni) OR (@pSub <> 0 AND tEprLicAmb.IdeUni IN (SELECT IDEUNI FROM dbo.DefinirArvoreSubordinadas(@pIdeUni)))))

		   AND (@pAmpMod = 0 OR tEprLicAmb.AmpMod <> 0)
		   AND (@pImp = 0 OR tEprLicAmb.Imp <> 0)
		   AND (@pIdeTipLicRegAmb IS NULL OR tEprLicAmb.IdeTipLicRegAmb = @pIdeTipLicRegAmb)
		   AND (@pIdeTipLicAmb IS NULL OR tTipLicAmb.IdeTipLicAmb = @pIdeTipLicAmb)
		   AND tTipLicAmb.IdeEmp = @pIdeEmp
		   AND tPacTar.IniPre < @lDataCorte
		   AND tLicAmb.Stt <> 4 /* Indeferida */ 
		   AND tLicAmb.Stt <> 5 /* Cancelada */  
		 GROUP BY tPacTar.IdePacTar, tPacTar.FreRec, tPacTar.AcaRec, tPacTar.IniPre, tPacTar.IniRea, tPacTar.FimPre, tPacTar.FimRea, vPacTarExcRecLog.UltExcRec, vPacTarExcRecLog.DatPre


		OPEN CursorCondicionantes
		FETCH NEXT FROM CursorCondicionantes INTO @lFreRec, @lAcaRec, @lIniPre, @lIniRea, @lFimPre, @lFimRea, @lUltExcRec, @lDatPre

		WHILE @@FETCH_STATUS = 0
		BEGIN

			IF @lAcaRec <> 0
			BEGIN
				IF @lUltExcRec IS NOT NULL 
				BEGIN
					IF @lFimRea IS NOT NULL 
						SET @lAtendido = @lAtendido + 1
					ELSE IF [dbo].[RetornarProximaDataFrequencia](@lDatPre, @lFreRec) >= @lDataCorte
						SET @lEmAtendimento = @lEmAtendimento + 1
					ELSE
						SET @lNaoAtendido = @lNaoAtendido + 1               
				END
				ELSE IF @lIniRea IS NOT NULL
				BEGIN
					IF [dbo].[RetornarProximaDataFrequencia](@lIniRea, @lFreRec) >= @lDataCorte
						SET @lEmAtendimento = @lEmAtendimento + 1
					ELSE
						SET @lNaoAtendido = @lNaoAtendido + 1
				END
				ELSE IF [dbo].[RetornarProximaDataFrequencia](@lIniPre, @lFreRec) >= @lDataCorte
					SET @lEmAtendimento = @lEmAtendimento + 1
				ELSE
					SET @lNaoAtendido = @lNaoAtendido + 1
			END
			ELSE
			BEGIN
				IF @lUltExcRec IS NOT NULL
				BEGIN
					IF @lUltExcRec <= @lDataCorte
						SET @lAtendido = @lAtendido + 1
					ELSE IF @lFimPre IS NOT NULL AND @lFimPre > @lDataCorte
						SET @lEmAtendimento = @lEmAtendimento + 1
					ELSE
						SET @lNaoAtendido = @lNaoAtendido + 1
				END
				ELSE
					SET @lNaoAtendido = @lNaoAtendido + 1
			END


		FETCH NEXT FROM CursorCondicionantes INTO @lFreRec, @lAcaRec, @lIniPre, @lIniRea, @lFimPre, @lFimRea, @lUltExcRec, @lDatPre
		END
		
		IF (@lAtendido + @lEmAtendimento + @lNaoAtendido <> 0)
		BEGIN
			INSERT INTO @RetEstatisticas(Dat, QtdCon, QtdPos, QtdCom) VALUES(@lDataCorte - 1, @lAtendido, @lEmAtendimento, @lNaoAtendido)
			SET @lAtendido = 0 
			SET @lEmAtendimento = 0 
			SET @lNaoAtendido = 0
		END
		
		CLOSE CursorCondicionantes
		DEALLOCATE CursorCondicionantes
		
	END

RETURN  
END
GO


IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarEstatisticasLA]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarEstatisticasLA]
GO

/****** Object:  UserDefinedFunction [dbo].[RetornarEstatisticasLA]    Script Date: 06/14/2010 16:22:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Função      : RetornarEstatisticasLA
    Propósito  : Retorna uma estatística mensal das licenças no período informado
    Parâmetros : pDataInicial        - Data Inicial do periodo
               : pDataFinal          - Data final do período
               : pIdeEmp             - Identificador da Empresa
               : pIdeLegAmb          - Identificador da Legislação Ambiental
               : pIdeUni             - Identificador da Unidade Gerencial
               : pIdeTipLicRegAmb    - Identificador do Tipo de Empreendimento
               : pIdeTipLicAmb       - Identificador do Tipo da Licença
               : pAmpMod             - Indicador de Ampliação do Empreendimento
               : pImp                - Indicador de Empreendimento Importante
			   : pSub                - Indicador de Incluir Subordinadas   
    Criação    : 14/06/2010          - Eduardo César
    Última Alt.: 15/04/2016          - Leonardo Lage */

CREATE 
FUNCTION [dbo].[RetornarEstatisticasLA](@pDataInicial DATETIME, @pDataFinal DATETIME, @pIdeEmp DECIMAL, @pIdeLegAmb DECIMAL, @pIdeUni DECIMAL, @pIdeTipLicRegAmb DECIMAL, @pIdeTipLicAmb DECIMAL, @pAmpMod INT, @pImp INT, @pNmeProj VARCHAR, @pNumLicAmb VARCHAR, @pNumPcs VARCHAR, @pIdeResp DECIMAL, @pSub INT)
RETURNS @RetEstatisticas TABLE( Dat     DATETIME,
                                QtdCon  INT,
                                QtdPos  INT,
                                QtdCom  INT)
AS
BEGIN

DECLARE @lDataCorte DATETIME,
        @lMes DATETIME,
        @lConforme INTEGER,
        @lPossibilidade INTEGER,
        @lComprometidos INTEGER,

        @lIdeEprLicAmb  DECIMAL(13),
        @lNme           NVARCHAR(60),
        @lIdeLicAmb     DECIMAL(13),
        @lPrzObt        INT,
        @lPrzObtDoc     INT,
        @lPrzAleVen     INT,
        @lDatPre        DATETIME,
        @lDatObt        DATETIME,
        @lVenFob        DATETIME,
        @lDatPrt        DATETIME,
        @lDatVal        DATETIME,
        @lLicAmbStt     INT
        
    SET @lConforme = 0
    SET @lPossibilidade = 0
    SET @lComprometidos = 0
    
    SET @lMes = CAST(CAST(DATEPART(MONTH, @pDataInicial) AS VARCHAR(2)) + '-01-' + CAST(DATEPART(YEAR, @pDataInicial) AS VARCHAR(4)) AS DATETIME) 

 WHILE @lMes <= @pDataFinal AND @lMes <= GETDATE()
 BEGIN 
 
    /*Data de corte igual ao ultimo dia do mês*/
    SET @lDataCorte = DATEADD(MONTH, 1, @lMes) - 1

    DECLARE CursorLicencasEmpreendimentos
    CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
    SELECT tEprLicAmb.IdeEprLicAmb,
            tEprLicAmb.Nme,
            vUltLicAmb.IdeLicAmb,
            tTipLicAmb.PrzObt,
            tTipLicAmb.PrzObtDoc,
            tTipLicAmb.PrzAleVen,
            (select vLicAmb.Dat
             from (select tRep.IdeLicAmb, tRep.DatRep Dat, tRep.UpdTme
                     from tRep
                    inner join (select tRep.IdeLicAmb, 
                                        MAX(tRep.UpdTme) UpdTme
                                      from tRep
                                     where tRep.UpdTme <= @lMes
                                     group by tRep.IdeLicAmb) vRep on tRep.IdeLicAmb = vRep.IdeLicAmb and tRep.UpdTme = vRep.UpdTme
                    where tRep.Tip = 1 
                    union 
                    select tLicAmb.IdeLicAmb, tLicAmb.DatPre Dat, UpdTme
                      from tLicAmb
                     where not exists (select 1 from tRep where tRep.IdeLicAmb = tLicAmb.IdeLicAmb ) 
					   AND tLicAmb.Stt <> 4 /* Indeferida */
					   AND tLicAmb.Stt <> 5 /* Cancelada */) vlicamb
            where vlicamb.Idelicamb = vUltLicAmb.IdeLicAmb) DatPre, 
            tLicAmb.DatObt,
            (select vLicAmb.Dat
             from (select tRep.IdeLicAmb, tRep.DatRep Dat, tRep.UpdTme
                     from tRep
                    inner join (select tRep.IdeLicAmb, 
                                        MAX(tRep.UpdTme) UpdTme
                                      from tRep
                                     where tRep.UpdTme <= @lMes
                                     group by tRep.IdeLicAmb) vRep on tRep.IdeLicAmb = vRep.IdeLicAmb and tRep.UpdTme = vRep.UpdTme
                    where tRep.Tip = 2
                    union 
                    select tLicAmb.IdeLicAmb, tLicAmb.VenFob Dat, UpdTme
                      from tLicAmb
                     where not exists (select 1 from tRep where tRep.IdeLicAmb = tLicAmb.IdeLicAmb ) 
					   AND tLicAmb.Stt <> 4 /* Indeferida */
					   AND tLicAmb.Stt <> 5 /* Cancelada */) vlicamb
            where vlicamb.Idelicamb = vUltLicAmb.IdeLicAmb) VenFob,
            tLicAmb.DatPrt,
            tLicAmb.DatVal,
			tLicAmb.Stt
      FROM tEprLicAmb
     INNER JOIN (SELECT X.IdeEprLicAmb, 
                        CASE WHEN X.IdeLicAmbTipLic IS NULL THEN X.IdeLicAmbTip ELSE X.IdeLicAmbTipLic END IdeLicAmb
                    FROM (SELECT Epr.IdeEprLicAmb,
                                (SELECT IdeLicAmb
                                    FROM (SELECT TOP 1 IdeLicAmb, CASE WHEN (DatObt IS NULL OR DatObt > @lMes) THEN DatPre ELSE DatObt END Dat, tLicAmb.IdeEprLicAmb
                                            FROM tLicAmb
                                          INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
                                          WHERE tTipLicAmb.TipLic IS NOT NULL
										    AND tLicAmb.Stt <> 4 /* Indeferida */
										    AND tLicAmb.Stt <> 5 /* Cancelada */
                                            AND (tLicAmb.DatInd IS NULL OR tLicAmb.DatInd > @lMes)
                                            AND (tLicAmb.DatCan IS NULL OR tLicAmb.DatCan > @lMes)
                                            AND CASE WHEN (DatObt IS NULL OR DatObt > @lMes) THEN DatPre ELSE DatObt END <= @lMes
                                          ORDER BY Dat DESC, tLicAmb.VenFob DESC) vLic
                                    WHERE vLic.IdeEprLicAmb = Epr.IdeEprLicAmb) IdeLicAmbTipLic,
                                 (SELECT IdeLicAmb
                                    FROM (SELECT TOP 1 IdeLicAmb, CASE WHEN (DatObt IS NULL OR DatObt > @lMes) THEN DatPre ELSE DatObt END Dat, tLicAmb.IdeEprLicAmb
                                            FROM tLicAmb
                                          INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
                                          WHERE tTipLicAmb.TipLic IS NULL
										    AND tLicAmb.Stt <> 4 /* Indeferida */
										    AND tLicAmb.Stt <> 5 /* Cancelada */
                                            AND (tLicAmb.DatInd IS NULL OR tLicAmb.DatInd > @lMes) 
                                            AND (tLicAmb.DatCan IS NULL OR tLicAmb.DatCan > @lMes) 
                                            AND CASE WHEN (DatObt IS NULL OR DatObt > @lMes) THEN DatPre ELSE DatObt END <= @lMes
                                          ORDER BY Dat DESC, tLicAmb.VenFob DESC) vLic
                                    WHERE vLic.IdeEprLicAmb = Epr.IdeEprLicAmb) IdeLicAmbTip       
                          FROM tEprLicAmb epr) X) vUltLicAmb ON tEprLicAmb.IdeEprLicAmb = vUltLicAmb.IdeEprLicAmb
     INNER JOIN tLicAmb ON tLicAmb.IdeEprLicAmb = tEprLicAmb.IdeEprLicAmb AND tLicAmb.IdeLicAmb = vUltLicAmb.IdeLicAmb
     INNER JOIN tTipLicAmb ON tTipLicAmb.IdeTipLicAmb = tLicAmb.IdeTipLicAmb
     INNER JOIN tTipLicRegAmb on tTipLicRegAmb.IdeTipLicRegAmb = tEprLicAmb.IdeTipLicRegAmb
     INNER JOIN tUni ON tUni.IdeUni = tEprLicAmb.IdeUni
     /* INNER JOIN (SELECT tWkfExe.IdeObj, MAX(tWkfExe.DatIni) Dat
                    FROM tWkfExe
                  WHERE tWkfExe.TipObj = 'EmpreendimentoLicenciamentoAmbiental'
                    AND tWkfExe.DatIni <= @lMes
                  GROUP BY tWkfExe.IdeObj) vWkf ON vWkf.IdeObj = tEprLicAmb.IdeEprLicAmb
     INNER JOIN tWkfExe ON tWkfExe.IdeObj = vWkf.IdeObj AND tWkfExe.DatIni = vWkf.Dat AND tWkfExe.TipObj = 'EmpreendimentoLicenciamentoAmbiental'
     INNER JOIN tWkfAtv ON tWkfAtv.IdeWkfAtv = tWkfExe.IdeWkfAtv
     INNER JOIN tWkfFas ON tWkfFas.IdeWkfFas = tWkfAtv.IdeWkfFas*/
     WHERE /*tWkfFas.Nme <> 'Cancelado'
        AND tWkfFas.Nme <> 'Desativado'
        AND EXISTS (SELECT 1
                     FROM tWkfExe
                    INNER JOIN tWkfAtv ON tWkfAtv.IdeWkfAtv = tWkfExe.IdeWkfAtv
                    INNER JOIN tWkfFas ON tWkfFas.IdeWkfFas = tWkfAtv.IdeWkfFas
                    WHERE tWkfExe.TipObj = 'EmpreendimentoLicenciamentoAmbiental'
                      AND tWkfFas.Nme = 'Licenciamento'
                      AND tWkfExe.IdeObj = vWkf.IdeObj)
        AND */(@pIdeLegAmb IS NULL OR tTipLicRegAmb.IdeLegAmb = @pIdeLegAmb)
		AND tLicAmb.Stt <> 4 /* Indeferida */
		AND tLicAmb.Stt <> 5 /* Cancelada */
        AND (@pIdeUni IS NULL OR((@pSub = 0 AND tEprLicAmb.IdeUni = @pIdeUni) OR (@pSub <> 0 AND tEprLicAmb.IdeUni IN (SELECT IDEUNI FROM dbo.DefinirArvoreSubordinadas(@pIdeUni)))))




        AND (@pAmpMod = 0 OR tEprLicAmb.AmpMod <> 0)
        AND (@pImp = 0 OR tEprLicAmb.Imp <> 0)
        AND (@pIdeTipLicRegAmb IS NULL OR tEprLicAmb.IdeTipLicRegAmb = @pIdeTipLicRegAmb)
        AND (@pIdeTipLicAmb IS NULL OR EXISTS (SELECT 1
                                                FROM tTipLicAmb
                                                INNER JOIN tLicAmb ON tTipLicAmb.IdeTipLicAmb = tLicAmb.IdeTipLicAmb
                                                WHERE tLicAmb.IdeEprLicAmb = tEprLicAmb.IdeEprLicAmb
                                                 AND tTipLicAmb.IdeTipLicAmb = @pIdeTipLicAmb))
        AND tTipLicAmb.IdeEmp = @pIdeEmp
		AND (@pNmeProj IS NULL OR tEprLicAmb.Nme LIKE '%' + @pNmeProj + '%')
		AND (@pNumLicAmb IS NULL OR tLicAmb.Num LIKE '%' + @pNumLicAmb + '%')
		AND (@pNumPcs IS NULL OR tLicAmb.NumPcs LIKE '%' + @pNumPcs + '%')
		AND (@pIdeResp IS NULL OR tEprLicAmb.IdeUsuRes = @pIdeResp)
    
        OPEN CursorLicencasEmpreendimentos
        FETCH NEXT FROM CursorLicencasEmpreendimentos INTO @lIdeEprLicAmb, @lNme, @lIdeLicAmb, @lPrzObt, @lPrzObtDoc, @lPrzAleVen, @lDatPre, @lDatObt, @lVenFob, @lDatPrt, @lDatVal, @lLicAmbStt

            WHILE @@FETCH_STATUS = 0
            BEGIN       

                --Conforme: Se (Licença não foi obtida e a data prevista > hoje + PrzAleVen) ou (foi obtida e data de vencimento > hoje + PrzAleVen)
                IF (@lDatObt IS NULL AND @lDatPre > @lDataCorte + @lPrzAleVen) OR (@lDatObt IS NOT NULL AND @lDatVal > @lDataCorte + @lPrzAleVen) OR @lLicAmbStt = 6 /* Concluida */
                    SET @lConforme = @lConforme + 1
                --Possibilidade: Se (Licença nao foi obtida e a data prevista < hoje + PrzAleVen e prevista > hoje) ou (foi obtida e data de vencimento < hoje + PrzAleVen e vencimento > hoje)
                ELSE IF (@lDatObt IS NULL AND @lDatPre < @lDataCorte + @lPrzAleVen AND @lDatPre > @lDataCorte) OR (@lDatObt IS NOT NULL AND @lDatVal < @lDataCorte + @lPrzAleVen AND @lDatVal > @lDataCorte)
                    SET @lPossibilidade = @lPossibilidade + 1
                --Comprometido: Se (Licença não foi obtida e a data prevista < hoje) ou (foi obtida e data de vencimento < hoje)
                ELSE IF (@lDatObt IS NULL AND @lDatPre < @lDataCorte) OR (@lDatObt IS NOT NULL AND @lDatVal < @lDataCorte)
                    SET @lComprometidos = @lComprometidos + 1

                FETCH NEXT FROM CursorLicencasEmpreendimentos INTO @lIdeEprLicAmb, @lNme, @lIdeLicAmb, @lPrzObt, @lPrzObtDoc, @lPrzAleVen, @lDatPre, @lDatObt, @lVenFob, @lDatPrt, @lDatVal, @lLicAmbStt
            END     
            
        IF (@lConforme + @lPossibilidade + @lComprometidos <> 0)
        BEGIN
            INSERT INTO @RetEstatisticas(Dat, QtdCon, QtdPos, QtdCom) VALUES(@lMes, @lConforme, @lPossibilidade, @lComprometidos)
            set @lConforme = 0 
            set @lPossibilidade = 0 
            set @lComprometidos = 0
        END

         CLOSE CursorLicencasEmpreendimentos
         DEALLOCATE CursorLicencasEmpreendimentos
    
    SET @lMes = DATEADD(MONTH, 1, @lMes)
 END 
 
 RETURN
 
END
GO

IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarEstatisticasLAAnual]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarEstatisticasLAAnual]
GO

/****** Object:  UserDefinedFunction [dbo].[RetornarEstatisticasLAAnual]    Script Date: 06/14/2010 16:23:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Função     : RetornarEstatisticasLAAnual
    Propósito  : Retorna uma estatística anual baseada na media mensal das licenças no período informado
    Parâmetros :   pDataInicial        - Data Inicial do periodo
              : pDataFinal          - Data final do período
              : pIdeEmp             - Identificador da Empresa
              : pIdeLegAmb          - Identificador da Legislação Ambiental
              : pIdeUni             - Identificador da Unidade Gerencial
              : pIdeTipLicRegAmb    - Identificador do Tipo de Empreendimento
              : pIdeTipLicAmb       - Identificador do Tipo da Licença
              : pAmpMod             - Indicador de Ampliação do Empreendimento
              : pImp                   - Indicador de Empreendimento Importante
			  : pSub			    - Indicador de Incluir Subordinadas
    Criação    : 14/06/2010 - Eduardo César
    Última Alt.: 25/07/2012 - max */

CREATE 
FUNCTION [dbo].[RetornarEstatisticasLAAnual](@pDataInicial DATETIME, @pDataFinal DATETIME, @pIdeEmp DECIMAL, @pIdeLegAmb DECIMAL, @pIdeUni DECIMAL, @pIdeTipLicRegAmb DECIMAL, @pIdeTipLicAmb DECIMAL, @pAmpMod INT, @pImp INT, @pNmeProj VARCHAR, @pNumLicAmb VARCHAR, @pNumPcs VARCHAR, @pIdeResp DECIMAL, @pSub INT)
RETURNS @RetEstatisticas TABLE( Dat     DATETIME,
                                QtdCon  INT,
                                QtdPos  INT,
                                QtdCom  INT)
AS
BEGIN

DECLARE @lDataCorte DATETIME,
        @lData DATETIME,
        @lConforme INTEGER,
        @lPossibilidade INTEGER,
        @lComprometidos INTEGER,
        
        @lDat DATETIME,
        @lQtdCon INTEGER,
        @lQtdPos INTEGER,
        @lQtdCom INTEGER

    SET @lConforme = 0
    SET @lPossibilidade = 0
    SET @lComprometidos = 0
        
    SET @lQtdCon = 0
    SET @lQtdPos = 0
    SET @lQtdCom = 0
 
    SET @lData = CAST('01-01-' + CAST(DATEPART(YEAR, @pDataInicial) AS VARCHAR(4)) AS DATETIME) 

    WHILE @lData <= @pDataFinal AND @lData <= GETDATE()
    BEGIN 
    
         /*Data de corte igual ao ultimo dia do ano*/
        SET @lDataCorte = DATEADD(YEAR, 1, @lData) - 1
     
        DECLARE CursorEstatisticasLA
        CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
        SELECT Dat,
                QtdCon,
                QtdPos,
                QtdCom
          FROM [dbo].[RetornarEstatisticasLA](@lData, @lDataCorte, @pIdeEmp, @pIdeLegAmb, @pIdeUni, @pIdeTipLicRegAmb, @pIdeTipLicAmb, @pAmpMod, @pImp, @pNmeProj, @pNumLicAmb, @pNumPcs, @pIdeResp, @pSub)
          
        OPEN CursorEstatisticasLA
        FETCH NEXT FROM CursorEstatisticasLA INTO @lDat, @lQtdCon, @lQtdPos, @lQtdCom
        
        WHILE @@FETCH_STATUS = 0
        BEGIN
        
            SET @lConforme = @lConforme + @lQtdCon
            SET @lPossibilidade = @lPossibilidade + @lQtdPos
            SET @lComprometidos = @lComprometidos + @lQtdCom
        
            FETCH NEXT FROM CursorEstatisticasLA INTO @lDat, @lQtdCon, @lQtdPos, @lQtdCom
        
        END
        

        IF (@lConforme + @lPossibilidade + @lComprometidos <> 0)
        BEGIN
            INSERT INTO @RetEstatisticas(Dat, QtdCon, QtdPos, QtdCom) VALUES(@lData, @lConforme, @lPossibilidade, @lComprometidos)
            SET @lConforme = 0 
            SET @lPossibilidade = 0 
            SET @lComprometidos = 0
        END
        
        CLOSE CursorEstatisticasLA
        DEALLOCATE CursorEstatisticasLA
     
        SET @lData = DATEADD(YEAR, 1, @lData)
     END
     
    RETURN

END


GO




IF  EXISTS (SELECT * FROM sysobjects WHERE ID = OBJECT_ID(N'[dbo].[RetornarFarolCustos]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarFarolCustos]
GO


/****** Object:  UserDefinedFunction [dbo].[RetornarFarolCustos]    Script Date: 10/11/2012 09:20:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE  FUNCTION [dbo].[RetornarFarolCustos](@pIdeSolPrb    DECIMAL)
RETURNS INT
AS
BEGIN
    DECLARE @lDiferencaEntreAcumulados                              INT 
    
    SET @lDiferencaEntreAcumulados =   (SELECT SUM(tGesFinIte.DESPRE) - SUM(tGesFinIte.DESREA)
                                        FROM tSolPrb
                                  INNER JOIN tSolPrbPas on tSolPrbPas.IdeSolPrb = tSolPrb.IdeSolPrb
                                  INNER JOIN tFer on tFer.IdeSolPrbPas = tSolPrbPas.IdeSolPrbPas
                                  INNER JOIN tGesFinIte on tGesFinIte.IdeGesFin = tFer.IdeGesFin
                                       WHERE tSolPrb.IdeSolPrb = @pIdeSolPrb)                                          
    
    IF (@lDiferencaEntreAcumulados >= 0)
    BEGIN
        RETURN 2
    END

    IF(@lDiferencaEntreAcumulados is null)
    BEGIN
        RETURN Null
    END
    
    RETURN 0
END
GO



IF EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarFarolIndTec]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarFarolIndTec]
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER ON
GO

/* Função      : [RetornarFarolIndTec]
   Propósito   : Retorna o Farol do Pior indicador tecnico Vinculado ao Projeto EPM
   Parâmetros  : pIdeSolPrb - Identificador da Solução de Problemas
   Retorno     : 0 - Farol Vermelho
                 1 - Farol Amarelo
                 2 - Farol Verde
                 3 - Farol Azul
                 NULL ou 9 - Caso o valor de meta ou do realizado sejam nulos, ou seja, não é possível determinar o farol
   Criação     : 08/08/2012 - Mar/Kdu
   Última Alt. : 08/08/2012 - Mar/Kdu */

CREATE FUNCTION [dbo].[RetornarFarolIndTec](@pIdeSolPrb DECIMAL(13), @pGetDate DATETIME)
RETURNS INT
AS
BEGIN
    DECLARE @lFarIndPro INT

	DECLARE @pInicio DATETIME
	DECLARE @pFim DATETIME

	SET @pInicio = DATEADD(MONTH, -6, @pGetDate)
	SET @pFim = DATEADD(MONTH, -1, @pGetDate) -- 6 MESES FORA O MES

	SET @pInicio = CONVERT(DATETIME, CONVERT(VARCHAR, DATEPART(YEAR, @pInicio)) + '-' + CONVERT(VARCHAR, DATEPART(MONTH, @pInicio)) + '-01') 
	SET @pFim = CONVERT(DATETIME, CONVERT(VARCHAR, DATEPART(YEAR, @pFim)) + '-' + CONVERT(VARCHAR, DATEPART(MONTH, @pFim)) + '-01')

    SELECT @lFarIndPro = MIN(FAROL) FROM (

        SELECT TSIMPARIND.IDESIMPARIND,
               TACO.IDEUNI,
               TACO.IDEIND,
               TACO.IDEITEETD1,
               TACO.IDEITEETD2,
               TACO.IDEITEETD3,
               TACO.IDEITEETD4,
               TACO.IDEITEETD5,
               TACO.IDEITEETD6,
               AVG(TVALACO.REA) REA,
               AVG(TVALACO.MET) MET,
               AVG(TVALACO.METINF) METINF,
               AVG(TVALACO.METSUP) METSUP,
               DBO.INDICADORES_DEFINIRFAROL(AVG(TVALACO.REA), AVG(TVALACO.MET), AVG(TVALACO.METINF), AVG(TVALACO.METSUP), TIND.MEL, TIND.ACECEN, TACO.PERTOLAZL, TACO.PERTOLVRD, TACO.PERTOLVRDINF, TACO.PERTOLAMR, TACO.PERTOLAMRINF, TACO.IDEIND, 1, 2, 4, 1, 3, TACO.PRC) FAROL
          FROM TSIMPARIND
    INNER JOIN TACO ON TSIMPARIND.IDEUNI = TACO.IDEUNI 
                   AND TSIMPARIND.IDEIND = TACO.IDEIND 
                   AND ISNULL(TSIMPARIND.IDEITEETD1, 0) = ISNULL(TACO.IDEITEETD1, 0)
                   AND ISNULL(TSIMPARIND.IDEITEETD2, 0) = ISNULL(TACO.IDEITEETD2, 0)
                   AND ISNULL(TSIMPARIND.IDEITEETD3, 0) = ISNULL(TACO.IDEITEETD3, 0)
                   AND ISNULL(TSIMPARIND.IDEITEETD4, 0) = ISNULL(TACO.IDEITEETD4, 0)
                   AND ISNULL(TSIMPARIND.IDEITEETD5, 0) = ISNULL(TACO.IDEITEETD5, 0)
                   AND ISNULL(TSIMPARIND.IDEITEETD6, 0) = ISNULL(TACO.IDEITEETD6, 0)
     LEFT JOIN TIND ON TACO.IDEIND = TIND.IDEIND
    INNER JOIN TVALACO ON TACO.IDEACO = TVALACO.IDEACO
    INNER JOIN TSIMPAR ON TSIMPARIND.IDESIMPARIND = TSIMPAR.IDESIMPAR
    INNER JOIN TSOLPRBSIMPAR ON TSIMPAR.IDESIMPAR = TSOLPRBSIMPAR.IDESIMPAR
    INNER JOIN TSOLPRB ON TSOLPRBSIMPAR.IDESOLPRB = TSOLPRB.IDESOLPRB
         WHERE TVALACO.FRE = 1
           AND TVALACO.TIP = 1
           AND TVALACO.OCO BETWEEN @pInicio AND @pFim
           AND TSOLPRB.IDESOLPRB = @pIdeSolPrb
      GROUP BY TSIMPARIND.IDESIMPARIND,
               TIND.MEL,
               TIND.ACECEN,
               TACO.PERTOLAZL,
               TACO.PERTOLVRD,
               TACO.PERTOLVRDINF,
               TACO.PERTOLAMR,
               TACO.PERTOLAMRINF,
               TACO.IDEUNI,
               TACO.IDEIND,
               TACO.IDEITEETD1,
               TACO.IDEITEETD2,
               TACO.IDEITEETD3,
               TACO.IDEITEETD4,
               TACO.IDEITEETD5,
               TACO.IDEITEETD6, 
			   TACO.PRC
    ) vFarIndTec

    RETURN(@lFarIndPro)
END
GO




/****** Object:  UserDefinedFunction [dbo].[RetornarFarolLicencas]    Script Date: 6/27/2018 10:12:34 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarFarolLicencas]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarFarolLicencas]
GO

/* Fun��o     : RetornarFarolLicencas
   Prop�sito  : Retorna o Farol das Licen�as de determinado Empreendimento da Empresa
   Par�metros :    pIdeEprLicAmb   - Identificador do Empreendimento
              : pTip            - Tipo Primitivo do Tipo de Licen�a
              : pTipLic         - Tipo do "Tipo de Licen�a" quando for "Licen�a Ambiental" (LP-LI-RLI-LO-LOC-RevLO)
   Cria��o    : 21/07/2009 - Eduardo C�sar
   �ltima Alt.: 27/07/2018 - Eduardo C�sar */
 
CREATE FUNCTION [dbo].[RetornarFarolLicencas](@pIdeEprLicAmb DECIMAL, @pTip INT, @pTipLic INT)
RETURNS NVARCHAR(4000)
AS
BEGIN
    DECLARE 
        @FarolLicencas      NVARCHAR(4000),
        @lTmpIdeTipLicAmb   DECIMAL(13),
        @lTmpSigTipLicAmb   NVARCHAR(10),
        @lTmpDesTipLicAmb   NVARCHAR(100),
        @lFarol             INT,
		@lFarolAux          INT,
        
        @lLicencaObtida     INT,
        @lIdeTipLicAmb      DECIMAL(13),
        @lSigTipLicAmb      NVARCHAR(10),
        @lDesTipLicAmb      NVARCHAR(100),
        @lIdeLicAmb         DECIMAL(13),
        @lPrzAleVen         INT,
        @lDatPrt            DATETIME,
        @lDatPre            DATETIME,
        @lDatObt            DATETIME,
        @lDatVal            DATETIME,
        @lDat               DATETIME,
        @lTipLic            INT,
		@lSttLicAmb			INT,
		@lVenFob			DATETIME,
		@lQtdDiaVen			INT,
		@lIdeLicAmbRel		DECIMAL(13),
		@lDatPrtRel			DATETIME,
		@lDatLimRen			DATETIME

        SET @lTmpSigTipLicAmb = ''
        SET @lTmpDesTipLicAmb = ''
        SET @FarolLicencas = ''
        SET @lTmpIdeTipLicAmb = 0
        SET @lLicencaObtida = 0
        SET @lFarol = 0

        DECLARE CursorLicencas CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
        SELECT tTipLicAmb.IdeTipLicAmb,
               tTipLicAmb.Sig SigTipLicAmb,
			   tTipLicAmb.Des DesTipLicAmb,
               tTipLicAmb.PrzAleVen,
               tLicAmb.IdeLicAmb,
               tLicAmb.DatPrt,
               tLicAmb.DatPre,
               tLicAmb.DatObt,
               tLicAmb.DatVal,
			   tLicAmb.VenFob,
               tLicAmb.QtdDiaVen,
               tTipLicAmb.TipLic,
               CASE WHEN tLicAmb.DatObt IS NOT NULL THEN tLicAmb.DatObt ELSE tLicAmb.DatPre END Dat,
			   tLicAmb.Stt,
			   LicRel.IDELICAMB IDELICAMBREL,
			   LicRel.DATPRT DATPRTREL,
			   case when ttIPLicAmb.PmtRnv = 1 
					then case when tLicAmb.DATLIMRENMAN = 1 
							then tLicAmb.DATLIMREN
							else tLicAmb.DatVal - ttIPLicAmb.PRZLMTRNV
						 end
					else null
			   end DATLIMREN
          FROM tEprLicAmb Epr
         INNER JOIN tLicAmb ON Epr.IdeEprLicAmb = tLicAmb.IdeEprLicAmb
         INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
		  LEFT JOIN tLicAmb LicRel on tLicAmb.IDELICAMBREL = LicRel.IDELICAMB
         WHERE Epr.IdeEprLicAmb = @pIdeEprLicAmb
           AND (@pTip IS NULL OR tTipLicAmb.Tip = @pTip)
           AND (@pTipLic IS NULL OR tTipLicAmb.TipLic = @pTipLic)
		   AND tLicAmb.Stt <> 4 /* Indeferida */ 
		   AND tLicAmb.Stt <> 5 /* Cancelada */   
         ORDER BY CASE WHEN TTIPLICAMB.TIPLIC IS NULL OR TTIPLICAMB.TIPLIC = 0 THEN TTIPLICAMB.TIP ELSE TTIPLICAMB.TIPLIC END, TTIPLICAMB.IDETIPLICAMB, case when tLicAmb.DatObt IS NULL and tLicAmb.DatPre is null then 1 else 0 end, Dat, tTipLicAmb.TipLic, tLicAmb.IdeLicAmb
        
        IF @pTip IS NULL
            RETURN NULL

        OPEN CursorLicencas
        FETCH CursorLicencas INTO @lIdeTipLicAmb, @lSigTipLicAmb, @lDesTipLicAmb, @lPrzAleVen, @lIdeLicAmb, @lDatPrt, @lDatPre, @lDatObt, @lDatVal, @lVenFob, @lQtdDiaVen, @lTipLic, @lDat, @lSttLicAmb, @lIdeLicAmbRel, @lDatPrtRel, @lDatLimRen

        IF @lIdeTipLicAmb IS NOT NULL
        BEGIN
            SET @lTmpIdeTipLicAmb = @lIdeTipLicAmb
            SET @lTmpSigTipLicAmb = @lSigTipLicAmb
			SET @lTmpDesTipLicAmb = @lDesTipLicAmb
        END

        WHILE @@FETCH_STATUS = 0
        BEGIN

            IF @lTmpIdeTipLicAmb <> @lIdeTipLicAmb AND @pTip IS NOT NULL
            BEGIN
				SET @lFarolAux = CASE @lFarol
								 WHEN 1 THEN 6 /* Conclu�da */
								 WHEN 2 THEN 1 /* Concedida */
								 WHEN 3 THEN 3 /* N�o Formalizada */
								 WHEN 4 THEN 7 /* Em renova��o */
								 WHEN 5 THEN 2 /* Formalizada */
								 WHEN 6 THEN 4 /* Pr�xima do prazo */
								 WHEN 7 THEN 5 /* Atrasada ou Vencida */
								 ELSE 0
								 END

                SET @FarolLicencas = @FarolLicencas + '#' + @lTmpSigTipLicAmb + '�' + CAST(@lFarolAux as NVARCHAR) + '�' + CAST(@lLicencaObtida as NVARCHAR) + '�' + CAST(@lTmpDesTipLicAmb as NVARCHAR) + '�' + CAST(@lTmpIdeTipLicAmb as NVARCHAR)

                SET @lTmpIdeTipLicAmb = @lIdeTipLicAmb
                SET @lTmpSigTipLicAmb = @lSigTipLicAmb
				SET @lTmpDesTipLicAmb = @lDesTipLicAmb
				SET @lFarol = 0
             END

		/* ORDEM DE IMPORT�NCIA DOS FAROIS DAS LICEN�AS
				Vermelha:	Atrasada ou Vencida (5) -> 7
				 Laranja:	Pr�xima do prazo (4) -> 6
					Azul:	Formalizada (2) -> 5
				  Marrom:	Em renova��o (7) -> 4
				  Branca:	N�o Formalizada (3) -> 3
				   Verde:	Concedida (1) -> 2
		 Verde rachurada:	Conclu�da (6) -> 1
		*/

            IF @lSttLicAmb <> 6 /* Concluida */
				BEGIN
					IF @lDatObt IS NOT NULL AND @lIdeLicAmbRel IS NOT NULL AND @lDatLimRen IS NOT NULL
						BEGIN
							IF (@lDatPrtRel IS NULL AND @lDatLimRen < DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0)) OR (@lDatPrtRel IS NOT NULL AND @lDatLimRen < @lDatPrtRel)
							BEGIN
								SET @lFarol = 7;--5
							END
							ELSE
							BEGIN
								IF @lFarol < 4
									SET @lFarol = 4--7
							END
						END 
					ELSE IF @lDatVal IS NOT NULL AND @lDatVal < DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0) 
						BEGIN
							SET @lFarol = 7--5
						END 
					ELSE IF @lDatPre IS NOT NULL AND @lDatPre < DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0) AND @lDatObt IS NULL
						BEGIN
							SET @lFarol = 7--5
						END 
					
					ELSE IF @lDatVal IS NOT NULL AND (@lDatVal - @lPrzAleVen) < DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0) AND (@lFarol < 6)
						BEGIN
							SET @lFarol = 6--4
						END
						
					ELSE IF @lDatObt IS NULL AND @lDatPre IS NOT NULL AND (@lDatPre - @lPrzAleVen) < DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0) AND (@lFarol < 6)
						BEGIN
							SET @lFarol = 6--4
						END
						
					ELSE IF @lDatObt IS NULL AND @lDatPrt IS NULL AND (@lFarol < 3)
						BEGIN
							SET @lFarol = 3
						END
						
					ELSE IF @lDatObt IS NULL AND @lDatPrt IS NOT NULL AND (@lFarol < 5)
						BEGIN
							SET @lFarol = 5--2
						END
						
					ELSE IF (@lFarol < 2)
						BEGIN
							SET @lFarol = 2--1
						END	
				END
			ELSE
				BEGIN
					IF @lFarol < 1 
						SET @lFarol = 1--6
				END

            IF @lDatObt IS NOT NULL
                SET @lLicencaObtida = 1
            ELSE 
                SET @lLicencaObtida = 0
            
            FETCH CursorLicencas INTO @lIdeTipLicAmb, @lSigTipLicAmb, @lDesTipLicAmb, @lPrzAleVen, @lIdeLicAmb, @lDatPrt, @lDatPre, @lDatObt, @lDatVal, @lVenFob, @lQtdDiaVen, @lTipLic, @lDat, @lSttLicAmb, @lIdeLicAmbRel, @lDatPrtRel, @lDatLimRen
        END
        
		SET @lFarolAux = CASE @lFarol
						 WHEN 1 THEN 6 /* Conclu�da */
						 WHEN 2 THEN 1 /* Concedida */
						 WHEN 3 THEN 3 /* N�o Formalizada */
						 WHEN 4 THEN 7 /* Em renova��o */
						 WHEN 5 THEN 2 /* Formalizada */
						 WHEN 6 THEN 4 /* Pr�xima do prazo */
						 WHEN 7 THEN 5 /* Atrasada ou Vencida */
						 ELSE 0
						 END;
		

        IF @lIdeTipLicAmb IS NOT NULL AND @pTip IS NOT NULL
        BEGIN
            IF @lTipLic = 6 AND @lDatObt IS NOT NULL
                SET @FarolLicencas = @lTmpSigTipLicAmb + '�' + CAST(@lFarolAux as NVARCHAR) + '�' + CAST(@lLicencaObtida as NVARCHAR) + '�' + CAST(@lTmpDesTipLicAmb as NVARCHAR) + '�' + CAST(@lTmpIdeTipLicAmb as NVARCHAR)
            ELSE
            BEGIN
                SET @FarolLicencas = @FarolLicencas + '#' + @lTmpSigTipLicAmb + '�' + CAST(@lFarolAux as NVARCHAR) + '�' + CAST(@lLicencaObtida as NVARCHAR) + '�' + CAST(@lTmpDesTipLicAmb as NVARCHAR) + '�' + CAST(@lTmpIdeTipLicAmb as NVARCHAR)
                SET @FarolLicencas = SUBSTRING(@FarolLicencas, 2, LEN(@FarolLicencas) - 1)
            END
        END
        
        CLOSE CursorLicencas
        DEALLOCATE CursorLicencas
        
    RETURN @FarolLicencas
END
GO



IF  EXISTS (SELECT * FROM sysobjects WHERE ID = OBJECT_ID(N'[dbo].[RetornarFarolPrazos]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarFarolPrazos]
GO


/****** Object:  UserDefinedFunction [dbo].[RetornarFarolPrazos]    Script Date: 10/11/2012 09:19:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE  FUNCTION [dbo].[RetornarFarolPrazos](@pIdeSolPrb    DECIMAL, @pGetDate DATETIME)
RETURNS INT
AS
BEGIN
    DECLARE @lQuantidadeMarcos                  INT
    DECLARE @lQuantidadeMarcosNaoConcluidosAteHoje          INT
    DECLARE @lStatusUltimoMarcoAteHoje              INT
    
  SELECT @lQuantidadeMarcos = COUNT(IdePacTar)
            FROM tSolPrb
      INNER JOIN tSolPrbPas on tSolPrbPas.IdeSolPrb = tSolPrb.IdeSolPrb
      INNER JOIN tFer on tFer.IdeSolPrbPas = tSolPrbPas.IdeSolPrbPas
      INNER JOIN tPacTar on tPacTar.IdePlaAco = tFer.IdePlaAco
           WHERE tSolPrb.IdeSolPrb = @pIdeSolPrb
             AND tPacTar.AcaMst <> 0
             AND tPacTar.Del = 0    

    IF (@lQuantidadeMarcos <= 0)
    BEGIN
        /* Farol do prazo indefinido, pois n�o existem marcos para o projeto */
        RETURN Null
    END
    
  SELECT @lQuantidadeMarcosNaoConcluidosAteHoje = COUNT(IdePacTar)
            FROM tSolPrb
      INNER JOIN tSolPrbPas on tSolPrbPas.IdeSolPrb = tSolPrb.IdeSolPrb
      INNER JOIN tFer on tFer.IdeSolPrbPas = tSolPrbPas.IdeSolPrbPas
      INNER JOIN tPacTar on tPacTar.IdePlaAco = tFer.IdePlaAco
           WHERE tSolPrb.IdeSolPrb = @pIdeSolPrb
             AND dbo.DefinirStatusAcao(Tpactar.IdePacTar, @pGetDate) <> 4
             AND dbo.DefinirStatusAcao(Tpactar.IdePacTar, @pGetDate) <> 5
             AND tPacTar.FimPre < @pGetDate
             AND tPacTar.AcaMst <> 0
             AND tPacTar.Del = 0

   SET @lStatusUltimoMarcoAteHoje =  (SELECT TOP 1 dbo.DefinirStatusAcao(tPacTar.IdePacTar, @pGetDate)
                                            FROM tSolPrb
                                      INNER JOIN tSolPrbPas on tSolPrbPas.IdeSolPrb = tSolPrb.IdeSolPrb
                                      INNER JOIN tFer on tFer.IdeSolPrbPas = tSolPrbPas.IdeSolPrbPas
                                      INNER JOIN tPacTar on tPacTar.IdePlaAco = tFer.IdePlaAco
                                           WHERE tSolPrb.IdeSolPrb = @pIdeSolPrb
                                             AND tPacTar.FimPre < @pGetDate
                                             AND tPacTar.AcaMst <> 0
                                             AND tPacTar.Del = 0
                                        ORDER BY FimPre DESC)
                
    /*
    @lStatusUltimoMarcoAteHoje nulo indica que existem marcos por�m a data corrente � menor que a data do milestone
    @lStatusUltimoMarcoAteHoje = 4 indica que o �ltimo marco foi concluido no prazo previsto
    @lStatusUltimoMarcoAteHoje = 5 indica que o �ltimo marco foi concluido com atraso
    */                                      
    IF (@lQuantidadeMarcosNaoConcluidosAteHoje = 0 AND (@lStatusUltimoMarcoAteHoje = 4 Or @lStatusUltimoMarcoAteHoje = 5 Or @lStatusUltimoMarcoAteHoje is null))
    BEGIN
        IF @lStatusUltimoMarcoAteHoje = 5 
            /* Farol do prazo � amarelo */
            RETURN 1
        ELSE
            /* Farol do prazo � verde */
            RETURN 2
    END
    
    /* Farol do prazo � vermelho */
    RETURN 0    
END

GO




IF EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarFarolRiscos]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarFarolRiscos]
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER ON
GO

/* Fun��o       : [RetornarFarolRiscos]         
    Prop�sito   : Retorna o Risco do Projeto EPM
    Par�metros  : pIdeSolPrb - Identificador da Solu��o de Problemas
    Retorno     : 0 - Vermelho, 1 - Amarelo, 2 - Verde
    Cria��o     : 26/07/2012 - Rogger           
    �ltima Alt. : 20/08/2012 - Rogger */            

CREATE FUNCTION [dbo].[RetornarFarolRiscos](@pIdeSolPrb DECIMAL(13))
RETURNS INT
AS          
BEGIN           
    DECLARE @lQuantidadeRiscos              INT
    DECLARE @lQuantidadeRiscosTotal     INT

    SELECT @lQuantidadeRiscosTotal = COUNT(IDEFERRISITE) --Se n�o tem riscos cadastrados o farol deve ficar amarelo.
            FROM TFERRISITE
      INNER JOIN TFER ON TFERRISITE.IDEFER = TFER.IDEFER
      INNER JOIN TSOLPRBPAS ON TSOLPRBPAS.IDESOLPRBPAS = TFER.IDESOLPRBPAS
           WHERE TSOLPRBPAS.IDESOLPRB = @pIdeSolPrb

    IF (@lQuantidadeRiscosTotal = 0)
    BEGIN
        RETURN 1
    END
    
    SELECT @lQuantidadeRiscos = COUNT(IDEFERRISITE) --Se o risco ocorreu o farol deve estar vermelho.
            FROM TFERRISITE
      INNER JOIN TFER ON TFERRISITE.IDEFER = TFER.IDEFER
      INNER JOIN TSOLPRBPAS ON TSOLPRBPAS.IDESOLPRBPAS = TFER.IDESOLPRBPAS
           WHERE TSOLPRBPAS.IDESOLPRB = @pIdeSolPrb
             AND (TFERRISITE.RISOCO <> 0 OR TFERRISITE.CONMED IS NULL)

    IF (@lQuantidadeRiscos > 0)
    BEGIN
        RETURN 0
    END
    
    RETURN 2                
END
GO


IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarHorasAteAgora]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarHorasAteAgora]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* FUNCAO      : [RetornarHorasAteAgora]         
   PROPOSITO   : RETORNA A QUANTIDADE DE HORAS EXECUTADAS AT� O MOMENTO
   PARAMETROS  : pInicioPrevisto: Inicio Previsto da tarefa
                 pFimPrevisto:  Fim PRevisto da tarefa
                 pDurHra:       Dura��o em horas da tarefa
				 pFreRec:		Periodicidade da tarefa
                 pData:			DATA DE CORTE DA AN�LISE, OU SEJA, ANALISAR A��ES AT� A DATA X                 
   Criacao      : 22/10/2015 - Daniel
   �ltima Alt.  : 
*/

CREATE FUNCTION [dbo].[RetornarHorasAteAgora]
(   
    @pInicioPrevisto          DATETIME,
    @pFimPrevisto             DATETIME,    
    @pDurHra                  INT,
    @pFreRec                  DECIMAL(2),
	@pData                    DATE
)
RETURNS FLOAT
AS
BEGIN

	RETURN CASE WHEN @pFreRec  = 0 
                THEN 
                    CASE WHEN @pInicioPrevisto < @pData THEN CASE WHEN @pFimPrevisto < @pData THEN ABS((DATEDIFF(day, @pInicioPrevisto, @pFimPrevisto) +1) * 8) ELSE ABS(DATEDIFF(day, @pInicioPrevisto, @pData) * 8) END ELSE 0 END
                ELSE 
                    round(
							  
					CASE WHEN @pFreRec  = 1 THEN
								
					CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1)) < DATEADD(DD, DATEDIFF(DD, 0, @pData), 0) THEN 
							CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1)) = @pInicioPrevisto THEN 1 ELSE @pDurHra / 8 END
					ELSE 
                        CONVERT(FLOAT, (((DATEADD(DD, DATEDIFF(DD, 0, @pData), 0) - 1) - @pInicioPrevisto)) + 1)
					END

                    WHEN @pFreRec  = 2 THEN
                                
								
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 7) < DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) THEN 
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 7) = @pInicioPrevisto THEN 1 ELSE @pDurHra / 8 END
						ELSE 
                        ( CONVERT(FLOAT,((DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) - 1) - @pInicioPrevisto))  / 7) + 1								 
					END

                    WHEN @pFreRec  = 3 THEN                                
								
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 15) < DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) THEN 
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 15) = @pInicioPrevisto THEN 1 ELSE @pDurHra / 8 END
						ELSE 
                        ( CONVERT(FLOAT,((DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) - 1) - @pInicioPrevisto))  / 15) + 1								 
					END

                    WHEN @pFreRec  = 4 THEN                                
								
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 30) < DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) THEN 
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 30) = @pInicioPrevisto THEN 1 ELSE @pDurHra / 8 END
						ELSE 
                        ( CONVERT(FLOAT,((DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) - 1) - @pInicioPrevisto))  / 30) + 1								 
					END

                    WHEN @pFreRec  = 5 THEN                                
								
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 60) < DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) THEN 
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 60) = @pInicioPrevisto THEN 1 ELSE @pDurHra / 8 END
						ELSE 
                        ( CONVERT(FLOAT,((DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) - 1) - @pInicioPrevisto))  / 60) + 1								 
					END

                    WHEN @pFreRec  = 6 THEN                                
								
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 90) < DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) THEN 
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 90) = @pInicioPrevisto THEN 1 ELSE @pDurHra / 8 END
						ELSE 
                        ( CONVERT(FLOAT,((DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) - 1) - @pInicioPrevisto))  / 90) + 1								 
					END

                    WHEN @pFreRec  = 7 THEN                                
								
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 120) < DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) THEN 
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 120) = @pInicioPrevisto THEN 1 ELSE @pDurHra / 8 END
						ELSE 
                        ( CONVERT(FLOAT,((DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) - 1) - @pInicioPrevisto))  / 120) + 1								 
					END

                    WHEN @pFreRec  = 8 THEN                                
								
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 180) < DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) THEN 
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 180) = @pInicioPrevisto THEN 1 ELSE @pDurHra / 8 END
						ELSE 
                        ( CONVERT(FLOAT,((DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) - 1) - @pInicioPrevisto))  / 180) + 1								 
					END
                               
					WHEN @pFreRec  = 9 THEN                                
								
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 365) < DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) THEN 
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 365) = @pInicioPrevisto THEN 1 ELSE @pDurHra / 8 END
						ELSE 
                        ( CONVERT(FLOAT,((DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) - 1) - @pInicioPrevisto))  / 365) + 1								 
					END

                    WHEN @pFreRec  = 10 THEN                                
								
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 730) < DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) THEN 
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 730) = @pInicioPrevisto THEN 1 ELSE @pDurHra / 8 END
						ELSE 
                        ( CONVERT(FLOAT,((DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) - 1) - @pInicioPrevisto))  / 730) + 1								 
					END

                    WHEN @pFreRec  = 11 THEN                                
								
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 1095) < DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) THEN 
						CASE WHEN @pInicioPrevisto + (((@pDurHra / 8) - 1) * 1095) = @pInicioPrevisto THEN 1 ELSE @pDurHra / 8 END
						ELSE 
                        ( CONVERT(FLOAT,((DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) - 1) - @pInicioPrevisto))  / 1095) + 1								 
					END

                    ELSE 0 END, 0							   
							   
					)  * 8 END       
END  
GO


IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarLicencaAtual]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarLicencaAtual]
GO

/****** Object:  UserDefinedFunction [dbo].[RetornarLicencaAtual]    Script Date: 23/11/2009 11:54:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Função     : RetornarLicencaAtual
   Propósito  : Retorna a licença atual de um Empreendimento a partir de um tipo passado como paâmetro ou de todos os tipos
   Parâmetros : pIdeEprLicAmb - Ide de um Empreendimento 
                pTip            - Tip da Licenca tTipLicAmb.Tip
                pTipLic     - Tip da Licenca Ambiental tTipLicAmb.TipLic
                pAtv            - Somente Licenças com Status Diferente 3(Indeferida) e 4 (Vencida)
                pLic            - 'LI'/'LO' Retorna a ultima licenca de Revalidação ou Correção de uma destas licenças
                pIdeLicAmb  - Identificador da Licença atual
   Criação    : 14/06/2010 - Flávio
   Última Alt.: */  
   
CREATE FUNCTION [dbo].[RetornarLicencaAtual]( @pIdeEprLicAmb DECIMAL(13),
                                                @pTip DECIMAL(13),
                                                @pTipLic DECIMAL(13),
                                                @pAtv DECIMAL(13),
                                                @pLic NVARCHAR(3),
                                                @pIdeLicAmb DECIMAL(13),
												@pLicAsvOutOutras INT = 0)
RETURNS DECIMAL(13)
AS
BEGIN
    /* Declare the return variable here */
    DECLARE @lretn DECIMAL(13)
    
    IF @pIdeEprLicAmb IS NULL   
        SET @lretn = NULL
    ELSE
     IF @pLic IS NULL 
        IF @pTip IS NOT NULL  /* Se foi passado o Tip Outorga/ASV/etc... */
            SET @lretn = (SELECT VLIC.IDELICAMB
                            FROM((SELECT TOP 1 IDELICAMB, CASE WHEN DATOBT IS NOT NULL THEN DATOBT ELSE DATPRE END DAT
                                FROM TLICAMB
                          INNER JOIN TTIPLICAMB ON TLICAMB.IDETIPLICAMB = TTIPLICAMB.IDETIPLICAMB
                               WHERE IDEEPRLICAMB = @pIdeEprLicAmb                 
                                 AND TTIPLICAMB.TIP = @pTip
								 AND (@pLicAsvOutOutras = 0 OR TLICAMB.IDELICAMB = dbo.RetornarLicencaAtual(@pIdeEprLicAmb, NULL, NULL, @pAtv, NULL, NULL, @pLicAsvOutOutras))
                                 AND (@pAtv = 0 OR (TLICAMB.STT <> 6 AND TLICAMB.STT <> 4 AND TLICAMB.STT <> 5))
							ORDER BY DAT DESC, TLICAMB.VENFOB + TLICAMB.QTDDIAVEN DESC)) VLIC)
        ELSE IF @pTipLic IS NOT NULL /* Se Ã© a Ãºltima licenÃ§a ambiental */
            SET @lretn = (SELECT VLIC.IDELICAMB
                            FROM((SELECT TOP 1 IDELICAMB, CASE WHEN DATOBT IS NOT NULL THEN DATOBT ELSE DATPRE END DAT
                                FROM TLICAMB
                          INNER JOIN TTIPLICAMB ON TLICAMB.IDETIPLICAMB = TTIPLICAMB.IDETIPLICAMB
                               WHERE IDEEPRLICAMB = @pIdeEprLicAmb                 
                                 AND TTIPLICAMB.TIPLIC = @pTipLic
                                 AND (@pAtv = 0 OR (TLICAMB.STT <> 6 AND TLICAMB.STT <> 4 AND TLICAMB.STT <> 5))
                            ORDER BY DAT DESC, TLICAMB.VENFOB + TLICAMB.QTDDIAVEN DESC)) VLIC)
        ELSE /* Se Ã© a Ãºltima licenÃ§a do Empreendimento */
            SET @lretn = (SELECT VLIC.IDELICAMB
                            FROM((SELECT TOP 1 IDELICAMB, CASE WHEN DATOBT IS NOT NULL THEN DATOBT ELSE DATPRE END DAT
                                FROM TLICAMB
                          INNER JOIN TTIPLICAMB ON TLICAMB.IDETIPLICAMB = TTIPLICAMB.IDETIPLICAMB
                               WHERE IDEEPRLICAMB = @pIdeEprLicAmb                 
                                 AND  (@pLicAsvOutOutras <> 0 OR (@pLicAsvOutOutras = 0 AND TTIPLICAMB.TIPLIC IS NOT NULL AND TTIPLICAMB.TIPLIC <> 0))
                                 AND (@pAtv = 0 OR (TLICAMB.STT <> 6 AND TLICAMB.STT <> 4 AND TLICAMB.STT <> 5))
                            ORDER BY DAT DESC, TLICAMB.VENFOB + TLICAMB.QTDDIAVEN DESC)) VLIC)
     ELSE IF UPPER(@pLic) = 'LI'
        SET @lretn = (SELECT VLIC.IDELICAMB
                            FROM((SELECT TOP 1 IDELICAMB, CASE WHEN DATOBT IS NOT NULL THEN DATOBT ELSE DATPRE END DAT
                                FROM TLICAMB
                          INNER JOIN TTIPLICAMB ON TLICAMB.IDETIPLICAMB = TTIPLICAMB.IDETIPLICAMB
                               WHERE IDEEPRLICAMB = @pIdeEprLicAmb                 
                                 AND (TTIPLICAMB.TIPLIC = 2 OR TTIPLICAMB.TIPLIC = 3 OR TTIPLICAMB.TIPLIC = 7) /* LI / RLI */
                                 AND (@pAtv = 0 OR (TLICAMB.STT <> 6 AND TLICAMB.STT <> 4 AND TLICAMB.STT <> 5))
                                 AND (@pIdeLicAmb IS NULL OR (TLICAMB.IDELICAMB <> @pIdeLicAmb))
                            ORDER BY DAT DESC, TLICAMB.VENFOB + TLICAMB.QTDDIAVEN DESC)) VLIC)
     ELSE IF UPPER(@pLic) = 'LO'
        SET @lretn = (SELECT VLIC.IDELICAMB
                            FROM((SELECT TOP 1 IDELICAMB, CASE WHEN DATOBT IS NOT NULL THEN DATOBT ELSE DATPRE END DAT
                                FROM TLICAMB
                          INNER JOIN TTIPLICAMB ON TLICAMB.IDETIPLICAMB = TTIPLICAMB.IDETIPLICAMB
                               WHERE IDEEPRLICAMB = @pIdeEprLicAmb                 
                                 AND (TTIPLICAMB.TIPLIC = 4 OR TTIPLICAMB.TIPLIC = 5 OR TTIPLICAMB.TIPLIC = 6) /* LO / RLO /LOC */
                                 AND (@pAtv = 0 OR (TLICAMB.STT <> 6 AND TLICAMB.STT <> 4 AND TLICAMB.STT <> 5))
                                 AND (@pIdeLicAmb IS NULL OR (TLICAMB.IDELICAMB <> @pIdeLicAmb))
                            ORDER BY DAT DESC, TLICAMB.VENFOB + TLICAMB.QTDDIAVEN DESC)) VLIC)
    /* Return the result of the function */
     RETURN @lretn
END

GO




IF  EXISTS (SELECT * FROM sysobjects WHERE ID = OBJECT_ID(N'[dbo].[RetornarOrdemTarefa]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarOrdemTarefa]
GO

/****** Object:  UserDefinedFunction [dbo].[RetornarOrdemTarefa]    Script Date: 22/11/2017 08:43:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[RetornarOrdemTarefa](@pIdePacTar DECIMAL(13))
RETURNS varchar(20)
AS          
BEGIN           
    DECLARE @lretn varchar(20),
	@lIdeSpr    DECIMAL(13)
    
	SELECT @lIdeSpr = IDEPACTARSUP, @lretn = CAST(ORD AS VARCHAR) FROM TPACTAR WHERE IDEPACTAR = @pIdePacTar

	while len(@lretn) < 3
		set @lretn  = '0' + @lretn 

	if @lIdeSpr is not null
	begin
		set @lretn = [dbo].[RetornarOrdemTarefa](@lIdeSpr) + '.' + @lretn
	end
	
    RETURN(@lretn)
END


GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarPiorFarolSubProjetos]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarPiorFarolSubProjetos]
GO

/****** Object:  UserDefinedFunction [dbo].[RetornarPiorFarolSubProjetos]    Script Date: 12/05/2015 10:17:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/* Fun��o     : RetornarPiorFarolSubProjetos
   Prop�sito  : Retorna o pio caso de Farol das Licen�as dos subprojetos de determinado Empreendimento da Empresa
   Par�metros : pIdeEprLicAmb   - Identificador do Empreendimento
   Cria��o    : 07/05/2015 - Eduardo C�sar
   �ltima Alt.:  */

CREATE
FUNCTION [dbo].[RetornarPiorFarolSubProjetos](@pIdeEprLicAmb DECIMAL(13))
RETURNS INT AS

BEGIN
	DECLARE @lFarol INT
	
    SELECT @lFarol = CASE WHEN MAX(VLIC.FAROL) IS NULL THEN 0 ELSE MAX(VLIC.FAROL) END
    FROM (SELECT CASE WHEN LIC.DATVAL < GETDATE() OR (LIC.DATPRE IS NOT NULL AND LIC.DATPRE < GETDATE() AND LIC.DATOBT IS NULL) THEN 5
            WHEN (LIC.DATVAL - TTIPLICAMB.PRZALEVEN < GETDATE()) OR (LIC.DATPRE < GETDATE() + TTIPLICAMB.PRZALEVEN AND LIC.DATOBT IS NULL) THEN 4
            ELSE 0 END FAROL
        FROM TLICAMB LIC 
        INNER JOIN TTIPLICAMB ON LIC.IDETIPLICAMB = TTIPLICAMB.IDETIPLICAMB
        INNER JOIN dbo.DefinirArvoreProjetosSubordinados(@pIdeEprLicAmb) EPR ON LIC.IDEEPRLICAMB = EPR.IDEEPRLICAMB
        WHERE LIC.STT <> 6
            AND EPR.IDEEPRLICAMB <> @pIdeEprLicAmb) VLIC
    WHERE VLIC.FAROL = 4 OR VLIC.FAROL = 5

    RETURN @lFarol
END
GO



IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarProximaDataFrequencia]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarProximaDataFrequencia]
GO

/****** Object:  UserDefinedFunction [dbo].[RetornarProximaDataFrequencia]    Script Date: 06/14/2010 16:24:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Função     : RetornarProximaDataFrequencia
   Propósito  : Retorna a proxima data domando como referência, a frequencia informada
   Parâmetros :    pData   - Data base
              : pFre    - Frequencia
   Criação    : 14/06/2010 - Eduardo César
   Última Alt.:  */

CREATE
FUNCTION [dbo].[RetornarProximaDataFrequencia](@pData DATETIME, @pFre DECIMAL)
RETURNS DATETIME AS

BEGIN
DECLARE @rtnData DATETIME

    IF @pFre = 1 /*Diario*/
        SET @rtnData = DATEADD(DAY, 1, @pData)
    ELSE IF @pFre = 2 /*Semanal*/
        SET @rtnData = DATEADD(DAY, 7, @pData)
    ELSE IF @pFre = 3 /*Quinzenal*/
        SET @rtnData = DATEADD(DAY, 15, @pData)
    ELSE IF @pFre = 4 /*Mensal*/
        SET @rtnData = DATEADD(MONTH, 1, @pData)
    ELSE IF @pFre = 5 /*Bimestral*/
        SET @rtnData = DATEADD(MONTH, 2, @pData)
    ELSE IF @pFre = 6 /*Trimestral*/
        SET @rtnData = DATEADD(MONTH, 3, @pData)
    ELSE IF @pFre = 7 /*Quadrimestral*/
        SET @rtnData = DATEADD(MONTH, 4, @pData)
    ELSE IF @pFre = 8 /*Semestral*/
        SET @rtnData = DATEADD(MONTH, 6, @pData)
    ELSE IF @pFre = 9 /*Anual*/
        SET @rtnData = DATEADD(YEAR, 1, @pData)
    ELSE IF @pFre = 10 /*Bienal*/
        SET @rtnData = DATEADD(YEAR, 2, @pData)
    ELSE IF @pFre = 11 /*Trienal*/
        SET @rtnData = DATEADD(YEAR, 3, @pData)
    
    RETURN @rtnData
END

GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarSeUsuarioPossuiRegra]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarSeUsuarioPossuiRegra]
GO

/****** Object:  UserDefinedFunction [dbo].[RetornarSeUsuarioPossuiRegra]    Script Date: 06/14/2010 16:22:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/* Função      : Retornar se o Usuário Possui determinada regra
   Propósito   : Verificar regra do usuário
   Parâmetros  : pIdeUsu - Identificador do usuário
                 pCodInt - Código da regra
   Retorno     : Retorna 1 se possui a regra e 0 se não possui
   Criação     : 20/11/2012 - FCS
   Última Alt. : */

CREATE FUNCTION [dbo].[RetornarSeUsuarioPossuiRegra]
                    (@pIdeUsu   DECIMAL(13), 
                     @pCodInt   VARCHAR(200),
                     @pValRegra INT)
RETURNS INT
AS
BEGIN
    DECLARE @lRetn          INT

    SELECT @lRetn = COUNT(Regra)
      FROM (SELECT tUsuOpeSis.IdeUsuOpeSis Regra
              FROM tUsuOpeSis
        INNER JOIN tOpeSis on tUsuOpeSis.IdeOpeSis = tOpeSis.IdeOpeSis
             WHERE tUsuOpeSis.IdeUsu = @pIdeUsu
               AND tOpeSis.CodInt = @pCodInt
               AND tUsuOpeSis.Val = @pValRegra
            UNION
            SELECT tGruUsuOpeSis.IdeGruUsuOpeSis Regra
              FROM tGruUsuOpeSis
        INNER JOIN tUsuGruUsu On tGruUsuOpeSis.IdeGruUsu = tUsuGruUsu.IdeGruUsu
        INNER JOIN tOpeSis on tGruUsuOpeSis.IdeOpeSis = tOpeSis.IdeOpeSis
             WHERE tUsuGruUsu.IdeUsu = @pIdeUsu
               AND tOpeSis.CodInt = @pCodInt
               AND tGruUsuOpeSis.Val = @pValRegra)Regras


    RETURN(@lRetn)

END

GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarSttVencimentoLicenca]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarSttVencimentoLicenca]
GO

/****** Object:  UserDefinedFunction [dbo].[RetornarSttVencimentoLicenca]    Script Date: 06/14/2010 16:22:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Fun��o      : RetornarSttVencimentoLicenca
   Prop�sito   : Retornar um status de email informando se � necess�rio enviar um email informando que a licen�a est� pr�xima do vencimento
   Par�metros  : pIdeLicAmb - Identificador da Licen�a Ambiental
   Retorno     : 0 = n�o mandar email
                 1 = mandar email
   Cria��o     : 04/09/2012 - Eduardo C�sar
   �ltima Alt.: 27/07/2018 - Eduardo C�sar */
CREATE  FUNCTION [dbo].[RetornarSttVencimentoLicenca](@pIdeLicAmb DECIMAL)
RETURNS INT

AS
BEGIN
    DECLARE @lTipoLicenca           INT,
            @lTipoLicencaAmbiental  INT,
            @lIdeEprLicAmb          DECIMAL(13),
            @lDataVencimento        DATETIME,
            @lDataObtencao          DATETIME,
            @lDataObtencaoProxima   DATETIME,
            @lPrazoAlerta           INT,
            @lStatusEmail           DECIMAL(1),
			@lLicencaRelacionada	DECIMAL(13),
			@lDataProtocoloRel		DATETIME,
    
            @ConstLicencaPrevia                 INT,
            @ConstLicencaImplantacao            INT,
            @ConstRevalidacaoLicencaImplantacao INT,
            @ConstLicencaOperacao               INT,
            @ConstLicencaOperacaoCorretiva      INT,
            @ConstRevalidacaoLicencaOperacao    INT,
            @ConstLicencaPreviaEImplantacao     INT

            SET @ConstLicencaPrevia                 = 1
            SET @ConstLicencaImplantacao            = 2
            SET @ConstRevalidacaoLicencaImplantacao = 3
            SET @ConstLicencaOperacao               = 4
            SET @ConstLicencaOperacaoCorretiva      = 5
            SET @ConstRevalidacaoLicencaOperacao    = 6
            SET @ConstLicencaPreviaEImplantacao     = 7
			
    
    SELECT @lIdeEprLicAmb = Lic.IdeEprLicAmb, 
           @lTipoLicenca = Tip.Tip, 
           @lTipoLicencaAmbiental = Tip.TipLic, 
           @lDataObtencao = Lic.DatObt, 
           @lDataVencimento = Lic.DatVal, 
           @lPrazoAlerta = Tip.PrzAleVen, 
           @lStatusEmail = Lic.SttEml,
		   @lLicencaRelacionada = LicRel.IdeLicAmb,
		   @lDataProtocoloRel = LicRel.DatPrt
      FROM tTipLicAmb Tip
     INNER JOIN tLicAmb Lic ON Tip.IdeTipLicAmb = Lic.IdeTipLicAmb
	  LEFT JOIN tLicAmb LicRel on Lic.IdeLicAmbRel = LicRel.IdeLicAmb
     WHERE Lic.IdeLicAmb = @pIdeLicAmb
    
    IF DATEADD(DAY, @lPrazoAlerta, @lDataVencimento ) > GETDATE() OR @lDataVencimento < GETDATE() 
        RETURN 0
    
	IF @lLicencaRelacionada IS NOT NULL AND @lDataProtocoloRel IS NOT NULL
		RETURN 0
    

    /* Verifica se N�O � uma Licen�a Ambiental do fluxo (LP / PI / LO) */
    IF @lTipoLicenca <> 1 
        
        IF @lStatusEmail <> 0 
            RETURN 0
        ELSE 
            RETURN 1
        
    ELSE
    BEGIN
    /*
        LicencaPrevia = 1,
        LicencaImplantacao = 2,
        RevalidacaoLicencaImplantacao = 3,
        LicencaOperacao = 4,
        LicencaOperacaoCorretiva = 5,
        RevalidacaoLicencaOperacao = 6,
        LicencaPreviaEImplantacao = 7
    */

        /* Tipo da Licenca Ambiental */
        IF @lTipoLicencaAmbiental = @ConstLicencaPrevia 
        BEGIN
        /* LP - Enviar email a cada 30 dias enquanto n�o houver uma licen�a do tipo LI concedida e a data de vencimento ainda for maior que hoje */
            SELECT @lDataObtencaoProxima = MIN(DatObt)
              FROM tEprLicAmb Epr
                INNER JOIN tLicAmb Lic ON Epr.IdeEprLicAmb = Lic.IdeEprLicAmb
                INNER JOIN tTipLicAmb Tip ON Tip.IdeTipLicAmb = Lic.IdeTipLicAmb
                WHERE Epr.IdeEprLicAmb = @lIdeEprLicAmb
                AND Lic.DatObt > @lDataObtencao
                AND Tip.Tip = @lTipoLicenca
                AND Tip.TipLic = @ConstLicencaImplantacao
            
            
            IF @lDataObtencaoProxima IS NULL 
                RETURN 1
            ELSE 
                RETURN 0
        END    
        ELSE IF @lTipoLicencaAmbiental = @ConstLicencaImplantacao AND @lTipoLicencaAmbiental = @ConstRevalidacaoLicencaImplantacao AND @lTipoLicencaAmbiental = @ConstLicencaPreviaEImplantacao 
        BEGIN
        /* LI - RevLI - LP+LI - Enviar email a cada 30 dias enquanto n�o houver uma licen�a do tipo RevLI ou LO concedida (com data de obten��o maior que a da licen�a em quest�o) e a data de vencimento ainda for maior que hoje */
            SELECT @lDataObtencaoProxima = MIN(DatObt)
              FROM tEprLicAmb Epr
             INNER JOIN tLicAmb Lic ON Epr.IdeEprLicAmb = Lic.IdeEprLicAmb
             INNER JOIN tTipLicAmb Tip ON Tip.IdeTipLicAmb = Lic.IdeTipLicAmb
             WHERE Epr.IdeEprLicAmb = @lIdeEprLicAmb
               AND Lic.DatObt > @lDataObtencao
               AND Tip.Tip = @lTipoLicenca
               AND (Tip.TipLic = @ConstRevalidacaoLicencaImplantacao OR Tip.TipLic = @ConstLicencaOperacao)
            
            IF @lDataObtencaoProxima IS NULL 
                RETURN 1
            ELSE 
                RETURN 0
           
        END
        ELSE IF @lTipoLicencaAmbiental = @ConstLicencaOperacao AND @lTipoLicencaAmbiental = @ConstLicencaOperacaoCorretiva AND @lTipoLicencaAmbiental = @ConstRevalidacaoLicencaOperacao 
        BEGIN
        /* LO - LOC - RevLO - Enviar email a cada 30 dias enquanto n�o houver uma licen�a do tipo RevLO concedida (com data de obten��o maior que a da licen�a em quest�o) e a data de vencimento for maior que hoje */
            SELECT @lDataObtencaoProxima = MIN(DatObt)
              FROM tEprLicAmb Epr
             INNER JOIN tLicAmb Lic ON Epr.IdeEprLicAmb = Lic.IdeEprLicAmb
             INNER JOIN tTipLicAmb Tip ON Tip.IdeTipLicAmb = Lic.IdeTipLicAmb
             WHERE Epr.IdeEprLicAmb = @lIdeEprLicAmb
               AND Lic.DatObt > @lDataObtencao
               AND Tip.Tip = @lTipoLicenca
               AND Tip.TipLic = @ConstRevalidacaoLicencaOperacao
            
            IF @lDataObtencaoProxima IS NULL
                RETURN 1
            ELSE 
                RETURN 0
            
        END
    END

    RETURN 0

END
GO



IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarTags]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarTags]
GO

/****** Object:  UserDefinedFunction [dbo].[RetornarTags]    Script Date: 23/11/2009 11:54:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Fun��o    : RetornarTags
  Prop�sito  : Retorna as Tags de determindado objeto por usu�rio e empresa
  Par�metros : pIdeObj        - Identificador do Objeto
              : pTypObj    - Tipo do Objeto
              : pIdeEmp    - Identificador da Empresa
              : pIdeUsu    - Identificador do Usuario
              : pQtdDeTags  - Quantidade de Tags a ser retornada
  Cria��o    : 24/01/2014  - Flavio Silva
  �ltima Alt.:  */
 
CREATE FUNCTION [dbo].RetornarTags(@pIdeObj DECIMAL, @pTypObj VARCHAR(200), @pIdeEmp DECIMAL, @pIdeUsu DECIMAL)
RETURNS NVARCHAR(4000)
AS
BEGIN
    DECLARE 
        @lTags      NVARCHAR(4000),        
        @lQtd      INT,
        @lNmeTag    NVARCHAR(80)
                
        SET @lTags = ''
        SET @lNmeTag = ''
        
        DECLARE CursorTags CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
            SELECT TTAG.NME
              FROM TTAG
        INNER JOIN TTAGREL ON TTAG.IDETAG = TTAGREL.IDETAG
             WHERE TTAGREL.IDEOBJ = @pIdeObj
              AND TTAGREL.TYPOBJ = @pTypObj
              AND TTAG.IDEEMP = @pIdeEmp
              AND TTAG.IDEUSU = @pIdeUsu              
          ORDER BY TTAG.NME ASC

        OPEN CursorTags
        FETCH CursorTags INTO @lNmeTag        
        
        WHILE @@FETCH_STATUS = 0
        BEGIN            
            SET @lTags = @lTags + '#�#'  + @lNmeTag        
            FETCH CursorTags INTO @lNmeTag
        END
        CLOSE CursorTags
        DEALLOCATE CursorTags
        
    RETURN @lTags
END
GO



IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarUnidadesPorUsuario]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarUnidadesPorUsuario]
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO


/* Fun��o      : RetornarUnidadesPorUsuario
   Prop�sito   : Retorna as Unidades Gerenciais do Usu�rio
   Par�metros  : pIdeUsu - Identificador do Usu�rio
   Retorno     : Retorna o IdeUni, Sig, UniVir e UpdDta das Unidades do Usu�rio
   Cria��o     : 31/10/2012 - Lux 
   �ltima Alt. : 15/04/2016 - Leonardo Lage
*/

CREATE FUNCTION [dbo].[RetornarUnidadesPorUsuario](@pIdeUsu DECIMAL(13))
RETURNS @retnTable TABLE (IdeUni DECIMAL(13), Sig NVARCHAR(50), UniVir DECIMAL(1), UpdDta DECIMAL(1), ORD INT)
AS
BEGIN
    
    INSERT INTO @retnTable (IdeUni, Sig, UniVir, UpdDta, ORD) 

        SELECT vUni.IDEUNI, 
               vUni.SIG, 
               vUni.UNIVIR, 
               MAX(ABS(vUni.UpdDta)) UPDDTA,
               ROW_NUMBER() OVER (ORDER BY SIG ASC) AS ORD
         FROM (SELECT tUni.IdeUni, 
                      tUni.Sig, 
                      tUni.UniVir, 
                      vUsuUni.UpdDta
                 FROM tUni INNER JOIN tUniTyp ON tUni.IdeUniTyp = tUniTyp.IdeUniTyp 
                           INNER JOIN (SELECT tUsuUni.IdeUni, 
                                              tUsuUni.UpdDta 
                                         FROM tUsuUni 
                                        WHERE tUsuUni.IdeUsu = @pIdeUsu 
                                        UNION  
                                       SELECT tGruUsuUni.IdeUni, 
                                              tGruUsuUni.UpdDta 
                                         FROM tGruUsuUni INNER JOIN tGruUsu ON tGruUsuUni.IdeGruUsu = tGruUsu.IdeGruUsu 
                                                         INNER JOIN tUsuGruUsu ON tGruUsu.IdeGruUsu = tUsuGruUsu.IdeGruUsu 
                                        WHERE tUsuGruUsu.IdeUsu = @pIdeUsu 
                                     ) vUsuUni ON tUni.IdeUni = vUsuUni.IdeUni 
                WHERE tUniTyp.Typ = 1 
				  ) vUni
         GROUP BY vUni.Sig, 
                  vUni.IdeUni,
                  vUni.UniVir
         ORDER BY vUni.Sig

    RETURN
END
GO




IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[RetornarVerificaoRevLA]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RetornarVerificaoRevLA]
GO

 /****** Object:  UserDefinedFunction [dbo].[RetornarVerificaoRevLA]    Script Date: 06/30/2010 08:37:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* Função     : RetornarVerificaoRevLA
   Propósito  : 
   Parâmetros : pTipInfo - Tipo da Informação
                pIdeEprLicAmb - Ide de um Empreendimento                 
   Criação    : 14/06/2010 - FCS
   Última Alt.: */
   
CREATE FUNCTION [dbo].[RetornarVerificaoRevLA]( @pTipInfo DECIMAL(13), @pIdeEprLicAmb DECIMAL(13))

RETURNS INTEGER
AS
BEGIN
    /* Declare the return variable here */
    DECLARE @lrtn               INTEGER,
            @lIdeLicRevAtual    DECIMAL(13),
            @lIdeLicAnt         DECIMAL(13),
            @lTipLic            DECIMAL(13),
            @lVenFob            DATETIME,
            @lDatObt            DATETIME,
            @lDatVal            DATETIME
    
    SET @lTipLic = 3
    
    IF @pTipInfo IS NULL OR @pIdeEprLicAmb IS NULL
        RETURN NULL
    ELSE
        IF @pTipInfo > 2
            SET @lTipLic = 6
            
        SET @lIdeLicRevAtual = (SELECT [DBO].[RETORNARLICENCAATUAL](@pIdeEprLicAmb,NULL,@lTipLic,1,NULL,NULL,0))

        IF @lIdeLicRevAtual IS NULL
            RETURN NULL 

        SELECT @lVenFob = VENFOB, @lDatObt = DATOBT
          FROM TLICAMB
         WHERE IDELICAMB = @lIdeLicRevAtual 
        
        IF @pTipInfo = 1 /* REQUERIMENTO FEITO COM DEVIDA ANTECEDENCIA */
        BEGIN
            SELECT @lDatVal = DATVAL
              FROM TLICAMB
             WHERE IDELICAMB = (SELECT [DBO].[RETORNARLICENCAATUAL](@pIdeEprLicAmb,NULL,NULL,1,'LI',@lIdeLicRevAtual,0))
             
            IF @lDatVal > @lVenFob
                SET @lrtn = 1
            ELSE
                SET @lrtn = 0
            
        END
        ELSE IF @pTipInfo = 2 /* LI RENOVADA DENTRO DO SEU PRAZO DE VALIDADE */
        BEGIN
            SELECT @lDatVal = DATVAL
              FROM TLICAMB
             WHERE IDELICAMB = (SELECT [DBO].[RETORNARLICENCAATUAL](@pIdeEprLicAmb,NULL,NULL,1,'LI',@lIdeLicRevAtual,0))
            
            IF @lDatVal > @lDatObt
                SET @lrtn = 1
            ELSE
                SET @lrtn = 0
                
        END
        ELSE IF @pTipInfo = 3 /* REQUERIMENTO FEITO DENTRO DO PRAZO LEGAL E/OU PREVISTO */
        BEGIN
            SELECT @lDatVal = DATVAL
              FROM TLICAMB
             WHERE IDELICAMB = (SELECT [DBO].[RETORNARLICENCAATUAL](@pIdeEprLicAmb,NULL,NULL,1,'LO',@lIdeLicRevAtual,0))
             
            IF @lDatVal > @lVenFob
                SET @lrtn = 1
            ELSE
                SET @lrtn = 0
                
        END
        ELSE IF @pTipInfo = 4 /* LO RENOVADA DENTRO DO SEU PRAZO DE VALIDADE */
        BEGIN
            
            SELECT @lDatVal = DATVAL
              FROM TLICAMB
             WHERE IDELICAMB = (SELECT [DBO].[RETORNARLICENCAATUAL](@pIdeEprLicAmb,NULL,NULL,1,'LO',@lIdeLicRevAtual,0))
            
            IF @lDatVal > @lDatObt
                SET @lrtn = 1
            ELSE
                SET @lrtn = 0
                
        END
        
    /* Return the result of the function */
    RETURN @lrtn

END

GO




/****** Object:  UserDefinedFunction [dbo].[fnSplit]    Script Date: 10/21/2008 16:09:27 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[To_Binary]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[To_Binary]
GO
/****** Object:  UserDefinedFunction [dbo].[fnSplit]    Script Date: 10/21/2008 16:09:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[To_Binary](
    @bitLength INT -- Tamanho m�ximo da string de retorno
  , @IntValue INT --N�mero a ser convertido
) RETURNS VARCHAR(1000)

BEGIN

DECLARE @vsResult VARCHAR(1000)
DECLARE @inti INT
select @inti = @bitLength, @vsResult = ''
WHILE @inti > 0
  BEGIN
    SELECT @vsResult = CONVERT(CHAR(1), @IntValue % 2) + @vsResult
    SELECT @IntValue = CONVERT(INT, (@IntValue / 2)), @inti = @inti - 1
  END
RETURN @vsResult
END
GO




/****** Object:  UserDefinedFunction [dbo].[To_ScientificNumber]    Script Date: 03/09/2009 09:50:02 ******/
IF  EXISTS (SELECT * FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[To_ScientificNumber]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[To_ScientificNumber]
GO

/****** Object:  UserDefinedFunction [dbo].[To_ScientificNumber]    Script Date: 03/09/2009 09:50:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[To_ScientificNumber](@pValue FLOAT) 
RETURNS FLOAT AS
BEGIN
    DECLARE @lCharFormat varchar(100),
            @lBeforeValue varchar(100),
            @lAfterValue varchar(100)

    SET @lCharFormat = UPPER(LTRIM(RTRIM(CONVERT(VarChar(50), convert(float, @pValue), 2))));

    SET @lBeforeValue = CONVERT(VARCHAR, CONVERT(DECIMAL(10,2), SUBSTRING(@lCharFormat, 1, CHARINDEX('E', @lCharFormat) - 1)));
    SET @lAfterValue = SUBSTRING(@lCharFormat, CHARINDEX('E', @lCharFormat), LEN(@lCharFormat) - LEN(@lBeforeValue));

RETURN CONVERT(FLOAT, @lBeforeValue + @lAfterValue);

END
GO




/*==============================================================*/
/* ATUALIZA��O DA VERS�O DO BANCO DE DADOS                      */
/*==============================================================*/

DECLARE @LVERSION DATETIME,
		@VERSAO   NVARCHAR(10)
SET @LVERSION = CAST('20180801' AS DATETIME)
SET @VERSAO = '1808.1'
IF EXISTS(SELECT VRS FROM TVRS WHERE VRS = @LVERSION AND NUMVRS = @VERSAO)
   UPDATE TVRS SET DTAFNC = GETDATE() WHERE VRS = @LVERSION AND NUMVRS = @VERSAO;
ELSE
    INSERT INTO TVRS (VRS, DTAFNC , NUMVRS) VALUES (@LVERSION, GETDATE() , @VERSAO);
GO


BEGIN
PRINT '1808.1'
END
GO

