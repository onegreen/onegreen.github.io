

/*********************************************************/
/*********************** CASO 186 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 186'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170130-186')
BEGIN

	ALTER TABLE TLICAMB ADD CSTMAN DECIMAL(1) NOT NULL DEFAULT 0
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170130-186', GETDATE())
	
END
GO



/*********************************************************/
/*********************** CASO 202 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 202'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170320-202')
BEGIN

	exec sp_ModifyColumn 'TDOCLICAMB', 'DES', 'NVARCHAR(250)', 0, 'NULL'
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170320-202', GETDATE())
	
END
GO



PRINT ('CASO 205')
GO
/* CRIANDO TABELA DE ITENS DO PLANO DA EMPRESA */
/*********************************************************/
/**********************   CASO 205  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170404-205')
BEGIN
	
/*==============================================================*/
  
	/*==============================================================*/
	/* TABLE: TATVEPRLICAMB                                         */
	/*==============================================================*/
	CREATE TABLE TPLNCONITEEMP  (
	   IDEPLNCONEMP         DECIMAL(13)                      NOT NULL,
	   CHV                  NVARCHAR(50)                     NOT NULL,
	   VLR                  NVARCHAR(50)                     NOT NULL
	)

	/*==============================================================*/
	/* INDEX: TPLNCONEMP2TPLNCONITEEMP_FK                        */
	/*==============================================================*/
	CREATE INDEX TPLNCONEMP2TPLNCONITEEMP_FK ON TPLNCONITEEMP (
	   IDEPLNCONEMP ASC
	)

	ALTER TABLE TPLNCONITEEMP
	   ADD CONSTRAINT TPLNCONEMP2TPLNCONITEEMP_FK FOREIGN KEY (IDEPLNCONEMP)
		  REFERENCES TPLNCONEMP (IDEPLNCONEMP)
		  ON DELETE CASCADE
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170404-205', GETDATE())
END
GO



PRINT ('CASO 220')
GO

/* Adicionando coluna para possibilitar remoÃ§Ã£o de atividades dos Relatorios e Graficos */
/*********************************************************/
/**********************   CASO 220  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170508-220')
BEGIN
	
/*==============================================================*/
  
		/*==============================================================*/
		/* TABLE: TPACTAR                                         		*/
		/*==============================================================*/
		ALTER TABLE TPACTAR ADD REMRELGRA DECIMAL(1) NOT NULL DEFAULT 0
		
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170508-220', GETDATE())
END
GO



IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170629-253')
BEGIN

	DECLARE cPlanos CURSOR FOR  SELECT CASE WHEN ACO.IDEPLAACO = LIC.IDEPLAACONTF THEN 1 /* NotificaÃ§Ã£o / Termo */
											WHEN ACO.IDEPLAACO = LIC.IDEPLAACOCMP THEN 2 /* CompensatÃ³ria */
											WHEN ACO.IDEPLAACO = LIC.IDEPLAACOPRGAMB THEN 3 /* Programa Ambiental */
											WHEN ACO.IDEPLAACO = LIC.IDEPLAACOORIBAS THEN 4 /* OrientaÃ§Ã£o */
											ELSE NULL END VINCULO, ACO.IDEPLAACO
								FROM TPLAACO ACO
								INNER JOIN TLICAMB LIC ON ACO.IDEPLAACO = LIC.IDEPLAACOCMP OR ACO.IDEPLAACO = LIC.IDEPLAACOPRGAMB OR ACO.IDEPLAACO = LIC.IDEPLAACONTF OR ACO.IDEPLAACO = LIC.IDEPLAACOORIBAS

declare @lIdePlaAco decimal(13), 
		@Vinculo int

	OPEN cPlanos
	FETCH NEXT FROM cPlanos INTO @Vinculo, @lIdePlaAco
	WHILE @@FETCH_STATUS = 0
	BEGIN 
		
		IF @Vinculo = 1 
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.NotificacaoDaLicenca', NME = 'NotificaÃ§Ãµes / Termos de Compromisso' WHERE IDEPLAACO = @lIdePlaAco
		ELSE IF @Vinculo = 2 
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.CompensatoriaDaLicenca', NME = 'CompensatÃ³rias' WHERE IDEPLAACO = @lIdePlaAco
		ELSE IF @Vinculo = 3 
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.ProgramaAmbientalDaLicenca', NME = 'Programas Ambientais' WHERE IDEPLAACO = @lIdePlaAco
		ELSE IF @Vinculo = 4 
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.OrientacaoDaLicenca', NME = 'OrientaÃ§Ãµes' WHERE IDEPLAACO = @lIdePlaAco
		
		
		FETCH NEXT FROM cPlanos INTO @Vinculo, @lIdePlaAco
	END

	CLOSE cPlanos
	DEALLOCATE cPlanos
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170629-253', GETDATE())
END
GO



PRINT ('CASO 257')
GO

/* Adicionando coluna para descriÃ§Ã£o do prazo da tarefa */
/*********************************************************/
/**********************   CASO 257  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170804-257')
BEGIN
	
/*==============================================================*/
  
		/*==============================================================*/
		/* TABLE: TPACTAR                                         		*/
		/*==============================================================*/
		ALTER TABLE TPACTAR ADD PRZ NVARCHAR(500) NULL
		
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170804-257', GETDATE())
END
GO



PRINT ('CASO 266')
GO

/* Removendo Tipo Uso Ãgua do Sistema */
/*********************************************************/
/**********************   CASO 266  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20170922-266')
BEGIN
	
/*==============================================================*/
  
		/*==============================================================*/
		/* TABLE: TMNUSIS                                         		*/
		/*==============================================================*/
		DELETE FROM TMNUSIS WHERE NME = 'TiposDeUsoDeAgua'
		
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170922-266', GETDATE())
END
GO



print ('CASO 261')
GO
/* Criando Tabela de Documentos no HistÃ³rico */
/*********************************************************/
/*********************   CASO 261  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20171019-261')
BEGIN
	
/*==============================================================*/
	/*==============================================================*/
	/* Table: TOBSLICAMBDOCLICAMB                                   */
	/*==============================================================*/
	create table TOBSLICAMBDOCLICAMB (
	   IDEDOCLICAMB         decimal(13)          null,
	   IDEOBSLICAMB         decimal(13)          null
	)

	/*==============================================================*/
	/* Index: TOBSLICAMB2TOBSLICAMBDOCLICAMB_FK                     */
	/*==============================================================*/
	create index TOBSLICAMB2TOBSLICAMBDOCLICAMB_FK on TOBSLICAMBDOCLICAMB (
	IDEOBSLICAMB ASC
	)

	/*==============================================================*/
	/* Index: TDOCLICAMB2TOBSLICAMBDOCLICAMB_FK                     */
	/*==============================================================*/
	create index TDOCLICAMB2TOBSLICAMBDOCLICAMB_FK on TOBSLICAMBDOCLICAMB (
	IDEDOCLICAMB ASC
	)

	alter table TOBSLICAMBDOCLICAMB
	   add constraint TDOCLICAMB2TOBSLICAMBDOCLICAMB_FK foreign key (IDEDOCLICAMB)
		  references TDOCLICAMB (IDEDOCLICAMB)

	alter table TOBSLICAMBDOCLICAMB
	   add constraint TOBSLICAMB2TOBSLICAMBDOCLICAMB_FK foreign key (IDEOBSLICAMB)
		  references TOBSLICAMB (IDEOBSLICAMB)
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20171019-261', GETDATE())
END
GO



print ('CASO 269')
GO
/* Criando Tabela de Lembrete de ExecuÃ§Ã£o de Tarefas Enviados */
/*********************************************************/
/*********************   CASO 269  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20171019-269')
BEGIN
	
/*==============================================================*/
  
	/*==============================================================*/
	/* Table: TLEMEXETARENV                                         */
	/*==============================================================*/
	create table TLEMEXETARENV (
	   IDELEMEXETARENV      decimal(13)          identity(1110000000000, 1),
	   IDEPACTAR            decimal(13)          not null,
	   IDEUSUREM            decimal(13)          not null,
	   IDEUSUDES            decimal(13)          not null,
	   MSG                  nvarchar(500)        null,
	   UPDTME               datetime             not null
	)

	alter table TLEMEXETARENV
	   add constraint PK_TLEMEXETARENV primary key (IDELEMEXETARENV)

	/*==============================================================*/
	/* Index: TPACTAR2TLEMEXETARENV_FK                              */
	/*==============================================================*/
	create index TPACTAR2TLEMEXETARENV_FK on TLEMEXETARENV (
	IDEPACTAR ASC
	)

	/*==============================================================*/
	/* Index: TUSUREM2TLEMEXETARENV_FK                              */
	/*==============================================================*/
	create index TUSUREM2TLEMEXETARENV_FK on TLEMEXETARENV (
	IDEUSUREM ASC
	)

	/*==============================================================*/
	/* Index: TUSUDES2TLEMEXETARENV_FK                              */
	/*==============================================================*/
	create index TUSUDES2TLEMEXETARENV_FK on TLEMEXETARENV (
	IDEUSUDES ASC
	)

	alter table TLEMEXETARENV
	   add constraint TPACTAR2TLEMEXETARENV_FK foreign key (IDEPACTAR)
		  references TPACTAR (IDEPACTAR)

	alter table TLEMEXETARENV
	   add constraint TUSUDES2TLEMEXETARENV_FK foreign key (IDEUSUDES)
		  references TUSU (IDEUSU)

	alter table TLEMEXETARENV
	   add constraint TUSUREM2TLEMEXETARENV_FK foreign key (IDEUSUREM)
		  references TUSU (IDEUSU)

	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20171019-269', GETDATE())
END
GO



PRINT ('CASO 278')
GO

/* Adicionando coluna para data de recebimento do documento */
/*********************************************************/
/**********************   CASO 278  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20171211-278')
BEGIN
	
/*==============================================================*/
  
		/*==============================================================*/
		/* TABLE: TDOCLICAMB                                       		*/
		/*==============================================================*/
		ALTER TABLE TDOCLICAMB ADD DATREC DATETIME NULL
		ALTER TABLE TDOCLICAMB ADD IDEUSUANX DECIMAL(13) NULL
		
		/*==============================================================*/
		/* Index: TUSU2TDOCLICAMB_FK                                    */
		/*==============================================================*/
		create index TUSU2TDOCLICAMB_FK on TDOCLICAMB (
		IDEUSUANX ASC
		)

		alter table TDOCLICAMB
		   add constraint TUSU2TDOCLICAMB_FK foreign key (IDEUSUANX)
			  references TUSU (IDEUSU)

		
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20171211-278', GETDATE())
END
GO

UPDATE TDOCLICAMB SET IDEUSUANX = 1110000000000 WHERE IDEUSUANX IS NULL



print ('CASO 302')
GO
/* Criando estrutura para permitir criação de Tags */
/*********************************************************/
/*********************   CASO 302  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20180319-302')
BEGIN
/*==============================================================*/
	DECLARE @lOrd INT
	BEGIN

		SELECT @lOrd = MAX(ORD) + 1
		  FROM TREGSIS
		 WHERE TIP = 1
		 
		INSERT INTO TREGSIS (IDEMOD, CODINT, NME, ORD, TIP, UPDTME)
			 SELECT IDEMOD, 'Remover tags do cadastro', 'Remover tags do cadastro', @lOrd, 1, GETDATE()
			   FROM TMOD
			  WHERE MODNME = 'Onegreen'

	END	
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TCMPTAG                                               */
	/*==============================================================*/
	CREATE TABLE TCMPTAG (
	   IDECMPTAG            DECIMAL(13)          IDENTITY(1110000000000,1),
	   UPDTME               DATETIME             NOT NULL
	)

	ALTER TABLE TCMPTAG
	   ADD CONSTRAINT TCMPTAG_PK PRIMARY KEY (IDECMPTAG)
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TTAGAMB                                               */
	/*==============================================================*/
	CREATE TABLE TTAGAMB (
	   IDETAGAMB            DECIMAL(13)          IDENTITY(1110000000000, 1),
	   IDEEMP               DECIMAL(13)          NULL,
	   NME                  NVARCHAR(100)        NOT NULL,
	   UPDTME               DATETIME             NOT NULL
	)

	ALTER TABLE TTAGAMB
	   ADD CONSTRAINT TTAGAMB_PK PRIMARY KEY (IDETAGAMB)

	/*==============================================================*/
	/* INDEX: TEPM2TTAGAMB_FK                                       */
	/*==============================================================*/
	CREATE INDEX TEPM2TTAGAMB_FK ON TTAGAMB (
	IDEEMP ASC
	)

	ALTER TABLE TTAGAMB
	   ADD CONSTRAINT TEMP2TTAGAMB_FK FOREIGN KEY (IDEEMP)
		  REFERENCES TEMP (IDEEMP)
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TCMPTAGAMB                                            */
	/*==============================================================*/
	CREATE TABLE TCMPTAGAMB (
	   IDECMPTAG            DECIMAL(13)          NULL,
	   IDETAGAMB            DECIMAL(13)          NULL
	)

	ALTER TABLE TCMPTAGAMB
	   ADD CONSTRAINT TCMPTAG2TCMPTAGAMB_FK FOREIGN KEY (IDECMPTAG)
		  REFERENCES TCMPTAG (IDECMPTAG)

	ALTER TABLE TCMPTAGAMB
	   ADD CONSTRAINT TTAGAMB2TCMPTAGAMB_FK FOREIGN KEY (IDETAGAMB)
		  REFERENCES TTAGAMB (IDETAGAMB)
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TEPRLICAMB                                            */
	/*==============================================================*/
	ALTER TABLE TEPRLICAMB
		ADD IDECMPTAG DECIMAL(13) NULL
	
	/*==============================================================*/
	/* INDEX: TCMPTAG2TEPRLICAMB_FK                                 */
	/*==============================================================*/
	CREATE INDEX TCMPTAG2TEPRLICAMB_FK ON TEPRLICAMB (
	IDECMPTAG ASC
	)

	ALTER TABLE TEPRLICAMB
	   ADD CONSTRAINT TCMPTAG2TEPRLICAMB_FK FOREIGN KEY (IDECMPTAG)
		  REFERENCES TCMPTAG (IDECMPTAG)
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TLICAMB                                               */
	/*==============================================================*/
	ALTER TABLE TLICAMB
		ADD IDECMPTAG DECIMAL(13) NULL
	
	/*==============================================================*/
	/* INDEX: TCMPTAG2TLICAMB_FK                                    */
	/*==============================================================*/
	CREATE INDEX TCMPTAG2TLICAMB_FK ON TLICAMB (
	IDECMPTAG ASC
	)

	ALTER TABLE TLICAMB
	   ADD CONSTRAINT TCMPTAG2TLICAMB_FK FOREIGN KEY (IDECMPTAG)
		  REFERENCES TCMPTAG (IDECMPTAG)
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TPACTAR                                               */
	/*==============================================================*/
	ALTER TABLE TPACTAR
		ADD IDECMPTAG DECIMAL(13) NULL
	
	/*==============================================================*/
	/* INDEX: TCMPTAG2TPACTAR_FK                                    */
	/*==============================================================*/
	CREATE INDEX TCMPTAG2TPACTAR_FK ON TPACTAR (
	IDECMPTAG ASC
	)

	ALTER TABLE TPACTAR
	   ADD CONSTRAINT TCMPTAG2TPACTAR_FK FOREIGN KEY (IDECMPTAG)
		  REFERENCES TCMPTAG (IDECMPTAG)
/*==============================================================*/
	/*==============================================================*/
	/* TABLE: TESTLICAMB                                               */
	/*==============================================================*/
	ALTER TABLE TESTLICAMB
		ADD IDECMPTAG DECIMAL(13) NULL
	
	/*==============================================================*/
	/* INDEX: TCMPTAG2TESTLICAMB_FK                                 */
	/*==============================================================*/
	CREATE INDEX TCMPTAG2TESTLICAMB_FK ON TESTLICAMB (
	IDECMPTAG ASC
	)

	ALTER TABLE TESTLICAMB
	   ADD CONSTRAINT TCMPTAG2TESTLICAMB_FK FOREIGN KEY (IDECMPTAG)
		  REFERENCES TCMPTAG (IDECMPTAG)
/*==============================================================*/
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180319-302', GETDATE())
END
GO



/*********************************************************/
/*********************** CASO 306 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 306'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20180329-306')
BEGIN

	exec sp_ModifyColumn 'TORG', 'SIG', 'NVARCHAR(30)', 1, ''' '''
		
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180329-306', GETDATE())
	
END
GO



print ('CASO 309')
GO
/* Criando permissão total para às tarefas */
/*********************************************************/
/*********************   CASO 309  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20180402-309')
BEGIN
/*==============================================================*/
	DECLARE @lOrd INT
	BEGIN

		SELECT @lOrd = MAX(ORD) + 1
		  FROM TREGSIS
		 WHERE TIP = 2
		 
		INSERT INTO TREGSIS (IDEMOD, CODINT, NME, ORD, TIP, UPDTME)
			 SELECT IDEMOD, 'Permissão total às tarefas_Onegreen', 'Permissão total às tarefas', @lOrd, 2, GETDATE()
			   FROM TMOD
			  WHERE MODNME = 'Onegreen'

	END	
/*==============================================================*/
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180402-309', GETDATE())
END
GO



print ('CASO 285')
GO
/* Criando regra para propagação da reprogramação da Validade das Licenças para Tarefas */
/*********************************************************/
/*********************   CASO 285  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20180403-285')
BEGIN
/*==============================================================*/
	DECLARE @lOrd INT
	BEGIN

		SELECT @lOrd = MAX(ORD) + 1
		  FROM TREGSIS
		 WHERE TIP = 2
		 
		INSERT INTO TREGSIS (IDEMOD, CODINT, NME, ORD, TIP, UPDTME)
			 SELECT IDEMOD, 'Propagar reprogramação da Validade das Licenças para Tarefas / Condicionantes_Onegreen', 'Propagar reprogramação da Validade das Licenças para Tarefas / Condicionantes', @lOrd, 2,  GETDATE()
			   FROM TMOD
			  WHERE MODNME = 'Onegreen'

	END	
/*==============================================================*/

	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180403-285', GETDATE())
END
GO




print ('CASO 271')
GO
/* Atualização no usuário do Onegreen  */
/*********************************************************/
/*********************   CASO 271  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20180404-271')
BEGIN
/*==============================================================*/

	UPDATE TUSU SET SUPADM = 0
	UPDATE TUSU SET SUPADM = 1 WHERE UPPER(NME) = 'ONEGREEN'

/*==============================================================*/

	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180404-271', GETDATE())
END
GO



/*==============================================================*/
/* ATUALIZAÃ‡ÃƒO DA VERSÃƒO DO BANCO DE DADOS                      */
/*==============================================================*/

DECLARE @LVERSION DATETIME,
		@VERSAO   NVARCHAR(10)
SET @LVERSION = CAST('20180413' AS DATETIME)
SET @VERSAO = '1804.1'
IF EXISTS(SELECT VRS FROM TVRS WHERE VRS = @LVERSION AND NUMVRS = @VERSAO)
   UPDATE TVRS SET DTATBL = GETDATE() WHERE VRS = @LVERSION AND NUMVRS = @VERSAO;
ELSE
    INSERT INTO TVRS (VRS, DTATBL , NUMVRS) VALUES (@LVERSION, GETDATE() , @VERSAO);
GO

BEGIN
PRINT '1804.1'
END
GO

