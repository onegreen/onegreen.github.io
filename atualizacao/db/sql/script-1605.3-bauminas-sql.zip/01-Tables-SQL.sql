

print ('CASO 15')
GO
/* Adicionando coluna de empresa na tabela de estados */
/*********************************************************/
/**********************   CASO 15  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160218-15')
BEGIN
	
/*==============================================================*/
  
	ALTER TABLE TESTPRV ADD IDEEMP DECIMAL(13) NULL

	/*==============================================================*/
	/* INDEX: TEMP2TESTPRV_FK                                       */
	/*==============================================================*/
	CREATE INDEX TEMP2TESTPRV_FK ON TESTPRV (
	IDEEMP ASC
	)

	ALTER TABLE TESTPRV
	   ADD CONSTRAINT TEMP2TESTPRV_FK FOREIGN KEY (IDEEMP)
		  REFERENCES TEMP (IDEEMP)
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160218-15', GETDATE())
END
GO


DECLARE @lIdeEmp DECIMAL(13)
BEGIN

	SELECT @lIdeEmp = IDEEMP 
	  FROM TTIPLICREGAMB
	 GROUP BY IDEEMP 


	  UPDATE TESTPRV SET IDEEMP = @lIdeEmp
	  UPDATE TWKF SET IDEEMP = @lIdeEmp

END
GO



print ('CASO 16')
GO
/* Criando Tabela de Atividades do licenciamento */
/*********************************************************/
/**********************   CASO 16  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160218-16')
BEGIN
	
/*==============================================================*/
  
	/*==============================================================*/
	/* TABLE: TATVEPRLICAMB                                         */
	/*==============================================================*/
	CREATE TABLE TATVEPRLICAMB (
	   IDEATVEPRLICAMB      DECIMAL(13)          IDENTITY(1110000000000,1),
	   IDEEPRLICAMB         DECIMAL(13)          NULL,
	   IDELICAMB            DECIMAL(13)          NULL,
	   IDEATVREGLICAMB      DECIMAL(13)          NOT NULL,
	   IDESIMFRM            DECIMAL(13)          NOT NULL,
	   DES                  NVARCHAR(150)        NOT NULL,
	   UPDTME               DATETIME             NOT NULL
	)

	ALTER TABLE TATVEPRLICAMB
	   ADD CONSTRAINT PK_TATVEPRLICAMB PRIMARY KEY (IDEATVEPRLICAMB)

	/*==============================================================*/
	/* INDEX: TATVREGLICAMB2TATVEPRLICAMB_FK                        */
	/*==============================================================*/
	CREATE INDEX TATVREGLICAMB2TATVEPRLICAMB_FK ON TATVEPRLICAMB (
	IDEATVREGLICAMB ASC
	)

	/*==============================================================*/
	/* INDEX: TSIMFRM2TATVEPRLICAMB_FK                              */
	/*==============================================================*/
	CREATE INDEX TSIMFRM2TATVEPRLICAMB_FK ON TATVEPRLICAMB (
	IDESIMFRM ASC
	)

	/*==============================================================*/
	/* INDEX: TEPRLICAMB2TATVEPRLICAMB_FK                           */
	/*==============================================================*/
	CREATE INDEX TEPRLICAMB2TATVEPRLICAMB_FK ON TATVEPRLICAMB (
	IDEEPRLICAMB ASC
	)

	/*==============================================================*/
	/* INDEX: TLICAMB2TATVEPRLICAMB_FK                              */
	/*==============================================================*/
	CREATE INDEX TLICAMB2TATVEPRLICAMB_FK ON TATVEPRLICAMB (
	IDELICAMB ASC
	)

	ALTER TABLE TATVEPRLICAMB
	   ADD CONSTRAINT TATVREGLICAMB2TATVEPRLICAMB_FK FOREIGN KEY (IDEATVREGLICAMB)
		  REFERENCES TATVREGLICAMB (IDEATVREGLICAMB)

	ALTER TABLE TATVEPRLICAMB
	   ADD CONSTRAINT TEPRLICAMB2TATVEPRLICAMB_FK FOREIGN KEY (IDEEPRLICAMB)
		  REFERENCES TEPRLICAMB (IDEEPRLICAMB)

	ALTER TABLE TATVEPRLICAMB
	   ADD CONSTRAINT TLICAMB2TATVEPRLICAMB_FK FOREIGN KEY (IDELICAMB)
		  REFERENCES TLICAMB (IDELICAMB)

	ALTER TABLE TATVEPRLICAMB
	   ADD CONSTRAINT TSIMFRM2TATVEPRLICAMB_FK FOREIGN KEY (IDESIMFRM)
		  REFERENCES TSIMFRM (IDESIMFRM)
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160218-16', GETDATE())
END
GO



print ('CASO 37')
GO
/* Adicionar campos na TTIPLICAMB para permitir Renova��o e Prazo Limite para Renova��o */
/*********************************************************/
/**********************   CASO 37  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160218-37')
BEGIN
	
/*==============================================================*/
  
   ALTER TABLE TTIPLICAMB ADD PMTRNV DECIMAL(1) NOT NULL DEFAULT 1
   
   ALTER TABLE TTIPLICAMB ADD PRZLMTRNV INT NULL
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160218-37', GETDATE())
END
GO



print ('CASO 45')
GO
/* Adicionar campo TLAINI na tabela TUSU para tela inicial por usu�rio */
/*********************************************************/
/**********************   CASO 45  ***********************/
/*********************************************************/

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160218-45')
BEGIN
	
/*==============================================================*/
  
   ALTER TABLE TUSU ADD TLAINI DECIMAL(1) NULL 
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160218-45', GETDATE())
END
GO



print ('CASO 73')
GO

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160418-73')
BEGIN
	
/*==============================================================*/
  
UPDATE tRegSis SET CODINT = 'Criar e alterar Projetos / Empreendimentos de Licenciamento_Onegreen' where Nme = 'Criar e alterar Projetos / Empreendimentos de Licenciamento'
UPDATE tRegSis SET CODINT = 'Criar e alterar Licen�as Ambientais_Onegreen' where Nme = 'Criar e alterar Licen�as Ambientais'
UPDATE tRegSis SET CODINT = 'Criar e alterar Condicionantes das Licen�as_Onegreen' where Nme = 'Criar e alterar Condicionantes das Licen�as'
UPDATE tRegSis SET CODINT = 'Criar e alterar Estudos das Licen�as_Onegreen' where Nme = 'Criar e alterar Estudos das Licen�as'
UPDATE tRegSis SET CODINT = 'Aprovar solicita��es de licenciamento do Meio Ambiente_Onegreen' where Nme = 'Aprovar solicita��es de licenciamento do Meio Ambiente'
UPDATE tRegSis SET CODINT = 'Excluir/Alterar Execu��es e Excluir Coment�rios de Tarefas_Onegreen' where Nme = 'Excluir/Alterar Execu��es e Excluir Coment�rios de Tarefas'
UPDATE tRegSis SET CODINT = 'Desativar ou Reativar Tarefas_Onegreen' where Nme = 'Desativar ou Reativar Tarefas'
UPDATE tRegSis SET CODINT = 'Criar e alterar Tarefas das Licen�as_Onegreen' where Nme = 'Criar e alterar Tarefas das Licen�as'
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160418-73', GETDATE())
END
GO



print ('CASO 74')
GO

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160418-74')
BEGIN
	
/*==============================================================*/
  
UPDATE tlogace SET Prd = 'Onegreen' WHERE Prd = 'Sigma'
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160418-74', GETDATE())
END
GO



print ('CASO 76')
GO

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160419-76')
BEGIN
	
/*==============================================================*/
  
UPDATE tPlaAco SET Typ = 'PortalSIM.Domain.LicenciamentoAmbiental.PlanoDeAcaoDoOnegreen' WHERE Typ = 'PortalSIM.Domain.LicenciamentoAmbiental.PlanoDeAcaoDoSigma'
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160419-76', GETDATE())
END
GO



print ('CASO 78')
GO

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160425-78')
BEGIN
	
/*==============================================================*/
  
UPDATE tCfgSetIte SET Vlr = 'OnegreenRoute' where Chv = 'DefaultRoute'
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160425-78', GETDATE())
END
GO



print ('CASO 79')
GO

IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160427-79')
BEGIN
	
/*==============================================================*/
  
UPDATE tMod SET ModNme = 'Onegreen' where ModNme = 'SIGMA'
	
/*==============================================================*/
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160427-79', GETDATE())
END
GO



/*********************************************************/
/*********************** CASO 102 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 102'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160520-102')
BEGIN

	IF EXISTS (SELECT 1
					 FROM SYSCOLUMNS
					WHERE ID = OBJECT_ID('TLOGACE')
					  AND UPPER(NAME) = 'IDNSEC')
	BEGIN
		
		EXEC SP_DROPCOLUMN 'TLOGACE', 'IDNSEC'

	END


	IF EXISTS (SELECT 1
					 FROM SYSCOLUMNS
					WHERE ID = OBJECT_ID('TLOGACE')
					  AND UPPER(NAME) = 'INPUSU')
	BEGIN
			
		EXEC SP_DROPCOLUMN 'TLOGACE', 'INPUSU'

	END
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160520-102', GETDATE())
END
GO



/*********************************************************/
/*********************** CASO 104 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 104'
END
GO


IF NOT EXISTS (SELECT 1
				 FROM TSQLUPD
				WHERE COD = '20160520-104')
BEGIN

	IF EXISTS (SELECT 1
			FROM  SYSCOLUMNS
			WHERE  ID = OBJECT_ID('TATVREGLICAMB')
			AND UPPER(NAME) = 'IDEPRTLICAMB'
			AND ISNULLABLE = 0)
	BEGIN
		IF EXISTS (SELECT 1
				FROM DBO.SYSREFERENCES R JOIN DBO.SYSOBJECTS O ON (O.ID = R.CONSTID AND O.TYPE = 'F')
				WHERE R.FKEYID = OBJECT_ID('TATVREGLICAMB') AND O.NAME = 'TPRTLICAMB2TATVREGLICAMB_FK')
			ALTER TABLE TATVREGLICAMB DROP CONSTRAINT TPRTLICAMB2TATVREGLICAMB_FK
		
		IF EXISTS (SELECT 1
				 FROM SYSINDEXES
				WHERE ID    = OBJECT_ID('TATVREGLICAMB')
				  AND NAME  = 'TPRTLICAMB2TATVREGLICAMB_FK'
				  AND INDID > 0
				  AND INDID < 255)
			DROP INDEX TATVREGLICAMB.TPRTLICAMB2TATVREGLICAMB_FK

		EXEC SP_MODIFYCOLUMN 'TATVREGLICAMB','IDEPRTLICAMB','DECIMAL(13)',0, 'NULL'

		EXEC('CREATE INDEX TPRTLICAMB2TATVREGLICAMB_FK ON TATVREGLICAMB (
				IDEPRTLICAMB ASC
				)')
		
		EXEC('ALTER TABLE TATVREGLICAMB
				   ADD CONSTRAINT TPRTLICAMB2TATVREGLICAMB_FK FOREIGN KEY (IDEPRTLICAMB)
					  REFERENCES TPRTLICAMB (IDEPRTLICAMB)')
	END
	
	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160520-104', GETDATE())
END
GO


/*********************************************************/
/*********************** CASO 109 ************************/
/*********************************************************/

BEGIN
PRINT 'CASO 109'
END
GO

DECLARE @lIdeWkfAtv		DECIMAL(13),
		@lIdeWkfAtvNxt	DECIMAL(13)
BEGIN

	IF NOT EXISTS (SELECT 1
					 FROM TSQLUPD
					WHERE COD = '20160524-109')
	BEGIN

		IF NOT EXISTS (select 1 from twkfaca where msgcnf = 'Deseja realmente reativar o projeto?')
		BEGIN

			UPDATE TWKFATV SET TYP = 'PortalSIM.Domain.WorkflowFx.Tarefa' 
			 WHERE IDEWKFATV = (SELECT ATV.IDEWKFATV
								  FROM TWKFATV ATV
								 INNER JOIN TWKFFAS FAS ON FAS.IDEWKFFAS = ATV.IDEWKFFAS
								 INNER JOIN TWKF WKF ON WKF.IDEWKF = FAS.IDEWKF
								 WHERE TYPTIP = 'PortalSIM.Domain.LicenciamentoAmbiental.Empreendimento'
								   AND ATV.NME = 'Cancelamento')

			SELECT @lIdeWkfAtv = ATV.IDEWKFATV
			  FROM TWKFATV ATV
			 INNER JOIN TWKFFAS FAS ON FAS.IDEWKFFAS = ATV.IDEWKFFAS
			 INNER JOIN TWKF WKF ON WKF.IDEWKF = FAS.IDEWKF
			 WHERE TYPTIP = 'PortalSIM.Domain.LicenciamentoAmbiental.Empreendimento'
			   AND ATV.NME = 'Cancelamento'

			SELECT @lIdeWkfAtvNxt = ATV.IDEWKFATV
			  FROM TWKFATV ATV
			 INNER JOIN TWKFFAS FAS ON FAS.IDEWKFFAS = ATV.IDEWKFFAS
			 INNER JOIN TWKF WKF ON WKF.IDEWKF = FAS.IDEWKF
			 WHERE TYPTIP = 'PortalSIM.Domain.LicenciamentoAmbiental.Empreendimento'
			   AND ATV.NME = 'Elaborar Empreendimento'

		   
			INSERT INTO TWKFACA (IDEWKFATV,IDEWKFATVNXT,ORD,NME,MSGCNF,ACERES,ICOLFT,ICORGT,BTNCSS,UPDTME,DES,EXGJUS,NMEEXB,RTADET,ACEVERESTVAL) 
						 VALUES (@lIdeWkfAtv, @lIdeWkfAtvNxt, 0, 'Reativar', 'Deseja realmente reativar o projeto?', NULL, 'icon-chevron-right icon-white', NULL, 'btn-danger', getdate(), 'Reativar', 0, NULL, NULL, 'ValidarUsuarioRequisitante')


			UPDATE TWKFACA SET RTADET = '{"Area":"Onegreen","Controller":"SolicitacoesDeLicenciamento","Action":"AoAprovarUmaSolicitacaoDeLicenciamento"}' WHERE UPPER(NME) LIKE 'APROVAR SOLICITA��O'

		END
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160524-109', GETDATE())

	END
END
GO




/*==============================================================*/
/* ATUALIZA��O DA VERS�O DO BANCO DE DADOS                      */
/*==============================================================*/

DECLARE @LVERSION DATETIME,
		@VERSAO   NVARCHAR(10)
SET @LVERSION = CAST('20160513' AS DATETIME)
SET @VERSAO = '1605.1'
IF EXISTS(SELECT VRS FROM TVRS WHERE VRS = @LVERSION AND NUMVRS = @VERSAO)
   UPDATE TVRS SET DTATBL = GETDATE() WHERE VRS = @LVERSION AND NUMVRS = @VERSAO;
ELSE
    INSERT INTO TVRS (VRS, DTATBL , NUMVRS) VALUES (@LVERSION, GETDATE() , @VERSAO);
GO

BEGIN
PRINT '1605.1'
END
GO

