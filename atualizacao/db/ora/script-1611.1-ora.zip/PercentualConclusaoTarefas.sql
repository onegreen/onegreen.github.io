

CREATE OR REPLACE FUNCTION PercentualConclusaoTarefas(pTableName IN VARCHAR, pIdeTable IN NUMBER, pData IN DATE, pPrevisto IN NUMBER) RETURN FLOAT
AS

/* FUNCAO      : PercentualConclusaoDeTarefa         
   PROPOSITO   : RETORNA O PERCENTUAL PREVISTO DE CONCLUSAO DE UMA TAREFA
   PARAMETROS  : pTableName: Tabela principal para busca das tarefas  
				 pIdeTable:  Id do registro da tabela principal para busca das tarefas  
				 pData: 	 Data de corte para retorno das tarefas
				 pPrevisto:	 Bit se deve retornar percentual previsto ou realizado das tarefas
   Criacao      : 02/10/2016 - erac
   �ltima Alt.  : */

    lPer            FLOAT;
    lHorasTotais    FLOAT;
    lHorasAteAgora  FLOAT;
    lCountTarefas   FLOAT;
BEGIN
    IF UPPER(pTableName) = 'TPLAACO' THEN
    IF pPrevisto <> 0 THEN            
      SELECT SUM(RetornarHorasAteAgora(INIPRE, FIMPRE, DURHRA, FREREC, pData)) INTO lHorasAteAgora
        FROM TPLAACO
        INNER JOIN TPACTAR ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
        WHERE TPLAACO.IDEPLAACO = pIdeTable
        AND TPACTAR.DEL = 0
        AND TPACTAR.INIPRE < pData
        AND (TPACTAR.IDEPACTARSUP IS NOT NULL OR TPACTAR.TEMSUB = 0);
        
      SELECT SUM(CASE WHEN TPACTAR.DURHRA = 0 OR TPACTAR.DURHRA IS NULL THEN 8 ELSE ABS(TPACTAR.DURHRA) END) INTO lHorasTotais
        FROM TPLAACO
        INNER JOIN TPACTAR ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
        WHERE TPLAACO.IDEPLAACO = pIdeTable
        AND TPACTAR.DEL = 0					
        AND (TPACTAR.IDEPACTARSUP IS NOT NULL OR TPACTAR.TEMSUB = 0);
          
      lPer := lHorasAteAgora * 100 / lHorasTotais;
        
    ELSE
      SELECT SUM((TPACTAR.PERCON / 100 * CASE WHEN TPACTAR.DURHRA = 0 OR TPACTAR.DURHRA IS NULL THEN 8 ELSE ABS(TPACTAR.DURHRA) END)) INTO lHorasAteAgora
        FROM TPLAACO
        INNER JOIN TPACTAR ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
        WHERE TPLAACO.IDEPLAACO = pIdeTable
        AND TPACTAR.DEL = 0
        AND TPACTAR.PERCON > 0 -- TAREFAS COM EXECUCOES ANTES MESMO DO INICIO PREVISTO
        AND ((TO_DATE(TPACTAR.FIMPRE) <= pData AND TO_DATE(TPACTAR.INIREA) <= pData) OR TO_DATE(TPACTAR.INIREA) <= pData)
        AND (TPACTAR.IDEPACTARSUP IS NOT  NULL OR TPACTAR.TEMSUB = 0);
    
      SELECT SUM(CASE WHEN TPACTAR.DURHRA = 0 OR TPACTAR.DURHRA IS NULL THEN 8 ELSE ABS(TPACTAR.DURHRA) END) INTO lHorasTotais
        FROM TPLAACO
        INNER JOIN TPACTAR ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
        WHERE TPLAACO.IDEPLAACO = pIdeTable
        AND TPACTAR.DEL = 0					
        AND (TPACTAR.IDEPACTARSUP IS NOT NULL OR TPACTAR.TEMSUB = 0);
        
      lPer := lHorasAteAgora * 100 / lHorasTotais;
    END IF;
  ELSE
      SELECT 0 INTO lPer FROM DUAL;
    END IF;
    
    IF lPer > 100 THEN
  lPer := 100;
END IF;
    
    RETURN TRUNC(lPer, 2);

END;