

/*********************************************************/
/*********************** CASO 186 ************************/
/*********************************************************/

BEGIN
dbms_output.put_line('CASO 186');
END;
/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20170130-186';

	IF lExists = 0 THEN
		
		EXECUTE IMMEDIATE 'ALTER TABLE TLICAMB ADD CSTMAN NUMBER(1) DEFAULT 0 NOT NULL';
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170130-186', SYSDATE);
		COMMIT;
	END IF;
END;
/

/*********************************************************/
/*********************** CASO 202 ************************/
/*********************************************************/

BEGIN
dbms_output.put_line('CASO 202');
END;
/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20170320-202';

	IF lExists = 0 THEN
		
		EXECUTE IMMEDIATE 'ALTER TABLE TDOCLICAMB MODIFY DES NVARCHAR2(250)';
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170320-202', SYSDATE);
		COMMIT;
	END IF;
END;
/

BEGIN
	dbms_output.put_line('CASO 205');
END;
/

/* Criando Tabela de Itens do Plano da Empresa */
/*********************************************************/
/**********************   CASO 205  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20170404-205';

	IF lExists = 0 THEN

  
/*==============================================================*/
		
		/*==============================================================*/
		/* TABLE: TPLNCONITEEMP                                         */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE TABLE TPLNCONITEEMP  (
							   IDEPLNCONEMP         NUMBER(13)                      NOT NULL,
							   CHV                  VARCHAR(50)                     NOT NULL,
							   VLR                  VARCHAR(50)                     NOT NULL
							)';

		/*==============================================================*/
		/* INDEX: TPLNCONEMP2TPLNCONITEEMP_FK                        */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TPLNCONEMP2TPLNCONITEEMP_FK ON TPLNCONITEEMP (
						   IDEPLNCONEMP ASC
						)';

		EXECUTE IMMEDIATE 'ALTER TABLE TPLNCONITEEMP
			   ADD CONSTRAINT TPLNCONEMP2TPLNCONITEEMP_FK FOREIGN KEY (IDEPLNCONEMP)
				  REFERENCES TPLNCONEMP (IDEPLNCONEMP)
				  ON DELETE CASCADE';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170404-205', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 220');
END;
/

/* Adicionando coluna para possibilitar remoÃ§Ã£o de atividades dos Relatorios e Graficos */
/*********************************************************/
/**********************   CASO 220  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20170508-220';

	IF lExists = 0 THEN

  
/*==============================================================*/
		
		/*==============================================================*/
		/* TABLE: TPACTAR                                         		*/
		/*==============================================================*/
		EXECUTE IMMEDIATE 'ALTER TABLE TPACTAR ADD REMRELGRA NUMBER (1) DEFAULT 0 NOT NULL ';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170508-220', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 253');
END;
/

/*********************************************************/
/**********************   CASO 253  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20170629-253';

	IF lExists = 0 THEN

  
/*==============================================================*/
  
  FOR TAR IN (SELECT CASE WHEN ACO.IDEPLAACO = LIC.IDEPLAACONTF THEN 1 /* NotificaÃ§Ã£o / Termo */
											WHEN ACO.IDEPLAACO = LIC.IDEPLAACOCMP THEN 2 /* CompensatÃ³ria */
											WHEN ACO.IDEPLAACO = LIC.IDEPLAACOPRGAMB THEN 3 /* Programa Ambiental */
											WHEN ACO.IDEPLAACO = LIC.IDEPLAACOORIBAS THEN 4 /* OrientaÃ§Ã£o */
											ELSE NULL END VINCULO, ACO.IDEPLAACO
								FROM TPLAACO ACO
								INNER JOIN TLICAMB LIC ON ACO.IDEPLAACO = LIC.IDEPLAACOCMP OR ACO.IDEPLAACO = LIC.IDEPLAACOPRGAMB OR ACO.IDEPLAACO = LIC.IDEPLAACONTF OR ACO.IDEPLAACO = LIC.IDEPLAACOORIBAS )
  LOOP

  	IF TAR.Vinculo = 1 THEN
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.NotificacaoDaLicenca', NME = 'NotificaÃ§Ãµes / Termos de Compromisso' WHERE IDEPLAACO = TAR.IdePlaAco;
		ELSIF TAR.Vinculo = 2 THEN
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.CompensatoriaDaLicenca', NME = 'CompensatÃ³rias' WHERE IDEPLAACO = TAR.IdePlaAco;
		ELSIF TAR.Vinculo = 3 THEN
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.ProgramaAmbientalDaLicenca', NME = 'Programas Ambientais' WHERE IDEPLAACO = TAR.IdePlaAco;
		ELSIF TAR.Vinculo = 4 THEN
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.OrientacaoDaLicenca', NME = 'OrientaÃ§Ãµes' WHERE IDEPLAACO = TAR.IdePlaAco;
		END IF;

  END LOOP;


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170629-253', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 257');
END;
/

/* Adicionando coluna para descriÃ§Ã£o do prazo da tarefa */
/*********************************************************/
/**********************   CASO 257  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20170804-257';

	IF lExists = 0 THEN

  
/*==============================================================*/
		
		/*==============================================================*/
		/* TABLE: TPACTAR                                         		*/
		/*==============================================================*/
		EXECUTE IMMEDIATE 'ALTER TABLE TPACTAR ADD PRZ NVARCHAR2(500)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170804-257', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 266');
END;
/

/* Removendo Tipo Uso Ãgua do Sistema */
/*********************************************************/
/**********************   CASO 266  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20170922-266';

	IF lExists = 0 THEN

  
/*==============================================================*/
		
		/*==============================================================*/
		/* TABLE: TPACTAR                                         		*/
		/*==============================================================*/
		EXECUTE IMMEDIATE 'DELETE FROM TMNUSIS WHERE NME = ''TiposDeUsoDeAgua''';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170922-266', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 261');
END;
/

/* Criando Tabela de Documentos no Histórico */
/*********************************************************/
/*********************   CASO 261  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20171019-261';

	IF lExists = 0 THEN

  
/*==============================================================*/
	/*==============================================================*/
	/* Table: TOBSLICAMBDOCLICAMB                                   */
	/*==============================================================*/
	EXECUTE IMMEDIATE 'create table TOBSLICAMBDOCLICAMB  (
	   IDEDOCLICAMB         NUMBER(13),
	   IDEOBSLICAMB         NUMBER(13)
	)';

	/*==============================================================*/
	/* Index: TDOCLICAMB2TOBSLICAMBDOCLICAMB                        */
	/*==============================================================*/
	EXECUTE IMMEDIATE 'create index TDOCLICAMB2TOBSLICAMBDOCLIC_FK on TOBSLICAMBDOCLICAMB (
	   IDEDOCLICAMB ASC
	)';

	/*==============================================================*/
	/* Index: TOBSLICAMB2TOBSLICAMBDOCLICAMB                        */
	/*==============================================================*/
	EXECUTE IMMEDIATE 'create index TOBSLICAMB2TOBSLICAMBDOCLIC_FK on TOBSLICAMBDOCLICAMB (
	   IDEOBSLICAMB ASC
	)';
	
	EXECUTE IMMEDIATE 'alter table TOBSLICAMBDOCLICAMB
		add constraint TDOCLICAMB2TOBSLICAMBDOCLIC_FK foreign key (IDEDOCLICAMB)
			references TDOCLICAMB (IDEDOCLICAMB)';

	EXECUTE IMMEDIATE 'alter table TOBSLICAMBDOCLICAMB
		add constraint TOBSLICAMB2TOBSLICAMBDOCLIC_FK foreign key (IDEOBSLICAMB)
			references TOBSLICAMB (IDEOBSLICAMB)';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20171019-261', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 269');
END;
/

/* Criando Tabela de Lembrete de Execução de Tarefas Enviados */
/*********************************************************/
/*********************   CASO 269  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20171019-269';

	IF lExists = 0 THEN

  
/*==============================================================*/
	EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQLEMEXETARENV START WITH 1110000000000 INCREMENT BY 1';
	
	/*==============================================================*/
	/* Table: TLEMEXETARENV                                         */
	/*==============================================================*/
	EXECUTE IMMEDIATE 'create table TLEMEXETARENV  (
	   IDELEMEXETARENV      NUMBER(13)                      not null,
	   IDEUSUREM            NUMBER(13)                      not null,
	   IDEPACTAR            NUMBER(13)                      not null,
	   IDEUSUDES            NUMBER(13)                      not null,
	   MSG                  NVARCHAR2(500),
	   UPDTME               DATE                            not null
	);';

	EXECUTE IMMEDIATE 'alter table TLEMEXETARENV
	   add constraint PK_TLEMEXETARENV primary key (IDELEMEXETARENV)';

	/*==============================================================*/
	/* Index: TPACTAR2TLEMEXETARENV_FK                              */
	/*==============================================================*/
	EXECUTE IMMEDIATE 'create index TPACTAR2TLEMEXETARENV_FK on TLEMEXETARENV (
	   IDEPACTAR ASC
	)';

	/*==============================================================*/
	/* Index: TUSUREM2TLEMEXETARENV_FK                              */
	/*==============================================================*/
	EXECUTE IMMEDIATE 'create index TUSUREM2TLEMEXETARENV_FK on TLEMEXETARENV (
	   IDEUSUREM ASC
	)';

	/*==============================================================*/
	/* Index: TUSUDES2TLEMEXETARENV_FK                              */
	/*==============================================================*/
	EXECUTE IMMEDIATE 'create index TUSUDES2TLEMEXETARENV_FK on TLEMEXETARENV (
	   IDEUSUDES ASC
	)';

	EXECUTE IMMEDIATE 'alter table TLEMEXETARENV
	   add constraint TPACTAR2TLEMEXETARENV_FK foreign key (IDEPACTAR)
		  references TPACTAR (IDEPACTAR)';

	EXECUTE IMMEDIATE 'alter table TLEMEXETARENV
	   add constraint TUSUDES2TLEMEXETARENV_FK foreign key (IDEUSUDES)
		  references TUSU (IDEUSU)';

	EXECUTE IMMEDIATE 'alter table TLEMEXETARENV
	   add constraint TUSUREM2TLEMEXETARENV_FK foreign key (IDEUSUREM)
		  references TUSU (IDEUSU)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20171019-269', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 278');
END;
/

/* Adicionando coluna para data de recebimento do documento */
/*********************************************************/
/**********************   CASO 278  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20171211-278';

	IF lExists = 0 THEN

  
/*==============================================================*/
		
		/*==============================================================*/
		/* TABLE: TDOCLICAMB                                       		*/
		/*==============================================================*/
		EXECUTE IMMEDIATE 'ALTER TABLE TDOCLICAMB ADD DATREC DATE';
		EXECUTE IMMEDIATE 'ALTER TABLE TDOCLICAMB ADD IDEUSUANX NUMBER(13)';
		
		/*==============================================================*/
		/* Index: TUSU2TDOCLICAMB_FK                                    */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'create index TUSU2TDOCLICAMB_FK on TDOCLICAMB (
		   IDEUSUANX ASC
		)';
		
		EXECUTE IMMEDIATE 'alter table TDOCLICAMB
		   add constraint TUSU2TDOCLICAMB_FK foreign key (IDEUSUANX)
			  references TUSU (IDEUSU)';
			  
		EXECUTE IMMEDIATE 'UPDATE TDOCLICAMB SET IDEUSUANX = 1110000000000 WHERE IDEUSUANX IS NULL';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20171211-278', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 302');
END;
/

/* Criando estrutura para permitir criação de Tags */
/*********************************************************/
/*********************   CASO 302  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lOrd NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20180319-302';

	IF lExists = 0 THEN
/*==============================================================*/
		SELECT MAX(ORD) + 1 INTO lOrd
		  FROM TREGSIS
		 WHERE TIP = 1;
		 
		INSERT INTO TREGSIS (IDEREGSIS, IDEMOD, CODINT, NME, ORD, TIP, UPDTME)
			 SELECT SEQREGSIS.NEXTVAL, IDEMOD, 'Remover tags do cadastro', 'Remover tags do cadastro', lOrd, 1, SYSDATE
			   FROM TMOD
			  WHERE MODNME = 'Onegreen';

/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQCMPTAG START WITH 1110000000000 INCREMENT BY 1';

		/*==============================================================*/
		/* TABLE: TCMPTAG                                               */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE TABLE TCMPTAG  (
		   IDECMPTAG            NUMBER(13)                      NOT NULL,
		   UPDTME               DATE                            NOT NULL
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TCMPTAG
		   ADD CONSTRAINT TCMPTAG_PK PRIMARY KEY (IDECMPTAG)';
/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQTAGAMB START WITH 1110000000000 INCREMENT BY 1';

		/*==============================================================*/
		/* TABLE: TTAGAMB                                               */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE TABLE TTAGAMB  (
		   IDETAGAMB            NUMBER(13)                      NOT NULL,
		   IDEEMP               NUMBER(13),
		   NME                  VARCHAR2(100)                   NOT NULL,
		   UPDTME               DATE                            NOT NULL
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TTAGAMB
		   ADD CONSTRAINT TTAGAMB_PK PRIMARY KEY (IDETAGAMB)';

		/*==============================================================*/
		/* INDEX: TEMP2TTAGAMB_FK                                       */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TEMP2TTAGAMB_FK ON TTAGAMB (
		   IDEEMP ASC
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TTAGAMB
		   ADD CONSTRAINT TEMP2TTAGAMB_FK FOREIGN KEY (IDEEMP)
			  REFERENCES TEMP (IDEEMP)';
/*==============================================================*/	  
		/*==============================================================*/
		/* TABLE: TCMPTAGAMB                                            */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE TABLE TCMPTAGAMB  (
		   IDECMPTAG            NUMBER(13),
		   IDETAGAMB            NUMBER(13)
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TCMPTAGAMB
		   ADD CONSTRAINT TCMPTAG2TCMPTAGAMB_FK FOREIGN KEY (IDECMPTAG)
			  REFERENCES TCMPTAG (IDECMPTAG)';

		EXECUTE IMMEDIATE 'ALTER TABLE TCMPTAGAMB
		   ADD CONSTRAINT TTAGAMB2TCMPTAGAMB_FK FOREIGN KEY (IDETAGAMB)
			  REFERENCES TTAGAMB (IDETAGAMB)';
/*==============================================================*/
		/*==============================================================*/
		/* TABLE: TEPRLICAMB                                            */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'ALTER TABLE TEPRLICAMB
			ADD IDECMPTAG DECIMAL(13) NULL';
		
		/*==============================================================*/
		/* INDEX: TCMPTAG2TEPRLICAMB_FK                                 */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TCMPTAG2TEPRLICAMB_FK ON TEPRLICAMB (
		   IDECMPTAG ASC
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TEPRLICAMB
		   ADD CONSTRAINT TCMPTAG2TEPRLICAMB_FK FOREIGN KEY (IDECMPTAG)
			  REFERENCES TCMPTAG (IDECMPTAG)';
/*==============================================================*/
		/*==============================================================*/
		/* TABLE: TLICAMB                                               */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'ALTER TABLE TLICAMB
			ADD IDECMPTAG DECIMAL(13) NULL';
		
		/*==============================================================*/
		/* INDEX: TCMPTAG2TLICAMB_FK                                    */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TCMPTAG2TLICAMB_FK ON TLICAMB (
		   IDECMPTAG ASC
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TLICAMB
		   ADD CONSTRAINT TCMPTAG2TLICAMB_FK FOREIGN KEY (IDECMPTAG)
			  REFERENCES TCMPTAG (IDECMPTAG)';
/*==============================================================*/
		/*==============================================================*/
		/* TABLE: TPACTAR                                               */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'ALTER TABLE TPACTAR
			ADD IDECMPTAG DECIMAL(13) NULL';
		
		/*==============================================================*/
		/* INDEX: TCMPTAG2TPACTAR_FK                                    */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TCMPTAG2TPACTAR_FK ON TPACTAR (
		   IDECMPTAG ASC
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TPACTAR
		   ADD CONSTRAINT TCMPTAG2TPACTAR_FK FOREIGN KEY (IDECMPTAG)
			  REFERENCES TCMPTAG (IDECMPTAG)';
/*==============================================================*/
		/*==============================================================*/
		/* TABLE: TESTLICAMB                                            */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'ALTER TABLE TESTLICAMB
			ADD IDECMPTAG DECIMAL(13) NULL';
		
		/*==============================================================*/
		/* INDEX: TCMPTAG2TESTLICAMB_FK                                 */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TCMPTAG2TESTLICAMB_FK ON TESTLICAMB (
		   IDECMPTAG ASC
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TESTLICAMB
		   ADD CONSTRAINT TCMPTAG2TESTLICAMB_FK FOREIGN KEY (IDECMPTAG)
			  REFERENCES TCMPTAG (IDECMPTAG)';
/*==============================================================*/
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180319-302', SYSDATE);

		COMMIT;

	END IF;
END;
/



/*********************************************************/
/*********************** CASO 306 ************************/
/*********************************************************/

BEGIN
dbms_output.put_line('CASO 306');
END;
/

DECLARE lExists		INT;

BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20180329-306';

	IF lExists = 0 THEN
	
		EXECUTE IMMEDIATE 'ALTER TABLE TORG ADD NEWSIG NVARCHAR2(30) NULL';
		EXECUTE IMMEDIATE 'UPDATE TORG SET NEWSIG = SIG';
		EXECUTE IMMEDIATE 'ALTER TABLE TORG DROP COLUMN SIG';
		EXECUTE IMMEDIATE 'ALTER TABLE TORG ADD SIG NVARCHAR2(30) DEFAULT '' '' NOT NULL';
		EXECUTE IMMEDIATE 'UPDATE TORG SET SIG = NEWSIG';
		EXECUTE IMMEDIATE 'ALTER TABLE TORG DROP COLUMN NEWSIG';
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180329-306', SYSDATE);
		COMMIT;
	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 309');
END;
/

/* Criando permissão total para às tarefas */
/*********************************************************/
/*********************   CASO 309  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lOrd NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20180402-309';

	IF lExists = 0 THEN
/*==============================================================*/
		SELECT MAX(ORD) + 1 INTO lOrd
		  FROM TREGSIS
		 WHERE TIP = 2;
		 
		INSERT INTO TREGSIS (IDEREGSIS, IDEMOD, CODINT, NME, ORD, TIP, UPDTME)
			 SELECT SEQREGSIS.NEXTVAL, IDEMOD, 'Permissão total às tarefas_Onegreen', 'Permissão total às tarefas', lOrd, 2, SYSDATE
			   FROM TMOD
			  WHERE MODNME = 'Onegreen';
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180402-309', SYSDATE);
		COMMIT;
  
/*==============================================================*/
	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 285');
END;
/

/* Criando regra para propagação da reprogramação da Validade das Licenças para Tarefas */
/*********************************************************/
/*********************   CASO 285  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lOrd NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20180403-285';

	IF lExists = 0 THEN
/*==============================================================*/
		SELECT MAX(ORD) + 1 INTO lOrd
		  FROM TREGSIS
		 WHERE TIP = 2;
		 
		INSERT INTO TREGSIS (IDEREGSIS, IDEMOD, CODINT, NME, ORD, TIP, UPDTME)
			 SELECT SEQREGSIS.NEXTVAL, IDEMOD, 'Propagar reprogramação da Validade das Licenças para Tarefas / Condicionantes_Onegreen', 'Propagar reprogramação da Validade das Licenças para Tarefas / Condicionantes', lOrd, 2, SYSDATE
			   FROM TMOD
			  WHERE MODNME = 'Onegreen';
  
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180403-285', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 271');
END;
/

/* Atualização no usuário do Onegreen  */
/*********************************************************/
/*********************   CASO 271  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lOrd NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20180404-271';

	IF lExists = 0 THEN
/*==============================================================*/
		UPDATE TUSU SET SUPADM = 0;
		BEGIN
			UPDATE TUSU SET SUPADM = 1 WHERE UPPER(NME) = 'ONEGREEN';
		EXCEPTION 
			WHEN OTHERS THEN COMMIT;
		END;
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180404-271', SYSDATE);

		COMMIT;

	END IF;
END;
/


/*==============================================================*/
/* ATUALIZAÇÃO DA VERSÃO DO BANCO DE DADOS                      */
/*==============================================================*/
DECLARE LVERSION DATE := TO_DATE('13-04-2018', 'DD-MM-YYYY');
        DUMMY    DATE;
        FOUND    BOOLEAN;
		VERSAO 	 NVARCHAR2(10) := '1804.1';
 
    CURSOR CURSORVERSAO(CPVERSION DATE) IS
    SELECT VRS FROM TVRS WHERE VRS = LVERSION AND NUMVRS = VERSAO;
BEGIN
    OPEN  CURSORVERSAO(LVERSION);
    FETCH CURSORVERSAO INTO DUMMY;
    FOUND := CURSORVERSAO%FOUND;
    CLOSE CURSORVERSAO;
    IF FOUND THEN
        UPDATE TVRS SET DTATBL = SYSDATE WHERE VRS = LVERSION AND NUMVRS = VERSAO;
    ELSE
        INSERT INTO TVRS (VRS, DTATBL , NUMVRS) VALUES (LVERSION, SYSDATE , VERSAO);
    END IF;
END;
/

BEGIN
dbms_output.put_line('1804.1');
END;
/

