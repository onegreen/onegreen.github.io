update twkf set ideemp = 1110000000001;
commit;
/