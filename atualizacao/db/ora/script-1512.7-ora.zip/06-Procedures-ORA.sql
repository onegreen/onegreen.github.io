
CREATE OR REPLACE 
PROCEDURE CONSOLIDACAOAUTOMATICA
   IS
   pIdePlaGesAnt number(13) := 0;
   pIdePlaGesAtu number(13) := 0;
BEGIN
    BEGIN
        IF TO_NUMBER(TO_CHAR(sysdate, 'MM')) <= 4 THEN
            BEGIN
                SELECT tPlaGes.IdePlaGes into pIdePlaGesAnt
                  FROM tPlaGes
                 WHERE tPlaGes.Exr = TO_NUMBER(TO_CHAR(sysdate, 'YYYY')) - 1
                   AND tPlaGes.Atv <> 0;
            EXCEPTION WHEN no_data_found THEN
                pIdePlaGesAnt := 0;
            END;
        END IF;

        BEGIN
            SELECT tPlaGes.IdePlaGes into pIdePlaGesAtu
             FROM tPlaGes
            WHERE tPlaGes.Exr = TO_NUMBER(TO_CHAR(sysdate, 'YYYY'))
              AND tPlaGes.Atv <> 0;
        EXCEPTION WHEN no_data_found THEN
            pIdePlaGesAtu := 0;
        END;

        IF pIdePlaGesAnt <> 0 THEN
            datamining.rundatamining(pIdePlaGesAnt, '', TO_DATE('01/01/' || to_char(to_number(to_char(sysdate, 'YYYY'))-1), 'DD/MM/YYYY'), TO_DATE('31/12/' || to_char(to_number(to_char(sysdate, 'YYYY'))-1), 'DD/MM/YYYY'), NULL, NULL, NULL, '111');
        END IF;

        IF pIdePlaGesAtu <> 0 THEN
            datamining.rundatamining(pIdePlaGesAtu, '', TO_DATE('01/01/' || to_char(to_number(to_char(sysdate, 'YYYY'))), 'DD/MM/YYYY'), TO_DATE('31/12/' || to_char(to_number(to_char(sysdate, 'YYYY'))), 'DD/MM/YYYY'), NULL, NULL, NULL, '111');
        END IF;
    END;
END;
/


CREATE OR REPLACE 
PROCEDURE salvarvaloracompanhamento(pIdeAco IN NUMBER, pFre NUMBER, pTip NUMBER, pOco DATE, pRea FLOAT, pMet FLOAT, pMetInf FLOAT, pMetSup FLOAT, pValoresAtualizar INT, pIdeUsu FLOAT, pPkIdentificator VARCHAR2)
   IS
-- Procedure usada para salvamento dos valores de acompanhamento
-- com empilhamento dos indicadores salvos para futura consolida��o
-- "on-demand"
    lIdeAco                     NUMBER;
    lIdeValAco                  NUMBER;
    lMinOco                     DATE;
    lRea                        FLOAT;
    lMet                        FLOAT;
    lMetInf                     FLOAT;
    lMetSup                     FLOAT;
    lOrd                        INT;
    lVerificaFilaAtualizacao    NUMBER := 0;
    lValoresAtualizar           INT := pValoresAtualizar;
BEGIN
    BEGIN
        /* Verifica se existe o registro com informa��es sobre o acompanhamento */
        SELECT TVALACO.IDEVALACO,
               TVALACO.REA,
               TVALACO.MET,
               TVALACO.METINF,
               TVALACO.METSUP
          INTO lIdeValAco, lRea, lMet, lMetInf, lMetSup
          FROM TVALACO
         WHERE TVALACO.IDEACO = pIdeAco
           AND TVALACO.FRE = pFre
           AND TVALACO.TIP = pTip
           AND TVALACO.OCO = pOco;

        IF pValoresAtualizar = 1 OR pValoresAtualizar = 3 OR pValoresAtualizar = 5 OR pValoresAtualizar = 7 OR pValoresAtualizar = 9 OR pValoresAtualizar = 11 OR pValoresAtualizar = 13 OR pValoresAtualizar = 15 THEN
            IF NOT pRea IS NULL AND NOT lRea IS NULL THEN
                IF pRea = lRea THEN
                    lValoresAtualizar := lValoresAtualizar - 1;
                END IF;
            ELSE
                IF NOT (NOT pRea IS NULL AND lRea IS NULL OR pRea IS NULL AND NOT lRea IS NULL) THEN
                    lValoresAtualizar := lValoresAtualizar - 1;
                END IF;
            END IF;
        END IF;

        /* Verifica se ser� necess�rio atualizar os valores da Meta */
        IF pValoresAtualizar = 2 OR pValoresAtualizar = 3 OR pValoresAtualizar = 6 OR pValoresAtualizar = 7 OR pValoresAtualizar = 10 OR pValoresAtualizar = 11 OR pValoresAtualizar = 14 OR pValoresAtualizar = 15 THEN
            IF NOT pMet IS NULL AND NOT lMet IS NULL THEN
                IF pMet = lMet THEN
                    lValoresAtualizar := lValoresAtualizar - 2;
                END IF;
            ELSE
                IF NOT (NOT pMet IS NULL AND lMet IS NULL OR pMet IS NULL AND NOT lMet IS NULL) THEN
                    lValoresAtualizar := lValoresAtualizar - 2;
                END IF;
            END IF;
        END IF;

        /* Verifica se ser� necess�rio atualizar os valores do Limite Inferior */
        IF pValoresAtualizar = 4 OR pValoresAtualizar = 5 OR pValoresAtualizar = 6 OR pValoresAtualizar = 7 OR pValoresAtualizar = 12 OR pValoresAtualizar = 13 OR pValoresAtualizar = 14 OR pValoresAtualizar = 15 THEN
            IF NOT pMetInf IS NULL AND NOT lMetInf IS NULL THEN
                IF pMetInf = lMetInf THEN
                    lValoresAtualizar := lValoresAtualizar - 4;
                END IF;
            ELSE
                IF NOT (NOT pMetInf IS NULL AND lMetInf IS NULL OR pMetInf IS NULL AND NOT lMetInf IS NULL) THEN
                    lValoresAtualizar := lValoresAtualizar - 4;
                END IF;
            END IF;
        END IF;

        /* Verifica se ser� necess�rio atualizar os valores do Limite Superior */
        IF pValoresAtualizar = 8 OR pValoresAtualizar = 9 OR pValoresAtualizar = 10 OR pValoresAtualizar = 11 OR pValoresAtualizar = 12 OR pValoresAtualizar = 13 OR pValoresAtualizar = 14 OR pValoresAtualizar = 15 THEN
            IF NOT pMetSup IS NULL AND NOT lMetSup IS NULL THEN
                IF pMetSup = lMetSup THEN
                    lValoresAtualizar := lValoresAtualizar - 8;
                END IF;
            ELSE
                IF NOT (NOT pMetSup IS NULL AND lMetSup IS NULL OR pMetSup IS NULL AND NOT lMetSup IS NULL) THEN
                    lValoresAtualizar := lValoresAtualizar - 8;
                END IF;
            END IF;
        END IF;

        IF lValoresAtualizar = 1 THEN
            UPDATE TVALACO SET REA = pRea, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 2 THEN
            UPDATE TVALACO SET MET = pMet, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 3 THEN
            UPDATE TVALACO SET REA = pRea, MET = pMet, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 4 THEN
            UPDATE TVALACO SET METINF = pMetInf, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 5 THEN
            UPDATE TVALACO SET REA = pRea, METINF = pMetInf, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 6 THEN
            UPDATE TVALACO SET MET = pMet, METINF = pMetInf, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 7 THEN
            UPDATE TVALACO SET REA = pRea, MET = pMet, METINF = pMetInf, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 8 THEN
            UPDATE TVALACO SET METSUP = pMetSup, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 9 THEN
            UPDATE TVALACO SET REA = pRea, METSUP = pMetSup, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 10 THEN
            UPDATE TVALACO SET MET = pMet, METSUP = pMetSup, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 11 THEN
            UPDATE TVALACO SET REA = pRea, MET = pMet, METSUP = pMetSup, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 12 THEN
            UPDATE TVALACO SET METINF = pMetInf, METSUP = pMetSup, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 13 THEN
            UPDATE TVALACO SET REA = pRea, METINF = pMetInf, METSUP = pMetSup, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 14 THEN
            UPDATE TVALACO SET MET = pMet, METINF = pMetInf, METSUP = pMetSup, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        ELSIF lValoresAtualizar = 15 THEN
            UPDATE TVALACO SET REA = pRea, MET = pMet, METINF = pMetInf, METSUP = pMetSup, IDEUSU = pIdeUsu, UPDTME = SYSDATE WHERE IDEVALACO = lIdeValAco;
            lVerificaFilaAtualizacao := 1;
        END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        IF NOT pRea IS NULL OR NOT pMet IS NULL OR NOT pMetInf IS NULL OR NOT pMetSup IS NULL THEN
			Select seqValAco.NextVal INTO lIdeValAco FROM DUAL;
            IF lValoresAtualizar = 1 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, REA, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pRea, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 2 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, MET, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pMet, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 3 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, REA, MET, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pRea, pMet, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 4 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, METINF, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pMetInf, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 5 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, REA, METINF, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pRea, pMetInf, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 6 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, MET, METINF, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pMet, pMetInf, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 7 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, REA, MET, METINF, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pRea, pMet, pMetInf, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 8 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, METSUP, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pMetSup, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 9 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, REA, METSUP, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pRea, pMetSup, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 10 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, MET, METSUP, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pMet, pMetSup, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 11 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, REA, MET, METSUP, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pRea, pMet, pMetSup, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 12 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, METINF, METSUP, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pMetInf, pMetSup, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 13 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, REA, METINF, METSUP, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pRea, pMetInf, pMetSup, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 14 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, MET, METINF, METSUP, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pMet, pMetInf, pMetSup, pIdeUsu, SYSDATE);
            ELSIF lValoresAtualizar = 15 THEN
                INSERT INTO TVALACO (IDEVALACO, IDEACO, FRE, TIP, OCO, REA, MET, METINF, METSUP, IDEUSU, UPDTME) VALUES (lIdeValAco, pIdeAco, pFre, pTip, pOco, pRea, pMet, pMetInf, pMetSup, pIdeUsu, SYSDATE);
            END IF;

            lVerificaFilaAtualizacao := 1;
        END IF;
    END;

    IF lVerificaFilaAtualizacao <> 0 THEN
        /* Verifica se o item atualizado j� se encontra na fila de consolida��o */
        BEGIN
            SELECT IDEACO, MINOCO
              INTO lIdeAco, lMinOco
              FROM TDTAMNGLNE
             WHERE TDTAMNGLNE.IDEACO = pIdeAco
               AND TDTAMNGLNE.FRE = pFre
               AND TDTAMNGLNE.TIP = pTip
               AND STT = 0;

            IF pOco < lMinOco THEN
                UPDATE TDTAMNGLNE SET MINOCO = pOco WHERE TDTAMNGLNE.IDEACO = pIdeAco AND TDTAMNGLNE.FRE = pFre AND TDTAMNGLNE.TIP = pTip AND STT = 0;
            END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
            SELECT COUNT(IdeAco)
              INTO lOrd
              FROM tDtaMngLne
             WHERE Stt = 0;

            INSERT INTO TDTAMNGLNE (IDEACO, FRE, TIP, MINOCO, ORD, STT, UPDTME) VALUES (pIdeAco, pFre, pTip, pOco, lOrd + 1, 0, SYSDATE);
        END;
    END IF;
END;
/




/*==============================================================*/
/* ATUALIZA��O DA VERS�O DO BANCO DE DADOS                      */
/*==============================================================*/
DECLARE LVERSION DATE := TO_DATE('01-12-2015', 'DD-MM-YYYY');
        DUMMY    DATE;
        FOUND    BOOLEAN;
		VERSAO 	 NVARCHAR2(10) := '1512.1';	
 
    CURSOR CURSORVERSAO(CPVERSION DATE) IS
    SELECT VRS FROM TVRS WHERE VRS = LVERSION AND NUMVRS = VERSAO;
BEGIN
    OPEN  CURSORVERSAO(LVERSION);
    FETCH CURSORVERSAO INTO DUMMY;
    FOUND := CURSORVERSAO%FOUND;
    CLOSE CURSORVERSAO;
    IF FOUND THEN
        UPDATE TVRS SET DTAPCD = SYSDATE WHERE VRS = LVERSION AND NUMVRS = VERSAO;
    ELSE
        INSERT INTO TVRS (VRS, DTAPCD , NUMVRS) VALUES (LVERSION, SYSDATE , VERSAO);
    END IF;
END;
/

BEGIN
dbms_output.put_line('1512.1');
END;
/
