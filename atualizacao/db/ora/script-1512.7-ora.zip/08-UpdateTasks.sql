

declare lQtdeExecucoesPrev int;
        lData_Referencia date;
        lPerConclusao float;
begin

  update tpactar set fimpre = prxexcrec where prxexcrec > fimpre and frerec <> 0 and fimrea is null;
  
  FOR tar IN (SELECT TAR.IDEPACTAR, TAR.INIPRE, TAR.FIMPRE, TAR.FREREC, COUNT(LOG.IDEPACTAR) qtdeExecucoes, TAR.PRXEXCREC
                FROM TPACTAR TAR
               INNER JOIN (SELECT IDEPACTAR, TYP FROM TPACTAREXCRECLOG GROUP BY IDEPACTAR, TYP, DATPRE) LOG ON TAR.IDEPACTAR = LOG.IDEPACTAR
               WHERE TAR.FREREC <> 0 
                 and del = 0
                 AND TAR.FIMREA IS NULL
                 AND LOG.TYP = 'PortalSIM.Domain.Atividades.Execucao'
               GROUP BY TAR.IDEPACTAR, TAR.INIPRE, TAR.FIMPRE, TAR.FREREC, TAR.PRXEXCREC) LOOP
    
    lData_Referencia := tar.inipre;
    lQtdeExecucoesPrev := 0;
    
    LOOP
       EXIT WHEN lData_Referencia > tar.fimpre;
       
       lData_Referencia := CASE tar.FreRec  WHEN 1 /* Di�rio */      THEN TO_DATE(lData_Referencia) + 1 
                                            WHEN 2 /* Semanal */     THEN TO_DATE(lData_Referencia) + 7 
                                            WHEN 3 /* Quinzenal */   THEN TO_DATE(lData_Referencia) + 15 
                                            WHEN 4 /* Mensal */      THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 1) 
                                            WHEN 5 /* Bimestral */   THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 2) 
                                            WHEN 6 /* Trimestral */  THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 3) 
                                            WHEN 7 /* Quadrimestral*/THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 4) 
                                            WHEN 8 /* Semestral */   THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 6) 
                                            WHEN 9 /* Anual */       THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 12) 
                                            WHEN 10 /* Bienal */     THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 24) 
                                            WHEN 11 /* Trienal */    THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 36) 
                            END;
                            
      lQtdeExecucoesPrev := lQtdeExecucoesPrev + 1;                        
      
    END LOOP;
    
    lPerConclusao := round(tar.qtdeExecucoes / lQtdeExecucoesPrev * 100,8);
    
    if lPerConclusao > 100 then
      update tpactar set DurHra = (lQtdeExecucoesPrev * 8), PerCon = 100, fimpre = case when prxexcrec = fimpre then fimpre - 1 else fimpre end where idepactar = tar.idepactar;
    else
      update tpactar set DurHra = (lQtdeExecucoesPrev * 8), PerCon = lPerConclusao where idepactar = tar.idepactar;
    end if;
    
      
  END LOOP;
  
  commit;
end;
/

