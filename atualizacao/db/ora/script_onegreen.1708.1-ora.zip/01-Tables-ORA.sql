

/*********************************************************/
/*********************** CASO 186 ************************/
/*********************************************************/

BEGIN
dbms_output.put_line('CASO 186');
END;
/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20170130-186';

	IF lExists = 0 THEN
		
		EXECUTE IMMEDIATE 'ALTER TABLE TLICAMB ADD CSTMAN NUMBER(1) DEFAULT 0 NOT NULL';
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170130-186', SYSDATE);
		COMMIT;
	END IF;
END;
/

/*********************************************************/
/*********************** CASO 186 ************************/
/*********************************************************/

BEGIN
dbms_output.put_line('CASO 186');
END;
/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20170130-186';

	IF lExists = 0 THEN
		
		EXECUTE IMMEDIATE 'ALTER TABLE TLICAMB ADD CSTMAN NUMBER(1) DEFAULT 0 NOT NULL';
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170130-186', SYSDATE);
		COMMIT;
	END IF;
END;
/

BEGIN
	dbms_output.put_line('CASO 205');
END;
/

/* Criando Tabela de Itens do Plano da Empresa */
/*********************************************************/
/**********************   CASO 205  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20170404-205';

	IF lExists = 0 THEN

  
/*==============================================================*/
		
		/*==============================================================*/
		/* TABLE: TPLNCONITEEMP                                         */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE TABLE TPLNCONITEEMP  (
							   IDEPLNCONEMP         NUMBER(13)                      NOT NULL,
							   CHV                  VARCHAR(50)                     NOT NULL,
							   VLR                  VARCHAR(50)                     NOT NULL
							)';

		/*==============================================================*/
		/* INDEX: TPLNCONEMP2TPLNCONITEEMP_FK                        */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TPLNCONEMP2TPLNCONITEEMP_FK ON TPLNCONITEEMP (
						   IDEPLNCONEMP ASC
						)';

		EXECUTE IMMEDIATE 'ALTER TABLE TPLNCONITEEMP
			   ADD CONSTRAINT TPLNCONEMP2TPLNCONITEEMP_FK FOREIGN KEY (IDEPLNCONEMP)
				  REFERENCES TPLNCONEMP (IDEPLNCONEMP)
				  ON DELETE CASCADE';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170404-205', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 220');
END;
/

/* Adicionando coluna para possibilitar remoção de atividades dos Relatorios e Graficos */
/*********************************************************/
/**********************   CASO 220  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20170508-220';

	IF lExists = 0 THEN

  
/*==============================================================*/
		
		/*==============================================================*/
		/* TABLE: TPACTAR                                         		*/
		/*==============================================================*/
		EXECUTE IMMEDIATE 'ALTER TABLE TPACTAR ADD REMRELGRA NUMBER (1) DEFAULT 0 NOT NULL ';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170508-220', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 253');
END;
/

/*********************************************************/
/**********************   CASO 253  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20170629-253';

	IF lExists = 0 THEN

  
/*==============================================================*/
  
  FOR TAR IN (SELECT CASE WHEN ACO.IDEPLAACO = LIC.IDEPLAACONTF THEN 1 /* Notificação / Termo */
											WHEN ACO.IDEPLAACO = LIC.IDEPLAACOCMP THEN 2 /* Compensatória */
											WHEN ACO.IDEPLAACO = LIC.IDEPLAACOPRGAMB THEN 3 /* Programa Ambiental */
											WHEN ACO.IDEPLAACO = LIC.IDEPLAACOORIBAS THEN 4 /* Orientação */
											ELSE NULL END VINCULO, ACO.IDEPLAACO
								FROM TPLAACO ACO
								INNER JOIN TLICAMB LIC ON ACO.IDEPLAACO = LIC.IDEPLAACOCMP OR ACO.IDEPLAACO = LIC.IDEPLAACOPRGAMB OR ACO.IDEPLAACO = LIC.IDEPLAACONTF OR ACO.IDEPLAACO = LIC.IDEPLAACOORIBAS )
  LOOP

  	IF TAR.Vinculo = 1 THEN
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.NotificacaoDaLicenca', NME = 'Notificações / Termos de Compromisso' WHERE IDEPLAACO = TAR.IdePlaAco;
		ELSIF TAR.Vinculo = 2 THEN
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.CompensatoriaDaLicenca', NME = 'Compensatórias' WHERE IDEPLAACO = TAR.IdePlaAco;
		ELSIF TAR.Vinculo = 3 THEN
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.ProgramaAmbientalDaLicenca', NME = 'Programas Ambientais' WHERE IDEPLAACO = TAR.IdePlaAco;
		ELSIF TAR.Vinculo = 4 THEN
			UPDATE TPLAACO SET TYP = 'PortalSIM.Domain.LicenciamentoAmbiental.OrientacaoDaLicenca', NME = 'Orientações' WHERE IDEPLAACO = TAR.IdePlaAco;
		END IF;

  END LOOP;


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170629-253', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 257');
END;
/

/* Adicionando coluna para descrição do prazo da tarefa */
/*********************************************************/
/**********************   CASO 257  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20170804-257';

	IF lExists = 0 THEN

  
/*==============================================================*/
		
		/*==============================================================*/
		/* TABLE: TPACTAR                                         		*/
		/*==============================================================*/
		EXECUTE IMMEDIATE 'ALTER TABLE TPACTAR ADD PRZ NVARCHAR2(500)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20170804-257', SYSDATE);

		COMMIT;

	END IF;
END;
/



/*==============================================================*/
/* ATUALIZAÇÃO DA VERSÃO DO BANCO DE DADOS                      */
/*==============================================================*/
DECLARE LVERSION DATE := TO_DATE('07-08-2017', 'DD-MM-YYYY');
        DUMMY    DATE;
        FOUND    BOOLEAN;
		VERSAO 	 NVARCHAR2(10) := '1708.1';
 
    CURSOR CURSORVERSAO(CPVERSION DATE) IS
    SELECT VRS FROM TVRS WHERE VRS = LVERSION AND NUMVRS = VERSAO;
BEGIN
    OPEN  CURSORVERSAO(LVERSION);
    FETCH CURSORVERSAO INTO DUMMY;
    FOUND := CURSORVERSAO%FOUND;
    CLOSE CURSORVERSAO;
    IF FOUND THEN
        UPDATE TVRS SET DTATBL = SYSDATE WHERE VRS = LVERSION AND NUMVRS = VERSAO;
    ELSE
        INSERT INTO TVRS (VRS, DTATBL , NUMVRS) VALUES (LVERSION, SYSDATE , VERSAO);
    END IF;
END;
/

BEGIN
dbms_output.put_line('1708.1');
END;
/

