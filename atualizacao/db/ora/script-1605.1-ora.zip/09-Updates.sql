
UPDATE TWKFACA SET MSGCNF =  'Deseja realmente retornar esta solicita��o para elabora��o?', exgjus = 1 where idewkfatv in (

	select atv.IDEWKFATV from TWKFATV ATV 
	inner join TWKFFAS fas on atv.IDEWKFFAS = fas.IDEWKFFAS
	inner join twkf wkf on fas.IDEWKF = wkf.IDEWKF
	where upper(wkf.NME) = 'WORKFLOW DE SOLICITA��ES DO SIGMA'
)
and upper(nme) = 'RETORNAR PARA ELABORA��O';


UPDATE TWKFACA SET exgjus = 1 where idewkfatv in (

	select atv.IDEWKFATV from TWKFATV ATV 
	inner join TWKFFAS fas on atv.IDEWKFFAS = fas.IDEWKFFAS
	inner join twkf wkf on fas.IDEWKF = wkf.IDEWKF
	where upper(wkf.NME) = 'WORKFLOW DE SOLICITA��ES DO SIGMA'
)
and upper(nme) = 'CANCELAR SOLICITA��O';


UPDATE TWKFACA SET MSGCNF =  'Deseja realmente enviar para Aprova��o?' where idewkfatv in (

	select atv.IDEWKFATV from TWKFATV ATV 
	inner join TWKFFAS fas on atv.IDEWKFFAS = fas.IDEWKFFAS
	inner join twkf wkf on fas.IDEWKF = wkf.IDEWKF
	where upper(wkf.NME) = 'WORKFLOW DE SOLICITA��ES DO SIGMA'
)
and upper(nme) = 'ENVIAR PARA APROVA��O';

commit;
