

BEGIN
	dbms_output.put_line('CASO 15');
END;
/

/* Adicionando coluna de empresa na tabela de estados */
/*********************************************************/
/**********************   CASO 15  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20160218-15';

	IF lExists = 0 THEN

  
/*==============================================================*/

		EXECUTE IMMEDIATE 'ALTER TABLE TESTPRV ADD IDEEMP NUMBER(13) NULL';
		
		/*==============================================================*/
		/* INDEX: TEMP2TESTPRV_FK                                       */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TEMP2TESTPRV_FK ON TESTPRV (
		   IDEEMP ASC
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TESTPRV
		   ADD CONSTRAINT TEMP2TESTPRV_FK FOREIGN KEY (IDEEMP)
			  REFERENCES TEMP (IDEEMP)';
			  
			  
		

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160218-15', SYSDATE);

		COMMIT;

	END IF;
END;
/

DECLARE lIdeEmp INT;
BEGIN

	SELECT IDEEMP INTO lIdeEmp
	  FROM TTIPLICREGAMB
	 GROUP BY IDEEMP;

	  UPDATE TESTPRV SET IDEEMP = lIdeEmp;
	  UPDATE TWKF SET IDEEMP = lIdeEmp;
	  
	  COMMIT;

END;
/


BEGIN
	dbms_output.put_line('CASO 16');
END;
/

/* Criando Tabela de Atividades do licenciamento */
/*********************************************************/
/**********************   CASO 16  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20160218-16';

	IF lExists = 0 THEN

  
/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQATVEPRLICAMB START WITH 1110000000001 INCREMENT BY 1';
		
		/*==============================================================*/
		/* TABLE: TATVEPRLICAMB                                         */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE TABLE TATVEPRLICAMB  (
		   IDEATVEPRLICAMB      NUMBER(13)                      NOT NULL,
		   IDEEPRLICAMB         NUMBER(13),
		   IDELICAMB            NUMBER(13),
		   IDESIMFRM            NUMBER(13)                      NOT NULL,
		   IDEATVREGLICAMB      NUMBER(13)                      NOT NULL,
		   DES                  NVARCHAR2(150)                  NOT NULL,
		   UPDTME               DATE                            NOT NULL
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TATVEPRLICAMB
		   ADD CONSTRAINT PK_TATVEPRLICAMB PRIMARY KEY (IDEATVEPRLICAMB)';

		/*==============================================================*/
		/* INDEX: TATVREGLICAMB2TATVEPRLICAMB_FK                        */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TATVREGLICAMB2TATVEPRLICAMB_FK ON TATVEPRLICAMB (
		   IDEATVREGLICAMB ASC
		)';

		/*==============================================================*/
		/* INDEX: TSIMFRM2TATVEPRLICAMB_FK                              */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TSIMFRM2TATVEPRLICAMB_FK ON TATVEPRLICAMB (
		   IDESIMFRM ASC
		)';

		/*==============================================================*/
		/* INDEX: TEPRLICAMB2TATVEPRLICAMB_FK                           */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TEPRLICAMB2TATVEPRLICAMB_FK ON TATVEPRLICAMB (
		   IDEEPRLICAMB ASC
		)';

		/*==============================================================*/
		/* INDEX: TLICAMB2TATVEPRLICAMB_FK                              */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TLICAMB2TATVEPRLICAMB_FK ON TATVEPRLICAMB (
		   IDELICAMB ASC
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TATVEPRLICAMB
		   ADD CONSTRAINT TATVREGLICAMB2TATVEPRLICAMB_FK FOREIGN KEY (IDEATVREGLICAMB)
			  REFERENCES TATVREGLICAMB (IDEATVREGLICAMB)';

		EXECUTE IMMEDIATE 'ALTER TABLE TATVEPRLICAMB
		   ADD CONSTRAINT TEPRLICAMB2TATVEPRLICAMB_FK FOREIGN KEY (IDEEPRLICAMB)
			  REFERENCES TEPRLICAMB (IDEEPRLICAMB)';

		EXECUTE IMMEDIATE 'ALTER TABLE TATVEPRLICAMB
		   ADD CONSTRAINT TLICAMB2TATVEPRLICAMB_FK FOREIGN KEY (IDELICAMB)
			  REFERENCES TLICAMB (IDELICAMB)';

		EXECUTE IMMEDIATE 'ALTER TABLE TATVEPRLICAMB
		   ADD CONSTRAINT TSIMFRM2TATVEPRLICAMB_FK FOREIGN KEY (IDESIMFRM)
			  REFERENCES TSIMFRM (IDESIMFRM)';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160218-16', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 37');
END;
/

/* Adicionar campos na TTIPLICAMB para permitir Renova��o e Prazo Limite para Renova��o */
/*********************************************************/
/**********************   CASO 37  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20160218-37';

	IF lExists = 0 THEN

  
/*==============================================================*/
  
	   EXECUTE IMMEDIATE 'ALTER TABLE TTIPLICAMB ADD PMTRNV NUMBER(1) DEFAULT 1 NOT NULL';
	   
	   EXECUTE IMMEDIATE 'ALTER TABLE TTIPLICAMB ADD PRZLMTRNV INT';
	

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160218-37', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 45');
END;
/

/* Adicionar campo TLAINI na tabela TUSU para tela inicial por usu�rio */
/*********************************************************/
/**********************   CASO 45  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20160218-45';

	IF lExists = 0 THEN

  
/*==============================================================*/
  
	   EXECUTE IMMEDIATE 'ALTER TABLE TUSU ADD TLAINI NUMBER(1)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160218-45', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 73');
END;
/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20160418-73';

	IF lExists = 0 THEN

  
/*==============================================================*/
  
	   EXECUTE IMMEDIATE 'UPDATE tRegSis SET CODINT = ''Criar e alterar Projetos / Empreendimentos de Licenciamento_Onegreen'' where CODINT = ''Criar e alterar Projetos / Empreendimentos de Licenciamento_SIGMA''';
	   EXECUTE IMMEDIATE 'UPDATE tRegSis SET CODINT = ''Criar e alterar Licen�as Ambientais_Onegreen'' where CODINT = ''Criar e alterar Licen�as Ambientais_SIGMA''';
	   EXECUTE IMMEDIATE 'UPDATE tRegSis SET CODINT = ''Criar e alterar Condicionantes das Licen�as_Onegreen'' where CODINT = ''Criar e alterar Condicionantes das Licen�as_SIGMA''';
	   EXECUTE IMMEDIATE 'UPDATE tRegSis SET CODINT = ''Criar e alterar Estudos das Licen�as_Onegreen'' where CODINT = ''Criar e alterar Estudos das Licen�as_SIGMA''';
	   EXECUTE IMMEDIATE 'UPDATE tRegSis SET CODINT = ''Criar e alterar Tarefas das Licen�as_Onegreen'' where CODINT = ''Criar e alterar Tarefas das Licen�as_SIGMA''';
     EXECUTE IMMEDIATE 'UPDATE tRegSis SET CODINT = ''Aprovar solicita��es de licenciamento do Meio Ambiente_Onegreen'' where CODINT = ''Aprovar solicita��es de licenciamento do Meio Ambiente_SIGMA''';
	   EXECUTE IMMEDIATE 'UPDATE tRegSis SET CODINT = ''Excluir/Alterar Execu��es e Excluir Coment�rios de Tarefas_Onegreen'' where CODINT = ''Excluir/Alterar Execu��es e Excluir Coment�rios de Tarefas_SIGMA''';
	   EXECUTE IMMEDIATE 'UPDATE tRegSis SET CODINT = ''Desativar ou Reativar Tarefas_Onegreen'' where CODINT = ''Desativar ou Reativar Tarefas_SIGMA''';
	   
	  
/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160418-73', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 74');
END;
/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20160418-74';

	IF lExists = 0 THEN

  
/*==============================================================*/
  
	   EXECUTE IMMEDIATE 'UPDATE tlogace SET Prd = ''Onegreen'' WHERE Prd = ''Sigma''';
	  
/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160418-74', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 76');
END;
/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20160418-76';

	IF lExists = 0 THEN

  
/*==============================================================*/
  
	   UPDATE tPlaAco SET Typ = 'PortalSIM.Domain.LicenciamentoAmbiental.PlanoDeAcaoDoOnegreen' WHERE Typ = 'PortalSIM.Domain.LicenciamentoAmbiental.PlanoDeAcaoDoSigma';
	  
/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160418-76', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 78');
END;
/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20160425-78';

	IF lExists = 0 THEN

  
/*==============================================================*/
  
	   UPDATE tCfgSetIte SET Vlr = 'OnegreenRoute' where Chv = 'DefaultRoute';
	  
/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160425-78', SYSDATE);

		COMMIT;

	END IF;
END;
/


BEGIN
	dbms_output.put_line('CASO 79');
END;
/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20160427-79';

	IF lExists = 0 THEN

  
/*==============================================================*/
  
	   UPDATE tMod SET ModNme = 'Onegreen' where ModNme = 'SIGMA';
	  
/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160427-79', SYSDATE);

		COMMIT;

	END IF;
END;
/



/*********************************************************/
/*********************** CASO 102 ************************/
/*********************************************************/

BEGIN
dbms_output.put_line('CASO 102');
END;
/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20160520-102';

	IF lExists = 0 THEN

		SELECT COUNT(1) INTO lExists
		 FROM USER_TAB_COLUMNS
		WHERE UPPER (TABLE_NAME) = 'TLOGACE'
		  AND UPPER (COLUMN_NAME) = 'INPUSU';
	 
		IF lExists <> 0 THEN

				EXECUTE IMMEDIATE 'ALTER TABLE TLOGACE DROP COLUMN IDNSEC';
		
		END IF;
		
		SELECT COUNT(1) INTO lExists
		 FROM USER_TAB_COLUMNS
		WHERE UPPER (TABLE_NAME) = 'TLOGACE'
		  AND UPPER (COLUMN_NAME) = 'IDNSEC';
	 
		IF lExists <> 0 THEN

				EXECUTE IMMEDIATE 'ALTER TABLE TLOGACE DROP COLUMN IDNSEC';
		
		END IF;
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160520-102', SYSDATE);
		COMMIT;
	END IF;
END;
/



/*********************************************************/
/*********************** CASO 104 ************************/
/*********************************************************/

BEGIN
dbms_output.put_line('CASO 104');
END;
/

DECLARE lNullable VARCHAR2(1);
		lExists		INT;
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20160520-104';

	IF lExists = 0 THEN

		SELECT NULLABLE
		  INTO lNullable
		  FROM USER_TAB_COLUMNS 
		 WHERE UPPER(TABLE_NAME) = 'TATVREGLICAMB' 
		   AND UPPER(COLUMN_NAME) = 'IDEPRTLICAMB';

    IF lNullable = 'N' THEN
      EXECUTE IMMEDIATE 'ALTER TABLE TATVREGLICAMB MODIFY IDEPRTLICAMB NUMBER(13) NULL';
    END IF;
  
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160520-104', SYSDATE);
		
		COMMIT;
	END IF;
END;
/



/*********************************************************/
/*********************** CASO 109 ************************/
/*********************************************************/

BEGIN
dbms_output.put_line('CASO 109');
END;
/

DECLARE lIdeWkfAtv		NUMBER(13);
        lIdeWkfAtvNxt	NUMBER(13);
        lExists       INT;
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20160524-109';

	IF lExists = 0 THEN

		SELECT COUNT(1) INTO lExists from twkfaca where msgcnf = 'Deseja realmente reativar o projeto?';

		IF lExists = 0 THEN

			UPDATE TWKFATV SET TYP = 'PortalSIM.Domain.WorkflowFx.Tarefa' 
			 WHERE IDEWKFATV = (SELECT ATV.IDEWKFATV
								  FROM TWKFATV ATV
								 INNER JOIN TWKFFAS FAS ON FAS.IDEWKFFAS = ATV.IDEWKFFAS
								 INNER JOIN TWKF WKF ON WKF.IDEWKF = FAS.IDEWKF
								 WHERE TYPTIP = 'PortalSIM.Domain.LicenciamentoAmbiental.Empreendimento'
								   AND ATV.NME = 'Cancelamento');

			SELECT ATV.IDEWKFATV INTO lIdeWkfAtv
			  FROM TWKFATV ATV
			 INNER JOIN TWKFFAS FAS ON FAS.IDEWKFFAS = ATV.IDEWKFFAS
			 INNER JOIN TWKF WKF ON WKF.IDEWKF = FAS.IDEWKF
			 WHERE TYPTIP = 'PortalSIM.Domain.LicenciamentoAmbiental.Empreendimento'
			   AND ATV.NME = 'Cancelamento';

			SELECT ATV.IDEWKFATV INTO lIdeWkfAtvNxt
			  FROM TWKFATV ATV
			 INNER JOIN TWKFFAS FAS ON FAS.IDEWKFFAS = ATV.IDEWKFFAS
			 INNER JOIN TWKF WKF ON WKF.IDEWKF = FAS.IDEWKF
			 WHERE TYPTIP = 'PortalSIM.Domain.LicenciamentoAmbiental.Empreendimento'
			   AND ATV.NME = 'Elaborar Empreendimento';

		   
			INSERT INTO TWKFACA (IDEWKFACA, IDEWKFATV,IDEWKFATVNXT,ORD,NME,MSGCNF,ACERES,ICOLFT,ICORGT,BTNCSS,UPDTME,DES,EXGJUS,NMEEXB,RTADET,ACEVERESTVAL) 
						 VALUES (SEQWKFACA.NextVal, lIdeWkfAtv, lIdeWkfAtvNxt, 0, 'Reativar', 'Deseja realmente reativar o projeto?', NULL, 'icon-chevron-right icon-white', NULL, 'btn-danger', SYSDATE, 'Reativar', 0, NULL, NULL, 'ValidarUsuarioRequisitante');


			UPDATE TWKFACA SET RTADET = '{"Area":"Onegreen","Controller":"SolicitacoesDeLicenciamento","Action":"AoAprovarUmaSolicitacaoDeLicenciamento"}' WHERE UPPER(NME) LIKE 'APROVAR SOLICITA��O';

		END IF;
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160524-109', SYSDATE);
	
		COMMIT;
	
	END IF;
END;
/




/*********************************************************/
/*********************** CASO 111 ************************/
/*********************************************************/

BEGIN
dbms_output.put_line('CASO 111');
END;
/

DECLARE lNullable VARCHAR2(1);
		lExists		INT;
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20160525-111';

	IF lExists = 0 THEN

		select COUNT(1) INTO lExists from user_objects where upper(object_name) = 'SEQPLNCON';

		IF lExists = 0 THEN
			EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQPLNCON START WITH 1110000000001 INCREMENT BY 1';
		END IF;

		
		select COUNT(1) INTO lExists from user_objects where upper(object_name) = 'SEQPLNCONEMP';

		IF lExists = 0 THEN
			EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQPLNCONEMP START WITH 1110000000001 INCREMENT BY 1';
		END IF;
		
		select COUNT(1) INTO lExists from user_objects where upper(object_name) = 'TEMP2TPLNCONEMP_FK';

		IF lExists <> 0 THEN
			EXECUTE IMMEDIATE 'alter table TPLNCONEMP DROP constraint TEMP2TPLNCONEMP_FK';
		END IF;		
		
		EXECUTE IMMEDIATE 'alter table TPLNCONEMP
		   add constraint TEMP2TPLNCONEMP_FK foreign key (IDEEMP)
			  references TEMP (IDEEMP)
			  on delete cascade';

		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20160525-111', SYSDATE);
		
		COMMIT;
	END IF;
END;
/




								 
								
/*==============================================================*/
/* ATUALIZA��O DA VERS�O DO BANCO DE DADOS                      */
/*==============================================================*/
DECLARE LVERSION DATE := TO_DATE('13-05-2016', 'DD-MM-YYYY');
        DUMMY    DATE;
        FOUND    BOOLEAN;
		VERSAO 	 NVARCHAR2(10) := '1605.1';
 
    CURSOR CURSORVERSAO(CPVERSION DATE) IS
    SELECT VRS FROM TVRS WHERE VRS = LVERSION AND NUMVRS = VERSAO;
BEGIN
    OPEN  CURSORVERSAO(LVERSION);
    FETCH CURSORVERSAO INTO DUMMY;
    FOUND := CURSORVERSAO%FOUND;
    CLOSE CURSORVERSAO;
    IF FOUND THEN
        UPDATE TVRS SET DTATBL = SYSDATE WHERE VRS = LVERSION AND NUMVRS = VERSAO;
    ELSE
        INSERT INTO TVRS (VRS, DTATBL , NUMVRS) VALUES (LVERSION, SYSDATE , VERSAO);
    END IF;
END;
/

BEGIN
dbms_output.put_line('1512.1');
END;
/
