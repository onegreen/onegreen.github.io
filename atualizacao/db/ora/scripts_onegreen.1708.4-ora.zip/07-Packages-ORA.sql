CREATE OR REPLACE PACKAGE ATIVIDADES

IS
	TYPE tCursorType IS REF CURSOR;
	
	PROCEDURE ResumoDasTarefas 
	( 
		pRecordSet 					           OUT SYS_REFCURSOR, 
		pIdeUni						             NUMBER,
		pSub						               INT,
		pPerIni						             DATE,
		pPerFin						             DATE,
		pIdeUsu						             NUMBER,
		pIdeUsuLogado				           NUMBER,
		pIdeEprLicAmb				           NUMBER,
	  pIdeLicAmb					           NUMBER,
		pIdeLegAmb					           NUMBER,
		pIdeTipLicRegAmb		           NUMBER,
		pIdeTipLicAmb				           NUMBER,
		pExcel						             INT,
		exibirCronogramaDeProjeto	     INT,
		exibirCondicionantes		       INT,
		exibirOrientacoes			         INT,
		exibirProgramasAmbientais	     INT,
		exibirCompensatorias		       INT,
		exibirNotificacoes 			       INT,
    exibirSomenteTarefasPrincipais INT
	);
	
	PROCEDURE ResumoDasTarefasPorUsuario
	(
		pRecordSet 					           OUT SYS_REFCURSOR, 
		pIdeUni						             NUMBER,
		pSub						               INT,
		pPerIni						             DATE,
		pPerFin						             DATE,
		pIdeUsu						             NUMBER,
		pIdeUsuLogado				           NUMBER,
		pIdeEprLicAmb				           NUMBER,
	  pIdeLicAmb					           NUMBER,
		pIdeLegAmb					           NUMBER,
		pIdeTipLicRegAmb			         NUMBER,
		pIdeTipLicAmb				           NUMBER,
		pExcel						             INT,
		exibirCronogramaDeProjeto	     INT,
		exibirCondicionantes		       INT,
		exibirOrientacoes			         INT,
		exibirProgramasAmbientais	     INT,
		exibirCompensatorias		       INT,
		exibirNotificacoes 			       INT,
    exibirSomenteTarefasPrincipais INT
	);
END;
/
	
CREATE OR REPLACE PACKAGE BODY ATIVIDADES
	IS
		
		PROCEDURE ResumoDasTarefas 
		( 
			pRecordSet 					           OUT SYS_REFCURSOR, 
      pIdeUni						             NUMBER,
      pSub						               INT,
      pPerIni						             DATE,
      pPerFin						             DATE,
      pIdeUsu						             NUMBER,
      pIdeUsuLogado				           NUMBER,
      pIdeEprLicAmb				           NUMBER,
      pIdeLicAmb					           NUMBER,
      pIdeLegAmb					           NUMBER,
      pIdeTipLicRegAmb			         NUMBER,
      pIdeTipLicAmb				           NUMBER,
      pExcel						             INT,
      exibirCronogramaDeProjeto	     INT,
      exibirCondicionantes		       INT,
      exibirOrientacoes			         INT,
      exibirProgramasAmbientais	     INT,
      exibirCompensatorias		       INT,
      exibirNotificacoes 			       INT,
      exibirSomenteTarefasPrincipais INT
		)
			IS
				CursorRelatorio     			tCursorType;
				lTblTemp            			OBJECT_TMPRELSTATUS30_TABLE := OBJECT_TMPRELSTATUS30_TABLE();
				lLvl                			INT;
				lPerIni            				DATE := NULL;
				lPerFin            				DATE := NULL;

				lHoje               			VARCHAR2(50) := 'TO_DATE(''' || TO_CHAR(SYSDATE, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
				lProximoAno						VARCHAR2(50) := 'TO_DATE(''01/01/' || TO_CHAR(EXTRACT(YEAR FROM CURRENT_TIMESTAMP) + 1) || ''', ''DD/MM/YYYY'')';
				
				lStrQuery           			VARCHAR2(12000) := '';
				lCondicaoAcoes	     			VARCHAR2(1000) := '';
				lCondicaoEmpreendimentos 		VARCHAR2(1000) := '';
				lCondicaoLicencas		 		VARCHAR2(1000) := '';
				lCondicaoIdeUni    				VARCHAR2(1000) := '';

				lCalculoSubtotal    			INT := 0;

				lOrd                			INT;
				lSig                			VARCHAR2(50);
				lIdeUni             			NUMBER(13);
				lCriados            			INT;
				lPlanejadasNoPrazo  			INT;
				lPlanejadasAtrasada 			INT;
				lEmExecucaoNoPrazo  			INT;
				lEmExecucaoAtrasada 			INT;
				lFinalizadaNoPrazo  			INT;
				lFinalizadaAtrasada 			INT;

				lTotalCriados       			INT;
				lTotalPlanejadasNoPrazo  		INT;
				lTotalPlanejadasAtrasada 		INT;
				lTotalEmExecucaoNoPrazo  		INT;
				lTotalEmExecucaoAtrasada 		INT;
				lTotalFinalizadaNoPrazo  		INT;
				lTotalFinalizadaAtrasada 		INT;

				lSubTotalCriados        		INT;
				lSubTotalPlanejadasNoPrazo   	INT;
				lSubTotalPlanejadasAtrasada  	INT;
				lSubTotalEmExecucaoNoPrazo   	INT;
				lSubTotalEmExecucaoAtrasada  	INT;
				lSubTotalFinalizadaNoPrazo   	INT;
				lSubTotalFinalizadaAtrasada  	INT;
				
				BEGIN 
				
					IF pSub = 0 OR pIdeUni IS NULL THEN
						lLvl := 1;
					ELSE
						lLvl := 3;
					END IF;
					
					IF NOT pPerIni IS NULL THEN
						lPerIni := pPerIni;
					END IF;
					
					IF NOT pPerFin IS NULL THEN
						lPerFin := pPerFin;
					END IF;
					
					IF NOT pIdeEprLicAmb IS NULL THEN
						lCondicaoEmpreendimentos := lCondicaoEmpreendimentos ||
						' AND TEPRLICAMB.IDEEPRLICAMB = ' || TO_CHAR(pIdeEprLicAmb);
					END IF;
					
					IF NOT pIdeLegAmb IS NULL THEN
						lCondicaoEmpreendimentos := lCondicaoEmpreendimentos ||
							' AND TEPRLICAMB.IDELEGAMB = ' || TO_CHAR(pIdeLegAmb);
					END IF;
					
					IF NOT pIdeTipLicRegAmb IS NULL THEN
						lCondicaoEmpreendimentos := lCondicaoEmpreendimentos ||
							' AND TEPRLICAMB.IDETIPLICREGAMB = ' || TO_CHAR(pIdeTipLicRegAmb);
					END IF;
					
          IF NOT pIdeLicAmb IS NULL THEN
            lCondicaoLicencas := lCondicaoLicencas ||
							' AND VPLAACOINF.IDELICAMB = ' || TO_CHAR(pIdeLicAmb);
					END IF;
          
					IF NOT pIdeTipLicAmb IS NULL THEN
						lCondicaoLicencas := lCondicaoLicencas ||
							' AND VPLAACOINF.IDETIPLICAMB = ' || TO_CHAR(pIdeTipLicAmb);
					END IF;
					
					IF NOT pIdeUni IS NULL THEN
						lCondicaoIdeUni := ' START WITH VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
					END IF;
					
          IF exibirSomenteTarefasPrincipais = 1 THEN
            lCondicaoAcoes := lCondicaoAcoes ||
							' AND TPACTAR.REMRELGRA = 0 ';
					END IF;
					
					IF NOT pIdeUsu IS NULL THEN
						lCondicaoAcoes := lCondicaoAcoes ||
							' AND TPACTAR.IDEUSURES = ' || TO_CHAR(pIdeUsu);
					END IF;
					
					IF (pPerIni IS NOT NULL AND pPerFin IS NOT NULL) THEN
	
						lCondicaoAcoes := lCondicaoAcoes ||
							' AND 
								(	
									TPACTAR.INIPRE <= TO_DATE(''' || TO_CHAR(pPerFin, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TPACTAR.FIMPRE >=  TO_DATE(''' || TO_CHAR(pPerIni, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')
								)';
					END IF;					
					
					lStrQuery := '	SELECT	
											VUNIARV.ORD, 
											VUNIARV.SIG,
											VUNIARV.IDEUNI,
											VUNIARV.LVL,
											COUNT(VPACTAR.IDEPACTAR) Criadas,
											
											SUM
											(
												CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE >= ' || lHoje || ' THEN 
													1 
												ELSE 
													0 
												END
											) PlanejadasNoPrazo,
											
											SUM
											(
												CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE < ' || lHoje || ' THEN 
													1 
												ELSE 
													0 
												END
											) PlanejadasAtrasada,
											
											SUM
											(
												CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, SYSDATE)) <= ROUND(VPACTAR.PERCON, 2) THEN 
													1 
												ELSE 
													0 
												END
											) EmExecucaoNoPrazo,
											
											SUM
											(
												CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, SYSDATE)) > ROUND(VPACTAR.PERCON, 2) THEN 
													1 
												ELSE 
													0 
												END
											) EmExecucaoAtrasada,
											
											SUM
											(
												CASE WHEN VPACTAR.FIMREA IS NOT NULL AND TO_DATE(VPACTAR.FIMREA) <= TO_DATE(VPACTAR.FIMPRE) THEN
													1 
												ELSE 
													0 
												END
											) FinalizadaNoPrazo,
											
											SUM
											(
												CASE WHEN VPACTAR.FIMREA IS NOT NULL AND TO_DATE(VPACTAR.FIMREA) > TO_DATE(VPACTAR.FIMPRE) THEN 
													1 
												ELSE 
													0 
												END
											) FinalizadaAtrasada 
									FROM 
									(
										SELECT 	
												VUNI.IDEUNI,
												SUBSTR((RPAD('' '', (LEVEL - 1) * 3, '' '') || VUNI.SIG), 1, 50) AS SIG,
												LEVEL LVL, 
												ROWNUM ORD 
										FROM
										  TUNI VUNI
											INNER JOIN 
													(
														SELECT 
															IDEUNI 
														FROM 
															TABLE(RetornarUnidadesPorUsuario(' || TO_CHAR(pIdeUsuLogado) || '))
													) TUSUUNI 
												ON VUNI.IDEUNI = TUSUUNI.IDEUNI
										WHERE 
											VUNI.IDEUNITYP IN 
													(
														SELECT 
															TUNITYP.IDEUNITYP 
														FROM 
															TUNITYP 
														WHERE TUNITYP.TYP = 1
													)
											 AND LEVEL <= ' || TO_CHAR(lLvl)  || '
											CONNECT BY PRIOR VUNI.IDEUNI = VUNI.IDESPR ' || lCondicaoIdeUni || ' 
										) VUNIARV ';
					
					
					lStrQuery := lStrQuery || '	INNER JOIN 
												(
														SELECT 
                              NULL IDELICAMB,
															NULL IDETIPLICAMB,
															TEPRLICAMB.IDEPLAACO, 
															NULL IDEPLAACONTF, 
															NULL IDEPLAACOCMP, 
															NULL IDEPLAACOPRGAMB, 
															NULL IDEPLAACOCND, 
															NULL IDEPLAACOORIBAS, 
															IDEUNI 
														FROM TEPRLICAMB
															WHERE TEPRLICAMB.IDEUNI IS NOT NULL ' || lCondicaoEmpreendimentos || '
													UNION 
														SELECT 
                              TLICAMB.IDELICAMB,
															TLICAMB.IDETIPLICAMB,
															NULL IDEPLAACO, 
															TLICAMB.IDEPLAACONTF, 
															TLICAMB.IDEPLAACOCMP, 
															TLICAMB.IDEPLAACOPRGAMB, 
															TLICAMB.IDEPLAACOCND, 
															TLICAMB.IDEPLAACOORIBAS, 
															IDEUNI 
														FROM TLICAMB 
															INNER JOIN TEPRLICAMB ON TLICAMB.IDEEPRLICAMB = TEPRLICAMB.IDEEPRLICAMB
															' || lCondicaoEmpreendimentos || '
												) VPLAACOINF 
													ON VPLAACOINF.IDEUNI = VUNIARV.IDEUNI 
														' || lCondicaoLicencas || '
											LEFT JOIN TPLAACO 
												ON	(
														' || TO_CHAR(exibirCronogramaDeProjeto) || '  <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACO
													)
													OR
													(
														' || TO_CHAR(exibirNotificacoes) || '  <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACONTF
													)
													OR 
													(
														' || TO_CHAR(exibirCompensatorias) || ' <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOCMP	
													)
													OR 
													(
														' || TO_CHAR(exibirProgramasAmbientais) || ' <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOPRGAMB	
													)
													OR 
													(
														' || TO_CHAR(exibirOrientacoes) || ' <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOORIBAS	
													)
													OR 
													(
														' || TO_CHAR(exibirCondicionantes) || ' <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOCND	
													) ';
											
													
					lStrQuery := lStrQuery || ' LEFT JOIN 
													(
														SELECT 
															TPACTAR.IDEPLAACO, 
															TPACTAR.IDEPACTAR, 
															TPACTAR.IDEFER, 
															TPACTAR.ACAREC, 
															TPACTAR.IDEUSURES, 
															TPACTAR.INIPRE, 
															TPACTAR.INIREA, 
															TPACTAR.FIMPRE, 
															TPACTAR.FIMREA, 
															TPACTAR.PRXEXCREC, 
															TPACTAR.FREREC, 
															TPACTAR.DURHRA, 
															TPACTAR.PERCON 
														FROM 
															TPACTAR 
																LEFT JOIN TPACTARREP 
																	ON TPACTAR.IDEPACTAR = TPACTARREP.IDEPACTAR 
														WHERE 
															TPACTAR.DEL = 0 
                              AND NOT EXISTS (SELECT 1 FROM TPACTAR TAR WHERE TAR.IDEPACTARSUP = TPACTAR.IDEPACTAR) 
                              ' || lCondicaoAcoes || ' 
														GROUP BY 
															TPACTAR.IDEPACTAR, 
															TPACTAR.IDEFER, 
															TPACTAR.ACAREC, 
															TPACTAR.IDEUSURES, 
															TPACTAR.INIPRE, 
															TPACTAR.INIREA, 
															TPACTAR.FIMPRE, 
															TPACTAR.FIMREA, 
															TPACTAR.PRXEXCREC, 
															TPACTAR.IDEPLAACO, 
															TPACTAR.FREREC, 
															TPACTAR.DURHRA, 
															TPACTAR.PERCON
														) VPACTAR 
													ON TPLAACO.IDEPLAACO = VPACTAR.IDEPLAACO
										GROUP BY 
											VUNIARV.SIG, 
											VUNIARV.IDEUNI, 
											VUNIARV.ORD, 
											VUNIARV.LVL	
										ORDER BY VUNIARV.ORD
					 ';
					 
					DBMS_OUTPUT.put_line(lStrQuery);
					
					lTotalCriados 					:= 0;
					lTotalPlanejadasNoPrazo 		:= 0;
					lTotalPlanejadasAtrasada 		:= 0;
					lTotalEmExecucaoNoPrazo 		:= 0;
					lTotalEmExecucaoAtrasada 		:= 0;
					lTotalFinalizadaNoPrazo 		:= 0;
					lTotalFinalizadaAtrasada 		:= 0;
		
					lSubTotalCriados 				:= 0;
					lSubTotalPlanejadasNoPrazo 		:= 0;
					lSubTotalPlanejadasAtrasada 	:= 0;
					lSubTotalEmExecucaoNoPrazo 		:= 0;
					lSubTotalEmExecucaoAtrasada 	:= 0;
					lSubTotalFinalizadaNoPrazo 		:= 0;
					lSubTotalFinalizadaAtrasada 	:= 0;
					
					IF CursorRelatorio%ISOPEN THEN
						CLOSE CursorRelatorio;
					END IF;
					
					OPEN CursorRelatorio FOR lStrQuery;
					
					LOOP
						FETCH CursorRelatorio INTO lOrd, lSig, lIdeUni, lLvl, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada;
						EXIT WHEN CursorRelatorio%NOTFOUND;
						
						IF lLvl = 2 THEN
							IF lCalculoSubtotal = 2 AND pExcel = 0 THEN
								lTblTemp.Extend;
								lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrd + 1, '', 0, '      Subtotal', -2, 2, lSubTotalCriados, lSubTotalPlanejadasNoPrazo, lSubTotalPlanejadasAtrasada, lSubTotalEmExecucaoNoPrazo, lSubTotalEmExecucaoAtrasada, lSubTotalFinalizadaNoPrazo, lSubTotalFinalizadaAtrasada);
							END IF;

							lCalculoSubtotal := 1;  
								
							lSubTotalCriados 			:= lCriados;
							lSubTotalPlanejadasNoPrazo 	:= lPlanejadasNoPrazo;
							lSubTotalPlanejadasAtrasada := lPlanejadasAtrasada;
							lSubTotalEmExecucaoNoPrazo 	:= lEmExecucaoNoPrazo;
							lSubTotalEmExecucaoAtrasada := lEmExecucaoAtrasada;
							lSubTotalFinalizadaNoPrazo 	:= lFinalizadaNoPrazo;
							lSubTotalFinalizadaAtrasada := lFinalizadaAtrasada;
						ELSIF lLvl = 3 THEN
							lCalculoSubtotal := 2;
										
							lSubTotalCriados 			:= lSubTotalCriados + lCriados;
							lSubTotalPlanejadasNoPrazo 	:= lSubTotalPlanejadasNoPrazo + lPlanejadasNoPrazo;
							lSubTotalPlanejadasAtrasada := lSubTotalPlanejadasAtrasada + lPlanejadasAtrasada;
							lSubTotalEmExecucaoNoPrazo 	:= lSubTotalEmExecucaoNoPrazo + lEmExecucaoNoPrazo;
							lSubTotalEmExecucaoAtrasada := lSubTotalEmExecucaoAtrasada + lEmExecucaoAtrasada;
							lSubTotalFinalizadaNoPrazo 	:= lSubTotalFinalizadaNoPrazo + lFinalizadaNoPrazo;
							lSubTotalFinalizadaAtrasada := lSubTotalFinalizadaAtrasada + lFinalizadaAtrasada;
						END IF;
						
						lTotalCriados				:= lTotalCriados + lCriados;
						lTotalPlanejadasNoPrazo 	:= lTotalPlanejadasNoPrazo + lPlanejadasNoPrazo;
						lTotalPlanejadasAtrasada 	:= lTotalPlanejadasAtrasada + lPlanejadasAtrasada;
						lTotalEmExecucaoNoPrazo 	:= lTotalEmExecucaoNoPrazo + lEmExecucaoNoPrazo;
						lTotalEmExecucaoAtrasada 	:= lTotalEmExecucaoAtrasada + lEmExecucaoAtrasada;
						lTotalFinalizadaNoPrazo 	:= lTotalFinalizadaNoPrazo + lFinalizadaNoPrazo;
						lTotalFinalizadaAtrasada 	:= lTotalFinalizadaAtrasada + lFinalizadaAtrasada;

						lTblTemp.Extend;
						lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrd, '', 0, lSig, lIdeUni, 0, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada);
						
					END LOOP;
					
					IF CursorRelatorio%ISOPEN THEN
						CLOSE CursorRelatorio;
					END IF;
					
					IF (pSub <> 0) THEN
						IF lCalculoSubtotal = 2 AND pExcel = 0 THEN
							lTblTemp.Extend;
							lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrd + 1, '', 0, '      Subtotal', -2, 2, lSubTotalCriados, lSubTotalPlanejadasNoPrazo, lSubTotalPlanejadasAtrasada, lSubTotalEmExecucaoNoPrazo, lSubTotalEmExecucaoAtrasada, lSubTotalFinalizadaNoPrazo, lSubTotalFinalizadaAtrasada);
						END IF;

						lTblTemp.Extend;
						lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrd + 2, '', 0, 'Total', -1, 1, lTotalCriados, lTotalPlanejadasNoPrazo, lTotalPlanejadasAtrasada, lTotalEmExecucaoNoPrazo, lTotalEmExecucaoAtrasada, lTotalFinalizadaNoPrazo, lTotalFinalizadaAtrasada);
					END IF;
					
					OPEN pRecordset FOR
						SELECT ROWNUM Id, T.* FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELSTATUS30_TABLE)) T;
				END;
		
		PROCEDURE ResumoDasTarefasPorUsuario
		(
			pRecordSet 					           OUT SYS_REFCURSOR, 
      pIdeUni						             NUMBER,
      pSub						               INT,
      pPerIni						             DATE,
      pPerFin						             DATE,
      pIdeUsu						             NUMBER,
      pIdeUsuLogado				           NUMBER,
      pIdeEprLicAmb				           NUMBER,
      pIdeLicAmb					           NUMBER,
      pIdeLegAmb					           NUMBER,
      pIdeTipLicRegAmb			         NUMBER,
      pIdeTipLicAmb				           NUMBER,
      pExcel						             INT,
      exibirCronogramaDeProjeto	     INT,
      exibirCondicionantes		       INT,
      exibirOrientacoes			         INT,
      exibirProgramasAmbientais	     INT,
      exibirCompensatorias		       INT,
      exibirNotificacoes 			       INT,
      exibirSomenteTarefasPrincipais INT
		)
			IS
				CursorRelatorio					tCursorType;
				CursorRelatorioOrderNivel1     	tCursorType;
				CursorRelatorioOrderNivel2     	tCursorType;
				lTblTemp            			OBJECT_TMPRELSTATUS30_TABLE := OBJECT_TMPRELSTATUS30_TABLE();
				lTblTempOrder       			OBJECT_TMPRELSTATUS30_TABLE := OBJECT_TMPRELSTATUS30_TABLE();
				lLvl                			INT;
				lPerIni            				DATE := NULL;
				lPerFin            				DATE := NULL;

				lHoje               			VARCHAR2(50) := 'TO_DATE(''' || TO_CHAR(SYSDATE, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
				lProximoAno						VARCHAR2(50) := 'TO_DATE(''01/01/' || TO_CHAR(EXTRACT(YEAR FROM CURRENT_TIMESTAMP) + 1) || ''', ''DD/MM/YYYY'')';
				
				lStrQuery           			VARCHAR2(8000) := '';
				lCondicaoAcoes	     			VARCHAR2(1000) := '';
				lCondicaoEmpreendimentos 		VARCHAR2(1000) := '';
				lCondicaoLicencas		 		VARCHAR2(1000) := '';
				lCondicaoIdeUni    				VARCHAR2(1000) := '';

				lCalculoSubtotal    			INT := 0;

				lOrd                			INT;
				lSig                			VARCHAR2(50);
				lIdeUni             			NUMBER(13);
				lCriados            			INT;
				lPlanejadasNoPrazo  			INT;
				lPlanejadasAtrasada 			INT;
				lEmExecucaoNoPrazo  			INT;
				lEmExecucaoAtrasada 			INT;
				lFinalizadaNoPrazo  			INT;
				lFinalizadaAtrasada 			INT;
				
				lTotal              			INT;

				lTotalCriados       			INT;
				lTotalPlanejadasNoPrazo  		INT;
				lTotalPlanejadasAtrasada 		INT;
				lTotalEmExecucaoNoPrazo  		INT;
				lTotalEmExecucaoAtrasada 		INT;
				lTotalFinalizadaNoPrazo  		INT;
				lTotalFinalizadaAtrasada 		INT;

				lSubTotalCriados        		INT;
				lSubTotalPlanejadasNoPrazo   	INT;
				lSubTotalPlanejadasAtrasada  	INT;
				lSubTotalEmExecucaoNoPrazo   	INT;
				lSubTotalEmExecucaoAtrasada  	INT;
				lSubTotalFinalizadaNoPrazo   	INT;
				lSubTotalFinalizadaAtrasada  	INT;

				lOrdemGrupoUsuario      		INT := 1;

				lNmeUsu             			NVARCHAR2(100);
				lIdeUsu             			NUMBER(13);
				lLastNmeUsu         			VARCHAR2(100);
				lLastIdeUsu         			NUMBER(13);
				
				BEGIN
					IF pSub = 0 OR pIdeUni IS NULL THEN
						lLvl := 1;
					ELSE
						lLvl := 3;
					END IF;
					
					IF NOT pPerIni IS NULL THEN
						lPerIni := pPerIni;
					END IF;
					
					IF NOT pPerFin IS NULL THEN
						lPerFin := pPerFin;
					END IF;
					
					IF NOT pIdeEprLicAmb IS NULL THEN
						lCondicaoEmpreendimentos := lCondicaoEmpreendimentos ||
						' AND TEPRLICAMB.IDEEPRLICAMB = ' || TO_CHAR(pIdeEprLicAmb);
					END IF;
					
					IF NOT pIdeLegAmb IS NULL THEN
						lCondicaoEmpreendimentos := lCondicaoEmpreendimentos ||
							' AND TEPRLICAMB.IDELEGAMB = ' || TO_CHAR(pIdeLegAmb);
					END IF;
					
					IF NOT pIdeTipLicRegAmb IS NULL THEN
						lCondicaoEmpreendimentos := lCondicaoEmpreendimentos ||
							' AND TEPRLICAMB.IDETIPLICREGAMB = ' || TO_CHAR(pIdeTipLicRegAmb);
					END IF;
					
          IF NOT pIdeLicAmb IS NULL THEN
            lCondicaoLicencas := lCondicaoLicencas ||
							' AND VPLAACOINF.IDELICAMB = ' || TO_CHAR(pIdeLicAmb);
					END IF;
					
					IF NOT pIdeTipLicAmb IS NULL THEN
						lCondicaoLicencas := lCondicaoLicencas ||
							' AND VPLAACOINF.IDETIPLICAMB = ' || TO_CHAR(pIdeTipLicAmb);
					END IF;
					
					IF NOT pIdeUni IS NULL THEN
						lCondicaoIdeUni := ' START WITH VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
					END IF;
					
          IF exibirSomenteTarefasPrincipais = 1 THEN
            lCondicaoAcoes := lCondicaoAcoes ||
							' AND TPACTAR.REMRELGRA = 0 ';
					END IF;
          
					IF NOT pIdeUsu IS NULL THEN
						lCondicaoAcoes := lCondicaoAcoes ||
							' AND TPACTAR.IDEUSURES = ' || TO_CHAR(pIdeUsu);
					END IF;
					
					IF (pPerIni IS NOT NULL AND pPerFin IS NOT NULL) THEN
	
						lCondicaoAcoes := lCondicaoAcoes ||
							' AND 
								(	
									TPACTAR.INIPRE <= TO_DATE(''' || TO_CHAR(pPerFin, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TPACTAR.FIMPRE >=  TO_DATE(''' || TO_CHAR(pPerIni, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')
								)';
					END IF;	
				
					lStrQuery := '	SELECT
											VUNIARV.ORD,
											TUSU.NME,
											TUSU.IDEUSU,
											VUNIARV.SIG,
											VUNIARV.IDEUNI,
											VUNIARV.LVL,
											COUNT(VPACTAR.IDEPACTAR) Criadas,
											
											SUM
											(
												CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE >= ' || lHoje || ' THEN 
													1 
												ELSE 
													0 
												END
											) PlanejadasNoPrazo,
											
											SUM
											(
												CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE < ' || lHoje || ' THEN 
													1 
												ELSE 
													0 
												END
											) PlanejadasAtrasada,
											
											SUM
											(
												CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, SYSDATE)) <= ROUND(VPACTAR.PERCON, 2) THEN 
													1 
												ELSE 
													0 
												END
											) EmExecucaoNoPrazo,
											
											SUM
											(
												CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, SYSDATE)) > ROUND(VPACTAR.PERCON, 2) THEN 
													1 
												ELSE 
													0 
												END
											) EmExecucaoAtrasada,
											
											SUM
											(
												CASE WHEN VPACTAR.FIMREA IS NOT NULL AND TO_DATE(VPACTAR.FIMREA) <= TO_DATE(VPACTAR.FIMPRE) THEN 
													1 
												ELSE 
													0 
												END
											) FinalizadaNoPrazo,
											
											SUM
											(
												CASE WHEN VPACTAR.FIMREA IS NOT NULL AND TO_DATE(VPACTAR.FIMREA) > TO_DATE(VPACTAR.FIMPRE) THEN 
													1 
												ELSE 
													0 
												END
											) FinalizadaAtrasada 
									FROM
									(
										SELECT 	
												VUNI.IDEUNI,
												SUBSTR((RPAD('' '', (LEVEL - 1) * 3, '' '') || VUNI.SIG), 1, 50) AS SIG, 
												LEVEL LVL, 
												ROWNUM ORD 
										FROM
										  TUNI VUNI
											INNER JOIN 
											(
												SELECT 
													IDEUNI 
												FROM 
													TABLE
													(
														RetornarUnidadesPorUsuario(' || TO_CHAR(pIdeUsuLogado) || ')
													)
											) TUSUUNI
												ON VUNI.IDEUNI = TUSUUNI.IDEUNI
										WHERE 
											VUNI.IDEUNITYP IN 	(
																	SELECT 
																			TUNITYP.IDEUNITYP 
																	FROM 
																		TUNITYP 
																	WHERE 
																		TUNITYP.TYP = 1
																)
											AND LEVEL <= ' || TO_CHAR(lLvl) || ' 
											CONNECT BY PRIOR VUNI.IDEUNI = VUNI.IDESPR ' || lCondicaoIdeUni || ' 
									) VUNIARV ';
									
					lStrQuery := lStrQuery || '	INNER JOIN 
												(
														SELECT 
                              NULL IDELICAMB,
															NULL IDETIPLICAMB,
															TEPRLICAMB.IDEPLAACO, 
															NULL IDEPLAACONTF, 
															NULL IDEPLAACOCMP, 
															NULL IDEPLAACOPRGAMB, 
															NULL IDEPLAACOCND, 
															NULL IDEPLAACOORIBAS, 
															IDEUNI 
														FROM TEPRLICAMB
															WHERE TEPRLICAMB.IDEUNI IS NOT NULL ' || lCondicaoEmpreendimentos || '
													UNION 
														SELECT 
                              TLICAMB.IDELICAMB,
															TLICAMB.IDETIPLICAMB,
															NULL IDEPLAACO, 
															TLICAMB.IDEPLAACONTF, 
															TLICAMB.IDEPLAACOCMP, 
															TLICAMB.IDEPLAACOPRGAMB, 
															TLICAMB.IDEPLAACOCND, 
															TLICAMB.IDEPLAACOORIBAS, 
															IDEUNI 
														FROM TLICAMB 
															INNER JOIN TEPRLICAMB ON TLICAMB.IDEEPRLICAMB = TEPRLICAMB.IDEEPRLICAMB
															' || lCondicaoEmpreendimentos || '
												) VPLAACOINF 
													ON VPLAACOINF.IDEUNI = VUNIARV.IDEUNI 
														' || lCondicaoLicencas || '
											LEFT JOIN TPLAACO 
												ON	(
														' || TO_CHAR(exibirCronogramaDeProjeto) || '  <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACO
													)
													OR
													(
														' || TO_CHAR(exibirNotificacoes) || '  <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACONTF
													)
													OR 
													(
														' || TO_CHAR(exibirCompensatorias) || ' <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOCMP	
													)
													OR 
													(
														' || TO_CHAR(exibirProgramasAmbientais) || ' <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOPRGAMB	
													)
													OR 
													(
														' || TO_CHAR(exibirOrientacoes) || ' <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOORIBAS	
													)
													OR 
													(
														' || TO_CHAR(exibirCondicionantes) || ' <> 0 AND
														TPLAACO.IDEPLAACO = VPLAACOINF.IDEPLAACOCND	
													) ';
				
					
					lStrQuery := lStrQuery ||  ' INNER JOIN 
												(
													SELECT 
															TPACTAR.IDEPLAACO, 
															TPACTAR.IDEPACTAR, 
															TPACTAR.IDEFER, 
															TPACTAR.ACAREC, 
															TPACTAR.IDEUSURES, 
															TPACTAR.INIPRE, 
															TPACTAR.INIREA, 
															TPACTAR.FIMPRE, 
															TPACTAR.FIMREA, 
															TPACTAR.PRXEXCREC, 
															TPACTAR.FREREC, 
															TPACTAR.DURHRA, 
															TPACTAR.PERCON 
													FROM 
														TPACTAR 
															LEFT JOIN TPACTARREP 
																ON TPACTAR.IDEPACTAR = TPACTARREP.IDEPACTAR 
													WHERE TPACTAR.DEL = 0 
                          AND NOT EXISTS (SELECT 1 FROM TPACTAR TAR WHERE TAR.IDEPACTARSUP = TPACTAR.IDEPACTAR)
                           ' || lCondicaoAcoes || ' 
														GROUP BY 
															TPACTAR.IDEPACTAR, 
															TPACTAR.IDEFER, 
															TPACTAR.ACAREC, 
															TPACTAR.IDEUSURES, 
															TPACTAR.INIPRE, 
															TPACTAR.INIREA, 
															TPACTAR.FIMPRE, 
															TPACTAR.FIMREA, 
															TPACTAR.PRXEXCREC, 
															TPACTAR.IDEPLAACO, 
															TPACTAR.FREREC, 
															TPACTAR.DURHRA, 
															TPACTAR.PERCON 
												) VPACTAR 
													ON TPLAACO.IDEPLAACO = VPACTAR.IDEPLAACO
												INNER JOIN TUSU 
													ON VPACTAR.IDEUSURES = TUSU.IDEUSU
											GROUP BY 
												TUSU.NME, 
												VUNIARV.SIG, 
												VUNIARV.IDEUNI, 
												TUSU.IDEUSU, 
												VUNIARV.ORD, 
												VUNIARV.LVL 
											ORDER BY 
												TUSU.NME, 
												VUNIARV.SIG';
					
					lTotalCriados 				:= 0;
					lTotalPlanejadasNoPrazo 	:= 0;
					lTotalPlanejadasAtrasada 	:= 0;
					lTotalEmExecucaoNoPrazo 	:= 0;
					lTotalEmExecucaoAtrasada 	:= 0;
					lTotalFinalizadaNoPrazo 	:= 0;
					lTotalFinalizadaAtrasada 	:= 0;

					lSubTotalCriados 			:= 0;
					lSubTotalPlanejadasNoPrazo 	:= 0;
					lSubTotalPlanejadasAtrasada := 0;
					lSubTotalEmExecucaoNoPrazo 	:= 0;
					lSubTotalEmExecucaoAtrasada := 0;
					lSubTotalFinalizadaNoPrazo	:= 0;
					lSubTotalFinalizadaAtrasada := 0;

					lLastNmeUsu 				:= '0';
					lLastIdeUsu 				:= 0;

					IF CursorRelatorio%ISOPEN THEN
						CLOSE CursorRelatorio;
					END IF;
					
					OPEN CursorRelatorio FOR lStrQuery;
					LOOP
						FETCH CursorRelatorio INTO lOrd, lNmeUsu, lIdeUsu, lSig, lIdeUni, lLvl, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada;
						EXIT WHEN CursorRelatorio%NOTFOUND;
						
						IF lNmeUsu <> lLastNmeUsu AND lLastNmeUsu <> '0' AND pExcel = 0 THEN
							lTblTemp.Extend;
							lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrdemGrupoUsuario * 10000, lLastNmeUsu, lLastIdeUsu, '', 0, 0, lSubTotalCriados, lSubTotalPlanejadasNoPrazo, lSubTotalPlanejadasAtrasada, lSubTotalEmExecucaoNoPrazo, lSubTotalEmExecucaoAtrasada, lSubTotalFinalizadaNoPrazo, lSubTotalFinalizadaAtrasada);

							lSubTotalCriados 			:= 0;
							lSubTotalPlanejadasNoPrazo 	:= 0;
							lSubTotalPlanejadasAtrasada := 0;
							lSubTotalEmExecucaoNoPrazo 	:= 0;
							lSubTotalEmExecucaoAtrasada := 0;
							lSubTotalFinalizadaNoPrazo 	:= 0;
							lSubTotalFinalizadaAtrasada := 0;

							lOrdemGrupoUsuario := lOrdemGrupoUsuario + 1;
						END IF;
						lTblTemp.Extend;
						lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrdemGrupoUsuario * 10000 + lOrd, lNmeUsu, lIdeUsu, lSig, lIdeUni, 0, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada);

						lLastNmeUsu := lNmeUsu;
						lLastIdeUsu := lIdeUsu;

						lSubTotalCriados 			:= lSubTotalCriados + lCriados;
						lSubTotalPlanejadasNoPrazo 	:= lSubTotalPlanejadasNoPrazo + lPlanejadasNoPrazo;
						lSubTotalPlanejadasAtrasada := lSubTotalPlanejadasAtrasada + lPlanejadasAtrasada;
						lSubTotalEmExecucaoNoPrazo 	:= lSubTotalEmExecucaoNoPrazo + lEmExecucaoNoPrazo;
						lSubTotalEmExecucaoAtrasada := lSubTotalEmExecucaoAtrasada + lEmExecucaoAtrasada;
						lSubTotalFinalizadaNoPrazo 	:= lSubTotalFinalizadaNoPrazo + lFinalizadaNoPrazo;
						lSubTotalFinalizadaAtrasada := lSubTotalFinalizadaAtrasada + lFinalizadaAtrasada;

						lTotalCriados 				:= lTotalCriados + lCriados;
						lTotalPlanejadasNoPrazo 	:= lTotalPlanejadasNoPrazo + lPlanejadasNoPrazo;
						lTotalPlanejadasAtrasada 	:= lTotalPlanejadasAtrasada + lPlanejadasAtrasada;
						lTotalEmExecucaoNoPrazo 	:= lTotalEmExecucaoNoPrazo + lEmExecucaoNoPrazo;
						lTotalEmExecucaoAtrasada 	:= lTotalEmExecucaoAtrasada + lEmExecucaoAtrasada;
						lTotalFinalizadaNoPrazo 	:= lTotalFinalizadaNoPrazo + lFinalizadaNoPrazo;
						lTotalFinalizadaAtrasada 	:= lTotalFinalizadaAtrasada + lFinalizadaAtrasada;
					END LOOP;

					IF CursorRelatorio%ISOPEN THEN
						CLOSE CursorRelatorio;
					END IF;
					
					lTblTemp.Extend;
					lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrdemGrupoUsuario * 10000, lLastNmeUsu, lLastIdeUsu, '', 0, 0, lSubTotalCriados, lSubTotalPlanejadasNoPrazo, lSubTotalPlanejadasAtrasada, lSubTotalEmExecucaoNoPrazo, lSubTotalEmExecucaoAtrasada, lSubTotalFinalizadaNoPrazo, lSubTotalFinalizadaAtrasada);

					lOrdemGrupoUsuario := lOrdemGrupoUsuario + 1;

					lOrd := 1;

					IF CursorRelatorioOrderNivel1%ISOPEN THEN
						CLOSE CursorRelatorioOrderNivel1;
					END IF;
					
					OPEN CursorRelatorioOrderNivel1 FOR SELECT * FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELSTATUS30_TABLE)) WHERE CAST(Ord / 10000 AS INTEGER) = Ord / 10000 ORDER BY NMEUSU;
					LOOP
						FETCH CursorRelatorioOrderNivel1 INTO lOrdemGrupoUsuario, lNmeUsu, lIdeUsu, lSig, lIdeUni, lTotal, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada;
						EXIT WHEN CursorRelatorioOrderNivel1%NOTFOUND;
						
						lTblTempOrder.Extend;
						lTblTempOrder(lTblTempOrder.LAST) := OBJECT_TMPRELSTATUS30(lOrd, lNmeUsu, lIdeUsu, '', 0, 0, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada);
						lOrd := lOrd + 1;

						IF CursorRelatorioOrderNivel2%ISOPEN THEN
							CLOSE CursorRelatorioOrderNivel2;
						END IF;
						
						OPEN CursorRelatorioOrderNivel2 FOR SELECT * FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELSTATUS30_TABLE)) WHERE Ord BETWEEN lOrdemGrupoUsuario + 1 AND lOrdemGrupoUsuario + 9999 ORDER BY Criadas DESC;
						LOOP
							FETCH CursorRelatorioOrderNivel2 INTO lOrdemGrupoUsuario, lNmeUsu, lIdeUsu, lSig, lIdeUni, lTotal, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada;
							EXIT WHEN CursorRelatorioOrderNivel2%NOTFOUND;
							
							lTblTempOrder.Extend;
							lTblTempOrder(lTblTempOrder.LAST) := OBJECT_TMPRELSTATUS30(lOrd, lNmeUsu, lIdeUsu, lSig, lIdeUni, 0, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada);
							lOrd := lOrd + 1;
						END LOOP;
						
						IF CursorRelatorioOrderNivel2%ISOPEN THEN
							CLOSE CursorRelatorioOrderNivel2;
						END IF;
					END LOOP;
					
					IF CursorRelatorioOrderNivel1%ISOPEN THEN
						CLOSE CursorRelatorioOrderNivel1;
					END IF;

          lTblTempOrder.Extend;
          lTblTempOrder(lTblTempOrder.LAST) := OBJECT_TMPRELSTATUS30(lOrdemGrupoUsuario * 10000, 'Total', -1, 'Total', -1, 0, lTotalCriados, lTotalPlanejadasNoPrazo, lTotalPlanejadasAtrasada, lTotalEmExecucaoNoPrazo, lTotalEmExecucaoAtrasada, lTotalFinalizadaNoPrazo, lTotalFinalizadaAtrasada);
					
					OPEN pRecordSet FOR
						SELECT ROWNUM Id, T.* FROM TABLE (CAST(lTblTempOrder AS OBJECT_TMPRELSTATUS30_TABLE)) T ORDER BY ORD;
			END;
	END;
/


create or replace 
PACKAGE BODY integridade
IS
    FUNCTION MARCARPLAMET(pIdeAco number) RETURN  boolean IS
    BEGIN 
        if manterIntregridadeTAco then
            UPDATE TACO SET FLGPLAMET = 1, UPDTME = SYSDATE WHERE TACO.IDEACO = pIdeAco AND TACO.FLGPLAMET = 0;
        end if;
        RETURN true;
    EXCEPTION
       WHEN others THEN
       return false;
    END;

    FUNCTION MARCARSOLPRB(pIdeAco number, pFre int, pOco date) RETURN  boolean IS
    BEGIN 
        UPDATE TVALACO
           SET FLGSOLPRB = 1, 
               UPDTME = SYSDATE 
         WHERE TVALACO.IDEACO = pIdeAco 
           AND TVALACO.FRE = pFre 
           AND TVALACO.OCO = pOco 
           AND TVALACO.FLGSOLPRB = 0;
           
        RETURN true;
    EXCEPTION
       WHEN others THEN
       return false;
    END;

    FUNCTION DESMARCARVINCULOSSOLPRBACO RETURN  boolean IS
        existsSolPrbAco int;
    BEGIN 
        FOR i IN 1..mChanged_SolPrbAco.Count()
        LOOP
           select COUNT(IDESOLPRBACO) into existsSolPrbAco
             from TSOLPRBACO
            where TSOLPRBACO.IDEACO = mChanged_SolPrbAco(I).IdeAco
              and TSOLPRBACO.SHWPLAMET <> 0;

           if existsSolPrbAco = 0 AND manterIntregridadeTAco then 
                UPDATE TACO SET FLGPLAMET = 0, UPDTME = SYSDATE WHERE TACO.IDEACO = mChanged_SolPrbAco(I).IdeAco AND TACO.FLGPLAMET <> 0;
           end if;    
            
           select count(*) into existsSolPrbAco
             from TSOLPRBACO
            where TSOLPRBACO.IDEACO = mChanged_SolPrbAco(I).IdeAco
              and TSOLPRBACO.FRE = mChanged_SolPrbAco(I).Fre
              and TSOLPRBACO.OCO = mChanged_SolPrbAco(I).Oco;

           if existsSolPrbAco = 0 then
               UPDATE TVALACO
                  SET FLGSOLPRB = 0,
                      UPDTME = SYSDATE
                WHERE TVALACO.IDEACO = mChanged_SolPrbAco(I).IdeAco
                  AND TVALACO.FRE = mChanged_SolPrbAco(I).Fre 
                  AND TVALACO.OCO = mChanged_SolPrbAco(I).Oco
                  AND TVALACO.FLGSOLPRB <> 0;
           end if;
        END LOOP;
        mChanged_SolPrbAco.delete();
        
        RETURN true;
    END;
    
    FUNCTION EMPILHARSOLPRB(pIdeAco number, pFre int, pOco date) RETURN boolean IS
    BEGIN
        mChanged_SolPrbAco.extend();
        mChanged_SolPrbAco(INTEGRIDADE.mChanged_SolPrbAco.LAST).IDEACO := pIdeAco;
        mChanged_SolPrbAco(INTEGRIDADE.mChanged_SolPrbAco.LAST).FRE := pFre;
        mChanged_SolPrbAco(INTEGRIDADE.mChanged_SolPrbAco.LAST).OCO := pOco;
        
        return true;
    END;

    FUNCTION LIMPARSOLPRBACOS  RETURN boolean IS
    BEGIN
        mChanged_SolPrbAco.delete();
        
        return true;
    END;
    
    FUNCTION MARCARACOANT (pIdeAco number, pData date) RETURN boolean IS    
        lDia     DATE;
        lSem     DATE;
        lMes     DATE;
    BEGIN
     lDia := pData;
     lSem := trunc(lDia, 'DAY');
     lMes := trunc(lDia, 'MONTH');
     
     if trunc(lSem, 'YEAR') <> trunc(lDia, 'YEAR') then
         lSem := trunc(lDia, 'YEAR');
     end if;
     
     UPDATE TVALACO SET FLGANT = 1, UPDTME = SYSDATE
      WHERE IDEACO = pIdeAco
        AND FLGANT = 0
        AND ((OCO = lDia AND FRE = 3 AND FLGANT = 0)
         OR ( OCO = lSem AND FRE = 2 AND FLGANT = 0)
         OR ( OCO = lMes AND FRE = 1 AND FLGANT = 0));     
         
     return true;
    END;
    
    FUNCTION EMPILHARACOANT (pIdeAco number, pIdeAnt number) RETURN boolean IS
    BEGIN
        mChanged_AcoAnt.extend();    
        mChanged_AcoAnt(INTEGRIDADE.mChanged_AcoAnt.LAST).IDEACO := pIdeAco;
        mChanged_AcoAnt(INTEGRIDADE.mChanged_AcoAnt.LAST).IDEANT := pIdeAnt;
        return true;
    END;
    
    FUNCTION LIMPARACOANTS  RETURN boolean IS
    BEGIN
        mChanged_AcoAnt.delete();        
        return true;
    END;
    
    FUNCTION DESMARCARACOANT RETURN boolean IS
        lDia     DATE;
        lSemIni  DATE;
        lSemFim  DATE;        
        lMes     DATE;
        lExisteDia int;
        lExisteSemana int;
        lExisteMes int;
    BEGIN
        FOR i IN 1..mChanged_AcoAnt.Count()
        LOOP
 
            SELECT TANT.DAT INTO lDia
              FROM TANT
             WHERE TANT.IDEANT = mChanged_AcoAnt(I).IDEANT;             

             lSemIni := trunc(lDia, 'DAY');
             lSemFim := lSemIni + 6;
             lMes := trunc(lDia, 'MONTH');
     
            if trunc(lSemIni, 'YEAR') <> trunc(lDia, 'YEAR') then
                lSemIni := trunc(lDia, 'YEAR');
            end if;
     
            if trunc(lSemIni, 'YEAR') <> trunc(lSemFim, 'YEAR') then
                lSemFim := last_day(lMes);
            end if;              
            
            
            SELECT COUNT(*)INTO lExisteDia
              FROM TACOANT INNER JOIN TANT ON TACOANT.IDEANT = TANT.IDEANT
             WHERE TACOANT.IDEACO = mChanged_AcoAnt(I).IDEACO
               AND TACOANT.DEL = 0
               AND TANT.DAT = lDia
               AND TANT.DEL = 0;


            if lExisteDia = 0  then
                 UPDATE TVALACO SET FLGANT = 0, UPDTME = SYSDATE
                  WHERE IDEACO = mChanged_AcoAnt(I).IDEACO
                    AND OCO = lDia
                    AND FRE = 3
                    AND FLGANT <> 0;
            end if;
                                
            SELECT COUNT(*)INTO lExisteSemana
              FROM TACOANT INNER JOIN TANT ON TACOANT.IDEANT = TANT.IDEANT
             WHERE TACOANT.IDEACO = mChanged_AcoAnt(I).IDEACO
               AND TACOANT.DEL = 0
               AND TANT.DAT BETWEEN lSemIni AND lSemFim
               AND TANT.DEL = 0;

            if lExisteSemana = 0  then
                 UPDATE TVALACO SET FLGANT = 0, UPDTME = SYSDATE
                  WHERE IDEACO = mChanged_AcoAnt(I).IDEACO
                    AND OCO = lSemIni
                    AND FRE = 2
                    AND FLGANT <> 0;
            end if;

            SELECT COUNT(*)INTO lExisteMes
              FROM TACOANT INNER JOIN TANT ON TACOANT.IDEANT = TANT.IDEANT
             WHERE TACOANT.IDEACO = mChanged_AcoAnt(I).IDEACO
               AND TACOANT.DEL = 0
               AND TANT.DAT BETWEEN lMes AND last_day(lMes)
               AND TANT.DEL = 0;

            if lExisteMes = 0  then
                 UPDATE TVALACO SET FLGANT = 0, UPDTME = SYSDATE
                  WHERE IDEACO = mChanged_AcoAnt(I).IDEACO
                    AND OCO = lMes
                    AND FRE = 1
                    AND FLGANT <> 0;
            end if;        
                        
        END LOOP;

        return true;
    END;


    FUNCTION MARCARANT_PILHA RETURN boolean IS
      lReturn boolean;
    BEGIN

      FOR i IN 1..mChangedToAdd_Ant.Count()
      LOOP
  
          lReturn := MARCARANT(mChangedToAdd_Ant(I).IdeAnt, mChangedToAdd_Ant(I).DATA);
  
      END LOOP;

    return true;
    END;


    FUNCTION MARCARANT (pIdeAnt NUMBER, pData DATE) RETURN boolean IS
        lDia     DATE;
        lSem     DATE; 
        lMes     DATE;
        
    BEGIN
        lDia := pData;
        lSem := trunc(lDia, 'DAY');
        lMes := trunc(lDia, 'MONTH');

        if trunc(lSem, 'YEAR') <> trunc(lDia, 'YEAR') then
            lSem := trunc(lDia, 'YEAR');
        end if;
        
       UPDATE TVALACO SET FLGANT = 1, UPDTME = SYSDATE
        WHERE IDEACO IN (SELECT TACOANT.IDEACO FROM TACOANT WHERE TACOANT.IDEANT = pIdeAnt AND TACOANT.DEL = 0)
          AND OCO = lDia
          AND FRE = 3
          AND FLGANT = 0;


       UPDATE TVALACO SET FLGANT = 1, UPDTME = SYSDATE
        WHERE IDEACO IN (SELECT TACOANT.IDEACO FROM TACOANT WHERE TACOANT.IDEANT = pIdeAnt AND TACOANT.DEL = 0)
          AND OCO = lSem
          AND FRE = 2
          AND FLGANT = 0;

       UPDATE TVALACO SET FLGANT = 1, UPDTME = SYSDATE
        WHERE IDEACO IN (SELECT TACOANT.IDEACO FROM TACOANT WHERE TACOANT.IDEANT = pIdeAnt AND TACOANT.DEL = 0)
          AND OCO = lMes
          AND FRE = 1
          AND FLGANT = 0;
    
    return true;
    END;
    
    FUNCTION DESMARCARANT RETURN boolean IS
        lDia     DATE;
        lSemIni  DATE; 
        lSemFim  DATE; 
        lMes     DATE;
        lIdeAco  NUMBER;
        lIdeAcoAnt NUMBER;
        
        lExisteDia int;
        lExisteSemana int;
        lExisteMes int;
        
        cursor cursor_tAcoAnt(pIdeAnt number) is
           select TACOANT.IDEACOANT,
                  TACOANT.IDEACO                  
             from TACOANT
            where TACOANT.IDEANT = pIdeAnt;
    BEGIN
    FOR i IN 1..mChangedToDel_Ant.Count()
    LOOP
        lDia := mChangedToDel_Ant(I).DATA;
        lSemIni := trunc(lDia, 'DAY');
        lSemFim := lSemIni + 6;
        lMes := trunc(lDia, 'MONTH');
     
         if trunc(lSemIni, 'YEAR') <> trunc(lDia, 'YEAR') then
             lSemIni := trunc(lDia, 'YEAR');
         end if;
     
        if trunc(lSemIni, 'YEAR') <> trunc(lSemFim, 'YEAR') then
           lSemFim := last_day(lMes);
        end if;
        
        open cursor_tAcoAnt(mChangedToDel_Ant(I).IdeAnt);
        
        loop
            fetch cursor_tAcoAnt into lIdeAcoAnt, lIdeAco;
            EXIT WHEN cursor_tAcoAnt%NOTFOUND;
                        
            SELECT COUNT(*)INTO lExisteDia
              FROM TACOANT INNER JOIN TANT ON TANT.IDEANT = TACOANT.IDEANT
             WHERE TACOANT.IDEACOANT <> lIdeAcoAnt
               AND TACOANT.IDEACO = lIdeAco
               AND TACOANT.DEL = 0
               AND TANT.DAT = lDia
               AND TANT.DEL = 0;


            if lExisteDia = 0  then
                 UPDATE TVALACO SET FLGANT = 0, UPDTME = SYSDATE
                  WHERE IDEACO = lIdeAco
                    AND OCO = lDia
                    AND FRE = 3
                    AND FLGANT <> 0;
            end if;
                                
            SELECT COUNT(*)INTO lExisteSemana
              FROM TACOANT INNER JOIN TANT ON TANT.IDEANT = TACOANT.IDEANT
             WHERE TACOANT.IDEACOANT <> lIdeAcoAnt
               AND TACOANT.IDEACO = lIdeAco
               AND TACOANT.DEL = 0
               AND TANT.DAT BETWEEN lSemIni AND lSemFim
               AND TANT.DEL = 0;

            if lExisteSemana = 0  then
                 UPDATE TVALACO SET FLGANT = 0, UPDTME = SYSDATE
                  WHERE IDEACO = lIdeAco
                    AND OCO = lSemIni
                    AND FRE = 2
                    AND FLGANT <> 0;
            end if;

            SELECT COUNT(*)INTO lExisteMes
              FROM TACOANT INNER JOIN TANT ON TANT.IDEANT = TACOANT.IDEANT
             WHERE TACOANT.IDEACOANT <> lIdeAcoAnt
               AND TACOANT.IDEACO = lIdeAco
               AND TACOANT.DEL = 0             
               AND TANT.DAT BETWEEN lMes AND last_day(lMes)
               AND TANT.DEL = 0;

            if lExisteMes = 0  then
                 UPDATE TVALACO SET FLGANT = 0, UPDTME = SYSDATE
                  WHERE IDEACO = lIdeAco
                    AND OCO = lMes
                    AND FRE = 1
                    AND FLGANT <> 0;
            end if;                
        
        end loop;
        close cursor_tAcoAnt;
      end loop;  
    return true;
    END;

    FUNCTION EMPILHARANTTOADD(pIdeAnt number, pData DATE) RETURN boolean IS
    BEGIN
        mChangedToAdd_Ant.extend();    
        mChangedToAdd_Ant(mChangedToAdd_Ant.LAST).IDEANT := pIdeAnt;
        mChangedToAdd_Ant(mChangedToAdd_Ant.LAST).DATA := pData;
        return true;
    END;

    FUNCTION EMPILHARANTTODEL(pIdeAnt number, pData DATE) RETURN boolean IS
    BEGIN
        mChangedToDel_Ant.extend();    
        mChangedToDel_Ant(mChangedToDel_Ant.LAST).IDEANT := pIdeAnt;
        mChangedToDel_Ant(mChangedToDel_Ant.LAST).DATA := pData;
        return true;
    END;
    
    FUNCTION LIMPARANT RETURN boolean IS
    BEGIN
        mChangedToDel_Ant.delete();
        mChangedToAdd_Ant.delete();
        return true;        
    END;

    FUNCTION DESABILITARINTEGRIDADETACO RETURN boolean IS
    BEGIN
        manterIntregridadeTAco := false;   
        
        return manterIntregridadeTAco;
    END;

    FUNCTION HABILITARINTEGRIDADETACO RETURN boolean IS
    BEGIN
        manterIntregridadeTAco := true;
        
        return manterIntregridadeTAco;
    END;       

    
   FUNCTION MARCARVALACOSOLPRBACO (pIdeAco number, pFre integer, pOco Date) RETURN integer IS
        existsSolPrbAco integer;
   BEGIN
           --insert into tabletest (des) values ('solprb');
      SELECT COUNT(*) INTO existsSolPrbAco
        FROM TSOLPRBACO
       WHERE TSOLPRBACO.IDEACO = pIdeAco
         AND TSOLPRBACO.FRE = pFre
         AND TSOLPRBACO.OCO = pOco;
         
    if existsSolPrbAco > 0 then
        return 1;    
    else
        return 0;
    end if;
        
   END;
   
   FUNCTION MARCARVALACOACOANT (pIdeAco number, pFre integer, pOco Date) RETURN integer IS     
        lDia     DATE;
        lSemIni  DATE; 
        lSemFim  DATE; 
        lMes     DATE;
        existsAcoAnt integer;
   BEGIN
        --insert into tabletest (des) values ('acoant');
        lDia := pOco;
        lSemIni := trunc(lDia, 'DAY');
        lSemFim := lSemIni + 6;
        lMes := trunc(lDia, 'MONTH');
        existsAcoAnt := 0;
        
         if trunc(lSemIni, 'YEAR') <> trunc(lDia, 'YEAR') then
             lSemIni := trunc(lDia, 'YEAR');
         end if;
     
        if trunc(lSemIni, 'YEAR') <> trunc(lSemFim, 'YEAR') then
           lSemFim := last_day(lMes);
        end if;
        
        if pFre = 3 then    
           SELECT COUNT(*) INTO existsAcoAnt
              FROM TACOANT INNER JOIN TANT ON TANT.IDEANT = TACOANT.IDEANT
             WHERE TACOANT.IDEACO = pIdeAco
               AND TACOANT.DEL = 0
               AND TANT.DEL = 0
               AND TANT.DAT = lDia;               
        elsif pFre = 2 then    
            SELECT COUNT(*) INTO existsAcoAnt
              FROM TACOANT INNER JOIN TANT ON TANT.IDEANT = TACOANT.IDEANT
             WHERE TACOANT.IDEACO = pIdeAco
               AND TACOANT.DEL = 0
               AND TANT.DEL = 0               
               AND TANT.DAT BETWEEN lSemIni AND lSemFim;
        elsif pFre = 1 then    
            SELECT COUNT(*) INTO existsAcoAnt
              FROM TACOANT INNER JOIN TANT ON TANT.IDEANT = TACOANT.IDEANT
             WHERE TACOANT.IDEACO = pIdeAco
               AND TACOANT.DEL = 0
               AND TANT.DEL = 0               
               AND TANT.DAT BETWEEN lMes AND last_day(lMes);
        end if; 
        
        if existsAcoAnt > 0 then
            return 1;
        else
            return 0;
        end if;
   END;
   
    FUNCTION DESMARCARVINCULOSSOLPRB RETURN boolean IS
        lExisteSolPrb integer;
        lExisteShwPlaMet integer;
        lIdeSolprb number;
        lIdeAco number;
        lFre integer;
        lOco Date;
        
        cursor cursor_tSolPrbAco(pIdeSolPrb number) is
        select TSOLPRBACO.IDESOLPRB,
               TSOLPRBACO.IDEACO,
               TSOLPRBACO.FRE,
               TSOLPRBACO.OCO
          from TSOLPRBACO
         where TSOLPRBACO.IDESOLPRB = pIdeSolPrb;    
    BEGIN
    FOR i IN 1..mChanged_SolPrb.Count()
    LOOP
        open cursor_tSolPrbAco(mChanged_SolPrb(I).IdeSolPrb);        
        loop
            fetch cursor_tSolPrbAco into lIdeSolprb, lIdeAco, lFre,lOco;
            EXIT WHEN cursor_tSolPrbAco%NOTFOUND;        

            SELECT COUNT(*) INTO lExisteSolPrb
             FROM TSOLPRBACO INNER JOIN TSOLPRB ON TSOLPRB.IDESOLPRB = TSOLPRBACO.IDESOLPRB
            WHERE TSOLPRB.ETP < 90
              AND TSOLPRBACO.IDESOLPRB <> lIdeSolprb
              AND TSOLPRBACO.IDEACO = lIdeAco
              AND TSOLPRBACO.FRE = lFre
              AND TSOLPRBACO.OCO = lOco;
               
               if lExisteSolPrb = 0 then
                    UPDATE TVALACO 
                       SET FLGSOLPRB = 0
                     WHERE IDEACO = lIdeAco
                       AND FRE = lFre
                       AND OCO = lOco
                       AND FLGSOLPRB <> 0; 
               end if;
               
           SELECT COUNT(*) into lExisteShwPlaMet
             FROM TSOLPRBACO INNER JOIN TSOLPRB ON TSOLPRB.IDESOLPRB = TSOLPRBACO.IDESOLPRB
            WHERE TSOLPRB.ETP < 90
              AND TSOLPRBACO.IDESOLPRB <> lIdeSolprb
              AND TSOLPRBACO.IDEACO = lIdeAco
              AND TSOLPRBACO.SHWPLAMET <> 0;
              
                
           if lExisteShwPlaMet = 0 AND manterIntregridadeTAco then 
                UPDATE TACO SET FLGPLAMET = 0, UPDTME = SYSDATE WHERE TACO.IDEACO = lIdeAco AND TACO.FLGPLAMET <> 0;
           end if;    
            
        end loop;
    end loop;
    return false;
    END;
    
    FUNCTION MARCARVINCULOSSOLPRB (pIdeSolPrb number) RETURN boolean IS
        lIdeSolprb number;
        lIdeAco number;
        lFre integer;
        lOco Date;
        
        cursor cursor_tSolPrbAco(pIdeSolPrb number) is
        select TSOLPRBACO.IDESOLPRB,
               TSOLPRBACO.IDEACO,
               TSOLPRBACO.FRE,
               TSOLPRBACO.OCO
          from TSOLPRBACO
         where TSOLPRBACO.IDESOLPRB = pIdeSolPrb;    
    BEGIN
        open cursor_tSolPrbAco(pIdeSolPrb);        
        loop
            fetch cursor_tSolPrbAco into lIdeSolprb, lIdeAco, lFre,lOco;
            EXIT WHEN cursor_tSolPrbAco%NOTFOUND;
            
         UPDATE TVALACO 
            SET FLGSOLPRB = 1
          WHERE IDEACO = lIdeAco
            AND FRE = lFre
            AND OCO = lOco
            AND FLGSOLPRB = 0;

         if manterIntregridadeTAco then 
            UPDATE TACO SET FLGPLAMET = 1, UPDTME = SYSDATE WHERE TACO.IDEACO = lIdeAco AND TACO.FLGPLAMET = 0;
         end if;    
           
        end loop;
    return false;
    END;
    
    FUNCTION EMPILHARIDESOLPRB (pIdeSolPrb number) RETURN boolean IS
    BEGIN
        mChanged_SolPrb.extend();    
        mChanged_SolPrb(mChanged_SolPrb.LAST).IDESOLPRB := pIdeSolPrb;
    return true;
    END;
    
    FUNCTION LIMPARIDESOLPRB  RETURN boolean IS
    BEGIN
        mChanged_SolPrb.delete();
    return true;
    END;    
	
	FUNCTION VinculoDeDocumentoComIndicador (pIdeFleSys number) RETURN boolean IS
		lIdeAco  	NUMBER;
        lFlgDocVin 	NUMBER;
		
		CURSOR cursor_VinculoDeDocumentos(pIdeFleSys NUMBER) IS
		SELECT 
			TMP.IDEACO,
			TMP.FLGDOCVIN
    	FROM TACO
			INNER JOIN 
			(
				SELECT 
					TACO.IDEACO, 
					(CASE WHEN COUNT (TDOCVIN.IDEDOCVIN) > 0 THEN 1 ELSE 0 END) FLGDOCVIN
				FROM 
					TACO
						INNER JOIN TIND ON TIND.IDEIND = TACO.IDEIND
						INNER JOIN TFLESYS ON TACO.IDEFLESYS = TFLESYS.IDEFLESYS OR TIND.IDEFLESYS = TFLESYS.IDEFLESYS
						INNER JOIN TDOCVIN ON TDOCVIN.IDEFLESYS = TFLESYS.IDEFLESYS
				WHERE 
					TACO.IDEFLESYS = pIdeFleSys OR TIND.IDEFLESYS = pIdeFleSys
				GROUP BY 
					TACO.IDEACO
			) TMP ON TACO.IDEACO = TMP.IDEACO;
	BEGIN
		OPEN cursor_VinculoDeDocumentos(pIdeFleSys);
		LOOP
			FETCH cursor_VinculoDeDocumentos INTO lIdeAco, lFlgDocVin;
            EXIT WHEN cursor_VinculoDeDocumentos%NOTFOUND;
				UPDATE 
					TACO 
				SET TACO.FLGDOCVIN = lFlgDocVin
				WHERE TACO.IDEACO = lIdeAco;
		END LOOP;
		RETURN TRUE;
	END;   
       
END;
/

create or replace PACKAGE MANUTENCAO IS

PROCEDURE AdicionarUnidades(pIdeUni NUMBER, pIdeUsu NUMBER, pUpdDta INT, pIdeUniTyp NUMBER, pIdeEmp NUMBER, pSubordinadas INT);
PROCEDURE AdicionarUnidadesGruUsu(pIdeUni NUMBER, pIdeGruUsu NUMBER, pUpdDta INT, pIdeUniTyp NUMBER, pIdeEmp NUMBER, pSubordinadas INT);
PROCEDURE AddUniUsu(pIdeUni NUMBER, pIdeSpr NUMBER, pPropagarPermissaoDeAcesso INT, pIdeEmp NUMBER, pPkIdentificator VARCHAR2, pSisNme VARCHAR2);
PROCEDURE AdicionarParticipantesUnidades(pIdeUni NUMBER, pIdeUsu NUMBER, pIdeUniTyp NUMBER, pIdeEmp NUMBER, pDtaEnt DATE, pFun INT, pStt INT, pPkIdentificator VARCHAR2);
PROCEDURE AtualizaTIDS(pPkIdentificator IN VARCHAR2);
PROCEDURE GerenciarRegrasPorUsuario(pIdeUni NUMBER, pIdeUniTyp NUMBER, pIdeUsu NUMBER, pIdeRegSis NUMBER, pIdeEmp NUMBER, pSubordinadas INT, pAcesso INT);
PROCEDURE GerenciarRegrasPorGruUsu(pIdeUni NUMBER, pIdeUniTyp NUMBER, pIdeGruUsu NUMBER, pIdeRegSis NUMBER, pIdeEmp NUMBER, pSubordinadas INT, pAcesso INT);
END;
/



create or replace PACKAGE BODY MANUTENCAO IS

	PROCEDURE AdicionarUnidades(pIdeUni          NUMBER,
							    pIdeUsu          NUMBER,
							    pUpdDta          INT,
							    pIdeUniTyp       NUMBER,
							    pIdeEmp          NUMBER,
							    pSubordinadas    INT)
	AS
		lUnidadeJaExiste INT;

		CURSOR CursorUnidades(cpIdeUniTyp NUMBER,
							  cpIdeEmp    NUMBER,
							  cpIdeUsu    NUMBER) IS
		SELECT tUni.IdeUni IdeUniAce,
					   vUsuUni.IdeUni IdeUniUsu
				  FROM tUni,
					   (SELECT IdeUni FROM tUsuUni WHERE IdeUsu = cpIdeUsu) vUsuUni
				 WHERE tUni.IdeUni = vUsuUni.IdeUni (+)
				   AND tUni.IdeUniTyp = cpIdeUniTyp 
				   AND tUni.IdeEmp = cpIdeEmp;
    
				CURSOR CursorUnidadesComIdeUni( cpIdeUsu     NUMBER,
										cpIdeUni     NUMBER) IS
				   SELECT vUni.IdeUni IdeUniAce,
						  vUsuUni.IdeUni IdeUniUsu
				  FROM (SELECT IdeUni FROM tUni CONNECT BY PRIOR tUni.IdeUni = tUni.IdeSpr START WITH tUni.IdeUni = cpIdeUni) vUni,
					   (SELECT IdeUni FROM tUsuUni WHERE IdeUsu = cpIdeUsu) vUsuUni
				 WHERE vUni.IdeUni = vUsuUni.IdeUni (+);
    
		/*Todos os cursores t�m o mesmo tipo de retorno*/
		lUnidades CursorUnidades%ROWTYPE;
    
		BEGIN

			IF pIdeUni = 0 THEN
        OPEN CursorUnidades(pIdeUniTyp, pIdeEmp, pIdeUsu);
			ELSIF pSubordinadas <> 0 THEN
				OPEN CursorUnidadesComIdeUni(pIdeUsu, pIdeUni);
			END IF;

			IF pIdeUni = 0 OR (pIdeUni <> 0 AND pSubordinadas <> 0) THEN
				LOOP
					IF pIdeUni = 0 THEN
            FETCH CursorUnidades INTO lUnidades;
            EXIT WHEN CursorUnidades%NOTFOUND;     
					ELSE
						FETCH CursorUnidadesComIdeUni INTO lUnidades;
						EXIT WHEN CursorUnidadesComIdeUni%NOTFOUND;
					END IF;
                
					IF lUnidades.IdeUniUsu IS NOT NULL THEN
						UPDATE tUsuUni SET UpdDta = pUpdDta, UpdTme = SYSDATE WHERE IdeUsu = pIdeUsu AND IdeUni = lUnidades.IdeUniUsu;
					ELSE
						INSERT INTO tUsuUni(IdeUsuUni, IdeUsu, IdeUni, UpdDta, Updtme) VALUES(SeqUsuUni.NextVal, pIdeUsu, lUnidades.IdeUniAce, pUpdDta, SYSDATE);
					END IF;
        
				END LOOP;
            
				IF pIdeUni = 0 THEN
					CLOSE CursorUnidades;
				ELSIF pSubordinadas <> 0 THEN
					CLOSE CursorUnidadesComIdeUni;
				END IF;
			 ELSE
			   SELECT COUNT(1) INTO lUnidadeJaExiste FROM TUSUUNI WHERE IDEUSU = PIDEUSU AND  IDEUNI = PIDEUNI;
			   IF lUnidadeJaExiste = 0 THEN
				 INSERT INTO tUsuUni(IdeUsuUni, IdeUsu, IdeUni, UpdDta, UpdTme) VALUES(SEQUSUUNI.NEXTVAL, pIdeUsu, pIdeUni, pUpdDta, SYSDATE);
			   ELSE
				 UPDATE tUsuUni SET UpdDta = pUpdDta, UpdTme = SYSDATE WHERE IdeUsu = pIdeUsu AND IdeUni = pIdeUni;
			   END IF;
			 END IF;
		END;
    
	PROCEDURE AdicionarUnidadesGruUsu(pIdeUni          NUMBER,
									  pIdeGruUsu       NUMBER,
									  pUpdDta          INT,
									  pIdeUniTyp       NUMBER,
									  pIdeEmp          NUMBER,
									  pSubordinadas    INT)
	AS
		lUnidadeJaExiste INT;

		CURSOR CursorUnidadesGruUsu(cpIdeUniTyp NUMBER,
									cpIdeEmp    NUMBER,
									cpIdeGruUsu NUMBER) IS
				SELECT tUni.IdeUni IdeUniAce,
					   vGruUsuUni.IdeUni IdeUniGruUsu
				  FROM tUni,
					   (SELECT IdeUni FROM tGruUsuUni WHERE IdeGruUsu = cpIdeGruUsu) vGruUsuUni
				 WHERE tUni.IdeUni = vGruUsuUni.IdeUni (+)
				   AND tUni.IdeUniTyp = cpIdeUniTyp 
				   AND tUni.IdeEmp = cpIdeEmp;
    
		CURSOR CursorUnidadesComIdeUniGruUsu(cpIdeUni    NUMBER,
											 cpIdeGruUsu NUMBER) IS
				SELECT vUni.IdeUni IdeUniAce,
					   vGruUsuUni.IdeUni IdeUniGruUsu
				  FROM (SELECT IdeUni FROM tUni CONNECT BY PRIOR tUni.IdeUni = tUni.IdeSpr START WITH tUni.IdeUni = cpIdeUni) vUni,
					   (SELECT IdeUni FROM tGruUsuUni WHERE IdeGruUsu = cpIdeGruUsu) vGruUsuUni
				 WHERE vUni.IdeUni = vGruUsuUni.IdeUni (+);
    
		/*Todos os cursores t�m o mesmo tipo de retorno*/
		lUnidadesGruUsu CursorUnidadesGruUsu%ROWTYPE;
    
		BEGIN

			IF pIdeUni = 0 THEN
				OPEN CursorUnidadesGruUsu(pIdeUniTyp, pIdeEmp, pIdeGruUsu);
			ELSIF pSubordinadas <> 0 THEN
				OPEN CursorUnidadesComIdeUniGruUsu(pIdeUni, pIdeGruUsu);
			END IF;

			IF pIdeUni = 0 OR (pIdeUni <> 0 AND pSubordinadas <> 0) THEN
				LOOP
					IF pIdeUni = 0 THEN
            FETCH CursorUnidadesGruUsu INTO lUnidadesGruUsu;
            EXIT WHEN CursorUnidadesGruUsu%NOTFOUND;
					ELSE
						FETCH CursorUnidadesComIdeUniGruUsu INTO lUnidadesGruUsu;
						EXIT WHEN CursorUnidadesComIdeUniGruUsu%NOTFOUND;
					END IF;
                
					IF lUnidadesGruUsu.IdeUniGruUsu IS NOT NULL THEN
						UPDATE tGruUsuUni SET UpdDta = pUpdDta, UpdTme = SYSDATE WHERE IdeGruUsu = pIdeGruUsu AND IdeUni = lUnidadesGruUsu.IdeUniGruUsu;
					ELSE
						INSERT INTO tGruUsuUni(IdeGruUsuUni, IdeGruUsu, IdeUni, UpdDta, UpdTme) VALUES(SeqGruUsuUni.NextVal, pIdeGruUsu, lUnidadesGruUsu.IdeUniAce, pUpdDta, SYSDATE);
					END IF;
        
				END LOOP;
            
				IF pIdeUni = 0 THEN
          CLOSE CursorUnidadesGruUsu;
				ELSIF pSubordinadas <> 0 THEN
					CLOSE CursorUnidadesComIdeUniGruUsu;
				END IF;
            
			Else
				SELECT COUNT(1) INTO lUnidadeJaExiste FROM TGRUUSUUNI WHERE IDEGRUUSU = PIDEGRUUSU AND IDEUNI = PIDEUNI;
				IF LUNIDADEJAEXISTE = 0 THEN
				  INSERT INTO tGruUsuUni(IdeGruUsuUni, IdeGruUsu, IdeUni, UpdDta, UpdTme) VALUES(SeqGruUsuUni.NextVal, pIdeGruUsu, pIdeUni, pUpdDta, SYSDATE);
				END IF;  
			END IF;
		END;
    
    
	PROCEDURE AddUniUsu(pIdeUni NUMBER,
									  pIdeSpr NUMBER,
									  pPropagarPermissaoDeAcesso INT,
									  pIdeEmp NUMBER,
									  pPkIdentificator VARCHAR2,
									  pSisNme VARCHAR2)
	AS
		lContador INT;
		lUpdDta INT;

		BEGIN
    
			   SELECT COUNT(DISTINCT vUsuUni.IdeUsu) INTO lContador
				  FROM (SELECT DISTINCT tUsuSis.IdeUsu, 1 UpdDta
								  FROM tUsuSis INNER JOIN tUsu ON tUsuSis.IdeUsu = tUsu.IdeUsu 
											   INNER JOIN tSis ON tUsuSis.IdeSis = tSis.IdeSis
								 WHERE (tUsuSis.Niv = 1 AND tUsu.IdeEmp = pIdeEmp AND tSis.IntNme = pSisNme)
						UNION
						SELECT DISTINCT tUsuUni.IdeUsu, CASE WHEN tUsuUni.UpdDta = 0 THEN 0 ELSE 1 END UpdDta
								   FROM tUsuUni
							 INNER JOIN tUsu ON tUsuUni.IdeUsu = tUsu.IdeUsu
									WHERE tUsuUni.IdeUni = pIdeSpr
									  AND pSisNme = 'SIG'
								  AND pPropagarPermissaoDeAcesso = 1) vUsuUni;
    
			FOR Usuarios IN (SELECT vUsuUni.IdeUsu, MAX(vUsuUni.UpdDta) UpdDta
							  FROM (SELECT DISTINCT tUsuSis.IdeUsu, 1 UpdDta
											  FROM tUsuSis INNER JOIN tUsu ON tUsuSis.IdeUsu = tUsu.IdeUsu 
														   INNER JOIN tSis ON tUsuSis.IdeSis = tSis.IdeSis
											 WHERE (tUsuSis.Niv = 1 AND tUsu.IdeEmp = pIdeEmp AND tSis.IntNme = pSisNme)
									UNION
									SELECT DISTINCT tUsuUni.IdeUsu, CASE WHEN tUsuUni.UpdDta = 0 THEN 0 ELSE 1 END UpdDta
											   FROM tUsuUni
										 INNER JOIN tUsu ON tUsuUni.IdeUsu = tUsu.IdeUsu
												WHERE tUsuUni.IdeUni = pIdeSpr
												  AND pSisNme = 'SIG'
											  AND pPropagarPermissaoDeAcesso = 1) vUsuUni
										 GROUP BY vUsuUni.IdeUsu)
			LOOP
                INSERT INTO tUsuUni(IdeUsuUni, IdeUsu, IdeUni, UpdDta, Updtme) VALUES(SeqUsuUni.NextVal, Usuarios.IdeUsu, pIdeUni, Usuarios.UpdDta, SYSDATE);                
			END LOOP;
		COMMIT;
      
		END;
    
	PROCEDURE AdicionarParticipantesUnidades(pIdeUni          NUMBER,
											 pIdeUsu          NUMBER,
											 pIdeUniTyp       NUMBER,
											 pIdeEmp          NUMBER,
											 pDtaEnt          DATE,
											 pFun             INT,
											 pStt             INT,
											 pPkIdentificator VARCHAR2)
	AS
		lIdePar NUMBER(13);
		lCount  INT;
   
		CURSOR CursorUnidades(cpIdeUniTyp NUMBER,
							  cpIdeEmp    NUMBER) IS                          
		SELECT tUni.IdeUni
		  FROM tUni 
		  WHERE tUni.IdeUniTyp = cpIdeUniTyp 
			AND tUni.IdeEmp = cpIdeEmp;

		lUnidades CursorUnidades%ROWTYPE;
    
		BEGIN
			IF pIdeUni = 0 THEN
				OPEN CursorUnidades(pIdeUniTyp, pIdeEmp);
				LOOP
					FETCH CursorUnidades INTO lUnidades;
					EXIT WHEN CursorUnidades%NOTFOUND;

					SELECT COUNT(1) INTO lCount FROM tPar WHERE tPar.ideuni = lUnidades.IdeUni AND tPar.IdeUsu = pIdeUsu AND tPar.Fun = pFun;
					IF lCount = 0 THEN
						lIdePar := GetTableIde('tPar', 1, pPkIdentificator);
						INSERT INTO tPar(IdePar, IdeUni, IdeUsu, Fun, DatEnt, Stt, UpdTme) VALUES(lIdePar, lUnidades.IdeUni, pIdeUsu, pFun, pDtaEnt, pStt, SYSDATE);
					END IF;
					lCount := 0;
				END LOOP;
			ELSE
				SELECT COUNT(1) INTO lCount FROM tPar WHERE tPar.ideuni = pIdeUni AND tPar.IdeUsu = pIdeUsu AND tPar.Fun = pFun;
				IF lCount = 0 THEN
					lIdePar := GetTableIde('tPar', 1, pPkIdentificator);
					INSERT INTO tPar(IdePar, IdeUni, IdeUsu, Fun, DatEnt, Stt, UpdTme) VALUES(lIdePar, pIdeUni, pIdeUsu, pFun, pDtaEnt, pStt, SYSDATE);
				END IF;
			END IF;
		END;

	PROCEDURE AtualizaTIDS(pPkIdentificator IN VARCHAR2)
	IS
	/* Procedimento: AtualizaTIDS
	   Prop�sito   : Atualizar coluna NewIde da tabela tIds
	   Par�metros  : pPkIdentificator-Iniciais das Pk's que ser�o criadas
	   Cria��o     : 17/12/2009 - rangel
	   �ltima Alt. : 16/12/2010 - rangel */

		lExiste NUMBER;
		lIdeName VARCHAR2(50);
		lQuery VARCHAR2(2000);

	BEGIN
		FOR ForTable IN (SELECT UPPER(TBLNME) TBLNME FROM TIDS ORDER BY TBLNME)
		LOOP
			lIdeName := 'IDE' || SUBSTR(ForTable.TBLNME, 2, LENGTH(ForTable.TBLNME));
			SELECT COUNT(*) INTO lExiste FROM USER_TAB_COLUMNS WHERE UPPER(COLUMN_NAME) = lIdeName AND UPPER(TABLE_NAME) = ForTable.TBLNME;
			IF lExiste <> 0 THEN
				lQuery := 'DECLARE lMaxIde NUMBER(13);
							  BEGIN
								 SELECT NVL(MAX(' || lIdeName || ' )+1, 0) INTO lMaxIde FROM ' || ForTable.TBLNME || ' WHERE ' || lIdeName || ' LIKE ' || chr(39) || pPkIdentificator || '__________' || chr(39) || ';
								 IF lMaxIde <> 0 THEN
								   UPDATE TIDS
								   SET NEWIDE = lMaxIde - ' || pPkIdentificator || '0000000000
								   WHERE UPPER(TBLNME) = '|| chr(39) || ForTable.TBLNME || chr(39) ||';
								 ELSE
								   DELETE TIDS WHERE UPPER(TBLNME) = '|| chr(39) || ForTable.TBLNME || chr(39) ||';
								 END IF;
								 COMMIT;
							   END;';
				EXECUTE IMMEDIATE lQuery;
			ELSE
				DELETE TIDS WHERE TBLNME = ForTable.TBLNME;
			END IF;
		END LOOP;
	END;

	PROCEDURE GerenciarRegrasPorUsuario(pIdeUni			NUMBER,
										pIdeUniTyp		NUMBER,
										pIdeUsu			NUMBER,
										pIdeRegSis		NUMBER,
										pIdeEmp			NUMBER,
										pSubordinadas	INT,
										pAcesso			INT)
	AS

    CURSOR CursorUnidades(cpIdeUni NUMBER, cpIdeUniTyp NUMBER, cpIdeUsu NUMBER, cpIdeRegSis NUMBER, cpIdeEmp NUMBER, cpAcesso INT, cpSubordinadas INT) IS
    SELECT IdeUsuUni
	  FROM tUsuUni
	 INNER JOIN tUni ON tUsuUni.IdeUni = tUni.IdeUni
	 WHERE tUsuUni.IdeUsu = cpIdeUsu
	   AND tUni.IdeUniTyp = cpIdeUniTyp
	   AND tUni.IdeEmp = cpIdeEmp
	   AND (cpIdeUni IS NULL 
			OR ((cpSubordinadas = 0 AND tUsuUni.IdeUni = cpIdeUni ) OR (cpSubordinadas <> 0 AND tUsuUni.IdeUni IN (SELECT IdeUni
																													 FROM tUni
																												  CONNECT BY PRIOR tUni.IdeUni = tUni.IdeSpr 
																													START WITH tUni.IdeUni = cpIdeUni))))
	   AND ((cpAcesso <> 0 AND NOT EXISTS (SELECT 1 FROM tUsuUniRegSis WHERE tUsuUniRegSis.IdeRegSis = cpIdeRegSis AND tUsuUniRegSis.IdeUsuUni = tUsuUni.IdeUsuUni))
			OR
			(cpAcesso = 0 AND EXISTS (SELECT 1 FROM tUsuUniRegSis WHERE tUsuUniRegSis.IdeRegSis = cpIdeRegSis AND tUsuUniRegSis.IdeUsuUni = tUsuUni.IdeUsuUni)));
     
	lUnidades CursorUnidades%ROWTYPE;
    
    BEGIN

		OPEN CursorUnidades(pIdeUni, pIdeUniTyp, pIdeUsu, pIdeRegSis, pIdeEmp, pAcesso, pSubordinadas);
        LOOP
			FETCH CursorUnidades INTO lUnidades;
			EXIT WHEN CursorUnidades%NOTFOUND;
                
			IF pAcesso = 0 THEN
				DELETE tUsuUniRegSis where tUsuUniRegSis.IdeUsuUni = lUnidades.IdeUsuUni AND tUsuUniRegSis.IdeRegSis = pIdeRegSis;
			ELSE
				INSERT INTO tUsuUniRegSis(IdeUsuUni, IdeRegSis) values (lUnidades.IdeUsuUni, pIdeRegSis);
			END IF;
	
		END LOOP;
		
		CLOSE CursorUnidades;
		
		COMMIT;
    END;


	PROCEDURE GerenciarRegrasPorGruUsu( pIdeUni			NUMBER,
										pIdeUniTyp		NUMBER,
										pIdeGruUsu		NUMBER,
										pIdeRegSis		NUMBER,
										pIdeEmp			NUMBER,
										pSubordinadas	INT,
										pAcesso			INT)
	AS

    CURSOR CursorUnidades(cpIdeUni NUMBER, cpIdeUniTyp NUMBER, cpIdeGruUsu NUMBER, cpIdeRegSis NUMBER, cpIdeEmp NUMBER, cpAcesso INT, cpSubordinadas INT) IS
    SELECT IdeGruUsuUni
	  FROM tGruUsuUni
	 INNER JOIN tUni ON tGruUsuUni.IdeUni = tUni.IdeUni
	 WHERE tGruUsuUni.IdeGruUsu = cpIdeGruUsu
	   AND tUni.IdeUniTyp = cpIdeUniTyp
	   AND tUni.IdeEmp = cpIdeEmp
	   AND (cpIdeUni IS NULL 
			OR ((cpSubordinadas = 0 AND tGruUsuUni.IdeUni = cpIdeUni ) OR (cpSubordinadas <> 0 AND tGruUsuUni.IdeUni IN (SELECT IdeUni
																														   FROM tUni
																													    CONNECT BY PRIOR tUni.IdeUni = tUni.IdeSpr 
																														  START WITH tUni.IdeUni = cpIdeUni))))
	   AND ((cpAcesso <> 0 AND NOT EXISTS (SELECT 1 FROM tGruUsuUniRegSis WHERE tGruUsuUniRegSis.IdeRegSis = cpIdeRegSis AND tGruUsuUniRegSis.IdeGruUsuUni = tGruUsuUni.IdeGruUsuUni))
			OR
			(cpAcesso = 0 AND EXISTS (SELECT 1 FROM tGruUsuUniRegSis WHERE tGruUsuUniRegSis.IdeRegSis = cpIdeRegSis AND tGruUsuUniRegSis.IdeGruUsuUni = tGruUsuUni.IdeGruUsuUni)));
     
	lUnidades CursorUnidades%ROWTYPE;
    
    BEGIN

		OPEN CursorUnidades(pIdeUni, pIdeUniTyp, pIdeGruUsu, pIdeRegSis, pIdeEmp, pAcesso, pSubordinadas);
        LOOP
			FETCH CursorUnidades INTO lUnidades;
			EXIT WHEN CursorUnidades%NOTFOUND;
                
			IF pAcesso = 0 THEN
				DELETE tGruUsuUniRegSis where tGruUsuUniRegSis.IdeGruUsuUni = lUnidades.IdeGruUsuUni AND tGruUsuUniRegSis.IdeRegSis = pIdeRegSis;
			ELSE
				INSERT INTO tGruUsuUniRegSis(IdeGruUsuUni, IdeRegSis) values (lUnidades.IdeGruUsuUni, pIdeRegSis);
			END IF;
	
		END LOOP;
		
		CLOSE CursorUnidades;
		
		COMMIT;
    END;



END;
/


create or replace
PACKAGE ONEGREEN
IS
    FUNCTION RelCumprimentoAcoes(pDatIni DATE, pDatFim DATE, pIdeEmp NUMBER, pIdeUni NUMBER, pSub3Niv INT, pTipoRelacionamento VARCHAR2, pTipoPrimitivoLicenca INT, pTipoLicencaAmbiental INT, pIdeTipLicAmb NUMBER, pTipoEndereco INT, pIdeEnd NUMBER, pIdeTipLegAmb NUMBER, pIdeTipLicRegAmb NUMBER, pIdeUsu NUMBER, pAgendamentoFuturo INT, pIdeEprLicAmb NUMBER, pSomenteTarefasPrincipais INT) RETURN Object_CumprimentoAcoes_Table;
	FUNCTION RetornarFarolImpOpe(pIdeEprLicAmb NUMBER, pIdeClsLicAmb NUMBER, pDatIniImp DATE, pDatIniOpe DATE) RETURN Object_FarolImpOpe_Table;
END;
/

create or replace
PACKAGE BODY ONEGREEN
IS

FUNCTION RelCumprimentoAcoes(pDatIni DATE, pDatFim DATE, pIdeEmp NUMBER, pIdeUni NUMBER, pSub3Niv INT, pTipoRelacionamento VARCHAR2, pTipoPrimitivoLicenca INT, pTipoLicencaAmbiental INT, pIdeTipLicAmb NUMBER, pTipoEndereco INT, pIdeEnd NUMBER, pIdeTipLegAmb NUMBER, pIdeTipLicRegAmb NUMBER, pIdeUsu NUMBER, pAgendamentoFuturo INT, pIdeEprLicAmb NUMBER, pSomenteTarefasPrincipais INT)
      RETURN Object_CumprimentoAcoes_Table
    AS

    lData_Referencia    DATE;
    lData_Prevista      DATE;
    lData_Realizada     DATE;
    lExists             INT;

    /* Condicionantes de um projeto no Onegreen */
    CURSOR CursorAcoes(cpDatIni DATE, cpDatFim DATE, cpIdeEmp NUMBER, cpIdeUni NUMBER, cpSub3Niv INT) IS
    SELECT MAX(LOG.IDEPACTAREXCRECLOG) IDEPACTAREXCRECLOG, UNI.IDEUNI, AMB.IDELICAMB IDEVIN, PLA.IDEPLAACO, TAR.IDEPACTAR, TAR.INIPRE, TAR.FIMPRE, TAR.FIMREA, TAR.PRXEXCREC, TAR.FREREC, COALESCE(MAX(LOG.DATPRE), TAR.INIPRE) MAXDATPRE
      FROM TPACTAR TAR
     INNER JOIN TPLAACO PLA ON PLA.IDEPLAACO =  TAR.IDEPLAACO
     INNER JOIN TLICAMB AMB ON ((PLA.IDEPLAACO = AMB.IDEPLAACOCND AND UPPER(pTipoRelacionamento) = 'CONDICIONANTES') OR 
												   (PLA.IDEPLAACO = AMB.IDEPLAACOCMP AND UPPER(pTipoRelacionamento) = 'COMPENSATORIAS') OR 
												   (PLA.IDEPLAACO = AMB.IDEPLAACONTF AND UPPER(pTipoRelacionamento) = 'NOTIFICACOESTERMOSDECOMPRIMISSO') OR 
												   (PLA.IDEPLAACO = AMB.IDEPLAACOORIBAS AND UPPER(pTipoRelacionamento) = 'ORIENTACOES') OR 
												   (PLA.IDEPLAACO = AMB.IDEPLAACOPRGAMB AND UPPER(pTipoRelacionamento) = 'PROGRAMASAMBIENTAIS'))
     INNER JOIN TEPRLICAMB EPR ON AMB.IDEEPRLICAMB = EPR.IDEEPRLICAMB 
     INNER JOIN TUNI UNI ON EPR.IDEUNI = UNI.IDEUNI
     INNER JOIN TTIPLICAMB ON TTIPLICAMB.IDETIPLICAMB = AMB.IDETIPLICAMB
     INNER JOIN TTIPLICREGAMB ON TTIPLICREGAMB.IDETIPLICREGAMB = EPR.IDETIPLICREGAMB
      LEFT JOIN TEPRLICAMBEND EPREND ON (EPREND.IDEEPRLICAMB = EPR.IDEEPRLICAMB AND EPREND.TIPEPRLICAMBEND = pTipoEndereco)
      LEFT JOIN TPACTAREXCRECLOG LOG ON TAR.IDEPACTAR =  LOG.IDEPACTAR AND LOG.TYP = 'PortalSIM.Domain.Atividades.Execucao'
     WHERE UNI.IDEEMP = cpIdeEmp
     AND (pIdeTipLicAmb IS NULL OR TTIPLICAMB.IDETIPLICAMB = pIdeTipLicAmb)
     AND (pIdeTipLegAmb IS NULL OR TTIPLICREGAMB.IdeLegAmb = pIdeTipLegAmb)
     AND (pIdeEnd IS NULL OR pIdeEnd = EPREND.IDEEND)
     AND (pIdeTipLicRegAmb IS NULL OR pIdeTipLicRegAmb = TTIPLICREGAMB.IDETIPLICREGAMB)
	 AND (pIdeEprLicAmb    IS NULL OR pIdeEprLicAmb    = EPR.IDEEPRLICAMB)
     AND (pIdeUsu IS NULL OR pIdeUsu = TAR.IDEUSURES)
	 AND (pTipoPrimitivoLicenca IS NULL OR TTIPLICAMB.TIP = pTipoPrimitivoLicenca)
	 AND (pTipoLicencaAmbiental IS NULL OR TTIPLICAMB.TIPLIC = pTipoLicencaAmbiental)
	 AND (pAgendamentoFuturo = 0 OR TAR.FIMREA IS NULL)
     AND AMB.Stt <> 4 /* Indeferida */
     AND AMB.Stt <> 5 /* Cancelada */
     AND TAR.Del = 0
     AND (pSomenteTarefasPrincipais = 0 OR TAR.REMRELGRA = 0)
       AND (cpIdeUni IS NULL
            OR ( (cpSub3Niv = 0 AND EPR.IdeUni = cpIdeUni) 
                 OR (cpSub3Niv <> 0 and EPR.IdeUni IN (SELECT tUni.IdeUni
                                     FROM tUni
                                    WHERE tUni.IdeUniTyp IN (SELECT tUniTyp.IdeUniTyp FROM tUniTyp WHERE tUniTyp.Typ = 1)
                                      AND Level <= 3
                                  CONNECT BY PRIOR tUni.IdeUni = tUni.IdeSpr
                                    START WITH tUni.IdeUni = cpIdeUni))))
       AND (   (TAR.FREREC = 0 AND TAR.FIMPRE BETWEEN cpDatIni AND cpDatFim)
            OR (TAR.FREREC <> 0 AND TAR.INIPRE IS NOT NULL  AND ((TAR.INIPRE BETWEEN cpDatIni AND cpDatFim) 
                                                             OR (TAR.FIMPRE BETWEEN cpDatIni AND cpDatFim) 

                                                             OR (TAR.INIPRE < CPDATINI AND TAR.FIMPRE > CPDATFIM)
                                                             OR EXISTS (SELECT 1 FROM TPACTAREXCRECLOG WHERE DATPRE BETWEEN cpDatIni AND cpDatFim AND TAR.IDEPACTAR = TPACTAREXCRECLOG.IDEPACTAR and rownum = 1)
                                                             )))
                                                             
     GROUP BY UNI.IDEUNI, AMB.IDELICAMB, PLA.IDEPLAACO, TAR.IDEPACTAR, TAR.INIPRE, TAR.FIMPRE, TAR.FIMREA, TAR.PRXEXCREC, TAR.FREREC
     ORDER BY TAR.FREREC, TAR.IDEPACTAR, TAR.FIMPRE;


    CURSOR CursorCronogramaDoProjeto(cpDatIni DATE, cpDatFim DATE, cpIdeEmp NUMBER, cpIdeUni NUMBER, cpSub3Niv INT) IS
    SELECT MAX(LOG.IDEPACTAREXCRECLOG) IDEPACTAREXCRECLOG, UNI.IDEUNI, 0 IDEVIN, PLA.IDEPLAACO, TAR.IDEPACTAR, TAR.INIPRE, TAR.FIMPRE, TAR.FIMREA, TAR.PRXEXCREC, TAR.FREREC, COALESCE(MAX(LOG.DATPRE), TAR.INIPRE) MAXDATPRE
      FROM TEPRLICAMB EPR
             INNER JOIN TPLAACO PLA ON PLA.IDEPLAACO =  EPR.IDEPLAACO
			 INNER JOIN TPACTAR TAR ON PLA.IDEPLAACO =  TAR.IDEPLAACO
             INNER JOIN TUNI UNI ON EPR.IDEUNI = UNI.IDEUNI
             INNER JOIN TTIPLICREGAMB ON TTIPLICREGAMB.IDETIPLICREGAMB = EPR.IDETIPLICREGAMB
      LEFT JOIN TEPRLICAMBEND EPREND ON (EPREND.IDEEPRLICAMB = EPR.IDEEPRLICAMB AND EPREND.TIPEPRLICAMBEND = pTipoEndereco)
      LEFT JOIN TPACTAREXCRECLOG LOG ON TAR.IDEPACTAR =  LOG.IDEPACTAR AND LOG.TYP = 'PortalSIM.Domain.Atividades.Execucao'
     WHERE UNI.IDEEMP = cpIdeEmp
     AND (pIdeTipLegAmb IS NULL OR TTIPLICREGAMB.IdeLegAmb = pIdeTipLegAmb)
     AND (pIdeEnd IS NULL OR pIdeEnd = EPREND.IDEEND)
     AND (pIdeTipLicRegAmb IS NULL OR pIdeTipLicRegAmb = TTIPLICREGAMB.IDETIPLICREGAMB)
	 AND (pIdeEprLicAmb    IS NULL OR pIdeEprLicAmb    = EPR.IDEEPRLICAMB)
     AND (pIdeUsu IS NULL OR pIdeUsu = TAR.IDEUSURES)
     AND (pAgendamentoFuturo = 0 OR TAR.FIMREA IS NULL)
     AND TAR.Del = 0     
     AND (pSomenteTarefasPrincipais = 0 OR TAR.REMRELGRA = 0)
       AND (cpIdeUni IS NULL
            OR ( (cpSub3Niv = 0 AND EPR.IdeUni = cpIdeUni) 
                 OR (cpSub3Niv <> 0 and EPR.IdeUni IN (SELECT tUni.IdeUni
                                     FROM tUni
                                    WHERE tUni.IdeUniTyp IN (SELECT tUniTyp.IdeUniTyp FROM tUniTyp WHERE tUniTyp.Typ = 1)
                                      AND Level <= 3
                                  CONNECT BY PRIOR tUni.IdeUni = tUni.IdeSpr
                                    START WITH tUni.IdeUni = cpIdeUni))))
       AND (   (TAR.FREREC = 0 AND TAR.FIMPRE BETWEEN cpDatIni AND cpDatFim)
            OR (TAR.FREREC <> 0 AND TAR.INIPRE IS NOT NULL  AND ((TAR.INIPRE BETWEEN cpDatIni AND cpDatFim) 
                                                             OR (TAR.FIMPRE BETWEEN cpDatIni AND cpDatFim) 

                                                             OR (TAR.INIPRE < CPDATINI AND TAR.FIMPRE > CPDATFIM)
                                                             OR EXISTS (SELECT 1 FROM TPACTAREXCRECLOG WHERE DATPRE BETWEEN cpDatIni AND cpDatFim AND TAR.IDEPACTAR = TPACTAREXCRECLOG.IDEPACTAR and rownum = 1)
                                                             )))
                                                             
     GROUP BY UNI.IDEUNI, PLA.IDEPLAACO, TAR.IDEPACTAR, TAR.INIPRE, TAR.FIMPRE, TAR.FIMREA, TAR.PRXEXCREC, TAR.FREREC
     ORDER BY TAR.FREREC, TAR.IDEPACTAR, TAR.FIMPRE;
     
     lAcoes CursorAcoes%ROWTYPE;

     CURSOR CursorExecucoesRecursivas(cpDatIni DATE, cpDatFim DATE, cpIdePacTar NUMBER) IS
     SELECT TO_DATE(LOG.DATPRE) DATPRE, TO_DATE(LOG.ULTEXCREC) ULTEXCREC, MAX(LOG.IDEPACTAREXCRECLOG) IDEPACTAREXCRECLOG
       FROM TPACTAREXCRECLOG LOG
      WHERE LOG.IDEPACTAR = cpIdePacTar
        AND LOG.DATPRE BETWEEN cpDatIni AND cpDatFim
		AND LOG.TYP = 'PortalSIM.Domain.Atividades.Execucao'
      GROUP BY TO_DATE(LOG.DATPRE), TO_DATE(LOG.ULTEXCREC)
      ORDER BY TO_DATE(LOG.DATPRE);

    lExecucoes  CursorExecucoesRecursivas%ROWTYPE;

    lObject_CumprimentoAcoes_Table Object_CumprimentoAcoes_Table := Object_CumprimentoAcoes_Table();
	lObject_CumprimentoAcoes Object_CumprimentoAcoes_Table := Object_CumprimentoAcoes_Table();
      
    BEGIN
        IF UPPER(pTipoRelacionamento) = 'CRONOGRAMADOPROJETO' THEN
            OPEN CursorCronogramaDoProjeto(pDatIni, pDatFim, pIdeEmp, pIdeUni, pSub3Niv);
        ELSE
            OPEN CursorAcoes(pDatIni, pDatFim, pIdeEmp, pIdeUni, pSub3Niv);
        END IF;
        
        LOOP
            IF UPPER(pTipoRelacionamento) = 'CRONOGRAMADOPROJETO' THEN
                FETCH CursorCronogramaDoProjeto INTO lAcoes;
                EXIT WHEN CursorCronogramaDoProjeto%NOTFOUND;
            ELSE
                FETCH CursorAcoes INTO lAcoes;
                EXIT WHEN CursorAcoes%NOTFOUND;
            END IF;
            
            IF lAcoes.FreRec = 0 THEN
                lData_Referencia := lAcoes.FimPre;
                lData_Prevista := lAcoes.FimPre;
                lData_Realizada := lAcoes.FimRea;
                lObject_CumprimentoAcoes_Table.extend;
                lObject_CumprimentoAcoes_Table(lObject_CumprimentoAcoes_Table.Last) := Object_CumprimentoAcoes(lAcoes.IdePacTarExcRecLog, lAcoes.IdeUni, lAcoes.IdeVin, lAcoes.IdePlaAco, lAcoes.IdePacTar, lAcoes.FreRec, lAcoes.IniPre, lData_Prevista, lData_Referencia, lData_Realizada);
            ELSE
                lData_Referencia := NULL;
                
                OPEN CursorExecucoesRecursivas(pDatIni, pDatFim, lAcoes.IdePacTar);
                LOOP
                    FETCH CursorExecucoesRecursivas INTO lExecucoes;
                    EXIT WHEN CursorExecucoesRecursivas%NOTFOUND;
                        
                        lData_Prevista := lAcoes.FimPre;
                        lData_Referencia := lExecucoes.DatPre;
                        lData_Realizada := lExecucoes.UltExcRec;

                        lObject_CumprimentoAcoes_Table.extend;
                        lObject_CumprimentoAcoes_Table(lObject_CumprimentoAcoes_Table.Last) := Object_CumprimentoAcoes(lExecucoes.IdePacTarExcRecLog, lAcoes.IdeUni, lAcoes.IdeVin, lAcoes.IdePlaAco, lAcoes.IdePacTar, lAcoes.FreRec, lAcoes.IniPre, lData_Prevista, lData_Referencia, lData_Realizada);
                    
                END LOOP;
                CLOSE CursorExecucoesRecursivas;
                
    IF lData_Referencia IS NULL THEN
        lData_Referencia := lAcoes.IniPre;
    END IF;

                LOOP
                     EXIT WHEN lData_Referencia > pDatFim OR (pAgendamentoFuturo = 0 AND lData_Referencia >= TO_DATE(SYSDATE)) OR lData_Referencia > lAcoes.FimPre OR lData_Referencia > lAcoes.FimRea;
                     
                     IF lData_Referencia >= pDatIni THEN
                         SELECT COUNT(1) 
                           INTO lExists 
                           FROM TABLE(lObject_CumprimentoAcoes_Table) 
                          WHERE IDEPACTAR = lAcoes.IdePacTar 
                            AND DATREF = lData_Referencia;

                         IF (lExists = 0) THEN
                             lObject_CumprimentoAcoes_Table.extend;
                             lObject_CumprimentoAcoes_Table(lObject_CumprimentoAcoes_Table.Last) := Object_CumprimentoAcoes(null, lAcoes.IdeUni, lAcoes.IdeVin, lAcoes.IdePlaAco, lAcoes.IdePacTar, lAcoes.FreRec, lAcoes.IniPre, lData_Prevista, lData_Referencia, NULL);
                         END IF;    


                     END IF;
                     
                     lData_Referencia := CASE lAcoes.FreRec WHEN 1 /* Di�rio */      THEN TO_DATE(lData_Referencia) + 1 
                                                            WHEN 2 /* Semanal */     THEN TO_DATE(lData_Referencia) + 7 
                                                            WHEN 3 /* Quinzenal */   THEN TO_DATE(lData_Referencia) + 15 
                                                            WHEN 4 /* Mensal */      THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 1) 
                                                            WHEN 5 /* Bimestral */   THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 2) 
                                                            WHEN 6 /* Trimestral */  THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 3) 
                                                            WHEN 7 /* Quadrimestral*/THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 4) 
                                                            WHEN 8 /* Semestral */   THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 6) 
                                                            WHEN 9 /* Anual */       THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 12) 
                                                            WHEN 10 /* Bienal */     THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 24) 
                                                            WHEN 11 /* Trienal */    THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 36) 
                                          END;
                END LOOP;

				  IF pAgendamentoFuturo = 1 THEN
				  FOR x in (SELECT * FROM TABLE(lObject_CumprimentoAcoes_Table) WHERE DATREA IS NOT NULL) loop
					   lObject_CumprimentoAcoes.extend;
					   lObject_CumprimentoAcoes(lObject_CumprimentoAcoes.Last) := Object_CumprimentoAcoes(null, X.IdeUni, X.IdeVin, X.IdePlaAco, X.IdePacTar, X.FreRec, X.IniPreTar, X.FimPreTar, X.DatRef, X.DATREA);
					END LOOP;
				  END IF;
            END IF;
            
        END LOOP;
        
        IF UPPER(pTipoRelacionamento) = 'CRONOGRAMADOPROJETO' THEN
            CLOSE CursorCronogramaDoProjeto;
        ELSE
            CLOSE CursorAcoes;
        END IF;
     
        RETURN lObject_CumprimentoAcoes_Table;
    END;


/* Fun��o     : RetornarFarolImpOpe
   Propósito  : Retorna Farol de Implanta��o e Opera��o de um Projeto com base no Licenciamento Sugerido e Datas Desejo de Implanta��o e Opera��o
   Parâmetros : pIdeEprLicAmb	- Identificador do Projeto a ser verificado
			  : pIdeClsLicAmb	- Identificador da Classifica��o do Projeto
			  : pDatIniImp		- Data Desejo de Implanta��o
			  : pDatIniOpe		- Data Desejo de Opera��o
    Cria��o    : 14/06/2013 - Eduardo C�sar
    Última Alt.: 09/04/2015 - Eduardo C�sar */
FUNCTION RetornarFarolImpOpe(pIdeEprLicAmb NUMBER, pIdeClsLicAmb NUMBER, pDatIniImp DATE, pDatIniOpe DATE)
  RETURN Object_FarolImpOpe_Table
AS

	lOrdemLI INT;
	lOrdemLO INT;
	lIdeLicAmbLI NUMBER(13); 
	lIdeLicAmbLO NUMBER(13);
	lFarolImplantacao INT;
	lFarolOperacao INT;
	lDataImplantacao DATE;
	lDataOperacao DATE;
	lPrazoObtDoc INT;
	lPrazoObt INT;


	lObject_FarolImpOpe_Table Object_FarolImpOpe_Table := Object_FarolImpOpe_Table();

	BEGIN
		lDataImplantacao := SYSDATE;
		lDataOperacao := SYSDATE;
		lFarolOperacao := -1;


		BEGIN

       SELECT vLicAmbImp.IdeLicAmbImp, COALESCE(vLicAmbImp.DatObtImp, vLicAmbImp.DatPreImp) INTO lIdeLicAmbLI, lDataImplantacao
        FROM (SELECT tLicAmb.IdeLicAmb IdeLicAmbImp,
              tLicAmb.IdeEprLicAmb,
              tLicAmb.DatPre DatPreImp,
              tLicAmb.DatObt DatObtImp														
            FROM tLicAmb INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
            WHERE tLicAmb.IdeEprLicAmb = pIdeEprLicAmb
            AND (tTipLicAmb.TipLic = 2 OR tTipLicAmb.TipLic = 3 OR tTipLicAmb.TipLic = 7)  /* LI / RevLI / (LP + LI) */
            AND tLicAmb.Stt <> 4 /* Indeferida */
            AND tLicAmb.Stt <> 5 /* Cancelada */
            ) vLicAmbImp
        INNER JOIN (SELECT LI.IdeEprLicAmb, LI.IdeLicAmb
                      FROM (SELECT tLicAmb.IdeEprLicAmb, 
                                   tLicAmb.IdeLicAmb
                              FROM tLicAmb INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
                             WHERE tLicAmb.IdeEprLicAmb = pIdeEprLicAmb
                               AND (tTipLicAmb.TipLic = 2 OR tTipLicAmb.TipLic = 3 OR tTipLicAmb.TipLic = 7)  /* LI / RevLI / (LP + LI) */ 
                               AND tLicAmb.Stt <> 4 /* Indeferida */ 
                               AND tLicAmb.Stt <> 5 /* Cancelada */ 
                             ORDER BY CASE WHEN tLicAmb.DatObt IS NOT NULL THEN tLicAmb.DatObt ELSE tLicAmb.DatPre END DESC) LI
                    WHERE ROWNUM = 1
             ) vUltLicAmbImp ON vUltLicAmbImp.IdeEprLicAmb = vLicAmbImp.IdeEprLicAmb AND vUltLicAmbImp.IdeLicAmb = vLicAmbImp.IdeLicAmbImp;

		EXCEPTION WHEN OTHERS THEN
			lIdeLicAmbLI := NULL;
      lDataImplantacao := NULL;
		END;

		BEGIN

       SELECT vLicAmbOpe.IdeLicAmbOpe, COALESCE(vLicAmbOpe.DatObtImp, vLicAmbOpe.DatPreImp) INTO lIdeLicAmbLO, lDataOperacao
        FROM (SELECT tLicAmb.IdeLicAmb IdeLicAmbOpe,
              tLicAmb.IdeEprLicAmb,
              tLicAmb.DatPre DatPreImp,
              tLicAmb.DatObt DatObtImp														
            FROM tLicAmb INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
            WHERE tLicAmb.IdeEprLicAmb = pIdeEprLicAmb
              AND (tTipLicAmb.TipLic = 4 OR tTipLicAmb.TipLic = 5 OR tTipLicAmb.TipLic = 6)  /* LO / RevLO / LOC */
              AND tLicAmb.Stt <> 4 /* Indeferida */ 
              AND tLicAmb.Stt <> 5 /* Cancelada */ 
            ) vLicAmbOpe
        INNER JOIN (SELECT LO.IdeEprLicAmb, LO.IdeLicAmb
                      FROM (SELECT tLicAmb.IdeEprLicAmb, 
                                   tLicAmb.IdeLicAmb IdeLicAmb
                              FROM tLicAmb INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
                             WHERE tLicAmb.IdeEprLicAmb = pIdeEprLicAmb
                               AND (tTipLicAmb.TipLic = 4 OR tTipLicAmb.TipLic = 5 OR tTipLicAmb.TipLic = 6)  /* LO / RevLO / LOC */
                               AND tLicAmb.Stt <> 4 /* Indeferida */ 
                               AND tLicAmb.Stt <> 5 /* Cancelada */ 
                             ORDER BY CASE WHEN tLicAmb.DatObt IS NOT NULL THEN tLicAmb.DatObt ELSE tLicAmb.DatPre END DESC) LO
                    WHERE ROWNUM = 1
             ) vUltLicAmbOpe ON vUltLicAmbOpe.IdeEprLicAmb = vLicAmbOpe.IdeEprLicAmb AND vUltLicAmbOpe.IdeLicAmb = vLicAmbOpe.IdeLicAmbOpe;

		EXCEPTION WHEN OTHERS THEN
			lIdeLicAmbLO := NULL;
      lDataOperacao := NULL;
		END;

		BEGIN
			SELECT LI.ORD INTO lOrdemLI
			  FROM (SELECT CLSTIP.ORD
					  FROM TCLSLICAMBTIPLICAMB CLSTIP
					 INNER JOIN TTIPLICAMB TIPLICLI ON (TIPLICLI.IDETIPLICAMB = CLSTIP.IDETIPLICAMB AND (TIPLICLI.TIPLIC = 2 OR TIPLICLI.TIPLIC = 3 OR TIPLICLI.TIPLIC = 7)) /* Tipos de licen�a de Implanta��o*/
					 WHERE CLSTIP.IDECLSLICAMB = PIDECLSLICAMB
					 ORDER BY CLSTIP.ORD) LI
			 WHERE ROWNUM = 1;
		EXCEPTION WHEN OTHERS THEN
			lOrdemLI := NULL;
		END;

		BEGIN
			SELECT LO.ORD INTO lOrdemLO
			  FROM (SELECT CLSTIP.ORD
					  FROM TCLSLICAMBTIPLICAMB CLSTIP
					 INNER JOIN TTIPLICAMB TIPLICLI ON (TIPLICLI.IDETIPLICAMB = CLSTIP.IDETIPLICAMB AND (TIPLICLI.TIPLIC = 4 OR TIPLICLI.TIPLIC = 5 OR TIPLICLI.TIPLIC = 6)) /* Tipos de licen�a de Opera��o*/
					 WHERE CLSTIP.IDECLSLICAMB = PIDECLSLICAMB
					 ORDER BY CLSTIP.ORD) LO
			 WHERE ROWNUM = 1;
		EXCEPTION WHEN OTHERS THEN
			lOrdemLO := NULL;
		END;

		/* Definindo Farol de Implanta��o */
		IF pDatIniImp IS NULL THEN
			lFarolImplantacao := -1;
		ELSE
			IF lIdeLicAmbLI IS NOT NULL THEN

				IF lDataImplantacao IS NULL THEN
					lFarolImplantacao := -1;
				ELSE
					IF lDataImplantacao > pDatIniImp THEN
						lFarolImplantacao := 0;
					ELSE
						lFarolImplantacao := 2;
					END IF;
				END IF;

			ELSE
				IF lOrdemLI IS NULL OR lIdeLicAmbLO IS NOT NULL THEN
					lFarolImplantacao := -1;
				ELSE
					BEGIN
						SELECT SUM(TIPLIC.PRZOBTDOC), SUM(TIPLIC.PRZOBT) INTO lPrazoObtDoc, lPrazoObt
						  FROM TTIPLICAMB TIPLIC
						 INNER JOIN TCLSLICAMBTIPLICAMB CLSTIP ON TIPLIC.IDETIPLICAMB = CLSTIP.IDETIPLICAMB
						 WHERE CLSTIP.IDECLSLICAMB = pIdeClsLicAmb
						   AND TIPLIC.IDETIPLICAMB NOT IN (SELECT IDETIPLICAMB FROM TLICAMB LIC WHERE IDEEPRLICAMB = pIdeEprLicAmb)
						   AND CLSTIP.ORD <= lOrdemLI;
					EXCEPTION WHEN OTHERS THEN
						lDataImplantacao := NULL;
					END;

					IF lDataImplantacao IS NULL THEN
						lDataImplantacao := SYSDATE;
					ELSE
						lDataImplantacao := NON_ANSI_ADD_MONTHS(SYSDATE + lPrazoObtDoc, lPrazoObt);
					END IF;

					IF lDataImplantacao > pDatIniImp THEN
						lFarolImplantacao := 0;
					ELSE
						lFarolImplantacao := 2;
					END IF;

				END IF;
			END IF;
		END IF;


		/* Definindo Farol de Opera��o */
		IF pDatIniOpe IS NULL THEN
			lFarolOperacao := -1;
		ELSE
			IF lIdeLicAmbLO IS NOT NULL THEN

				IF lDataOperacao IS NULL THEN
					lFarolOperacao := -1;
				ELSE
					IF lDataOperacao > pDatIniOpe THEN
						lFarolOperacao := 0;
					ELSE
						lFarolOperacao := 2;
					END IF;
				END IF;

			ELSE
				IF lOrdemLO IS NULL THEN
					lFarolOperacao := -1;
				ELSE
					BEGIN
						SELECT SUM(TIPLIC.PRZOBTDOC), SUM(TIPLIC.PRZOBT) INTO lPrazoObtDoc, lPrazoObt
						  FROM TTIPLICAMB TIPLIC
						 INNER JOIN TCLSLICAMBTIPLICAMB CLSTIP ON TIPLIC.IDETIPLICAMB = CLSTIP.IDETIPLICAMB
						 WHERE CLSTIP.IDECLSLICAMB = pIdeClsLicAmb
						   AND TIPLIC.IDETIPLICAMB NOT IN (SELECT IDETIPLICAMB FROM TLICAMB LIC WHERE IDEEPRLICAMB = pIdeEprLicAmb)
						   AND CLSTIP.ORD > lOrdemLI
						   AND CLSTIP.ORD <= lOrdemLO;
					EXCEPTION WHEN OTHERS THEN
						lDataOperacao := NULL;
					END;

					IF lDataOperacao IS NULL THEN
						lDataOperacao := lDataImplantacao;
					ELSE
						lDataOperacao := NON_ANSI_ADD_MONTHS(lDataImplantacao + lPrazoObtDoc, lPrazoObt);
					END IF;

					IF lDataOperacao > pDatIniOpe THEN
						lFarolOperacao := 0;
					ELSE
						lFarolOperacao := 2;
					END IF;

				END IF;
			END IF;
		END IF;

		lObject_FarolImpOpe_Table.EXTEND;
		lObject_FarolImpOpe_Table(lObject_FarolImpOpe_Table.Last) := Object_FarolImpOpe(pIdeEprLicAmb,  lFarolImplantacao, lFarolOperacao);

		Return lObject_FarolImpOpe_Table;
	END;

END;
/


CREATE OR REPLACE
PACKAGE RELATORIOS
IS
    TYPE tCursorType IS REF CURSOR;
    
    PROCEDURE RelStatusAcoesAgenda(pRecordSet OUT SYS_REFCURSOR, pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pIdeTipAgd NUMBER, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT);
	PROCEDURE RelStatusAcoesAgendaRes(pRecordSet OUT SYS_REFCURSOR, pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pIdeTipAgd NUMBER, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT);

    PROCEDURE RelStatusProjetosRes(pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls NUMBER, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT, pPortalSim30 INT, pRecordSet OUT tCursorType);
    PROCEDURE RelStatusAcoesRes(pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls NUMBER, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT, pPortalSim30 INT, pRecordSet OUT tCursorType);

    PROCEDURE RelStatusProjetos(pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls NUMBER, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT, pPortalSim30 INT, pRecordSet OUT tCursorType);
    PROCEDURE RelStatusAcoes(pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls NUMBER, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT, pPortalSim30 INT, pRecordSet OUT tCursorType);
    
	PROCEDURE RelStatusProjetosRes30(pRecordSet OUT tCursorType, pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls INT, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT);
    PROCEDURE RelStatusAcoesRes30(pRecordSet OUT tCursorType, pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls INT, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT);

    PROCEDURE RelStatusProjetos30(pRecordSet OUT tCursorType, pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls INT, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT);
    PROCEDURE RelStatusAcoes30(pRecordSet OUT tCursorType, pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls INT, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT);
	 
	PROCEDURE RelNumeroGrupos (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pExr INT, pRecordset OUT tCursorType);
    PROCEDURE RelGruposAtivos(pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pDat DATE, pRecordset OUT tCursorType);
    PROCEDURE RelListagemGrupos(pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pSomenteGruposAtivos INT, pRecordset OUT tCursorType);
    PROCEDURE RelTempoGrupos(pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pRecordset OUT tCursorType);

    PROCEDURE RelNumeroCirculistas (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pExr INT, pRecordset OUT tCursorType);
    PROCEDURE RelPlacarGeralCirculistas(pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeGruCCQ NUMBER, pSomenteGruposAtivos INT, pSomenteParticipantesAtivos INT, pRecordset OUT tCursorType);
    PROCEDURE RelTempoCirculistas (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pRecordset OUT tCursorType);
    PROCEDURE RelPercParticipacaoEfetivo (pIdeEmp NUMBER, pNop INT, pRecordset OUT tCursorType);
    PROCEDURE RelAdesaoEfetiva(pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pRecordset OUT tCursorType);
    PROCEDURE RelPercParticipacaoPrograma(pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pRecordset OUT tCursorType);

    PROCEDURE RelNumeroProjetos (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pExr INT, pRecordset OUT tCursorType);
    PROCEDURE RelListagemProjetos (pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pIdeGruInd NUMBER, pIdeMetSolPrb NUMBER, pPerIniAbe DATE, pPerFinAbe DATE, pPerIniEnc DATE, pPerFinEnc DATE, pRecordset OUT tCursorType);
    PROCEDURE RelNumeroProjetosPeriodo (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pAnoIni INT, pAnoFim INT, pRecordset OUT tCursorType);
    PROCEDURE RelProjetosRegImp (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pPerIni DATE, pPerFin DATE, pRecordset OUT tCursorType);
    PROCEDURE RelProjetosGanhos (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pPerIni DATE, pPerFin DATE, pRecordset OUT tCursorType);
    PROCEDURE RelProdutividadeGrupos(pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pDatIni DATE, pDatFin DATE, pRecordset OUT tCursorType);

    PROCEDURE RelPercReunioesRealizadas (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pExr INT, pRecordset OUT tCursorType);
    PROCEDURE RelPercParticipacaoReunioes (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pExr INT, pRecordset OUT tCursorType);

    PROCEDURE RetornarIdeiasPorUG (pIdeUni IN NUMBER, pSub IN NUMBER, pDatIni IN DATE, pDatFin IN DATE, pRecordset OUT tCursorType);

END;
/

CREATE OR REPLACE
PACKAGE BODY RELATORIOS
IS

    TYPE RecordMeses IS RECORD (Valor1 INT, Valor2 INT);
    TYPE TypeRecordMeses IS TABLE OF RecordMeses INDEX BY BINARY_INTEGER;
    Meses           TypeRecordMeses;

    /* Fun��o     : RelStatusAcoesAgenda
   Prop�sito  : Retorna os Status das Acoes sob a Responsabilidade de uma Unidade Gerencial e/ou suas subordinadas at� o 3o n�vel
   Par�metros : pIdeUni-Identificador da Unidade Gerencial
                pSub-Indica se o relat�rio deve retornar dados apenas da UG selecionada ou de suas subordinadas at� o 3o n�vel
                pPerIni-Per�odo de In�cio definido pelo Usu�rio (pode ser nulo)
                pPerFin-Per�odo de T�rmino definido pelo usu�rio (pode ser nulo)
                pIdeUsu-Identificador do Usu�rio respons�vel pelas Solu��es de Problema ou pelas A��es
                pCls-Classifica��o sob as quais ser� feita a pesquisa
   Cria��o    : 22/11/2010 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */
   
PROCEDURE RelStatusAcoesAgenda(pRecordSet OUT SYS_REFCURSOR, pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pIdeTipAgd NUMBER, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT)
    IS
        CursorRelatorio     tCursorType;
        
        lTblTemp            OBJECT_TMPRELSTATUS30_TABLE := OBJECT_TMPRELSTATUS30_TABLE();
				
        lLvl                INT;
        lPerIni             DATE := NULL;
        lPerFin             DATE := NULL;

		lHoje               VARCHAR2(50) := 'TO_DATE(''' || TO_CHAR(SYSDATE, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
    
        lStrQuery           VARCHAR2(8000) := '';
        lCondicaoAcoes1     VARCHAR2(1000) := '';
        lCondicaoTipoAgendamento VARCHAR2(1000) := '';
        lCondicaoIdeUni     VARCHAR2(1000) := '';
            
        lCalculoSubtotal    INT := 0;

        lOrd                INT;
        lSig                VARCHAR2(50);
        lIdeUni             NUMBER(13);
        lCriados            INT;
        lPlanejadasNoPrazo  INT;
        lPlanejadasAtrasada INT;
        lEmExecucaoNoPrazo  INT;
        lEmExecucaoAtrasada INT;
        lFinalizadaNoPrazo  INT;
        lFinalizadaAtrasada INT;

        lTotalCriados       INT;
        lTotalPlanejadasNoPrazo  INT;
        lTotalPlanejadasAtrasada INT;
        lTotalEmExecucaoNoPrazo  INT;
        lTotalEmExecucaoAtrasada INT;
        lTotalFinalizadaNoPrazo  INT;
        lTotalFinalizadaAtrasada INT;

        lSubTotalCriados        INT;
        lSubTotalPlanejadasNoPrazo   INT;
        lSubTotalPlanejadasAtrasada  INT;
        lSubTotalEmExecucaoNoPrazo   INT;
        lSubTotalEmExecucaoAtrasada  INT;
        lSubTotalFinalizadaNoPrazo   INT;
        lSubTotalFinalizadaAtrasada  INT;
BEGIN

    IF pSub = 0 OR pIdeUni IS NULL THEN
        lLvl := 1;
    ELSE
        lLvl := 3;
    END IF;
        
    IF NOT pPerIni IS NULL THEN
        lPerIni := pPerIni;
    END IF;

    IF NOT pPerFin IS NULL THEN
        lPerFin := pPerFin;
    END IF;

    IF NOT pIdeUni IS NULL THEN
        lCondicaoIdeUni := ' START WITH VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF NOT pIdeTipAgd IS NULL THEN
        lCondicaoTipoAgendamento := ' WHERE TAGD.IDETIPAGD = ' || TO_CHAR(pIdeTipAgd);
    END IF;
    
    IF NOT lPerIni IS NULL THEN         
        lCondicaoAcoes1 := lCondicaoAcoes1 || ' AND TPACTAR.FIMPRE BETWEEN TO_DATE(''' || TO_CHAR(lPerIni, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TO_DATE(''' || TO_CHAR(lPerFin, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
    END IF;
    
    IF NOT pIdeUsu IS NULL THEN
        lCondicaoAcoes1 := lCondicaoAcoes1 || ' AND TPACTAR.IDEUSURES = ' || TO_CHAR(pIdeUsu);
    END IF;

    lStrQuery :=              'SELECT VUNIARV.ORD, ';
    lStrQuery := lStrQuery || '       VUNIARV.SIG, ';
    lStrQuery := lStrQuery || '       VUNIARV.IdeUni, ';
    lStrQuery := lStrQuery || '       VUNIARV.LVL, ';
    lStrQuery := lStrQuery || '       COUNT(VPACTAR.IDEPACTAR) Criados, ';
    lStrQuery := lStrQuery || '       SUM(CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE >= ' || lHoje || ' THEN 1 ELSE 0 END) PlanejadasNoPrazo, ';
	lStrQuery := lStrQuery || '       SUM(CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE < ' || lHoje || ' THEN 1 ELSE 0 END) PlanejadasAtrasada, ';
	lStrQuery := lStrQuery || '       SUM(CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, SYSDATE)) <= VPACTAR.PERCON THEN 1 ELSE 0 END) END) EmExecucaoNoPrazo, ';
	lStrQuery := lStrQuery || '       SUM(CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, SYSDATE)) > VPACTAR.PERCON THEN 1 ELSE 0 END) END) EmExecucaoAtrasada, ';
    lStrQuery := lStrQuery || '       SUM(CASE WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA <= VPACTAR.FIMPRE THEN 1 ELSE 0 END) FinalizadaNoPrazo, ';
	lStrQuery := lStrQuery || '       SUM(CASE WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA > VPACTAR.FIMPRE THEN 1 ELSE 0 END) FinalizadaAtrasada ';
    lStrQuery := lStrQuery || 'FROM (SELECT VUNI.IDEUNI, ';
    lStrQuery := lStrQuery || '             SUBSTR((RPAD('' '', (LEVEL - 1) * 3, '' '') || VUNI.SIG), 1, 50) AS SIG, ';
    lStrQuery := lStrQuery || '             LEVEL LVL, ';
    lStrQuery := lStrQuery || '             ROWNUM ORD ';
    lStrQuery := lStrQuery || '        FROM TUNI VUNI ';
	lStrQuery := lStrQuery ||  '             INNER JOIN (SELECT IDEUNI FROM TABLE(RetornarUnidadesPorUsuario(' || TO_CHAR(pIdeUsuLogado) || '))) TUSUUNI ON TUNI.IDEUNI = TUSUUNI.IDEUNI ';
    lStrQuery := lStrQuery || '       WHERE TUNI.IDEUNITYP IN (SELECT TUNITYP.IDEUNITYP FROM TUNITYP WHERE TUNITYP.TYP = 1) ';
    lStrQuery := lStrQuery || '         AND LEVEL <= ' || TO_CHAR(lLvl);
    lStrQuery := lStrQuery || '      CONNECT BY PRIOR VUNI.IDEUNI = VUNI.IDESPR ' || lCondicaoIdeUni || ' ) VUNIARV LEFT JOIN (SELECT IDEAGD, IDEUNI, IDEPLAACO FROM TAGD ' || lCondicaoTipoAgendamento || ') TAGD ON TAGD.IDEUNI = VUNIARV.IDEUNI ';
    lStrQuery := lStrQuery || '                                                                                                 LEFT JOIN TPLAACO ON TPLAACO.IDEPLAACO = TAGD.IDEPLAACO ';
    lStrQuery := lStrQuery || '                                                                                                 LEFT JOIN (SELECT TPACTAR.IDEPLAACO, TPACTAR.IDEPACTAR, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.INIPRE, TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, TPACTAR.FREREC, TPACTAR.DURHRA, TPACTAR.PERCON FROM TPACTAR LEFT JOIN TPACTARREP ON TPACTAR.IDEPACTAR = TPACTARREP.IDEPACTAR WHERE TPACTAR.DEL = 0 ' || lCondicaoAcoes1 || ' GROUP BY TPACTAR.IDEPACTAR, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.INIPRE, TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, TPACTAR.IDEPLAACO, TPACTAR.FREREC, TPACTAR.DURHRA, TPACTAR.PERCON) VPACTAR ON TPLAACO.IDEPLAACO = VPACTAR.IDEPLAACO ';
    lStrQuery := lStrQuery || ' GROUP BY VUNIARV.SIG, VUNIARV.IDEUNI, VUNIARV.ORD, VUNIARV.LVL ';
    lStrQuery := lStrQuery || ' ORDER BY VUNIARV.ORD ';
    
    lTotalCriados := 0;
    lTotalPlanejadasNoPrazo := 0;
    lTotalPlanejadasAtrasada := 0;
    lTotalEmExecucaoNoPrazo := 0;
    lTotalEmExecucaoAtrasada := 0;
    lTotalFinalizadaNoPrazo := 0;
    lTotalFinalizadaAtrasada := 0;

	lSubTotalCriados := 0;
    lSubTotalPlanejadasNoPrazo := 0;
    lSubTotalPlanejadasAtrasada := 0;
    lSubTotalEmExecucaoNoPrazo := 0;
    lSubTotalEmExecucaoAtrasada := 0;
    lSubTotalFinalizadaNoPrazo := 0;
    lSubTotalFinalizadaAtrasada := 0;

    IF CursorRelatorio%ISOPEN THEN
        CLOSE CursorRelatorio;
    END IF;

    OPEN CursorRelatorio FOR lStrQuery;
    LOOP    
        FETCH CursorRelatorio INTO lOrd, lSig, lIdeUni, lLvl, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada;
        EXIT WHEN CursorRelatorio%NOTFOUND;

        IF lLvl = 2 THEN
            IF lCalculoSubtotal = 2 AND pExcel = 0 THEN
                lTblTemp.Extend;
				lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrd + 1, '', 0, '      Subtotal', -2, 2, lSubTotalCriados, lSubTotalPlanejadasNoPrazo, lSubTotalPlanejadasAtrasada, lSubTotalEmExecucaoNoPrazo, lSubTotalEmExecucaoAtrasada, lSubTotalFinalizadaNoPrazo, lSubTotalFinalizadaAtrasada);
            END IF;

            lCalculoSubtotal := 1;  
            
            lSubTotalCriados := lCriados;
            lSubTotalPlanejadasNoPrazo := lPlanejadasNoPrazo;
            lSubTotalPlanejadasAtrasada := lPlanejadasAtrasada;
            lSubTotalEmExecucaoNoPrazo := lEmExecucaoNoPrazo;
            lSubTotalEmExecucaoAtrasada := lEmExecucaoAtrasada;
            lSubTotalFinalizadaNoPrazo := lFinalizadaNoPrazo;
            lSubTotalFinalizadaAtrasada := lFinalizadaAtrasada;
        ELSIF lLvl = 3 THEN
            lCalculoSubtotal := 2;
                        
            lSubTotalCriados := lSubTotalCriados + lCriados;
            lSubTotalPlanejadasNoPrazo := lSubTotalPlanejadasNoPrazo + lPlanejadasNoPrazo;
            lSubTotalPlanejadasAtrasada := lSubTotalPlanejadasAtrasada + lPlanejadasAtrasada;
            lSubTotalEmExecucaoNoPrazo := lSubTotalEmExecucaoNoPrazo + lEmExecucaoNoPrazo;
            lSubTotalEmExecucaoAtrasada := lSubTotalEmExecucaoAtrasada + lEmExecucaoAtrasada;
            lSubTotalFinalizadaNoPrazo := lSubTotalFinalizadaNoPrazo + lFinalizadaNoPrazo;
            lSubTotalFinalizadaAtrasada := lSubTotalFinalizadaAtrasada + lFinalizadaAtrasada;
        END IF;

        lTotalCriados := lTotalCriados + lCriados;
        lTotalPlanejadasNoPrazo := lTotalPlanejadasNoPrazo + lPlanejadasNoPrazo;
        lTotalPlanejadasAtrasada := lTotalPlanejadasAtrasada + lPlanejadasAtrasada;
        lTotalEmExecucaoNoPrazo := lTotalEmExecucaoNoPrazo + lEmExecucaoNoPrazo;
        lTotalEmExecucaoAtrasada := lTotalEmExecucaoAtrasada + lEmExecucaoAtrasada;
        lTotalFinalizadaNoPrazo := lTotalFinalizadaNoPrazo + lFinalizadaNoPrazo;
        lTotalFinalizadaAtrasada := lTotalFinalizadaAtrasada + lFinalizadaAtrasada;

        lTblTemp.Extend;
		lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrd, '', 0, lSig, lIdeUni, 0, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada);
    END LOOP;

    IF CursorRelatorio%ISOPEN THEN
        CLOSE CursorRelatorio;
    END IF;

    IF (pSub <> 0 AND pExcel = 0) THEN
        IF lCalculoSubtotal = 2 THEN
            lTblTemp.Extend;
			lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrd + 1, '', 0, '      Subtotal', -2, 2, lSubTotalCriados, lSubTotalPlanejadasNoPrazo, lSubTotalPlanejadasAtrasada, lSubTotalEmExecucaoNoPrazo, lSubTotalEmExecucaoAtrasada, lSubTotalFinalizadaNoPrazo, lSubTotalFinalizadaAtrasada);
        END IF;

        lTblTemp.Extend;
		lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrd + 2, '', 0, 'Total', -1, 1, lTotalCriados, lTotalPlanejadasNoPrazo, lTotalPlanejadasAtrasada, lTotalEmExecucaoNoPrazo, lTotalEmExecucaoAtrasada, lTotalFinalizadaNoPrazo, lTotalFinalizadaAtrasada);
    END IF;
    
    OPEN pRecordset FOR
	SELECT ROWNUM Id, T.* FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELSTATUS30_TABLE)) T;
    
END;

PROCEDURE RelStatusAcoesAgendaRes(pRecordSet OUT SYS_REFCURSOR, pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pIdeTipAgd NUMBER, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT)
    IS
        CursorRelatorio     tCursorType;
        CursorRelatorioOrderNivel1     tCursorType;
        CursorRelatorioOrderNivel2     tCursorType;
        
        lTblTemp            OBJECT_TMPRELSTATUS30_TABLE := OBJECT_TMPRELSTATUS30_TABLE();
		lTblTempOrder       OBJECT_TMPRELSTATUS30_TABLE := OBJECT_TMPRELSTATUS30_TABLE();
        
        lLvl                INT;
        lPerIni             DATE := NULL;
        lPerFin             DATE := NULL;
            
        lHoje               VARCHAR2(50) := 'TO_DATE(''' || TO_CHAR(SYSDATE, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
    
        lStrQuery           VARCHAR2(8000) := '';
        lCondicaoAcoes1     VARCHAR2(1000) := '';
        lCondicaoTipoAgendamento VARCHAR2(1000) := '';
        lCondicaoIdeUni     VARCHAR2(1000) := '';
            
        lCalculoSubtotal    INT := 0;

        lOrd                INT;
		lOrdFinal           INT;
        lSig                VARCHAR2(50);
        lIdeUni             NUMBER(13);
        lCriados            INT;
		lPlanejadasNoPrazo  INT;
        lPlanejadasAtrasada INT;
        lEmExecucaoNoPrazo  INT;
        lEmExecucaoAtrasada INT;
        lFinalizadaNoPrazo  INT;
        lFinalizadaAtrasada INT;

		lTotal              INT;

        lTotalCriados       INT;
		lTotalPlanejadasNoPrazo  INT;
        lTotalPlanejadasAtrasada INT;
        lTotalEmExecucaoNoPrazo  INT;
        lTotalEmExecucaoAtrasada INT;
        lTotalFinalizadaNoPrazo  INT;
        lTotalFinalizadaAtrasada INT;

        lSubTotalCriados        INT;
		lSubTotalPlanejadasNoPrazo   INT;
        lSubTotalPlanejadasAtrasada  INT;
        lSubTotalEmExecucaoNoPrazo   INT;
        lSubTotalEmExecucaoAtrasada  INT;
        lSubTotalFinalizadaNoPrazo   INT;
        lSubTotalFinalizadaAtrasada  INT;

		lOrdemGrupoUsuario      INT;

        lNmeUsu             NVARCHAR2(100);
        lIdeUsu             NUMBER(13);
        lLastNmeUsu         VARCHAR2(100);
        lLastIdeUsu         NUMBER(13);
BEGIN
    IF pSub = 0 OR pIdeUni IS NULL THEN
        lLvl := 1;
    ELSE
        lLvl := 3;
    END IF;

	lOrdemGrupoUsuario := 1;
     
    IF NOT pPerIni IS NULL THEN
        lPerIni := pPerIni;
    END IF;

    IF NOT pPerFin IS NULL THEN
        lPerFin := pPerFin;
    END IF;

    IF NOT pIdeUni IS NULL THEN
        lCondicaoIdeUni := ' START WITH VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF NOT pIdeTipAgd IS NULL THEN
        lCondicaoTipoAgendamento := ' WHERE TAGD.IDETIPAGD = ' || TO_CHAR(pIdeTipAgd);
    END IF;
    
    IF NOT lPerIni IS NULL THEN         
        lCondicaoAcoes1 := lCondicaoAcoes1 || ' AND TPACTAR.FIMPRE BETWEEN TO_DATE(''' || TO_CHAR(lPerIni, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TO_DATE(''' || TO_CHAR(lPerFin, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
    END IF;
    
    IF NOT pIdeUsu IS NULL THEN
        lCondicaoAcoes1 := lCondicaoAcoes1 || ' AND TPACTAR.IDEUSURES = ' || TO_CHAR(pIdeUsu);
    END IF;

    lStrQuery :=              'SELECT VUNIARV.ORD, ';
	lStrQuery := lStrQuery || '       TUSU.NME, ';
	lStrQuery := lStrQuery || '       TUSU.IDEUSU, ';
    lStrQuery := lStrQuery || '       VUNIARV.SIG, ';
    lStrQuery := lStrQuery || '       VUNIARV.IdeUni, ';
    lStrQuery := lStrQuery || '       VUNIARV.LVL, ';
    lStrQuery := lStrQuery || '       COUNT(VPACTAR.IDEPACTAR) Criados, ';
	lStrQuery := lStrQuery || '       SUM(CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE >= ' || lHoje || ' THEN 1 ELSE 0 END) PlanejadasNoPrazo, ';
	lStrQuery := lStrQuery || '       SUM(CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE < ' || lHoje || ' THEN 1 ELSE 0 END) PlanejadasAtrasada, ';
	lStrQuery := lStrQuery || '       SUM(CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, SYSDATE)) <= VPACTAR.PERCON THEN 1 ELSE 0 END) END) EmExecucaoNoPrazo, ';
	lStrQuery := lStrQuery || '       SUM(CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, SYSDATE)) > VPACTAR.PERCON THEN 1 ELSE 0 END) END) EmExecucaoAtrasada, ';
    lStrQuery := lStrQuery || '       SUM(CASE WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA <= VPACTAR.FIMPRE THEN 1 ELSE 0 END) FinalizadaNoPrazo, ';
	lStrQuery := lStrQuery || '       SUM(CASE WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA > VPACTAR.FIMPRE THEN 1 ELSE 0 END) FinalizadaAtrasada ';
    lStrQuery := lStrQuery || 'FROM (SELECT VUNI.IDEUNI, ';
    lStrQuery := lStrQuery || '             SUBSTR((RPAD('' '', (LEVEL - 1) * 3, '' '') || VUNI.SIG), 1, 50) AS SIG, ';
    lStrQuery := lStrQuery || '             LEVEL LVL, ';
    lStrQuery := lStrQuery || '             ROWNUM ORD ';
    lStrQuery := lStrQuery || '        FROM TUNI VUNI';
	lStrQuery := lStrQuery ||  '             INNER JOIN (SELECT IDEUNI FROM TABLE(RetornarUnidadesPorUsuario(' || TO_CHAR(pIdeUsuLogado) || '))) TUSUUNI ON TUNI.IDEUNI = TUSUUNI.IDEUNI ';
    lStrQuery := lStrQuery || '       WHERE TUNI.IDEUNITYP IN (SELECT TUNITYP.IDEUNITYP FROM TUNITYP WHERE TUNITYP.TYP = 1) ';
    lStrQuery := lStrQuery || '         AND LEVEL <= ' || TO_CHAR(lLvl);
    lStrQuery := lStrQuery || '      CONNECT BY PRIOR VUNI.IDEUNI = VUNI.IDESPR ' || lCondicaoIdeUni || ' ) VUNIARV INNER JOIN (SELECT IDEAGD, IDEUNI, IDEPLAACO FROM TAGD ' || lCondicaoTipoAgendamento || ') TAGD ON TAGD.IDEUNI = VUNIARV.IDEUNI ';
    lStrQuery := lStrQuery || '                                                                                                 INNER JOIN TPLAACO ON TPLAACO.IDEPLAACO = TAGD.IDEPLAACO ';
    lStrQuery := lStrQuery || '                                                                                                 INNER JOIN (SELECT TPACTAR.IDEPLAACO, TPACTAR.IDEPACTAR, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.INIPRE, TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, TPACTAR.FREREC, TPACTAR.DURHRA, TPACTAR.PERCON FROM TPACTAR LEFT JOIN TPACTARREP ON TPACTAR.IDEPACTAR = TPACTARREP.IDEPACTAR WHERE TPACTAR.DEL = 0 ' || lCondicaoAcoes1 || ' GROUP BY TPACTAR.IDEPACTAR, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.INIPRE, TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, TPACTAR.IDEPLAACO, TPACTAR.FREREC, TPACTAR.DURHRA, TPACTAR.PERCON ) VPACTAR ON TPLAACO.IDEPLAACO = VPACTAR.IDEPLAACO ';
	lStrQuery := lStrQuery || '                                                                                                 INNER JOIN TUSU ON VPACTAR.IDEUSURES = TUSU.IDEUSU ';
    lStrQuery := lStrQuery || ' GROUP BY TUSU.NME, VUNIARV.SIG, VUNIARV.IDEUNI, TUSU.IDEUSU, VUNIARV.ORD, VUNIARV.LVL ';
    lStrQuery := lStrQuery || ' ORDER BY TUSU.NME, VUNIARV.SIG ';
    
    lTotalCriados := 0;
    lTotalPlanejadasNoPrazo := 0;
    lTotalPlanejadasAtrasada := 0;
    lTotalEmExecucaoNoPrazo := 0;
    lTotalEmExecucaoAtrasada := 0;
    lTotalFinalizadaNoPrazo := 0;
    lTotalFinalizadaAtrasada := 0;

	lSubTotalCriados := 0;
    lSubTotalPlanejadasNoPrazo := 0;
    lSubTotalPlanejadasAtrasada := 0;
    lSubTotalEmExecucaoNoPrazo := 0;
    lSubTotalEmExecucaoAtrasada := 0;
    lSubTotalFinalizadaNoPrazo := 0;
    lSubTotalFinalizadaAtrasada := 0;

    lLastNmeUsu := '0';
    lLastIdeUsu := 0;

   IF CursorRelatorio%ISOPEN THEN
        CLOSE CursorRelatorio;
    END IF;

    OPEN CursorRelatorio FOR lStrQuery;
    LOOP
        FETCH CursorRelatorio INTO lOrd, lNmeUsu, lIdeUsu, lSig, lIdeUni, lLvl, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada;
        EXIT WHEN CursorRelatorio%NOTFOUND;

        IF lNmeUsu <> lLastNmeUsu AND lLastNmeUsu <> '0' AND pExcel = 0 THEN
            lTblTemp.Extend;
            lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrdemGrupoUsuario * 10000, lLastNmeUsu, lLastIdeUsu, '', 0, 0, lSubTotalCriados, lSubTotalPlanejadasNoPrazo, lSubTotalPlanejadasAtrasada, lSubTotalEmExecucaoNoPrazo, lSubTotalEmExecucaoAtrasada, lSubTotalFinalizadaNoPrazo, lSubTotalFinalizadaAtrasada);

            lSubTotalCriados := 0;
            lSubTotalPlanejadasNoPrazo := 0;
			lSubTotalPlanejadasAtrasada := 0;
			lSubTotalEmExecucaoNoPrazo := 0;
			lSubTotalEmExecucaoAtrasada := 0;
			lSubTotalFinalizadaNoPrazo := 0;
			lSubTotalFinalizadaAtrasada := 0;

            lOrdemGrupoUsuario := lOrdemGrupoUsuario + 1;
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrdemGrupoUsuario * 10000 + lOrd, lNmeUsu, lIdeUsu, lSig, lIdeUni, 0, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada);

        lLastNmeUsu := lNmeUsu;
        lLastIdeUsu := lIdeUsu;

        lSubTotalCriados := lSubTotalCriados + lCriados;
		lSubTotalPlanejadasNoPrazo := lSubTotalPlanejadasNoPrazo + lPlanejadasNoPrazo;
        lSubTotalPlanejadasAtrasada := lSubTotalPlanejadasAtrasada + lPlanejadasAtrasada;
        lSubTotalEmExecucaoNoPrazo := lSubTotalEmExecucaoNoPrazo + lEmExecucaoNoPrazo;
        lSubTotalEmExecucaoAtrasada := lSubTotalEmExecucaoAtrasada + lEmExecucaoAtrasada;
        lSubTotalFinalizadaNoPrazo := lSubTotalFinalizadaNoPrazo + lFinalizadaNoPrazo;
        lSubTotalFinalizadaAtrasada := lSubTotalFinalizadaAtrasada + lFinalizadaAtrasada;

        lTotalCriados := lTotalCriados + lCriados;
        lTotalPlanejadasNoPrazo := lTotalPlanejadasNoPrazo + lPlanejadasNoPrazo;
        lTotalPlanejadasAtrasada := lTotalPlanejadasAtrasada + lPlanejadasAtrasada;
        lTotalEmExecucaoNoPrazo := lTotalEmExecucaoNoPrazo + lEmExecucaoNoPrazo;
        lTotalEmExecucaoAtrasada := lTotalEmExecucaoAtrasada + lEmExecucaoAtrasada;
        lTotalFinalizadaNoPrazo := lTotalFinalizadaNoPrazo + lFinalizadaNoPrazo;
        lTotalFinalizadaAtrasada := lTotalFinalizadaAtrasada + lFinalizadaAtrasada;
    END LOOP;

    IF CursorRelatorio%ISOPEN THEN
        CLOSE CursorRelatorio;
    END IF;

    lTblTemp.Extend;
    lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS30(lOrdemGrupoUsuario * 10000, lLastNmeUsu, lLastIdeUsu, '', 0, 0, lSubTotalCriados, lSubTotalPlanejadasNoPrazo, lSubTotalPlanejadasAtrasada, lSubTotalEmExecucaoNoPrazo, lSubTotalEmExecucaoAtrasada, lSubTotalFinalizadaNoPrazo, lSubTotalFinalizadaAtrasada);

    lOrdemGrupoUsuario := lOrdemGrupoUsuario + 1;

    lOrd := 1;

    IF CursorRelatorioOrderNivel1%ISOPEN THEN
        CLOSE CursorRelatorioOrderNivel1;
    END IF;

    OPEN CursorRelatorioOrderNivel1 FOR SELECT * FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELSTATUS30_TABLE)) WHERE CAST(Ord / 10000 AS INTEGER) = Ord / 10000 ORDER BY Criadas DESC;
    LOOP
        FETCH CursorRelatorioOrderNivel1 INTO lOrdemGrupoUsuario, lNmeUsu, lIdeUsu, lSig, lIdeUni, lTotal, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada;
        EXIT WHEN CursorRelatorioOrderNivel1%NOTFOUND;

        lTblTempOrder.Extend;
        lTblTempOrder(lTblTempOrder.LAST) := OBJECT_TMPRELSTATUS30(lOrd, lNmeUsu, lIdeUsu, '', 0, 0, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada);
        lOrd := lOrd + 1;

        IF CursorRelatorioOrderNivel2%ISOPEN THEN
            CLOSE CursorRelatorioOrderNivel2;
        END IF;

        OPEN CursorRelatorioOrderNivel2 FOR SELECT * FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELSTATUS30_TABLE)) WHERE Ord BETWEEN lOrdemGrupoUsuario + 1 AND lOrdemGrupoUsuario + 9999 ORDER BY Criadas DESC;
        LOOP
            FETCH CursorRelatorioOrderNivel2 INTO lOrdemGrupoUsuario, lNmeUsu, lIdeUsu, lSig, lIdeUni, lTotal, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada;
            EXIT WHEN CursorRelatorioOrderNivel2%NOTFOUND;

            lTblTempOrder.Extend;
            lTblTempOrder(lTblTempOrder.LAST) := OBJECT_TMPRELSTATUS30(lOrd, lNmeUsu, lIdeUsu, lSig, lIdeUni, 0, lCriados, lPlanejadasNoPrazo, lPlanejadasAtrasada, lEmExecucaoNoPrazo, lEmExecucaoAtrasada, lFinalizadaNoPrazo, lFinalizadaAtrasada);
            lOrd := lOrd + 1;
        END LOOP;

        IF CursorRelatorioOrderNivel2%ISOPEN THEN
            CLOSE CursorRelatorioOrderNivel2;
        END IF;
    END LOOP;

    IF CursorRelatorioOrderNivel1%ISOPEN THEN
        CLOSE CursorRelatorioOrderNivel1;
    END IF;

    IF pExcel = 0 THEN
        lTblTempOrder.Extend;
        lTblTempOrder(lTblTempOrder.LAST) := OBJECT_TMPRELSTATUS30(lOrdemGrupoUsuario * 10000, 'Total', -1, 'Total', -1, 0, lTotalCriados, lTotalPlanejadasNoPrazo, lTotalPlanejadasAtrasada, lTotalEmExecucaoNoPrazo, lTotalEmExecucaoAtrasada, lTotalFinalizadaNoPrazo, lTotalFinalizadaAtrasada);
    END IF;

    OPEN pRecordSet FOR
	SELECT ROWNUM Id, T.* FROM TABLE (CAST(lTblTempOrder AS OBJECT_TMPRELSTATUS30_TABLE)) T ORDER BY ORD;
    
END;

/* Fun��o     : RelStatusProjetosRes
   Prop�sito  : Retorna os Status dos Projetos sob a Responsabilidade de uma Unidade Gerencial e/ou suas subordinadas at� o 3o n�vel
   Par�metros : pIdeUni-Identificador da Unidade Gerencial
                pSub-Indica se o relat�rio deve retornar dados apenas da UG selecionada ou de suas subordinadas at� o 3o n�vel
                pPerIni-Per�odo de In�cio definido pelo Usu�rio (pode ser nulo)
                pPerFin-Per�odo de T�rmino definido pelo usu�rio (pode ser nulo)
                pIdeUsu-Identificador do Usu�rio respons�vel pelas Solu��es de Problema ou pelas A��es
                pCls-Classifica��o sob as quais ser� feita a pesquisa
   Cria��o    : 22/11/2010 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelStatusProjetosRes(pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls NUMBER, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT, pPortalSim30 INT, pRecordSet OUT tCursorType)
    IS
        CursorRelatorio     tCursorType;
        CursorRelatorioOrderNivel1     tCursorType;
        CursorRelatorioOrderNivel2     tCursorType;

        lTblTemp            OBJECT_TMPRELSTATUS_TABLE := OBJECT_TMPRELSTATUS_TABLE();
        lTblTempOrder       OBJECT_TMPRELSTATUS_TABLE := OBJECT_TMPRELSTATUS_TABLE();

        lLvl                INT;
        lPerIni             DATE := NULL;
        lPerFin             DATE := NULL;

        lHoje               VARCHAR2(50) := 'TO_DATE(''' || TO_CHAR(SYSDATE, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';

        lStrQuery           VARCHAR2(8000) := '';
        lCondicaoProjetos   VARCHAR2(1000) := '';
        lCondicaoEnvolvidos VARCHAR2(1000);

        lOrd                INT;
        lSig                VARCHAR2(50);
        lIdeUsu             NUMBER(13);
        lCriados            INT;
        lAgingMonths        INT;
        lEmAberto           INT;
        lReprogramadas      INT;
        lEmAndamento        INT;
        lEmAtraso           INT;
        lConcluidos         INT;

        lTotal              INT;

        lTotalCriados       INT;
        lTotalAgingMonths   INT;
        lTotalEmAberto      INT;
        lTotalReprogramadas INT;
        lTotalEmAndamento   INT;
        lTotalEmAtraso      INT;
        lTotalConcluidos    INT;

        lSubTotalCriados        INT;
        lSubTotalAgingMonths    INT;
        lSubTotalEmAberto       INT;
        lSubTotalReprogramadas  INT;
        lSubTotalEmAndamento    INT;
        lSubTotalEmAtraso       INT;
        lSubTotalConcluidos     INT;

        lOrdemGrupoUsuario      INT;

        lNmeUsu         NVARCHAR2(100);
        lIdeUni         NUMBER(13);
        lLastNmeUsu     VARCHAR2(100);
        lLastIdeUsu     NUMBER(13);
BEGIN
    IF pSub = 0 THEN
        lLvl := 1;
    ELSE
        lLvl := 3;
    END IF;

    lOrdemGrupoUsuario := 1;
    lCondicaoEnvolvidos := ' ';

    IF NOT pPerIni IS NULL THEN
        lPerIni := pPerIni;
    END IF;

    IF NOT pPerFin IS NULL THEN
        lPerFin := pPerFin;
    END IF;

    IF pCls <> 0 THEN
        IF LENGTH(lCondicaoProjetos) > 0 THEN
            lCondicaoProjetos := lCondicaoProjetos || ' AND ';
        END IF;

        IF pPortalSim30 = 0 THEN
          lCondicaoProjetos := lCondicaoProjetos ||         'TSOLPRB.CLS = ' || TO_CHAR(PCLS);
        ELSE
          lCondicaoProjetos := lCondicaoProjetos ||         'TSOLPRB.IDECLS = ' || TO_CHAR(PCLS);
        END IF;
    END IF;

    IF NOT lPerIni IS NULL THEN
        IF LENGTH(lCondicaoProjetos) > 0 THEN
            lCondicaoProjetos := lCondicaoProjetos || ' AND ';
        END IF;

        lCondicaoProjetos := lCondicaoProjetos ||         '(TSOLPRB.DATABE BETWEEN TO_DATE(''' || TO_CHAR(lPerIni, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TO_DATE(''' || TO_CHAR(lPerFin, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
        lCondicaoProjetos := lCondicaoProjetos ||         ' OR TSOLPRB.DATENCPRE BETWEEN TO_DATE(''' || TO_CHAR(LPERINI, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TO_DATE(''' || TO_CHAR(LPERFIN, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
        lCondicaoProjetos := lCondicaoProjetos ||         ' OR (TSOLPRB.DATABE < TO_DATE(''' || TO_CHAR(lPerIni, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TSOLPRB.DATENCPRE > TO_DATE(''' || TO_CHAR(lPerFin, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')))';
    END IF;

    IF LENGTH(lCondicaoProjetos) > 0 THEN
            lCondicaoProjetos := lCondicaoProjetos || ' AND ';
    END IF;
    
    IF pPortalSim30 = 0 THEN
      lCondicaoProjetos := lCondicaoProjetos ||         'TSOLPRB.TYP = ''PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblemaAntiga'' ';
    ELSE
      lCondicaoProjetos := lCondicaoProjetos ||         'TSOLPRB.TYP = ''PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'' ';
	  lCondicaoProjetos := lCondicaoProjetos ||         'AND TSOLPRB.IDESOLPRBSUP IS NULL ';
	END IF;

    lCondicaoProjetos := lCondicaoProjetos ||         'AND TSOLPRB.DATCNC IS NULL ';
	
    IF NOT pIdeUsu IS NULL THEN
        lCondicaoEnvolvidos := ' AND TSOLPRBPAR.IDEUSU = ' || TO_CHAR(pIdeUsu);
    END IF;

    lStrQuery :=             'SELECT VUNIARV.ORD, ';
    lStrQuery := lStrQuery ||       'TUSU.NME, ';
    lStrQuery := lStrQuery ||       'TUSU.IDEUSU, ';
    lStrQuery := lStrQuery ||       'TRIM(VUNIARV.SIG), ';
    lStrQuery := lStrQuery ||       'VUNIARV.IDEUNI, ';
    lStrQuery := lStrQuery ||       'COUNT(TSOLPRB.IDESOLPRB) Criados, ';
    IF pPortalSim30 = 0 THEN
      lStrQuery := lStrQuery ||       'AVG(TRUNC((CASE WHEN TSOLPRB.DATENC IS NULL THEN ' || lHoje || ' ELSE TSOLPRB.DATENC END - TSOLPRB.DATABE)/30)) AgingMonths, ';
      lStrQuery := lStrQuery ||       '0 EmAberto, ';
      lStrQuery := lStrQuery ||       '0 Reprogramadas, ';
      lStrQuery := lStrQuery ||       'SUM(CASE WHEN NOT TSOLPRB.DATABE IS NULL AND TSOLPRB.DATENC IS NULL AND (TSOLPRB.DATENCPRE IS NULL OR TSOLPRB.DATENCPRE >= ' || lHoje || ') THEN 1 ELSE 0 END) EmAndamento, ';
      lStrQuery := lStrQuery ||       'SUM(CASE WHEN TSOLPRB.DATENCPRE < ' || lHoje || ' AND TSOLPRB.DATENC IS NULL THEN 1 ELSE 0 END) EmAtraso, ';
      lStrQuery := lStrQuery ||       'SUM(CASE WHEN TSOLPRB.DATENC IS NULL THEN 0 ELSE 1 END) Concluidos ';
    ELSE    
      lStrQuery := lStrQuery ||        '0 AgingMonths, '; --FinalizadaAtrasada
      lStrQuery := lStrQuery ||        '0 EmAberto, '; --EmExecucaoAtrasada
      lStrQuery := lStrQuery ||        '0 Reprogramadas, '; --PlanejadasAtrasada    
      lStrQuery := lStrQuery ||        'SUM(CASE WHEN NOT TSOLPRB.DATABE IS NULL AND TSOLPRB.DATENC IS NULL AND (TSOLPRB.DATENCPRE IS NULL OR TSOLPRB.DATENCPRE >= ' || lHoje || ') THEN 1 ELSE 0 END) EmAndamento, '; --PlanejadasNoPrazo
      lStrQuery := lStrQuery ||        'SUM(CASE WHEN TSOLPRB.DATENCPRE < ' || lHoje || ' AND TSOLPRB.DATENC IS NULL THEN 1 ELSE 0 END) EmAtraso, '; --EmExecucaoNoPrazo
      lStrQuery := lStrQuery ||        'SUM(CASE WHEN TSOLPRB.DATENC IS NULL THEN 0 ELSE 1 END) Concluidos '; --FinalizadaNoPrazo
    END IF;
    
    lStrQuery := lStrQuery ||  ' FROM (SELECT VUNI.IDEUNI, ';
    
    IF NOT pIdeUni IS NULL THEN
       lStrQuery := lStrQuery ||  '             SUBSTR((RPAD('' '', (LEVEL - 1) * 3, '' '') || VUNI.SIG), 1, 50) AS SIG, ';
       lStrQuery := lStrQuery ||  '             LEVEL LVL, ';
    ELSE
       lStrQuery := lStrQuery ||  '             VUNI.SIG SIG, ';
       lStrQuery := lStrQuery ||  '             0 LVL, ';
    END IF;
    
	 lStrQuery := lStrQuery ||  '             ROWNUM ORD ';
    lStrQuery := lStrQuery ||  '        FROM  TUNI VUNI ';
    lStrQuery := lStrQuery ||  '             INNER JOIN (SELECT IDEUNI FROM TABLE(RetornarUnidadesPorUsuario(' || TO_CHAR(pIdeUsuLogado) || '))) TUSUUNI ON TUNI.IDEUNI = TUSUUNI.IDEUNI ';
    lStrQuery := lStrQuery ||  '       WHERE TUNI.IDEUNITYP IN (SELECT TUNITYP.IDEUNITYP FROM TUNITYP WHERE TUNITYP.TYP = 1) ';
    
    IF NOT pIdeUni IS NULL THEN
      lStrQuery := lStrQuery ||  '         AND LEVEL <= ' || TO_CHAR(lLvl);
      lStrQuery := lStrQuery ||  '      CONNECT BY PRIOR VUNI.IDEUNI = VUNI.IDESPR START WITH VUNI.IDEUNI = ' || TO_CHAR(PIDEUNI);
    END IF;
    
    IF pPortalSim30 = 0 THEN
        lStrQuery := lStrQuery ||  ') VUNIARV LEFT JOIN (SELECT * FROM TSOLPRB ';
        lStrQuery := lStrQuery ||                      ' WHERE TSOLPRB.ETP <> 90 ';

        IF LENGTH(lCondicaoProjetos) > 0 THEN
            lStrQuery := lStrQuery || ' AND ' || lCondicaoProjetos;
        END IF;
        lStrQuery := lStrQuery ||  ') TSOLPRB ON (TSOLPRB.IDEUNI = VUNIARV.IDEUNI OR TSOLPRB.IDEUNIREL = VUNIARV.IDEUNI)';
        LSTRQUERY := LSTRQUERY || '  INNER JOIN (SELECT * FROM TSOLPRBPAR WHERE ORDFUN = 1 ' || LCONDICAOENVOLVIDOS || ' ) TSOLPRBPAR ON TSOLPRB.IDESOLPRB = TSOLPRBPAR.IDESOLPRB '; 
    ELSE
        lStrQuery := lStrQuery ||  ') VUNIARV INNER JOIN TSOLPRB ON VUNIARV.IDEUNI = TSOLPRB.IDEUNI ';
        
        LSTRQUERY := LSTRQUERY || '  INNER JOIN (   SELECT TSOLPRBPAR.* FROM TSOLPRBPAR ';
        LSTRQUERY := LSTRQUERY || '             INNER JOIN TMETSOLPRBFUN ON TSOLPRBPAR.IDEMETSOLPRBFUN = TMETSOLPRBFUN.IDEMETSOLPRBFUN  ';
        LSTRQUERY := LSTRQUERY || '             WHERE TMETSOLPRBFUN.FUNPRN = 1 ' || LCONDICAOENVOLVIDOS || ' ) TSOLPRBPAR ON TSOLPRB.IDESOLPRB = TSOLPRBPAR.IDESOLPRB ';
    END IF;
 
    lStrQuery := lStrQuery || ' INNER JOIN TUSU ON TSOLPRBPAR.IDEUSU = TUSU.IDEUSU ';
    
    IF PPORTALSIM30 <> 0 THEN
        IF LENGTH(lCondicaoProjetos) > 0 THEN
            lStrQuery := lStrQuery || ' AND ' || lCondicaoProjetos;
        END IF;
    END IF;
    lStrQuery := lStrQuery || ' GROUP BY TUSU.NME, VUNIARV.SIG, VUNIARV.IDEUNI, VUNIARV.ORD, TUSU.IDEUSU ';
    lStrQuery := lStrQuery || ' ORDER BY TUSU.NME, VUNIARV.SIG ';

    lTotalCriados := 0;
    lTotalAgingMonths := 0;
    lTotalEmAberto := 0;
    lTotalReprogramadas := 0;
    lTotalEmAndamento := 0;
    lTotalEmAtraso := 0;
    lTotalConcluidos := 0;

    lSubTotalCriados := 0;
    lSubTotalAgingMonths := 0;
    lSubTotalEmAberto := 0;
    lSubTotalReprogramadas := 0;
    lSubTotalEmAndamento := 0;
    lSubTotalEmAtraso := 0;
    lSubTotalConcluidos := 0;

    lLastNmeUsu := '0';
    lLastIdeUsu := 0;

    IF CursorRelatorio%ISOPEN THEN
        CLOSE CursorRelatorio;
    END IF;

    OPEN CursorRelatorio FOR lStrQuery;
    LOOP
        FETCH CursorRelatorio INTO lOrd, lNmeUsu, lIdeUsu, lSig, lIdeUni, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos;
        EXIT WHEN CursorRelatorio%NOTFOUND;

        IF lNmeUsu <> lLastNmeUsu AND lLastNmeUsu <> '0' THEN
            lTblTemp.Extend;
            lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrdemGrupoUsuario * 10000, lLastNmeUsu, lLastIdeUsu, '', 0, 0, lSubTotalCriados, lSubTotalAgingMonths / CASE WHEN lSubTotalCriados = 0 THEN NULL ELSE lSubTotalCriados END, lSubTotalEmAberto, lSubTotalReprogramadas, lSubTotalEmAndamento, lSubTotalEmAtraso, lSubTotalConcluidos);

            lSubTotalCriados := 0;
            lSubTotalAgingMonths := 0;
            lSubTotalEmAberto := 0;
            lSubTotalReprogramadas := 0;
            lSubTotalEmAndamento := 0;
            lSubTotalEmAtraso := 0;
            lSubTotalConcluidos := 0;

            lOrdemGrupoUsuario := lOrdemGrupoUsuario + 1;
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrdemGrupoUsuario * 10000 + lOrd, lNmeUsu, lIdeUsu, lSig, lIdeUni, 0, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos);

        lLastNmeUsu := lNmeUsu;
        lLastIdeUsu := lIdeUsu;

        lSubTotalCriados := lSubTotalCriados + lCriados;
        lSubTotalAgingMonths := lSubTotalAgingMonths + (lAgingMonths * lCriados);
        lSubTotalEmAberto := lSubTotalEmAberto + lEmAberto;
        lSubTotalReprogramadas := lSubTotalReprogramadas + lReprogramadas;
        lSubTotalEmAndamento := lSubTotalEmAndamento + lEmAndamento;
        lSubTotalEmAtraso := lSubTotalEmAtraso + lEmAtraso;
        lSubTotalConcluidos := lSubTotalConcluidos + lConcluidos;

        lTotalCriados := lTotalCriados + lCriados;
        lTotalAgingMonths := lTotalAgingMonths + (lAgingMonths * lCriados);
        lTotalEmAberto := lTotalEmAberto + lEmAberto;
        lTotalReprogramadas := lTotalReprogramadas + lReprogramadas;
        lTotalEmAndamento := lTotalEmAndamento + lEmAndamento;
        lTotalEmAtraso := lTotalEmAtraso + lEmAtraso;
        lTotalConcluidos := lTotalConcluidos + lConcluidos;
    END LOOP;

    IF CursorRelatorio%ISOPEN THEN
        CLOSE CursorRelatorio;
    END IF;
	
	IF lSubTotalCriados > 0 THEN
		lTblTemp.Extend;
		lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrdemGrupoUsuario * 10000, lLastNmeUsu, lLastIdeUsu, '', 0, 0, lSubTotalCriados, lSubTotalAgingMonths / CASE WHEN lSubTotalCriados = 0 THEN NULL ELSE lSubTotalCriados END, lSubTotalEmAberto, lSubTotalReprogramadas, lSubTotalEmAndamento, lSubTotalEmAtraso, lSubTotalConcluidos);
	END IF;

    lOrdemGrupoUsuario := lOrdemGrupoUsuario + 1;

    lOrd := 1;

    IF CursorRelatorioOrderNivel1%ISOPEN THEN
        CLOSE CursorRelatorioOrderNivel1;
    END IF;

    OPEN CursorRelatorioOrderNivel1 FOR SELECT * FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELSTATUS_TABLE)) WHERE CAST(Ord / 10000 AS INTEGER) = Ord / 10000 ORDER BY NMEUSU;
    LOOP
        FETCH CursorRelatorioOrderNivel1 INTO lOrdemGrupoUsuario, lNmeUsu, lIdeUsu, lSig, lIdeUni, lTotal, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos;
        EXIT WHEN CursorRelatorioOrderNivel1%NOTFOUND;

        IF pExcel = 0 THEN
            lTblTempOrder.Extend;
            lTblTempOrder(lTblTempOrder.LAST) := OBJECT_TMPRELSTATUS(lOrd, lNmeUsu, lIdeUsu, '', 0, 0, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos);
            lOrd := lOrd + 1;
        END IF;

        IF CursorRelatorioOrderNivel2%ISOPEN THEN
            CLOSE CursorRelatorioOrderNivel2;
        END IF;

        OPEN CursorRelatorioOrderNivel2 FOR SELECT * FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELSTATUS_TABLE)) WHERE Ord BETWEEN lOrdemGrupoUsuario + 1 AND lOrdemGrupoUsuario + 9999 ORDER BY SIG;
        LOOP
            FETCH CursorRelatorioOrderNivel2 INTO lOrdemGrupoUsuario, lNmeUsu, lIdeUsu, lSig, lIdeUni, lTotal, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos;
            EXIT WHEN CursorRelatorioOrderNivel2%NOTFOUND;

            lTblTempOrder.Extend;
            lTblTempOrder(lTblTempOrder.LAST) := OBJECT_TMPRELSTATUS(lOrd, lNmeUsu, lIdeUsu, lSig, lIdeUni, 0, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos);
            lOrd := lOrd + 1;
        END LOOP;

        IF CursorRelatorioOrderNivel2%ISOPEN THEN
            CLOSE CursorRelatorioOrderNivel2;
        END IF;
    END LOOP;

    IF CursorRelatorioOrderNivel1%ISOPEN THEN
        CLOSE CursorRelatorioOrderNivel1;
    END IF;

    IF pExcel = 0 AND lTotalCriados > 0 THEN
        lTblTempOrder.Extend;
        lTblTempOrder(lTblTempOrder.LAST) := OBJECT_TMPRELSTATUS(lOrdemGrupoUsuario * 10000, 'Total', 0, 'Total', 0, 0, lTotalCriados, lTotalAgingMonths / CASE WHEN lTotalCriados = 0 THEN NULL ELSE lTotalCriados END, lTotalEmAberto, lTotalReprogramadas, lTotalEmAndamento, lTotalEmAtraso, lTotalConcluidos);
    END IF;

    OPEN pRecordSet FOR
    SELECT ROWNUM Id, 
      T.*,
      EmAberto EMEXECUCAOATRASADA,
      EmAtraso EMEXECUCAONOPRAZO,
      Reprogramadas PLANEJADASATRASADA,
      EmAndamento PLANEJADASNOPRAZO,
      AgingMonths FINALIZADANOPRAZO,
      Concluidos FINALIZADAATRASADA
    FROM TABLE (CAST(lTblTempOrder AS OBJECT_TMPRELSTATUS_TABLE)) T ORDER BY ORD;

END;

/* Fun��o     : RelStatusAcoesRes
   Prop�sito  : Retorna os Status das Acoes sob a Responsabilidade de uma Unidade Gerencial e/ou suas subordinadas at� o 3o n�vel
   Par�metros : pIdeUni-Identificador da Unidade Gerencial
                pSub-Indica se o relat�rio deve retornar dados apenas da UG selecionada ou de suas subordinadas at� o 3o n�vel
                pPerIni-Per�odo de In�cio definido pelo Usu�rio (pode ser nulo)
                pPerFin-Per�odo de T�rmino definido pelo usu�rio (pode ser nulo)
                pIdeUsu-Identificador do Usu�rio respons�vel pelas Solu��es de Problema ou pelas A��es
                pCls-Classifica��o sob as quais ser� feita a pesquisa
   Cria��o    : 22/11/2010 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelStatusAcoesRes(pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls NUMBER, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT, pPortalSim30 INT, pRecordSet OUT tCursorType)
    IS
        CursorRelatorio                tCursorType;
        CursorRelatorioOrderNivel1     tCursorType;
        CursorRelatorioOrderNivel2     tCursorType;

        lTblTemp            OBJECT_TMPRELSTATUS_TABLE := OBJECT_TMPRELSTATUS_TABLE();
        lTblTempOrder       OBJECT_TMPRELSTATUS_TABLE := OBJECT_TMPRELSTATUS_TABLE();

        lLvl                INT;
        lPerIni             DATE := NULL;
        lPerFin             DATE := NULL;

        lHoje               VARCHAR2(50) := 'TO_DATE(''' || TO_CHAR(SYSDATE, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';

        lStrQuery           VARCHAR2(8000) := '';
        lCondicaoAcoes1     VARCHAR2(1000) := '';
        lCondicaoAcoes2     VARCHAR2(1000) := '';

        lCalculoSubtotal    INT := 0;

        lOrd                INT;
        lOrdFinal           INT;
        lSig                VARCHAR2(50);
        lIdeUni             NUMBER(13);
        lCriados            INT;
        lAgingMonths        INT;
        lEmAberto           INT;
        lReprogramadas      INT;
        lEmAndamento        INT;
        lEmAtraso           INT;
        lConcluidos         INT;

        lTotal              INT;

        lTotalCriados       INT;
        lTotalAgingMonths   INT;
        lTotalEmAberto      INT;
        lTotalReprogramadas INT;
        lTotalEmAndamento   INT;
        lTotalEmAtraso      INT;
        lTotalConcluidos    INT;

        lSubTotalCriados        INT;
        lSubTotalAgingMonths    INT;
        lSubTotalEmAberto       INT;
        lSubTotalReprogramadas  INT;
        lSubTotalEmAndamento    INT;
        lSubTotalEmAtraso       INT;
        lSubTotalConcluidos     INT;

        lOrdemGrupoUsuario      INT;

        lNmeUsu             NVARCHAR2(100);
        lIdeUsu             NUMBER(13);
        lLastNmeUsu         VARCHAR2(100);
        lLastIdeUsu         NUMBER(13);

BEGIN
    IF pSub = 0 THEN
        lLvl := 1;
    ELSE
        lLvl := 3;
    END IF;

    lOrdemGrupoUsuario := 1;

    IF NOT pPerIni IS NULL THEN
        lPerIni := pPerIni;
    END IF;

    IF NOT pPerFin IS NULL THEN
        lPerFin := pPerFin;
    END IF;

    IF pCls <> 0 THEN
        IF LENGTH(lCondicaoAcoes2) > 0 THEN
            lCondicaoAcoes2 := lCondicaoAcoes2 || ' AND ';
        END IF;

         IF pPortalSim30 = 0 THEN
          lCondicaoAcoes2 := lCondicaoAcoes2 ||         'TSOLPRB.CLS = ' || TO_CHAR(PCLS);
        ELSE
          lCondicaoAcoes2 := lCondicaoAcoes2 ||         'TSOLPRB.IDECLS = ' || TO_CHAR(PCLS);
        END IF;
    END IF;

    IF LENGTH(lCondicaoAcoes2) > 0 THEN
            lCondicaoAcoes2 := lCondicaoAcoes2 || ' AND ';
    END IF;
    
    IF pPortalSim30 = 0 THEN
       lCondicaoAcoes2 := lCondicaoAcoes2 ||         'TSOLPRB.TYP = ''PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblemaAntiga'' ';
    ELSE
       lCondicaoAcoes2 := lCondicaoAcoes2 ||         'TSOLPRB.TYP = ''PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'' ';
    END IF;

	lCondicaoAcoes2 := lCondicaoAcoes2 ||         ' AND TSOLPRB.DATCNC IS NULL  ';

    IF NOT lPerIni IS NULL THEN
        lCondicaoAcoes1 := lCondicaoAcoes1 || ' AND (TPACTAR.INIPRE BETWEEN TO_DATE(''' || TO_CHAR(LPERINI, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TO_DATE(''' || TO_CHAR(LPERFIN, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
        lCondicaoAcoes1 := lCondicaoAcoes1 || '      OR TPACTAR.FIMPRE BETWEEN TO_DATE(''' || TO_CHAR(LPERINI, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TO_DATE(''' || TO_CHAR(LPERFIN, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
        lCondicaoAcoes1 := lCondicaoAcoes1 || '      OR (TPACTAR.INIPRE < TO_DATE(''' || TO_CHAR(lPerIni, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TPACTAR.FIMPRE > TO_DATE(''' || TO_CHAR(lPerFin, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')))';
   END IF;

    IF NOT pIdeUsu IS NULL THEN
        lCondicaoAcoes1 := lCondicaoAcoes1 || ' AND TPACTAR.IDEUSURES = ' || TO_CHAR(pIdeUsu);
    END IF;

    lStrQuery :=              'SELECT VUNIARV.ORD, ';
	
    IF pPortalSim30 = 0 THEN
      lStrQuery := lStrQuery ||        'CASE WHEN VPACTAR.IDEUSURES IS NULL THEN COALESCE(VPACTAR.NmeUsuRes, CAST('''' as VARCHAR2(100))) || '' (Terceiro)'' ELSE TUSU.Nme END NME , ';
      lStrQuery := lStrQuery ||        'CASE WHEN VPACTAR.IDEUSURES IS NULL THEN -1 ELSE TUSU.IDEUSU END IDEUSU , ';
    ELSE
      lStrQuery := lStrQuery ||        'TUSU.NME, ';
      lStrQuery := lStrQuery ||        'TUSU.IDEUSU, ';
    END IF;
  
    lStrQuery := lStrQuery ||        'VUNIARV.SIG, ';
    lStrQuery := lStrQuery ||        'VUNIARV.IdeUni, ';
    lStrQuery := lStrQuery ||        'VUNIARV.LVL, ';
    lStrQuery := lStrQuery ||        'COUNT(VPACTAR.IDEPACTAR) Criados, ';
    IF pPortalSim30 = 0 THEN
        lStrQuery := lStrQuery ||        '0 AgingMonths, ';
        lStrQuery := lStrQuery ||        'SUM(VPACTAR.NUMREP) Reprogramadas, ';
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN (VPACTAR.INIPRE IS NULL OR (VPACTAR.INIPRE >= ' || lHoje || ' AND VPACTAR.INIREA IS NULL)) AND VPACTAR.FIMPRE >= ' || lHoje || ' AND VPACTAR.FIMREA IS NULL THEN 1 ELSE 0 END) EmAberto, ';
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN (VPACTAR.ACAREC = 0 AND NOT VPACTAR.INIPRE IS NULL AND NOT VPACTAR.INIREA IS NULL AND VPACTAR.FIMPRE >= ' || lHoje || ' AND VPACTAR.FIMREA IS NULL) OR (VPACTAR.ACAREC <> 0 AND VPACTAR.PRXEXCREC >= ' || lHoje || ' AND VPACTAR.FIMREA IS NULL) THEN 1 ELSE 0 END) EmAndamento, ';
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN (VPACTAR.INIPRE < ' || lHoje || ' AND VPACTAR.INIREA IS NULL AND VPACTAR.FIMREA IS NULL) OR (VPACTAR.ACAREC = 0 AND VPACTAR.FIMPRE < ' || lHoje || ' AND VPACTAR.FIMREA IS NULL) OR (VPACTAR.ACAREC <> 0 AND VPACTAR.PRXEXCREC < ' || lHoje || ' AND VPACTAR.FIMREA IS NULL) THEN 1 ELSE 0 END) EmAtraso, ';
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN NOT VPACTAR.FIMREA IS NULL THEN 1 ELSE 0 END) Concluidos ';
    ELSE
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE >= ' || lHoje || ' THEN 1 ELSE 0 END) Reprogramadas, '; -- PlanejadaNoPrazo
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE < ' || lHoje || ' THEN 1 ELSE 0 END) EmAndamento, '; -- PlanejadaAtrasada
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, SYSDATE)) > VPACTAR.PERCON  THEN 1 ELSE 0 END) END) EmAberto, '; -- EmAndamentoAtrasada
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, SYSDATE)) <= VPACTAR.PERCON THEN 1 ELSE 0 END) END) AgingMonths, '; -- EmAndamentoNoPrazo
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA > VPACTAR.FIMPRE THEN 1 ELSE 0 END) EmAtraso, '; --FinalizadaAtrasada
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA <= VPACTAR.FIMPRE THEN 1 ELSE 0 END) Concluidos '; --FinalizadaNoPrazo
    END IF;
    lStrQuery := lStrQuery ||  'FROM (SELECT VUNI.IDEUNI, ';
    
	 IF NOT pIdeUni IS NULL THEN
	   lStrQuery := lStrQuery ||  '             SUBSTR((RPAD('' '', (LEVEL - 1) * 3, '' '') || VUNI.SIG), 1, 50) AS SIG, ';
      lStrQuery := lStrQuery ||  '             LEVEL LVL, ';
    ELSE
      lStrQuery := lStrQuery ||  '             VUNI.SIG, ';
      lStrQuery := lStrQuery ||  '             0 LVL, ';
    END IF;

    lStrQuery := lStrQuery ||  '             ROWNUM ORD ';
    lStrQuery := lStrQuery ||  '        FROM  TUNI VUNI ';
    lStrQuery := lStrQuery ||  '             INNER JOIN (SELECT IDEUNI FROM TABLE(RetornarUnidadesPorUsuario(' || TO_CHAR(pIdeUsuLogado) || '))) TUSUUNI ON TUNI.IDEUNI = TUSUUNI.IDEUNI ';
    lStrQuery := lStrQuery ||  '       WHERE TUNI.IDEUNITYP IN (SELECT TUNITYP.IDEUNITYP FROM TUNITYP WHERE TUNITYP.TYP = 1) ';
    
    IF NOT pIdeUni IS NULL THEN
      lStrQuery := lStrQuery ||  '         AND LEVEL <= ' || TO_CHAR(lLvl);
      lStrQuery := lStrQuery ||  '      CONNECT BY PRIOR VUNI.IDEUNI = VUNI.IDESPR ';
      lStrQuery := lStrQuery ||  '      START WITH VUNI.IDEUNI = ' || TO_CHAR(pIdeUni) ;
    END IF;
    
	IF PPORTALSIM30 = 0 THEN
        lStrQuery := lStrQuery ||     ' ) VUNIARV LEFT JOIN (SELECT * FROM TSOLPRB ';
        lStrQuery := lStrQuery ||     ' WHERE TSOLPRB.ETP <> 90 ';

        
        IF LENGTH(lCondicaoAcoes2) > 0 THEN
          lStrQuery := lStrQuery ||     ' AND ' || lCondicaoAcoes2;
        END IF;
        
        lStrQuery := lStrQuery ||   ') TSOLPRB ON VUNIARV.IDEUNI = TSOLPRB.IDEUNI ';
    ELSE
        lStrQuery := lStrQuery ||     ' ) VUNIARV INNER JOIN TSOLPRB ON VUNIARV.IDEUNI = TSOLPRB.IDEUNI ';
    END IF;
	
    IF PPORTALSIM30 = 0 THEN

			 lStrQuery := lStrQuery ||   'LEFT JOIN (SELECT tFer.IdeFer, tFer.Nme, tSolPrbPas.IdeSolPrb, TSOLPRBPAS.IDESOLPRBPAS
																  FROM tFer
															 INNER JOIN tSolPrbPas ON tFer.IdeSolPrbPas = tSolPrbPas.IdeSolPrbPas
															 WHERE tFer.TipFer = 32
															 UNION
															 SELECT tFer.IdeFer, tFer.Nme, tSolPrb.IdeSolPrb, TFER.IDESOLPRBPAS
															 FROM tSolPrb
															 INNER JOIN tLinRac ON tSolPrb.IdeSolPrb = tLinRac.IdeSolPrb
															 INNER JOIN tRac ON tRac.IdeLinRac = tLinRac.IdeLinRac
															 INNER JOIN tFer ON tFer.IdeRac = tRac.IdeRac
															 WHERE tFer.TipFer = 32) tFer ON TSOLPRB.IdeSolPrb = TFER.IdeSolPrb ';
			 lStrQuery := lStrQuery || ' INNER JOIN (SELECT TPACTAR.IDEPACTAR, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, CASE WHEN TPACTAR.IDEUSURES IS NULL THEN TPACTAR.NMEUSURES ELSE NULL END NMEUSURES, TPACTAR.INIPRE, TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, TPACTAR.PERCON, TPACTAR.DURHRA, COUNT(TPACTARREP.IDEPACTARREP) NUMREP FROM TPACTAR LEFT JOIN TPACTARREP ON TPACTAR.IDEPACTAR = TPACTARREP.IDEPACTAR WHERE TPACTAR.DEL = 0 AND TPACTAR.FIMPRE IS NOT NULL ' || lCondicaoAcoes1 || ' GROUP BY TPACTAR.IDEPACTAR, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, CASE WHEN TPACTAR.IDEUSURES IS NULL THEN TPACTAR.NMEUSURES ELSE NULL END, TPACTAR.INIPRE, TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, TPACTAR.PERCON, TPACTAR.DURHRA) VPACTAR ON TFER.IDEFER = VPACTAR.IDEFER ';
			 

	ELSE
		LSTRQUERY := LSTRQUERY || ' INNER JOIN TSOLPRBPAS ON TSOLPRBPAS.IDESOLPRB = TSOLPRB.IDESOLPRB
                                INNER JOIN TFER ON TFER.IDESOLPRBPAS = TSOLPRBPAS.IDESOLPRBPAS
                                INNER JOIN TPLAACO ON TPLAACO.IDEPLAACO = TFER.IDEPLAACO 
                                INNER JOIN (SELECT TPACTAR.FREREC, TPACTAR.IDEPACTAR, TPACTAR.IdePlaAco, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, CASE WHEN TPACTAR.IDEUSURES IS NULL THEN TPACTAR.NMEUSURES ELSE NULL END NMEUSURES, TPACTAR.INIPRE, TPACTAR.INIREA,
                                            TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC
                                            FROM TPACTAR
                                              INNER JOIN TPLAACO ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
                                            WHERE TPACTAR.DEL = 0 
                                                AND TPACTAR.FIMPRE IS NOT NULL  ' || lCondicaoAcoes1 || ' 
                                            GROUP BY TPACTAR.IDEPACTAR,  TPACTAR.IdePlaAco, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.NMEUSURES, TPACTAR.INIPRE, TPACTAR.INIREA, 
                                                     TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, TPACTAR.FREREC) VPACTAR ON TFER.IdePlaAco = VPACTAR.IdePlaAco ';
	END IF;
	 
	  lStrQuery := lStrQuery || ' LEFT JOIN TUSU ON VPACTAR.IDEUSURES = TUSU.IDEUSU ';
    
    IF PPORTALSIM30 <> 0 THEN
        lStrQuery := lStrQuery ||     ' WHERE TSOLPRB.ETP <> 90 ';
        
        IF LENGTH(lCondicaoAcoes2) > 0 THEN
          lStrQuery := lStrQuery ||     ' AND ' || lCondicaoAcoes2;
        END IF;
    END IF;
    
    IF PPORTALSIM30 = 0 THEN
      lStrQuery := lStrQuery || ' GROUP BY TUSU.NME, VPACTAR.IDEUSURES, VPACTAR.NMEUSURES, VUNIARV.SIG, VUNIARV.IDEUNI, TUSU.IDEUSU, VUNIARV.ORD, VUNIARV.LVL ';
    ELSE
      --lStrQuery := lStrQuery || ' GROUP BY TUSU.NME, VUNIARV.SIG, VUNIARV.IDEUNI, TUSU.IDEUSU, VUNIARV.ORD, VUNIARV.LVL ';
        lStrQuery := lStrQuery || ' GROUP BY TUSU.NME, VPACTAR.IDEUSURES, VPACTAR.NMEUSURES, VUNIARV.SIG, VUNIARV.IDEUNI, TUSU.IDEUSU, VUNIARV.ORD, VUNIARV.LVL ';
    END IF;
    
    lStrQuery := lStrQuery || ' ORDER BY TUSU.NME, VUNIARV.SIG ';
    
    lTotalCriados := 0;
    lTotalAgingMonths := 0;
    lTotalEmAberto := 0;
    lTotalReprogramadas := 0;
    lTotalEmAndamento := 0;
    lTotalEmAtraso := 0;
    lTotalConcluidos := 0;

    lSubTotalCriados := 0;
    lSubTotalEmAberto := 0;
    lSubTotalReprogramadas := 0;
    lSubTotalEmAndamento := 0;
    lSubTotalEmAtraso := 0;
    lSubTotalConcluidos := 0;

    lLastNmeUsu := '0';
    lLastIdeUsu := 0;

    IF CursorRelatorio%ISOPEN THEN
        CLOSE CursorRelatorio;
    END IF;

    OPEN CursorRelatorio FOR lStrQuery;
    LOOP
        FETCH CursorRelatorio INTO lOrd, lNmeUsu, lIdeUsu, lSig, lIdeUni, lLvl, lCriados, lAgingMonths, lReprogramadas, lEmAberto, lEmAndamento, lEmAtraso, lConcluidos;
        EXIT WHEN CursorRelatorio%NOTFOUND;

        IF lNmeUsu <> lLastNmeUsu AND lLastNmeUsu <> '0' THEN
            lTblTemp.Extend;
            lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrdemGrupoUsuario * 10000, lLastNmeUsu, lLastIdeUsu, '', 0, 0, lSubTotalCriados, lSubTotalAgingMonths, lSubTotalEmAberto, lSubTotalReprogramadas, lSubTotalEmAndamento, lSubTotalEmAtraso, lSubTotalConcluidos);

            lSubTotalCriados := 0;
            lSubTotalAgingMonths := 0;
            lSubTotalEmAberto := 0;
            lSubTotalReprogramadas := 0;
            lSubTotalEmAndamento := 0;
            lSubTotalEmAtraso := 0;
            lSubTotalConcluidos := 0;

            lOrdemGrupoUsuario := lOrdemGrupoUsuario + 1;
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrdemGrupoUsuario * 10000 + lOrd, lNmeUsu, lIdeUsu, lSig, lIdeUni, 0, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos);

        lLastNmeUsu := lNmeUsu;
        lLastIdeUsu := lIdeUsu;

        lSubTotalCriados := lSubTotalCriados + lCriados;
        lSubTotalAgingMonths := lSubTotalAgingMonths + (lAgingMonths * lCriados);
        lSubTotalEmAberto := lSubTotalEmAberto + lEmAberto;
        lSubTotalReprogramadas := lSubTotalReprogramadas + lReprogramadas;
        lSubTotalEmAndamento := lSubTotalEmAndamento + lEmAndamento;
        lSubTotalEmAtraso := lSubTotalEmAtraso + lEmAtraso;
        lSubTotalConcluidos := lSubTotalConcluidos + lConcluidos;

        lTotalCriados := lTotalCriados + lCriados;
        lTotalAgingMonths := lTotalAgingMonths + (lAgingMonths * lCriados);
        lTotalEmAberto := lTotalEmAberto + lEmAberto;
        lTotalReprogramadas := lTotalReprogramadas + lReprogramadas;
        lTotalEmAndamento := lTotalEmAndamento + lEmAndamento;
        lTotalEmAtraso := lTotalEmAtraso + lEmAtraso;
        lTotalConcluidos := lTotalConcluidos + lConcluidos;
    END LOOP;

    IF CursorRelatorio%ISOPEN THEN
        CLOSE CursorRelatorio;
    END IF;

	IF lSubTotalCriados > 0 THEN
		lTblTemp.Extend;
		lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrdemGrupoUsuario * 10000, lLastNmeUsu, lLastIdeUsu, '', 0, 0, lSubTotalCriados, lSubTotalAgingMonths / CASE WHEN lSubTotalCriados = 0 THEN NULL ELSE lSubTotalCriados END, lSubTotalEmAberto, lSubTotalReprogramadas, lSubTotalEmAndamento, lSubTotalEmAtraso, lSubTotalConcluidos);
	END IF;

    lOrdemGrupoUsuario := lOrdemGrupoUsuario + 1;

    lOrd := 1;

    IF CursorRelatorioOrderNivel1%ISOPEN THEN
        CLOSE CursorRelatorioOrderNivel1;
    END IF;

    OPEN CursorRelatorioOrderNivel1 FOR SELECT * FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELSTATUS_TABLE)) WHERE CAST(Ord / 10000 AS INTEGER) = Ord / 10000 ORDER BY NMEUSU;
    LOOP
        FETCH CursorRelatorioOrderNivel1 INTO lOrdemGrupoUsuario, lNmeUsu, lIdeUsu, lSig, lIdeUni, lTotal, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos;
        EXIT WHEN CursorRelatorioOrderNivel1%NOTFOUND;

        IF pExcel = 0 THEN
            lTblTempOrder.Extend;
            lTblTempOrder(lTblTempOrder.LAST) := OBJECT_TMPRELSTATUS(lOrd, lNmeUsu, lIdeUsu, '', 0, 0, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos);
            lOrd := lOrd + 1;
        END IF;
        
        IF CursorRelatorioOrderNivel2%ISOPEN THEN
            CLOSE CursorRelatorioOrderNivel2;
        END IF;

        OPEN CursorRelatorioOrderNivel2 FOR SELECT * FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELSTATUS_TABLE)) WHERE Ord BETWEEN lOrdemGrupoUsuario + 1 AND lOrdemGrupoUsuario + 9999 ORDER BY SIG;
        LOOP
            FETCH CursorRelatorioOrderNivel2 INTO lOrdemGrupoUsuario, lNmeUsu, lIdeUsu, lSig, lIdeUni, lTotal, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos;
            EXIT WHEN CursorRelatorioOrderNivel2%NOTFOUND;

            lTblTempOrder.Extend;
            lTblTempOrder(lTblTempOrder.LAST) := OBJECT_TMPRELSTATUS(lOrd, lNmeUsu, lIdeUsu, lSig, lIdeUni, 0, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos);
            lOrd := lOrd + 1;
        END LOOP;

        IF CursorRelatorioOrderNivel2%ISOPEN THEN
            CLOSE CursorRelatorioOrderNivel2;
        END IF;
    END LOOP;

    IF CursorRelatorioOrderNivel1%ISOPEN THEN
        CLOSE CursorRelatorioOrderNivel1;
    END IF;

    IF pExcel = 0 AND lTotalCriados > 0 THEN
        lTblTempOrder.Extend;
        lTblTempOrder(lTblTempOrder.LAST) := OBJECT_TMPRELSTATUS(lOrdemGrupoUsuario * 10000, 'Total', 0, 'Total', 0, 0, lTotalCriados, lTotalAgingMonths / CASE WHEN lTotalCriados = 0 THEN NULL ELSE lTotalCriados END, lTotalEmAberto, lTotalReprogramadas, lTotalEmAndamento, lTotalEmAtraso, lTotalConcluidos);
    END IF;

    OPEN pRecordSet FOR
    SELECT ROWNUM Id, 
      T.*,
      EmAberto EMEXECUCAOATRASADA,
      AgingMonths EMEXECUCAONOPRAZO,
      EmAndamento PLANEJADASATRASADA,
      Reprogramadas PLANEJADASNOPRAZO,
      EmAtraso FINALIZADAATRASADA,
      Concluidos FINALIZADANOPRAZO 
    FROM TABLE (CAST(lTblTempOrder AS OBJECT_TMPRELSTATUS_TABLE)) T ORDER BY ORD;

END;

/* Fun��o     : RelStatusProjetos
   Prop�sito  : Retorna os Status dos Projetos sob a Responsabilidade de uma Unidade Gerencial e/ou suas subordinadas at� o 3o n�vel
   Par�metros : pIdeUni-Identificador da Unidade Gerencial
                pSub-Indica se o relat�rio deve retornar dados apenas da UG selecionada ou de suas subordinadas at� o 3o n�vel
                pPerIni-Per�odo de In�cio definido pelo Usu�rio (pode ser nulo)
                pPerFin-Per�odo de T�rmino definido pelo usu�rio (pode ser nulo)
                pIdeUsu-Identificador do Usu�rio respons�vel pelas Solu��es de Problema ou pelas A��es
                pCls-Classifica��o sob as quais ser� feita a pesquisa
   Cria��o    : 22/11/2010 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */
   
PROCEDURE RelStatusProjetos(pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls NUMBER, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT, pPortalSim30 INT, pRecordSet OUT tCursorType)  
    IS
        CursorRelatorio     tCursorType;
        
        lTblTemp            OBJECT_TMPRELSTATUS_TABLE := OBJECT_TMPRELSTATUS_TABLE();
        
        lLvl                INT;
        lPerIni             DATE := NULL;
        lPerFin             DATE := NULL;
            
        lHoje               VARCHAR2(50) := 'TO_DATE(''' || TO_CHAR(SYSDATE, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
    
        lStrQuery           VARCHAR2(8000) := '';
        lCondicaoProjetos   VARCHAR2(1000) := '';
        lCondicaoEnvolvidos VARCHAR2(1000);
            
        lCalculoSubtotal    INT := 0;

        lOrd                INT;
        lSig                VARCHAR2(50);
        lIdeUni             NUMBER(13);
        lCriados            INT;
        lAgingMonths        INT;
        lEmAberto           INT;
        lReprogramadas      INT;
        lEmAndamento        INT;
        lEmAtraso           INT;
        lConcluidos         INT; 

        lTotalCriados       INT;
        lTotalAgingMonths   INT;
        lTotalEmAberto      INT;
        lTotalReprogramadas INT;
        lTotalEmAndamento   INT;
        lTotalEmAtraso      INT;
        lTotalConcluidos    INT; 

        lSubTotalCriados        INT;
        lSubTotalAgingMonths    INT;
        lSubTotalEmAberto       INT;
        lSubTotalReprogramadas  INT;            
        lSubTotalEmAndamento    INT;
        lSubTotalEmAtraso       INT;
        lSubTotalConcluidos     INT;
BEGIN
    IF pSub = 0 THEN
        lLvl := 1;
    ELSE
        lLvl := 3;
    END IF;
     
    IF NOT pPerIni IS NULL THEN
        lPerIni := pPerIni;
    END IF;

    IF NOT pPerFin IS NULL THEN
        lPerFin := pPerFin;
    END IF;
    
    IF pCls <> 0 THEN
        IF LENGTH(lCondicaoProjetos) > 0 THEN
            lCondicaoProjetos := lCondicaoProjetos || ' AND ';
        END IF;
            
        IF pPortalSim30 = 0 THEN
          lCondicaoProjetos := lCondicaoProjetos ||         'TSOLPRB.CLS = ' || TO_CHAR(PCLS);
        ELSE
          lCondicaoProjetos := lCondicaoProjetos ||         'TSOLPRB.IDECLS = ' || TO_CHAR(PCLS);
        END IF;

    END IF;
    
    IF NOT lPerIni IS NULL THEN
        IF LENGTH(lCondicaoProjetos) > 0 THEN
            lCondicaoProjetos := lCondicaoProjetos || ' AND ';
        END IF;
            
        lCondicaoProjetos := lCondicaoProjetos ||         '(TSOLPRB.DATABE BETWEEN TO_DATE(''' || TO_CHAR(lPerIni, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TO_DATE(''' || TO_CHAR(lPerFin, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
        lCondicaoProjetos := lCondicaoProjetos ||         ' OR TSOLPRB.DATENCPRE BETWEEN TO_DATE(''' || TO_CHAR(LPERINI, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TO_DATE(''' || TO_CHAR(LPERFIN, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
        lCondicaoProjetos := lCondicaoProjetos ||         ' OR (TSOLPRB.DATABE < TO_DATE(''' || TO_CHAR(lPerIni, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TSOLPRB.DATENCPRE > TO_DATE(''' || TO_CHAR(lPerFin, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')))';
    END IF;
    
	
    IF NOT pIdeUsu IS NULL THEN
        lCondicaoEnvolvidos := 'INNER JOIN (SELECT DISTINCT TSOLPRBPAR.IDESOLPRB FROM TSOLPRBPAR WHERE TSOLPRBPAR.IDEUSU = ' || TO_CHAR(pIdeUsu) || ') VSOLPRBPAR ON TSOLPRB.IDESOLPRB = VSOLPRBPAR.IDESOLPRB';
    END IF;

    lStrQuery :=             'SELECT VUNIARV.ORD, ';
    lStrQuery := lStrQuery ||       'VUNIARV.SIG, ';
    lStrQuery := lStrQuery ||       'VUNIARV.IDEUNI, ';
    lStrQuery := lStrQuery ||       'VUNIARV.LVL, ';
    lStrQuery := lStrQuery ||       'COUNT(TSOLPRB.IDESOLPRB) Criados, ';
    IF pPortalSim30 = 0 THEN
      lStrQuery := lStrQuery ||       'AVG(TRUNC((CASE WHEN TSOLPRB.DATENC IS NULL THEN ' || lHoje || ' ELSE TSOLPRB.DATENC END - TSOLPRB.DATABE)/30)) AgingMonths, ';
      lStrQuery := lStrQuery ||       '0 EmAberto, ';
      lStrQuery := lStrQuery ||       '0 Reprogramadas, ';
      lStrQuery := lStrQuery ||       'SUM(CASE WHEN NOT TSOLPRB.DATABE IS NULL AND TSOLPRB.DATENC IS NULL AND (TSOLPRB.DATENCPRE IS NULL OR TSOLPRB.DATENCPRE >= ' || lHoje || ') THEN 1 ELSE 0 END) EmAndamento, ';
      lStrQuery := lStrQuery ||       'SUM(CASE WHEN TSOLPRB.DATENCPRE < ' || lHoje || ' AND TSOLPRB.DATENC IS NULL THEN 1 ELSE 0 END) EmAtraso, ';
      lStrQuery := lStrQuery ||       'SUM(CASE WHEN TSOLPRB.DATENC IS NULL THEN 0 ELSE 1 END) Concluidos ';
    ELSE    
      lStrQuery := lStrQuery ||        '0 AgingMonths, '; --FinalizadaAtrasada
      lStrQuery := lStrQuery ||        '0 EmAberto, '; --EmExecucaoAtrasada
      lStrQuery := lStrQuery ||        '0 Reprogramadas, '; --PlanejadasAtrasada    
      lStrQuery := lStrQuery ||        'SUM(CASE WHEN NOT TSOLPRB.DATABE IS NULL AND TSOLPRB.DATENC IS NULL AND (TSOLPRB.DATENCPRE IS NULL OR TSOLPRB.DATENCPRE >= ' || lHoje || ') THEN 1 ELSE 0 END) EmAndamento, '; --PlanejadasNoPrazo
      lStrQuery := lStrQuery ||        'SUM(CASE WHEN TSOLPRB.DATENCPRE < ' || lHoje || ' AND TSOLPRB.DATENC IS NULL THEN 1 ELSE 0 END) EmAtraso, '; --EmExecucaoNoPrazo
      lStrQuery := lStrQuery ||        'SUM(CASE WHEN TSOLPRB.DATENC IS NULL THEN 0 ELSE 1 END) Concluidos '; --FinalizadaNoPrazo
      
    END IF;
    lStrQuery := lStrQuery ||  ' FROM (SELECT VUNI.IDEUNI, ';
    
	 IF NOT pIdeUni IS NULL THEN
      lStrQuery := lStrQuery ||  '             SUBSTR((RPAD('' '', (LEVEL - 1) * 3, '' '') || VUNI.SIG), 1, 50) AS SIG, ';
      lStrQuery := lStrQuery ||  '             LEVEL LVL, ';
	 ELSE
      lStrQuery := lStrQuery ||  '             VUNI.SIG, ';
      lStrQuery := lStrQuery ||  '             0 LVL, ';
    END IF;
	 
	 lStrQuery := lStrQuery ||  '             ROWNUM ORD ';
    lStrQuery := lStrQuery ||  '        FROM TUNI VUNI ';
    lStrQuery := lStrQuery ||  '             INNER JOIN (SELECT IDEUNI FROM TABLE(RetornarUnidadesPorUsuario(' || TO_CHAR(pIdeUsuLogado) ||'))) TUSUUNI ON TUNI.IDEUNI = TUSUUNI.IDEUNI ';
    lStrQuery := lStrQuery ||  '       WHERE TUNI.IDEUNITYP IN (SELECT TUNITYP.IDEUNITYP FROM TUNITYP WHERE TUNITYP.TYP = 1) ';
    
	 IF NOT pIdeUni IS NULL THEN
      lStrQuery := lStrQuery ||  '         AND LEVEL <= ' || TO_CHAR(lLvl);
      lStrQuery := lStrQuery ||  '      CONNECT BY PRIOR VUNI.IDEUNI = VUNI.IDESPR ';
      lStrQuery := lStrQuery ||  ' START WITH VUNI.IDEUNI = ' || TO_CHAR(PIDEUNI) ;
    END IF;
	 
    lStrQuery := lStrQuery ||  ' ) VUNIARV LEFT JOIN ( SELECT TSOLPRB.IDESOLPRB, TSOLPRB.DATABE, TSOLPRB.DATENC, TSOLPRB.DATENCPRE, TSOLPRB.IDEUNI, TSOLPRB.IDEUNIREL FROM TSOLPRB ';

	IF LENGTH(lCondicaoEnvolvidos) > 0 THEN
		lStrQuery := lStrQuery || lCondicaoEnvolvidos;
	END IF;

   
   lStrQuery := lStrQuery ||  ' WHERE TSOLPRB.ETP <> 90 ';
   lStrQuery := lStrQuery ||  '   AND TSOLPRB.DATCNC IS NULL ';

    IF pPortalSim30 = 0 THEN
       lStrQuery := lStrQuery || '   AND TSOLPRB.TYP = ''PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblemaAntiga'' ';
    ELSE
       lStrQuery := lStrQuery || '   AND TSOLPRB.TYP = ''PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'' ';
	   lStrQuery := lStrQuery ||  '   AND TSOLPRB.IDESOLPRBSUP IS NULL ';
    END IF;

    IF LENGTH(lCondicaoProjetos) > 0 THEN
        lStrQuery := lStrQuery || ' AND ' || lCondicaoProjetos;
    END IF;
    
    IF pPortalSim30 = 0 THEN
        lStrQuery := lStrQuery ||  ') TSOLPRB ON (TSOLPRB.IDEUNI = VUNIARV.IDEUNI OR TSOLPRB.IDEUNIREL = VUNIARV.IDEUNI) ';
	ELSE
		lStrQuery := lStrQuery ||  ') TSOLPRB ON TSOLPRB.IDEUNI = VUNIARV.IDEUNI ';
    END IF;

    IF LENGTH(lCondicaoEnvolvidos) > 0 AND pPortalSim30 = 0 THEN
        lStrQuery := lStrQuery || lCondicaoEnvolvidos;
    END IF;
    lStrQuery := lStrQuery || ' GROUP BY VUNIARV.SIG, VUNIARV.IDEUNI, VUNIARV.ORD, VUNIARV.LVL ';
    lStrQuery := lStrQuery || ' ORDER BY VUNIARV.ORD ';
    
    lTotalCriados := 0;
    lTotalAgingMonths := 0;
    lTotalEmAberto := 0;
    lTotalReprogramadas := 0;
    lTotalEmAndamento := 0;
    lTotalEmAtraso := 0;
    lTotalConcluidos := 0;

    IF CursorRelatorio%ISOPEN THEN
        CLOSE CursorRelatorio;
    END IF;

    OPEN CursorRelatorio FOR lStrQuery;
    LOOP    
        FETCH CursorRelatorio INTO lOrd, lSig, lIdeUni, lLvl, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos;
        EXIT WHEN CursorRelatorio%NOTFOUND;

        IF lLvl = 2 THEN
            IF lCalculoSubtotal = 2 AND pExcel = 0 THEN
                lTblTemp.Extend;
                lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrd + 1, '', 0, '      Subtotal', lIdeUni, 2, lSubTotalCriados, CASE WHEN pPortalSim30 = 0 THEN lSubTotalAgingMonths / CASE WHEN lSubTotalCriados = 0 THEN NULL ELSE lSubTotalCriados END ELSE lSubTotalAgingMonths END, lSubTotalEmAberto, lSubTotalReprogramadas, lSubTotalEmAndamento, lSubTotalEmAtraso, lSubTotalConcluidos);
            END IF;

            lCalculoSubtotal := 1;  
            
            lSubTotalCriados := lCriados;
            lSubTotalAgingMonths := (lAgingMonths * lCriados);
            lSubTotalEmAberto := lEmAberto;
            lSubTotalReprogramadas := lReprogramadas;
            lSubTotalEmAndamento := lEmAndamento;
            lSubTotalEmAtraso := lEmAtraso;
            lSubTotalConcluidos := lConcluidos;
        ELSIF lLvl = 3 THEN
            lCalculoSubtotal := 2;  
        
            lSubTotalCriados := lSubTotalCriados + lCriados;
            lSubTotalAgingMonths := lSubTotalAgingMonths + (lAgingMonths * lCriados);
            lSubTotalEmAberto := lSubTotalEmAberto + lEmAberto;
            lSubTotalReprogramadas := lSubTotalReprogramadas + lReprogramadas;
            lSubTotalEmAndamento := lSubTotalEmAndamento + lEmAndamento;
            lSubTotalEmAtraso := lSubTotalEmAtraso + lEmAtraso;
            lSubTotalConcluidos := lSubTotalConcluidos + lConcluidos;
        END IF;

        lTotalCriados := lTotalCriados + lCriados;
        lTotalAgingMonths := lTotalAgingMonths + (lAgingMonths * lCriados);
        lTotalEmAberto := lTotalEmAberto + lEmAberto;
        lTotalReprogramadas := lTotalReprogramadas + lReprogramadas;
        lTotalEmAndamento := lTotalEmAndamento + lEmAndamento;
        lTotalEmAtraso := lTotalEmAtraso + lEmAtraso;
        lTotalConcluidos := lTotalConcluidos + lConcluidos;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrd, '', 0, lSig, lIdeUni, 0, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos);        
    END LOOP;

    IF CursorRelatorio%ISOPEN THEN
        CLOSE CursorRelatorio;
    END IF;

    IF pSub <> 0 AND pExcel = 0 THEN
        IF lCalculoSubtotal = 2 THEN
            lTblTemp.Extend;
            lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrd + 1, '', 0, '      Subtotal', lIdeUni, 2, lSubTotalCriados, lSubTotalAgingMonths, lSubTotalEmAberto, lSubTotalReprogramadas, lSubTotalEmAndamento, lSubTotalEmAtraso, lSubTotalConcluidos);        
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrd + 1, '', 0, 'Total', lIdeUni, 1, lTotalCriados, lTotalAgingMonths, lTotalEmAberto, lTotalReprogramadas, lTotalEmAndamento, lTotalEmAtraso, lTotalConcluidos);        
    END IF;
    
    OPEN pRecordset FOR
    SELECT ROWNUM Id,
      T.*, 
      EmAberto EMEXECUCAOATRASADA,
      EmAtraso EMEXECUCAONOPRAZO,
      Reprogramadas PLANEJADASATRASADA,
      EmAndamento PLANEJADASNOPRAZO,
      AgingMonths FINALIZADAATRASADA,
      Concluidos FINALIZADANOPRAZO 
    FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELSTATUS_TABLE)) T;
    
END;

/* Fun��o     : RelStatusAcoes
   Prop�sito  : Retorna os Status das Acoes sob a Responsabilidade de uma Unidade Gerencial e/ou suas subordinadas at� o 3o n�vel
   Par�metros : pIdeUni-Identificador da Unidade Gerencial
                pSub-Indica se o relat�rio deve retornar dados apenas da UG selecionada ou de suas subordinadas at� o 3o n�vel
                pPerIni-Per�odo de In�cio definido pelo Usu�rio (pode ser nulo)
                pPerFin-Per�odo de T�rmino definido pelo usu�rio (pode ser nulo)
                pIdeUsu-Identificador do Usu�rio respons�vel pelas Solu��es de Problema ou pelas A��es
                pCls-Classifica��o sob as quais ser� feita a pesquisa
   Cria��o    : 22/11/2010 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */
   
PROCEDURE RelStatusAcoes(pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls NUMBER, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT, pPortalSim30 INT, pRecordSet OUT tCursorType)
    IS
        CursorRelatorio     tCursorType;
        
        lTblTemp            OBJECT_TMPRELSTATUS_TABLE := OBJECT_TMPRELSTATUS_TABLE();
        
        lLvl                INT;
        lPerIni             DATE := NULL;
        lPerFin             DATE := NULL;
            
        lHoje               VARCHAR2(50) := 'TO_DATE(''' || TO_CHAR(SYSDATE, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
    
        lStrQuery           VARCHAR2(8000) := '';
        lCondicaoAcoes1     VARCHAR2(1000) := '';
        lCondicaoAcoes2     VARCHAR2(1000) := '';
            
        lCalculoSubtotal    INT := 0;

        lOrd                INT;
        lSig                VARCHAR2(50);
        lIdeUni             NUMBER(13);
        lCriados            INT;
        lAgingMonths        INT;
        lEmAberto           INT;
        lReprogramadas      INT;
        lEmAndamento        INT;
        lEmAtraso           INT;
        lConcluidos         INT; 

        lTotalCriados       INT;
        lTotalAgingMonths   INT;
        lTotalEmAberto      INT;
        lTotalReprogramadas INT;
        lTotalEmAndamento   INT;
        lTotalEmAtraso      INT;
        lTotalConcluidos    INT; 

        lSubTotalCriados        INT;
        lSubTotalAgingMonths    INT;
        lSubTotalEmAberto       INT;
        lSubTotalReprogramadas  INT;            
        lSubTotalEmAndamento    INT;
        lSubTotalEmAtraso       INT;
        lSubTotalConcluidos     INT;
BEGIN
    IF pSub = 0 THEN
        lLvl := 1;
    ELSE
        lLvl := 3;
    END IF;
     
    IF NOT pPerIni IS NULL THEN
        lPerIni := pPerIni;
    END IF;

    IF NOT pPerFin IS NULL THEN
        lPerFin := pPerFin;
    END IF;
    
    IF pCls <> 0 THEN
        IF LENGTH(lCondicaoAcoes2) > 0 THEN
            lCondicaoAcoes2 := lCondicaoAcoes2 || ' AND ';
        END IF;
            
         IF pPortalSim30 = 0 THEN
          lCondicaoAcoes2 := lCondicaoAcoes2 ||         'TSOLPRB.CLS = ' || TO_CHAR(PCLS);
        ELSE
          lCondicaoAcoes2 := lCondicaoAcoes2 ||         'TSOLPRB.IDECLS = ' || TO_CHAR(PCLS);
        END IF;
    END IF;
    
    IF LENGTH(lCondicaoAcoes2) > 0 THEN
            lCondicaoAcoes2 := lCondicaoAcoes2 || ' AND ';
    END IF;
    
    IF pPortalSim30 = 0 THEN
       lCondicaoAcoes2 := lCondicaoAcoes2 ||         'TSOLPRB.TYP = ''PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblemaAntiga'' ';
    ELSE
       lCondicaoAcoes2 := lCondicaoAcoes2 ||         'TSOLPRB.TYP = ''PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'' ';
    END IF;
    
	lCondicaoAcoes2 := lCondicaoAcoes2 ||         ' AND TSOLPRB.DATCNC IS NULL  ';

    IF NOT lPerIni IS NULL THEN         
        lCondicaoAcoes1 := lCondicaoAcoes1 || ' AND (TPACTAR.INIPRE BETWEEN TO_DATE(''' || TO_CHAR(LPERINI, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TO_DATE(''' || TO_CHAR(LPERFIN, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
        lCondicaoAcoes1 := lCondicaoAcoes1 || '      OR TPACTAR.FIMPRE BETWEEN TO_DATE(''' || TO_CHAR(LPERINI, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TO_DATE(''' || TO_CHAR(LPERFIN, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')';
        lCondicaoAcoes1 := lCondicaoAcoes1 || '      OR (TPACTAR.INIPRE < TO_DATE(''' || TO_CHAR(lPerIni, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'') AND TPACTAR.FIMPRE > TO_DATE(''' || TO_CHAR(lPerFin, 'DD/MM/YYYY') || ''', ''DD/MM/YYYY'')))';
   END IF;
    
    IF NOT pIdeUsu IS NULL THEN
        lCondicaoAcoes1 := lCondicaoAcoes1 || ' AND TPACTAR.IDEUSURES = ' || TO_CHAR(pIdeUsu);
    END IF;

    lStrQuery :=              'SELECT VUNIARV.ORD, ';
    lStrQuery := lStrQuery ||        'VUNIARV.SIG, ';
    lStrQuery := lStrQuery ||        'VUNIARV.IdeUni, ';
    lStrQuery := lStrQuery ||        'VUNIARV.LVL, ';
    lStrQuery := lStrQuery ||        'COUNT(VPACTAR.IDEPACTAR) Criados, ';
    IF pPortalSim30 = 0 THEN
        lStrQuery := lStrQuery ||        '0 AgingMonths, ';
        lStrQuery := lStrQuery ||        'SUM(VPACTAR.NUMREP) Reprogramadas, ';
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN (VPACTAR.INIPRE IS NULL OR (VPACTAR.INIPRE >= ' || lHoje || ' AND VPACTAR.INIREA IS NULL)) AND VPACTAR.FIMPRE >= ' || lHoje || ' AND VPACTAR.FIMREA IS NULL THEN 1 ELSE 0 END) EmAberto, ';
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN (VPACTAR.ACAREC = 0 AND NOT VPACTAR.INIPRE IS NULL AND NOT VPACTAR.INIREA IS NULL AND VPACTAR.FIMPRE >= ' || lHoje || ' AND VPACTAR.FIMREA IS NULL) OR (VPACTAR.ACAREC <> 0 AND VPACTAR.PRXEXCREC >= ' || lHoje || ' AND VPACTAR.FIMREA IS NULL) THEN 1 ELSE 0 END) EmAndamento, ';
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN (VPACTAR.INIPRE < ' || lHoje || ' AND VPACTAR.INIREA IS NULL AND VPACTAR.FIMREA IS NULL) OR (VPACTAR.ACAREC = 0 AND VPACTAR.FIMPRE < ' || lHoje || ' AND VPACTAR.FIMREA IS NULL) OR (VPACTAR.ACAREC <> 0 AND VPACTAR.PRXEXCREC < ' || lHoje || ' AND VPACTAR.FIMREA IS NULL) THEN 1 ELSE 0 END) EmAtraso, ';
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN NOT VPACTAR.FIMREA IS NULL THEN 1 ELSE 0 END) Concluidos ';
    ELSE
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE >= ' || lHoje || ' THEN 1 ELSE 0 END) Reprogramadas, '; -- PlanejadaNoPrazo
		lStrQuery := lStrQuery ||        'SUM(CASE WHEN VPACTAR.INIREA IS NULL AND VPACTAR.INIPRE < ' || lHoje || ' THEN 1 ELSE 0 END) EmAndamento, '; -- PlanejadaAtrasada
		lStrQuery := lStrQuery ||        'SUM(CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, SYSDATE)) <= VPACTAR.PERCON THEN 1 ELSE 0 END) END) AgingMonths, '; -- EmAndamentoNoPrazo
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN VPACTAR.INIREA IS NOT NULL AND VPACTAR.FIMREA IS NULL AND (PercentualPrevConclusaoTarefa(VPACTAR.INIPRE, VPACTAR.FIMPRE, VPACTAR.DURHRA, VPACTAR.FREREC, SYSDATE)) > VPACTAR.PERCON THEN 1 ELSE 0 END) END) EmAberto, '; -- EmAndamentoAtrasada
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA > VPACTAR.FIMPRE THEN 1 ELSE 0 END) EmAtraso, '; --FinalizadaAtrasada
        lStrQuery := lStrQuery ||        'SUM(CASE WHEN VPACTAR.FIMREA IS NOT NULL AND VPACTAR.FIMREA <= VPACTAR.FIMPRE THEN 1 ELSE 0 END) Concluidos '; --FinalizadaNoPrazo
    END IF;
    
    lStrQuery := lStrQuery ||  'FROM (SELECT VUNI.IDEUNI, ';
    IF NOT PIDEUNI IS NULL THEN
      LSTRQUERY := LSTRQUERY ||  '             SUBSTR((RPAD('' '', (LEVEL - 1) * 3, '' '') || VUNI.SIG), 1, 50) AS SIG, ';
      LSTRQUERY := LSTRQUERY ||  '             LEVEL LVL, ';
    ELSE
      LSTRQUERY := LSTRQUERY ||  '             VUNI.SIG, ';
      LSTRQUERY := LSTRQUERY ||  '             0 LVL, ';
    END IF;
    
    lStrQuery := lStrQuery ||  '             ROWNUM ORD ';
    lStrQuery := lStrQuery ||  '        FROM TUNI VUNI ';
	  lStrQuery := lStrQuery ||  '             INNER JOIN (SELECT IDEUNI FROM TABLE(RetornarUnidadesPorUsuario(' || TO_CHAR(pIdeUsuLogado) || '))) TUSUUNI ON TUNI.IDEUNI = TUSUUNI.IDEUNI ';
    lStrQuery := lStrQuery ||  '       WHERE TUNI.IDEUNITYP IN (SELECT TUNITYP.IDEUNITYP FROM TUNITYP WHERE TUNITYP.TYP = 1) ';
    
    IF NOT PIDEUNI IS NULL THEN
      lStrQuery := lStrQuery ||  '         AND LEVEL <= ' || TO_CHAR(lLvl);
      LSTRQUERY := LSTRQUERY ||  '      CONNECT BY PRIOR VUNI.IDEUNI = VUNI.IDESPR ';
      LSTRQUERY := LSTRQUERY ||  '      START WITH VUNI.IDEUNI = ' || TO_CHAR(PIDEUNI); 
    END IF;
	
	IF PPORTALSIM30 = 0 THEN
        lStrQuery := lStrQuery ||     ' ) VUNIARV LEFT JOIN (SELECT * FROM TSOLPRB ';
        lStrQuery := lStrQuery ||     ' WHERE TSOLPRB.ETP <> 90 ';
        
        IF LENGTH(lCondicaoAcoes2) > 0 THEN
          lStrQuery := lStrQuery ||     ' AND ' || lCondicaoAcoes2;
        END IF;
        
        lStrQuery := lStrQuery ||   ') TSOLPRB ON VUNIARV.IDEUNI = TSOLPRB.IDEUNI ';
     ELSE
        lStrQuery := lStrQuery ||     ' ) VUNIARV LEFT JOIN (SELECT TSOLPRB.IDESOLPRB, TSOLPRB.IDEUNI 
												FROM TSOLPRB
												WHERE TSOLPRB.ETP <> 90 ';

		IF LENGTH(lCondicaoAcoes2) > 0 THEN
          lStrQuery := lStrQuery ||     ' AND ' || lCondicaoAcoes2;
        END IF;

		 lStrQuery := lStrQuery || ' ) TSOLPRB ON VUNIARV.IDEUNI = TSOLPRB.IDEUNI ';
    END IF;
	 IF pPortalSim30 = 0 THEN

		 lStrQuery := lStrQuery ||     'LEFT JOIN (SELECT tFer.IdeFer, tFer.Nme, tSolPrbPas.IdeSolPrb, TSOLPRBPAS.IDESOLPRBPAS
                                    FROM tFer 
                                    INNER JOIN tSolPrbPas ON tFer.IdeSolPrbPas = tSolPrbPas.IdeSolPrbPas 
                                    WHERE tFer.TipFer = 32 
                                    UNION 
                                    SELECT tFer.IdeFer, tFer.Nme, tSolPrb.IdeSolPrb, TFER.IDESOLPRBPAS 
                                    FROM tSolPrb 
                                    INNER JOIN tLinRac ON tSolPrb.IdeSolPrb = tLinRac.IdeSolPrb 
                                    INNER JOIN tRac ON tRac.IdeLinRac = tLinRac.IdeLinRac 
                                    INNER JOIN tFer ON tFer.IdeRac = tRac.IdeRac 
                                    WHERE tFer.TipFer = 32) tFer ON TSOLPRB.IdeSolPrb = TFER.IdeSolPrb ';
		 lStrQuery := lStrQuery ||     'LEFT JOIN (SELECT TPACTAR.IDEPACTAR, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.INIPRE, 
                                    TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, TPACTAR.PERCON, TPACTAR.DURHRA, COUNT(TPACTARREP.IDEPACTARREP) NUMREP 
                                    FROM TPACTAR 
                                    LEFT JOIN TPACTARREP ON TPACTAR.IDEPACTAR = TPACTARREP.IDEPACTAR 
                                    WHERE TPACTAR.DEL = 0 AND TPACTAR.FIMPRE IS NOT NULL AND ( ' || pIsAdministrador || ' <> 0 OR TPACTAR.PUB <> 0) ' || lCondicaoAcoes1 || ' 
                                    GROUP BY TPACTAR.IDEPACTAR, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.INIPRE,
                                    TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, TPACTAR.PERCON, TPACTAR.DURHRA) VPACTAR ON TFER.IDEFER = VPACTAR.IDEFER ';
    ELSE
		lStrQuery := lStrQuery || ' LEFT JOIN TSOLPRBPAS ON TSOLPRBPAS.IDESOLPRB = TSOLPRB.IDESOLPRB
									LEFT JOIN TFER ON TFER.IDESOLPRBPAS = TSOLPRBPAS.IDESOLPRBPAS
									LEFT JOIN (SELECT TPACTAR.FREREC, TPACTAR.IDEPACTAR, TPACTAR.idePlaAco, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES, TPACTAR.INIPRE, 
									TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC
									FROM TPACTAR
                      INNER JOIN TPLAACO ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
									WHERE TPACTAR.DEL = 0 
										  AND TPACTAR.FIMPRE IS NOT NULL ' || lCondicaoAcoes1 || ' 
										  GROUP BY TPACTAR.IDEPACTAR,tpactar.IDEPLAACO, TPACTAR.IDEFER, TPACTAR.ACAREC, TPACTAR.IDEUSURES,
										  TPACTAR.INIPRE, TPACTAR.INIREA, TPACTAR.FIMPRE, TPACTAR.FIMREA, TPACTAR.PRXEXCREC, TPACTAR.FREREC
										) VPACTAR ON TFER.IDEPLAACO = VPACTAR.IDEPLAACO ';
	END IF;
	
	lStrQuery := lStrQuery || ' GROUP BY VUNIARV.SIG, VUNIARV.IDEUNI, VUNIARV.ORD, VUNIARV.LVL ';
    lStrQuery := lStrQuery || ' ORDER BY VUNIARV.ORD ';
    
    lTotalCriados := 0;
    lTotalAgingMonths := 0;
    lTotalEmAberto := 0;
    lTotalReprogramadas := 0;
    lTotalEmAndamento := 0;
    lTotalEmAtraso := 0;
    lTotalConcluidos := 0;

    IF CursorRelatorio%ISOPEN THEN
        CLOSE CursorRelatorio;
    END IF;

    OPEN CursorRelatorio FOR lStrQuery;
    LOOP    
        FETCH CursorRelatorio INTO lOrd, lSig, lIdeUni, lLvl, lCriados, lAgingMonths, lReprogramadas, lEmAberto, lEmAndamento, lEmAtraso, lConcluidos;
        EXIT WHEN CursorRelatorio%NOTFOUND;

        IF lLvl = 2 THEN
            IF lCalculoSubtotal = 2 AND pExcel = 0 THEN
                lTblTemp.Extend;
                lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrd + 1, '', 0, '      Subtotal', lIdeUni, 2, lSubTotalCriados, 0, lSubTotalEmAberto, lSubTotalReprogramadas, lSubTotalEmAndamento, lSubTotalEmAtraso, lSubTotalConcluidos);
            END IF;

            lCalculoSubtotal := 1;  
            
            lSubTotalCriados := lCriados;
            lSubTotalAgingMonths := (lAgingMonths * lCriados);
            lSubTotalEmAberto := lEmAberto;
            lSubTotalReprogramadas := lReprogramadas;
            lSubTotalEmAndamento := lEmAndamento;
            lSubTotalEmAtraso := lEmAtraso;
            lSubTotalConcluidos := lConcluidos;
        ELSIF lLvl = 3 THEN
            lCalculoSubtotal := 2;
                        
            lSubTotalCriados := lSubTotalCriados + lCriados;
            lSubTotalAgingMonths := lSubTotalAgingMonths + (lAgingMonths * lCriados);
            lSubTotalEmAberto := lSubTotalEmAberto + lEmAberto;
            lSubTotalReprogramadas := lSubTotalReprogramadas + lReprogramadas;
            lSubTotalEmAndamento := lSubTotalEmAndamento + lEmAndamento;
            lSubTotalEmAtraso := lSubTotalEmAtraso + lEmAtraso;
            lSubTotalConcluidos := lSubTotalConcluidos + lConcluidos;
        END IF;

        lTotalCriados := lTotalCriados + lCriados;
        lTotalAgingMonths := lTotalAgingMonths + (lAgingMonths * lCriados);
        lTotalEmAberto := lTotalEmAberto + lEmAberto;
        lTotalReprogramadas := lTotalReprogramadas + lReprogramadas;
        lTotalEmAndamento := lTotalEmAndamento + lEmAndamento;
        lTotalEmAtraso := lTotalEmAtraso + lEmAtraso;
        lTotalConcluidos := lTotalConcluidos + lConcluidos;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrd, '', 0, lSig, lIdeUni, 0, lCriados, lAgingMonths, lEmAberto, lReprogramadas, lEmAndamento, lEmAtraso, lConcluidos);        
    END LOOP;

    IF CursorRelatorio%ISOPEN THEN
        CLOSE CursorRelatorio;
    END IF;

    IF pSub <> 0 AND pExcel = 0 THEN
        IF lCalculoSubtotal = 2 THEN
            lTblTemp.Extend;
            lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrd + 1, '', 0, '      Subtotal', lIdeUni, 2, lSubTotalCriados, 0, lSubTotalEmAberto, lSubTotalReprogramadas, lSubTotalEmAndamento, lSubTotalEmAtraso, lSubTotalConcluidos);        
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELSTATUS(lOrd + 1, '', 0, 'Total', lIdeUni, 1, lTotalCriados, 0, lTotalEmAberto, lTotalReprogramadas, lTotalEmAndamento, lTotalEmAtraso, lTotalConcluidos);        
    END IF;
    
    OPEN pRecordset FOR
    SELECT ROWNUM Id, 
      T.*, 
      EmAberto EMEXECUCAOATRASADA,
      AgingMonths EMEXECUCAONOPRAZO,
      EmAndamento PLANEJADASATRASADA,
      Reprogramadas PLANEJADASNOPRAZO,
      EmAtraso FINALIZADAATRASADA,
      Concluidos FINALIZADANOPRAZO 
    FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELSTATUS_TABLE)) T;      
    
END;

/*Prop�sito: Retorna fun��o de mesmo nome, passando o parametro pRecordSet na primeira posi��o. O "30" indica que � usado no portal 3.0*/
PROCEDURE RelStatusProjetosRes30(pRecordSet OUT tCursorType, pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls INT, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT)
   IS
   BEGIN
    RelStatusProjetosRes(PIDEUNI, PSUB, PPERINI, PPERFIN, PIDEUSU, PCLS, PISADMINISTRADOR, PIDEUSULOGADO, PEXCEL, 1, PRECORDSET);
END;

/*Prop�sito: Retorna fun��o de mesmo nome, passando o parametro pRecordSet na primeira posi��o. O "30" indica que � usado no portal 3.0*/
PROCEDURE RelStatusAcoesRes30(pRecordSet OUT tCursorType, pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls INT, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT)
   IS
   BEGIN
    RelStatusAcoesRes(PIDEUNI, PSUB, PPERINI, PPERFIN, PIDEUSU, PCLS, PISADMINISTRADOR, PIDEUSULOGADO, PEXCEL, 1, PRECORDSET);
END;

/*Prop�sito: Retorna fun��o de mesmo nome, passando o parametro pRecordSet na primeira posi��o. O "30" indica que � usado no portal 3.0*/
PROCEDURE RelStatusProjetos30(pRecordSet OUT tCursorType, pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls INT, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT)
   IS
   BEGIN
    RelStatusProjetos(PIDEUNI, PSUB, PPERINI, PPERFIN, PIDEUSU, PCLS, PISADMINISTRADOR, PIDEUSULOGADO, PEXCEL, 1, PRECORDSET);
END;

/*Prop�sito: Retorna fun��o de mesmo nome, passando o parametro pRecordSet na primeira posi��o. O "30" indica que � usado no portal 3.0*/
PROCEDURE RelStatusAcoes30(pRecordSet OUT tCursorType, pIdeUni NUMBER, pSub INT, pPerIni DATE, pPerFin DATE, pIdeUsu NUMBER, pCls INT, pIsAdministrador INT, pIdeUsuLogado NUMBER, pExcel INT)
   IS
   BEGIN
    RelStatusAcoes(PIDEUNI, PSUB, PPERINI, PPERFIN, PIDEUSU, PCLS, PISADMINISTRADOR, PIDEUSULOGADO, PEXCEL, 1, PRECORDSET);
END;


/* Fun��o     : RelNumeroGrupos
   Prop�sito  : Retorna o total de Grupos Criamos e Extintos na Empresa no ano selecionado
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios, sendo: 1-Coordena��o, 2-UG, 3-UO e 4-Empresa
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
                pExr-Exerc�cio selecionado (n�o est� dispon�vel a todos os relat�rios)
   Cria��o    : 31/07/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelNumeroGrupos (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pExr INT, pRecordset OUT tCursorType)
    IS
        CursorUnidades      tCursorType;
        CursorIdadeGrupos   tCursorType;

        lStrGrupos          VARCHAR2(4000);
        lStrIdadeGrupos     VARCHAR2(4000);

        lTblTemp            OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lIdeUniOpe          NUMBER(13);
        lNmeUniOpe          VARCHAR2(25);
        lIdeUni             NUMBER(13);
        lSigUni             VARCHAR2(25);
        lIdeUniRel          NUMBER(13);
        lSigUniRel          VARCHAR2(25);
        lIdeGruCCQ          NUMBER(13);

        lDatCri             DATE;
        lDatCnc             DATE;

        lInicioAno          DATE := TO_DATE('01/01/' || pExr, 'DD/MM/YYYY');
        lFinalAno           DATE := ADD_MONTHS(TO_DATE('01/12/' || TO_CHAR(pExr), 'DD/MM/YYYY'), 1) - 0.00001;
BEGIN
    IF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL FROM ';
    ELSIF pTipo = 2 THEN   -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL FROM ';
    ELSIF pTipo = 3 THEN   -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL FROM ';
    ELSIF pTipo = 4 THEN   -- Agrupamento pela Empresa
        lStrGrupos := 'SELECT DISTINCT 0 IDEUNIOPE, '''' NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    -- Local para condi��es espec�ficas que filtre diretamente a tabela de Grupos
    lStrGrupos := lStrGrupos || ' AND TUNI.DATCRI <= TO_DATE(''' || TO_CHAR(lFinalAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= TO_DATE(''' || TO_CHAR(lInicioAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS''))';
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    lStrGrupos := lStrGrupos || ' ORDER BY NMEUNIOPE, SIGUNI, SIGUNIREL';

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lIdeUniOpe, lNmeUniOpe, lIdeUni, lSigUni, lIdeUniRel, lSigUniRel;
        EXIT WHEN CursorUnidades%NOTFOUND;

        Meses(0).Valor1 := 0;
        Meses(1).Valor1 := NULL;
        Meses(2).Valor1 := NULL;
        Meses(3).Valor1 := NULL;
        Meses(4).Valor1 := NULL;
        Meses(5).Valor1 := NULL;
        Meses(6).Valor1 := NULL;
        Meses(7).Valor1 := NULL;
        Meses(8).Valor1 := NULL;
        Meses(9).Valor1 := NULL;
        Meses(10).Valor1 := NULL;
        Meses(11).Valor1 := NULL;
        Meses(12).Valor1 := NULL;
        Meses(13).Valor1 := 0;

        Meses(1).Valor2 := NULL;
        Meses(2).Valor2 := NULL;
        Meses(3).Valor2 := NULL;
        Meses(4).Valor2 := NULL;
        Meses(5).Valor2 := NULL;
        Meses(6).Valor2 := NULL;
        Meses(7).Valor2 := NULL;
        Meses(8).Valor2 := NULL;
        Meses(9).Valor2 := NULL;
        Meses(10).Valor2 := NULL;
        Meses(11).Valor2 := NULL;
        Meses(12).Valor2 := NULL;

        lStrIdadeGrupos := 'SELECT DISTINCT VGRUCCQ.IDEUNI, TRUNC(VGRUCCQ.DATCRI, ''MONTH'') DATCRI, TRUNC(VGRUCCQ.DATCNC, ''MONTH'') DATCNC FROM';
        lStrIdadeGrupos := lStrIdadeGrupos || '(SELECT TUNI.IDEUNI, TUNI.DATCRI, TUNI.DATCNC, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3';
        lStrIdadeGrupos := lStrIdadeGrupos || ') VGRUCCQ, (SELECT VUNI.IDEUNI, VUNI.IDEUNIOPE FROM VUNI WHERE TYP = 1) VUNI ';

        lStrIdadeGrupos := lStrIdadeGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI';
        
        IF lIdeUniOpe <> 0 THEN
           lStrIdadeGrupos := lStrIdadeGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(lIdeUniOpe);
        END IF;

        IF lIdeUni <> 0 THEN
           lStrIdadeGrupos := lStrIdadeGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(lIdeUni);
        END IF;

        IF lIdeUniRel <> 0 THEN
              lStrIdadeGrupos := lStrIdadeGrupos || ' AND VGRUCCQ.IDEUNIREL = ' || TO_CHAR(lIdeUniRel);
        END IF;

        IF CursorIdadeGrupos%ISOPEN THEN
            CLOSE CursorIdadeGrupos;
        END IF;

        OPEN CursorIdadeGrupos FOR lStrIdadeGrupos;
        LOOP
            FETCH CursorIdadeGrupos INTO lIdeGruCCQ, lDatCri, lDatCnc;
            EXIT WHEN CursorIdadeGrupos%NOTFOUND;

            IF lDatCri < lInicioAno AND (lDatCnc IS NULL OR lDatCnc >= lInicioAno) THEN
                Meses(0).Valor1 := Meses(0).Valor1 + 1;
            END IF;

            IF TO_NUMBER(TO_CHAR(lDatCri, 'YYYY')) = pExr THEN
                IF Meses(TO_NUMBER(TO_CHAR(lDatCri, 'MM'))).Valor1 IS NULL THEN
                    Meses(TO_NUMBER(TO_CHAR(lDatCri, 'MM'))).Valor1 := 0;
                END IF;
                Meses(TO_NUMBER(TO_CHAR(lDatCri, 'MM'))).Valor1 := Meses(TO_NUMBER(TO_CHAR(lDatCri, 'MM'))).Valor1 + 1;
            END IF;

            IF TO_NUMBER(TO_CHAR(lDatCnc, 'YYYY')) = pExr THEN
                IF Meses(TO_NUMBER(TO_CHAR(lDatCnc, 'MM'))).Valor2 IS NULL THEN
                    Meses(TO_NUMBER(TO_CHAR(lDatCnc, 'MM'))).Valor2 := 0;
                END IF;
                Meses(TO_NUMBER(TO_CHAR(lDatCnc, 'MM'))).Valor2 := Meses(TO_NUMBER(TO_CHAR(lDatCnc, 'MM'))).Valor2 + 1;
            END IF;

            IF lDatCri < lFinalAno AND (lDatCnc IS NULL OR lDatCnc >= lFinalAno) THEN
                Meses(13).Valor1 := Meses(13).Valor1 + 1;
            END IF;
        END LOOP;

        IF CursorIdadeGrupos%ISOPEN THEN
            CLOSE CursorIdadeGrupos;
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, NULL, NULL, Meses(0).Valor1, NULL, Meses(1).Valor1, Meses(1).Valor2, Meses(2).Valor1, Meses(2).Valor2, Meses(3).Valor1, Meses(3).Valor2, Meses(4).Valor1, Meses(4).Valor2, Meses(5).Valor1, Meses(5).Valor2, Meses(6).Valor1, Meses(6).Valor2, Meses(7).Valor1, Meses(7).Valor2, Meses(8).Valor1, Meses(8).Valor2, Meses(9).Valor1, Meses(9).Valor2, Meses(10).Valor1, Meses(10).Valor2, Meses(11).Valor1, Meses(11).Valor2, Meses(12).Valor1, Meses(12).Valor2, Meses(13).Valor1, NULL, NULL, NULL);
    END LOOP;

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN pRecordset FOR
    SELECT *
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE));
END;

/* Fun��o     : RelGruposAtivos
   Prop�sito  : Retorna a listagem ou o Total de Grupos Ativos da Empresa
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios, sendo: 0-Grupos sem total, 1-Coordena��o, 2-UG, 3-UO e 4-Empresa
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
                pDat-Data base para a busca das informa��es do relat�rio
   Cria��o    : 12/12/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelGruposAtivos(pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pDat DATE, pRecordset OUT tCursorType)
    IS
        CursorUnidades      tCursorType;

        lStrGrupos          VARCHAR2(4000);

        lTblTemp            OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lIdeUniOpe          NUMBER(13);
        lNmeUniOpe          VARCHAR2(25);
        lIdeUni             NUMBER(13);
        lSigUni             VARCHAR2(25);
        lIdeUniRel          NUMBER(13);
        lSigUniRel          VARCHAR2(25);
        lIdeGruCCQ          NUMBER(13);
        lNmeGruCCQ          VARCHAR2(45);

        lPodeSair           INT;

        lTotalProjetos      INT;
        lMaxDatEncProjeto   DATE;
BEGIN
    IF pTipo = 0 THEN      -- listagem dos Grupos
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, VGRUCCQ.IDEGRUCCQ, VGRUCCQ.NMEGRUCCQ FROM ';
    ELSIF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, VGRUCCQ.IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 2 THEN   -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, '''' SIGUNIREL, VGRUCCQ.IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 3 THEN   -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, '''' SIGUNI, VUNIREL.IDEUNIREL, '''' SIGUNIREL, VGRUCCQ.IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 4 THEN   -- Agrupamento por Empresa
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, '''' NMEUNIOPE, VUNI.IDEUNI, '''' SIGUNI, VUNIREL.IDEUNIREL, '''' SIGUNIREL, VGRUCCQ.IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    -- Local para condi��es espec�ficas que filtre diretamente a tabela de Grupos
    lStrGrupos := lStrGrupos || ' AND TUNI.DATCRI <= TO_DATE(''' || TO_CHAR(pDat, 'DD/MM/YYYY') || ' 23:59:59'', ''DD/MM/YYYY HH24:MI:SS'') AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= TO_DATE(''' || TO_CHAR(pDat, 'DD/MM/YYYY') || ' 00:00:00'', ''DD/MM/YYYY HH24:MI:SS''))';
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    lStrGrupos := lStrGrupos || ' ORDER BY NMEUNIOPE, SIGUNI, SIGUNIREL, NMEGRUCCQ';

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lIdeUniOpe, lNmeUniOpe, lIdeUni, lSigUni, lIdeUniRel, lSigUniRel, lIdeGruCCQ, lNmeGruCCQ;
        EXIT WHEN CursorUnidades%NOTFOUND;

        SELECT COUNT(TSOLPRB.IDESOLPRB),
               MAX(TSOLPRB.DATENC)
          INTO lTotalProjetos,
               lMaxDatEncProjeto
          FROM TSOLPRB
         WHERE TSOLPRB.IDEUNI = lIdeGruCCQ
           AND TSOLPRB.DATENC >= add_months(pDat, -12)
           AND TSOLPRB.DATENC <= pDat;

        lPodeSair := 0;

        IF lTotalProjetos > 0 THEN
            FOR lI IN 1..lTblTemp.Count
            LOOP
                IF (lTblTemp(lI).STRCOL1 = lNmeUniOpe OR lTblTemp(lI).STRCOL1 IS NULL AND lNmeUniOpe IS NULL) AND (lTblTemp(lI).STRCOL2 = lSigUni OR lTblTemp(lI).STRCOL2 IS NULL AND lSigUni IS NULL) AND (lTblTemp(lI).STRCOL3 = lSigUniRel OR lTblTemp(lI).STRCOL3 IS NULL AND lSigUniRel IS NULL) AND (lTblTemp(lI).STRCOL4 = lNmeGruCCQ OR lTblTemp(lI).STRCOL4 IS NULL AND lNmeGruCCQ IS NULL) THEN
                    lTblTemp(lI).VALANOANT01 := lTblTemp(lI).VALANOANT01 + 1;
                    lTblTemp(lI).VALDAT01 := lMaxDatEncProjeto;
                    lPodeSair := 1;
                    EXIT;
                END IF;
            END LOOP;
            IF lPodeSair = 0 THEN
                lTblTemp.Extend;
                lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, lMaxDatEncProjeto, NULL);
            END IF;
        ELSE
            SELECT MAX(TSOLPRB.DATENC)
              INTO lMaxDatEncProjeto
              FROM TSOLPRB
             WHERE TSOLPRB.IDEUNI = lIdeGruCCQ
               AND TSOLPRB.DATENC <= pDat;        
        
            FOR lI IN 1..lTblTemp.Count
            LOOP
                IF (lTblTemp(lI).STRCOL1 = lNmeUniOpe OR lTblTemp(lI).STRCOL1 IS NULL AND lNmeUniOpe IS NULL) AND (lTblTemp(lI).STRCOL2 = lSigUni OR lTblTemp(lI).STRCOL2 IS NULL AND lSigUni IS NULL) AND (lTblTemp(lI).STRCOL3 = lSigUniRel OR lTblTemp(lI).STRCOL3 IS NULL AND lSigUniRel IS NULL) AND (lTblTemp(lI).STRCOL4 = lNmeGruCCQ OR lTblTemp(lI).STRCOL4 IS NULL AND lNmeGruCCQ IS NULL) THEN
                    lTblTemp(lI).VALANOANT02 := lTblTemp(lI).VALANOANT02 + 1;
                    IF NOT lMaxDatEncProjeto IS NULL THEN
                        lTblTemp(lI).VALDAT01 := lMaxDatEncProjeto;
                    END IF;
                    lPodeSair := 1;
                    EXIT;
                END IF;
            END LOOP;
            IF lPodeSair = 0 THEN
                lTblTemp.Extend;
                lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, lMaxDatEncProjeto, NULL);
            END IF;
        END IF;
    END LOOP;

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN pRecordset FOR
    SELECT *
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE));
END;

/* Fun��o     : RelListagemGrupos
   Prop�sito  : Retorna a Listagem dos Grupos existentes na empesa
   Par�metros : pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
                pSomenteGruposAtivos-Indica se � para retornar todos os Grupos ou somente os Grupos Ativos
   Cria��o    : 04/01/2009 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelListagemGrupos(pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pSomenteGruposAtivos INT, pRecordset OUT tCursorType)
    IS
BEGIN

   OPEN pRecordSet FOR
      SELECT VUNISPR.NMEUNIOPE,
             VUNISPR.SIGUNI,
             VUNIREL.SIGUNIREL,
             TUNI.NME NMEGRUCCQ,
             TUNI.DATCRI,
             TUNI.DATCNC,
             VPAR.NMEUSU
        FROM TUNI, TUNITYP,
             (SELECT VUNI.IDEUNI, VUNI.IDEUNIOPE, VUNI.SIGUNIOPE NMEUNIOPE, VUNI.SIG SIGUNI FROM VUNI) VUNISPR,
             (SELECT VUNI.IDEUNI, VUNI.SIG SIGUNIREL FROM VUNI) VUNIREL,
             (SELECT TPAR.IDEUNI, TUSU.NME NMEUSU FROM TPAR, TUSU WHERE TPAR.IDEUSU = TUSU.IDEUSU AND TPAR.FUN = 1 AND TPAR.STT = 1) VPAR
       WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP
         AND TUNI.IDESPR = VUNISPR.IDEUNI (+)
         AND TUNI.IDEUNIREL = VUNIREL.IDEUNI (+)
         AND TUNI.IDEUNI = VPAR.IDEUNI (+)
         AND TUNITYP.TYP = 3
         AND TUNI.IDEEMP = pIdeEmp
         AND (pIdeUniOpe = 0 OR VUNISPR.IDEUNIOPE = pIdeUniOpe)
         AND (pIdeUni = 0 OR TUNI.IDESPR = pIdeUni)
         AND (pIdeUniRel = 0 OR TUNI.IDEUNIREL = pIdeUniRel)
         AND (pSomenteGruposAtivos = 0 OR (pSomenteGruposAtivos <> 0 AND TUNI.ATV <> 0))
      ORDER BY NMEUNIOPE,
               SIGUNI,
               SIGUNIREL,
               NMEGRUCCQ;

END;

/* Fun��o     : RelProdutividadeGrupos
   Prop�sito  : Retorna a Produtividade dos Grupos por UO, UG (Ger�ncia) ou Coordena��o
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios, sendo: 1-Coordena��o, 2-UG, 3-UO e 4-Toda Empresa
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
                pDatIni-Data do Per�odo Inicial
                pDatFin-Data do Per�odo Final
   Cria��o    : 12/12/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelProdutividadeGrupos(pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pDatIni DATE, pDatFin DATE, pRecordset OUT tCursorType)
    IS
        CursorUnidades      tCursorType;

        lStrGrupos          VARCHAR2(4000);

        lTblTemp            OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lIdeUniOpe          NUMBER(13);
        lNmeUniOpe          VARCHAR2(25);
        lIdeUni             NUMBER(13);
        lSigUni             VARCHAR2(25);
        lIdeUniRel          NUMBER(13);
        lSigUniRel          VARCHAR2(25);
        lIdeGruCCQ          NUMBER(13);
        lNmeGruCCQ          VARCHAR2(45);

        lPodeSair           INT;

        lTotalProjetos              INT;
BEGIN
    IF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, VGRUCCQ.IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 2 THEN   -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, '''' SIGUNIREL, VGRUCCQ.IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 3 THEN   -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, '''' SIGUNI, VUNIREL.IDEUNIREL, '''' SIGUNIREL, VGRUCCQ.IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 4 THEN   -- Agrupamento pela Empresa
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, '''' NMEUNIOPE, VUNI.IDEUNI, '''' SIGUNI, VUNIREL.IDEUNIREL, '''' SIGUNIREL, VGRUCCQ.IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    -- Local para condi��es espec�ficas que filtre diretamente a tabela de Grupos
    lStrGrupos := lStrGrupos || ' AND TUNI.DATCRI <= TO_DATE(''' || TO_CHAR(pDatFin, 'DD/MM/YYYY') || ' 23:59:59'', ''DD/MM/YYYY HH24:MI:SS'') AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= TO_DATE(''' || TO_CHAR(pDatIni, 'DD/MM/YYYY') || ' 00:00:00'', ''DD/MM/YYYY HH24:MI:SS''))';
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    lStrGrupos := lStrGrupos || ' ORDER BY NMEUNIOPE, SIGUNI, SIGUNIREL, NMEGRUCCQ';

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lIdeUniOpe, lNmeUniOpe, lIdeUni, lSigUni, lIdeUniRel, lSigUniRel, lIdeGruCCQ, lNmeGruCCQ;
        EXIT WHEN CursorUnidades%NOTFOUND;

        SELECT COUNT(TSOLPRB.IDESOLPRB)
          INTO lTotalProjetos
          FROM TSOLPRB
         WHERE TSOLPRB.IDEUNI = lIdeGruCCQ
           AND TSOLPRB.DATENC >= add_months(TRUNC(SYSDATE, 'DD'), -12)
           AND TSOLPRB.DATENC <= SYSDATE;

        lPodeSair := 0;

        IF lTotalProjetos > 0 THEN
            FOR lI IN 1..lTblTemp.Count
            LOOP
                IF (lTblTemp(lI).STRCOL1 = lNmeUniOpe OR lTblTemp(lI).STRCOL1 IS NULL AND lNmeUniOpe IS NULL) AND (lTblTemp(lI).STRCOL2 = lSigUni OR lTblTemp(lI).STRCOL2 IS NULL AND lSigUni IS NULL) AND (lTblTemp(lI).STRCOL3 = lSigUniRel OR lTblTemp(lI).STRCOL3 IS NULL AND lSigUniRel IS NULL) AND (lTblTemp(lI).STRCOL4 = lNmeGruCCQ OR lTblTemp(lI).STRCOL4 IS NULL AND lNmeGruCCQ IS NULL) THEN
                    lTblTemp(lI).VALANOANT01 := lTblTemp(lI).VALANOANT01 + 1;
                    lTblTemp(lI).VALANOANT02 := lTblTemp(lI).VALANOANT02 + lTotalProjetos;
                    lPodeSair := 1;
                    EXIT;
                END IF;
            END LOOP;
            IF lPodeSair = 0 THEN
                lTblTemp.Extend;
                lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, 1, lTotalProjetos, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
            END IF;
        ELSE
            FOR lI IN 1..lTblTemp.Count
            LOOP
                IF (lTblTemp(lI).STRCOL1 = lNmeUniOpe OR lTblTemp(lI).STRCOL1 IS NULL AND lNmeUniOpe IS NULL) AND (lTblTemp(lI).STRCOL2 = lSigUni OR lTblTemp(lI).STRCOL2 IS NULL AND lSigUni IS NULL) AND (lTblTemp(lI).STRCOL3 = lSigUniRel OR lTblTemp(lI).STRCOL3 IS NULL AND lSigUniRel IS NULL) AND (lTblTemp(lI).STRCOL4 = lNmeGruCCQ OR lTblTemp(lI).STRCOL4 IS NULL AND lNmeGruCCQ IS NULL) THEN
                    lTblTemp(lI).VALANOANT01 := lTblTemp(lI).VALANOANT01 + 1;
                    lPodeSair := 1;
                    EXIT;
                END IF;
            END LOOP;
            IF lPodeSair = 0 THEN
                lTblTemp.Extend;
                lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
            END IF;
        END IF;
    END LOOP;

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN pRecordset FOR
    SELECT VTMPTBL.*, CASE WHEN VTMPTBL.VALANOANT01 = 0 THEN 0 ELSE VTMPTBL.VALANOANT02 / VTMPTBL.VALANOANT01 * 100 END PER
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE)) VTMPTBL;

END;

/* Fun��o     : RelNumeroCirculistas
   Prop�sito  : Retorna a movimenta��o mensal de circulistas e a situa��o no in�cio do ano e no final do ano
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios, sendo: 0-Grupo de CCQ, 1-Coordena��o, 2-UG, 3-UO e 4-Empresa
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
                pIdeGruCCQ-Identificador do Grupo de CCQ selecionado (n�o est� dispon�vel a todos os relat�rios)
                pExr-Exerc�cio selecionado (n�o est� dispon�vel a todos os relat�rios)
   Cria��o    : 31/07/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelNumeroCirculistas (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pExr INT, pRecordset OUT tCursorType)
    IS
        CursorUnidades          tCursorType;
        CursorNumeroCirculistas tCursorType;
        lStrGrupos              VARCHAR2(8000);
        lStrNumeroCirculistas   VARCHAR2(8000);

        lTblTemp            OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lIdeUniOpe              NUMBER(13);
        lNmeUniOpe              VARCHAR2(25);
        lIdeUni                 NUMBER(13);
        lSigUni                 VARCHAR2(25);
        lIdeUniRel              NUMBER(13);
        lSigUniRel              VARCHAR2(25);
        lIdeGruCCQ              NUMBER(13);
        lNmeGruCCQ              VARCHAR2(45);

        lIdePar                 NUMBER(13);

        lDatEnt                 DATE;
        lDatTrf                 DATE;

        lInicioAno              DATE := TO_DATE('01/01/' || pExr, 'DD/MM/YYYY');
        lFinalAno               DATE := ADD_MONTHS(TO_DATE('01/12/' || TO_CHAR(pExr), 'DD/MM/YYYY'), 1) - 0.00001;
BEGIN
    IF pTipo = 0 THEN   -- Agrupamento por Grupos
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, VGRUCCQ.IDEGRUCCQ, NVL(VGRUCCQ.NMEGRUCCQ, '''') NMEGRUCCQ FROM ';
    ELSIF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 2 THEN   -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 3 THEN   -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 4 THEN   -- Agrupamento pela Empresa
        lStrGrupos := 'SELECT DISTINCT 0 IDEUNIOPE, '''' NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    -- Local para condi��es espec�ficas que filtre diretamente a tabela de Grupos
    lStrGrupos := lStrGrupos || ' AND TUNI.DATCRI <= TO_DATE(''' || TO_CHAR(lFinalAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= TO_DATE(''' || TO_CHAR(lInicioAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS''))';
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    IF pIdeGruCCQ <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(pIdeGruCCQ);
    END IF;

    lStrGrupos := lStrGrupos || ' ORDER BY NMEUNIOPE, SIGUNI, SIGUNIREL, NMEGRUCCQ';

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lIdeUniOpe, lNmeUniOpe, lIdeUni, lSigUni, lIdeUniRel, lSigUniRel, lIdeGruCCQ, lNmeGruCCQ;
        EXIT WHEN CursorUnidades%NOTFOUND;

        Meses(0).Valor1 := 0;
        Meses(1).Valor1 := NULL;
        Meses(2).Valor1 := NULL;
        Meses(3).Valor1 := NULL;
        Meses(4).Valor1 := NULL;
        Meses(5).Valor1 := NULL;
        Meses(6).Valor1 := NULL;
        Meses(7).Valor1 := NULL;
        Meses(8).Valor1 := NULL;
        Meses(9).Valor1 := NULL;
        Meses(10).Valor1 := NULL;
        Meses(11).Valor1 := NULL;
        Meses(12).Valor1 := NULL;
        Meses(13).Valor1 := 0;

        Meses(0).Valor2 := 0;
        Meses(1).Valor2 := NULL;
        Meses(2).Valor2 := NULL;
        Meses(3).Valor2 := NULL;
        Meses(4).Valor2 := NULL;
        Meses(5).Valor2 := NULL;
        Meses(6).Valor2 := NULL;
        Meses(7).Valor2 := NULL;
        Meses(8).Valor2 := NULL;
        Meses(9).Valor2 := NULL;
        Meses(10).Valor2 := NULL;
        Meses(11).Valor2 := NULL;
        Meses(12).Valor2 := NULL;
        Meses(13).Valor2 := 0;

        lStrNumeroCirculistas := 'SELECT DISTINCT VGRUCCQ.IDEPAR, TRUNC(VGRUCCQ.DATENT, ''MONTH'') DATENT, TRUNC(VGRUCCQ.DATTRF, ''MONTH'') DATTRF FROM ';

        lStrNumeroCirculistas := lStrNumeroCirculistas || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL, VPAR.IDEPAR, VPAR.DATENT, VPAR.DATTRF FROM TUNI, TUNITYP, VPAR WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNI.IDEUNI = VPAR.IDEUNI AND VPAR.FUN IN ([FUNCAO]) AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
        lStrNumeroCirculistas := lStrNumeroCirculistas || ') VGRUCCQ, (SELECT VUNI.IDEUNI, VUNI.IDEUNIOPE FROM VUNI WHERE TYP = 1) VUNI ';

        lStrNumeroCirculistas := lStrNumeroCirculistas || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI';

        IF lIdeUniOpe <> 0 THEN
           lStrNumeroCirculistas := lStrNumeroCirculistas || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(lIdeUniOpe);
        END IF;

        IF lIdeUni <> 0 THEN
              lStrNumeroCirculistas := lStrNumeroCirculistas || ' AND VUNI.IDEUNI = ' || TO_CHAR(lIdeUni);
        END IF;

        IF lIdeUniRel <> 0 THEN
              lStrNumeroCirculistas := lStrNumeroCirculistas || ' AND VGRUCCQ.IDEUNIREL = ' || TO_CHAR(lIdeUniRel);
        END IF;

        IF lIdeGruCCQ <> 0 THEN
            lStrNumeroCirculistas := lStrNumeroCirculistas || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(lIdeGruCCQ);
        END IF;

        IF CursorNumeroCirculistas%ISOPEN THEN
            CLOSE CursorNumeroCirculistas;
        END IF;

        OPEN CursorNumeroCirculistas FOR REPLACE(lStrNumeroCirculistas, '[FUNCAO]', '1, 2, 3');
        LOOP
            FETCH CursorNumeroCirculistas INTO lIdePar, lDatEnt, lDatTrf;
            EXIT WHEN CursorNumeroCirculistas%NOTFOUND;

            IF lDatEnt < lInicioAno AND (lDatTrf IS NULL OR lDatTrf >= lInicioAno) THEN
                Meses(0).Valor1 := Meses(0).Valor1 + 1;
            END IF;

            IF TO_NUMBER(TO_CHAR(lDatEnt, 'YYYY')) = pExr THEN
                IF Meses(TO_NUMBER(TO_CHAR(lDatEnt, 'MM'))).Valor1 IS NULL THEN
                    Meses(TO_NUMBER(TO_CHAR(lDatEnt, 'MM'))).Valor1 := 0;
                END IF;
                Meses(TO_NUMBER(TO_CHAR(lDatEnt, 'MM'))).Valor1 := Meses(TO_NUMBER(TO_CHAR(lDatEnt, 'MM'))).Valor1 + 1;
            END IF;

            IF TO_NUMBER(TO_CHAR(lDatTrf, 'YYYY')) = pExr THEN
                IF Meses(TO_NUMBER(TO_CHAR(lDatTrf, 'MM'))).Valor2 IS NULL THEN
                    Meses(TO_NUMBER(TO_CHAR(lDatTrf, 'MM'))).Valor2 := 0;
                END IF;
                Meses(TO_NUMBER(TO_CHAR(lDatTrf, 'MM'))).Valor2 := Meses(TO_NUMBER(TO_CHAR(lDatTrf, 'MM'))).Valor2 + 1;
            END IF;

            IF lDatEnt < lFinalAno AND (lDatTrf IS NULL OR lDatTrf >= lFinalAno) THEN
                Meses(13).Valor1 := Meses(13).Valor1 + 1;
            END IF;
        END LOOP;

        IF CursorNumeroCirculistas%ISOPEN THEN
            CLOSE CursorNumeroCirculistas;
        END IF;

        OPEN CursorNumeroCirculistas FOR REPLACE(lStrNumeroCirculistas, '[FUNCAO]', '4');
        LOOP
            FETCH CursorNumeroCirculistas INTO lIdePar, lDatEnt, lDatTrf;
            EXIT WHEN CursorNumeroCirculistas%NOTFOUND;

            IF lDatEnt < lInicioAno AND (lDatTrf IS NULL OR lDatTrf >= lInicioAno) THEN
                Meses(0).Valor2 := Meses(0).Valor2 + 1;
            END IF;

            IF lDatEnt < lFinalAno AND (lDatTrf IS NULL OR lDatTrf >= lFinalAno) THEN
                Meses(13).Valor2 := Meses(13).Valor2 + 1;
            END IF;
        END LOOP;

        IF CursorNumeroCirculistas%ISOPEN THEN
            CLOSE CursorNumeroCirculistas;
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, Meses(0).Valor1, Meses(0).Valor2, Meses(1).Valor1, Meses(1).Valor2, Meses(2).Valor1, Meses(2).Valor2, Meses(3).Valor1, Meses(3).Valor2, Meses(4).Valor1, Meses(4).Valor2, Meses(5).Valor1, Meses(5).Valor2, Meses(6).Valor1, Meses(6).Valor2, Meses(7).Valor1, Meses(7).Valor2, Meses(8).Valor1, Meses(8).Valor2, Meses(9).Valor1, Meses(9).Valor2, Meses(10).Valor1, Meses(10).Valor2, Meses(11).Valor1, Meses(11).Valor2, Meses(12).Valor1, Meses(12).Valor2, Meses(13).Valor1, Meses(13).Valor2, NULL, NULL);
    END LOOP;

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN pRecordset FOR
    SELECT *
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE));
END;

/* Fun��o     : RelPlacarGeralCirculistas
   Prop�sito  : Retorna a Produtividade dos Grupos por UO, UG (Ger�ncia) ou Coordena��o
   Par�metros : pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeGruCCQ-IDentificador do Grupo de CCQ
                pSomenteGruposAtivos-Indica se deve listar somente os Grupos Ativos ou Todos.
                pSomenteParticipantesAtivos-Indica se deve listar somente os Participantes Ativos ou Todos.
   Cria��o    : 29/07/09 - kdu
   �ltima Alt.: 02/05/2016 - Leonardo Lage*/

PROCEDURE RelPlacarGeralCirculistas(pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeGruCCQ NUMBER, pSomenteGruposAtivos INT, pSomenteParticipantesAtivos INT, pRecordset OUT tCursorType)
    IS
BEGIN
    OPEN pRecordset FOR
       SELECT NVL(VUNI.NMEUNIOPE, '') NMEUNIOPE,
              NVL(VUNI.SIGUNI, '') SIGUNI,
              NVL(VUNIREL.SIGUNIREL, '') SIGUNIREL,
              NVL(VGRUCCQ.NMEGRUCCQ, '') NMEGRUCCQ,
              VPAR.NMEUSU,
              VPAR.FUN,
              VPAR.DATENT,
              VPAR.DATTRF,          
              DECODE(VPAR.STT, 0, 'Inativo', 1, 'Ativo', 2, 'Transferido') STT,
              VPAR.NMEUNITRF,
              TO_CHAR(VGRUCCQ.DatCri, 'DD/MM/YYYY') DatCri
         FROM (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL, TUNI.ATV, TUNI.IDEEMP, TUNI.DATCRI, TUNITYP.TYP FROM TUNI,TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = pIdeEmp) VGRUCCQ,
              (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE, IDESPR FROM VUNI WHERE TYP = 1) VUNI,
              (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL,
              (SELECT TPAR.IDEPAR, TPAR.IDEUNI, TUSU.NME NMEUSU, TPAR.FUN, TPAR.DATENT, TPAR.DATTRF, TUNITRF.NME NMEUNITRF, TPAR.STT FROM TPAR, TUSU, TUNI TUNITRF WHERE TPAR.IDEUSU = TUSU.IDEUSU AND TPAR.IDEUNITRF = TUNITRF.IDEUNI (+)) VPAR
        WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+)
          AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)
          AND VGRUCCQ.IDEGRUCCQ = VPAR.IDEUNI (+)
          AND ((pSomenteGruposAtivos = 0) OR (pSomenteGruposAtivos <> 0 AND VGRUCCQ.ATV <> 0))
          AND ((pSomenteParticipantesAtivos = 0) OR (pSomenteParticipantesAtivos <> 0 AND VPAR.STT = 1))
          AND ((pIdeUniOpe <> 0 AND VUNI.IDEUNIOPE = pIdeUniOpe) OR pIdeUniOpe = 0 )
          AND ((pIdeUni <> 0 AND VUNI.IDEUNI = pIdeUni) OR pIdeUni = 0 )
          AND ((pIdeGruCCQ <> 0 AND VGRUCCQ.IDEGRUCCQ = pIdeGruCCQ) OR pIdeGruCCQ = 0 )
    ORDER BY NMEUNIOPE,
             SIGUNIREL,
             SIGUNI,
             NMEUSU;
END;

/* Fun��o     : RelAdesaoEfetiva
   Prop�sito  : Retorna o Percentual de Ades�o Efetiva por UO, UG (Ger�ncia) ou Coordena��o
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios, sendo: 0-Grupos sem total, 1-Coordena��o, 2-UG, 3-UO e 4-Toda Empresa
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
   Cria��o    : 12/12/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelAdesaoEfetiva(pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pRecordset OUT tCursorType)
    IS
        CursorUnidades      tCursorType;

        lStrGrupos          VARCHAR2(4000);

        lTblTemp            OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lIdeUniOpe          NUMBER(13);
        lNmeUniOpe          VARCHAR2(25);
        lIdeUni             NUMBER(13);
        lSigUni             VARCHAR2(25);
        lIdeUniRel          NUMBER(13);
        lSigUniRel          VARCHAR2(25);
        lIdeGruCCQ          NUMBER(13);
        lNmeGruCCQ          VARCHAR2(45);

        lPodeSair           INT;

        lTotalProjetos              INT;
        lTotalParticipantesAtivos   INT;
BEGIN
    IF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, VGRUCCQ.IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 2 THEN   -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, '''' SIGUNIREL, VGRUCCQ.IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 3 THEN   -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, '''' SIGUNI, VUNIREL.IDEUNIREL, '''' SIGUNIREL, VGRUCCQ.IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 4 THEN   -- Agrupamento pela Empresa
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, '''' NMEUNIOPE, VUNI.IDEUNI, '''' SIGUNI, VUNIREL.IDEUNIREL, '''' SIGUNIREL, VGRUCCQ.IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    -- Local para condi��es espec�ficas que filtre diretamente a tabela de Grupos
    lStrGrupos := lStrGrupos || ' AND TUNI.DATCRI <= TO_DATE(''' || TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= TO_DATE(''' || TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS''))';
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    lStrGrupos := lStrGrupos || ' ORDER BY NMEUNIOPE, SIGUNI, SIGUNIREL, NMEGRUCCQ';

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lIdeUniOpe, lNmeUniOpe, lIdeUni, lSigUni, lIdeUniRel, lSigUniRel, lIdeGruCCQ, lNmeGruCCQ;
        EXIT WHEN CursorUnidades%NOTFOUND;

        SELECT COUNT(TPAR.IDEPAR)
          INTO lTotalParticipantesAtivos
          FROM TPAR
         WHERE TPAR.IDEUNI = lIdeGruCCQ
           AND TPAR.STT = 1
           AND TPAR.FUN <= 3;

        SELECT COUNT(TSOLPRB.IDESOLPRB)
          INTO lTotalProjetos
          FROM TSOLPRB
         WHERE TSOLPRB.IDEUNI = lIdeGruCCQ
           AND TSOLPRB.DATENC >= add_months(TRUNC(SYSDATE, 'DD'), -12)
           AND TSOLPRB.DATENC <= SYSDATE;

        lPodeSair := 0;

        IF lTotalProjetos > 0 THEN
            FOR lI IN 1..lTblTemp.Count
            LOOP
                IF (lTblTemp(lI).STRCOL1 = lNmeUniOpe OR lTblTemp(lI).STRCOL1 IS NULL AND lNmeUniOpe IS NULL) AND (lTblTemp(lI).STRCOL2 = lSigUni OR lTblTemp(lI).STRCOL2 IS NULL AND lSigUni IS NULL) AND (lTblTemp(lI).STRCOL3 = lSigUniRel OR lTblTemp(lI).STRCOL3 IS NULL AND lSigUniRel IS NULL) AND (lTblTemp(lI).STRCOL4 = lNmeGruCCQ OR lTblTemp(lI).STRCOL4 IS NULL AND lNmeGruCCQ IS NULL) THEN
                    lTblTemp(lI).VALANOANT01 := lTblTemp(lI).VALANOANT01 + lTotalParticipantesAtivos;
                    lTblTemp(lI).VALANOANT02 := lTblTemp(lI).VALANOANT02 + lTotalParticipantesAtivos;
                    lPodeSair := 1;
                    EXIT;
                END IF;
            END LOOP;
            IF lPodeSair = 0 THEN
                lTblTemp.Extend;
                lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, lTotalParticipantesAtivos, lTotalParticipantesAtivos, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
            END IF;
        ELSE
            FOR lI IN 1..lTblTemp.Count
            LOOP
                IF (lTblTemp(lI).STRCOL1 = lNmeUniOpe OR lTblTemp(lI).STRCOL1 IS NULL AND lNmeUniOpe IS NULL) AND (lTblTemp(lI).STRCOL2 = lSigUni OR lTblTemp(lI).STRCOL2 IS NULL AND lSigUni IS NULL) AND (lTblTemp(lI).STRCOL3 = lSigUniRel OR lTblTemp(lI).STRCOL3 IS NULL AND lSigUniRel IS NULL) AND (lTblTemp(lI).STRCOL4 = lNmeGruCCQ OR lTblTemp(lI).STRCOL4 IS NULL AND lNmeGruCCQ IS NULL) THEN
                    lTblTemp(lI).VALANOANT01 := lTblTemp(lI).VALANOANT01 + lTotalParticipantesAtivos;
                    lPodeSair := 1;
                    EXIT;
                END IF;
            END LOOP;
            IF lPodeSair = 0 THEN
                lTblTemp.Extend;
                lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, lTotalParticipantesAtivos, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
            END IF;
        END IF;
    END LOOP;

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN pRecordset FOR
    SELECT VTMPTBL.*, CASE WHEN VTMPTBL.VALANOANT01 = 0 THEN 0 ELSE VTMPTBL.VALANOANT02 / VTMPTBL.VALANOANT01 * 100 END PER
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE)) VTMPTBL;

END;

/* Fun��o     : RelPercParticipacaoPrograma
   Prop�sito  : Retorna o Percentual de Participa��o dos Funcion�rios no Programa de CCQ da Empresa
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios, sendo: 1-Coordena��o, 2-UG, 3-UO e 4-Toda Empresa
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
   Cria��o    : 29/07/2009 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelPercParticipacaoPrograma(pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pRecordset OUT tCursorType)
    IS
        CursorUnidades      tCursorType;

        lStrGrupos          VARCHAR2(4000);

        lTblTemp            OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lIdeUniOpe          NUMBER(13);
        lNmeUniOpe          VARCHAR2(25);
        lIdeUni             NUMBER(13);
        lSigUni             VARCHAR2(25);
        lIdeUniRel          NUMBER(13);
        lSigUniRel          VARCHAR2(25);

        lIdeUniSel          NUMBER(13);

        lTotalFuncionariosAtivos    INT;
        lTotalParticipantesAtivos   INT;
BEGIN
    IF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL FROM ';
    ELSIF pTipo = 2 THEN   -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, '''' SIGUNIREL FROM ';
    ELSIF pTipo = 3 THEN   -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, '''' SIGUNI, VUNIREL.IDEUNIREL, '''' SIGUNIREL FROM ';
    ELSIF pTipo = 4 THEN   -- Agrupamento pela Empresa
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, '''' NMEUNIOPE, VUNI.IDEUNI, '''' SIGUNI, VUNIREL.IDEUNIREL, '''' SIGUNIREL FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    -- Local para condi��es espec�ficas que filtre diretamente a tabela de Grupos
    lStrGrupos := lStrGrupos || ' AND TUNI.DATCRI <= TO_DATE(''' || TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= TO_DATE(''' || TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS''))';
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    lStrGrupos := lStrGrupos || ' ORDER BY NMEUNIOPE, SIGUNI, SIGUNIREL';

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lIdeUniOpe, lNmeUniOpe, lIdeUni, lSigUni, lIdeUniRel, lSigUniRel;
        EXIT WHEN CursorUnidades%NOTFOUND;

        IF pTipo = 1 THEN
            lIdeUniSel := lIdeUniRel;
        ELSIF pTipo = 2 THEN
            lIdeUniSel := lIdeUni;
        ELSIF pTipo = 3 THEN
            lIdeUniSel := lIdeUniOpe;
        END IF;

        IF pTipo <> 4 THEN
            SELECT COUNT(TPAR.IDEPAR)
              INTO lTotalParticipantesAtivos
              FROM TPAR, TUSU
             WHERE TPAR.IDEUSU = TUSU.IDEUSU
               AND TUSU.IDEUNIGER IN (SELECT VUNI.IDEUNI
                                        FROM (SELECT TUNI.IDEUNI, TUNI.IDESPR
                                                FROM TUNI
                                               WHERE TUNI.IDEUNITYP IN (SELECT TUNITYP.IDEUNITYP
                                                                          FROM TUNITYP
                                                                         WHERE TUNITYP.TYP = 1)) VUNI
                                      CONNECT BY PRIOR VUNI.IDEUNI = VUNI.IDESPR
                                      START WITH VUNI.IDEUNI = lIdeUniSel)
               AND TPAR.STT = 1
               AND TPAR.FUN <= 3;

            SELECT COUNT(TUSU.IDEUSU)
              INTO lTotalFuncionariosAtivos
              FROM TUSU
             WHERE TUSU.IDEUNIGER IN (SELECT VUNI.IDEUNI
                                        FROM (SELECT TUNI.IDEUNI, TUNI.IDESPR
                                                FROM TUNI
                                               WHERE TUNI.IDEUNITYP IN (SELECT TUNITYP.IDEUNITYP
                                                                          FROM TUNITYP
                                                                         WHERE TUNITYP.TYP = 1)) VUNI
                                      CONNECT BY PRIOR VUNI.IDEUNI = VUNI.IDESPR
                                      START WITH VUNI.IDEUNI = lIdeUniSel)
               AND TUSU.STT <> 0;
        ELSE
            SELECT COUNT(TPAR.IDEPAR)
              INTO lTotalParticipantesAtivos
              FROM TPAR, TUSU
             WHERE TPAR.IDEUSU = TUSU.IDEUSU
               AND TPAR.STT = 1
               AND TPAR.FUN <= 3;

            SELECT COUNT(TUSU.IDEUSU)
              INTO lTotalFuncionariosAtivos
              FROM TUSU
             WHERE TUSU.STT <> 0;
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, NULL, NULL, lTotalFuncionariosAtivos, lTotalParticipantesAtivos, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
    END LOOP;

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN pRecordset FOR
    SELECT VTMPTBL.*, CASE WHEN VTMPTBL.VALANOANT01 = 0 THEN 0 ELSE VTMPTBL.VALANOANT02 / VTMPTBL.VALANOANT01 * 100 END PER
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE)) VTMPTBL;

END;

/* Fun��o     : RelTempoCirculistas
   Prop�sito  : Agrupar todas as rotinas necess�rias ao retorno das informa��es para os Relat�rios do CCQ
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios, sendo: 0-Grupos sem total, 1-Coordena��o, 2-UG, 3-UO e 4-Toda Empresa
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
                pIdeGruCCQ-Identificador do Grupo de CCQ selecionado (n�o est� dispon�vel a todos os relat�rios)
   Cria��o    : 31/07/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelTempoCirculistas (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pRecordset OUT tCursorType)
    IS
        CursorUnidades          tCursorType;
        lStrGrupos              VARCHAR2(4000);

        lTblTemp                OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lNmeUniOpe              VARCHAR2(30);
        lSigUni                 VARCHAR2(50);
        lSigUniRel              VARCHAR2(50);
        lNmeGruCCQ              VARCHAR2(50);

        lTotalMeses             INT;
BEGIN
    IF pTipo = 0 THEN      -- Agrupamento por Grupo de CCQ
        lStrGrupos := 'SELECT DISTINCT NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, NVL(VUNI.SIGUNI, '''') SIGUNI, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, VGRUCCQ.NMEGRUCCQ, ROUND(AVG(MESES), 0) TOTALMESES FROM ';
    ELSIF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, NVL(VUNI.SIGUNI, '''') SIGUNI, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, '''' NMEGRUCCQ, ROUND(AVG(MESES), 0) TOTALMESES FROM ';
    ELSIF pTipo = 2 THEN  -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, NVL(VUNI.SIGUNI, '''') SIGUNI, '''' SIGUNIREL, '''' NMEGRUCCQ, ROUND(AVG(MESES), 0) TOTALMESES FROM ';
    ELSIF pTipo = 3 THEN  -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, '''' SIGUNI, '''' SIGUNIREL, '''' NMEGRUCCQ, ROUND(AVG(MESES), 0) TOTALMESES FROM ';
    ELSIF pTipo = 4 THEN  -- Agrupamento por Empresa
        lStrGrupos := 'SELECT DISTINCT '''' NMEUNIOPE, '''' SIGUNI, '''' SIGUNIREL, '''' NMEGRUCCQ, ROUND(AVG(MESES), 0) TOTALMESES FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL, MONTHS_BETWEEN(SYSDATE, VPAR.DATADM) AS MESES FROM TUNI, TUNITYP, VPAR WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNI.IDEUNI = VPAR.IDEUNI AND VPAR.FUN <= 3 AND VPAR.STT = 1 AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    IF pIdeGruCCQ <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(pIdeGruCCQ);
    END IF;

    IF pTipo = 0 THEN       -- Agrupamento por Grupo
        lStrGrupos := lStrGrupos || ' GROUP BY NMEUNIOPE, SIGUNI, SIGUNIREL, NMEGRUCCQ';
    ELSIF pTipo = 1 THEN    -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := lStrGrupos || ' GROUP BY NMEUNIOPE, SIGUNI, SIGUNIREL';
    ELSIF pTipo = 2 THEN  -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := lStrGrupos || ' GROUP BY NMEUNIOPE, SIGUNI';
    ELSIF pTipo = 3 THEN  -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := lStrGrupos || ' GROUP BY NMEUNIOPE';
    END IF;

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, lTotalMeses;
        EXIT WHEN CursorUnidades%NOTFOUND;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, lTotalMeses, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
    END LOOP;

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN pRecordset FOR
    SELECT VTMPTBL.*
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE)) VTMPTBL;
END;

/* Fun��o     : RelTempoGrupos
   Prop�sito  : Retorna o Tempo M�dio de Forma��o de Grupos por UO, UG (Ger�ncia) ou Coordena��o
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios, sendo: 1-Coordena��o, 2-UG, 3-UO e 4-Toda Empresa
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
   Cria��o    : 31/07/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelTempoGrupos (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pRecordset OUT tCursorType)
    IS
        CursorUnidades          tCursorType;
        lStrGrupos              VARCHAR2(4000);

        lTblTemp            OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lNmeUniOpe          VARCHAR2(25);
        lSigUni             VARCHAR2(25);
        lSigUniRel          VARCHAR2(25);
        lNmeGruCCQ          VARCHAR2(45);

        lTotalMeses             INT;
BEGIN
    IF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, NVL(VUNI.SIGUNI, '''') SIGUNI, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, ROUND(AVG(MESES),0) TOTALMESES FROM ';
    ELSIF pTipo = 2 THEN   -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, NVL(VUNI.SIGUNI, '''') SIGUNI, '''' SIGUNIREL, ROUND(AVG(MESES),0) TOTALMESES FROM ';
    ELSIF pTipo = 3 THEN   -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, '''' SIGUNI, '''' SIGUNIREL, ROUND(AVG(MESES),0) TOTALMESES FROM ';
    ELSIF pTipo = 4 THEN   -- Agrupamento pela Empresa
        lStrGrupos := 'SELECT DISTINCT '''' NMEUNIOPE, '''' SIGUNI, '''' SIGUNIREL, ROUND(AVG(MESES),0) TOTALMESES FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL, MONTHS_BETWEEN(SYSDATE, TUNI.DATCRI) AS MESES FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    IF pTipo = 1 THEN    -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := lStrGrupos || ' GROUP BY NMEUNIOPE, SIGUNI, SIGUNIREL';
    ELSIF pTipo = 2 THEN  -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := lStrGrupos || ' GROUP BY NMEUNIOPE, SIGUNI';
    ELSIF pTipo = 3 THEN  -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := lStrGrupos || ' GROUP BY NMEUNIOPE';
    END IF;

    lStrGrupos := lStrGrupos || ' ORDER BY NMEUNIOPE, SIGUNI, SIGUNIREL';

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lNmeUniOpe, lSigUni, lSigUniRel, lTotalMeses;
        EXIT WHEN CursorUnidades%NOTFOUND;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, NULL, NULL, lTotalMeses, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
    END LOOP;

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN pRecordset FOR
    SELECT VTMPTBL.*
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE)) VTMPTBL;
END;

/* Fun��o     : RelNumeroProjetos
   Prop�sito  : Retorna a quantidade de projetos abertos e encerrados m�s-a-m�s por cada grupo
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios, sendo: 0-Grupo de CCQ, 1-Coordena��o, 2-UG, 3-UO e 4-Empresa
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
                pIdeGruCCQ-Identificador do Grupo de CCQ selecionado (n�o est� dispon�vel a todos os relat�rios)
                pExr-Exerc�cio selecionado (n�o est� dispon�vel a todos os relat�rios)
   Cria��o    : 31/07/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelNumeroProjetos (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pExr INT, pRecordset OUT tCursorType)
    IS
        CursorUnidades          tCursorType;
        CursorNumeroProjetos    tCursorType;

        lStrGrupos              VARCHAR2(8000);
        lStrNumeroProjetos      VARCHAR2(8000);

        lTblTemp                OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lIdeUniOpe              NUMBER(13);
        lNmeUniOpe              VARCHAR2(25);
        lIdeUni                 NUMBER(13);
        lSigUni                 VARCHAR2(25);
        lIdeUniRel              NUMBER(13);
        lSigUniRel              VARCHAR2(25);
        lIdeGruCCQ              NUMBER(13);
        lNmeGruCCQ              VARCHAR2(45);

        lIdeSolPrb              NUMBER(13);
        lDatAbe                 DATE;
        lDatEnc                 DATE;

        lInicioAno              DATE := TO_DATE('01/01/' || TO_CHAR(pExr), 'DD/MM/YYYY');
        lFinalAno               DATE := ADD_MONTHS(TO_DATE('01/12/' || TO_CHAR(pExr), 'DD/MM/YYYY'), 1) - 0.00001;
BEGIN
    IF pTipo = 0 THEN   -- Agrupamento por Grupos
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, VGRUCCQ.IDEGRUCCQ, NVL(VGRUCCQ.NMEGRUCCQ, '''') NMEGRUCCQ FROM ';
    ELSIF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 2 THEN   -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 3 THEN   -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 4 THEN   -- Agrupamento pela Empresa
        lStrGrupos := 'SELECT DISTINCT 0 IDEUNIOPE, '''' NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    -- Local para condi��es espec�ficas que filtre diretamente a tabela de Grupos
    lStrGrupos := lStrGrupos || ' AND TUNI.DATCRI <= TO_DATE(''' || TO_CHAR(lFinalAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= TO_DATE(''' || TO_CHAR(lInicioAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS''))';
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    IF pIdeGruCCQ <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(pIdeGruCCQ);
    END IF;

    lStrGrupos := lStrGrupos || ' ORDER BY NMEUNIOPE, SIGUNI, SIGUNIREL, NMEGRUCCQ';

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lIdeUniOpe, lNmeUniOpe, lIdeUni, lSigUni, lIdeUniRel, lSigUniRel, lIdeGruCCQ, lNmeGruCCQ;
        EXIT WHEN CursorUnidades%NOTFOUND;

        Meses(0).Valor1 := 0;
        Meses(1).Valor1 := NULL;
        Meses(2).Valor1 := NULL;
        Meses(3).Valor1 := NULL;
        Meses(4).Valor1 := NULL;
        Meses(5).Valor1 := NULL;
        Meses(6).Valor1 := NULL;
        Meses(7).Valor1 := NULL;
        Meses(8).Valor1 := NULL;
        Meses(9).Valor1 := NULL;
        Meses(10).Valor1 := NULL;
        Meses(11).Valor1 := NULL;
        Meses(12).Valor1 := NULL;
        Meses(13).Valor1 := 0;

        Meses(0).Valor2 := 0;
        Meses(1).Valor2 := NULL;
        Meses(2).Valor2 := NULL;
        Meses(3).Valor2 := NULL;
        Meses(4).Valor2 := NULL;
        Meses(5).Valor2 := NULL;
        Meses(6).Valor2 := NULL;
        Meses(7).Valor2 := NULL;
        Meses(8).Valor2 := NULL;
        Meses(9).Valor2 := NULL;
        Meses(10).Valor2 := NULL;
        Meses(11).Valor2 := NULL;
        Meses(12).Valor2 := NULL;
        Meses(13).Valor2 := 0;

        lStrNumeroProjetos := 'SELECT TSOLPRB.IDESOLPRB, TSOLPRB.DATABE, TSOLPRB.DATENC FROM ';
        lStrNumeroProjetos := lStrNumeroProjetos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
        lStrNumeroProjetos := lStrNumeroProjetos || ') VGRUCCQ, (SELECT VUNI.IDEUNI, VUNI.IDEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, TSOLPRB ';
        lStrNumeroProjetos := lStrNumeroProjetos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI AND VGRUCCQ.IDEGRUCCQ = TSOLPRB.IDEUNI';
        lStrNumeroProjetos := lStrNumeroProjetos || '   AND TSOLPRB.DATABE <= TO_DATE(''' || TO_CHAR(lFinalAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'')';

        IF lIdeUniOpe <> 0 THEN
           lStrNumeroProjetos := lStrNumeroProjetos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(lIdeUniOpe);
        END IF;

        IF lIdeUni <> 0 THEN
           lStrNumeroProjetos := lStrNumeroProjetos || ' AND VUNI.IDEUNI = ' || TO_CHAR(lIdeUni);
        END IF;

        IF lIdeUniRel <> 0 THEN
           lStrNumeroProjetos := lStrNumeroProjetos || ' AND VGRUCCQ.IDEUNIREL = ' || TO_CHAR(lIdeUniRel);
        END IF;

        IF lIdeGruCCQ <> 0 THEN
            lStrNumeroProjetos := lStrNumeroProjetos || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(lIdeGruCCQ);
        END IF;

        lStrNumeroProjetos := lStrNumeroProjetos || ' ORDER BY TSOLPRB.DATABE';

        IF CursorNumeroProjetos%ISOPEN THEN
            CLOSE CursorNumeroProjetos;
        END IF;

        OPEN CursorNumeroProjetos FOR lStrNumeroProjetos;
        LOOP
            FETCH CursorNumeroProjetos INTO lIdeSolPrb, lDatAbe, lDatEnc;
            EXIT WHEN CursorNumeroProjetos%NOTFOUND;

            IF lDatAbe < lInicioAno THEN
                Meses(0).Valor1 := Meses(0).Valor1 + 1;
            END IF;

            IF lDatEnc < lInicioAno THEN
                Meses(0).Valor2 := Meses(0).Valor2 + 1;
            END IF;

            IF TO_NUMBER(TO_CHAR(lDatAbe, 'YYYY')) = pExr THEN
                IF Meses(TO_NUMBER(TO_CHAR(lDatAbe, 'MM'))).Valor1 IS NULL THEN
                    Meses(TO_NUMBER(TO_CHAR(lDatAbe, 'MM'))).Valor1 := 0;
                END IF;
                Meses(TO_NUMBER(TO_CHAR(lDatAbe, 'MM'))).Valor1 := Meses(TO_NUMBER(TO_CHAR(lDatAbe, 'MM'))).Valor1 + 1;
            END IF;

            IF TO_NUMBER(TO_CHAR(lDatEnc, 'YYYY')) = pExr THEN
                IF Meses(TO_NUMBER(TO_CHAR(lDatEnc, 'MM'))).Valor2 IS NULL THEN
                    Meses(TO_NUMBER(TO_CHAR(lDatEnc, 'MM'))).Valor2 := 0;
                END IF;
                Meses(TO_NUMBER(TO_CHAR(lDatEnc, 'MM'))).Valor2 := Meses(TO_NUMBER(TO_CHAR(lDatEnc, 'MM'))).Valor2 + 1;
            END IF;

            IF lDatAbe < lFinalAno THEN
                Meses(13).Valor1 := Meses(13).Valor1 + 1;
            END IF;

            IF lDatEnc < lFinalAno THEN
                Meses(13).Valor2 := Meses(13).Valor2 + 1;
            END IF;
        END LOOP;

        IF CursorNumeroProjetos%ISOPEN THEN
            CLOSE CursorNumeroProjetos;
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, Meses(0).Valor1, Meses(0).Valor2, Meses(1).Valor1, Meses(1).Valor2, Meses(2).Valor1, Meses(2).Valor2, Meses(3).Valor1, Meses(3).Valor2, Meses(4).Valor1, Meses(4).Valor2, Meses(5).Valor1, Meses(5).Valor2, Meses(6).Valor1, Meses(6).Valor2, Meses(7).Valor1, Meses(7).Valor2, Meses(8).Valor1, Meses(8).Valor2, Meses(9).Valor1, Meses(9).Valor2, Meses(10).Valor1, Meses(10).Valor2, Meses(11).Valor1, Meses(11).Valor2, Meses(12).Valor1, Meses(12).Valor2, Meses(13).Valor1, Meses(13).Valor2, NULL, NULL);
    END LOOP;

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN pRecordset FOR
    SELECT *
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE));
END;

/* Fun��o     : RELATORIOS_RelListagemProjetos
   Prop�sito  : Retorna a quantidade de projetos abertos e encerrados m�s-a-m�s durante um ano
   Par�metros : pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
                pIdeGruCCQ-Identificador do Grupo de CCQ selecionado
                pIdeGruInd-Identificador do Grupo de CCQ selecionado
                pIdeMetSolPrb-Identificador do Grupo de CCQ selecionado
                pPerIniAbe-Per�odo inicial da Abertura dos Projetos
                pPerFinAbe-Per�odo final da Abertura dos Projetos
                pPerIniEnc-Per�odo inicial do Encerramento dos Projetos
                pPerFinEnc-Per�odo final da Encerramento dos Projetos
   Cria��o    : 31/07/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelListagemProjetos (pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pIdeGruInd NUMBER, pIdeMetSolPrb NUMBER, pPerIniAbe DATE, pPerFinAbe DATE, pPerIniEnc DATE, pPerFinEnc DATE, pRecordset OUT tCursorType)
    IS
        lPerIniAbe              DATE := pPerIniAbe;
        lPerFinAbe              DATE := pPerFinAbe;
        lPerIniEnc              DATE := pPerIniEnc;
        lPerFinEnc              DATE := pPerFinEnc;

        lMenorPerIni            DATE;
        lMaiorPerFin            DATE;
BEGIN
    IF lPerIniAbe IS NULL THEN
        lPerIniAbe := TO_DATE('01-01-1900', 'DD-MM-YYYY');
    END IF;

    IF lPerFinAbe IS NULL THEN
        lPerFinAbe := SYSDATE;
    END IF;

    IF lPerIniEnc IS NULL AND NOT lPerFinEnc IS NULL THEN
        lPerIniEnc := TO_DATE('01-01-1900', 'DD-MM-YYYY');
    ELSIF NOT lPerIniEnc IS NULL AND lPerFinEnc IS NULL THEN
        lPerFinEnc := SYSDATE;
    END IF;

    IF lPerIniEnc IS NULL THEN
        lMenorPerIni := lPerIniAbe;
    ELSE
        IF lPerIniAbe < lPerIniEnc THEN
            lMenorPerIni := lPerIniAbe;
        ELSE
            lMenorPerIni := lPerIniEnc;
        END IF;
    END IF;

    IF lPerFinEnc IS NULL THEN
        lMaiorPerFin := lPerFinAbe;
    ELSE
        IF lPerFinAbe < lPerFinEnc THEN
            lMaiorPerFin := lPerFinAbe;
        ELSE
            lMaiorPerFin := lPerFinEnc;
        END IF;
    END IF;

    IF lPerIniEnc IS NULL THEN
        OPEN pRecordset FOR
        SELECT VUNI.IDEUNIOPE,
               NVL(VUNI.NMEUNIOPE, '') NMEUNIOPE,
               VUNI.IDEUNI,
               NVL(VUNI.SIGUNI, '') SIGUNI,
               VUNIREL.IDEUNIREL,
               NVL(VUNIREL.SIGUNIREL, '') SIGUNIREL,
               VGRUCCQ.IDEGRUCCQ,
               NVL(VGRUCCQ.NMEGRUCCQ, '') NMEGRUCCQ,
               VSOLPRB.NUM,
               VSOLPRB.DES,
               VSOLPRB.NMEETP ETP,
               VSOLPRB.NMEGRUIND,
               VSOLPRB.NMEMETSOLPRB,
               VSOLPRB.DATABE,
               VSOLPRB.DATENC
          FROM (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = pIdeEmp AND TUNI.DATCRI <= lMaiorPerFin AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= lMenorPerIni)) VGRUCCQ,
               (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI,
               (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL,
               VSOLPRB
         WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+) AND VGRUCCQ.IDEGRUCCQ = VSOLPRB.IDEUNI
           AND (pIdeUniOpe = 0 OR VUNI.IDEUNIOPE = pIdeUniOpe)
           AND (pIdeUni = 0 OR VUNI.IDEUNI = pIdeUni)
           AND (pIdeUniRel = 0 OR VGRUCCQ.IDEUNIREL = pIdeUniRel)
           AND (pIdeGruCCQ = 0 OR VGRUCCQ.IDEGRUCCQ = pIdeGruCCQ)
           AND (pIdeGruInd = 0 OR VSOLPRB.IDEGRUIND = pIdeGruInd)
           AND (pIdeMetSolPrb = 0 OR VSOLPRB.IDEMETSOLPRB = pIdeMetSolPrb)
           AND VSOLPRB.DATABE BETWEEN lPerIniAbe AND lPerFinAbe
         ORDER BY NMEUNIOPE,
                  SIGUNI,
                  SIGUNIREL,
                  NMEGRUCCQ,
                  DATABE,
                  DATENC;
    ELSE
        OPEN pRecordset FOR
        SELECT VUNI.IDEUNIOPE,
               NVL(VUNI.NMEUNIOPE, '') NMEUNIOPE,
               VUNI.IDEUNI,
               NVL(VUNI.SIGUNI, '') SIGUNI,
               VUNIREL.IDEUNIREL,
               NVL(VUNIREL.SIGUNIREL, '') SIGUNIREL,
               VGRUCCQ.IDEGRUCCQ,
               NVL(VGRUCCQ.NMEGRUCCQ, '') NMEGRUCCQ,
               VSOLPRB.NUM,
               VSOLPRB.DES,
               VSOLPRB.NMEETP ETP,
               VSOLPRB.NMEGRUIND,
               VSOLPRB.NMEMETSOLPRB,
               VSOLPRB.DATABE,
               VSOLPRB.DATENC
          FROM (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = pIdeEmp AND TUNI.DATCRI <= lMaiorPerFin AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= lMenorPerIni)) VGRUCCQ,
               (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI,
               (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL,
               VSOLPRB
         WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+) AND VGRUCCQ.IDEGRUCCQ = VSOLPRB.IDEUNI
           AND (pIdeUniOpe = 0 OR VUNI.IDEUNIOPE = pIdeUniOpe)
           AND (pIdeUni = 0 OR VUNI.IDEUNI = pIdeUni)
           AND (pIdeUniRel = 0 OR VGRUCCQ.IDEUNIREL = pIdeUniRel)
           AND (pIdeGruCCQ = 0 OR VGRUCCQ.IDEGRUCCQ = pIdeGruCCQ)
           AND (pIdeGruInd = 0 OR VSOLPRB.IDEGRUIND = pIdeGruInd)
           AND (pIdeMetSolPrb = 0 OR VSOLPRB.IDEMETSOLPRB = pIdeMetSolPrb)
           AND VSOLPRB.DATABE BETWEEN lPerIniAbe AND lPerFinAbe
           AND VSOLPRB.DATENC BETWEEN lPerIniEnc AND lPerFinEnc
         ORDER BY NMEUNIOPE,
                  SIGUNI,
                  SIGUNIREL,
                  NMEGRUCCQ,
                  DATABE,
                  DATENC;
    END IF;
END;

/* Fun��o     : RELATORIOS_RelNumeroProjetosPeriodo
   Prop�sito  : Retorna a quantidade de projetos abertos e encerrados agrupagos ano-a-ano conforme per�odo de tempo escolhido
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
                pIdeGruCCQ-Identificador do Grupo de CCQ selecionado
                pAnoIni-Ano/Exerc�cio inicial que ser� utilizado para retorno das informa��es
                pAnoFim-Ano/Exerc�cio final que ser� utilizado para retorno das informa��es
   Cria��o    : 31/07/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelNumeroProjetosPeriodo (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pAnoIni INT, pAnoFim INT, pRecordset OUT tCursorType)
    IS
        CursorUnidades          tCursorType;
        CursorNumeroProjetos    tCursorType;

        lStrGrupos              VARCHAR2(8000);
        lStrNumeroProjetos      VARCHAR2(8000);

        lTblTemp                OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lIdeUniOpe              NUMBER(13);
        lNmeUniOpe              VARCHAR2(25);
        lIdeUni                 NUMBER(13);
        lSigUni                 VARCHAR2(25);
        lIdeUniRel              NUMBER(13);
        lSigUniRel              VARCHAR2(25);
        lIdeGruCCQ              NUMBER(13);
        lNmeGruCCQ              VARCHAR2(45);

        lIdeSolPrb              NUMBER(13);
        lDatAbe                 DATE;
        lDatEnc                 DATE;

        lInicioPeriodo          DATE := TO_DATE('01/01/' || TO_CHAR(pAnoIni), 'DD/MM/YYYY');
        lFinalPeriodo           DATE := ADD_MONTHS(TO_DATE('01/12/' || TO_CHAR(pAnoFim), 'DD/MM/YYYY'), 1) - 0.00001;
BEGIN
    IF pTipo = 0 THEN   -- Agrupamento por Grupos
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, VGRUCCQ.IDEGRUCCQ, NVL(VGRUCCQ.NMEGRUCCQ, '''') NMEGRUCCQ FROM ';
    ELSIF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 2 THEN   -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 3 THEN   -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 4 THEN   -- Agrupamento pela Empresa
        lStrGrupos := 'SELECT DISTINCT 0 IDEUNIOPE, '''' NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    -- Local para condi��es espec�ficas que filtre diretamente a tabela de Grupos
    lStrGrupos := lStrGrupos || ' AND TUNI.DATCRI <= TO_DATE(''' || TO_CHAR(lFinalPeriodo, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= TO_DATE(''' || TO_CHAR(lInicioPeriodo, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS''))';
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    IF pIdeGruCCQ <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(pIdeGruCCQ);
    END IF;

    lStrGrupos := lStrGrupos || ' ORDER BY NMEUNIOPE, SIGUNI, SIGUNIREL, NMEGRUCCQ';

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lIdeUniOpe, lNmeUniOpe, lIdeUni, lSigUni, lIdeUniRel, lSigUniRel, lIdeGruCCQ, lNmeGruCCQ;
        EXIT WHEN CursorUnidades%NOTFOUND;

        Meses(0).Valor1 := 0;
        Meses(1).Valor1 := NULL;
        Meses(2).Valor1 := NULL;
        Meses(3).Valor1 := NULL;
        Meses(4).Valor1 := NULL;
        Meses(5).Valor1 := NULL;
        Meses(6).Valor1 := NULL;
        Meses(7).Valor1 := NULL;
        Meses(8).Valor1 := NULL;
        Meses(9).Valor1 := NULL;
        Meses(10).Valor1 := NULL;
        Meses(11).Valor1 := NULL;
        Meses(12).Valor1 := NULL;
        Meses(13).Valor1 := 0;

        Meses(0).Valor2 := 0;
        Meses(1).Valor2 := NULL;
        Meses(2).Valor2 := NULL;
        Meses(3).Valor2 := NULL;
        Meses(4).Valor2 := NULL;
        Meses(5).Valor2 := NULL;
        Meses(6).Valor2 := NULL;
        Meses(7).Valor2 := NULL;
        Meses(8).Valor2 := NULL;
        Meses(9).Valor2 := NULL;
        Meses(10).Valor2 := NULL;
        Meses(11).Valor2 := NULL;
        Meses(12).Valor2 := NULL;
        Meses(13).Valor2 := 0;

        lStrNumeroProjetos := 'SELECT TSOLPRB.IDESOLPRB, TSOLPRB.DATABE, TSOLPRB.DATENC FROM ';
        lStrNumeroProjetos := lStrNumeroProjetos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
        lStrNumeroProjetos := lStrNumeroProjetos || ') VGRUCCQ, (SELECT VUNI.IDEUNI, VUNI.IDEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, TSOLPRB ';
        lStrNumeroProjetos := lStrNumeroProjetos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI AND VGRUCCQ.IDEGRUCCQ = TSOLPRB.IDEUNI';
        lStrNumeroProjetos := lStrNumeroProjetos || '   AND (TSOLPRB.DATABE BETWEEN TO_DATE(''' || TO_CHAR(lInicioPeriodo, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND TO_DATE(''' || TO_CHAR(lFinalPeriodo, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'')';
        lStrNumeroProjetos := lStrNumeroProjetos || '    OR TSOLPRB.DATENC BETWEEN TO_DATE(''' || TO_CHAR(lInicioPeriodo, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND TO_DATE(''' || TO_CHAR(lFinalPeriodo, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS''))';

        IF lIdeUniOpe <> 0 THEN
           lStrNumeroProjetos := lStrNumeroProjetos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(lIdeUniOpe);
        END IF;

        IF lIdeUni <> 0 THEN
           lStrNumeroProjetos := lStrNumeroProjetos || ' AND VUNI.IDEUNI = ' || TO_CHAR(lIdeUni);
        END IF;

        IF lIdeUniRel <> 0 THEN
           lStrNumeroProjetos := lStrNumeroProjetos || ' AND VGRUCCQ.IDEUNIREL = ' || TO_CHAR(lIdeUniRel);
        END IF;

        IF lIdeGruCCQ <> 0 THEN
            lStrNumeroProjetos := lStrNumeroProjetos || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(lIdeGruCCQ);
        END IF;

        lStrNumeroProjetos := lStrNumeroProjetos || ' ORDER BY TSOLPRB.DATABE';

        IF CursorNumeroProjetos%ISOPEN THEN
            CLOSE CursorNumeroProjetos;
        END IF;

        OPEN CursorNumeroProjetos FOR lStrNumeroProjetos;
        LOOP
            FETCH CursorNumeroProjetos INTO lIdeSolPrb, lDatAbe, lDatEnc;
            EXIT WHEN CursorNumeroProjetos%NOTFOUND;

            IF NOT lDatAbe IS NULL THEN
                IF Meses(TO_NUMBER(TO_CHAR(lDatAbe, 'YYYY')) - pAnoIni + 1).Valor1 IS NULL THEN
                   Meses(TO_NUMBER(TO_CHAR(lDatAbe, 'YYYY')) - pAnoIni + 1).Valor1 := 0;
                END IF;
                Meses(TO_NUMBER(TO_CHAR(lDatAbe, 'YYYY')) - pAnoIni + 1).Valor1 := Meses(TO_NUMBER(TO_CHAR(lDatAbe, 'YYYY')) - pAnoIni + 1).Valor1 + 1;
            END IF;

            IF NOT lDatEnc IS NULL THEN
                IF Meses(TO_NUMBER(TO_CHAR(lDatEnc, 'YYYY')) - pAnoIni + 1).Valor2 IS NULL THEN
                   Meses(TO_NUMBER(TO_CHAR(lDatEnc, 'YYYY')) - pAnoIni + 1).Valor2 := 0;
                END IF;
                Meses(TO_NUMBER(TO_CHAR(lDatEnc, 'YYYY')) - pAnoIni + 1).Valor2 := Meses(TO_NUMBER(TO_CHAR(lDatEnc, 'YYYY')) - pAnoIni + 1).Valor2 + 1;
            END IF;
        END LOOP;

        IF CursorNumeroProjetos%ISOPEN THEN
            CLOSE CursorNumeroProjetos;
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, Meses(0).Valor1, Meses(0).Valor2, Meses(1).Valor1, Meses(1).Valor2, Meses(2).Valor1, Meses(2).Valor2, Meses(3).Valor1, Meses(3).Valor2, Meses(4).Valor1, Meses(4).Valor2, Meses(5).Valor1, Meses(5).Valor2, Meses(6).Valor1, Meses(6).Valor2, Meses(7).Valor1, Meses(7).Valor2, Meses(8).Valor1, Meses(8).Valor2, Meses(9).Valor1, Meses(9).Valor2, Meses(10).Valor1, Meses(10).Valor2, Meses(11).Valor1, Meses(11).Valor2, Meses(12).Valor1, Meses(12).Valor2, Meses(13).Valor1, Meses(13).Valor2, NULL, NULL);
    END LOOP;
    
    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF; 

    OPEN pRecordset FOR
    SELECT *
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE));
END;

/* Fun��o     : RELATORIOS_RelProjetosRegImp
   Prop�sito  : Retorna a quantidade de projetos registrados e implantados de cada M�todo no per�odo selecionado
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
                pIdeGruCCQ-Identificador do Grupo de CCQ selecionado (n�o est� dispon�vel a todos os relat�rios)
                pPerIni-Per�odo Inicial das informa��es que ser�o retornadas (n�o est� dispon�vel a todos os relat�rios)
                pPerFin-Per�odo Final das informa��es que ser�o retornadas (n�o est� dispon�vel a todos os relat�rios)
   Cria��o    : 31/07/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelProjetosRegImp (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pPerIni DATE, pPerFin DATE, pRecordset OUT tCursorType)
    IS
        CursorUnidades          tCursorType;
        CursorNumeroProjetos    tCursorType;

        lStrGrupos              VARCHAR2(8000);
        lStrNumeroProjetos      VARCHAR2(8000);

        lTblTemp                OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lIdeUniOpe              NUMBER(13);
        lNmeUniOpe              VARCHAR2(25);
        lIdeUni                 NUMBER(13);
        lSigUni                 VARCHAR2(25);
        lIdeUniRel              NUMBER(13);
        lSigUniRel              VARCHAR2(25);
        lIdeGruCCQ              NUMBER(13);
        lNmeGruCCQ              VARCHAR2(45);

        lIdeSolPrb              NUMBER(13);
        lDatAbe                 DATE;
        lDatEnc                 DATE;
        lNmeMetSolPrb           VARCHAR2(35);
BEGIN
    IF pTipo = 0 THEN   -- Agrupamento por Grupos
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, VGRUCCQ.IDEGRUCCQ, NVL(VGRUCCQ.NMEGRUCCQ, '''') NMEGRUCCQ FROM ';
    ELSIF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 2 THEN   -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 3 THEN   -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 4 THEN   -- Agrupamento pela Empresa
        lStrGrupos := 'SELECT DISTINCT 0 IDEUNIOPE, '''' NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    -- Local para condi��es espec�ficas que filtre diretamente a tabela de Grupos
    lStrGrupos := lStrGrupos || ' AND TUNI.DATCRI <= TO_DATE(''' || TO_CHAR(pPerFin, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= TO_DATE(''' || TO_CHAR(pPerIni, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS''))';
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    IF pIdeGruCCQ <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(pIdeGruCCQ);
    END IF;

    lStrGrupos := lStrGrupos || ' ORDER BY NMEUNIOPE, SIGUNI, SIGUNIREL, NMEGRUCCQ';

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lIdeUniOpe, lNmeUniOpe, lIdeUni, lSigUni, lIdeUniRel, lSigUniRel, lIdeGruCCQ, lNmeGruCCQ;
        EXIT WHEN CursorUnidades%NOTFOUND;

        Meses(0).Valor1 := 0;
        Meses(1).Valor1 := 0;
        Meses(2).Valor1 := 0;
        Meses(3).Valor1 := 0;
        Meses(4).Valor1 := 0;
        Meses(5).Valor1 := 0;
        Meses(6).Valor1 := 0;
        Meses(7).Valor1 := 0;
        Meses(8).Valor1 := 0;
        Meses(9).Valor1 := 0;
        Meses(10).Valor1 := 0;
        Meses(11).Valor1 := 0;
        Meses(12).Valor1 := 0;
        Meses(13).Valor1 := 0;

        Meses(0).Valor2 := 0;
        Meses(1).Valor2 := 0;
        Meses(2).Valor2 := 0;
        Meses(3).Valor2 := 0;
        Meses(4).Valor2 := 0;
        Meses(5).Valor2 := 0;
        Meses(6).Valor2 := 0;
        Meses(7).Valor2 := 0;
        Meses(8).Valor2 := 0;
        Meses(9).Valor2 := 0;
        Meses(10).Valor2 := 0;
        Meses(11).Valor2 := 0;
        Meses(12).Valor2 := 0;
        Meses(13).Valor2 := 0;

        lStrNumeroProjetos := 'SELECT TSOLPRB.IDESOLPRB, TSOLPRB.DATABE, TSOLPRB.DATENC, TMETSOLPRB.NME NMEMETSOLPRB FROM';
        lStrNumeroProjetos := lStrNumeroProjetos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
        lStrNumeroProjetos := lStrNumeroProjetos || ') VGRUCCQ, (SELECT VUNI.IDEUNI, VUNI.IDEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, TSOLPRB, TMETSOLPRB ';
        lStrNumeroProjetos := lStrNumeroProjetos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI AND VGRUCCQ.IDEGRUCCQ = TSOLPRB.IDEUNI AND TSOLPRB.IDEMETSOLPRB = TMETSOLPRB.IDEMETSOLPRB ';
        lStrNumeroProjetos := lStrNumeroProjetos || '   AND (TSOLPRB.DATABE BETWEEN TO_DATE(''' || TO_CHAR(pPerIni, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND TO_DATE(''' || TO_CHAR(pPerFin, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'')';
        lStrNumeroProjetos := lStrNumeroProjetos || '    OR TSOLPRB.DATENC BETWEEN TO_DATE(''' || TO_CHAR(pPerIni, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND TO_DATE(''' || TO_CHAR(pPerFin, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS''))';

        IF lIdeUniOpe <> 0 THEN
           lStrNumeroProjetos := lStrNumeroProjetos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(lIdeUniOpe);
        END IF;

        IF lIdeUni <> 0 THEN
           lStrNumeroProjetos := lStrNumeroProjetos || ' AND VUNI.IDEUNI = ' || TO_CHAR(lIdeUni);
        END IF;

        IF lIdeUniRel <> 0 THEN
           lStrNumeroProjetos := lStrNumeroProjetos || ' AND VGRUCCQ.IDEUNIREL = ' || TO_CHAR(lIdeUniRel);
        END IF;

        IF lIdeGruCCQ <> 0 THEN
            lStrNumeroProjetos := lStrNumeroProjetos || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(lIdeGruCCQ);
        END IF;

        IF CursorNumeroProjetos%ISOPEN THEN
            CLOSE CursorNumeroProjetos;
        END IF;

        OPEN CursorNumeroProjetos FOR lStrNumeroProjetos;
        LOOP
            FETCH CursorNumeroProjetos INTO lIdeSolPrb, lDatAbe, lDatEnc, lNmeMetSolPrb;
            EXIT WHEN CursorNumeroProjetos%NOTFOUND;

            IF lNmeMetSolPrb = 'PDCA' THEN
                IF lDatAbe >= pPerIni AND lDatAbe <= pPerFin THEN
                    IF Meses(1).Valor2 IS NULL THEN
                       Meses(1).Valor2 := 0;
                    END IF;
                    Meses(1).Valor2 := Meses(1).Valor2 + 1;
                END IF;

                IF lDatEnc >= pPerIni AND lDatEnc <= pPerFin THEN
                    IF Meses(2).Valor2 IS NULL THEN
                       Meses(2).Valor2 := 0;
                    END IF;
                    Meses(2).Valor2 := Meses(2).Valor2 + 1;
                END IF;
            ELSE
                IF lDatAbe >= pPerIni AND lDatAbe <= pPerFin THEN
                    IF Meses(1).Valor1 IS NULL THEN
                       Meses(1).Valor1 := 0;
                    END IF;
                    Meses(1).Valor1 := Meses(1).Valor1 + 1;
                END IF;

                IF lDatEnc >= pPerIni AND lDatEnc <= pPerFin THEN
                    IF Meses(2).Valor1 IS NULL THEN
                       Meses(2).Valor1 := 0;
                    END IF;
                    Meses(2).Valor1 := Meses(2).Valor1 + 1;
                END IF;
            END IF;
        END LOOP;

        IF CursorNumeroProjetos%ISOPEN THEN
            CLOSE CursorNumeroProjetos;
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, NULL, NULL, Meses(1).Valor1, Meses(1).Valor2, Meses(2).Valor1, Meses(2).Valor2, Meses(1).Valor1 - Meses(2).Valor1, Meses(1).Valor2 - Meses(2).Valor2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
    END LOOP;
    
    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;
    
    OPEN pRecordset FOR
    SELECT *
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE));

END;

/* Fun��o     : RELATORIOS_RelProjetosGanhos
   Prop�sito  : Retorna a quantidade de projetos abertos e encerrados m�s-a-m�s durante um ano
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
                pIdeGruCCQ-Identificador do Grupo de CCQ selecionado
                pPerIni-Per�odo inicial que ser� utilizado para retorno das informa��es
                pPerFin-Per�odo final que ser� utilizado para retorno das informa��es
   Cria��o    : 31/07/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelProjetosGanhos (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pPerIni DATE, pPerFin DATE, pRecordset OUT tCursorType)
    IS
        CursorUnidades          tCursorType;
        CursorNumeroProjetos    tCursorType;

        lStrGrupos              VARCHAR2(8000);
        lStrNumeroProjetos      VARCHAR2(8000);

        lTblTemp                OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lIdeUniOpe              NUMBER(13);
        lNmeUniOpe              VARCHAR2(25);
        lIdeUni                 NUMBER(13);
        lSigUni                 VARCHAR2(25);
        lIdeUniRel              NUMBER(13);
        lSigUniRel              VARCHAR2(25);
        lIdeGruCCQ              NUMBER(13);
        lNmeGruCCQ              VARCHAR2(45);

        lIdeSolPrb              NUMBER(13);
        lCustoImplantacao       FLOAT;
        lGanho                  FLOAT;
        lRetorno                FLOAT;

        lTotalCustoImplantacao  FLOAT;
        lTotalGanho             FLOAT;
        lTotalRetorno           FLOAT;
BEGIN
    IF pTipo = 0 THEN   -- Agrupamento por Grupos
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, VGRUCCQ.IDEGRUCCQ, NVL(VGRUCCQ.NMEGRUCCQ, '''') NMEGRUCCQ FROM ';
    ELSIF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 2 THEN   -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 3 THEN   -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 4 THEN   -- Agrupamento pela Empresa
        lStrGrupos := 'SELECT DISTINCT 0 IDEUNIOPE, '''' NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    -- Local para condi��es espec�ficas que filtre diretamente a tabela de Grupos
    lStrGrupos := lStrGrupos || ' AND TUNI.DATCRI <= TO_DATE(''' || TO_CHAR(pPerFin, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= TO_DATE(''' || TO_CHAR(pPerIni, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS''))';
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    IF pIdeGruCCQ <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(pIdeGruCCQ);
    END IF;

    lStrGrupos := lStrGrupos || ' ORDER BY NMEUNIOPE, SIGUNI, SIGUNIREL, NMEGRUCCQ';

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lIdeUniOpe, lNmeUniOpe, lIdeUni, lSigUni, lIdeUniRel, lSigUniRel, lIdeGruCCQ, lNmeGruCCQ;
        EXIT WHEN CursorUnidades%NOTFOUND;

        lStrNumeroProjetos := 'SELECT TSOLPRB.IDESOLPRB, NVL(TSOLPRB.CSTIMP, 0), NVL(TSOLPRB.GAN, 0), NVL(TSOLPRB.RET, 0) FROM ';
        lStrNumeroProjetos := lStrNumeroProjetos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
        lStrNumeroProjetos := lStrNumeroProjetos || ') VGRUCCQ, (SELECT VUNI.IDEUNI, VUNI.IDEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, TSOLPRB ';
        lStrNumeroProjetos := lStrNumeroProjetos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI AND VGRUCCQ.IDEGRUCCQ = TSOLPRB.IDEUNI';
        lStrNumeroProjetos := lStrNumeroProjetos || '   AND TSOLPRB.DATABE BETWEEN TO_DATE(''' || TO_CHAR(pPerIni, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND TO_DATE(''' || TO_CHAR(pPerFin, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'')';

        IF lIdeUniOpe <> 0 THEN
           lStrNumeroProjetos := lStrNumeroProjetos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(lIdeUniOpe);
        END IF;

        IF lIdeUni <> 0 THEN
           lStrNumeroProjetos := lStrNumeroProjetos || ' AND VUNI.IDEUNI = ' || TO_CHAR(lIdeUni);
        END IF;

        IF lIdeUniRel <> 0 THEN
           lStrNumeroProjetos := lStrNumeroProjetos || ' AND VGRUCCQ.IDEUNIREL = ' || TO_CHAR(lIdeUniRel);
        END IF;

        IF lIdeGruCCQ <> 0 THEN
            lStrNumeroProjetos := lStrNumeroProjetos || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(lIdeGruCCQ);
        END IF;

        lStrNumeroProjetos := lStrNumeroProjetos || ' ORDER BY TSOLPRB.DATABE';

        IF CursorNumeroProjetos%ISOPEN THEN
            CLOSE CursorNumeroProjetos;
        END IF;

        lTotalCustoImplantacao := 0;
        lTotalGanho := 0;
        lTotalRetorno := 0;

        OPEN CursorNumeroProjetos FOR lStrNumeroProjetos;
        LOOP
            FETCH CursorNumeroProjetos INTO lIdeSolPrb, lCustoImplantacao, lGanho, lRetorno;
            EXIT WHEN CursorNumeroProjetos%NOTFOUND;

            lTotalCustoImplantacao := lTotalCustoImplantacao + lCustoImplantacao;
            lTotalGanho := lTotalGanho + lGanho;
            lTotalRetorno := lTotalRetorno + lRetorno;
        END LOOP;

        IF CursorNumeroProjetos%ISOPEN THEN
            CLOSE CursorNumeroProjetos;
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, NULL, NULL, lTotalCustoImplantacao, lTotalGanho, lTotalRetorno, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
    END LOOP;

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;
        
    OPEN pRecordset FOR
    SELECT *
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE));
END;

/* Fun��o     : RelPercReunioesRealizadas
   Prop�sito  : Retorna o percentual de reuni�es realizadas m�s-a-m�s pelos Grupos de CCQ
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios, sendo: 0-Grupo de CCQ, 1-Coordena��o, 2-UG, 3-UO e 4-Empresa
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
                pIdeGruCCQ-Identificador do Grupo de CCQ
                pExr-Exerc�cio selecionado (n�o est� dispon�vel a todos os relat�rios)
   Cria��o    : 31/07/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelPercReunioesRealizadas (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pExr INT, pRecordset OUT tCursorType)
    IS
        CursorUnidades          tCursorType;
        CursorReunioes          tCursorType;

        lStrGrupos              VARCHAR2(8000);
        lStrReunioes            VARCHAR2(8000);

        lTblTemp                OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lIdeUniOpe              NUMBER(13);
        lNmeUniOpe              VARCHAR2(25);
        lIdeUni                 NUMBER(13);
        lSigUni                 VARCHAR2(25);
        lIdeUniRel              NUMBER(13);
        lSigUniRel              VARCHAR2(25);
        lIdeGruCCQ              NUMBER(13);
        lNmeGruCCQ              VARCHAR2(45);

        lIdeUniScd              NUMBER(13);
        lDat                    DATE;
        lStt                    NUMBER(1);

        lInicioAno              DATE := TO_DATE('01/01/' || TO_CHAR(pExr), 'DD/MM/YYYY');
        lFinalAno               DATE := ADD_MONTHS(TO_DATE('01/12/' || TO_CHAR(pExr), 'DD/MM/YYYY'), 1) - 0.00001;
BEGIN
    IF pTipo = 0 THEN   -- Agrupamento por Grupos
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, VGRUCCQ.IDEGRUCCQ, NVL(VGRUCCQ.NMEGRUCCQ, '''') NMEGRUCCQ FROM ';
    ELSIF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 2 THEN   -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 3 THEN   -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 4 THEN   -- Agrupamento pela Empresa
        lStrGrupos := 'SELECT DISTINCT 0 IDEUNIOPE, '''' NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    -- Local para condi��es espec�ficas que filtre diretamente a tabela de Grupos
    lStrGrupos := lStrGrupos || ' AND TUNI.DATCRI <= TO_DATE(''' || TO_CHAR(lFinalAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= TO_DATE(''' || TO_CHAR(lInicioAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS''))';
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    IF pIdeGruCCQ <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(pIdeGruCCQ);
    END IF;

    lStrGrupos := lStrGrupos || ' ORDER BY NMEUNIOPE, SIGUNI, SIGUNIREL, NMEGRUCCQ';

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lIdeUniOpe, lNmeUniOpe, lIdeUni, lSigUni, lIdeUniRel, lSigUniRel, lIdeGruCCQ, lNmeGruCCQ;
        EXIT WHEN CursorUnidades%NOTFOUND;
        
        Meses(0).Valor1 := NULL;
        Meses(1).Valor1 := NULL;
        Meses(2).Valor1 := NULL;
        Meses(3).Valor1 := NULL;
        Meses(4).Valor1 := NULL;
        Meses(5).Valor1 := NULL;
        Meses(6).Valor1 := NULL;
        Meses(7).Valor1 := NULL;
        Meses(8).Valor1 := NULL;
        Meses(9).Valor1 := NULL;
        Meses(10).Valor1 := NULL;
        Meses(11).Valor1 := NULL;
        Meses(12).Valor1 := NULL;
        Meses(13).Valor1 := NULL;

        Meses(0).Valor2 := NULL;
        Meses(1).Valor2 := NULL;
        Meses(2).Valor2 := NULL;
        Meses(3).Valor2 := NULL;
        Meses(4).Valor2 := NULL;
        Meses(5).Valor2 := NULL;
        Meses(6).Valor2 := NULL;
        Meses(7).Valor2 := NULL;
        Meses(8).Valor2 := NULL;
        Meses(9).Valor2 := NULL;
        Meses(10).Valor2 := NULL;
        Meses(11).Valor2 := NULL;
        Meses(12).Valor2 := NULL;
        Meses(13).Valor2 := NULL;

        lStrReunioes := 'SELECT TUNISCD.IDEUNISCD, TUNISCD.DAT, TUNISCD.STT FROM ';
        lStrReunioes := lStrReunioes || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
        lStrReunioes := lStrReunioes || ') VGRUCCQ, (SELECT VUNI.IDEUNI, VUNI.IDEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, TUNISCD ';
        lStrReunioes := lStrReunioes || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI AND VGRUCCQ.IDEGRUCCQ = TUNISCD.IDEUNI';
        lStrReunioes := lStrReunioes || '   AND TUNISCD.DAT BETWEEN TO_DATE(''' || TO_CHAR(lInicioAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND TO_DATE(''' || TO_CHAR(lFinalAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'')';

        IF lIdeUniOpe <> 0 THEN
           lStrReunioes := lStrReunioes || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(lIdeUniOpe);
        END IF;

        IF lIdeUni <> 0 THEN
           lStrReunioes := lStrReunioes || ' AND VUNI.IDEUNI = ' || TO_CHAR(lIdeUni);
        END IF;

        IF lIdeUniRel <> 0 THEN
           lStrReunioes := lStrReunioes || ' AND VGRUCCQ.IDEUNIREL = ' || TO_CHAR(lIdeUniRel);
        END IF;

        IF lIdeGruCCQ <> 0 THEN
            lStrReunioes := lStrReunioes || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(lIdeGruCCQ);
        END IF;

        lStrReunioes := lStrReunioes || ' ORDER BY TUNISCD.DAT';

        IF CursorReunioes%ISOPEN THEN
            CLOSE CursorReunioes;
        END IF;

        OPEN CursorReunioes FOR lStrReunioes;
        LOOP
            FETCH CursorReunioes INTO lIdeUniScd, lDat, lStt;
            EXIT WHEN CursorReunioes%NOTFOUND;

            IF lDat <= SYSDATE() THEN
                IF Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor1 IS NULL THEN
                    Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor1 := 0;
                END IF;
                IF lStt = 1 THEN
                    Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor1 := Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor1 + 1;
                END IF;

                IF Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor2 IS NULL THEN
                    Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor2 := 0;
                END IF;
                Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor2 := Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor2 + 1;

                IF Meses(13).Valor1 IS NULL THEN
                    Meses(13).Valor1 := 0;
                END IF;
                IF lStt = 1 THEN
                    Meses(13).Valor1 := Meses(13).Valor1 + 1;
                END IF;
                IF Meses(13).Valor2 IS NULL THEN
                    Meses(13).Valor2 := 0;
                END IF;
                Meses(13).Valor2 := Meses(13).Valor2 + 1;
            END IF;
        END LOOP;

        IF CursorReunioes%ISOPEN THEN
            CLOSE CursorReunioes;
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, NULL, NULL, Meses(1).Valor1, Meses(1).Valor2, Meses(2).Valor1, Meses(2).Valor2, Meses(3).Valor1, Meses(3).Valor2, Meses(4).Valor1, Meses(4).Valor2, Meses(5).Valor1, Meses(5).Valor2, Meses(6).Valor1, Meses(6).Valor2, Meses(7).Valor1, Meses(7).Valor2, Meses(8).Valor1, Meses(8).Valor2, Meses(9).Valor1, Meses(9).Valor2, Meses(10).Valor1, Meses(10).Valor2, Meses(11).Valor1, Meses(11).Valor2, Meses(12).Valor1, Meses(12).Valor2, Meses(13).Valor1, Meses(13).Valor2, NULL, NULL);
    END LOOP;

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN pRecordset FOR
    SELECT StrCol1,
           StrCol2,
           StrCol3,
           StrCol4,
           ValJan01 / ValJan02 * 100 PerJan,
           ValFev01 / ValFev02 * 100 PerFev,
           ValMar01 / ValMar02 * 100 PerMar,
           ValAbr01 / ValAbr02 * 100 PerAbr,
           ValMai01 / ValMai02 * 100 PerMai,
           ValJun01 / ValJun02 * 100 PerJun,
           ValJul01 / ValJul02 * 100 PerJul,
           ValAgo01 / ValAgo02 * 100 PerAgo,
           ValSet01 / ValSet02 * 100 PerSet,
           ValOut01 / ValOut02 * 100 PerOut,
           ValNov01 / ValNov02 * 100 PerNov,
           ValDez01 / ValDez02 * 100 PerDez,
           ValAnoAtu01 / ValAnoAtu02 * 100 PerAnu
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE));
        
END;

/* Fun��o     : RELATORIOS_RelPercParticipacaoEfetivo
   Prop�sito  : Retorna o Percentual de Participa��o do Efetivo da Empresa no Projeto do CCQ
   Par�metros : pIdeEmp-Identificador da Empresa
   Cria��o    : 13/12/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelPercParticipacaoEfetivo (pIdeEmp NUMBER, pNop INT, pRecordset OUT tCursorType)
    IS
        lTotalParticipantesGrupos   INT;
        lQuantidadeEfetivo          INT;
        lFator                      FLOAT;
BEGIN
   SELECT COUNT(DISTINCT TUSU.IDEUSU) INTO lTotalParticipantesGrupos
     FROM TPAR, TUNI, TUNITYP, TUSU
    WHERE TPAR.IDEUNI = TUNI.IDEUNI
      AND TUNI.IDEUNITYP = TUNITYP.IDEUNITYP
      AND TPAR.IDEUSU = TUSU.IDEUSU
      AND TUNITYP.TYP = 3
      AND TPAR.STT = 1
      AND TPAR.FUN <= 3
      AND TUNI.IDEEMP = pIdeEmp
      AND TUNI.ATV <> 0
      AND TUSU.IDEEMPFUN = pIdeEmp;

   SELECT QTDFUN,
          FAT
     INTO lQuantidadeEfetivo,
          lFator
     FROM TEMP
    WHERE TEMP.IDEEMP = pIdeEmp;

    OPEN pRecordset FOR
    SELECT CASE WHEN lQuantidadeEfetivo <> 0 AND lFator <> 0 THEN lTotalParticipantesGrupos / (lQuantidadeEfetivo * lFator) * 100 ELSE 0 END PercParticipacaoEfetivo FROM DUAL;

END;

/* Fun��o     : RelPercParticipacaoReunioes
   Prop�sito  : Retorna o percentual de participa��o dos circulistas nas reuni�es realizadas pelos Grupos de CCQ
   Par�metros : pTipo-Tipo do Agrupamento dos Relat�rios, sendo: 0-Grupo de CCQ, 1-Coordena��o, 2-UG, 3-UO e 4-Empresa
                pIdeEmp-Identificador da Empresa do usu�rio que est� logado no sistema
                pIdeUniOpe-Identificador da Unidade Operacional selecionada
                pIdeUni-Identificador da Unidade Gerencial selecionada
                pIdeUniRel-Identificador da Coordena��o selecionada
                pIdeGruCCQ-Identificador do Grupo de CCQ
                pExr-Exerc�cio selecionado (n�o est� dispon�vel a todos os relat�rios)                
   Cria��o    : 31/07/2008 - mar
   �ltima Alt.: 02/05/2016 - Leonardo Lage */

PROCEDURE RelPercParticipacaoReunioes (pTipo INT, pIdeEmp NUMBER, pIdeUniOpe NUMBER, pIdeUni NUMBER, pIdeUniRel NUMBER, pIdeGruCCQ NUMBER, pExr INT, pRecordset OUT tCursorType)
    IS
        CursorUnidades          tCursorType;
        CursorReunioes          tCursorType;
        
        lStrGrupos              VARCHAR2(8000);
        lStrReunioes            VARCHAR2(8000);

        lTblTemp                OBJECT_TMPRELATORIOS_TABLE := OBJECT_TMPRELATORIOS_TABLE();

        lIdeUniOpe              NUMBER(13);
        lNmeUniOpe              VARCHAR2(25);
        lIdeUni                 NUMBER(13);
        lSigUni                 VARCHAR2(25);
        lIdeUniRel              NUMBER(13);
        lSigUniRel              VARCHAR2(25);
        lIdeGruCCQ              NUMBER(13);
        lNmeGruCCQ              VARCHAR2(45);

        lIdeUniScdPar           NUMBER(13);
        lDat                    DATE;
        lPre                    NUMBER(1);
        lAbo                    NUMBER(1);

        lInicioAno              DATE := TO_DATE('01/01/' || TO_CHAR(pExr), 'DD/MM/YYYY');
        lFinalAno               DATE := ADD_MONTHS(TO_DATE('01/12/' || TO_CHAR(pExr), 'DD/MM/YYYY'), 1) - 0.00001;
BEGIN
    IF pTipo = 0 THEN   -- Agrupamento por Grupos
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, VGRUCCQ.IDEGRUCCQ, NVL(VGRUCCQ.NMEGRUCCQ, '''') NMEGRUCCQ FROM ';
    ELSIF pTipo = 1 THEN   -- Agrupamento por UNIREL (Coordena��o)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, VUNIREL.IDEUNIREL, NVL(VUNIREL.SIGUNIREL, '''') SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 2 THEN   -- Agrupamento por UG (Unidade Gerencial)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, VUNI.IDEUNI, NVL(VUNI.SIGUNI, '''') SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 3 THEN   -- Agrupamento por UO (Unidade Operacional)
        lStrGrupos := 'SELECT DISTINCT VUNI.IDEUNIOPE, NVL(VUNI.NMEUNIOPE, '''') NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    ELSIF pTipo = 4 THEN   -- Agrupamento pela Empresa
        lStrGrupos := 'SELECT DISTINCT 0 IDEUNIOPE, '''' NMEUNIOPE, 0 IDEUNI, '''' SIGUNI, 0 IDEUNIREL, '''' SIGUNIREL, 0 IDEGRUCCQ, '''' NMEGRUCCQ FROM ';
    END IF;

    lStrGrupos := lStrGrupos || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
    -- Local para condi��es espec�ficas que filtre diretamente a tabela de Grupos
    lStrGrupos := lStrGrupos || ' AND TUNI.DATCRI <= TO_DATE(''' || TO_CHAR(lFinalAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND (TUNI.DATCNC IS NULL OR TUNI.DATCNC >= TO_DATE(''' || TO_CHAR(lInicioAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS''))';
    lStrGrupos := lStrGrupos || ') VGRUCCQ, (SELECT IDEUNI, SIG SIGUNI, IDEUNIOPE, SIGUNIOPE NMEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, ';
    lStrGrupos := lStrGrupos || '           (SELECT IDEUNI IDEUNIREL, SIG SIGUNIREL FROM VUNI WHERE TYP = 1) VUNIREL ';
    lStrGrupos := lStrGrupos || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI (+) AND VGRUCCQ.IDEUNIREL = VUNIREL.IDEUNIREL (+)';

    IF pIdeUniOpe <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(pIdeUniOpe);
    END IF;

    IF pIdeUni <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNI.IDEUNI = ' || TO_CHAR(pIdeUni);
    END IF;

    IF pIdeUniRel <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VUNIREL.IDEUNIREL = ' || TO_CHAR(pIdeUniRel);
    END IF;

    IF pIdeGruCCQ <> 0 THEN
        lStrGrupos := lStrGrupos || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(pIdeGruCCQ);
    END IF;

    lStrGrupos := lStrGrupos || ' ORDER BY NMEUNIOPE, SIGUNI, SIGUNIREL, NMEGRUCCQ';

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN CursorUnidades FOR lStrGrupos;
    LOOP    
        FETCH CursorUnidades INTO lIdeUniOpe, lNmeUniOpe, lIdeUni, lSigUni, lIdeUniRel, lSigUniRel, lIdeGruCCQ, lNmeGruCCQ;
        EXIT WHEN CursorUnidades%NOTFOUND;

        Meses(0).Valor1 := NULL;
        Meses(1).Valor1 := NULL;
        Meses(2).Valor1 := NULL;
        Meses(3).Valor1 := NULL;
        Meses(4).Valor1 := NULL;
        Meses(5).Valor1 := NULL;
        Meses(6).Valor1 := NULL;
        Meses(7).Valor1 := NULL;
        Meses(8).Valor1 := NULL;
        Meses(9).Valor1 := NULL;
        Meses(10).Valor1 := NULL;
        Meses(11).Valor1 := NULL;
        Meses(12).Valor1 := NULL;
        Meses(13).Valor1 := NULL;

        Meses(0).Valor2 := NULL;
        Meses(1).Valor2 := NULL;
        Meses(2).Valor2 := NULL;
        Meses(3).Valor2 := NULL;
        Meses(4).Valor2 := NULL;
        Meses(5).Valor2 := NULL;
        Meses(6).Valor2 := NULL;
        Meses(7).Valor2 := NULL;
        Meses(8).Valor2 := NULL;
        Meses(9).Valor2 := NULL;
        Meses(10).Valor2 := NULL;
        Meses(11).Valor2 := NULL;
        Meses(12).Valor2 := NULL;
        Meses(13).Valor2 := NULL;

        lStrReunioes := 'SELECT TUNISCDPAR.IDEUNISCDPAR, TUNISCD.DAT, TUNISCDPAR.PRE, NVL(TMOTNAOCMPREU.ABO, 0) FROM ';
        lStrReunioes := lStrReunioes || ' (SELECT TUNI.IDEUNI IDEGRUCCQ, TUNI.NME NMEGRUCCQ, TUNI.IDESPR, TUNI.IDEUNIREL FROM TUNI, TUNITYP WHERE TUNI.IDEUNITYP = TUNITYP.IDEUNITYP AND TUNITYP.TYP = 3 AND TUNI.IDEEMP = ' || TO_CHAR(pIdeEmp);
        lStrReunioes := lStrReunioes || ') VGRUCCQ, (SELECT VUNI.IDEUNI, VUNI.IDEUNIOPE FROM VUNI WHERE TYP = 1) VUNI, TUNISCD, TUNISCDPAR, TATV, TMOTNAOCMPREU ';
        lStrReunioes := lStrReunioes || ' WHERE VGRUCCQ.IDESPR = VUNI.IDEUNI AND VGRUCCQ.IDEGRUCCQ = TUNISCD.IDEUNI AND TUNISCD.IDEUNISCD = TUNISCDPAR.IDEUNISCD AND TUNISCD.IDEATV = TATV.IDEATV AND TUNISCDPAR.IDEMOTNAOCMPREU = TMOTNAOCMPREU.IDEMOTNAOCMPREU (+) ';
        lStrReunioes := lStrReunioes || '   AND TUNISCD.DAT BETWEEN TO_DATE(''' || TO_CHAR(lInicioAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') AND TO_DATE(''' || TO_CHAR(lFinalAno, 'DD/MM/YYYY HH24:MI:SS') || ''', ''DD/MM/YYYY HH24:MI:SS'') ';
        lStrReunioes := lStrReunioes || '   AND TUNISCD.STT = 1 ';
        lStrReunioes := lStrReunioes || '   AND TATV.TIPATV = 1 ';

        IF lIdeUniOpe <> 0 THEN
           lStrReunioes := lStrReunioes || ' AND VUNI.IDEUNIOPE = ' || TO_CHAR(lIdeUniOpe);
        END IF;

        IF lIdeUni <> 0 THEN
           lStrReunioes := lStrReunioes || ' AND VUNI.IDEUNI = ' || TO_CHAR(lIdeUni);
        END IF;

        IF lIdeUniRel <> 0 THEN
           lStrReunioes := lStrReunioes || ' AND VGRUCCQ.IDEUNIREL = ' || TO_CHAR(lIdeUniRel);
        END IF;

        IF lIdeGruCCQ <> 0 THEN
            lStrReunioes := lStrReunioes || ' AND VGRUCCQ.IDEGRUCCQ = ' || TO_CHAR(lIdeGruCCQ);
        END IF;

        lStrReunioes := lStrReunioes || ' ORDER BY TUNISCD.DAT';

        IF CursorReunioes%ISOPEN THEN
            CLOSE CursorReunioes;
        END IF;

        OPEN CursorReunioes FOR lStrReunioes;
        LOOP
            FETCH CursorReunioes INTO lIdeUniScdPar, lDat, lPre, lAbo;
            EXIT WHEN CursorReunioes%NOTFOUND;

            IF lDat <= SYSDATE() THEN
                IF Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor1 IS NULL THEN
                    Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor1 := 0;
                END IF;
                IF lPre <> 0 THEN
                    Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor1 := Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor1 + 1;

                    IF Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor2 IS NULL THEN
                        Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor2 := 0;
                    END IF;
                    Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor2 := Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor2 + 1;
                ELSE
                    IF lAbo = 0 THEN
                        IF Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor2 IS NULL THEN
                            Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor2 := 0;
                        END IF;
                        Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor2 := Meses(TO_NUMBER(TO_CHAR(lDat, 'MM'))).Valor2 + 1;
                    END IF;
                END IF;

                IF Meses(13).Valor1 IS NULL THEN
                    Meses(13).Valor1 := 0;
                END IF;
                IF lPre <> 0 THEN
                    Meses(13).Valor1 := Meses(13).Valor1 + 1;
                    
                    IF Meses(13).Valor2 IS NULL THEN
                        Meses(13).Valor2 := 0;
                    END IF;
                    Meses(13).Valor2 := Meses(13).Valor2 + 1;
                ELSE
                    IF lAbo = 0 THEN
                        IF Meses(13).Valor2 IS NULL THEN
                            Meses(13).Valor2 := 0;
                        END IF;
                        Meses(13).Valor2 := Meses(13).Valor2 + 1;
                    END IF;
                END IF;
            END IF;
        END LOOP;

        IF CursorReunioes%ISOPEN THEN
            CLOSE CursorReunioes;
        END IF;

        lTblTemp.Extend;
        lTblTemp(lTblTemp.LAST) := OBJECT_TMPRELATORIOS(lNmeUniOpe, lSigUni, lSigUniRel, lNmeGruCCQ, NULL, NULL, NULL, Meses(1).Valor1, Meses(1).Valor2, Meses(2).Valor1, Meses(2).Valor2, Meses(3).Valor1, Meses(3).Valor2, Meses(4).Valor1, Meses(4).Valor2, Meses(5).Valor1, Meses(5).Valor2, Meses(6).Valor1, Meses(6).Valor2, Meses(7).Valor1, Meses(7).Valor2, Meses(8).Valor1, Meses(8).Valor2, Meses(9).Valor1, Meses(9).Valor2, Meses(10).Valor1, Meses(10).Valor2, Meses(11).Valor1, Meses(11).Valor2, Meses(12).Valor1, Meses(12).Valor2, Meses(13).Valor1, Meses(13).Valor2, NULL, NULL);
    END LOOP;

    IF CursorUnidades%ISOPEN THEN
        CLOSE CursorUnidades;
    END IF;

    OPEN pRecordset FOR
    SELECT StrCol1,
           StrCol2,
           StrCol3,
           StrCol4,
           ValJan01 / ValJan02 * 100 PerJan,
           ValFev01 / ValFev02 * 100 PerFev,
           ValMar01 / ValMar02 * 100 PerMar,
           ValAbr01 / ValAbr02 * 100 PerAbr,
           ValMai01 / ValMai02 * 100 PerMai,
           ValJun01 / ValJun02 * 100 PerJun,
           ValJul01 / ValJul02 * 100 PerJul,
           ValAgo01 / ValAgo02 * 100 PerAgo,
           ValSet01 / ValSet02 * 100 PerSet,
           ValOut01 / ValOut02 * 100 PerOut,
           ValNov01 / ValNov02 * 100 PerNov,
           ValDez01 / ValDez02 * 100 PerDez,
           ValAnoAtu01 / ValAnoAtu02 * 100 PerAnu
        FROM TABLE (CAST(lTblTemp AS OBJECT_TMPRELATORIOS_TABLE));

END;

PROCEDURE RetornarIdeiasPorUG (pIdeUni IN NUMBER, pSub IN NUMBER, pDatIni IN DATE, pDatFin IN DATE, pRecordset OUT tCursorType)
IS
   lideuni   FLOAT;
   lsig      VARCHAR2 (50);
   ltotide   INT;
   ltable    t_tableideiasarvoreunidades := t_tableideiasarvoreunidades();
BEGIN
   FOR ldatarow IN (SELECT vuni.ideuni, vuni.sig
                      FROM (SELECT tuni.ideuni,
                                   SUBSTR((RPAD(' ', (LEVEL - 1) * 4, ' ') || tuni.sig), 1, 50) AS sig
                              FROM tuni
                             WHERE tuni.ideunityp IN (SELECT tunityp.ideunityp
                                                        FROM tunityp
                                                       WHERE tunityp.typ = 1)
                            CONNECT BY PRIOR tuni.ideuni = tuni.idespr
                            START WITH tuni.ideuni = pideuni) vuni)
   LOOP
         ltable.EXTEND;

         IF psub <> 0
         THEN
            SELECT SUM (totide)
              INTO ltotide
              FROM (SELECT COUNT (tide.ideide) totide
                      FROM tide, tsolprb, tuni
                     WHERE tide.ideide = tsolprb.ideide
                       AND tide.ideunisug = tuni.ideuni
                       AND tsolprb.datenc BETWEEN pdatini AND pdatfin
                       AND tuni.idespr IN (
                              SELECT     tuni.ideuni
                                    FROM tuni
                                   WHERE tuni.ideunityp IN (
                                                      SELECT tunityp.ideunityp
                                                        FROM tunityp
                                                       WHERE tunityp.typ = 1)
                              CONNECT BY PRIOR tuni.ideuni = tuni.idespr
                              START WITH tuni.ideuni = ldatarow.ideuni)
                    UNION
                    SELECT COUNT (tide.ideide) totide
                      FROM tide, tsolprb
                     WHERE tide.ideide = tsolprb.ideide
                       AND tide.ideunisug IS NULL
                       AND tsolprb.datenc BETWEEN pdatini AND pdatfin
                       AND tsolprb.ideuni IN (
                              SELECT     tuni.ideuni
                                    FROM tuni
                                   WHERE tuni.ideunityp IN (
                                                      SELECT tunityp.ideunityp
                                                        FROM tunityp
                                                       WHERE tunityp.typ = 1)
                              CONNECT BY PRIOR tuni.ideuni = tuni.idespr
                              START WITH tuni.ideuni = ldatarow.ideuni));
         ELSE
            SELECT SUM (totide)
              INTO ltotide
              FROM (SELECT COUNT (tide.ideide) totide
                      FROM tide, tsolprb, tuni
                     WHERE tide.ideide = tsolprb.ideide
                       AND tide.ideunisug = tuni.ideuni
                       AND tsolprb.datenc BETWEEN pdatini AND pdatfin
                       AND tuni.idespr IN (ldatarow.ideuni)
                    UNION
                    SELECT COUNT (tide.ideide) totide
                      FROM tide, tsolprb
                     WHERE tide.ideide = tsolprb.ideide
                       AND tide.ideunisug IS NULL
                       AND tsolprb.datenc BETWEEN pdatini AND pdatfin
                       AND tsolprb.ideuni IN (ldatarow.ideuni));
         END IF;

         ltable (ltable.LAST) :=
                t_ideiasarvoreunidade (ldatarow.ideuni, ldatarow.sig, ltotide);
   END LOOP;

   OPEN precordset FOR
   SELECT ideuni, sig, totide
     FROM TABLE (CAST (ltable AS t_tableideiasarvoreunidades));

END;

END;
/



/*==============================================================*/
/* ATUALIZA��O DA VERS�O DO BANCO DE DADOS                      */
/*==============================================================*/
DECLARE LVERSION DATE := TO_DATE('02-03-2018', 'DD-MM-YYYY');
        DUMMY    DATE;
        FOUND    BOOLEAN;
		VERSAO	 NVARCHAR2(10) := '1708.4';
 
    CURSOR CURSORVERSAO(CPVERSION DATE) IS
    SELECT VRS FROM TVRS WHERE VRS = LVERSION AND NUMVRS = VERSAO;
BEGIN
    OPEN  CURSORVERSAO(LVERSION);
    FETCH CURSORVERSAO INTO DUMMY;
    FOUND := CURSORVERSAO%FOUND;
    CLOSE CURSORVERSAO;
    IF FOUND THEN
        UPDATE TVRS SET DTAPCK = SYSDATE WHERE VRS = LVERSION AND NUMVRS = VERSAO;
    ELSE
        INSERT INTO TVRS (VRS, DTAPCK , NUMVRS) VALUES (LVERSION, SYSDATE , VERSAO);
    END IF;
END;
/

BEGIN
dbms_output.put_line('1708.4');
END;
/
