
DECLARE EXISTE NUMBER(1);
BEGIN

    SELECT COUNT(*) INTO EXISTE FROM USER_OBJECTS WHERE UPPER(OBJECT_NAME) = 'OBJECT_CUMPRIMENTOACOES';
    IF EXISTE = 1 THEN
        BEGIN
            EXECUTE IMMEDIATE 'DROP TYPE OBJECT_CUMPRIMENTOACOES FORCE';
        END;
    END IF;
    
    SELECT COUNT(*) INTO EXISTE FROM USER_OBJECTS WHERE UPPER(OBJECT_NAME) = 'OBJECT_CUMPRIMENTOACOES_TABLE';
    IF EXISTE = 1 THEN
        BEGIN
            EXECUTE IMMEDIATE 'DROP TYPE OBJECT_CUMPRIMENTOACOES_TABLE  FORCE';
        END;
    END IF;
    
END;
/ 

CREATE OR REPLACE
TYPE OBJECT_CUMPRIMENTOACOES AS OBJECT(
	IDEPACTAREXCRECLOG NUMBER(13),
	IDEUNI		NUMBER(13),
	IDEVIN		NUMBER(13),
	IDEPLAACO   NUMBER(13),
	IDEPACTAR   NUMBER(13),
	FREREC      INT,
	INIPRETAR	DATE,
	FIMPRETAR	DATE,
	DATREF      DATE,
	DATREA      DATE
);
/

CREATE OR REPLACE 
TYPE OBJECT_CUMPRIMENTOACOES_TABLE
AS TABLE OF OBJECT_CUMPRIMENTOACOES;
/

declare existe number(1);
begin

    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_DEFINIRARVORESUBORD';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_DEFINIRARVORESUBORD FORCE';
        end;
    end if;
    
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_DEFINIRARVSUBORD_TABLE';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_DEFINIRARVSUBORD_TABLE  FORCE';
        end;
    end if;
    
end;
/ 

CREATE OR REPLACE 
TYPE OBJECT_DEFINIRARVORESUBORD AS OBJECT (IdeUni NUMBER(13), Sig NVARCHAR2(100), IdeSpr NUMBER(13), Ord INTEGER, LVL INTEGER);
/

CREATE OR REPLACE 
TYPE OBJECT_DEFINIRARVSUBORD_TABLE
 AS TABLE OF OBJECT_DEFINIRARVORESUBORD;
/


DECLARE EXISTE NUMBER(1);
BEGIN

    SELECT COUNT(*) INTO EXISTE FROM USER_OBJECTS WHERE UPPER(OBJECT_NAME) = 'OBJECT_DOCUMENTOSUSUARIO';
    IF EXISTE = 1 THEN
        BEGIN
            EXECUTE IMMEDIATE 'DROP TYPE OBJECT_DOCUMENTOSUSUARIO FORCE';
        END;
    END IF;
    
    SELECT COUNT(*) INTO EXISTE FROM USER_OBJECTS WHERE UPPER(OBJECT_NAME) = 'OBJECT_DOCUMENTOSUSUARIO_TABLE';
    IF EXISTE = 1 THEN
        BEGIN
            EXECUTE IMMEDIATE 'DROP TYPE OBJECT_DOCUMENTOSUSUARIO_TABLE FORCE';
        END;
    END IF;
    
END;
/ 

CREATE OR REPLACE
TYPE OBJECT_DOCUMENTOSUSUARIO AS OBJECT(
	IDEDOCCNT		NUMBER(13)
);
/

CREATE OR REPLACE 
TYPE OBJECT_DOCUMENTOSUSUARIO_TABLE
AS TABLE OF OBJECT_DOCUMENTOSUSUARIO;
/

declare existe number(1);
begin

    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_ESTATISTICALA';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_ESTATISTICALA FORCE';
        end;
    end if;
    
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_ESTATISTICALA_TABLE';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_ESTATISTICALA_TABLE  FORCE';
        end;
    end if;
    
end;
/ 

CREATE OR REPLACE
TYPE OBJECT_ESTATISTICALA AS OBJECT(
Dat     DATE,
QtdCon  INT,
QtdPos  INT,
QtdCom  INT);
/

CREATE OR REPLACE 
TYPE OBJECT_ESTATISTICALA_TABLE
AS TABLE OF OBJECT_ESTATISTICALA;
/



DECLARE EXISTE NUMBER(1);
BEGIN

    SELECT COUNT(*) INTO EXISTE FROM USER_OBJECTS WHERE UPPER(OBJECT_NAME) = 'OBJECT_FAROLIMPOPE';
    IF EXISTE = 1 THEN
        BEGIN
            EXECUTE IMMEDIATE 'DROP TYPE OBJECT_FAROLIMPOPE FORCE';
        END;
    END IF;
    
    SELECT COUNT(*) INTO EXISTE FROM USER_OBJECTS WHERE UPPER(OBJECT_NAME) = 'OBJECT_FAROLIMPOPE_TABLE';
    IF EXISTE = 1 THEN
        BEGIN
            EXECUTE IMMEDIATE 'DROP TYPE OBJECT_FAROLIMPOPE_TABLE  FORCE';
        END;
    END IF;
    
END;
/ 

CREATE OR REPLACE
Type Object_FarolImpOpe As Object(
IDEEPRLICAMB NUMBER(13),
FARIMP  INT,
FAROPE  INT);
/

create or replace 
Type Object_FarolImpOpe_Table
AS TABLE OF OBJECT_FAROLIMPOPE;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_MITIGACAO_TABLE';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_MITIGACAO_TABLE';
        end;
    end if;
end;
/

CREATE OR REPLACE
TYPE OBJECT_MITIGACAO AS OBJECT(
Avl                 INT,
SigUni              VARCHAR2(25),
NmeCau              VARCHAR2(100),
NmeEfe              VARCHAR2(100),
RisAtuRatPonCalIni  FLOAT,
RisAtuRatFinCalIni  FLOAT,
RisAtuRatPonCalFim  FLOAT,
RisAtuRatFinCalFim  FLOAT,
PerMitPon           FLOAT,
PerMitFin           FLOAT,
RisAvlCount         INT);
/

CREATE OR REPLACE 
TYPE OBJECT_MITIGACAO_TABLE
AS TABLE OF OBJECT_MITIGACAO;
/


declare existe number(1);
begin

    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_PLAGESRIS';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_PLAGESRIS FORCE';
        end;
    end if;
    
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_PLAGESRIS_TABLE';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_PLAGESRIS_TABLE  FORCE';
        end;
    end if;
    
end;
/

CREATE OR REPLACE
TYPE OBJECT_PLAGESRIS  AS OBJECT ( 
IdePlaGesRis        NUMBER(13),
IdePlaGesRisAvl     NUMBER(13),
IdeRis              NUMBER(2),
IdeCau              NUMBER(13),
IdeUni              NUMBER(13),
IdeEfe              NUMBER(13),
IdePcs              NUMBER(13),
IdeGruRis           NUMBER(13),
IdeFunFme           NUMBER(13),
IdeOcoFme           NUMBER(13),
IdeSevFme           NUMBER(13),
IdeUsuRes           NUMBER(13),
SigUni              VARCHAR2(25),
NmeFun              VARCHAR2(60),
NmeGru              VARCHAR2(70),
NmeCau              VARCHAR2(100),
NmeEfe              VARCHAR2(100),
Cau                 VARCHAR2(300),
Obs                 VARCHAR2(300),
ValSev              FLOAT,
CatSev              INT,
RisImg              INT,
ValAmbRisImg        FLOAT,
RisOriRatPonCal     FLOAT,
RisAtuRatPonCal     FLOAT,
RisPlaRatPonCal     FLOAT,
RisOriRatFinCal     FLOAT,
RisAtuRatFinCal     FLOAT,
RisPlaRatFinCal     FLOAT,
RisOriRatImgCal     FLOAT,
RisAtuRatImgCal     FLOAT,
RisPlaRatImgCal     FLOAT,
RisOriRatPerCal     FLOAT,
RisAtuRatPerCal     FLOAT,
RisPlaRatPerCal     FLOAT,
RisAtuRatPonCalIni  FLOAT,
RisAtuRatFinCalIni  FLOAT,
RisAtuRatImgCalIni  FLOAT,
PerMitRel           FLOAT,
RisUsuResVrf        VARCHAR2(25),
HasSolPrb           INT,
ColCnf1             VARCHAR2(1),
ColCnf2             VARCHAR2(1),
ColCnf3             VARCHAR2(1),
ColCnf4             VARCHAR2(1),
ColCnf5             VARCHAR2(1),
ColCnf6             VARCHAR2(1),
ColCnf7             VARCHAR2(1),
ColCnf8             VARCHAR2(1),
ColCnf9             VARCHAR2(1),
CauApl              INT,
MaxIniPre           DATE,
IdeUsuPacTarRes     NUMBER(13),
Dat                 DATE);
/

CREATE OR REPLACE 
TYPE OBJECT_PLAGESRIS_TABLE
 AS TABLE OF OBJECT_PLAGESRIS;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_TEMPRELPRODUTIVIDADE';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_TEMPRELPRODUTIVIDADE';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE OBJECT_RELPRODUTIVIDADE AS OBJECT (
NMEGRUCCQ VARCHAR2(45),
NMEUSUFAC VARCHAR2(40),
DATNSC VARCHAR2(10),
PNTREU INT,
PNTPTC INT,
PNTVEA INT,
PNTPDC INT,
PNTTOT INT);
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPRELPRODUTIVIDADE AS TABLE OF OBJECT_RELPRODUTIVIDADE;
/


declare existe number(1);
begin

    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_RETORNARARVORETABELA';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_RETORNARARVORETABELA FORCE';
        end;
    end if;
    
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_RETORNARARVORETAB_TABLE';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_RETORNARARVORETAB_TABLE  FORCE';
        end;
    end if;
    
end;
/ 

CREATE OR REPLACE 
TYPE OBJECT_RETORNARARVORETABELA AS OBJECT (Ide NUMBER(13), Nme VARCHAR2(100), IdeSpr NUMBER(13), Ord INTEGER);
/

CREATE OR REPLACE 
TYPE OBJECT_RETORNARARVORETAB_TABLE
 AS TABLE OF OBJECT_RETORNARARVORETABELA;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_TEMPTABLEFAROLDIARIO';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_TEMPTABLEFAROLDIARIO';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPFAROLDIARIO AS OBJECT (
  IDEACO NUMBER(13),
  IDEACOORI NUMBER(13),
  IDEUNI NUMBER(13),
  SIGUNI VARCHAR2(25),
  NMEUNI VARCHAR2(45),
  UNIVIR NUMBER(1),
  IDEIND NUMBER(13),
  NMEGRUIND VARCHAR2(30),
  NMEIND VARCHAR2(60),
  IDEITEETD1 NUMBER(13),
  NMEITEETD1 VARCHAR2(50),
  IDEITEETD2 NUMBER(13),
  NMEITEETD2 VARCHAR2(50),
  IDEITEETD3 NUMBER(13),
  NMEITEETD3 VARCHAR2(50),
  IDEITEETD4 NUMBER(13),
  NMEITEETD4 VARCHAR2(50),
  IDEITEETD5 NUMBER(13),
  NMEITEETD5 VARCHAR2(50),
  IDEITEETD6 NUMBER(13),
  NMEITEETD6 VARCHAR2(50),
  NMEUNIMED VARCHAR2(30),
  MELIND INT,
  DESMET VARCHAR2(200),
  SIGMET VARCHAR2(35),
  RESACO VARCHAR2(40),
  SIGTIPACOIND VARCHAR2(3),
  VRFDSD NUMBER(2),
  IMP NUMBER(1),
  PRC NUMBER(1),
  FATGRN FLOAT,
  PND FLOAT,
  ACMDIM NUMBER(1),
  STT NUMBER(1),
  SOLPRBMEL INT,
  REA FLOAT,
  MET FLOAT,
  METINF FLOAT,
  METSUP FLOAT,
  PER FLOAT,
  FAR01 INT,
  FAR02 INT,
  FAR03 INT,
  FAR04 INT,
  FAR05 INT,
  FAR06 INT,
  FAR07 INT,
  FAR08 INT,
  FAR09 INT,
  FAR10 INT,
  FAR11 INT,
  FAR12 INT,
  FAR13 INT,
  FAR14 INT,
  FAR15 INT,
  FAR16 INT,
  FAR17 INT,
  FAR18 INT,
  FAR19 INT,
  FAR20 INT,
  FAR21 INT,
  FAR22 INT,
  FAR23 INT,
  FAR24 INT,
  FAR25 INT,
  FAR26 INT,
  FAR27 INT,
  FAR28 INT,
  FAR29 INT,
  FAR30 INT,
  FAR31 INT
 );
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPTABLEFAROLDIARIO AS TABLE OF OBJECT_TEMPFAROLDIARIO;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_TEMPTABLEFAROLMENSAL';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_TEMPTABLEFAROLMENSAL';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPFAROLMENSAL AS OBJECT (
  IDEACO NUMBER(13),
  IDEACOORI NUMBER(13),
  IDEUNI NUMBER(13),
  SIGUNI VARCHAR2(25),
  NMEUNI VARCHAR2(45),
  UNIVIR NUMBER(1),
  IDEIND NUMBER(13),
  NMEGRUIND VARCHAR2(30),
  NMEIND VARCHAR2(60),
  IDEITEETD1 NUMBER(13),
  NMEITEETD1 VARCHAR2(50),
  IDEITEETD2 NUMBER(13),
  NMEITEETD2 VARCHAR2(50),
  IDEITEETD3 NUMBER(13),
  NMEITEETD3 VARCHAR2(50),
  IDEITEETD4 NUMBER(13),
  NMEITEETD4 VARCHAR2(50),
  IDEITEETD5 NUMBER(13),
  NMEITEETD5 VARCHAR2(50),
  IDEITEETD6 NUMBER(13),
  NMEITEETD6 VARCHAR2(50),
  NMEUNIMED VARCHAR2(30),
  MELIND INT,
  DESMET VARCHAR2(200),
  SIGMET VARCHAR2(35),
  RESACO VARCHAR2(40),
  SIGTIPACOIND VARCHAR2(3),
  VRFDSD NUMBER(2),
  IMP NUMBER(1),
  PRC NUMBER(1),
  FATGRN FLOAT,
  PND FLOAT,
  ACMDIM NUMBER(1),
  STT NUMBER(1),
  SOLPRBMEL INT,
  REA FLOAT,
  MET FLOAT,
  METINF FLOAT,
  METSUP FLOAT,
  PER FLOAT,
  PERATN FLOAT,
  FAR01 INT,
  FAR02 INT,
  FAR03 INT,
  FAR04 INT,
  FAR05 INT,
  FAR06 INT,
  FAR07 INT,
  FAR08 INT,
  FAR09 INT,
  FAR10 INT,
  FAR11 INT,
  FAR12 INT);
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPTABLEFAROLMENSAL AS TABLE OF OBJECT_TEMPFAROLMENSAL;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_TEMPTABLEIDE';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_TEMPTABLEIDE';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPIDE AS OBJECT (IDETMP NUMBER(13));
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPTABLEIDE AS TABLE OF REF OBJECT_TEMPIDE;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_TEMPTABLEMAPEAMENTO';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_TEMPTABLEMAPEAMENTO';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPMAPEAMENTO AS OBJECT (
  IDEACO NUMBER(13),
  IDEACOORI NUMBER(13),
  IDEMAPOBJ NUMBER(13),
  NMEMAPOBJ VARCHAR(200),
  IDEOBJEST NUMBER(13),
  TOP NUMBER,
  LFT NUMBER,
  WDT NUMBER,
  HGT NUMBER,
  ORITXT NUMBER(1),
  FMTMAP NUMBER(1),
  IDEMAPSUB NUMBER(13),
  TIPCLC NUMBER(1),
  PNDOBJESTACO FLOAT,
  IDEUNI NUMBER(13),
  SIGUNI VARCHAR2(25),
  NMEUNI VARCHAR2(45),
  UNIVIR NUMBER(1),
  IDEIND NUMBER(13),
  NMEGRUIND VARCHAR2(30),
  NMEIND VARCHAR2(60),
  IDEITEETD1 NUMBER(13),
  NMEITEETD1 VARCHAR2(50),
  IDEITEETD2 NUMBER(13),
  NMEITEETD2 VARCHAR2(50),
  IDEITEETD3 NUMBER(13),
  NMEITEETD3 VARCHAR2(50),
  IDEITEETD4 NUMBER(13),
  NMEITEETD4 VARCHAR2(50),
  IDEITEETD5 NUMBER(13),
  NMEITEETD5 VARCHAR2(50),
  IDEITEETD6 NUMBER(13),
  NMEITEETD6 VARCHAR2(50),
  NMEUNIMED VARCHAR2(30),
  MELIND INT,
  DESMET VARCHAR2(200),
  SIGMET VARCHAR2(35),
  RESACO VARCHAR2(40),
  SIGTIPACOIND VARCHAR2(3),
  IMP NUMBER(1),
  PRC NUMBER(1),
  FATGRN FLOAT,
  PND FLOAT,
  ACMDIM NUMBER(1),
  STT NUMBER(1),
  SOLPRBMEL INT,
  REA FLOAT,
  MET FLOAT,
  METINF FLOAT,
  METSUP FLOAT,
  PER FLOAT,
  FAR01 INT,
  FAR02 INT,
  FAR03 INT,
  FAR04 INT,
  FAR05 INT,
  FAR06 INT,
  FAR07 INT,
  FAR08 INT,
  FAR09 INT,
  FAR10 INT,
  FAR11 INT,
  FAR12 INT);
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPTABLEMAPEAMENTO AS TABLE OF OBJECT_TEMPMAPEAMENTO;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_TEMPTABLEPLANILHADIARIO';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_TEMPTABLEPLANILHADIARIO';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPPLANILHADIARIO AS OBJECT (
  IDEACO NUMBER(13),
  IDEUNI NUMBER(13),
  SIGUNI VARCHAR2(25),
  NMEUNI VARCHAR2(45),
  UNIVIR NUMBER(1),
  IDEIND NUMBER(13),
  NMEGRUIND VARCHAR2(30),
  NMEIND VARCHAR2(60),
  IDEITEETD1 NUMBER(13),
  NMEITEETD1 VARCHAR2(50),
  IDEITEETD2 NUMBER(13),
  NMEITEETD2 VARCHAR2(50),
  IDEITEETD3 NUMBER(13),
  NMEITEETD3 VARCHAR2(50),
  IDEITEETD4 NUMBER(13),
  NMEITEETD4 VARCHAR2(50),
  IDEITEETD5 NUMBER(13),
  NMEITEETD5 VARCHAR2(50),
  IDEITEETD6 NUMBER(13),
  NMEITEETD6 VARCHAR2(50),
  NMEUNIMED VARCHAR2(30),
  MELIND INT,
  DESMET VARCHAR2(200),
  SIGMET VARCHAR2(35),
  RESACO VARCHAR2(40),
  SIGTIPACOIND VARCHAR2(3),
  VRFDSD NUMBER(2),
  DSDITE NUMBER(1),
  DSDHIE NUMBER(1),
  DSDITEFML NUMBER(1),
  VALBMK FLOAT,
  VALREAX_1 FLOAT,
  VALREAX_2 FLOAT,
  IMP NUMBER(1),
  PRC NUMBER(1),
  FATGRN FLOAT,
  ACMDIM NUMBER(1),
  STT NUMBER(1),
  REA01 FLOAT,
  MET01 FLOAT,
  METINF01 FLOAT,
  METSUP01 FLOAT,
  FAR01 INT,
  PER01 FLOAT,
  REA02 FLOAT,
  MET02 FLOAT,
  METINF02 FLOAT,
  METSUP02 FLOAT,
  FAR02 INT,
  PER02 FLOAT,
  REA03 FLOAT,
  MET03 FLOAT,
  METINF03 FLOAT,
  METSUP03 FLOAT,
  FAR03 INT,
  PER03 FLOAT,
  REA04 FLOAT,
  MET04 FLOAT,
  METINF04 FLOAT,
  METSUP04 FLOAT,
  FAR04 INT,
  PER04 FLOAT,
  REA05 FLOAT,
  MET05 FLOAT,
  METINF05 FLOAT,
  METSUP05 FLOAT,
  FAR05 INT,
  PER05 FLOAT,
  REA06 FLOAT,
  MET06 FLOAT,
  METINF06 FLOAT,
  METSUP06 FLOAT,
  FAR06 INT,
  PER06 FLOAT,
  REA07 FLOAT,
  MET07 FLOAT,
  METINF07 FLOAT,
  METSUP07 FLOAT,
  FAR07 INT,
  PER07 FLOAT,
  REA08 FLOAT,
  MET08 FLOAT,
  METINF08 FLOAT,
  METSUP08 FLOAT,
  FAR08 INT,
  PER08 FLOAT,
  REA09 FLOAT,
  MET09 FLOAT,
  METINF09 FLOAT,
  METSUP09 FLOAT,
  FAR09 INT,
  PER09 FLOAT,
  REA10 FLOAT,
  MET10 FLOAT,
  METINF10 FLOAT,
  METSUP10 FLOAT,
  FAR10 INT,
  PER10 FLOAT,
  REA11 FLOAT,
  MET11 FLOAT,
  METINF11 FLOAT,
  METSUP11 FLOAT,
  FAR11 INT,
  PER11 FLOAT,
  REA12 FLOAT,
  MET12 FLOAT,
  METINF12 FLOAT,
  METSUP12 FLOAT,
  FAR12 INT,
  PER12 FLOAT,
  REA13 FLOAT,
  MET13 FLOAT,
  METINF13 FLOAT,
  METSUP13 FLOAT,
  FAR13 INT,
  PER13 FLOAT,
  REA14 FLOAT,
  MET14 FLOAT,
  METINF14 FLOAT,
  METSUP14 FLOAT,
  FAR14 INT,
  PER14 FLOAT,
  REA15 FLOAT,
  MET15 FLOAT,
  METINF15 FLOAT,
  METSUP15 FLOAT,
  FAR15 INT,
  PER15 FLOAT,
  REA16 FLOAT,
  MET16 FLOAT,
  METINF16 FLOAT,
  METSUP16 FLOAT,
  FAR16 INT,
  PER16 FLOAT,
  REA17 FLOAT,
  MET17 FLOAT,
  METINF17 FLOAT,
  METSUP17 FLOAT,
  FAR17 INT,
  PER17 FLOAT,
  REA18 FLOAT,
  MET18 FLOAT,
  METINF18 FLOAT,
  METSUP18 FLOAT,
  FAR18 INT,
  PER18 FLOAT,
  REA19 FLOAT,
  MET19 FLOAT,
  METINF19 FLOAT,
  METSUP19 FLOAT,
  FAR19 INT,
  PER19 FLOAT,
  REA20 FLOAT,
  MET20 FLOAT,
  METINF20 FLOAT,
  METSUP20 FLOAT,
  FAR20 INT,
  PER20 FLOAT,
  REA21 FLOAT,
  MET21 FLOAT,
  METINF21 FLOAT,
  METSUP21 FLOAT,
  FAR21 INT,
  PER21 FLOAT,
  REA22 FLOAT,
  MET22 FLOAT,
  METINF22 FLOAT,
  METSUP22 FLOAT,
  FAR22 INT,
  PER22 FLOAT,
  REA23 FLOAT,
  MET23 FLOAT,
  METINF23 FLOAT,
  METSUP23 FLOAT,
  FAR23 INT,
  PER23 FLOAT,
  REA24 FLOAT,
  MET24 FLOAT,
  METINF24 FLOAT,
  METSUP24 FLOAT,
  FAR24 INT,
  PER24 FLOAT,
  REA25 FLOAT,
  MET25 FLOAT,
  METINF25 FLOAT,
  METSUP25 FLOAT,
  FAR25 INT,
  PER25 FLOAT,
  REA26 FLOAT,
  MET26 FLOAT,
  METINF26 FLOAT,
  METSUP26 FLOAT,
  FAR26 INT,
  PER26 FLOAT,
  REA27 FLOAT,
  MET27 FLOAT,
  METINF27 FLOAT,
  METSUP27 FLOAT,
  FAR27 INT,
  PER27 FLOAT,
  REA28 FLOAT,
  MET28 FLOAT,
  METINF28 FLOAT,
  METSUP28 FLOAT,
  FAR28 INT,
  PER28 FLOAT,
  REA29 FLOAT,
  MET29 FLOAT,
  METINF29 FLOAT,
  METSUP29 FLOAT,
  FAR29 INT,
  PER29 FLOAT,
  REA30 FLOAT,
  MET30 FLOAT,
  METINF30 FLOAT,
  METSUP30 FLOAT,
  FAR30 INT,
  PER30 FLOAT,
  REA31 FLOAT,
  MET31 FLOAT,
  METINF31 FLOAT,
  METSUP31 FLOAT,
  FAR31 INT,
  PER31 FLOAT);
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPTABLEPLANILHADIARIO AS TABLE OF OBJECT_TEMPPLANILHADIARIO;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_TEMPTABLEPLANILHAMENSAL';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_TEMPTABLEPLANILHAMENSAL';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPPLANILHAMENSAL AS OBJECT (
   IDEACO NUMBER(13),
   IDEUNI NUMBER(13),
   SIGUNI VARCHAR2(25),
   NMEUNI VARCHAR2(45),
   UNIVIR NUMBER(1),
   IDEIND NUMBER(13),
   NMEGRUIND VARCHAR2(30),
   NMEIND VARCHAR2(60),
   IDEITEETD1 NUMBER(13),
   NMEITEETD1 VARCHAR2(50),
   IDEITEETD2 NUMBER(13),
   NMEITEETD2 VARCHAR2(50),
   IDEITEETD3 NUMBER(13),
   NMEITEETD3 VARCHAR2(50),
   IDEITEETD4 NUMBER(13),
   NMEITEETD4 VARCHAR2(50),
   IDEITEETD5 NUMBER(13),
   NMEITEETD5 VARCHAR2(50),
   IDEITEETD6 NUMBER(13),
   NMEITEETD6 VARCHAR2(50),
   NMEUNIMED VARCHAR2(30),
   MELIND INT,
   DESMET VARCHAR2(200),
   SIGMET VARCHAR2(35),
   RESACO VARCHAR2(40),
   SIGTIPACOIND VARCHAR2(3),
   VRFDSD NUMBER(2),
   DSDITE NUMBER(1),
   DSDHIE NUMBER(1),
   DSDITEFML NUMBER(1),
   VALBMK FLOAT,
   VALREAX_1 FLOAT,
   VALREAX_2 FLOAT,
   IMP NUMBER(1),
   PRC NUMBER(1),
   FATGRN FLOAT,
   ACMDIM NUMBER(1),
   STT NUMBER(1),
   REA01 FLOAT,
   MET01 FLOAT,
   METINF01 FLOAT,
   METSUP01 FLOAT,
   FAR01 INT,
   PER01 FLOAT,
   REA02 FLOAT,
   MET02 FLOAT,
   METINF02 FLOAT,
   METSUP02 FLOAT,
   FAR02 INT,
   PER02 FLOAT,
   REA03 FLOAT,
   MET03 FLOAT,
   METINF03 FLOAT,
   METSUP03 FLOAT,
   FAR03 INT,
   PER03 FLOAT,
   REA04 FLOAT,
   MET04 FLOAT,
   METINF04 FLOAT,
   METSUP04 FLOAT,
   FAR04 INT,
   PER04 FLOAT,
   REA05 FLOAT,
   MET05 FLOAT,
   METINF05 FLOAT,
   METSUP05 FLOAT,
   FAR05 INT,
   PER05 FLOAT,
   REA06 FLOAT,
   MET06 FLOAT,
   METINF06 FLOAT,
   METSUP06 FLOAT,
   FAR06 INT,
   PER06 FLOAT,
   REA07 FLOAT,
   MET07 FLOAT,
   METINF07 FLOAT,
   METSUP07 FLOAT,
   FAR07 INT,
   PER07 FLOAT,
   REA08 FLOAT,
   MET08 FLOAT,
   METINF08 FLOAT,
   METSUP08 FLOAT,
   FAR08 INT,
   PER08 FLOAT,
   REA09 FLOAT,
   MET09 FLOAT,
   METINF09 FLOAT,
   METSUP09 FLOAT,
   FAR09 INT,
   PER09 FLOAT,
   REA10 FLOAT,
   MET10 FLOAT,
   METINF10 FLOAT,
   METSUP10 FLOAT,
   FAR10 INT,
   PER10 FLOAT,
   REA11 FLOAT,
   MET11 FLOAT,
   METINF11 FLOAT,
   METSUP11 FLOAT,
   FAR11 INT,
   PER11 FLOAT,
   REA12 FLOAT,
   MET12 FLOAT,
   METINF12 FLOAT,
   METSUP12 FLOAT,
   FAR12 INT,
   PER12 FLOAT);
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPTABLEPLANILHAMENSAL AS TABLE OF OBJECT_TEMPPLANILHAMENSAL;
/


DECLARE EXISTE NUMBER(1);
BEGIN

    SELECT COUNT(*) INTO EXISTE FROM USER_OBJECTS WHERE UPPER(OBJECT_NAME) = 'OBJECT_TEMPUNIUSU';
    IF EXISTE = 1 THEN
        BEGIN
            EXECUTE IMMEDIATE 'DROP TYPE OBJECT_TEMPUNIUSU FORCE';
        END;
    END IF;
    
    SELECT COUNT(*) INTO EXISTE FROM USER_OBJECTS WHERE UPPER(OBJECT_NAME) = 'OBJECT_TEMPUNIUSU_TABLE';
    IF EXISTE = 1 THEN
        BEGIN
            EXECUTE IMMEDIATE 'DROP TYPE OBJECT_TEMPUNIUSU_TABLE FORCE';
        END;
    END IF;
    
END;
/

CREATE OR REPLACE
TYPE OBJECT_TEMPUNIUSU  AS OBJECT ( 

IdeUni              NUMBER(13),
Sig                 VARCHAR2(50),
UniVir              NUMBER(1),
UpdDta              NUMBER(1),
ORD                 INT
);
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPUNIUSU_TABLE
 AS TABLE OF OBJECT_TEMPUNIUSU;
/
 

declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_TMPACO_TABLE';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_TMPACO_TABLE';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE OBJECT_TMPACO AS OBJECT (
   IDEACO           NUMBER(13),
   IDEACOREL        NUMBER(13),
   IDEIND           NUMBER(13),
   ORD              SMALLINT,
   REMOVE           NUMBER(1)
 );
/

CREATE OR REPLACE TYPE OBJECT_TMPACO_TABLE AS TABLE OF OBJECT_TMPACO;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_TMPRELATORIOS_TABLE';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_TMPRELATORIOS_TABLE';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE OBJECT_TMPRELATORIOS AS OBJECT (StrCol1     VARCHAR2(50),
                                           StrCol2     VARCHAR2(50),
                                           StrCol3     VARCHAR2(50),
                                           StrCol4     VARCHAR2(50),
                                           ValStr01    VARCHAR2(50),
                                           ValAnoAnt01 INT,
                                           ValAnoAnt02 INT,
                                           ValJan01    INT,
                                           ValJan02    INT,
                                           ValFev01    INT,
                                           ValFev02    INT,
                                           ValMar01    INT,
                                           ValMar02    INT,
                                           ValAbr01    INT,
                                           ValAbr02    INT,
                                           ValMai01    INT,
                                           ValMai02    INT,
                                           ValJun01    INT,
                                           ValJun02    INT,
                                           ValJul01    INT,
                                           ValJul02    INT,
                                           ValAgo01    INT,
                                           ValAgo02    INT,
                                           ValSet01    INT,
                                           ValSet02    INT,
                                           ValOut01    INT,
                                           ValOut02    INT,
                                           ValNov01    INT,
                                           ValNov02    INT,
                                           ValDez01    INT,
                                           ValDez02    INT,
                                           ValAnoAtu01 INT,
                                           ValAnoAtu02 INT,
                                           ValDat01    DATE,
                                           ValDat02    DATE);
/

CREATE OR REPLACE TYPE OBJECT_TMPRELATORIOS_TABLE AS TABLE OF OBJECT_TMPRELATORIOS;
/


declare existe number(1);
begin

	SELECT COUNT(*) INTO EXISTE FROM USER_OBJECTS WHERE UPPER(OBJECT_NAME) = 'OBJECT_TMPRELSTATUS';
    IF EXISTE = 1 THEN
        BEGIN
            EXECUTE IMMEDIATE 'DROP TYPE OBJECT_TMPRELSTATUS FORCE';
        END;
    END IF;

    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_TMPRELSTATUS_TABLE';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_TMPRELSTATUS_TABLE FORCE';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE object_tmprelstatus         AS OBJECT (ORD                 INT, 
                                            NMEUSU              VARCHAR2(100),
                                            IDEUSU              DECIMAL(13),
                                            SIG                 VARCHAR2(75),
                                            IDEUNI              DECIMAL(13),
                                            TOT                 INT, 
                                            Criados             INT, 
                                            AgingMonths         INT,
                                            EmAberto            INT,
                                            Reprogramadas       INT,
                                            EmAndamento         INT, 
                                            EmAtraso            INT, 
                                            Concluidos          INT);
/

CREATE OR REPLACE TYPE OBJECT_TMPRELSTATUS_TABLE AS TABLE OF OBJECT_TMPRELSTATUS;
/


declare existe number(1);
begin

	SELECT COUNT(*) INTO EXISTE FROM USER_OBJECTS WHERE UPPER(OBJECT_NAME) = 'OBJECT_TMPRELSTATUS30';
    IF EXISTE = 1 THEN
        BEGIN
            EXECUTE IMMEDIATE 'DROP TYPE OBJECT_TMPRELSTATUS30 FORCE';
        END;
    END IF;

    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_TMPRELSTATUS30_TABLE';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_TMPRELSTATUS30_TABLE FORCE';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE object_tmprelstatus30         AS OBJECT (ORD                 INT, 
                                            NMEUSU              VARCHAR2(100),
                                            IDEUSU              DECIMAL(13),
                                            SIG                 VARCHAR2(75),
                                            IDEUNI              DECIMAL(13),
                                            TOT                 INT, 
                                            Criadas             INT, 
                                            PlanejadasNoPrazo   INT,
                                            PlanejadasAtrasada  INT,
                                            EmExecucaoNoPrazo   INT,
                                            EmExecucaoAtrasada  INT, 
                                            FinalizadaNoPrazo   INT, 
                                            FinalizadaAtrasada  INT);
/

CREATE OR REPLACE TYPE OBJECT_TMPRELSTATUS30_TABLE AS TABLE OF OBJECT_TMPRELSTATUS30;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'OBJTABLEDIMENSOESDISPONIVEIS';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJTABLEDIMENSOESDISPONIVEIS';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE OBJTEMPDIMENSOESDISPONIVEIS AS OBJECT (
  IDETIPDSD NUMBER(13),
  ORD NUMBER(1),
  NMEETD VARCHAR(40)
 );
/

CREATE OR REPLACE 
TYPE OBJTABLEDIMENSOESDISPONIVEIS AS TABLE OF OBJTEMPDIMENSOESDISPONIVEIS;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'OBJ_TEMPTABLEERROCOPIAACO';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJ_TEMPTABLEERROCOPIAACO';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE OBJ_TEMPERROCOPIAACO AS OBJECT ( 
   NMEACOORI VARCHAR2(1000), 
   NMEACODST VARCHAR2(1000), 
   TIPERR NUMBER(1));
/

CREATE OR REPLACE 
TYPE OBJ_TEMPTABLEERROCOPIAACO AS TABLE OF OBJ_TEMPERROCOPIAACO;
/

declare existe number(1);
begin
    
    select count(*) into existe from user_objects where upper(object_name) = 'SPLIT_OBJ';
    if existe = 1 then
        begin
			execute immediate 'DROP TYPE SPLIT_OBJ';
        end;
    end if;
	
	select count(*) into existe from user_objects where upper(object_name) = 'SPLIT_TBL';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE SPLIT_TBL';
        end;
    end if;
    COMMIT;
end;
/

CREATE OR REPLACE TYPE SPLIT_TBL AS OBJECT (
   ITEM  VARCHAR2(8000),
   ORD VARCHAR2(8000));
/

CREATE OR REPLACE 
TYPE SPLIT_OBJ AS TABLE OF SPLIT_TBL;
/
declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'TTABLERETORNOBONUSTYPE';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE TTABLERETORNOBONUSTYPE';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE TRETORNOBONUSTYPE AS OBJECT (DAT DATE, ANOREF INT, REG NUMBER(8),
   NTA FLOAT);
/

CREATE OR REPLACE 
TYPE TTABLERETORNOBONUSTYPE AS TABLE OF TRETORNOBONUSTYPE;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'TABLEDESVIOMENSAL';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE TABLEDESVIOMENSAL';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE TYPEDESVIOMENSAL AS OBJECT (
   IDEACO NUMBER(13),
   IDEACOORI NUMBER(13),
   IDEUNI NUMBER(13),
   SIGUNI VARCHAR2(50),
   NMEUNI VARCHAR2(50),
   NMENIVHIE VARCHAR2(30),
   UNIVIR NUMBER(1),
   IDEIND NUMBER(13),
   NMEGRUIND VARCHAR2(60),
   NMEIND VARCHAR2(60),
   IDEITEETD1 NUMBER(13),
   NMEITEETD1 VARCHAR2(50),
   IDEITEETD2 NUMBER(13),
   NMEITEETD2 VARCHAR2(50),
   IDEITEETD3 NUMBER(13),
   NMEITEETD3 VARCHAR2(50),
   IDEITEETD4 NUMBER(13),
   NMEITEETD4 VARCHAR2(50),
   IDEITEETD5 NUMBER(13),
   NMEITEETD5 VARCHAR2(50),
   IDEITEETD6 NUMBER(13),
   NMEITEETD6 VARCHAR2(50),
   NMEUNIMED VARCHAR2(30),
   MELIND INT,
   DESMET VARCHAR2(200),
   SIGMET VARCHAR2(35),
   RESACO VARCHAR2(40),
   SIGTIPACOIND VARCHAR2(3),
   VRFDSD NUMBER(2),
   IMP NUMBER(1),
   PRC NUMBER(1),
   FATGRN FLOAT,
   PND FLOAT,
   ACMDIM NUMBER(1),
   STT NUMBER(1),
   SOLPRBMEL INT,
   REA FLOAT,
   MET FLOAT,
   METINF FLOAT,
   METSUP FLOAT,
   PER FLOAT,
   PERATN FLOAT,
   FAR INT);
/

CREATE OR REPLACE 
TYPE TABLEDESVIOMENSAL AS TABLE OF TYPEDESVIOMENSAL;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'TABLETMPIDE';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE TABLETMPIDE';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE TYPETMPIDE AS OBJECT (IDETMP NUMBER(13));
/

CREATE OR REPLACE 
TYPE TABLETMPIDE AS TABLE OF TYPETMPIDE;
/

 
declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'OBJECT_TEMPRETNDOC';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE OBJECT_TEMPRETNDOC';
        end;
    end if;
end;
/

CREATE OR REPLACE TYPE T_DOCUMENTOSUSUARIO AS OBJECT (
   IDEDOCCNT           NUMBER(13),
   PERNAORCB           INT,
   IDEUSU              NUMBER(13), 
   IDEDOCCNTVERUSU     NUMBER(13)
 );
/

CREATE OR REPLACE 
TYPE OBJECT_TEMPRETNDOC AS TABLE OF T_DOCUMENTOSUSUARIO;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'T_TABLEIDEIASARVOREUNIDADES';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE T_TABLEIDEIASARVOREUNIDADES';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE T_IDEIASARVOREUNIDADE AS OBJECT (
     ideuni   NUMBER (13),
     sig      VARCHAR2 (100),
     totide   INT
  );
/

CREATE OR REPLACE 
TYPE T_TABLEIDEIASARVOREUNIDADES IS TABLE OF T_IDEIASARVOREUNIDADE;
/


declare existe number(1);
begin
    select count(*) into existe from user_objects where upper(object_name) = 'T_TABLERELATORIOSANUAIS';
    if existe = 1 then
        begin
            execute immediate 'DROP TYPE T_TABLERELATORIOSANUAIS';
        end;
    end if;
end;
/

CREATE OR REPLACE 
TYPE T_LINHARELATORIOSANUAIS AS OBJECT 
                                        (StrCol1     VARCHAR2(50),
                                         StrCol2     VARCHAR2(50),
                                         StrCol3     VARCHAR2(50),
                                         ValStr01    VARCHAR2(20),
                                         ValAnoAnt01 INT,
                                         ValAnoAnt02 INT,
                                                      ValJan01    INT,
                                         ValJan02    INT,
                                                      ValFev01    INT,
                                         ValFev02    INT,
                                                      ValMar01    INT,
                                         ValMar02    INT,
                                                      ValAbr01    INT,
                                         ValAbr02    INT,
                                                      ValMai01    INT,
                                         ValMai02    INT,
                                                      ValJun01    INT,
                                         ValJun02    INT,
                                                      ValJul01    INT,
                                         ValJul02    INT,
                                                      ValAgo01    INT,
                                         ValAgo02    INT,
                                         ValSet01    INT,
                                         ValSet02    INT,
                                         ValOut01    INT,
                                         ValOut02    INT,
                                         ValNov01    INT,
                                         ValNov02    INT,
                                         ValDez01    INT,
                                         ValDez02    INT,
                                         ValAnoAtu01 INT,
                                         ValAnoAtu02 INT);
/

CREATE OR REPLACE 
TYPE T_TABLERELATORIOSANUAIS AS TABLE OF T_LINHARELATORIOSANUAIS;
/



/*==============================================================*/
/* ATUALIZA��O DA VERS�O DO BANCO DE DADOS                      */
/*==============================================================*/
DECLARE LVERSION DATE := TO_DATE('02-03-2018', 'DD-MM-YYYY');
        DUMMY    DATE;
        FOUND    BOOLEAN;
		VERSAO	 NVARCHAR2(10) := '1708.4';
 
    CURSOR CURSORVERSAO(CPVERSION DATE) IS
    SELECT VRS FROM TVRS WHERE VRS = LVERSION AND NUMVRS = VERSAO;
BEGIN
    OPEN  CURSORVERSAO(LVERSION);
    FETCH CURSORVERSAO INTO DUMMY;
    FOUND := CURSORVERSAO%FOUND;
    CLOSE CURSORVERSAO;
    IF FOUND THEN
        UPDATE TVRS SET DTAOBJTYP = SYSDATE WHERE VRS = LVERSION AND NUMVRS = VERSAO;
    ELSE
        INSERT INTO TVRS (VRS, DTAOBJTYP , NUMVRS) VALUES (LVERSION, SYSDATE , VERSAO);
    END IF;
END;
/

BEGIN
dbms_output.put_line('1708.4');
END;
/

