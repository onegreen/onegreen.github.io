
DECLARE lExists		INT;
		lOrd NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TAUTEML
	 WHERE TPLNME = 'Aviso de Renovacao de Licenca';

	IF lExists = 0 THEN
/*==============================================================*/
		--Aviso de Renovacao de Licenca
		INSERT INTO TAUTEML (IdeAutEml, IdeEmp, Ord, Des, Tip, TblNme, TplNme, TipAge, TipFlt, ExcTme, DiaExc, DtaBse, EnvIme, DiaEntEnv, NumEnv, Msg, Atv, UpdTme)
		VALUES
		(1110000000016, 1110000000001, 2015, 'onegreen - Aviso de Renova��o de Licen�a', 1, 'tLicAmb', 'Aviso de Renovacao de Licenca', 3, 0, null, null, null, 1, 0, 1, 'Prezado usu�rio,

		Uma licen�a registrada no onegreen, que est� sob sua responsabilidade, est� pr�xima do seu prazo de Renova��o.

		Pedimos que tome conhecimento.', 1, SYSDATE);

		COMMIT;

	END IF;
	
	SELECT COUNT(1) INTO lExists
	  FROM TAUTEML
	 WHERE TPLNME = 'Aviso de Proximidade de Vencimento da Notificacao de Abertura do Processo';
	
	IF lExists = 0 THEN
/*==============================================================*/
		--Aviso de Proximidade de Vencimento da Notificacao de Abertura do Processo
		INSERT INTO TAUTEML (IdeAutEml, IdeEmp, Ord, Des, Tip, TblNme, TplNme, TipAge, TipFlt, ExcTme, DiaExc, DtaBse, EnvIme, DiaEntEnv, NumEnv, Msg, Atv, UpdTme)
		VALUES
		(1110000000017, 1110000000001, 2016, 'onegreen - Aviso de Proximidade de Vencimento da Notificacao de Abertura do Processo', 1, 'tLicAmb', 'Aviso de Proximidade de Vencimento da Notificacao de Abertura do Processo', 3, 0, null, null, null, 1, 0, 1, 'Prezado usu�rio,

		Uma licen�a registrada no onegreen, que est� sob sua responsabilidade, est� pr�xima do vencimento da notifica��o de abertura do processo

		Pedimos que tome conhecimento.', 1, SYSDATE);

		COMMIT;

	END IF;
	
END;
/


commit;