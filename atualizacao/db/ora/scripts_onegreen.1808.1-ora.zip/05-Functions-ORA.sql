
CREATE OR REPLACE 
FUNCTION ABREVIARDESCRICAO(pDescricao IN VARCHAR2, pTamanho INT, pIniciaisMaiusculas INT)
  RETURN  VARCHAR2 IS
    lDescricao  VARCHAR2(1000);
    lPosIni     INT;
    lLastPosIni INT;
    lNewPosIni  INT;
BEGIN
    lPosIni := INSTR(pDescricao, ' ', pTamanho);
    IF lPosIni > 0 THEN
        lDescricao := SUBSTR(pDescricao, 1, lPosIni - 1);
    ELSE
        lDescricao := pDescricao;
    END IF;

    IF pIniciaisMaiusculas <> 0 AND LENGTH(lDescricao) > 0 THEN
        lDescricao := LOWER(lDescricao);
        lDescricao := UPPER(SUBSTR(lDescricao, 1, 1)) || SUBSTR(lDescricao, 2, LENGTH(lDescricao));

        lPosIni := INSTR(lDescricao, ' ', 2);

        WHILE lPosIni > 0
        LOOP
            lLastPosIni := lPosIni;
            lPosIni := INSTR(lDescricao, ' ', lLastPosIni + 1);

            IF lPosIni = 0 THEN
                lPosIni := LENGTH(lDescricao) + 1;
            END IF;

            IF lPosIni - lLastPosIni <> 3 THEN       -- n�o leva para mai�sculas os textos De, Da, etc.
                lDescricao := SUBSTR(lDescricao, 1, lLastPosIni) || UPPER(SUBSTR(lDescricao, lLastPosIni + 1, 1)) || SUBSTR(lDescricao, lLastPosIni + 2, LENGTH(lDescricao));
            END IF;

            lPosIni := INSTR(lDescricao, ' ', lLastPosIni + 1);
        END LOOP;
    END IF;

    RETURN lDescricao;

END;
/


CREATE OR REPLACE 
FUNCTION BITCOMPARE(pBitLength IN INTEGER, 
                    pCompareValue IN INTEGER, 
                    pIntValue IN INTEGER) 
RETURN INTEGER 
IS 
lBinIntValue        VARCHAR2(2000); 
lBinCompareValue    VARCHAR2(2000); 
lCharIntValue       CHAR; 
lCharCompareValue   CHAR; 
lInti               INTEGER; 
BEGIN 
 
    lInti := pBitLength; 
    lBinIntValue := To_Binary(pBitLength, pIntValue); 
    lBinCompareValue := To_Binary(pBitLength, pCompareValue); 
 
    WHILE lInti > 0 
    LOOP 
 
        lCharIntValue := SUBSTR(lBinIntValue, lInti, 1); 
        lCharCompareValue := SUBSTR(lBinCompareValue, lInti, 1); 
 
        IF lCharIntValue = 1 AND lCharCompareValue <> 1 THEN 
            RETURN 0; 
        END IF; 
     
        lInti := lInti - 1; 
         
    END LOOP; 
 
    RETURN 1; 
END;
/


CREATE OR REPLACE 
FUNCTION CALCULARRANKING (pIdeUni IN NUMBER,
    pData IN DATE) RETURN FLOAT
IS
    CURSOR CursorReunioesMes(cpIdeUni NUMBER, cpData DATE) IS
        SELECT MIN(tUniScd.Dat) Dat, COUNT(tUniScdPar.IdeUniScdPar) NumPar
          FROM tUniScd, tUniScdPar
         WHERE tUniScd.IdeUniScd = tUniScdPar.IdeUniScd (+) AND
               tUniScd.IdeUni = cpIdeUni AND
               (tUniScd.Dat BETWEEN TRUNC(cpData, 'YEAR') AND cpData) AND
               tUniScd.Stt = 1
      GROUP BY tUniScd.IdeUniScd
      ORDER BY Dat;

    CURSOR CursorReunioesLider(cpIdeUni NUMBER, cpData DATE) IS
        SELECT MIN(tUniScd.Dat) Dat, COUNT(vUniScdPar.IdeUniScdPar) ParRes
          FROM tUniScd, (SELECT IdeUniScdPar, IdeUniScd FROM tUniScdPar WHERE tUniScdPar.Pre <> 0 AND tUniScdPar.Fun = 1) vUniScdPar
         WHERE tUniScd.IdeUniScd = vUniScdPar.IdeUniScd (+) AND
               tUniScd.IdeUni = cpIdeUni AND
               (tUniScd.Dat BETWEEN TRUNC(cpData, 'YEAR') AND cpData) AND
               tUniScd.Stt = 1
      GROUP BY tUniScd.IdeUniScd
      ORDER BY Dat;

    ReunioesMesDataRow   CursorReunioesMes%ROWTYPE;
    ReunioesLiderDataRow CursorReunioesLider%ROWTYPE;

    QuantidadePDCA              NUMBER := 1;        /* Quantidade de PDCA/Ano que o grupo deve fazer */
    QuantidadeVerAgir           NUMBER := 2;        /* Quantidade de Ver e Agir/Ano que o grupo deve fazer */
    PesoPDCA                    FLOAT := 35;        /* Peso percentual dos projetos PDCA no c�lculo */
    PesoVerAgir                 FLOAT := 35;        /* Peso percentual dos projetos Ver e Agir no c�lculo */
    IdeVerAgir                  NUMBER := 1110000000011; /* Identificador do m�todo VerAgir */
    IdePDCA                     NUMBER := 1110000000012; /* Identificador do m�todo PDCA */

    QuantidadeReunioesMes       NUMBER := 1;        /* N�mero m�nimo de reuni�es que o grupo deve fazer/m�s */
    ParticipacaoReuniao         FLOAT := 50;        /* Percentual de participa��o dos componentes nas reuni�es */
    PesoParticipacaoReuniao     FLOAT := 15;        /* Peso percentual nas participa��es dos componentes */
    ParticipacaoLider           FLOAT := 70;        /* Percentual de participa��es dos l�deres em reuni�es */
    PesoParticipacaoLider       FLOAT := 15;        /* Peso percentual nas participa��es dos l�deres */

    NumeroParticipantesGrupo    NUMBER;             /* N�mero de participantes ativos no grupo na data passada */
    NumeroVerAgir               NUMBER;             /* N�mero de Ver e Agir encerrados neste ano */
    NumeroPDCA                  NUMBER;             /* N�mero de PDCA encerrados neste ano */
    NumeroReunioesMes           NUMBER := 0;        /* N�mero de Reuni�es/M�s com mais de 50% de Participa��o */
    NumeroReunioesLider         NUMBER := 0;        /* N�mero de Reuni�es com a participa��o do L�der */

    UltimoMes                   NUMBER := 0;        /* Armazena o �ltimo m�s pesquisado para efeito de n�o computar em um mesmo m�s duas reuni�es que atendam ao requisito */

    Ranking                     FLOAT := 0;
BEGIN
    SELECT COUNT(IdeSolPrb) INTO NumeroVerAgir
      FROM tSolPrb
     WHERE IdeUni = pIdeUni AND
           IdeMetSolPrb = IdeVerAgir AND
           (DatEnc BETWEEN TRUNC(pData, 'YEAR') AND TO_DATE('31/12/' || TO_CHAR(pData, 'YYYY'), 'DD/MM/YYYY'));

    SELECT COUNT(IdeSolPrb) INTO NumeroPDCA
      FROM tSolPrb
     WHERE IdeUni = pIdeUni AND
           IdeMetSolPrb = IdePDCA AND
           (DatEnc BETWEEN TRUNC(pData, 'YEAR') AND TO_DATE('31/12/' || TO_CHAR(pData, 'YYYY'), 'DD/MM/YYYY'));

    IF NumeroVerAgir >= QuantidadeVerAgir THEN
        Ranking := Ranking + PesoVerAgir;
    ELSE
        IF QuantidadeVerAgir > 0 THEN
            Ranking := Ranking + (NumeroVerAgir / QuantidadeVerAgir * PesoVerAgir);
        END IF;
    END IF;

    IF NumeroPDCA >= QuantidadePDCA THEN
        Ranking := Ranking + PesoPDCA;
    ELSE
        IF QuantidadePDCA > 0 THEN
            Ranking := Ranking + (NumeroPDCA / QuantidadePDCA * PesoPDCA);
        END IF;
    END IF;

    OPEN CursorReunioesMes(pIdeUni, pData);
    LOOP
        FETCH CursorReunioesMes INTO ReunioesMesDataRow;
        EXIT WHEN CursorReunioesMes%NOTFOUND;

        IF UltimoMes <> TO_NUMBER(TO_CHAR(ReunioesMesDataRow.Dat, 'MM')) THEN
            SELECT COUNT(IdePar) INTO NumeroParticipantesGrupo
              FROM tPar
             WHERE IdeUni = pIdeUni AND
                   (DatEnt <= TRUNC(ReunioesMesDataRow.Dat, 'MONTH') OR DatEnt IS NULL) AND
                   (DatTrf >= TRUNC(ReunioesMesDataRow.Dat, 'MONTH') OR DatTrf IS NULL) AND
                   Fun <= 3;

            IF ReunioesMesDataRow.NumPar >= NumeroParticipantesGrupo * (ParticipacaoReuniao / 100) THEN
                NumeroReunioesMes := NumeroReunioesMes + 1;
                UltimoMes := TO_NUMBER(TO_CHAR(ReunioesMesDataRow.Dat, 'MM'));
            END IF;
        END IF;
    END LOOP;

    OPEN CursorReunioesLider(pIdeUni, pData);
    LOOP
        FETCH CursorReunioesLider INTO ReunioesLiderDataRow;
        EXIT WHEN CursorReunioesLider%NOTFOUND;

        IF ReunioesLiderDataRow.ParRes <> 0 THEN
            NumeroReunioesLider := NumeroReunioesLider + 1;
        END IF;
    END LOOP;

    IF TO_NUMBER(TO_CHAR(pData, 'MM')) > 0 THEN
        Ranking := Ranking + (NumeroReunioesMes / TO_NUMBER(TO_CHAR(pData, 'MM')) * PesoParticipacaoReuniao);
    END IF;

    IF CursorReunioesMes%ROWCOUNT > 0 THEN
        IF NumeroReunioesLider / CursorReunioesMes%ROWCOUNT * 100 >= ParticipacaoLider THEN
            Ranking := Ranking + PesoParticipacaoLider;
        END IF;
    END IF;

    CLOSE CursorReunioesMes;

    RETURN Ranking;
EXCEPTION WHEN OTHERS THEN
    RETURN -1;
END;
/


CREATE OR REPLACE 
FUNCTION DECODEXML(pStrXml IN varchar, pField IN varchar2)
RETURN VARCHAR2 
IS

/* Procedimento: DecodeXml
   Prop�sito   : Retira o encode de uma string no formato Xml
   Par�metros  : pStrXml-String no formato Xml (Para campos do tipo LONG, utilizar a fun��o LONG_TO_CHAR para converter para varchar)
                 pField-Campo no formato Xml que ser� devolvido
   Cria��o     : 17/05/2005 - mar
   �ltima Alt. : 20/07/2005 - jul */

lMmo LONG;
lRetn VARCHAR(8000);
lVar VARCHAR(8000);
lPosIni INT;
lPosFim INT;
lCharCode INT;
BEGIN
    lMmo := pStrXml;
    select lMmo into lVar from dual;

    IF INSTR(lVar, '<' || pField || '>') > 0 THEN
        lPosIni := INSTR(lVar, '<' || pField || '>');
        lPosFim := INSTR(lVar, '</' || pField || '>');
        lRetn := SUBSTR(lVar, lPosIni + LENGTH('<' || pField || '>'), lPosFim - (lPosIni + LENGTH('<' || pField || '>')));
    ELSE    
    
        lRetn := '';
    
    END IF;
    
    lCharCode := 123;
    WHILE lCharCode < 255
    LOOP
        lRetn := REPLACE(lRetn, '&'||'amp;#'|| CAST(lCharCode AS varchar2) || ';', CHR(lCharCode));
        lCharCode := lCharCode + 1;
    END LOOP;

    lRetn := REPLACE(lRetn, '&'||'amp;lt;', '<');
    lRetn := REPLACE(lRetn, '&'||'amp;gt;', '>');
    lRetn := REPLACE(lRetn, '&'||'amp;amp;', '&');
    lRetn := REPLACE(lRetn, '&'||'amp;quot;', '"');
    lRetn := REPLACE(lRetn, '&'||'amp;euro;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;iexcl;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;cent;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;pound;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;curren;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;yen;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;brvbar;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;sect;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;uml;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;copy;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;ordf;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;laquo;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;not;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;shy;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;reg;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;macr;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;deg;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;plusmn;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;sup2;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;sup3;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;acute;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;micro;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;para;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;middot;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;cedil;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;sup1;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;ordm;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;raquo;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;frac14;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;frac12;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;frac34;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;iquest;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;AElig;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;ETH;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;times;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;Oslash;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;THORN;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;szlig;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;aelig;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;divide;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;oslash;', '�');
    lRetn := REPLACE(lRetn, '&'||'amp;thorn;', '�');

RETURN lRetn;

END;
/

create or replace 
FUNCTION                  "DEFINIRARVORESUBORDINADAS" (pIdDaUnidade NUMBER) RETURN  OBJECT_DEFINIRARVSUBORD_TABLE AS

/* Função       : DefinirArvoreSubordinadas
   Propósito    : Retorna a hierarquia de determinada UG em determinado Plano de Gestão
   Parâmetros   : idDaUnidade - Id da Unidade que terá sua árvore montada         
                  idDoPlanoDeGestao - Id do Plano de Gestão
   Criação      : 10/11/2015 - Paulo Bandeira
   Última Alt.  : 18/04/2016 */


        CURSOR CursorUnidadesGerenciais(idDaUnidade NUMBER) IS
        SELECT tUni.IdeUni, 
			   tUni.Sig SIG,
			   tUni.IdeSpr,
			   ROWNUM ORD,
			   LEVEL LVL
		  FROM tUni
	   CONNECT BY PRIOR tUni.IdeUni = tUni.IdeSpr
		 START WITH tUni.IdeUni = idDaUnidade;

        
    lOrd INTEGER;
    lObject_DefinirArvSubord_Tbl OBJECT_DEFINIRARVSUBORD_TABLE := OBJECT_DEFINIRARVSUBORD_TABLE();
    

    lUnidadesGerenciais CursorUnidadesGerenciais%ROWTYPE;

BEGIN
        OPEN CursorUnidadesGerenciais(pIdDaUnidade);
        LOOP
            FETCH CursorUnidadesGerenciais INTO lUnidadesGerenciais;
            EXIT WHEN CursorUnidadesGerenciais%NOTFOUND;

            lObject_DefinirArvSubord_Tbl.EXTEND();
            
            lObject_DefinirArvSubord_Tbl(lObject_DefinirArvSubord_Tbl.LAST) := OBJECT_DEFINIRARVORESUBORD(lUnidadesGerenciais.IdeUni, lUnidadesGerenciais.Sig, lUnidadesGerenciais.IdeSpr, lUnidadesGerenciais.Ord, lUnidadesGerenciais.LVL);
        END LOOP;
        CLOSE CursorUnidadesGerenciais;

    RETURN lObject_DefinirArvSubord_Tbl;
END;
 /
 
CREATE OR REPLACE 
FUNCTION DEFINIRHORARIOACIDENTE(pDatAcd IN DATE) RETURN INT
IS

/* Fun��o      : definirhorarioacidente
   Prop�sito   : Definir o hor�rio do acidente
   Par�metros  : pDatAcd-� a data/hora do acidente
   Retorno     : 0-Madrugada
                 1-Manh�
                 2-Tarde
                 3-Noite
   Cria��o     : 19/03/2007 - mar
   �ltima Alt. : 19/03/2007 - mar    */

    lRetn                   INT;
    lHora                   INT := TO_NUMBER(TO_CHAR(pDatAcd, 'HH24'));
BEGIN
    IF lHora < 6 THEN
       lretn := 0;
    ELSIF lHora >= 6 AND lHora < 12 THEN
       lretn := 1;
    ELSIF lHora >= 12 AND lHora < 18 THEN
       lretn := 2;
    ELSIF lHora >= 18 AND lHora < 24 THEN
       lretn := 3;
    END IF;

    RETURN lRetn;

END;
/


CREATE OR REPLACE 
FUNCTION DEFINIRSTATUSACAO(pIdePlaAco IN NUMBER, pDataCorrente IN DATE) RETURN INT
IS

/* Fun��o      : DefinirStatusAcao
   Prop�sito   : Definir o Status de uma determinada a��o de um Plano
   Par�metros  : pInicioPrevisto-Data de In�cio Previsto da Tarefa
                 pFinalPrevisto-Data de T�rmino Previsto da Tarefa
                 pInicioRealizado-Data de In�cio Realizado da Tarefa
                 pFinalRealizado-Data de T�rmino Realizado da Tarefa
                 pDataCorrente-Data atual do sistema
   Retorno     :     0-SemStatus
                         1-Planejada
                         2-EmExecucao
                         4-CronogramaComprometido
                         5-Concluida
                         6-ConcluidaComAtraso
   Cria��o     : 09/08/2005 - mar
   �ltima Alt. : 18/13/2014 - PRB */

    lRetn                   INT := 0;
    lSemStatus              INT := 0;
    lPlanejada              INT := 1;
    lEmExecucao             INT := 2;
    lAtrasada                   INT := 3;
    lConcluida              INT := 4;
    lConcluidaComAtraso     INT := 5;
    lPlaAcoComColunaQuando  NUMBER(1);
    lInicioPrevisto         DATE; 
    lFinalPrevisto          DATE;
    lInicioRealizado        DATE; 
    lFinalRealizado         DATE;
    lDataCorrente           DATE;
    lPeriodicidade          INT;
    lDataProximaExecucao    DATE;
    lPercentualDeConclusaoPrevisto FLOAT := 0;
    lPercentualDeConclusao    FLOAT;
    lPrazoParaExecucao    INT;

BEGIN
    lDataCorrente := TO_DATE(TO_CHAR(pDataCorrente, 'DD-MM-YYYY'), 'DD-MM-YYYY');

    SELECT BitCompare(12, CASE WHEN tPacTar.IdeFer IS NULL THEN tAtv.ColShw ELSE tFer.ColShw END, 64), -- Quando = 64
                                 CASE WHEN tPacTar.IdePacTarRel IS NULL THEN tPacTar.IniPre ELSE tPacTarRel.IniPre END,
                                 CASE WHEN tPacTar.IdePacTarRel IS NULL THEN tPacTar.FimPre ELSE tPacTarRel.FimPre END,
                                 CASE WHEN tPacTar.IdePacTarRel IS NULL THEN tPacTar.IniRea ELSE tPacTarRel.IniRea END,
                                 CASE WHEN tPacTar.IdePacTarRel IS NULL THEN tPacTar.FimRea ELSE tPacTarRel.FimRea END,
                                 TPACTAR.FREREC, TPACTAR.PRXEXCREC,
                                 CASE WHEN tPacTar.INIPRE IS NOT NULL AND tPacTar.FIMPRE IS NOT NULL THEN tPacTar.FimPre - tPacTar.IniPre + 1 ELSE 0 END,
                                 TPACTAR.PERCON
                                 INTO lPlaAcoComColunaQuando, lInicioPrevisto, lFinalPrevisto, lInicioRealizado, lFinalRealizado, lPeriodicidade, lDataProximaExecucao, lPrazoParaExecucao, lPercentualDeConclusao
      FROM tPacTar
                          LEFT JOIN tFer ON tPacTar.IdeFer = tFer.IdeFer
                          LEFT JOIN tUniScd ON tPacTar.IdeUniScd = tUniScd.IdeUniScd
                          LEFT JOIN tAtv ON tUniScd.IdeAtv = tAtv.IdeAtv
                          LEFT JOIN tPacTar tPacTarRel ON tPacTar.IdePacTarRel = tPacTarRel.IdePacTar
     WHERE tPacTar.IdePacTar = pIdePlaAco;

    IF NOT lFinalPrevisto IS NULL THEN
        lFinalPrevisto := lFinalPrevisto + 1 - 0.00001;
    END IF;
    
    IF (lPeriodicidade = 0 AND lPrazoParaExecucao > 0) THEN
      lPercentualDeConclusaoPrevisto := (TO_DATE(TO_CHAR(SYSDATE, 'DD-MM-YYYY'), 'DD-MM-YYYY') - lInicioPrevisto) / lPrazoParaExecucao * 100;
    END IF;
    
    IF lFinalRealizado IS NOT NULL THEN
        IF lFinalPrevisto IS NOT NULL THEN
            IF lFinalRealizado <= lFinalPrevisto THEN
                lRetn := lConcluida;
            ELSE
                lRetn := lConcluidaComAtraso;
            END IF;
        ELSE
            lRetn := lConcluida;
        END IF;
    ELSE
          IF lInicioPrevisto IS NOT NULL THEN
              IF lInicioPrevisto >= lDataCorrente THEN
                    IF lInicioRealizado IS NOT NULL THEN
                        lRetn := lEmExecucao;
                    ELSE
                        lRetn := lPlanejada;
                    END IF;
              ELSE
                    IF lInicioRealizado IS NOT NULL THEN
                          IF lInicioRealizado <= lInicioPrevisto THEN
                               IF lPeriodicidade = 0 THEN
                                    IF lFinalPrevisto IS NOT NULL THEN
                                            IF lFinalPrevisto >= lDataCorrente THEN
                                                lRetn := lEmExecucao;
                                            ELSE
                                                lRetn := lAtrasada;
                                            END IF;
                                    END IF;
                                ELSE
                                    IF lDataProximaExecucao IS NULL THEN
                                        lRetn := lAtrasada;
                                    ELSIF lDataProximaExecucao >= lDataCorrente THEN
                                        lRetn := lEmExecucao;
                                    ELSE
                                        lRetn := lAtrasada;
                                    END IF;
                                END IF;
                          ELSE
                                IF lPeriodicidade = 0 THEN
                                    IF lPercentualDeConclusao < lPercentualDeConclusaoPrevisto THEN
                                        lRetn := lAtrasada;
                                    ELSE
                                        lRetn := lEmExecucao;
                                    END IF;
                                ELSE
                                    IF lDataProximaExecucao IS NULL THEN
                                        lRetn := lAtrasada;
                                    ELSIF lDataProximaExecucao >= lDataCorrente THEN
                                        lRetn := lEmExecucao;
                                    ELSE
                                        lRetn := lAtrasada;
                                    END IF;
                                END IF;
                          END IF;
                    ELSE
                         IF lFinalPrevisto IS NOT NULL THEN
                             lRetn := lAtrasada;
                         END IF;
                    END IF;
              END IF;
          ELSE
              IF lFinalPrevisto IS NOT NULL THEN
                  IF lFinalPrevisto >= lDataCorrente THEN
                      lRetn := lPlanejada;
                  ELSE
                      lRetn := lAtrasada;
                  END IF;
              ELSE
                  lRetn := lSemStatus;
              END IF;
          END IF;
    END IF;

    RETURN lRetn;

END;
/

create or replace FUNCTION DefinirStatusDaAcao30(pIdePlaAco IN NUMBER, pDataCorrente IN DATE) RETURN INT
IS

/* Fun��o      : DefinirStatusDaAcao30
 Prop�sito   : Definir o Status de uma determinada a��o
 Par�metros  : pInicioPrevisto - Data de in�cio previsto
               pFimPrevisto - Data de fim previsto
               pInicioRealizado - Data de in�cio realizado
               pFimRealizado - Data de fim realizado
               pDataCorrente - Data atual do sistema
 Retorno     : 1 = PlanejadaAtrasada
                2 = PlanejadaNoPrazo
                3 = EmAndamentoAtrasada
                4 = EmAndamentoNoPrazo
                5 = ConcluidaAtrasada
                6 = ConcluidaNoPrazo
 Cria��o     : 09/08/2005 - mar
 �ltima Alt. : 18/11/2014 - max */

  lRetn                   INT := 0;
  
  lPlanejadaAtrasada       INT := 1;
  lPlanejadaNoPrazo        INT := 2;
  lEmAndamentoAtrasada     INT := 3;
  lEmAndamentoNoPrazo      INT := 4;
  lConcluidaAtrasada       INT := 5;
  lConcluidaNoPrazo        INT := 6;
  lDurHra				   INT;
  
  lInicioPrevisto         DATE; 
  lFimPrevisto          DATE;
  lInicioRealizado        DATE; 
  lFimRealizado           DATE;
  lDataCorrente           DATE;
  lPeriodicidade          INT;
  lDataProximaExecucao    DATE;
  lPercentualDeConclusaoPrevisto FLOAT := 0;
  lPercentualDeConclusao    FLOAT;
  lPrazoParaExecucao    INT;

BEGIN
  lDataCorrente := TO_DATE(TO_CHAR(pDataCorrente, 'DD-MM-YYYY'), 'DD-MM-YYYY');

  SELECT tPacTar.IniPre,
           tPacTar.FimPre,
           tPacTar.IniRea,
           tPacTar.FimRea,
           TPACTAR.FREREC,
           TPACTAR.PRXEXCREC,
           CASE WHEN tPacTar.INIPRE IS NOT NULL AND tPacTar.FIMPRE IS NOT NULL THEN tPacTar.FimPre - tPacTar.IniPre + 1 ELSE 0 END,
           TPACTAR.PERCON,
		   TPACTAR.DURHRA
           INTO lInicioPrevisto, lFimPrevisto, lInicioRealizado, lFimRealizado, lPeriodicidade, lDataProximaExecucao, lPrazoParaExecucao, lPercentualDeConclusao, lDurHra
    FROM tPacTar
   WHERE tPacTar.IdePacTar = pIdePlaAco;

  IF NOT lFimPrevisto IS NULL THEN
      lFimPrevisto := lFimPrevisto + 1 - 0.00001;
  END IF;
    
  IF lFimRealizado IS NOT NULL THEN
    IF lFimRealizado <= lFimPrevisto THEN
      lRetn := lConcluidaNoPrazo;
    ELSE
      lRetn := lConcluidaAtrasada;
    END IF;
  ELSE 
    IF lInicioRealizado IS NOT NULL THEN
	
		lPercentualDeConclusaoPrevisto := PercentualPrevConclusaoTarefa(lInicioPrevisto, lFimPrevisto, lDurHra, lPeriodicidade, pDataCorrente);
		
		IF lPercentualDeConclusaoPrevisto > lPercentualDeConclusao THEN
			lRetn := lEmAndamentoAtrasada;
		ELSE
			lRetn := lEmAndamentoNoPrazo;
		END IF;
		
    ELSE 
        IF lInicioPrevisto < lDataCorrente THEN
            lRetn := lPlanejadaAtrasada;
        ELSE
            lRetn := lPlanejadaNoPrazo;
        END IF;
    END IF;
  END IF;
  RETURN lRetn;

END;
/

create or replace function FNSPLIT
(
    p_list varchar2,
    p_del varchar2 := ','

) return split_obj pipelined
is

/* Fun��o       : FNSPLIT
   Prop�sito    : Retorna uma string de registros, separados por determinado separador, em formato de tabela
   Par�metros   : p_list - Texto a ser separado
                  p_del - Separador
   Cria��o      : Eduardo C�sar
   �ltima Alt.  : Leoanrdo Lage */

    l_idx    pls_integer;
    l_list    varchar2(8000) := p_list;

    l_value    varchar2(8000);
    
    l_obj split_tbl := split_tbl(NULL, NULL);
    
    l_cont number := 0;
begin
    loop
        l_idx := instr(l_list,p_del);
        if l_idx > 0 then
            l_cont := l_cont + 1;
            l_obj.item := substr(l_list,1,l_idx-1);
            l_obj.ord := l_cont;
            pipe row(l_obj);
            l_list := substr(l_list,l_idx+length(p_del));
        else
            l_cont := l_cont + 1;
            l_obj.item := l_list;
            l_obj.ord := l_cont;
            pipe row(l_obj);
            exit;
        end if;
    end loop;
    return;
end;
/
CREATE OR REPLACE FUNCTION FNSPLITONPOSITION
  (sInputList VARCHAR, sDelimiter CHAR, pPosition INTEGER)
  RETURN VARCHAR IS    
    sItem VARCHAR(8000);
    pCount INTEGER;
    sInputListTmp VARCHAR(8000);
BEGIN 
    pCount := 1;
    sInputListTmp := sInputList;
       
    WHILE INSTR(sInputListTmp, sDelimiter) <> 0
    LOOP
        sItem := RTRIM(LTRIM(SUBSTR(sInputListTmp,1,INSTR(sInputListTmp, sDelimiter)-1)));
        sInputListTmp := RTRIM(LTRIM(SUBSTR(sInputListTmp,INSTR(sInputListTmp, sDelimiter)+LENGTH(sDelimiter),LENGTH(sInputListTmp))));
        
        IF pCount = pPosition THEN
            RETURN sItem;
        END IF;
        
        pCount := pCount + 1;        
    END LOOP;
    
    IF sInputListTmp IS NOT NULL THEN
        RETURN sInputListTmp;
    END IF;
    
    RETURN '0';
    
EXCEPTION
   WHEN others THEN
       RETURN '0';
END;
/


CREATE OR REPLACE 
FUNCTION gettableide(sTableName IN VARCHAR2, Incremento IN NUMBER, pPkIdentificator IN VARCHAR2) RETURN FLOAT

/* Fun��o     : GetTableIde
   Prop�sito  : Retorna o identificador que deve ser usado em uma nova linha que est� sendo inserida em uma tabela
   Par�metros : sTableName-Nome da tabela a ter seu Ide gerado
   Cria��o    : 14/06/2003 - mar
   �ltima Alt.: 14/06/2003 - mar */

IS
   CURSOR CursorIds(cpTableName VARCHAR2) IS
   SELECT ROWID,
         NewIde
      FROM tIDs
   WHERE UPPER(TblNme) = UPPER(cpTableName);

   IdsDataRow    CursorIds%ROWTYPE;
   NewIde        FLOAT := -1;
   ErrorCode     NUMBER;
   ErrorMessage  VARCHAR2(400);
   lIdeDtaMngErr FLOAT;
BEGIN
   LOOP
   EXIT WHEN NewIde >= 0;
      BEGIN
            OPEN CursorIds(sTableName);       /* Abre o cursor e o seta para o DataRow */
            FETCH CursorIds INTO IdsDataRow;

            /* Se encontrar a tabela monta o Ide da tabela e incrementa o contador, sen�o cria o 1o. Ide */
            IF CursorIds%FOUND THEN
               NewIde := TO_NUMBER(pPkIdentificator||'0000000000') + IdsDataRow.NewIde;

               UPDATE tIds
                  SET NewIde = IdsDataRow.NewIde + Incremento
               WHERE ROWID = IdsDataRow.ROWID;
            ELSE
               NewIde := TO_NUMBER(pPkIdentificator||'0000000001');

               INSERT INTO tIds (TblNme, NewIde)
                     VALUES (sTableName, 2);
            END IF;

            CLOSE CursorIds;

            COMMIT;
      EXCEPTION WHEN OTHERS THEN
            NewIde := -1;
      END;
   END LOOP;

   RETURN NewIde;

END GetTableIde;
/


CREATE OR REPLACE
FUNCTION LONG_TO_CHAR(pRowId rowid,
                      pTableName varchar2,
                      pColumn varchar2)
RETURN varchar2 AS

lRetn varchar2(32767);
lSql varchar2(2000);
--
begin
  lSql := 'select ' || pColumn || ' from ' || pTableName || ' where rowid = '|| chr(39) || pRowId || chr(39);
  dbms_output.put_line (lSql);
  execute immediate lSql into lRetn;

  lRetn := substr(lRetn, 1, 20000);
  RETURN lRetn;
END;
/


CREATE OR REPLACE 
FUNCTION NON_ANSI_ADD_MONTHS(vDate DATE, vMonths INTEGER) 
RETURN DATE AS
  newDate DATE;
BEGIN
  newDate := add_months(vDate, vMonths);
  IF to_char(vDate, 'DD') < to_char(newDate, 'DD') THEN
    newDate := vDate + numtoyminterval(vMonths, 'month');
  END IF;
  RETURN newDate;
END;
/



CREATE OR REPLACE FUNCTION PercentualConclusaoTarefas(pTableName IN VARCHAR, pIdeTable IN NUMBER, pData IN DATE, pPrevisto IN NUMBER) RETURN FLOAT
AS

/* FUNCAO      : PercentualConclusaoDeTarefa         
   PROPOSITO   : RETORNA O PERCENTUAL PREVISTO DE CONCLUSAO DE UMA TAREFA
   PARAMETROS  : pTableName: Tabela principal para busca das tarefas  
				 pIdeTable:  Id do registro da tabela principal para busca das tarefas  
				 pData: 	 Data de corte para retorno das tarefas
				 pPrevisto:	 Bit se deve retornar percentual previsto ou realizado das tarefas
   Criacao      : 02/10/2016 - erac
   �ltima Alt.  : 08/03/2017 - erac*/

    lPer            FLOAT;
    lHorasTotais    FLOAT;
    lHorasAteAgora  FLOAT;
    lCountTarefas   FLOAT;
BEGIN
    IF UPPER(pTableName) = 'TPLAACO' THEN
    IF pPrevisto <> 0 THEN            
      SELECT SUM(RetornarHorasAteAgora(INIPRE, FIMPRE, DURHRA, FREREC, pData)) INTO lHorasAteAgora
        FROM TPLAACO
        INNER JOIN TPACTAR ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
        WHERE TPLAACO.IDEPLAACO = pIdeTable
        AND TPACTAR.DEL = 0
        AND TPACTAR.INIPRE < pData
        AND (TPACTAR.IDEPACTARSUP IS NOT NULL OR TPACTAR.TEMSUB = 0);
        
      SELECT SUM(CASE WHEN TPACTAR.DURHRA = 0 OR TPACTAR.DURHRA IS NULL THEN 8 ELSE ABS(TPACTAR.DURHRA) END) INTO lHorasTotais
        FROM TPLAACO
        INNER JOIN TPACTAR ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
        WHERE TPLAACO.IDEPLAACO = pIdeTable
        AND TPACTAR.DEL = 0					
        AND (TPACTAR.IDEPACTARSUP IS NOT NULL OR TPACTAR.TEMSUB = 0);
          
      lPer := lHorasAteAgora * 100 / lHorasTotais;
        
    ELSE
      
      SELECT SUM( (CASE WHEN FREREC = 0 THEN PERCOMEXC ELSE PERCON END) / 100 * CASE WHEN DURHRA = 0 OR DURHRA IS NULL THEN 8 ELSE ABS(DURHRA) END) into lHorasAteAgora
        FROM (SELECT MAX(EXC.PERCON) PERCOMEXC, TPACTAR.PERCON , TPACTAR.DURHRA, TPACTAR.FREREC
                FROM TPLAACO
               INNER JOIN TPACTAR ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
               INNER JOIN TPACTAREXCRECLOG EXC ON TPACTAR.IDEPACTAR = EXC.IDEPACTAR
               WHERE TPLAACO.IDEPLAACO = pIdeTable
                 AND TPACTAR.DEL = 0
                 AND TPACTAR.PERCON > 0 -- TAREFAS COM EXECUCOES ANTES MESMO DO INICIO PREVISTO
                 AND ((((TO_DATE(TPACTAR.FIMPRE) <= pData AND TO_DATE(TPACTAR.INIREA) <= pData) OR TO_DATE(TPACTAR.INIREA) <= pData) AND TPACTAR.FIMREA IS NULL) OR ((TO_DATE(TPACTAR.FIMPRE) <= pData AND TPACTAR.FIMREA IS NOT NULL) OR (TO_DATE(TPACTAR.FIMREA) <= pData)))
                 AND TO_DATE(EXC.ULTEXCREC) <= pData
                 AND (TPACTAR.IDEPACTARSUP IS NOT  NULL OR TPACTAR.TEMSUB = 0)
               GROUP BY TPACTAR.DEL,TPACTAR.DURHRA, TPACTAR.FREREC,TPACTAR.PERCON, tpactar.IDEPACTAR) X;
    
      SELECT SUM(CASE WHEN TPACTAR.DURHRA = 0 OR TPACTAR.DURHRA IS NULL THEN 8 ELSE ABS(TPACTAR.DURHRA) END) INTO lHorasTotais
        FROM TPLAACO
        INNER JOIN TPACTAR ON TPLAACO.IDEPLAACO = TPACTAR.IDEPLAACO
        WHERE TPLAACO.IDEPLAACO = pIdeTable
        AND TPACTAR.DEL = 0					
        AND (TPACTAR.IDEPACTARSUP IS NOT NULL OR TPACTAR.TEMSUB = 0);
        
      lPer := lHorasAteAgora * 100 / lHorasTotais;
    END IF;
  ELSE
      SELECT 0 INTO lPer FROM DUAL;
    END IF;
    
    IF lPer > 100 THEN
  lPer := 100;
END IF;
    
    RETURN TRUNC(lPer, 2);

END;
/


CREATE OR REPLACE FUNCTION PercentualPrevConclusaoTarefa (pInicioPrevisto DATE, pFimPrevisto DATE, pDurHra INT, pFreRec NUMBER, pData DATE)
RETURN  FLOAT IS

/* FUNCAO      : PercentualPrevistoConclusaoDeTarefa         
   PROPOSITO   : RETORNA O PERCENTUAL PREVISTO DE CONCLUSAO DE UMA TAREFA
   PARAMETROS  : pInicioPrevisto:	Inicio Previsto da tarefa
                 pFimPrevisto:  	Fim PRevisto da tarefa
                 pDurHra:       	Dura��o em horas da tarefa
				 pFreRec:			Periodicidade da tarefa
                 pData:				DATA DE CORTE DA AN�LISE, OU SEJA, ANALISAR A��ES AT� A DATA X                 
   Criacao      : 02/09/2015 - Flavio
   �ltima Alt.  : 03/09/2015 - erac */

    lPer			FLOAT;
	lHorasTotais	FLOAT;
	lHorasAteAgora	FLOAT;
  lData_Referencia DATE;
  lQtdeExecucoes INT;
	
BEGIN

	IF pInicioPrevisto > pData THEN 
		RETURN 0;
	END IF;

  IF pFreRec = 0 THEN
    lHorasAteAgora :=	CASE WHEN pInicioPrevisto < pData  THEN (pData - pInicioPrevisto) * 8 ELSE 0 END;
  ELSE
    lQtdeExecucoes := 0;
    lData_Referencia := pInicioPrevisto;
    LOOP
       EXIT WHEN lData_Referencia >= TO_DATE(pData);
       
       lData_Referencia := CASE pFreRec WHEN 1 /* Di�rio */      THEN TO_DATE(lData_Referencia) + 1 
                                        WHEN 2 /* Semanal */     THEN TO_DATE(lData_Referencia) + 7 
                                        WHEN 3 /* Quinzenal */   THEN TO_DATE(lData_Referencia) + 15 
                                        WHEN 4 /* Mensal */      THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 1) 
                                        WHEN 5 /* Bimestral */   THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 2) 
                                        WHEN 6 /* Trimestral */  THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 3) 
                                        WHEN 7 /* Quadrimestral*/THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 4) 
                                        WHEN 8 /* Semestral */   THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 6) 
                                        WHEN 9 /* Anual */       THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 12) 
                                        WHEN 10 /* Bienal */     THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 24) 
                                        WHEN 11 /* Trienal */    THEN NON_ANSI_ADD_MONTHS(lData_Referencia, 36) 
                            END;
                            
      lQtdeExecucoes := lQtdeExecucoes + 1;                        
      
    END LOOP;
    lHorasAteAgora := lQtdeExecucoes * 8;
  END IF;
						
	lHorasTotais := CASE WHEN pDurHra = 0 OR pDurHra IS NULL THEN 8 ELSE ABS(pDurHra) END;

	lPer := abs(lHorasAteAgora) / lHorasTotais * 100;

	IF lPer > 100 then
		lPer := 100;
	END IF;

    RETURN round(lPer, 2);

END;
/


CREATE OR REPLACE
FUNCTION RETORNARARVORE(pTableName VARCHAR2, pIdeTable NUMBER, pSeparador VARCHAR2 := ' - ') RETURN  VARCHAR2 IS

/* Fun��o     : RETORNARARVORE
   Prop�sito  : Retorna todo o caminho referente a uma �rvore (utilizado para tabelas com auto relacionamento)
   Par�metros : pTableName-Nome da Tabela
                pIdeTable-Ide do registro que ter� sua �rvore montada
   Cria��o    : 04/12/2005 - mar
   �ltima Alt.: 18/04/2016 - Leonardo Lage */

        CURSOR CursorProcessos(cIdeTable NUMBER) IS
        SELECT VPCS.NME
        FROM (SELECT TPCS.NME
                FROM TPCS
              CONNECT BY PRIOR TPCS.IDESPR = TPCS.IDEPCS
              START WITH TPCS.IDEPCS = cIdeTable) VPCS;

        CURSOR CursorProcessosIde(cIdeTable NUMBER) IS
        SELECT TO_CHAR(VPCS.IDEPCS)
        FROM (SELECT TPCS.IDEPCS
                FROM TPCS
              CONNECT BY PRIOR TPCS.IDESPR = TPCS.IDEPCS
              START WITH TPCS.IDEPCS = cIdeTable) VPCS;

        CURSOR CursorUnidadesGerenciais(cpIdeTable NUMBER) IS
        SELECT SIG
          FROM TUNI
		  CONNECT BY PRIOR TUNI.IdeSpr = TUNI.IdeUni
               START WITH TUNI.IdeUni = cpIdeTable;

        CURSOR CursorUnidadesGerenciaisIde(cpIdeTable NUMBER) IS
        SELECT TO_CHAR(IDEUNI)
          FROM TUNI
       CONNECT BY PRIOR TUNI.IdeSpr = TUNI.IdeUni
         START WITH TUNI.IdeUni = cpIdeTable;

        CURSOR CursorPastasPublicas(cIdeTable NUMBER) IS
        SELECT VPST.NME
        FROM (SELECT TPSTPUB.NME
                FROM TPSTPUB
              CONNECT BY PRIOR TPSTPUB.IDESPR = TPSTPUB.IDEPSTPUB
              START WITH TPSTPUB.IDEPSTPUB = cIdeTable) VPST;

        CURSOR CursorPastasPublicasIde(cIdeTable NUMBER) IS
        SELECT TO_CHAR(VPST.IDEPSTPUB)
        FROM (SELECT TPSTPUB.IDEPSTPUB
                FROM TPSTPUB
              CONNECT BY PRIOR TPSTPUB.IDESPR = TPSTPUB.IDEPSTPUB
              START WITH TPSTPUB.IDEPSTPUB = cIdeTable) VPST;

        lTmpNme           VARCHAR2(100) := '';
        lretn             VARCHAR2(500);
        lPrimeiro         DECIMAL(1) := 1;
BEGIN
    IF UPPER(pTableName) = 'TPCS' THEN
        OPEN CursorProcessos(pIdeTable);
        LOOP
            FETCH CursorProcessos INTO lTmpNme;
            EXIT WHEN CursorProcessos%NOTFOUND;

            IF lPrimeiro = 1 THEN
                lretn := TRIM(lTmpNme);
                lPrimeiro := 0;
            ELSE
                lretn := TRIM(lTmpNme) || pSeparador || lretn;
            END IF;
        END LOOP;

        CLOSE CursorProcessos;
    ELSIF UPPER(pTableName) = 'TPCS_IDEPCS' THEN
        OPEN CursorProcessosIde(pIdeTable);
        LOOP
            FETCH CursorProcessosIde INTO lTmpNme;
            EXIT WHEN CursorProcessosIde%NOTFOUND;

            IF lPrimeiro = 1 THEN
                lretn := TRIM(lTmpNme);
                lPrimeiro := 0;
            ELSE
                lretn := TRIM(lTmpNme) || pSeparador || lretn;
            END IF;
        END LOOP;

        CLOSE CursorProcessosIde;
    ELSIF UPPER(pTableName) = 'TUNI' THEN
        OPEN CursorUnidadesGerenciais(pIdeTable);
        LOOP
            FETCH CursorUnidadesGerenciais INTO lTmpNme;
            EXIT WHEN CursorUnidadesGerenciais%NOTFOUND;

            IF lPrimeiro = 1 THEN
                lretn := TRIM(lTmpNme);
                lPrimeiro := 0;
            ELSE
                lretn := TRIM(lTmpNme) || pSeparador || lretn;
            END IF;
        END LOOP;

        CLOSE CursorUnidadesGerenciais;
    ELSIF UPPER(pTableName) = 'TUNI_IDEUNI' THEN
        OPEN CursorUnidadesGerenciaisIde(pIdeTable);
        LOOP
            FETCH CursorUnidadesGerenciaisIde INTO lTmpNme;
            EXIT WHEN CursorUnidadesGerenciaisIde%NOTFOUND;

            IF lPrimeiro = 1 THEN
                lretn := TRIM(lTmpNme);
                lPrimeiro := 0;
            ELSE
                lretn := TRIM(lTmpNme) || pSeparador || lretn;
            END IF;
        END LOOP;

        CLOSE CursorUnidadesGerenciaisIde;
    ELSIF UPPER(pTableName) = 'TPSTPUB' THEN
        OPEN CursorPastasPublicas(pIdeTable);
        LOOP
            FETCH CursorPastasPublicas INTO lTmpNme;
            EXIT WHEN CursorPastasPublicas%NOTFOUND;

            IF lPrimeiro = 1 THEN
                lretn := TRIM(lTmpNme);
                lPrimeiro := 0;
            ELSE
                lretn := TRIM(lTmpNme) || pSeparador || lretn;
            END IF;
        END LOOP;
        
        CLOSE CursorPastasPublicas;
    ELSIF UPPER(pTableName) = 'TPSTPUB_IDEPSTPUB' THEN
        OPEN CursorPastasPublicasIde(pIdeTable);
        LOOP
            FETCH CursorPastasPublicasIde INTO lTmpNme;
            EXIT WHEN CursorPastasPublicasIde%NOTFOUND;

            IF lPrimeiro = 1 THEN
                lretn := TRIM(lTmpNme);
                lPrimeiro := 0;
            ELSE
                lretn := TRIM(lTmpNme) || pSeparador || lretn;
            END IF;
        END LOOP;

        CLOSE CursorPastasPublicasIde;
    END IF;

    RETURN lretn;
END;
/


CREATE OR REPLACE 
FUNCTION RetornarArvoreTabela(pTableName VARCHAR2, pIdeTable NUMBER) RETURN  OBJECT_RETORNARARVORETAB_TABLE AS

/* Fun��o       : RetornarArvoreTabela
   Prop�sito    : Retorna todos os n�veis superiores de um registro, retornando um campo ORD onde quanto menor o valor, maior o nivel (utilizado para tabelas com auto relacionamento)
   Par�metros   : pTableName-Nome da Tabela         
                  pIdeTable-Ide do registro que ter� sua �rvore montada         
   Cria��o      : 14/07/2009 - Eduardo C�sar
   �ltima Alt.  : 18/04/2016 - Leonardo Lage*/

        CURSOR CursorProcessos(cIdeTable NUMBER) IS
        SELECT VPCS.IDEPCS,
               VPCS.NME,
               VPCS.IDESPR
        FROM (SELECT TPCS.IDEPCS,
                     TPCS.NME,
                     TPCS.IDESPR
                FROM TPCS
              CONNECT BY PRIOR TPCS.IDESPR = TPCS.IDEPCS
              START WITH TPCS.IDEPCS = cIdeTable) VPCS;

        CURSOR CursorUnidadesGerenciais(cpIdeTable NUMBER) IS
        SELECT VUNI.IDEUNI,
               VUNI.SIG,
               VUNI.IDESPR
          FROM (SELECT tUni.IDEUNI,
                       tUni.SIG,
                       tUni.IDESPR
                  FROM TUNI
               CONNECT BY PRIOR tUni.IdeSpr = tUni.IdeUni
                 START WITH tUni.IdeUni = cpIdeTable) VUNI;

        CURSOR CursorUsuarios(cIdeTable NUMBER) IS
        SELECT VUSU.IDEUSU,
               VUSU.NME,
               VUSU.IDEUSUSUP
        FROM (SELECT TUSU.IDEUSU,
                     TUSU.NME,
                     TUSU.IDEUSUSUP
                FROM TUSU
                WHERE IDEUSU <> cIdeTable
                    AND TUSU.STT <> 0
              CONNECT BY PRIOR TUSU.IDEUSUSUP = TUSU.IDEUSU
              START WITH TUSU.IDEUSU = cIdeTable) VUSU;

        CURSOR CursorNormaRequisito(cIdeTable NUMBER) IS
        SELECT VNORREQ.IDENORREQ,
               VNORREQ.IDENORREQSUP,
               VNORREQ.NUMREQ,
               VNORREQ.DES
        FROM (SELECT TNORREQ.NUMREQ,
                     TNORREQ.IDENORREQ,
                     TNORREQ.IDENORREQSUP,
                     TNORREQ.DES
                FROM TNORREQ
                WHERE TNORREQ.IDENORREQ <> cIdeTable
              CONNECT BY PRIOR TNORREQ.IDENORREQSUP = TNORREQ.IDENORREQ
              START WITH TNORREQ.IDENORREQ = cIdeTable) VNORREQ;
			  
        CURSOR CursorProjetosLicenciamento(cIdeTable NUMBER) IS
        SELECT VEPRLICAMB.NME,
			   VEPRLICAMB.IDEEPRLICAMB,
			   VEPRLICAMB.IDEEPRLICAMBREL
        FROM (SELECT TEPRLICAMB.NME,
                     TEPRLICAMB.IDEEPRLICAMB,
                     TEPRLICAMB.IDEEPRLICAMBREL
				FROM TEPRLICAMB
             CONNECT BY PRIOR TEPRLICAMB.IDEEPRLICAMBREL = TEPRLICAMB.IDEEPRLICAMB
               START WITH TEPRLICAMB.IDEEPRLICAMB = cIdeTable) VEPRLICAMB;

    lOrd INTEGER;
    lObject_RetornarArvoreTab_Tbl OBJECT_RETORNARARVORETAB_TABLE := OBJECT_RETORNARARVORETAB_TABLE();
    
    lProcessos CursorProcessos%ROWTYPE;
    lUnidadesGerenciais CursorUnidadesGerenciais%ROWTYPE;
    lUsuarios CursorUsuarios%ROWTYPE;
	lNormaRequisito CursorNormaRequisito%ROWTYPE;
	lProjetoLicenciamento CursorProjetosLicenciamento%ROWTYPE;

BEGIN

    lOrd := 0;
    IF UPPER(pTableName) = 'TPCS' THEN
    
        

        OPEN CursorProcessos(pIdeTable);
        LOOP
            FETCH CursorProcessos INTO lProcessos;
            EXIT WHEN CursorProcessos%NOTFOUND;            
            lObject_RetornarArvoreTab_Tbl.EXTEND();
            
            lObject_RetornarArvoreTab_Tbl(lObject_RetornarArvoreTab_Tbl.LAST) := OBJECT_RETORNARARVORETABELA(lProcessos.IdePcs, lProcessos.Nme, lProcessos.IdeSpr, lOrd);
            lOrd := lOrd + 1;

        END LOOP;
        CLOSE CursorProcessos;
        
        
    ELSIF UPPER(pTableName) = 'TUNI' THEN  
        
    
        OPEN CursorUnidadesGerenciais(pIdeTable);
        LOOP
            FETCH CursorUnidadesGerenciais INTO lUnidadesGerenciais;
            EXIT WHEN CursorUnidadesGerenciais%NOTFOUND;

            lObject_RetornarArvoreTab_Tbl.EXTEND();
            
            lObject_RetornarArvoreTab_Tbl(lObject_RetornarArvoreTab_Tbl.LAST) := OBJECT_RETORNARARVORETABELA(lUnidadesGerenciais.IdeUni, lUnidadesGerenciais.Sig, lUnidadesGerenciais.IdeSpr, lOrd);
            lOrd := lOrd + 1;
            
        END LOOP;
        CLOSE CursorUnidadesGerenciais;

    ELSIF UPPER(pTableName) = 'TUSU' THEN
    
        OPEN CursorUsuarios(pIdeTable);
        LOOP
            FETCH CursorUsuarios INTO lUsuarios;
            EXIT WHEN CursorUsuarios%NOTFOUND;            
            lObject_RetornarArvoreTab_Tbl.EXTEND();
            
            lObject_RetornarArvoreTab_Tbl(lObject_RetornarArvoreTab_Tbl.LAST) := OBJECT_RETORNARARVORETABELA(lUsuarios.IdeUsu, lUsuarios.Nme, lUsuarios.IdeUsuSup, lOrd);
            lOrd := lOrd + 1;

        END LOOP;
        CLOSE CursorUsuarios;

    ELSIF UPPER(pTableName) = 'TNORREQ' THEN
    
        OPEN CursorNormaRequisito(pIdeTable);
        LOOP
            FETCH CursorNormaRequisito INTO lNormaRequisito;
            EXIT WHEN CursorNormaRequisito%NOTFOUND;            
            lObject_RetornarArvoreTab_Tbl.EXTEND();
            
            lObject_RetornarArvoreTab_Tbl(lObject_RetornarArvoreTab_Tbl.LAST) := OBJECT_RETORNARARVORETABELA(lNormaRequisito.IdeNorReq, lNormaRequisito.DES, lNormaRequisito.IdeNorReqSup, lOrd);
            lOrd := lOrd + 1;

        END LOOP;
        CLOSE CursorNormaRequisito;

    ELSIF UPPER(pTableName) = 'TEPRLICAMB' THEN
    
        OPEN CursorProjetosLicenciamento(pIdeTable);
        LOOP
            FETCH CursorProjetosLicenciamento INTO lProjetoLicenciamento;
            EXIT WHEN CursorProjetosLicenciamento%NOTFOUND;            
            lObject_RetornarArvoreTab_Tbl.EXTEND();
            
            lObject_RetornarArvoreTab_Tbl(lObject_RetornarArvoreTab_Tbl.LAST) := OBJECT_RETORNARARVORETABELA(lProjetoLicenciamento.IDEEPRLICAMB, lProjetoLicenciamento.NME, lProjetoLicenciamento.IDEEPRLICAMBREL, lOrd);
            lOrd := lOrd + 1;

        END LOOP;
        CLOSE CursorProjetosLicenciamento;

    END IF;

    RETURN lObject_RetornarArvoreTab_Tbl;
END;
/


create or replace 
FUNCTION RETORNARESTATISTICASCOND(pData DATE, pIdeEmp NUMBER, pIdeEstPrv NUMBER, pIdeUni NUMBER, pIdeTipLicRegAmb NUMBER, pIdeTipLicAmb NUMBER, pAmpMod INT, pImp INT, pSub INT)
  RETURN Object_EstatisticaLA_Table
AS

/* Função     : RetornarEstatisticasCond    
   Propósito  : Retorna uma estatística anual das condicionantes
   Parâmetros : pData               - Data que corresponte ao ano a ser pesquisado
              : pIdeEmp             - Identificador da Empresa
              : pIdeLegAmb          - Identificador da Legislação Ambiental
              : pIdeUni             - Identificador da Unidade Gerencial
              : pIdeTipLicRegAmb    - Identificador do Tipo de Empreendimento
              : pIdeTipLicAmb       - Identificador do Tipo da Licença
              : pAmpMod             - Indicador de Ampliação do Empreendimento
              : pImp                   - Indicador de Empreendimento Importante
              : pSub             - Indicador de Incluir Subordinadas
   Criação    : 14/06/2010 - Eduardo César
   Última Alt.: 18/04/2016 - Leonardo Lage*/

/*Obtem o ano da data passada por parâmetro*/
lAno VARCHAR2(4) := TO_CHAR(pData, 'yyyy');

lDataCorte DATE := TO_DATE('01-01-'||lAno, 'dd-mm-yyyy');
lAtendido INTEGER := 0;
lEmAtendimento INTEGER := 0;
lNaoAtendido INTEGER := 0;

CURSOR CursorCondicionantes(cpData DATE, cpIdeEmp NUMBER, cpIdeLegAmb NUMBER, cpIdeUni NUMBER, cpIdeTipLicRegAmb NUMBER, cpIdeTipLicAmb NUMBER, cpAmpMod INT, cpImp INT, cpSub INT) IS
SELECT tPacTar.FreRec,
       tPacTar.AcaRec,
       tPacTar.IniPre,
       tPacTar.IniRea,
       tPacTar.FimPre,
       tPacTar.FimRea,
       vPacTarExcRecLog.UltExcRec,
       vPacTarExcRecLog.DatPre
  FROM tEprLicAmb
 INNER JOIN tTipLicRegAmb on tTipLicRegAmb.IdeTipLicRegAmb = tEprLicAmb.IdeTipLicRegAmb 
 INNER JOIN tLicAmb ON tLicAmb.IdeEprLicAmb = tEprLicAmb.IdeEprLicAmb
 INNER JOIN tTipLicAmb ON tTipLicAmb.IdeTipLicAmb = tLicAmb.IdeTipLicAmb
 INNER JOIN tPacTar ON tPacTar.IdePlaAco = tLicAmb.IdePlaAcoCnd
 INNER JOIN tUni ON tUni.IdeUni = tEprLicAmb.IdeUni
  LEFT JOIN (SELECT tPacTarExcRecLog.IdePacTar, tPacTarExcRecLog.UltExcRec, tPacTarExcRecLog.DatPre
               FROM (SELECT IdePacTar, MAX(DatPre) DatPre, MAX(UltExcRec) UltExcRec
                       FROM tPacTarExcRecLog
                      WHERE tPacTarExcRecLog.DatPre < cpData
                      GROUP BY  IdePacTar) vAte
              INNER JOIN tPacTarExcRecLog ON vAte.IdePacTar = tPacTarExcRecLog.IdePacTar AND vAte.DatPre = tPacTarExcRecLog.DatPre AND vAte.UltExcRec = tPacTarExcRecLog.UltExcRec) vPacTarExcRecLog ON vPacTarExcRecLog.IdePacTar = tPacTar.IdePacTar
/* INNER JOIN (SELECT tWkfExe.IdeObj, MAX(tWkfExe.DatIni) Dat
               FROM tWkfExe
              WHERE tWkfExe.TipObj = 'EmpreendimentoLicenciamentoAmbiental'
                AND tWkfExe.DatIni <= cpData
              GROUP BY tWkfExe.IdeObj) vWkf ON vWkf.IdeObj = tEprLicAmb.IdeEprLicAmb
 INNER JOIN tWkfExe ON tWkfExe.IdeObj = vWkf.IdeObj AND tWkfExe.DatIni = vWkf.Dat AND tWkfExe.TipObj = 'EmpreendimentoLicenciamentoAmbiental'
 INNER JOIN tWkfAtv ON tWkfAtv.IdeWkfAtv = tWkfExe.IdeWkfAtv
 INNER JOIN tWkfFas ON tWkfFas.IdeWkfFas = tWkfAtv.IdeWkfFas*/
 WHERE /*tWkfFas.Nme <> 'cancelado'
   AND tWkfFas.Nme <> 'desativado'
   AND EXISTS (SELECT 1
                 FROM tWkfExe
                INNER JOIN tWkfAtv ON tWkfAtv.IdeWkfAtv = tWkfExe.IdeWkfAtv
                INNER JOIN tWkfFas ON tWkfFas.IdeWkfFas = tWkfAtv.IdeWkfFas
                WHERE tWkfExe.TipObj = 'EmpreendimentoLicenciamentoAmbiental'
                  AND tWkfFas.Nme = 'Licenciamento'
                  AND tWkfExe.IdeObj = vWkf.IdeObj)
   AND */(cpIdeLegAmb IS NULL OR tTipLicRegAmb.IdeLegAmb = cpIdeLegAmb)
   AND (cpIdeUni IS NULL OR((cpSub = 0 AND tEprLicAmb.IdeUni = cpIdeUni) OR (cpSub <> 0 AND tEprLicAmb.IdeUni IN (SELECT tUni.IdeUni
																													FROM tUni
																												   WHERE tUni.IdeUniTyp IN (SELECT tUniTyp.IdeUniTyp FROM tUniTyp WHERE tUniTyp.Typ = 1)
																										         CONNECT BY PRIOR tUni.IdeUni = tUni.IdeSpr
																											        START WITH tUni.IdeUni = cpIdeUni)))) 
   
   
   AND (cpAmpMod = 0 OR tEprLicAmb.AmpMod <> 0)
   AND (cpImp = 0 OR tEprLicAmb.Imp <> 0)
   AND (cpIdeTipLicRegAmb IS NULL OR tEprLicAmb.IdeTipLicRegAmb = cpIdeTipLicRegAmb)
   AND (cpIdeTipLicAmb IS NULL OR tTipLicAmb.IdeTipLicAmb = cpIdeTipLicAmb)
   AND tTipLicAmb.IdeEmp = cpIdeEmp
   AND tPacTar.IniPre < cpData
   AND tLicAmb.Stt <> 4 /* Indeferida */ 
   AND tLicAmb.Stt <> 5 /* Cancelada */  
 GROUP BY tPacTar.IdePacTar, tPacTar.FreRec, tPacTar.AcaRec, tPacTar.IniPre, tPacTar.IniRea, tPacTar.FimPre, tPacTar.FimRea, vPacTarExcRecLog.UltExcRec, vPacTarExcRecLog.DatPre;

lCondicionantes CursorCondicionantes%ROWTYPE;

lObject_EstatisticaLA_Table Object_EstatisticaLA_Table := Object_EstatisticaLA_Table();

  
BEGIN
LOOP
EXIT WHEN TO_CHAR(lDataCorte, 'yyyy') > lAno OR lDataCorte > SYSDATE;

    lDataCorte := NON_ANSI_ADD_MONTHS(lDataCorte, 3);
    OPEN CursorCondicionantes(lDataCorte, pIdeEmp, pIdeEstPrv, pIdeUni, pIdeTipLicRegAmb, pIdeTipLicAmb, pAmpMod, pImp, pSub);
    
    LOOP
    
        FETCH CursorCondicionantes INTO lCondicionantes;
        EXIT WHEN CursorCondicionantes%NOTFOUND;
        
        IF lCondicionantes.AcaRec <> 0 THEN
            
            IF lCondicionantes.UltExcRec IS NOT NULL THEN
            
                IF lCondicionantes.FimRea IS NOT NULL THEN                    
                    lAtendido := lAtendido + 1;
                
                ELSIF RetornarProximaDataFrequencia(lCondicionantes.DatPre, lCondicionantes.FreRec) >= lDataCorte OR (RetornarProximaDataFrequencia(lCondicionantes.DatPre, lCondicionantes.FreRec) >= SYSDATE AND lDataCorte > SYSDATE) THEN
                    lEmAtendimento := lEmAtendimento + 1;
                ELSE
                    lNaoAtendido := lNaoAtendido + 1;
                END IF;
            
            ELSIF LCONDICIONANTES.INIREA IS NOT NULL THEN 
                IF RetornarProximaDataFrequencia(lCondicionantes.IniRea, lCondicionantes.FreRec) >= lDataCorte OR (RetornarProximaDataFrequencia(lCondicionantes.IniRea, lCondicionantes.FreRec) >= SYSDATE AND lDataCorte > SYSDATE) THEN
                    lEmAtendimento := lEmAtendimento + 1;
                ELSE
                    lNaoAtendido := lNaoAtendido + 1;
                END IF;
            ELSIF RetornarProximaDataFrequencia(lCondicionantes.IniPre, lCondicionantes.FreRec) >= lDataCorte OR (RetornarProximaDataFrequencia(lCondicionantes.IniPre, lCondicionantes.FreRec) >= SYSDATE AND lDataCorte > SYSDATE) THEN
                lEmAtendimento := lEmAtendimento + 1;
            ELSE
                lNaoAtendido := lNaoAtendido + 1;
            END IF;
            
        ELSE
            IF lCondicionantes.FimRea IS NOT NULL AND lCondicionantes.FimRea <= lDataCorte THEN
                lAtendido := lAtendido + 1;
            ELSE
                IF lCondicionantes.FimRea IS NOT NULL AND lCondicionantes.FimRea <= SYSDATE AND lDataCorte > SYSDATE THEN
                    lAtendido := lAtendido + 1;
                ELSIF lCondicionantes.FimPre IS NOT NULL AND (lCondicionantes.FimPre > lDataCorte OR (lCondicionantes.FimPre > SYSDATE AND lDataCorte > SYSDATE)) THEN
                    lEmAtendimento := lEmAtendimento + 1;
                ELSE
                    lNaoAtendido := lNaoAtendido + 1;
                END IF;
            END IF;
        END IF;
    
    END LOOP;
    
    CLOSE CursorCondicionantes;
    
    if (lAtendido + lEmAtendimento + lNaoAtendido) <> 0 then
        lObject_EstatisticaLA_Table.extend;
        lObject_EstatisticaLA_Table(lObject_EstatisticaLA_Table.Last) := Object_EstatisticaLA(lDataCorte - 1, lAtendido, lEmAtendimento, lNaoAtendido);

        lAtendido := 0; 
        lEmAtendimento := 0; 
        lNaoAtendido := 0;
    end if;
END LOOP;

RETURN lObject_EstatisticaLA_Table;
  
END; 
/


create or replace 
FUNCTION RETORNARESTATISTICASLA(pDataInicial DATE, pDataFinal DATE, pIdeEmp NUMBER, pIdeLegAmb NUMBER, pIdeUni NUMBER, pIdeTipLicRegAmb NUMBER, pIdeTipLicAmb NUMBER, pAmpMod INT, pImp INT, pNmeProj VARCHAR, pNumLicAmb VARCHAR, pNumPcs VARCHAR, pIdeResp NUMBER, pSub INT)
  RETURN Object_EstatisticaLA_Table
AS

/* Função     : RetornarEstatisticasLA
    Propósito  : Retorna uma estatística mensal das licenças no período informado
    Parâmetros : pDataInicial        - Data Inicial do periodo
                  : pDataFinal          - Data final do período
                  : pIdeEmp             - Identificador da Empresa
                  : pIdeLegAmb          - Identificador do Legislação Ambiental
                  : pIdeUni             - Identificador da Unidade Gerencial
                  : pIdeTipLicRegAmb    - Identificador do Tipo de Empreendimento
                  : pIdeTipLicAmb       - Identificador do Tipo da Licença
                  : pAmpMod             - Indicador de Ampliação do Empreendimento
                  : pImp                - Indicador de Empreendimento Importante
						: pSub                  Indicador de Incluir Subordinadas
    Criação    : 14/06/2010 - Eduardo César
    Última Alt.: 24/07/2012 */

lDataCorte DATE;
lDatOco DATE;
lConforme INTEGER := 0;
lPossibilidade INTEGER := 0;
lComprometidos INTEGER := 0;

CURSOR CursorLicencasEmpreendimentos(cpData DATE, cpIdeEmp NUMBER, cpIdeLegAmb NUMBER, cpIdeUni NUMBER, cpIdeTipLicRegAmb NUMBER, cpIdeTipLicAmb NUMBER, cpAmpMod INT, cpImp INT, cpNmeProj VARCHAR, cpNumLicAmb VARCHAR, cpNumPcs VARCHAR, cpIdeResp NUMBER, cpSub INT) IS
SELECT tEprLicAmb.IdeEprLicAmb,
         tEprLicAmb.Nme,
         vUltLicAmb.IdeLicAmb,
         tTipLicAmb.PrzObt,
         tTipLicAmb.PrzObtDoc,
         tTipLicAmb.PrzAleVen,
         (select vLicAmb.Dat
            from (select tRep.IdeLicAmb, tRep.DatRep Dat, tRep.UpdTme
                      from tRep
                     inner join (select tRep.IdeLicAmb, 
                                              MAX(tRep.UpdTme) UpdTme
                                             from tRep
                                            where tRep.UpdTme <= cpData
                                            group by tRep.IdeLicAmb) vRep on tRep.IdeLicAmb = vRep.IdeLicAmb and tRep.UpdTme = vRep.UpdTme
                     where tRep.Tip = 1 
                     union 
                    select tLicAmb.IdeLicAmb, tLicAmb.DatPre Dat, UpdTme
                      from tLicAmb
                     where not exists (select 1 from tRep where tRep.IdeLicAmb = tLicAmb.IdeLicAmb ) 
					   AND tLicAmb.Stt <> 4 /* Indeferida */ 
					   AND tLicAmb.Stt <> 5 /* Cancelada */  ) vlicamb
          where vlicamb.Idelicamb = vUltLicAmb.IdeLicAmb) DatPre, 
         tLicAmb.DatObt,
         (select vLicAmb.Dat
            from (select tRep.IdeLicAmb, tRep.DatRep Dat, tRep.UpdTme
                      from tRep
                     inner join (select tRep.IdeLicAmb, 
                                              MAX(tRep.UpdTme) UpdTme
                                             from tRep
                                            where tRep.UpdTme <= cpData
                                            group by tRep.IdeLicAmb) vRep on tRep.IdeLicAmb = vRep.IdeLicAmb and tRep.UpdTme = vRep.UpdTme
                     where tRep.Tip = 2
                     union 
                    select tLicAmb.IdeLicAmb, tLicAmb.VenFob Dat, UpdTme
                       from tLicAmb
                     where not exists (select 1 from tRep where tRep.IdeLicAmb = tLicAmb.IdeLicAmb ) 
					   AND tLicAmb.Stt <> 4 /* Indeferida */
					   AND tLicAmb.Stt <> 5 /* Cancelada */) vlicamb
          where vlicamb.Idelicamb = vUltLicAmb.IdeLicAmb) VenFob,
         tLicAmb.DatPrt,
         tLicAmb.DatVal,
		 tLicAmb.Stt
  FROM tEprLicAmb
 INNER JOIN (SELECT IdeEprLicAmb, 
                          CASE WHEN IdeLicAmbTipLic IS NULL THEN IdeLicAmbTip ELSE IdeLicAmbTipLic END IdeLicAmb
                    FROM (SELECT Epr.IdeEprLicAmb,
                                     (SELECT IdeLicAmb
                                         FROM (SELECT IdeLicAmb, CASE WHEN (DatObt IS NULL OR DatObt > cpData) THEN DatPre ELSE DatObt END Dat, tLicAmb.IdeEprLicAmb
                                                    FROM tLicAmb
                                                  INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
                                                  WHERE tTipLicAmb.TipLic IS NOT NULL
												    AND tLicAmb.Stt <> 4 /* Indeferida */
												    AND tLicAmb.Stt <> 5 /* Cancelada */
                                                    AND (tLicAmb.DatInd IS NULL OR tLicAmb.DatInd > cpData)
                                                    AND (tLicAmb.DatCan IS NULL OR tLicAmb.DatCan > cpData)
                                                    AND CASE WHEN (DatObt IS NULL OR DatObt > cpData) THEN DatPre ELSE DatObt END <= cpData
                                                  ORDER BY Dat DESC, tLicAmb.VenFob DESC) vLic
                                         WHERE vLic.IdeEprLicAmb = Epr.IdeEprLicAmb
                                            AND ROWNUM = 1) IdeLicAmbTipLic,
                                      (SELECT IdeLicAmb
                                          FROM (SELECT IdeLicAmb, CASE WHEN (DatObt IS NULL OR DatObt > cpData) THEN DatPre ELSE DatObt END Dat, tLicAmb.IdeEprLicAmb
                                                    FROM tLicAmb
                                                  INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
                                                  WHERE tTipLicAmb.TipLic IS NULL
												    AND tLicAmb.Stt <> 4 /* Indeferida */
												    AND tLicAmb.Stt <> 5 /* Cancelada */
                                                    AND (tLicAmb.DatInd IS NULL OR tLicAmb.DatInd > cpData) 
                                                    AND (tLicAmb.DatCan IS NULL OR tLicAmb.DatCan > cpData) 
                                                    AND CASE WHEN (DatObt IS NULL OR DatObt > cpData) THEN DatPre ELSE DatObt END <= cpData
                                                  ORDER BY Dat DESC, tLicAmb.VenFob DESC) vLic
                                         WHERE vLic.IdeEprLicAmb = Epr.IdeEprLicAmb
                                            AND ROWNUM = 1) IdeLicAmbTip       
                             FROM tEprLicAmb epr)) vUltLicAmb ON tEprLicAmb.IdeEprLicAmb = vUltLicAmb.IdeEprLicAmb
 INNER JOIN tLicAmb ON tLicAmb.IdeEprLicAmb = tEprLicAmb.IdeEprLicAmb AND tLicAmb.IdeLicAmb = vUltLicAmb.IdeLicAmb
 INNER JOIN tTipLicAmb ON tTipLicAmb.IdeTipLicAmb = tLicAmb.IdeTipLicAmb
 INNER JOIN tTipLicRegAmb on tTipLicRegAmb.IdeTipLicRegAmb = tEprLicAmb.IdeTipLicRegAmb
 INNER JOIN tUni ON tUni.IdeUni = tEprLicAmb.IdeUni
/* INNER JOIN (SELECT tWkfExe.IdeObj, MAX(tWkfExe.DatIni) Dat
                    FROM tWkfExe
                  WHERE tWkfExe.TipObj = 'EmpreendimentoLicenciamentoAmbiental'
                     AND tWkfExe.DatIni <= cpData
                  GROUP BY tWkfExe.IdeObj) vWkf ON vWkf.IdeObj = tEprLicAmb.IdeEprLicAmb
 INNER JOIN tWkfExe ON tWkfExe.IdeObj = vWkf.IdeObj AND tWkfExe.DatIni = vWkf.Dat AND tWkfExe.TipObj = 'EmpreendimentoLicenciamentoAmbiental'
 INNER JOIN tWkfAtv ON tWkfAtv.IdeWkfAtv = tWkfExe.IdeWkfAtv
 INNER JOIN tWkfFas ON tWkfFas.IdeWkfFas = tWkfAtv.IdeWkfFas*/
 WHERE /*tWkfFas.Nme <> 'Cancelado'
    AND tWkfFas.Nme <> 'Desativado'
    AND EXISTS (SELECT 1
                      FROM tWkfExe
                     INNER JOIN tWkfAtv ON tWkfAtv.IdeWkfAtv = tWkfExe.IdeWkfAtv
                     INNER JOIN tWkfFas ON tWkfFas.IdeWkfFas = tWkfAtv.IdeWkfFas
                     WHERE tWkfExe.TipObj = 'EmpreendimentoLicenciamentoAmbiental'
                        AND tWkfFas.Nme = 'Licenciamento'
                        AND tWkfExe.IdeObj = vWkf.IdeObj)
    AND*/ (cpIdeLegAmb IS NULL OR tTipLicRegAmb.IdeLegAmb = cpIdeLegAmb)
	AND tLicAmb.Stt <> 4 /* Indeferida */
	AND tLicAmb.Stt <> 5 /* Cancelada */
    AND (cpIdeUni IS NULL OR((cpSub = 0 AND tEprLicAmb.IdeUni = cpIdeUni) OR (cpSub <> 0 AND tEprLicAmb.IdeUni IN (SELECT tUni.IdeUni
																													 FROM tUni
																													 WHERE tUni.IdeUniTyp IN (SELECT tUniTyp.IdeUniTyp FROM tUniTyp WHERE tUniTyp.Typ = 1)
																										 CONNECT BY PRIOR tUni.IdeUni = tUni.IdeSpr
																											   START WITH tUni.IdeUni = cpIdeUni))))
    
    AND (cpAmpMod = 0 OR tEprLicAmb.AmpMod <> 0)
    AND (cpImp = 0 OR tEprLicAmb.Imp <> 0)
    AND (cpIdeTipLicRegAmb IS NULL OR tEprLicAmb.IdeTipLicRegAmb = cpIdeTipLicRegAmb)
    AND (cpIdeTipLicAmb IS NULL OR EXISTS (SELECT 1
                                                          FROM tTipLicAmb
                                                         INNER JOIN tLicAmb ON tTipLicAmb.IdeTipLicAmb = tLicAmb.IdeTipLicAmb
                                                         WHERE tLicAmb.IdeEprLicAmb = tEprLicAmb.IdeEprLicAmb
                                                            AND tTipLicAmb.IdeTipLicAmb = cpIdeTipLicAmb))
    AND tTipLicAmb.IdeEmp = cpIdeEmp
    AND (cpNmeProj IS NULL OR tEprLicAmb.Nme LIKE '%' || cpNmeProj || '%')
    AND (cpNumLicAmb IS NULL OR tLicAmb.Num LIKE '%' || cpNumLicAmb || '%')
    AND (cpNumPcs IS NULL OR tLicAmb.NumPcs LIKE '%' || cpNumPcs || '%')
    AND (cpIdeResp IS NULL OR tEprLicAmb.IdeUsuRes = cpIdeResp);


lLicencasEmpreendimentos CursorLicencasEmpreendimentos%ROWTYPE;

lObject_EstatisticaLA_Table Object_EstatisticaLA_Table := Object_EstatisticaLA_Table();

BEGIN

lDatOco := TO_DATE('01-' || TO_CHAR(pDataInicial, 'mm') || '-' || TO_CHAR(pDataInicial, 'yyyy'), 'dd-mm-yyyy');

/* Verifica o status dos empreendimentos em um range de 2 anos anteriores à data passada por pararâmetro */
LOOP
     EXIT WHEN lDatOco > pDataFinal OR lDatOco > SYSDATE;
     
     /* Data de corte igual ao ultimo dia do mês */
     lDataCorte := ADD_MONTHS(lDatOco, 1) - 1;
     
     OPEN CursorLicencasEmpreendimentos(lDatOco, pIdeEmp, pIdeLegAmb, pIdeUni, pIdeTipLicRegAmb, pIdeTipLicAmb, pAmpMod, pImp, pNmeProj, pNumLicAmb, pNumPcs, pIdeResp,pSub);
     LOOP
          FETCH CursorLicencasEmpreendimentos INTO lLicencasEmpreendimentos;
          EXIT WHEN CursorLicencasEmpreendimentos%NOTFOUND;
                
          /* Conforme: Se (Licença não foi obtida e a data prevista > hoje + PrzAleVen) ou (foi obtida e data de vencimento > hoje + PrzAleVen) */
          IF (lLicencasEmpreendimentos.DatObt IS NULL AND lLicencasEmpreendimentos.DatPre > lDataCorte + lLicencasEmpreendimentos.PrzAleVen) OR (lLicencasEmpreendimentos.DatObt IS NOT NULL AND lLicencasEmpreendimentos.DatVal > lDataCorte + lLicencasEmpreendimentos.PrzAleVen) OR lLicencasEmpreendimentos.Stt = 6 THEN
                lConforme := lConforme + 1;
          /* Possibilidade: Se (Licença nao foi obtida e a data prevista < hoje + PrzAleVen e prevista > hoje) ou (foi obtida e data de vencimento < hoje + PrzAleVen e vencimento > hoje) */
          ELSIF (lLicencasEmpreendimentos.DatObt IS NULL AND lLicencasEmpreendimentos.DatPre < lDataCorte + lLicencasEmpreendimentos.PrzAleVen AND lLicencasEmpreendimentos.DatPre > lDataCorte) OR (lLicencasEmpreendimentos.DatObt IS NOT NULL AND lLicencasEmpreendimentos.DatVal < lDataCorte + lLicencasEmpreendimentos.PrzAleVen AND lLicencasEmpreendimentos.DatVal > lDataCorte) THEN
                lPossibilidade := lPossibilidade + 1;
          /* Comprometido: Se (Licença não foi obtida e a data prevista < hoje) ou (foi obtida e data de vencimento < hoje) */
          ELSIF (lLicencasEmpreendimentos.DatObt IS NULL AND lLicencasEmpreendimentos.DatPre < lDataCorte) OR (lLicencasEmpreendimentos.DatObt IS NOT NULL AND lLicencasEmpreendimentos.DatVal < lDataCorte) THEN
                lComprometidos := lComprometidos + 1;
          END IF;            
     END LOOP;
          
     CLOSE CursorLicencasEmpreendimentos;
          
     if (lConforme + lPossibilidade + lComprometidos) <> 0 then
         lObject_EstatisticaLA_Table.extend;
         lObject_EstatisticaLA_Table(lObject_EstatisticaLA_Table.Last) := Object_EstatisticaLA(lDatOco, lConforme, lPossibilidade, lComprometidos);
          
         lConforme := 0; 
         lPossibilidade := 0; 
         lComprometidos := 0;   
     end if;
     
     lDatOco := ADD_MONTHS(lDatOco, 1);
     
END LOOP;

RETURN lObject_EstatisticaLA_Table;

END;
/

CREATE OR REPLACE
FUNCTION RETORNARESTATISTICASLAANUAL(pDataInicial DATE, pDataFinal DATE, pIdeEmp NUMBER, pIdeLegAmb NUMBER, pIdeUni NUMBER, pIdeTipLicRegAmb NUMBER, pIdeTipLicAmb NUMBER, pAmpMod INT, pImp INT, pNmeProj VARCHAR, pNumLicAmb VARCHAR, pNumPcs VARCHAR, pIdeResp NUMBER, pSub INT)
  RETURN Object_EstatisticaLA_Table
AS

/* Fun��o     : RetornarEstatisticasLAAnual
   Prop�sito  : Retorna uma estatística anual baseada na media mensal das licenças no período informado
   Par�metros : pDataInicial        - Data Inicial do periodo
              : pDataFinal          - Data final do período
              : pIdeEmp             - Identificador da Empresa
              : pIdeLegAmb          - Identificador da Legisla��o Ambienta�
              : pIdeUni             - Identificador da Unidade Gerencial
              : pIdeTipLicRegAmb    - Identificador do Tipo de Empreendimento
              : pIdeTipLicAmb       - Identificador do Tipo da Licença
              : pAmpMod             - Indicador de Ampliação do Empreendimento
              : pImp                - Indicador de Empreendimento Importante
              : pNmeProj            - Nome do Projeto
              : pNumLicAmb          - N�mero da Licen�a
              : pNumPcs             - N�mero do Processo
              : pIdeResp            - Identificador do Respons�vel
              : pSub                - Indicador de Incluir Subordinadas
   Criação    : 14/06/2010 - Eduardo César
   Última Alt.: 02/07/2010 - Eduardo César */


lDataCorte DATE;
lConforme INTEGER := 0;
lPossibilidade INTEGER := 0;
lComprometidos INTEGER := 0;
lDatOco DATE;

CURSOR CursorEstatisticasLA(cpDataInicial DATE, cpDataFinal DATE, cpIdeEmp NUMBER, cpIdeLegAmb NUMBER, cpIdeUni NUMBER, cpIdeTipLicRegAmb NUMBER, cpIdeTipLicAmb NUMBER, cpAmpMod INT, cpImp INT, cpNmeProj VARCHAR, cpNumLicAmb VARCHAR, cpNumPcs VARCHAR, cpIdeResp NUMBER, cpSub INT) IS
SELECT Dat,
       QtdCon,
       QtdPos,
       QtdCom
  FROM TABLE(RetornarEstatisticasLA(cpDataInicial, cpDataFinal, cpIdeEmp, cpIdeLegAmb, cpIdeUni, cpIdeTipLicRegAmb, cpIdeTipLicAmb, cpAmpMod, cpImp, cpNmeProj, cpNumLicAmb, cpNumPcs, cpIdeResp, cpSub));

lEstatisticasEmpreendimentos CursorEstatisticasLA%ROWTYPE;

lObject_EstatisticaLA_Table Object_EstatisticaLA_Table := Object_EstatisticaLA_Table();

BEGIN

lDatOco := TO_DATE('0101'|| TO_CHAR(pDataInicial, 'yyyy'), 'dd-mm-yyyy');

LOOP
    EXIT WHEN lDatOco > pDataFinal OR lDatOco > SYSDATE;
        
    /* Data de corte igual ao ultimo dia do ano */
    lDataCorte := ADD_MONTHS(lDatOco, 12) - 1;
    
    OPEN CursorEstatisticasLA(lDatOco, lDataCorte, pIdeEmp, pIdeLegAmb, pIdeUni, pIdeTipLicRegAmb, pIdeTipLicAmb, pAmpMod, pImp, pNmeProj, pNumLicAmb, pNumPcs, pIdeResp, pSub);
    LOOP
        FETCH CursorEstatisticasLA INTO lEstatisticasEmpreendimentos;
        EXIT WHEN CursorEstatisticasLA%NOTFOUND;
            
        lConforme := lConforme + lEstatisticasEmpreendimentos.QtdCon;
        lPossibilidade := lPossibilidade + lEstatisticasEmpreendimentos.QtdPos;
        lComprometidos := lComprometidos + lEstatisticasEmpreendimentos.QtdCom;
            
    END LOOP;
        
    CLOSE CursorEstatisticasLA;
        
    if (lConforme + lPossibilidade + lComprometidos) <> 0 then
        lObject_EstatisticaLA_Table.extend;
        lObject_EstatisticaLA_Table(lObject_EstatisticaLA_Table.Last) := Object_EstatisticaLA(lDatOco, lConforme, lPossibilidade, lComprometidos);
        
        lConforme := 0;
        lPossibilidade := 0;
        lComprometidos := 0;
    end if;
    
    lDatOco := ADD_MONTHS(lDatOco, 12);

END LOOP;

RETURN lObject_EstatisticaLA_Table;

END; 
/


CREATE OR REPLACE
FUNCTION RetornarFarolCustos(pIdeSolPrb NUMBER) RETURN INT IS
	lDiferencaEntreAcumulados								INT;
BEGIN
	BEGIN   
			SELECT (SUM(tGesFinIte.DESPRE) - SUM(tGesFinIte.DESREA)) INTO lDiferencaEntreAcumulados
			FROM tSolPrb
	  INNER JOIN tSolPrbPas on tSolPrbPas.IdeSolPrb = tSolPrb.IdeSolPrb
	  INNER JOIN tFer on tFer.IdeSolPrbPas = tSolPrbPas.IdeSolPrbPas
	  INNER JOIN tGesFinIte on tGesFinIte.IdeGesFin = tFer.IdeGesFin
		   WHERE tSolPrb.IdeSolPrb = pIdeSolPrb;
   EXCEPTION
   WHEN OTHERS THEN
       RETURN NULL;
   END; 
	
	IF (lDiferencaEntreAcumulados >= 0) THEN
		RETURN 2;
	END IF;
	
	RETURN 0;
END;
/


CREATE OR REPLACE 
FUNCTION RetornarFarolLicencas(pIdeEprLicAmb NUMBER, pTip INT, pTipLic INT) RETURN NVARCHAR2
IS
    
/* Fun��o     : RetornarFarolLicencas
   Prop�sito  : Retorna o Farol das Licen�as de determinado Empreendimento da Empresa
   Par�metros :    pIdeEprLicAmb   - Identificador do Empreendimento
              : pTip            - Tipo Primitivo do Tipo de Licen�a
              : pTipLic         - Tipo do "Tipo de Licen�a" quando for "Licen�a Ambiental" (LP-LI-RLI-LO-LOC-RevLO)
   Cria��o    : 21/07/2009 - Eduardo C�sar
   �ltima Alt.: 20/06/2017 - Eduardo C�sar */
    
        FarolLicencas     NVARCHAR2(4000);
        lTmpIdeTipLicAmb  NUMBER(13) := 0;
        lTmpSigTipLicAmb  NVARCHAR2(10) := '';
		lTmpDesTipLicAmb  NVARCHAR2(100) := '';
        lLicencaObtida    INT := 0;
        lFarol            INT := 0;
		lFarolAux         INT := 0;
        
        CURSOR CursorLicencas(cpIdeEprLicAmb NUMBER, cpTip INT, cpTipLic INT) IS
        SELECT tTipLicAmb.IdeTipLicAmb,
               tTipLicAmb.Sig SigTipLicAmb,
               tTipLicAmb.Des DesTipLicAmb,
               tTipLicAmb.PrzAleVen,
               tLicAmb.IdeLicAmb,
               tLicAmb.DatPrt,
               tLicAmb.DatPre,
               tLicAmb.DatObt,
               tLicAmb.DatVal,
               tLicAmb.VenFob,
               tLicAmb.QtdDiaVen,
               tTipLicAmb.TipLic,
               CASE WHEN tLicAmb.DATOBT IS NOT NULL THEN tLicAmb.DATOBT ELSE tLicAmb.DATPRE END DAT,
			   tLicAmb.Stt SttLicAmb,
			   LicRel.IDELICAMB IDELICAMBREL,
			   LicRel.DATPRT DATPRTREL,
			   case when ttIPLicAmb.PmtRnv = 1 
					then case when tLicAmb.DATLIMRENMAN = 1 
							then tLicAmb.DATLIMREN
							else tLicAmb.DatVal - ttIPLicAmb.PRZLMTRNV
						 end
					else null
			   end DATLIMREN
          FROM tEprLicAmb
         INNER JOIN tTipLicRegAmb on tTipLicRegAmb.IdeTipLicRegAmb = tEprLicAmb.IdeTipLicRegAmb
         INNER JOIN tLicAmb ON tEprLicAmb.IdeEprLicAmb = tLicAmb.IdeEprLicAmb
         INNER JOIN tTipLicAmb ON tLicAmb.IdeTipLicAmb = tTipLicAmb.IdeTipLicAmb
          LEFT JOIN tLicAmb LicRel on tLicAmb.IDELICAMBREL = LicRel.IDELICAMB
         WHERE tEprLicAmb.IdeEprLicAmb = cpIdeEprLicAmb
           AND (cpTip IS NULL OR tTipLicAmb.Tip = cpTip)
           AND (cpTipLic IS NULL OR tTipLicAmb.TipLic = cpTipLic)
		   AND tLicAmb.Stt <> 4 /* Indeferida */
		   AND tLicAmb.Stt <> 5 /* Cancelada */
         ORDER BY CASE WHEN TTIPLICAMB.TIPLIC IS NULL OR TTIPLICAMB.TIPLIC = 0 THEN TTIPLICAMB.TIP ELSE TTIPLICAMB.TIPLIC END, TTIPLICAMB.IDETIPLICAMB, case when DatObt IS NULL and DatPre is null then 1 else 0 end, DAT, tTipLicAmb.TipLic, tLicAmb.IdeLicAmb;

        lLicencas CursorLicencas%ROWTYPE;
        
    BEGIN
        FarolLicencas := '';
        
        OPEN CursorLicencas(pIdeEprLicAmb, pTip, pTipLic);

        LOOP
            FETCH CursorLicencas INTO lLicencas;
            EXIT WHEN CursorLicencas%NOTFOUND;
            
            IF lTmpIdeTipLicAmb = 0 THEN
                lTmpIdeTipLicAmb := lLicencas.IdeTipLicAmb;
                lTmpSigTipLicAmb := lLicencas.SigTipLicAmb;
                lTmpDesTipLicAmb := lLicencas.DesTipLicAmb;
            END IF;
            

            IF lTmpIdeTipLicAmb <> lLicencas.IdeTipLicAmb AND pTip IS NOT NULL THEN

				lFarolAux := CASE lFarol
								  WHEN 1 THEN 6 /* Conclu�da */
								  WHEN 2 THEN 1 /* Concedida */
								  WHEN 3 THEN 3 /* N�o Formalizada */
								  WHEN 4 THEN 7 /* Em renova��o */
								  WHEN 5 THEN 2 /* Formalizada */
								  WHEN 6 THEN 4 /* Pr�xima do prazo */
								  WHEN 7 THEN 5 /* Atrasada ou Vencida */
								  ELSE 0
								  END;
			
				FarolLicencas := FarolLicencas || '#' || lTmpSigTipLicAmb || '�' || CAST(lFarolAux AS VARCHAR2) || '�' || lLicencaObtida || '�' || lTmpDesTipLicAmb || '�' || lTmpIdeTipLicAmb;
                
                lTmpIdeTipLicAmb := lLicencas.IdeTipLicAmb;
                lTmpSigTipLicAmb := lLicencas.SigTipLicAmb;
                lTmpDesTipLicAmb := lLicencas.DesTipLicAmb;
                
                lFarol := 0;
            END IF;

			/* ORDEM DE IMPORT�NCIA DOS FAROIS DAS LICEN�AS
					Vermelha:	Atrasada ou Vencida (5) -> 7
					 Laranja:	Pr�xima do prazo (4) -> 6
						Azul:	Formalizada (2) -> 5
					  Marrom:	Em renova��o (7) -> 4
					  Branca:	N�o Formalizada (3) -> 3
					   Verde:	Concedida (1) -> 2
			 Verde rachurada:	Conclu�da (6) -> 1
			*/

			IF lLicencas.SttLicAmb <> 6 THEN /* Concluida */

                IF (lLicencas.DatObt IS NOT NULL AND lLicencas.IdeLicAmbRel IS NOT NULL AND lLicencas.DatLimRen IS NOT NULL) THEN
                    IF (lLicencas.DatPrtRel IS NULL AND lLicencas.DatLimRen < TO_DATE(SYSDATE)) OR (lLicencas.DatPrtRel IS NOT NULL AND lLicencas.DatLimRen < lLicencas.DatPrtRel) THEN
                        lFarol := 7;--5;
                    ELSE
                        IF lFarol < 4 THEN lFarol := 4;/*7*/ END IF;
                    END IF;
				ELSIF (lLicencas.DatVal IS NOT NULL AND lLicencas.DatVal < TO_DATE(SYSDATE)) OR (lLicencas.DatPre IS NOT NULL AND lLicencas.DatPre < TO_DATE(SYSDATE) AND lLicencas.DatObt IS NULL) THEN
					lFarol := 7;--5;
				ELSIF (lLicencas.DatVal IS NOT NULL AND lLicencas.DatVal - lLicencas.PrzAleVen < TO_DATE(SYSDATE)) OR (lLicencas.DatPre < TO_DATE(SYSDATE) + lLicencas.PrzAleVen  AND lLicencas.DatObt IS NULL) THEN 
					IF lFarol < 6 THEN lFarol := 6;/*4*/ END IF;
				ELSIF lLicencas.DatObt IS NULL AND lLicencas.DatPrt IS NULL THEN 
					IF lFarol < 3 THEN lFarol := 3; END IF;
				ELSIF lLicencas.DatObt IS NULL AND lLicencas.DatPrt IS NOT NULL THEN 
					IF lFarol < 5 THEN lFarol := 5;/*2*/ END IF;
				ELSE
					IF lFarol < 2 THEN lFarol := 2;/*1*/ END IF;
				END IF;

			ELSE
				IF lFarol < 1 THEN lFarol := 1;/*6*/ END IF;
			END IF;

        END LOOP;

		IF lLicencas.DatObt IS NOT NULL THEN
			lLicencaObtida := 1;
		ELSE 
			lLicencaObtida := 0;
		END IF;
        
        IF lTmpIdeTipLicAmb <> 0 AND pTip IS NOT NULL THEN
			lFarolAux := CASE lFarol
							  WHEN 1 THEN 6 /* Conclu�da */
							  WHEN 2 THEN 1 /* Concedida */
							  WHEN 3 THEN 3 /* N�o Formalizada */
							  WHEN 4 THEN 7 /* Em renova��o */
							  WHEN 5 THEN 2 /* Formalizada */
							  WHEN 6 THEN 4 /* Pr�xima do prazo */
							  WHEN 7 THEN 5 /* Atrasada ou Vencida */
							  ELSE 0
							  END;
							  
            IF lLicencas.TipLic = 6 AND lLicencas.DatObt IS NOT NULL THEN
                FarolLicencas := lTmpSigTipLicAmb || '�' || CAST(lFarolAux AS VARCHAR2) || '�' || lLicencaObtida || '�' || lTmpDesTipLicAmb || '�' || lTmpIdeTipLicAmb;
            ELSE
                FarolLicencas := FarolLicencas || '#' || lTmpSigTipLicAmb || '�' || CAST(lFarolAux AS VARCHAR2) || '�' || lLicencaObtida || '�' || lTmpDesTipLicAmb || '�' || lTmpIdeTipLicAmb;
                FarolLicencas := SUBSTR(FarolLicencas, 2, LENGTH(FarolLicencas));
            END IF;

        ELSIF pTip IS NULL THEN
            lFarol := -1;
            FarolLicencas := CAST(lFarol AS VARCHAR2); 
        ELSE 
            FarolLicencas := NULL;
        END IF;

        CLOSE CursorLicencas;

        IF FarolLicencas = '' THEN 
            FarolLicencas := NULL; 
        END IF;
        
        RETURN FarolLicencas;
    
    END;
/
	
	
CREATE OR REPLACE
FUNCTION RetornarFarolPrazos(pIdeSolPrb NUMBER) RETURN INT IS
	    lQuantidadeMarcos								INT;
        lMarcosNaoConcluidosAteHoje			            INT;
	    lStatusUltimoMarcoAteHoje						INT;
BEGIN	
  SELECT COUNT(IdePacTar)INTO lQuantidadeMarcos
			FROM tSolPrb
	  INNER JOIN tSolPrbPas ON tSolPrbPas.IdeSolPrb = tSolPrb.IdeSolPrb
	  INNER JOIN tFer ON tFer.IdeSolPrbPas = tSolPrbPas.IdeSolPrbPas
	  INNER JOIN tPacTar ON tPacTar.IdePlaAco = tFer.IdePlaAco
		   WHERE tSolPrb.IdeSolPrb = pIdeSolPrb
			 AND tPacTar.AcaMst <> 0
			 AND tPacTar.Del = 0;	

	IF (lQuantidadeMarcos <= 0) THEN
		RETURN NULL;
	END IF;
	
  SELECT COUNT(IdePacTar) INTO lMarcosNaoConcluidosAteHoje
			FROM tSolPrb
	  INNER JOIN tSolPrbPas on tSolPrbPas.IdeSolPrb = tSolPrb.IdeSolPrb
	  INNER JOIN tFer on tFer.IdeSolPrbPas = tSolPrbPas.IdeSolPrbPas
	  INNER JOIN tPacTar on tPacTar.IdePlaAco = tFer.IdePlaAco
		   WHERE tSolPrb.IdeSolPrb = pIdeSolPrb
			 AND DefinirStatusAcao(Tpactar.IdePacTar, SYSDATE) <> 4
			 AND DefinirStatusAcao(Tpactar.IdePacTar, SYSDATE) <> 5
			 AND tPacTar.FimPre < SYSDATE()
			 AND tPacTar.AcaMst <> 0
			 AND tPacTar.Del = 0;
   BEGIN 
	SELECT STATUS INTO lStatusUltimoMarcoAteHoje 
    FROM ( 
												   SELECT DefinirStatusAcao(tPacTar.IdePacTar, SYSDATE) STATUS
													FROM tSolPrb
											  INNER JOIN tSolPrbPas on tSolPrbPas.IdeSolPrb = tSolPrb.IdeSolPrb
											  INNER JOIN tFer on tFer.IdeSolPrbPas = tSolPrbPas.IdeSolPrbPas
											  INNER JOIN tPacTar on tPacTar.IdePlaAco = tFer.IdePlaAco
												   WHERE tSolPrb.IdeSolPrb = pIdeSolPrb
													 AND tPacTar.FimPre < SYSDATE
													 AND tPacTar.AcaMst <> 0
													 AND tPacTar.Del = 0
												ORDER BY FimPre DESC
											) vACA
		WHERE ROWNUM = 1;
   EXCEPTION
   WHEN OTHERS THEN
	lStatusUltimoMarcoAteHoje := NULL;
   END;
											
	IF (lMarcosNaoConcluidosAteHoje = 0 AND (lStatusUltimoMarcoAteHoje = 4 Or lStatusUltimoMarcoAteHoje is null)) THEN
		RETURN 2;
	END IF;

	RETURN 0;	
END;
/


CREATE OR REPLACE FUNCTION RetornarHorasAteAgora (pInicioPrevisto DATE, pFimPrevisto DATE, pDurHra INT, pFreRec NUMBER, pData DATE)
RETURN  FLOAT IS

/* FUNCAO      : [RetornarHorasAteAgora]         
   PROPOSITO   : RETORNA A QUANTIDADE DE HORAS EXECUTADAS AT� O MOMENTO
   PARAMETROS  : pInicioPrevisto: Inicio Previsto da tarefa
                 pFimPrevisto:  Fim PRevisto da tarefa
                 pDurHra:       Dura��o em horas da tarefa
				 pFreRec:		Periodicidade da tarefa
                 pData:			DATA DE CORTE DA AN�LISE, OU SEJA, ANALISAR A��ES AT� A DATA X                 
   Criacao      : 22/10/2015 - Daniel
   �ltima Alt.  : 
*/

    lPer			FLOAT;
	lHorasTotais	FLOAT;
	lHorasAteAgora	FLOAT;
	
BEGIN

	RETURN CASE WHEN pFreRec = 0 
							THEN                               
							  CASE WHEN pInicioPrevisto < trunc(pData) THEN CASE WHEN pFimPrevisto < trunc(pData) THEN ((pFimPrevisto - pInicioPrevisto) + 1) * 8 ELSE (trunc(pData) - pInicioPrevisto) * 8 END ELSE 0 END
							ELSE
							  TRUNC(CASE WHEN pFreRec = 1 THEN
								CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1)) < TRUNC(pData) THEN 
								  CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1)) = pInicioPrevisto THEN 1 ELSE pDurHra / 8 END
							   ELSE 
								  (((TRUNC(pData) - 1) - pInicioPrevisto)) + 1
							   END
								
							   WHEN pFreRec = 2 THEN
							   CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 7) < TRUNC(pData) THEN 
								  CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 7) = pInicioPrevisto THEN 1 ELSE pDurHra / 8 END
							   ELSE 
								  (((TRUNC(pData) - 1) - pInicioPrevisto) / 7) + 1
							   END
								
							   WHEN pFreRec = 3 THEN
							   CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 15) < TRUNC(pData) THEN 
								  CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 15) = pInicioPrevisto THEN 1 ELSE pDurHra / 8 END
							   ELSE 
								  (((TRUNC(pData) - 1) - pInicioPrevisto) / 15) + 1
							   END
								
							   WHEN pFreRec = 4 THEN
							   CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 30) < TRUNC(pData) THEN 
								  CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 30) = pInicioPrevisto THEN 1 ELSE pDurHra / 8 END
							   ELSE 
								  (((TRUNC(pData) - 1) - pInicioPrevisto) / 30) + 1
							   END
								
							   WHEN pFreRec = 5 THEN
							   CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 60) < TRUNC(pData) THEN 
								  CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 60) = pInicioPrevisto THEN 1 ELSE pDurHra / 8 END
							   ELSE 
								  (((TRUNC(pData) - 1) - pInicioPrevisto) / 60) + 1
							   END
								
							   WHEN pFreRec = 6 THEN
							   CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 90) < TRUNC(pData) THEN 
								  CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 90) = pInicioPrevisto THEN 1 ELSE pDurHra / 8 END
							   ELSE 
								  (((TRUNC(pData) - 1) - pInicioPrevisto) / 90) + 1
							   END
							   
							   WHEN pFreRec = 7 THEN
							   CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 120) < TRUNC(pData) THEN 
								  CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 120) = pInicioPrevisto THEN 1 ELSE pDurHra / 8 END
							   ELSE 
								  (((TRUNC(pData) - 1) - pInicioPrevisto) / 120) + 1
							   END
							   
							   WHEN pFreRec = 8 THEN
							   CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 180) < TRUNC(pData) THEN 
								  CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 180) = pInicioPrevisto THEN 1 ELSE pDurHra / 8 END
							   ELSE 
								  (((TRUNC(pData) - 1) - pInicioPrevisto) / 180) + 1
							   END
							   
							   WHEN pFreRec = 9 THEN
							   CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 365) < TRUNC(pData) THEN 
								  CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 365) = pInicioPrevisto THEN 1 ELSE pDurHra / 8 END
							   ELSE 
								  (((TRUNC(pData) - 1) - pInicioPrevisto) / 365) + 1
							   END
							   
							   WHEN pFreRec = 10 THEN
							   CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 730) < TRUNC(pData) THEN 
								  CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 730) = pInicioPrevisto THEN 1 ELSE pDurHra / 8 END
							   ELSE 
								  (((TRUNC(pData) - 1) - pInicioPrevisto) / 730) + 1
							   END
							   
							   WHEN pFreRec = 11 THEN
							   CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 1095) < TRUNC(pData) THEN 
								  CASE WHEN pInicioPrevisto + (((pDurHra / 8) - 1) * 1095) = pInicioPrevisto THEN 1 ELSE pDurHra / 8 END
							   ELSE 
								  (((TRUNC(pData) - 1) - pInicioPrevisto) / 1095) + 1
							   END
							   
							   ELSE
								0 END, 0) * 8
						END;
END;
/

CREATE OR REPLACE 
FUNCTION RetornarLicencaAtual( pIdeEprLicAmb NUMBER, pTip NUMBER, pTipLic NUMBER, pAtv NUMBER, pLic NVARCHAR2, pIdeLicAmb NUMBER, pLicAsvOutOutras INT := 0)
RETURN NUMBER IS
/* Função     : RetornarLicencaAtual
   Propósito  : Retorna a licença atual de um Empreendimento a partir de um tipo passado como paâmetro ou de todos os tipos
   Parâmetros : pIdeEprLicAmb  - Ide de um Empreendimento 
                pTip            - Tip da Licenca tTipLicAmb.Tip
                pTipLic     - Tip da Licenca Ambiental tTipLicAmb.TipLic
                pAtv            - Somente Licenças com Status Diferente 3(Indeferida) e 4 (Vencida)
                pLic            - 'LI'/'LO' Retorna a ultima licenca de Revalidação ou Correção de uma destas licenças
                pIdeLicAmb  - Identificador da Licença atual
   Criação    : 23/04/2010 - Flávio
   Última Alt.: 02/07/2010 - Eduardo César */
     
   lretn NUMBER := NULL;

BEGIN
    IF pIdeEprLicAmb IS NULL THEN /* Se não foi passado o Identificador do Empreendimento */
        lretn := NULL;
    ELSE
       IF pLic IS NULL THEN        
        IF pTip IS NOT NULL THEN /* Se foi passado o Tip Outorga/ASV/etc... */
            SELECT IDELICAMB INTO lretn FROM (
                  SELECT IDELICAMB, CASE WHEN DATOBT IS NOT NULL THEN DATOBT ELSE DATPRE END DAT
                    FROM TLICAMB
              INNER JOIN TTIPLICAMB ON TLICAMB.IDETIPLICAMB = TTIPLICAMB.IDETIPLICAMB
                   where IDEEPRLICAMB = PIDEEPRLICAMB
                     AND TTIPLICAMB.TIP = pTip
                     and (PATV = 0 or (TLICAMB.STT <> 6 and TLICAMB.STT <> 4 and TLICAMB.STT <> 5))
                     AND (pLicAsvOutOutras = 0 OR TLICAMB.IDELICAMB = RetornarLicencaAtual(pIdeEprLicAmb, NULL, NULL, pAtv, NULL, NULL, pLicAsvOutOutras))
                ORDER BY DAT DESC, TLICAMB.VENFOB + TLICAMB.QTDDIAVEN DESC) VLIC
             WHERE ROWNUM = 1;
         ELSIF pTipLic IS NOT NULL THEN /* Se é a última licença ambiental */
            SELECT IDELICAMB INTO lretn FROM (
                  SELECT IDELICAMB, CASE WHEN DATOBT IS NOT NULL THEN DATOBT ELSE DATPRE END DAT
                    FROM TLICAMB
              INNER JOIN TTIPLICAMB ON TLICAMB.IDETIPLICAMB = TTIPLICAMB.IDETIPLICAMB
                   WHERE IDEEPRLICAMB = pIdeEprLicAmb
                     AND TTIPLICAMB.TIPLIC = pTipLic
                     AND (pAtv = 0 OR (TLICAMB.STT <> 6 AND TLICAMB.STT <> 4 AND TLICAMB.STT <> 5))
                ORDER BY DAT DESC, TLICAMB.VENFOB + TLICAMB.QTDDIAVEN DESC) VLIC
             WHERE ROWNUM = 1;         
         ElSE                                   /* Se é a última licença do Empreendimento */
            SELECT IDELICAMB INTO lretn FROM (
                  SELECT IDELICAMB, CASE WHEN DATOBT IS NOT NULL THEN DATOBT ELSE DATPRE END DAT
                    FROM TLICAMB
              INNER JOIN TTIPLICAMB ON TLICAMB.IDETIPLICAMB = TTIPLICAMB.IDETIPLICAMB
                   WHERE IDEEPRLICAMB = PIDEEPRLICAMB                  
                     AND (pLicAsvOutOutras <> 0 OR (pLicAsvOutOutras = 0 AND TTIPLICAMB.TIPLIC IS NOT NULL AND TTIPLICAMB.TIPLIC <> 0))
                     AND (pAtv = 0 OR (TLICAMB.STT <> 6 AND TLICAMB.STT <> 4 AND TLICAMB.STT <> 5))
                ORDER BY DAT DESC, TLICAMB.VENFOB + TLICAMB.QTDDIAVEN DESC) VLIC
             WHERE ROWNUM = 1;
         END IF;
       ELSE
        IF UPPER(pLic) = 'LI' THEN
           SELECT IDELICAMB INTO lretn FROM (
                  SELECT IDELICAMB, CASE WHEN DATOBT IS NOT NULL THEN DATOBT ELSE DATPRE END DAT
                    FROM TLICAMB
              INNER JOIN TTIPLICAMB ON TLICAMB.IDETIPLICAMB = TTIPLICAMB.IDETIPLICAMB
                   WHERE IDEEPRLICAMB = pIdeEprLicAmb
                     AND (TTIPLICAMB.TIPLIC = 2 OR TTIPLICAMB.TIPLIC = 3 OR TTIPLICAMB.TIPLIC = 7)  /* LI / RLI */
                     AND (pAtv = 0 OR (TLICAMB.STT <> 6 AND TLICAMB.STT <> 4 AND TLICAMB.STT <> 5))
                     AND (pIdeLicAmb IS NULL OR (TLICAMB.IDELICAMB <> pIdeLicAmb))
                ORDER BY DAT DESC, TLICAMB.VENFOB + TLICAMB.QTDDIAVEN DESC) VLIC
             WHERE ROWNUM = 1;
        ELSIF UPPER(pLic) = 'LO' THEN
           SELECT IDELICAMB INTO lretn FROM (
                  SELECT IDELICAMB, CASE WHEN DATOBT IS NOT NULL THEN DATOBT ELSE DATPRE END DAT
                    FROM TLICAMB
              INNER JOIN TTIPLICAMB ON TLICAMB.IDETIPLICAMB = TTIPLICAMB.IDETIPLICAMB
                   WHERE IDEEPRLICAMB = pIdeEprLicAmb
                     AND (TTIPLICAMB.TIPLIC = 4 OR TTIPLICAMB.TIPLIC = 5 OR TTIPLICAMB.TIPLIC = 6) /* LO / RLO /LOC */
                     AND (pAtv = 0 OR (TLICAMB.STT <> 6 AND TLICAMB.STT <> 4 AND TLICAMB.STT <> 5))
                     AND (pIdeLicAmb IS NULL OR (TLICAMB.IDELICAMB <> pIdeLicAmb))                       
                ORDER BY DAT DESC, TLICAMB.VENFOB + TLICAMB.QTDDIAVEN DESC) VLIC
             WHERE ROWNUM = 1;      
        END IF;
       END IF;
    END IF;
    RETURN lretn;
END;
/

CREATE OR REPLACE 
FUNCTION RETORNARMETAANUAL(pIdeAco NUMBER, pCmpMet NUMBER)
  RETURN  FLOAT IS

/* Fun��o     : RetornarMetaAnual
   Prop�sito  : Retorna o valor inserido em dezembro (apurado ou acumulado) como sendo a Meta Anual do Indicador
   Par�metros : pTableName-Nome da Tabela
                pIdeTable-Ide do registro que ter� sua �rvore montada
   Cria��o    : 20/10/2006 - mar
   �ltima Alt.: 25/02/2007 - mar */

    lretn       FLOAT := NULL;
BEGIN
    IF pCmpMet = 0 THEN
        lretn := NULL;
    ELSE
        SELECT DECODE(MAX(tValAco.Met), NULL, MAX(tValAco.MetInf), MAX(tValAco.Met)) INTO lretn   -- Se o indicador n�o tiver Meta procura pelo Limite Inferior
          FROM tValAco
         WHERE tValAco.IdeAco = pIdeAco
           AND tValAco.Fre = 1
           AND tValAco.Tip = pCmpMet
           AND TO_NUMBER(TO_CHAR(tValAco.Oco, 'MM')) = 12;
    END IF;

    RETURN lretn;
END;
/


CREATE OR REPLACE 
FUNCTION RETORNARNUMEROREUNIAO(pIdeUni NUMBER, pDat DATE)
  RETURN  INT IS

/* Fun��o      : RetornarNumeroReuniao
   Prop�sito   : Definir o N�mero da Reuni�o
   Par�metros  : pIdeUni-Identificador da Unidade Gerencial
                 pDat-Data/Hora da Reuni�o
   Retorno     : Retorna o n�mero da reuni�o dentro da Unidade Gerencial
   Cria��o     : 31/10/2005 - mar
   �ltima Alt. : 31/10/2005 - mar    */

    lretn   INT;

BEGIN
    SELECT COUNT(IDEUNISCD) + 1
      INTO lretn
      FROM TUNISCD, TATV
     WHERE TUNISCD.IDEATV = TATV.IDEATV
       AND TUNISCD.IDEUNI = pIdeUni
       AND TATV.TIPATV = 1
       AND TUNISCD.DAT BETWEEN TO_DATE('01/01/' || TO_NUMBER(TO_CHAR(pDat, 'YYYY')), 'dd/MM/yyyy') AND pDat - 0.00001;

    RETURN lretn;
END;
/



create or replace FUNCTION RetornarOrdemTarefa(pIdePacTar NUMBER) RETURN NVARCHAR2 IS

  lretn	NVARCHAR2(30);
  lIdeSpr INT;
BEGIN
	BEGIN   
			
      SELECT IDEPACTARSUP, TO_CHAR(ORD) INTO lIdeSpr, lretn FROM TPACTAR WHERE IDEPACTAR = pIdePacTar;
      
   EXCEPTION
   WHEN OTHERS THEN
        
        SELECT TO_CHAR(ORD) INTO lretn FROM TPACTAR WHERE IDEPACTAR = pIdePacTar;
        lIdeSpr := null;
        
   END; 

  WHILE length(lretn) < 3 LOOP
        lretn := '0' || lretn;
  END LOOP;

  IF lIdeSpr IS NOT NULL THEN
    lretn := RetornarOrdemTarefa(lIdeSpr) || '.' || lretn;
  END IF;

	RETURN lretn;
END;
/



CREATE OR REPLACE 
FUNCTION RetornarPiorFarolSubProjetos(pIdeEprLicAmb NUMBER) RETURN INT
IS
    
/* Fun��o     : RetornarPiorFarolSubProjetos
   Prop�sito  : Retorna o pio caso de Farol das Licen�as dos subprojetos de determinado Empreendimento da Empresa
   Par�metros : pIdeEprLicAmb   - Identificador do Empreendimento
   Cria��o    : 07/05/2015 - Eduardo C�sar
   �ltima Alt.:  */
    
    lFarol INT := 0;
        
    BEGIN


      SELECT CASE WHEN MAX(VLIC.FAROL) IS NULL THEN 0 ELSE MAX(VLIC.FAROL) END INTO lFarol
        FROM (SELECT CASE WHEN LIC.DATVAL < SYSDATE OR (LIC.DATPRE IS NOT NULL AND LIC.DATPRE < SYSDATE AND LIC.DATOBT IS NULL) THEN 5
						  WHEN (LIC.DATVAL - TTIPLICAMB.PRZALEVEN < SYSDATE) OR (LIC.DATPRE < SYSDATE + TTIPLICAMB.PRZALEVEN AND LIC.DATOBT IS NULL) THEN 4
					 ELSE 0 END FAROL
            FROM TLICAMB LIC 
           INNER JOIN TTIPLICAMB ON LIC.IDETIPLICAMB = TTIPLICAMB.IDETIPLICAMB
           INNER JOIN (SELECT EPR.IDEEPRLICAMB, LEVEL LVL, EPR.IDEEPRLICAMBREL
                   FROM TEPRLICAMB EPR
                    CONNECT BY PRIOR EPR.IDEEPRLICAMB = EPR.IDEEPRLICAMBREL
                    START WITH EPR.IDEEPRLICAMB = pIdeEprLicAmb) EPR ON LIC.IDEEPRLICAMB = EPR.IDEEPRLICAMB
           WHERE LIC.STT <> 6
             AND EPR.IDEEPRLICAMB <> pIdeEprLicAmb) VLIC
       WHERE VLIC.FAROL = 4 OR VLIC.FAROL = 5;


        RETURN lFarol;
    
    END;
/


create or replace 
FUNCTION RETORNARPROXIMADATAFREQUENCIA(pData DATE, pFre NUMBER)
RETURN DATE AS

/* Função     : RetornarProximaDataFrequencia
   Propósito  : Retorna a proxima data domando como referência, a frequencia informada
   Parâmetros :    pData   - Data base
              : pFre    - Frequencia
   Criação    : 14/06/2010 - Eduardo César
   Última Alt.: 17/01/2013 - Eduardo César */

rtnData DATE;

BEGIN

    IF pFre = 1 THEN /*Diario*/
        rtnData := pData + 1;
    ELSIF pFre = 2 THEN /*Semanal*/
        rtnData := pData + 7;
    ELSIF pFre = 3 THEN /*Quinzenal*/
        rtnData := pData + 15;
    ELSIF pFre = 4 THEN /*Mensal*/
        rtnData := NON_ANSI_ADD_MONTHS(pData, 1);
    ELSIF pFre = 5 THEN /*Bimestral*/
        rtnData := NON_ANSI_ADD_MONTHS(pData, 2);
    ELSIF pFre = 6 THEN /*Trimestral*/
        rtnData := NON_ANSI_ADD_MONTHS(pData, 3);
    ELSIF pFre = 7 THEN /*Quadrimestral*/
        rtnData := NON_ANSI_ADD_MONTHS(pData, 4);
    ELSIF pFre = 8 THEN /*Semestral*/
        rtnData := NON_ANSI_ADD_MONTHS(pData, 6);
    ELSIF pFre = 9 THEN /*Anual*/
        rtnData := NON_ANSI_ADD_MONTHS(pData, 12);
    ELSIF pFre = 10 THEN /*Bienal*/
        rtnData := NON_ANSI_ADD_MONTHS(pData, 24);
    ELSIF pFre = 11 THEN /*Trienal*/
        rtnData := NON_ANSI_ADD_MONTHS(pData, 36);
    END IF;

    RETURN rtnData;
END;
/

CREATE OR REPLACE 
FUNCTION retornarseusuariopossuiregra(pIdeUsu IN NUMBER, pCodInt IN VARCHAR, pValRegra IN INT) RETURN INT
IS

/* Fun��o      : Retornar se o Usu�rio Possui determinada regra
   Prop�sito   : Verificar regra do usu�rio
   Par�metros  : pIdeUsu - Identificador do usu�rio
                 pCodInt - C�digo da regra
   Retorno     : Retorna 1 se possui a regra e 0 se n�o possui
   Cria��o     : 20/11/2012 - FCS
   �ltima Alt. : */

	lRetn  INT := 0;
	
BEGIN

SELECT COUNT(Regra) INTO lRetn
  FROM (SELECT tUsuOpeSis.IdeUsuOpeSis Regra
      FROM tUsuOpeSis
  INNER JOIN tOpeSis on tUsuOpeSis.IdeOpeSis = tOpeSis.IdeOpeSis
     WHERE tUsuOpeSis.IdeUsu = pIdeUsu
       AND tOpeSis.CodInt = pCodInt
       AND tUsuOpeSis.Val = pValRegra
    UNION
    SELECT tGruUsuOpeSis.IdeGruUsuOpeSis Regra
      FROM tGruUsuOpeSis
  INNER JOIN tUsuGruUsu On tGruUsuOpeSis.IdeGruUsu = tUsuGruUsu.IdeGruUsu
  INNER JOIN tOpeSis on tGruUsuOpeSis.IdeOpeSis = tOpeSis.IdeOpeSis
     WHERE tUsuGruUsu.IdeUsu = pIdeUsu
       AND tOpeSis.CodInt = pCodInt
       AND tGruUsuOpeSis.Val = pValRegra) Regras;

	RETURN lRetn;

END;
/



CREATE OR REPLACE 
FUNCTION RetornarSttVencimentoLicenca(pIdeLicAmb NUMBER) RETURN INT
IS

/* Fun��o      : RetornarSttVencimentoLicenca
   Prop�sito   : Retornar um status de email informando se � necess�rio enviar um email informando que a licen�a est� pr�xima do vencimento
   Par�metros  : pIdeLicAmb - Identificador da Licen�a Ambiental
   Retorno     : 0 = n�o mandar email
                 1 = mandar email
   Cria��o     : 04/09/2012 - Eduardo C�sar
   �ltima Alt.: 27/07/2018 - Eduardo C�sar */
   
    lRetn                  INT := 0;
    lTipoLicenca           INT;
    lTipoLicencaAmbiental  INT;
    lIdeEprLicAmb          NUMBER(13);
    lDataVencimento        DATE;
    lDataObtencao          DATE;
    lDataObtencaoProxima   DATE;
    lPrazoAlerta           INT;
    lStatusEmail           NUMBER(1);
	lLicencaRelacionada	   NUMBER(13);
	lDataProtocoloRel	   DATE;
	
    
    lLicencaPrevia INT := 1;
    lLicencaImplantacao INT := 2;
    lRevalidacaoLicencaImplantacao INT := 3;
    lLicencaOperacao INT := 4;
    lLicencaOperacaoCorretiva INT := 5;
    lRevalidacaoLicencaOperacao INT := 6;
    lLicencaPreviaEImplantacao INT := 7;

BEGIN
    
    SELECT Lic.IdeEprLicAmb, Tip.Tip, Tip.TipLic, Lic.DatObt, Lic.DatVal, Tip.PrzAleVen, Lic.SttEml, LicRel.IdeLicAmb, LicRel.DatPrt
	  INTO lIdeEprLicAmb, lTipoLicenca, lTipoLicencaAmbiental, lDataObtencao, lDataVencimento, lPrazoAlerta, lStatusEmail, lLicencaRelacionada, lDataProtocoloRel
      FROM tTipLicAmb Tip
     INNER JOIN tLicAmb Lic ON Tip.IdeTipLicAmb = Lic.IdeTipLicAmb
      LEFT JOIN tLicAmb LicRel on Lic.IdeLicAmbRel = LicRel.IdeLicAmb
     WHERE Lic.IdeLicAmb = pIdeLicAmb;
    
    IF lDataVencimento - lPrazoAlerta > SYSDATE OR lDataVencimento < SYSDATE THEN
        RETURN 0;
    END IF;
	
	IF lLicencaRelacionada IS NOT NULL AND lDataProtocoloRel IS NOT NULL THEN
		RETURN 0;
	END IF;

    /* Verifica se N�O � uma Licen�a Ambiental do fluxo (LP / PI / LO) */
    IF lTipoLicenca <> 1 THEN
        IF lStatusEmail <> 0 then
            RETURN 0;
        ELSE 
            RETURN 1;
        END IF;
    ELSE
    
    /*
        LicencaPrevia = 1,
        LicencaImplantacao = 2,
        RevalidacaoLicencaImplantacao = 3,
        LicencaOperacao = 4,
        LicencaOperacaoCorretiva = 5,
        RevalidacaoLicencaOperacao = 6,
        LicencaPreviaEImplantacao = 7
    */

        /* Tipo da Licenca Ambiental */
        IF lTipoLicencaAmbiental = lLicencaPrevia THEN
        /* LP - Enviar email a cada 30 dias enquanto n�o houver uma licen�a do tipo LI concedida e a data de vencimento ainda for maior que hoje */
            BEGIN
                SELECT MIN(DatObt) INTO lDataObtencaoProxima
                  FROM tEprLicAmb Epr
                 INNER JOIN tLicAmb Lic ON Epr.IdeEprLicAmb = Lic.IdeEprLicAmb
                 INNER JOIN tTipLicAmb Tip ON Tip.IdeTipLicAmb = Lic.IdeTipLicAmb
                 WHERE Epr.IdeEprLicAmb = lIdeEprLicAmb
                   AND Lic.DatObt > lDataObtencao
                   AND Tip.Tip = lTipoLicenca
                   AND Tip.TipLic = lLicencaImplantacao;
            EXCEPTION WHEN OTHERS THEN
                lDataObtencaoProxima := NULL;
            END;
            
            IF lDataObtencaoProxima IS NULL THEN
                RETURN 1;
            ELSE 
                RETURN 0;
            END IF;
            
       ELSIF lTipoLicencaAmbiental = lLicencaImplantacao AND lTipoLicencaAmbiental = lRevalidacaoLicencaImplantacao AND lTipoLicencaAmbiental = lLicencaPreviaEImplantacao THEN
        /* LI - RevLI - LP+LI - Enviar email a cada 30 dias enquanto n�o houver uma licen�a do tipo RevLI ou LO concedida (com data de obten��o maior que a da licen�a em quest�o) e a data de vencimento ainda for maior que hoje */
            BEGIN
                SELECT MIN(DatObt) INTO lDataObtencaoProxima
                  FROM tEprLicAmb Epr
                 INNER JOIN tLicAmb Lic ON Epr.IdeEprLicAmb = Lic.IdeEprLicAmb
                 INNER JOIN tTipLicAmb Tip ON Tip.IdeTipLicAmb = Lic.IdeTipLicAmb
                 WHERE Epr.IdeEprLicAmb = lIdeEprLicAmb
                   AND Lic.DatObt > lDataObtencao
                   AND Tip.Tip = lTipoLicenca
                   AND (Tip.TipLic = lRevalidacaoLicencaImplantacao OR Tip.TipLic = lLicencaOperacao);
            EXCEPTION WHEN OTHERS THEN
                lDataObtencaoProxima := NULL;
            END;
            
            IF lDataObtencaoProxima IS NULL THEN
                RETURN 1;
            ELSE 
                RETURN 0;
            END IF;
        
        ELSIF lTipoLicencaAmbiental = lLicencaOperacao AND lTipoLicencaAmbiental = lLicencaOperacaoCorretiva AND lTipoLicencaAmbiental = lRevalidacaoLicencaOperacao THEN
        /* LO - LOC - RevLO - Enviar email a cada 30 dias enquanto n�o houver uma licen�a do tipo RevLO concedida (com data de obten��o maior que a da licen�a em quest�o) e a data de vencimento for maior que hoje */
            BEGIN
                SELECT MIN(DatObt) INTO lDataObtencaoProxima
                  FROM tEprLicAmb Epr
                 INNER JOIN tLicAmb Lic ON Epr.IdeEprLicAmb = Lic.IdeEprLicAmb
                 INNER JOIN tTipLicAmb Tip ON Tip.IdeTipLicAmb = Lic.IdeTipLicAmb
                 WHERE Epr.IdeEprLicAmb = lIdeEprLicAmb
                   AND Lic.DatObt > lDataObtencao
                   AND Tip.Tip = lTipoLicenca
                   AND Tip.TipLic = lRevalidacaoLicencaOperacao;
            EXCEPTION WHEN OTHERS THEN
                lDataObtencaoProxima := NULL;
            END;
            
            IF lDataObtencaoProxima IS NULL THEN
                RETURN 1;
            ELSE 
                RETURN 0;
            END IF;
            
        END IF;
    END IF;

    RETURN lRetn;

END;
/



/* Fun��o    : RetornarTags
  Prop�sito  : Retorna as Tags de determindado objeto por usu�rio e empresa
  Par�metros : pIdeObj        - Identificador do Objeto
              : pTypObj    - Tipo do Objeto
              : pIdeEmp    - Identificador da Empresa
              : pIdeUsu    - Identificador do Usuario
              : pQtdDeTags  - Quantidade de Tags a ser retornada
  Cria��o    : 24/01/2014  - Flavio Silva
  �ltima Alt.:  */

CREATE OR REPLACE 
FUNCTION RetornarTags(pIdeObj NUMBER, pTypObj VARCHAR2, pIdeEmp NUMBER, pIdeUsu NUMBER) RETURN NVARCHAR2
IS
    lTags     NVARCHAR2(2000) := '';
BEGIN
  
  FOR NomeTag IN (SELECT TTAG.NME
                FROM TTAG
          INNER JOIN TTAGREL ON TTAG.IDETAG = TTAGREL.IDETAG
               WHERE TTAGREL.IDEOBJ = pIdeObj
                AND TTAGREL.TYPOBJ = pTypObj
                AND TTAG.IDEEMP = pIdeEmp
                AND TTAG.IDEUSU = pIdeUsu
           ORDER BY TTAG.NME ASC) LOOP
           
    lTags := lTags || '#�#'  || NomeTag.nme;
  END LOOP;

  RETURN lTags;
END;
/

CREATE OR REPLACE
FUNCTION RETORNARULTIMAEXECUCAODATAREFA(pIDEPACTAR NUMBER, pTYP VARCHAR2) RETURN DATE IS
dataRetorno DATE;
BEGIN

  /* Fun��o      : RetornarUltimaExecucaoDaTarefa
   Prop�sito   : Retorna a data da �ltima execu��o de uma tarefa
   Par�metros  : pTyp - Tipo de evento (Nesse caso uma execu��o)
   Retorno     : Retorna uma data
   Cria��o     : 18/09/2014 - Vin�cius */

  SELECT ULTEXCREC INTO dataRetorno 
  FROM 
    (SELECT row_number() OVER(ORDER BY L.DATPRE DESC) linha, L.ULTEXCREC FROM tpactarexcreclog L WHERE L.idepactar = pIDEPACTAR AND L.typ = pTYP) 
  WHERE linha = 1;
   RETURN dataRetorno;
  
  EXCEPTION WHEN OTHERS THEN RETURN NULL;  
  
END;
/

CREATE OR REPLACE 
FUNCTION RETORNARULTIMASIGNIFICANCIAAVL(pIdePlaCauEfe NUMBER, pColRetn INT) RETURN NUMBER IS

/* Fun��o       : RETORNARULTIMASIGNIFICANCIAAVL            
   Prop�sito    : Retorna a �ltima signific�ncia de cada Planilha de Causa-e-Efeito
   Par�metros   : pIdePlaCauEfe-Identificador da Planilha de Causa-e-Efeito
   Cria��o  : 26/03/2008 - mar          
   �ltima Alt.  : 18/11/2010 - Rogger */
   
   lRetn NUMBER;

BEGIN 
    -- Verifica a signific�ncia da �ltima avalia��o anterior � data passada como par�metro
    
    IF pColRetn = 0 THEN
        SELECT TPLACAUEFEVER.SGN INTO lRetn
          FROM TPLACAUEFEVER
         WHERE TPLACAUEFEVER.IDEPLACAUEFE = pIdePlaCauEfe
           AND TPLACAUEFEVER.ULTAVL <> 0;
     ELSE
        SELECT TPLACAUEFEVER.IDEGRSSGN INTO lRetn
          FROM TPLACAUEFEVER
         WHERE TPLACAUEFEVER.IDEPLACAUEFE = pIdePlaCauEfe
           AND TPLACAUEFEVER.ULTAVL <> 0;
     END IF;

    RETURN lRetn;
END;
/


CREATE OR REPLACE 
FUNCTION RetornarUnidadesPorUsuario(pIdeUsu NUMBER)
  RETURN  OBJECT_TEMPUNIUSU_TABLE
AS

/*  Fun��o      : RetornarUnidadesPorUsuario
    Prop�sito   : Retorna as Unidades Gerenciais do Usu�rio
    Par�metros  : pIdeUsu - Identificador do Usu�rio
    Retorno     : Retorna o IdeUni, Sig, UniVir e UpdDta das Unidades do Usu�rio
    Cria��o     : 31/10/2012 - Lux
Ult. Modifica��o: 18/04/2016 - Leonardo Lage*/

lOrd INT;

CURSOR CursorUnisUsu(cpIdeUsu NUMBER) IS

SELECT vUni.IDEUNI, 
               vUni.SIG, 
               vUni.UNIVIR, 
               MAX(ABS(vUni.UpdDta)) UPDDTA
         FROM (SELECT tUni.IdeUni, 
                      tUni.Sig, 
                      tUni.UniVir, 
                      vUsuUni.UpdDta 
                 FROM tUni INNER JOIN tUniTyp ON tUni.IdeUniTyp = tUniTyp.IdeUniTyp 
                           INNER JOIN (SELECT tUsuUni.IdeUni, 
                                              tUsuUni.UpdDta 
                                         FROM tUsuUni 
                                        WHERE tUsuUni.IdeUsu = cpIdeUsu 
                                        UNION  
                                       SELECT tGruUsuUni.IdeUni, 
                                              tGruUsuUni.UpdDta 
                                         FROM tGruUsuUni INNER JOIN tGruUsu ON tGruUsuUni.IdeGruUsu = tGruUsu.IdeGruUsu 
                                                         INNER JOIN tUsuGruUsu ON tGruUsu.IdeGruUsu = tUsuGruUsu.IdeGruUsu 
                                        WHERE tUsuGruUsu.IdeUsu = cpIdeUsu 
                                        ) vUsuUni ON tUni.IdeUni = vUsuUni.IdeUni 
                WHERE tUniTyp.Typ = 1) vUni
         GROUP BY vUni.Sig, 
                  vUni.IdeUni,
                  vUni.UniVir
         ORDER BY vUni.Sig;



lCursorUnisUsu CursorUnisUsu%ROWTYPE;
lOBJECT_TEMPUNIUSU_TABLE OBJECT_TEMPUNIUSU_TABLE := OBJECT_TEMPUNIUSU_TABLE();

BEGIN
    lOrd := 1;
    
    OPEN CursorUnisUsu(pIdeUsu);
    
    LOOP

        FETCH CursorUnisUsu INTO lCursorUnisUsu;
        EXIT WHEN CursorUnisUsu%NOTFOUND;
        
        lOBJECT_TEMPUNIUSU_TABLE.extend;
        lOBJECT_TEMPUNIUSU_TABLE(lOBJECT_TEMPUNIUSU_TABLE.Last) := OBJECT_TEMPUNIUSU(lCursorUnisUsu.IdeUni, lCursorUnisUsu.Sig, lCursorUnisUsu.UniVir, lCursorUnisUsu.UpdDta, lOrd);
        
        lOrd := lOrd + 1;

    END LOOP;

    CLOSE CursorUnisUsu;

    RETURN lOBJECT_TEMPUNIUSU_TABLE;

END;
/

CREATE OR REPLACE 
FUNCTION RETORNARUSUARIOSACOMPANHAMENTO(pIdeUsu IN NUMBER)
  RETURN tabletmpide

/* Fun��o     : RetornarUsuariosAcompanhamentos
   Prop�sito  : Retorna todos os acompanhamentos que um usu�rio pode alterar
   Par�metros : pIdeUsu-Identificador do usu�rio que acessa a informa��o
   Cria��o    : 17/10/2006 - mar
   �ltima Alt.: 10/09/2009 - rangel */

AS
    CURSOR CursorAcompanhamentos(cIdeUsu NUMBER) IS
    SELECT TACO.IDEACO
       FROM TACO INNER JOIN TUSUACO ON TACO.IDEACO = TUSUACO.IDEACO
       WHERE DECODE(CIDEUSU, 0, 0, TUSUACO.IDEUSU) = DECODE(CIDEUSU, 0, 0, CIDEUSU)
    UNION
    SELECT TACO.IDEACO
       FROM TACO INNER JOIN TIND ON TACO.IDEIND = TIND.IDEIND
                 INNER JOIN TGRPIND ON TGRPIND.IDEGRPIND = TIND.IDEGRPIND
                 INNER JOIN TGRPINDUSU  ON TGRPIND.IDEGRPIND = TGRPINDUSU.IDEGRPIND
       WHERE DECODE(CIDEUSU, 0, 0, TGRPINDUSU.IDEUSU) = DECODE(CIDEUSU, 0, 0, CIDEUSU);

    lIdeAco             NUMBER(13);

    lTempTableIde tabletmpide := tabletmpide();
BEGIN
    OPEN CursorAcompanhamentos(pIdeUsu);
    LOOP
        FETCH CursorAcompanhamentos INTO lIdeAco;
        EXIT WHEN CursorAcompanhamentos%NOTFOUND;

        lTempTableIde.extend;
        lTempTableIde(lTempTableIde.Last) := typetmpide(lIdeAco);
    END LOOP;
    CLOSE CursorAcompanhamentos;

    RETURN lTempTableIde;
END;
/


CREATE OR REPLACE 
FUNCTION RetornarVerificacaoRevLA(pIdeEprLicAmb NUMBER, pTipInfo NUMBER)

/* Função     : RetornarVerificacaoRevLA
   Propósito  : Retorna a liceça atual de um Empreendimento de todos ou um determinado tipo
   Parâmetros : pIdeEprLicAmb - Ide de um Empreendimento
              : pTipInfo - Tipo da Informação
   Criação    : 06/05/2010 - Flávio / Eduardo César
   Última Alt.: 02/07/2010 - Eduardo César */  

RETURN INTEGER IS
    lrtn            INTEGER;
    lIdeLicRevAtual NUMBER;
    lIdeLicAnt      NUMBER;
    lTipLic         NUMBER;  /*RLI*/
    lVenFob         DATE;
    lDatObt         DATE;
    lDatVal         DATE;
    
BEGIN 
    
    lTipLic := 3;  /* RLI */
    IF pTipInfo IS NULL OR pIdeEprLicAmb IS NULL THEN
        RETURN NULL;
    ELSE
        IF pTipInfo > 2 THEN
            lTipLic := 6; /* RLO */
        END IF;
        
        SELECT RETORNARLICENCAATUAL(pIdeEprLicAmb,NULL,lTipLic,1,NULL,NULL) INTO lIdeLicRevAtual FROM DUAL;
        
        SELECT VENFOB, DATOBT INTO lVenFob, lDatObt
          FROM TLICAMB
         WHERE IDELICAMB = lIdeLicRevAtual;
        
        IF lIdeLicRevAtual IS NULL THEN
            RETURN NULL;
        ELSE
            IF pTipInfo = 1 THEN   /* REQUERIMENTO FEITO COM DEVIDA ANTECEDENCIA */

                SELECT DATVAL INTO lDatVal
                  FROM TLICAMB
                 WHERE IDELICAMB = RETORNARLICENCAATUAL(pIdeEprLicAmb,NULL,NULL,1,'LI',lIdeLicRevAtual);

                IF lDatVal > lVenFob THEN
                    lrtn := 1;
                ELSE
                    lrtn := 0;
                END IF;
                
            ELSIF pTipInfo = 2 THEN /* LI RENOVADA DENTRO DO SEU PRAZO DE VALIDADE */
            
                SELECT DATVAL INTO lDatVal
                  FROM TLICAMB
                 WHERE IDELICAMB = RETORNARLICENCAATUAL(pIdeEprLicAmb,NULL,NULL,1,'LI',lIdeLicRevAtual);

                IF lDatVal > lDatObt THEN
                    lrtn := 1;
                ELSE
                    lrtn := 0;
                END IF;
                
            ELSIF pTipInfo = 3 THEN /* REQUERIMENTO FEITO DENTRO DO PRAZO LEGAL E/OU PREVISTO */
                SELECT DATVAL INTO lDatVal
                  FROM TLICAMB
                 WHERE IDELICAMB = RETORNARLICENCAATUAL(pIdeEprLicAmb,NULL,NULL,1,'LO',lIdeLicRevAtual);

                IF lDatVal > lVenFob THEN
                    lrtn := 1;
                ELSE
                    lrtn := 0;
                END IF;

            ELSIF pTipInfo = 4 THEN /* LO RENOVADA DENTRO DO SEU PRAZO DE VALIDADE */
                SELECT DATVAL INTO lDatVal
                  FROM TLICAMB
                 WHERE IDELICAMB = RETORNARLICENCAATUAL(pIdeEprLicAmb,NULL,NULL,1,'LO',lIdeLicRevAtual);
                 
                IF lDatVal > lDatObt THEN
                    lrtn := 1;
                ELSE
                    lrtn := 0;
                END IF;
                  
            ELSE
                RETURN NULL;
            END IF;    
        END IF;
    END IF;
    RETURN lrtn ;
END;
/


/* Função      : [TemPlanoDeRecuperacao]
    Propósito   : Retorna se tem ou não Plano de Recuperação
    Parâmetros  : pIdeSolPrb - Identificador da Solução de Problemas
    Retorno     : true - Quando existe Plano de Recuperação
                    : false - Quando não tem Plano de Recuperação
    Criação     : 13/08/2012 - Max/Kdu
    Última Alt. : 13/08/2012 - Max/Kdu */

CREATE OR REPLACE FUNCTION TemPlanoDeRecuperacao(pIdeSolPrb NUMBER) RETURN INT IS
     lTemPlanoDeRecuperacao INT;
BEGIN
    BEGIN   
        SELECT SUM(DISTINCT tFer.Prs) INTO lTemPlanoDeRecuperacao 
          FROM tFer INNER JOIN tSolPrbPas ON tFer.IdeSolPrbPas = tSolPrbPas.IdeSolPrbPas
    INNER JOIN tSolPrb ON tSolPrb.IdeSolPrb = tSolPrbPas.IdeSolPrb
         WHERE tSolPrb.IdeSolPrb = pIdeSolPrb
           AND tFer.TipFer = 8192;

    EXCEPTION WHEN NO_DATA_FOUND THEN
        lTemPlanoDeRecuperacao := NULL;
    END;

    RETURN lTemPlanoDeRecuperacao;
END;
/


CREATE OR REPLACE
FUNCTION To_Binary(pBitLength IN INTEGER,
                   pDecin IN INTEGER)
RETURN VARCHAR2
IS
lDecin INTEGER;
lNextDigit INTEGER;
lResult VARCHAR(2000);
BEGIN
lDecin := pDecin;

WHILE lDecin > 0
LOOP
lNextDigit := MOD (lDecin, 2);
lResult := TO_CHAR (lNextDigit) || lResult;
lDecin := FLOOR (lDecin / 2);
END LOOP;

WHILE LENGTH(lResult) < pBitLength
LOOP
    lResult := '0' || lResult;
END LOOP;

RETURN lResult;
END;
/


CREATE OR REPLACE 
FUNCTION To_ScientificNumber(pValue FLOAT) RETURN FLOAT AS
    lCharFormat varchar2(100);
    lBeforeValue FLOAT;
    lAfterValue FLOAT;
begin
    lCharFormat := UPPER(REPLACE(TRIM(to_char(pValue, '9.99EEEE')), '.', ','));
    
    BEGIN       
        lAfterValue := cast(SUBSTR(lCharFormat, INSTR(lCharFormat, 'E') + 1) AS FLOAT);
        lBeforeValue := cast(SUBSTR(lCharFormat, 1, INSTR(lCharFormat, 'E') - 1) AS FLOAT);
    EXCEPTION
    WHEN OTHERS THEN
        lCharFormat := REPLACE(lCharFormat, ',', '.');
        lBeforeValue := cast(SUBSTR(lCharFormat, 1, INSTR(lCharFormat, 'E') - 1) AS FLOAT);
        lAfterValue := cast(SUBSTR(lCharFormat, INSTR(lCharFormat, 'E') + 1) AS FLOAT);
    END;

    RETURN lBeforeValue * POWER(10, lAfterValue);
END;
/


CREATE OR REPLACE 
FUNCTION weekofday(pDate IN DATE) RETURN INT IS

    /* Fun��o     : WeekOfDay
       Prop�sito  : Retorna o n�mero da semana no ano (1..53) da data passada
       Par�metros : pDate-Data passada como par�metro
       Cria��o    : 03/03/2009 - mar
       �ltima Alt.: 03/03/2009 - mar */

    lAjuste     INT := 0;
    lretn       INT := 0;
BEGIN 
    IF NOT pDate IS NULL THEN
        IF TO_NUMBER(TO_CHAR(pDate, 'MM')) = 1 AND TO_NUMBER(TO_CHAR(pDate, 'IW')) >= 52 THEN
            lretn := 1;
        ELSIF TO_NUMBER(TO_CHAR(pDate, 'MM')) = 12 AND TO_NUMBER(TO_CHAR(pDate, 'IW')) = 1 THEN
            lretn := 53;
        ELSE
            IF TO_NUMBER(TO_CHAR(TO_DATE('01-01-' || TO_CHAR(pDate, 'YYYY'), 'DD-MM-YYYY'), 'IW')) <> 1 AND TO_NUMBER(TO_CHAR(TO_DATE('01-01-' || TO_CHAR(pDate, 'YYYY'), 'DD-MM-YYYY'), 'D')) <> 1 THEN
                lAjuste := 1;
            END IF;
        
            lretn := TO_NUMBER(TO_CHAR(pDate, 'IW'));
        END IF;

        IF TO_NUMBER(TO_CHAR(pDate, 'D')) = 1 AND TRUNC(pDate) <> TO_DATE('01-01-' || TO_CHAR(pDate, 'YYYY'), 'DD-MM-YYYY') THEN
            lAjuste := lAjuste + 1;
        END IF;
    END IF;

    RETURN lretn + lAjuste;
END;
/


 
/*==============================================================*/
/* ATUALIZA��O DA VERS�O DO BANCO DE DADOS                      */
/*==============================================================*/
DECLARE LVERSION DATE := TO_DATE('01-08-2018', 'DD-MM-YYYY');
        DUMMY    DATE;
        FOUND    BOOLEAN;
		VERSAO 	 NVARCHAR2(10) := '1808.1';
 
    CURSOR CURSORVERSAO(CPVERSION DATE) IS
    SELECT VRS FROM TVRS WHERE VRS = LVERSION AND NUMVRS = VERSAO;
BEGIN
    OPEN  CURSORVERSAO(LVERSION);
    FETCH CURSORVERSAO INTO DUMMY;
    FOUND := CURSORVERSAO%FOUND;
    CLOSE CURSORVERSAO;
    IF FOUND THEN
        UPDATE TVRS SET DTAFNC = SYSDATE WHERE VRS = LVERSION AND NUMVRS = VERSAO;
    ELSE
        INSERT INTO TVRS (VRS, DTAFNC , NUMVRS) VALUES (LVERSION, SYSDATE , VERSAO);
    END IF;
END;
/

BEGIN
dbms_output.put_line('1808.1');
END;
/

