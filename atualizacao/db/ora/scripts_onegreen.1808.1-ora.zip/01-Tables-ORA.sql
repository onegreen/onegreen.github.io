

BEGIN
	dbms_output.put_line('CASO 302');
END;
/

/* Criando estrutura para permitir criação de Tags */
/*********************************************************/
/*********************   CASO 302  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lOrd NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20180319-302';

	IF lExists = 0 THEN
/*==============================================================*/
		SELECT MAX(ORD) + 1 INTO lOrd
		  FROM TREGSIS
		 WHERE TIP = 1;
		 
		INSERT INTO TREGSIS (IDEREGSIS, IDEMOD, CODINT, NME, ORD, TIP, UPDTME)
			 SELECT SEQREGSIS.NEXTVAL, IDEMOD, 'Remover tags do cadastro', 'Remover tags do cadastro', lOrd, 1, SYSDATE
			   FROM TMOD
			  WHERE MODNME = 'Onegreen';

/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQCMPTAG START WITH 1110000000000 INCREMENT BY 1';

		/*==============================================================*/
		/* TABLE: TCMPTAG                                               */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE TABLE TCMPTAG  (
		   IDECMPTAG            NUMBER(13)                      NOT NULL,
		   UPDTME               DATE                            NOT NULL
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TCMPTAG
		   ADD CONSTRAINT TCMPTAG_PK PRIMARY KEY (IDECMPTAG)';
/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQTAGAMB START WITH 1110000000000 INCREMENT BY 1';

		/*==============================================================*/
		/* TABLE: TTAGAMB                                               */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE TABLE TTAGAMB  (
		   IDETAGAMB            NUMBER(13)                      NOT NULL,
		   IDEEMP               NUMBER(13),
		   NME                  VARCHAR2(100)                   NOT NULL,
		   UPDTME               DATE                            NOT NULL
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TTAGAMB
		   ADD CONSTRAINT TTAGAMB_PK PRIMARY KEY (IDETAGAMB)';

		/*==============================================================*/
		/* INDEX: TEMP2TTAGAMB_FK                                       */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TEMP2TTAGAMB_FK ON TTAGAMB (
		   IDEEMP ASC
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TTAGAMB
		   ADD CONSTRAINT TEMP2TTAGAMB_FK FOREIGN KEY (IDEEMP)
			  REFERENCES TEMP (IDEEMP)';
/*==============================================================*/	  
		/*==============================================================*/
		/* TABLE: TCMPTAGAMB                                            */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE TABLE TCMPTAGAMB  (
		   IDECMPTAG            NUMBER(13),
		   IDETAGAMB            NUMBER(13)
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TCMPTAGAMB
		   ADD CONSTRAINT TCMPTAG2TCMPTAGAMB_FK FOREIGN KEY (IDECMPTAG)
			  REFERENCES TCMPTAG (IDECMPTAG)';

		EXECUTE IMMEDIATE 'ALTER TABLE TCMPTAGAMB
		   ADD CONSTRAINT TTAGAMB2TCMPTAGAMB_FK FOREIGN KEY (IDETAGAMB)
			  REFERENCES TTAGAMB (IDETAGAMB)';
/*==============================================================*/
		/*==============================================================*/
		/* TABLE: TEPRLICAMB                                            */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'ALTER TABLE TEPRLICAMB
			ADD IDECMPTAG DECIMAL(13) NULL';
		
		/*==============================================================*/
		/* INDEX: TCMPTAG2TEPRLICAMB_FK                                 */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TCMPTAG2TEPRLICAMB_FK ON TEPRLICAMB (
		   IDECMPTAG ASC
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TEPRLICAMB
		   ADD CONSTRAINT TCMPTAG2TEPRLICAMB_FK FOREIGN KEY (IDECMPTAG)
			  REFERENCES TCMPTAG (IDECMPTAG)';
/*==============================================================*/
		/*==============================================================*/
		/* TABLE: TLICAMB                                               */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'ALTER TABLE TLICAMB
			ADD IDECMPTAG DECIMAL(13) NULL';
		
		/*==============================================================*/
		/* INDEX: TCMPTAG2TLICAMB_FK                                    */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TCMPTAG2TLICAMB_FK ON TLICAMB (
		   IDECMPTAG ASC
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TLICAMB
		   ADD CONSTRAINT TCMPTAG2TLICAMB_FK FOREIGN KEY (IDECMPTAG)
			  REFERENCES TCMPTAG (IDECMPTAG)';
/*==============================================================*/
		/*==============================================================*/
		/* TABLE: TPACTAR                                               */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'ALTER TABLE TPACTAR
			ADD IDECMPTAG DECIMAL(13) NULL';
		
		/*==============================================================*/
		/* INDEX: TCMPTAG2TPACTAR_FK                                    */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TCMPTAG2TPACTAR_FK ON TPACTAR (
		   IDECMPTAG ASC
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TPACTAR
		   ADD CONSTRAINT TCMPTAG2TPACTAR_FK FOREIGN KEY (IDECMPTAG)
			  REFERENCES TCMPTAG (IDECMPTAG)';
/*==============================================================*/
		/*==============================================================*/
		/* TABLE: TESTLICAMB                                            */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'ALTER TABLE TESTLICAMB
			ADD IDECMPTAG DECIMAL(13) NULL';
		
		/*==============================================================*/
		/* INDEX: TCMPTAG2TESTLICAMB_FK                                 */
		/*==============================================================*/
		EXECUTE IMMEDIATE 'CREATE INDEX TCMPTAG2TESTLICAMB_FK ON TESTLICAMB (
		   IDECMPTAG ASC
		)';

		EXECUTE IMMEDIATE 'ALTER TABLE TESTLICAMB
		   ADD CONSTRAINT TCMPTAG2TESTLICAMB_FK FOREIGN KEY (IDECMPTAG)
			  REFERENCES TCMPTAG (IDECMPTAG)';
/*==============================================================*/
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180319-302', SYSDATE);

		COMMIT;

	END IF;
END;
/



/*********************************************************/
/*********************** CASO 306 ************************/
/*********************************************************/

BEGIN
dbms_output.put_line('CASO 306');
END;
/

DECLARE lExists		INT;

BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20180329-306';

	IF lExists = 0 THEN
	
		EXECUTE IMMEDIATE 'ALTER TABLE TORG ADD NEWSIG NVARCHAR2(30) NULL';
		EXECUTE IMMEDIATE 'UPDATE TORG SET NEWSIG = SIG';
		EXECUTE IMMEDIATE 'ALTER TABLE TORG DROP COLUMN SIG';
		EXECUTE IMMEDIATE 'ALTER TABLE TORG ADD SIG NVARCHAR2(30) DEFAULT '' '' NOT NULL';
		EXECUTE IMMEDIATE 'UPDATE TORG SET SIG = NEWSIG';
		EXECUTE IMMEDIATE 'ALTER TABLE TORG DROP COLUMN NEWSIG';
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180329-306', SYSDATE);
		COMMIT;
	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 309');
END;
/

/* Criando permissão total para às tarefas */
/*********************************************************/
/*********************   CASO 309  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lOrd NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20180402-309';

	IF lExists = 0 THEN
/*==============================================================*/
		SELECT MAX(ORD) + 1 INTO lOrd
		  FROM TREGSIS
		 WHERE TIP = 2;
		 
		INSERT INTO TREGSIS (IDEREGSIS, IDEMOD, CODINT, NME, ORD, TIP, UPDTME)
			 SELECT SEQREGSIS.NEXTVAL, IDEMOD, 'Permissão total às tarefas_Onegreen', 'Permissão total às tarefas', lOrd, 2, SYSDATE
			   FROM TMOD
			  WHERE MODNME = 'Onegreen';
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180402-309', SYSDATE);
		COMMIT;
  
/*==============================================================*/
	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 285');
END;
/

/* Criando regra para propagação da reprogramação da Validade das Licenças para Tarefas */
/*********************************************************/
/*********************   CASO 285  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lOrd NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20180403-285';

	IF lExists = 0 THEN
/*==============================================================*/
		SELECT MAX(ORD) + 1 INTO lOrd
		  FROM TREGSIS
		 WHERE TIP = 2;
		 
		INSERT INTO TREGSIS (IDEREGSIS, IDEMOD, CODINT, NME, ORD, TIP, UPDTME)
			 SELECT SEQREGSIS.NEXTVAL, IDEMOD, 'Propagar reprogramação da Validade das Licenças para Tarefas / Condicionantes_Onegreen', 'Propagar reprogramação da Validade das Licenças para Tarefas / Condicionantes', lOrd, 2, SYSDATE
			   FROM TMOD
			  WHERE MODNME = 'Onegreen';
  
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180403-285', SYSDATE);

		COMMIT;

	END IF;
END;
/



BEGIN
	dbms_output.put_line('CASO 271');
END;
/

/* Atualização no usuário do Onegreen  */
/*********************************************************/
/*********************   CASO 271  ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lOrd NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20180404-271';

	IF lExists = 0 THEN
/*==============================================================*/
		UPDATE TUSU SET SUPADM = 0;
		BEGIN
			UPDATE TUSU SET SUPADM = 1 WHERE UPPER(NME) = 'ONEGREEN';
		EXCEPTION 
			WHEN OTHERS THEN COMMIT;
		END;
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180404-271', SYSDATE);

		COMMIT;

	END IF;
END;
/



/*********************************************************/
/*********************** CASO 320 ************************/
/*********************************************************/

BEGIN
dbms_output.put_line('CASO 320');
END;
/

DECLARE lExists		INT;

BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20180504-320';

	IF lExists = 0 THEN
	
		EXECUTE IMMEDIATE 'ALTER TABLE TESTLICAMB MODIFY (IDECONEMPRESESTAMB NULL)';

		EXECUTE IMMEDIATE 'ALTER TABLE TESTLICAMB
		   ADD CONSTRAINT TCONEMPRESESTAMB2TEST_FK FOREIGN KEY (IDECONEMPRESESTAMB)
			  REFERENCES TCONEMPRESESTAMB (IDECONEMPRESESTAMB)';

		EXECUTE IMMEDIATE 'ALTER TABLE TESTLICAMB
		   ADD CONSTRAINT TLICAMB2TEST_FK FOREIGN KEY (IDELICAMB)
			  REFERENCES TLICAMB (IDELICAMB)';

		EXECUTE IMMEDIATE 'ALTER TABLE TESTLICAMB
		   ADD CONSTRAINT TTIPEST2TEST_FK FOREIGN KEY (IDETIPESTLICAMB)
			  REFERENCES TTIPESTLICAMB (IDETIPESTLICAMB)';
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180504-320', SYSDATE);
		COMMIT;
	END IF;
END;
/



/*********************************************************/
/*********************** CASO 339 ************************/
/*********************************************************/

BEGIN
dbms_output.put_line('CASO 339');
END;
/

DECLARE lExists		INT;

BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '10280621-339';

	IF lExists = 0 THEN
	
		EXECUTE IMMEDIATE 'ALTER TABLE TLICAMB ADD DATLIMREN DATE';
		EXECUTE IMMEDIATE 'ALTER TABLE TLICAMB ADD DATLIMRENMAN NUMBER(1) DEFAULT 0 NOT NULL';
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('10280621-339', SYSDATE);
		COMMIT;
	END IF;
END;
/



/*********************************************************/
/*********************** CASO 345 ************************/
/*********************************************************/

BEGIN
dbms_output.put_line('CASO 345');
END;
/

DECLARE lExists		INT;

BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20180710-345';

	IF lExists = 0 THEN
	
		EXECUTE IMMEDIATE 'ALTER TABLE TOBSLICAMB ADD DATOBS DATE';
		EXECUTE IMMEDIATE 'UPDATE TOBSLICAMB SET DATOBS = DAT';
		
		INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20180710-345', SYSDATE);
		COMMIT;
	END IF;
END;
/



/*==============================================================*/
/* ATUALIZAÇÃO DA VERSÃO DO BANCO DE DADOS                      */
/*==============================================================*/
DECLARE LVERSION DATE := TO_DATE('01-08-2018', 'DD-MM-YYYY');
        DUMMY    DATE;
        FOUND    BOOLEAN;
		VERSAO 	 NVARCHAR2(10) := '1808.1';
 
    CURSOR CURSORVERSAO(CPVERSION DATE) IS
    SELECT VRS FROM TVRS WHERE VRS = LVERSION AND NUMVRS = VERSAO;
BEGIN
    OPEN  CURSORVERSAO(LVERSION);
    FETCH CURSORVERSAO INTO DUMMY;
    FOUND := CURSORVERSAO%FOUND;
    CLOSE CURSORVERSAO;
    IF FOUND THEN
        UPDATE TVRS SET DTATBL = SYSDATE WHERE VRS = LVERSION AND NUMVRS = VERSAO;
    ELSE
        INSERT INTO TVRS (VRS, DTATBL , NUMVRS) VALUES (LVERSION, SYSDATE , VERSAO);
    END IF;
END;
/

BEGIN
dbms_output.put_line('1808.1');
END;
/

