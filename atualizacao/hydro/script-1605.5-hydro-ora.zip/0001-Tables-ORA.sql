BEGIN
	dbms_output.put_line('CASO 30185');
END;
/
/*Identity da tabela TTIPDSD*/
/*********************************************************/
/********************** CASO 30185 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30185';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDETIPDSD), 1110000000000) + 1 INTO lProximoIde FROM TTIPDSD;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQTIPDSD
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30185', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30224');
END;
/
/*Identity da tabela TDSDITE*/
/*********************************************************/
/********************** CASO 30224 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30224';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDEDSDITE), 1110000000000) + 1 INTO lProximoIde FROM TDSDITE;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQDSDITE
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30224', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30194');
END;
/
/*Identity da tabela TMAP*/
/*********************************************************/
/********************** CASO 30194 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30194';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDEMAP), 1110000000000) + 1 INTO lProximoIde FROM TMAP;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQMAP
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30194', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30232');
END;
/
/*Identity da tabela TUNIMAP*/
/*********************************************************/
/********************** CASO 30232 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30232';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDEUNIMAP), 1110000000000) + 1 INTO lProximoIde FROM TUNIMAP;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQUNIMAP
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30232', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30233');
END;
/
/*Identity da tabela TMAPOBJSOLPRB*/
/*********************************************************/
/********************** CASO 30233 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30233';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDEMAPOBJSOLPRB), 1110000000000) + 1 INTO lProximoIde FROM TMAPOBJSOLPRB;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQMAPOBJSOLPRB
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30233', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30234');
END;
/
/*Identity da tabela TMAPOBJ*/
/*********************************************************/
/********************** CASO 30234 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30234';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDEMAPOBJ), 1110000000000) + 1 INTO lProximoIde FROM TMAPOBJ;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQMAPOBJ
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30234', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30235');
END;
/
/*Identity da tabela TMAPOBJESTACO*/
/*********************************************************/
/********************** CASO 30235 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30235';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDEMAPOBJESTACO), 1110000000000) + 1 INTO lProximoIde FROM TMAPOBJESTACO;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQMAPOBJESTACO
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30235', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30236');
END;
/
/*Identity da tabela TOBJEST*/
/*********************************************************/
/********************** CASO 30236 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30236';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDEOBJEST), 1110000000000) + 1 INTO lProximoIde FROM TOBJEST;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQOBJEST
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30236', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30237');
END;
/
/*Identity da tabela TPRS*/
/*********************************************************/
/********************** CASO 30237 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30237';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDEPRS), 1110000000000) + 1 INTO lProximoIde FROM TPRS;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQPRS
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30237', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30190');
END;
/
/*Identity da tabela TDTAMNGCFG*/
/*********************************************************/
/********************** CASO 30190 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30190';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDEDTAMNGCFG), 1110000000000) + 1 INTO lProximoIde FROM TDTAMNGCFG;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQDTAMNGCFG
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30190', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30387');
END;
/
/*Altera��o do tamanho do campo FLENME da tabela TMAP*/
/*********************************************************/
/********************** CASO 30387 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30387';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TMAP MODIFY FLENME VARCHAR2(255)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30387', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30362');
END;
/
/*TipObj e IdeObj na tEprLicAmb*/
/*********************************************************/
/********************** CASO 30362 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30362';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TEPRLICAMB ADD TYPOBJ NVARCHAR2(200)';

EXECUTE IMMEDIATE 'ALTER TABLE TEPRLICAMB ADD IDEOBJ NUMBER(13)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30362', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30663');
END;
/
/*Tabelas para o Modelo de Gr�ficos*/
/*********************************************************/
/********************** CASO 30663 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30663';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'create sequence SEQMDLGRA
increment by 1
start with 1110000000000';

EXECUTE IMMEDIATE 'create sequence SEQFRMCAL
increment by 1
start with 1110000000000';

EXECUTE IMMEDIATE 'create sequence SEQMDLSECGRA
increment by 1
start with 1110000000000';

EXECUTE IMMEDIATE 'create sequence SEQFRMCALITE
increment by 1
start with 1110000000000';

/*==============================================================*/
/* Table: TFRMCAL                                               */
/*==============================================================*/
EXECUTE IMMEDIATE 'create table TFRMCAL  (
   IDEFRMCAL            NUMBER(13)                      not null,
   DSCCALC              VARCHAR2(4000),
   FRMCAL               NUMBER(1)                       not null,
   INDOBG               NUMBER(1)                       not null,
   UPDTME               DATE                            not null
)';

EXECUTE IMMEDIATE 'alter table TFRMCAL
   add constraint PK_TFRMCAL primary key (IDEFRMCAL)';

/*==============================================================*/
/* Table: TFRMCALITE                                            */
/*==============================================================*/
EXECUTE IMMEDIATE 'create table TFRMCALITE  (
   IDEFRMCALITE         NUMBER(13)                      not null,
   IDEFRMCAL            NUMBER(13)                      not null,
   IDEACO               NUMBER(13),
   ORG                  int                             not null,
   ATRMES               int                             not null,
   FRMAGPITE            NUMBER(1)                       not null,
   UPDTME               DATE                            not null
)';

EXECUTE IMMEDIATE 'alter table TFRMCALITE
   add constraint PK_TFRMCALITE primary key (IDEFRMCALITE)';

/*==============================================================*/
/* Index: TFRMCAL2TFRMCALITE_FK                                 */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TFRMCAL2TFRMCALITE_FK on TFRMCALITE (
   IDEFRMCAL ASC
)';

/*==============================================================*/
/* Index: TACO2TFRMCALITE_FK                                    */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TACO2TFRMCALITE_FK on TFRMCALITE (
   IDEACO ASC
)';

/*==============================================================*/
/* Table: TMDLGRA                                               */
/*==============================================================*/
EXECUTE IMMEDIATE 'create table TMDLGRA  (
   IDEMDLGRA            NUMBER(13)                      not null,
   IDEEMP               NUMBER(13)                      not null,
   IDEACO               NUMBER(13),
   NME                  VARCHAR2(50)                    not null,
   ORDCMP               NUMBER(1)                       not null,
   TIPGRA               NUMBER(1)                       not null,
   ESTSEC               NUMBER(1)                       not null,
   NMEAY1               VARCHAR2(50),
   NMEAY2               VARCHAR2(50),
   POSLEG               NUMBER(1)                       not null,
   SHWGRAAXX            NUMBER(1)                       not null,
   SHWGRAAXY            NUMBER(1)                       not null,
   COR                  VARCHAR2(50)                    not null,
   ATV                  NUMBER(1)                       not null,
   INCACOCMP            NUMBER(1)                       not null,
   PER                  NUMBER(1)                       not null,
   UPDTME               DATE                            not null
)';

EXECUTE IMMEDIATE 'alter table TMDLGRA
   add constraint PK_TMDLGRA primary key (IDEMDLGRA)';

/*==============================================================*/
/* Index: TACO2TMDLGRA_FK                                       */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TACO2TMDLGRA_FK on TMDLGRA (
   IDEACO ASC
)';

/*==============================================================*/
/* Table: TMDLSECGRA                                            */
/*==============================================================*/
EXECUTE IMMEDIATE 'create table TMDLSECGRA  (
   IDEMDLSECGRA         NUMBER(13)                      not null,
   IDEMDLGRA            NUMBER(13)                      not null,
   IDEFRMCAL            NUMBER(13),
   IDEACO               NUMBER(13),
   NME                  VARCHAR2(50)                    not null,
   TIPSEC               NUMBER(1)                       not null,
   FRMAGP               NUMBER(1)                       not null,
   SHWLEG               NUMBER(1)                       not null,
   SHWROT               NUMBER(1)                       not null,
   ESTSEC               VARCHAR2(50)                    not null,
   COR                  VARCHAR2(50)                    not null,
   CORFAR               NUMBER(1)                       not null,
   DSCPER               VARCHAR2(50),
   ACM                  NUMBER(1)                       not null,
   AXY                  VARCHAR2(1)                     not null,
   ATRMES               int                             not null,
   ORG                  int                             not null,
   ORD                  int                             not null,
   UPDTME               DATE                            not null
)';

EXECUTE IMMEDIATE 'alter table TMDLSECGRA
   add constraint PK_TMDLSECGRA primary key (IDEMDLSECGRA)';

/*==============================================================*/
/* Index: TMDLGRA2TMDLSECGRA_FK                                 */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TMDLGRA2TMDLSECGRA_FK on TMDLSECGRA (
   IDEMDLGRA ASC
)';

/*==============================================================*/
/* Index: TFRMCAL2TMDLSECGRA_FK                                 */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TFRMCAL2TMDLSECGRA_FK on TMDLSECGRA (
   IDEFRMCAL ASC
)';

/*==============================================================*/
/* Index: TACO2TMDLSECGRA_FK                                    */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TACO2TMDLSECGRA_FK on TMDLSECGRA (
   IDEACO ASC
)';

EXECUTE IMMEDIATE 'alter table TFRMCALITE
   add constraint TACO2TFRMCALITE_FK foreign key (IDEACO)
      references TACO (IDEACO)';

EXECUTE IMMEDIATE 'alter table TFRMCALITE
   add constraint TFRMCAL2TFRMCALITE_FK foreign key (IDEFRMCAL)
      references TFRMCAL (IDEFRMCAL)';

EXECUTE IMMEDIATE 'alter table TMDLGRA
   add constraint TACO2TMDLGRA_FK foreign key (IDEACO)
      references TACO (IDEACO)';

EXECUTE IMMEDIATE 'alter table TMDLSECGRA
   add constraint TACO2TMDLSECGRA_FK foreign key (IDEACO)
      references TACO (IDEACO)';

EXECUTE IMMEDIATE 'alter table TMDLSECGRA
   add constraint TFRMCAL2TMDLSECGRA_FK foreign key (IDEFRMCAL)
      references TFRMCAL (IDEFRMCAL)';

EXECUTE IMMEDIATE 'alter table TMDLSECGRA
   add constraint TMDLGRA2TMDLSECGRA_FK foreign key (IDEMDLGRA)
      references TMDLGRA (IDEMDLGRA)';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30663', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 31256');
END;
/
/*Tamanho da coluna NME da tabela TAGDPAR*/
/*********************************************************/
/********************** CASO 31256 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '31256';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TAGDPAR MODIFY NME NVARCHAR2(100)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('31256', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 28088');
END;
/
/*Index TBCKLOGPRJ2TSOLPRB_FK na tabela TSOLPRB*/
/*********************************************************/
/********************** CASO 28088 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '28088';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT COUNT(1) INTO lExists 
FROM USER_INDEXES 
WHERE UPPER(INDEX_NAME) = 'TBCKLOGPRJ2TSOLPRB_FK';

IF lExists = 0 THEN
	EXECUTE IMMEDIATE 'CREATE INDEX TBCKLOGPRJ2TSOLPRB_FK ON TSOLPRB (IDEBCKLOGPRJ ASC)';
END IF;

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('28088', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30017');
END;
/
/*Identity da tabela TDTAMNGITE*/
/*********************************************************/
/********************** CASO 30017 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30017';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDEDTAMNGITE), 1110000000000) + 1 INTO lProximoIde FROM TDTAMNGITE;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQDTAMNGITE
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30017', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 30977');
END;
/
/*Coluna ATV da Tabela TPLAACO*/
/*********************************************************/
/********************** CASO 30977 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '30977';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TPLAACO ADD ATV NUMBER(1) DEFAULT 1 NOT NULL';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('30977', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 32162');
END;
/
/*Identity da Tabela TGRUUSUOPESIS*/
/*********************************************************/
/********************** CASO 32162 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '32162';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDEGRUUSUOPESIS), 1110000000000) + 1 INTO lProximoIde FROM TGRUUSUOPESIS;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQGRUUSUOPESIS
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('32162', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 36697');
END;
/
/*Adicionar coluna CTRNME na TOPESIS*/
/*********************************************************/
/********************** CASO 36697 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '36697';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		DECLARE
   lExistsColuna INT;
BEGIN
	SELECT COUNT(1) INTO lExistsColuna
	FROM USER_TAB_COLUMNS
	WHERE UPPER (TABLE_NAME) = 'TOPESIS'
	AND UPPER (COLUMN_NAME) = 'CTRNME' ;

    IF lExistsColuna = 0 THEN
		EXECUTE IMMEDIATE 'ALTER TABLE TOPESIS ADD CTRNME VARCHAR2(100) NULL';
    END IF;

END;

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('36697', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 31799');
END;
/
/*Identity da Tabela TUSUOPESIS*/
/*********************************************************/
/********************** CASO 31799 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '31799';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDEUSUOPESIS), 1110000000000) + 1 INTO lProximoIde FROM TUSUOPESIS;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQUSUOPESIS
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('31799', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 31798');
END;
/
/*Identity da Tabela TOPESIS*/
/*********************************************************/
/********************** CASO 31798 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '31798';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		SELECT NVL(MAX(IDEOPESIS), 1110000000000) + 1 INTO lProximoIde FROM TOPESIS;
		EXECUTE IMMEDIATE '
		CREATE SEQUENCE SEQOPESIS
		START WITH ' || TO_CHAR(lProximoIde) || '
		INCREMENT BY 1';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('31798', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 31916');
END;
/
/*Coluna ACMDIM da Tabela TUNIMED*/
/*********************************************************/
/********************** CASO 31916 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '31916';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TUNIMED ADD ACMDIM NUMBER(1) NULL';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('31916', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 32733');
END;
/
/*Adicionando IDEMDLGRA na TACO*/
/*********************************************************/
/********************** CASO 32733 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '32733';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TACO ADD IDEMDLGRA NUMBER(13)';
  
/*==============================================================*/
/* INDEX: TMDLGRA2TACO_FK                                       */
/*==============================================================*/
EXECUTE IMMEDIATE '
CREATE INDEX TMDLGRA2TACO_FK ON TACO (
   IDEMDLGRA ASC
)';

EXECUTE IMMEDIATE '
ALTER TABLE TACO
   ADD CONSTRAINT TMDLGRA2TACO_FK FOREIGN KEY (IDEMDLGRA)
      REFERENCES TMDLGRA (IDEMDLGRA)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('32733', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 32284');
END;
/
/*Adicionar IDEEMP na tabela TTIPACOIND*/
/*********************************************************/
/********************** CASO 32284 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '32284';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TTIPACOIND ADD IDEEMP NUMBER(13) NULL';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('32284', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 32418');
END;
/
/*Setar IDEEMP da tabela TTIPACOIND*/
/*********************************************************/
/********************** CASO 32418 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
      lIdeEmp NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '32418';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
  SELECT IDEEMP INTO lIdeEmp
         FROM TEMP 
         WHERE ROWNUM = 1 ORDER BY IDEEMP ASC;
         
  UPDATE TTIPACOIND  
     SET IDEEMP = lIdeEmp
     WHERE TTIPACOIND.IDEEMP IS NULL;
    

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('32418', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 31920');
END;
/
/*Tabelas para Vis�o*/
/*********************************************************/
/********************** CASO 31920 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '31920';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'create sequence SEQVIS
increment by 1
start with 1110000000000';

EXECUTE IMMEDIATE 'create sequence SEQVISACO
increment by 1
start with 1110000000000';

/*==============================================================*/
/* Table: TVIS                                                  */
/*==============================================================*/
EXECUTE IMMEDIATE 'create table TVIS  (
   IDEVIS               NUMBER(13)                      not null,
   IDEUSU               NUMBER(13)                      not null,
   IDEPLAGES            NUMBER(13)                      not null,
   IDEUNI               NUMBER(13)                      not null,
   NME                  NVARCHAR2(100)                  not null,
   DEF                  NUMBER(1)                       not null,
   FRE                  NUMBER(1)                       not null,
   DATCRI               DATE                            not null,
   FRMVIS               NUMBER(1)                       not null,
   TIP                  NUMBER(1)                       not null,
   JSNFLT               NCLOB,
   JSNDSD               NCLOB,
   UPDTME               DATE                            not null
)';

EXECUTE IMMEDIATE 'alter table TVIS
   add constraint PK_TVIS primary key (IDEVIS)';

/*==============================================================*/
/* Index: TUSU2TVIS_FK                                          */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TUSU2TVIS_FK on TVIS (
   IDEUSU ASC
)';

/*==============================================================*/
/* Index: TPLAGES2TVIS_FK                                       */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TPLAGES2TVIS_FK on TVIS (
   IDEPLAGES ASC
)';

/*==============================================================*/
/* Index: TUNI2TVIS_FK                                          */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TUNI2TVIS_FK on TVIS (
   IDEUNI ASC
)';

/*==============================================================*/
/* Table: TVISACO                                               */
/*==============================================================*/
EXECUTE IMMEDIATE 'create table TVISACO  (
   IDEVISACO            NUMBER(13)                      not null,
   IDEVIS               NUMBER(13)                      not null,
   IDEIND               NUMBER(13)                      not null,
   IDEACO               NUMBER(13)                      not null,
   REF                  NVARCHAR2(400)                  not null,
   JSNDSD               NCLOB,
   UPDTME               DATE                            not null
)';

EXECUTE IMMEDIATE 'alter table TVISACO
   add constraint PK_TVISACO primary key (IDEVISACO)';

/*==============================================================*/
/* Index: TACO2TVISACO_FK                                       */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TACO2TVISACO_FK on TVISACO (
   IDEACO ASC
)';

/*==============================================================*/
/* Index: TVIS2TVISACO_FK                                       */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TVIS2TVISACO_FK on TVISACO (
   IDEVIS ASC
)';

/*==============================================================*/
/* Index: TIND2TVISACO_FK                                       */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TIND2TVISACO_FK on TVISACO (
   IDEIND ASC
)';

EXECUTE IMMEDIATE 'alter table TVIS
   add constraint TPLAGES2TVIS_FK foreign key (IDEPLAGES)
      references TPLAGES (IDEPLAGES)';

EXECUTE IMMEDIATE 'alter table TVIS
   add constraint TUNI2TVIS_FK foreign key (IDEUNI)
      references TUNI (IDEUNI)';

EXECUTE IMMEDIATE 'alter table TVIS
   add constraint TUSU2TVIS_FK foreign key (IDEUSU)
      references TUSU (IDEUSU)';

EXECUTE IMMEDIATE 'alter table TVISACO
   add constraint TACO2TVISACO_FK foreign key (IDEACO)
      references TACO (IDEACO)';

EXECUTE IMMEDIATE 'alter table TVISACO
   add constraint TIND2TVISACO_FK foreign key (IDEIND)
      references TIND (IDEIND)';

EXECUTE IMMEDIATE 'alter table TVISACO
   add constraint TVIS2TVISACO_FK foreign key (IDEVIS)
      references TVIS (IDEVIS)';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('31920', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 33145');
END;
/
/*Alterar nome da Coluna da TUNIMED.ACMDIM para FRMACMAUT*/
/*********************************************************/
/********************** CASO 33145 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '33145';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TUNIMED DROP COLUMN ACMDIM';

EXECUTE IMMEDIATE 'ALTER TABLE TUNIMED ADD FRMACMAUT NUMBER(1) DEFAULT 0 NOT NULL';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('33145', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 33146');
END;
/
/*Adicionar coluna FRMACMAUT na TIND*/
/*********************************************************/
/********************** CASO 33146 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '33146';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TIND ADD FRMACMAUT NUMBER(1) NULL';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('33146', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 33147');
END;
/
/*Adicionar coluna FRMACMAUT na TACO*/
/*********************************************************/
/********************** CASO 33147 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '33147';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TACO	ADD FRMACMAUT NUMBER(1) NULL';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('33147', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 33095');
END;
/
/*Cria��o das colunas para indicar se a �rea de Reultado e Indicador Base foram criados automaticamente*/
/*********************************************************/
/********************** CASO 33095 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '33095';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TGRUIND ADD CRIAUT NUMBER(1) DEFAULT 0 NOT NULL';

EXECUTE IMMEDIATE 'ALTER TABLE TIND ADD CRIAUT NUMBER(1) DEFAULT 0 NOT NULL ';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('33095', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 31446');
END;
/
/*IdeLicAmbRel na tLicAmb*/
/*********************************************************/
/********************** CASO 31446 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '31446';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		
EXECUTE IMMEDIATE'ALTER TABLE TLICAMB ADD IDELICAMBREL NUMBER(13)';

EXECUTE IMMEDIATE'CREATE INDEX TLICAMB_X1 ON TLICAMB (
   IDELICAMB ASC,
   IDELICAMBREL ASC
)';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('31446', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 33348');
END;
/
/*Adicionar coluna STTCFG na TEMP*/
/*********************************************************/
/********************** CASO 33348 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '33348';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TEMP ADD STTCFG NUMBER(1) DEFAULT 1 NOT NULL';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('33348', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 33392');
END;
/
/*Adicionar coluna VLR na TPLNCONEMP*/
/*********************************************************/
/********************** CASO 33392 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '33392';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TPLNCONEMP ADD VLR FLOAT NULL';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('33392', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 33161');
END;
/
/*Criar tabela TMODIMPEXC*/
/*********************************************************/
/********************** CASO 33161 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '33161';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQMODIMPEXC
INCREMENT BY 1
START WITH 1110000000000';


/*==============================================================*/
/* TABLE: TMODIMPEXC                                            */
/*==============================================================*/
EXECUTE IMMEDIATE 'CREATE TABLE TMODIMPEXC  (
   IDEMODIMPEXC         NUMBER(13)                      NOT NULL,
   IDEUNI               NUMBER(13)                      NOT NULL,
   NME                  NVARCHAR2(100)                  NOT NULL,
   FRMIMPEXC            NUMBER(1)                       NOT NULL,
   ABAPLA               INT,
   COLIND               NVARCHAR2(40)                   NOT NULL,
   COLDAT               NVARCHAR2(40),
   COLVAL               NVARCHAR2(40)                   NOT NULL,
   LINIGN               INT,
   PUB                  NUMBER(1)                      DEFAULT 0 NOT NULL,
   UPDTME               DATE                            NOT NULL
)';

EXECUTE IMMEDIATE 'ALTER TABLE TMODIMPEXC
   ADD CONSTRAINT PK_TMODIMPEXC PRIMARY KEY (IDEMODIMPEXC)';

/*==============================================================*/
/* INDEX: TUNI2TMODIMPEXC_FK                                    */
/*==============================================================*/
EXECUTE IMMEDIATE 'CREATE INDEX TUNI2TMODIMPEXC_FK ON TMODIMPEXC (
   IDEUNI ASC
)';

EXECUTE IMMEDIATE 'ALTER TABLE TMODIMPEXC
   ADD CONSTRAINT TUNI2TMODIMPEXC_FK FOREIGN KEY (IDEUNI)
      REFERENCES TUNI (IDEUNI)
      ON DELETE CASCADE';

	  

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('33161', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 33701');
END;
/
/*Adicionar coluna TIPIMP na TMODIMPEXC*/
/*********************************************************/
/********************** CASO 33701 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '33701';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TMODIMPEXC ADD TIPIMP NUMBER(1) NOT NULL' ;

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('33701', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 33112');
END;
/
/*Inserts da TSIS*/
/*********************************************************/
/********************** CASO 33112 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
  idesis number(13);
  countMeetings number(13);
  countResults number(13);
  countActions number(13);

BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '33112';

	IF lExists = 0 THEN

  
/*==============================================================*/

  select max(idesis) into idesis from tsis;
  
  select count(1) into countMeetings from TSIS where intnme = 'meetings';
  select count(1) into countResults from TSIS where intnme = 'results';
  select count(1) into countActions from TSIS where intnme = 'actions';
  
  if countMeetings = 0 then
    idesis := idesis + 1;
    INSERT INTO tsis (idesis, nme, des, intnme, extsys, shw, updtme, pub) VALUES (idesis, 'MEETINGs', '', 'meetings', 0, 1, sysdate, 1);
  end if;
  
  if countResults = 0 then
    idesis := idesis + 1;
    INSERT INTO tsis (idesis, nme, des, intnme, extsys, shw, updtme, pub) VALUES (idesis, 'RESULTs', '', 'results', 0, 1, sysdate, 1);
  end if;
  
  if countActions = 0 then
    idesis := idesis + 1;
    INSERT INTO tsis (idesis, nme, des, intnme, extsys, shw, updtme, pub) VALUES (idesis, 'ACTIONs', '', 'actions', 0, 1, sysdate, 1);
  end if;



/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('33112', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 34303');
END;
/
/*Cria��o das tabelas para configura��od e um programa de resultado*/
/*********************************************************/
/********************** CASO 34303 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '34303';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQPGRRST
INCREMENT BY 1
START WITH 1110000000000';


/*==============================================================*/
/* TABLE: TPGRRST                                               */
/*==============================================================*/
EXECUTE IMMEDIATE 'CREATE TABLE TPGRRST  (
   IDEPGRRST            NUMBER(13)                      NOT NULL,
   IDEPLAGES            NUMBER(13)                      NOT NULL,
   SIG                  NVARCHAR2(15)                   NOT NULL,
   DES                  NVARCHAR2(50)                   NOT NULL,
   FORCLC               NUMBER(1)                      DEFAULT 0 NOT NULL,
   UPDTME               DATE                            NOT NULL
)';

EXECUTE IMMEDIATE 'ALTER TABLE TPGRRST
   ADD CONSTRAINT PK_TPGRRST PRIMARY KEY (IDEPGRRST)';

/*==============================================================*/
/* INDEX: TPLAGES2TPGRRST_FK                                    */
/*==============================================================*/
EXECUTE IMMEDIATE 'CREATE INDEX TPLAGES2TPGRRST_FK ON TPGRRST (
   IDEPLAGES ASC
)';

EXECUTE IMMEDIATE 'ALTER TABLE TPGRRST
   ADD CONSTRAINT TPLAGES2TPGRRST_FK FOREIGN KEY (IDEPLAGES)
      REFERENCES TPLAGES (IDEPLAGES)
      ON DELETE CASCADE';


	  
EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQPGRRSTITE
INCREMENT BY 1
START WITH 1110000000000';


/*==============================================================*/
/* TABLE: TPGRRSTITE                                            */
/*==============================================================*/
EXECUTE IMMEDIATE 'CREATE TABLE TPGRRSTITE  (
   IDEPGRRSTITE        NUMBER(13)                      NOT NULL,
   IDEPGRRST            NUMBER(13),
   COLCOR               NUMBER(1),
   FRMCLC               NUMBER(1),
   PERATN               FLOAT,
   NTA                  FLOAT,
   UPDTME               DATE                            NOT NULL
)';

EXECUTE IMMEDIATE 'ALTER TABLE TPGRRSTITE
   ADD CONSTRAINT PK_TPGRRSTITE PRIMARY KEY (IDEPGRRSTITE)';

/*==============================================================*/
/* INDEX: TPGRRST2TPGRRSTITE_FK2                                */
/*==============================================================*/
EXECUTE IMMEDIATE 'CREATE INDEX TPGRRST2TPGRRSTITE_FK2 ON TPGRRSTITE (
   IDEPGRRST ASC
)';

EXECUTE IMMEDIATE 'ALTER TABLE TPGRRSTITE
   ADD CONSTRAINT TPGRRST2TPGRRSTITE_FK FOREIGN KEY (IDEPGRRST)
      REFERENCES TPGRRST (IDEPGRRST)
      ON DELETE CASCADE';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('34303', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 34747');
END;
/
/*Cria��o das tabelas para configura��o de um programa de resultados para um usu�rio*/
/*********************************************************/
/********************** CASO 34747 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '34747';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQPGRRSTUSU
INCREMENT BY 1
START WITH 1110000000000';


EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQPGRRSTUSUACO
INCREMENT BY 1
START WITH 1110000000000';


/*==============================================================*/
/* Table: TPGRRSTUSU                                            */
/*==============================================================*/
EXECUTE IMMEDIATE '
create table TPGRRSTUSU  (
   IDEPGRRSTUSU         NUMBER(13)                      not null,
   IDEUSU               NUMBER(13)                      not null,
   IDEUNI               NUMBER(13)                      not null,
   IDEPGRRST            NUMBER(13)                      not null,
   DATINI               DATE                            not null,
   DATFIM               DATE                            not null,
   UPDTME               DATE                            not null
)';

EXECUTE IMMEDIATE 'alter table TPGRRSTUSU
   add constraint PK_TPGRRSTUSU primary key (IDEPGRRSTUSU)';

/*==============================================================*/
/* Table: TPGRRSTUSUACO                                         */
/*==============================================================*/
EXECUTE IMMEDIATE 'create table TPGRRSTUSUACO  (
   IDEPGRRSTUSUACO      NUMBER(13)                      not null,
   IDEPGRRSTUSU         NUMBER(13)                      not null,
   IDEACO               NUMBER(13)                      not null,
   PSO                  FLOAT                           not null,
   UPDTME               DATE                            not null
)';

EXECUTE IMMEDIATE 'alter table TPGRRSTUSUACO
   add constraint PK_TPGRRSTUSUACO primary key (IDEPGRRSTUSUACO)';

EXECUTE IMMEDIATE 'alter table TPGRRSTUSU
   add constraint TUNI2TPGRRSTUSU_FK foreign key (IDEUNI)
      references TUNI (IDEUNI)
      on delete cascade';

EXECUTE IMMEDIATE 'alter table TPGRRSTUSU
   add constraint TUSU2TPGRRSTUSU_FK foreign key (IDEUSU)
      references TUSU (IDEUSU)
      on delete cascade';

EXECUTE IMMEDIATE 'alter table TPGRRSTUSUACO
   add constraint TACO2TPGRRSTUSUACO_FK foreign key (IDEACO)
      references TACO (IDEACO)
      on delete cascade';

EXECUTE IMMEDIATE 'alter table TPGRRSTUSUACO
   add constraint TPGRRSTUSUACO_FK foreign key (IDEPGRRSTUSU)
      references TPGRRSTUSU (IDEPGRRSTUSU)
      on delete cascade';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('34747', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 33673');
END;
/
/*Adicionar �ndice �nico na tEprLicAmbEnd*/
/*********************************************************/
/********************** CASO 33673 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
    index_exists NUMBER := 0;

BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '33673';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		
	/*==============================================================*/

		  FOR EPREND IN (SELECT IDEEPRLICAMB, IDEEND, TIPEPRLICAMBEND, MIN(IDEEPRLICAMBEND) IDEEPRLICAMBEND FROM TEPRLICAMBEND GROUP BY IDEEPRLICAMB, IDEEND, TIPEPRLICAMBEND HAVING COUNT(IDEEPRLICAMBEND) > 1)
		  LOOP
		  
			DELETE TEPRLICAMBEND WHERE IDEEPRLICAMB = EPREND.IDEEPRLICAMB AND IDEEND = EPREND.IDEEND AND TIPEPRLICAMBEND = EPREND.TIPEPRLICAMBEND AND IDEEPRLICAMBEND <> EPREND.IDEEPRLICAMBEND;
			  
		  END LOOP;
		  COMMIT;

		/*==============================================================*/
		/* Index: TEPRLICAMBEND_X1                                      */
		/*==============================================================*/
		SELECT COUNT(1) INTO index_exists FROM user_indexes WHERE index_name = 'TEPRLICAMBEND_X1';	
		
		IF index_exists = 0 THEN
		  EXECUTE IMMEDIATE '
		  CREATE UNIQUE INDEX TEPRLICAMBEND_X1 ON TEPRLICAMBEND (
			 IDEEPRLICAMB ASC,
			 IDEEND ASC,
			 TIPEPRLICAMBEND ASC
		  )';
		END IF;


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('33673', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 33537');
END;
/
/*Adicionar coluna IDEMAP na TUNIPLAGES, para Mapa favorito*/
/*********************************************************/
/********************** CASO 33537 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '33537';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		
/*==============================================================*/


        EXECUTE IMMEDIATE 'ALTER TABLE TUNIPLAGES ADD IDEMAP NUMBER(13)' ;

		EXECUTE IMMEDIATE 'ALTER TABLE TUNIPLAGES
							ADD CONSTRAINT TMAP2TUNIPLAGES_FK FOREIGN KEY (IDEMAP) REFERENCES TMAP (IDEMAP)';

/*==============================================================*/


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('33537', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 34772');
END;
/
/*Alterar��o do tamanho das colunas NME e NMEEXB na TWKFATV*/
/*********************************************************/
/********************** CASO 34772 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '34772';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TWKFATV MODIFY NME NVARCHAR2(160)';
EXECUTE IMMEDIATE 'ALTER TABLE TWKFATV MODIFY NMEEXB NVARCHAR2(160)';
EXECUTE IMMEDIATE 'ALTER TABLE TWKFACA MODIFY ACEVERESTVAL NVARCHAR2(1000)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('34772', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 35005');
END;
/
/*Adicionar coluna FLENME na TMODIMPEXC, para Nome do arquivo*/
/*********************************************************/
/********************** CASO 35005 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '35005';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TMODIMPEXC ADD FLENME NVARCHAR2(100) NULL';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('35005', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 35277');
END;
/
/*Adicionar coluna RSC na TCLS*/
/*********************************************************/
/********************** CASO 35277 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '35277';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE ('ALTER TABLE TCLS ADD RSC NVARCHAR2(100)');

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('35277', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 35483');
END;
/
/*Adicionar coluna LINFIN na TMODIMPEXC, para Linha Final*/
/*********************************************************/
/********************** CASO 35483 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '35483';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TMODIMPEXC ADD LINFIN INT NULL';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('35483', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 34842');
END;
/
/*Adicionar coluna IDEFLESYS na TMAPOBJ, para relacionamento do agregador de documentos*/
/*********************************************************/
/********************** CASO 34842 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '34842';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'alter table TMAPOBJ add IDEFLESYS NUMBER(13) NULL';

/*==============================================================*/
/* Index: TFLESYS2TMAPOBJ_FK                                    */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TFLESYS2TMAPOBJ_FK on TMAPOBJ (
   IDEFLESYS ASC
)';

EXECUTE IMMEDIATE 'alter table TMAPOBJ
   add constraint FK_TMAPOBJ_TFLESYS2T_TFLESYS foreign key (IDEFLESYS)
      references TFLESYS (IDEFLESYS)
      on delete cascade';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('34842', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 35599');
END;
/
/*Alterar tamanho da coluna COD na TACO, de 25 para 50*/
/*********************************************************/
/********************** CASO 35599 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '35599';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TACO MODIFY COD VARCHAR2(50)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('35599', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 35340');
END;
/
/*Adicionar coluna IDEWKFFAS na tabela TPGRRSTUSU e a coluna FRMCFG na tabela TPGRRST.*/
/*********************************************************/
/********************** CASO 35340 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '35340';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TPGRRST ADD (FRMCFG int default(1) not null, IDEGRUUSU NUMBER(13) null)'; 

EXECUTE IMMEDIATE 'alter table TPGRRST
   add constraint FK_TPGRRST_TPRGRST2T_TGRUUSU foreign key (IDEGRUUSU)
      references TGRUUSU (IDEGRUUSU)
      on delete cascade';
  
EXECUTE IMMEDIATE 'ALTER TABLE TPGRRSTUSU ADD IDEWKFFAS NUMBER(13) NULL';
	    
/*==============================================================*/
/* Index: TPGRRSTUSU2TWKFFAS_FK                                 */
/*==============================================================*/
EXECUTE IMMEDIATE 'create index TPGRRSTUSU2TWKFFAS_FK on TPGRRSTUSU (
   IDEWKFFAS ASC
)';

EXECUTE IMMEDIATE 'alter table TPGRRSTUSU
   add constraint FK_TPGRRSTU_TPGRRSTUS_TWKFFAS foreign key (IDEWKFFAS)
      references TWKFFAS (IDEWKFFAS)
      on delete cascade';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('35340', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 35835');
END;
/
/*Tabela para a nova ferramenta de gr�ficos do indicador*/
/*********************************************************/
/********************** CASO 35835 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '35835';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQGRFIND INCREMENT BY 1 START WITH 1110000000000';

EXECUTE IMMEDIATE '
create table TGRFIND  (
   IDEGRFIND            NUMBER(13)                      not null,
   IDEMDLGRA            NUMBER(13)                      not null,
   IDEACO               NUMBER(13)                      not null,
   FRE                  NUMBER(1)                       not null,
   DATCRT               DATE,
   ORDDSD               INT,
   TIPDSD               INT,
   UPDTME               DATE                            not null
)';

EXECUTE IMMEDIATE '
alter table TGRFIND
   add constraint PK_TGRFIND primary key (IDEGRFIND)';

EXECUTE IMMEDIATE '
alter table TGRFIND
   add constraint TACO2TGRFIND_FK foreign key (IDEACO)
      references TACO (IDEACO)';

EXECUTE IMMEDIATE '
alter table TGRFIND
   add constraint TMDLGRA2TGRFIND_FK foreign key (IDEMDLGRA)
      references TMDLGRA (IDEMDLGRA)';

EXECUTE IMMEDIATE '
alter table TFER
	add IDEGRFIND NUMBER(13)';

EXECUTE IMMEDIATE '
alter table TFER
   add constraint TGRFIND2TFER_FK foreign key (IDEGRFIND)
      references TGRFIND (IDEGRFIND)
      on delete cascade';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('35835', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 36002');
END;
/
/*Script para atualizar os registros j� existentes do Workflow de Solu��es de Problemas, para funcionar com recursos*/
/*********************************************************/
/********************** CASO 36002 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '36002';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		-- Alterar Nome das Fases

UPDATE TWKFFAS
SET NME = 'EmIdentificacao', NMEEXB = 'Em Identifica��o'
WHERE IDEWKF = (select IDEWKF FROM TWKF WHERE TWKF.TYPTIP ='PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema' AND ROWNUM = 1)
AND NME = 'Em Identifica��o';

UPDATE TWKFFAS
SET NME = 'EmAnalise', NMEEXB = 'Em An�lise'
WHERE IDEWKF = (select IDEWKF FROM TWKF WHERE TWKF.TYPTIP ='PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema' AND ROWNUM = 1)
AND NME = 'Em An�lise';

UPDATE TWKFFAS
SET NME = 'EmAprovacao', NMEEXB = 'Em Aprova��o'
WHERE IDEWKF = (select IDEWKF FROM TWKF WHERE TWKF.TYPTIP ='PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema' AND ROWNUM = 1)
AND NME = 'Em Aprova��o';

UPDATE TWKFFAS
SET NME = 'EmExecucao', NMEEXB = 'Em Execu��o'
WHERE IDEWKF = (select IDEWKF FROM TWKF WHERE TWKF.TYPTIP ='PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema' AND ROWNUM = 1)
AND NME = 'Em Execu��o';

UPDATE TWKFFAS
SET NME = 'EmVerificacao', NMEEXB = 'Em Verifica��o'
WHERE IDEWKF = (select IDEWKF FROM TWKF WHERE TWKF.TYPTIP ='PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema' AND ROWNUM = 1)
AND NME = 'Em Verifica��o';

UPDATE TWKFFAS
SET NME = 'EmCheckDeEficacia', NMEEXB = 'Em Check de Efic�cia'
WHERE IDEWKF = (select IDEWKF FROM TWKF WHERE TWKF.TYPTIP ='PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema' AND ROWNUM = 1)
AND NME = 'Em Check de Efic�cia';

UPDATE TWKFFAS
SET NME = 'Concluida', NMEEXB = 'Conclu�da'
WHERE IDEWKF = (select IDEWKF FROM TWKF WHERE TWKF.TYPTIP ='PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema' AND ROWNUM = 1)
AND NME = 'Conclu�da';

UPDATE TWKFFAS
SET NME = 'Cancelada', NMEEXB = 'Cancelada'
WHERE IDEWKF = (select IDEWKF FROM TWKF WHERE TWKF.TYPTIP ='PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema' AND ROWNUM = 1)
AND NME = 'Cancelada';

UPDATE TWKFFAS
SET NME = 'Bloqueada', NMEEXB = 'Bloqueada'
WHERE IDEWKF = (select IDEWKF FROM TWKF WHERE TWKF.TYPTIP ='PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema' AND ROWNUM = 1)
AND NME = 'Bloqueada';

--Alterar Nome das a��es e das mensagem de confima��es

UPDATE TWKFACA
SET TWKFACA.MSGCNF = 'DesejaCancelarAhSolucaoDeProblema', TWKFACA.NMEEXB = 'Cancelar'
WHERE TWKFACA.IDEWKFACA IN (SELECT TWKFACA.IDEWKFACA
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFACA.MSGCNF = 'Deseja cancelar a Solu��o de Problema?');

UPDATE TWKFACA
SET TWKFACA.MSGCNF = 'DesejaConcluirAhSolucaoDeProblema', TWKFACA.NMEEXB = 'Concluir'
WHERE TWKFACA.IDEWKFACA IN (SELECT TWKFACA.IDEWKFACA
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFACA.MSGCNF = 'Deseja concluir a Solu��o de Problema?');

UPDATE TWKFACA
SET TWKFACA.MSGCNF = 'DesejaEnviarParaAnalise', TWKFACA.NMEEXB = 'Analise'
WHERE TWKFACA.IDEWKFACA IN (SELECT TWKFACA.IDEWKFACA
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFACA.MSGCNF = 'Deseja enviar para An�lise?');

UPDATE TWKFACA
SET TWKFACA.MSGCNF = 'DesejaEnviarParaExecucao', TWKFACA.NMEEXB = 'Execucao'
WHERE TWKFACA.IDEWKFACA IN (SELECT TWKFACA.IDEWKFACA
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFACA.MSGCNF = 'Deseja enviar para Execu��o?');

UPDATE TWKFACA
SET TWKFACA.MSGCNF = 'DesejaEnviarParaRevisao', TWKFACA.NMEEXB = 'Revisao'
WHERE TWKFACA.IDEWKFACA IN (SELECT TWKFACA.IDEWKFACA
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFACA.MSGCNF = 'Deseja enviar para Revis�o?');

UPDATE TWKFACA
SET TWKFACA.MSGCNF = 'DesejaEnviarParaVerificacao', TWKFACA.NMEEXB = 'Verificacao'
WHERE TWKFACA.IDEWKFACA IN (SELECT TWKFACA.IDEWKFACA
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFACA.MSGCNF = 'Deseja enviar para Verifica��o?');

UPDATE TWKFACA
SET TWKFACA.MSGCNF = 'DesejaFinalizarAhAnalise', TWKFACA.NMEEXB = 'FinalizarAnalise'
WHERE TWKFACA.IDEWKFACA IN (SELECT TWKFACA.IDEWKFACA
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFACA.MSGCNF = 'Deseja finalizar a An�lise?');

UPDATE TWKFACA
SET TWKFACA.MSGCNF = 'DesejaFinalizarAhVerificacao', TWKFACA.NMEEXB = 'FinalizarVerificacao'
WHERE TWKFACA.IDEWKFACA IN (SELECT TWKFACA.IDEWKFACA
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFACA.MSGCNF = 'Deseja finalizar a Verifica��o?');


UPDATE TWKFACA
SET TWKFACA.MSGCNF = 'DesejaReativarAhSolucaoDeProblema', TWKFACA.NMEEXB = 'Reativar'
WHERE TWKFACA.IDEWKFACA IN (SELECT TWKFACA.IDEWKFACA
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFACA.MSGCNF = 'Deseja reativar a Solu��o de Problema?');

UPDATE TWKFACA
SET TWKFACA.MSGCNF = 'DesejaRetornarParaAnalise', TWKFACA.NMEEXB = 'Analise'
WHERE TWKFACA.IDEWKFACA IN (SELECT TWKFACA.IDEWKFACA
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFACA.MSGCNF = 'Deseja retornar para An�lise?');

UPDATE TWKFACA
SET TWKFACA.MSGCNF = 'DesejaRretornarParaVerificacao', TWKFACA.NMEEXB = 'Verificacao'
WHERE TWKFACA.IDEWKFACA IN (SELECT TWKFACA.IDEWKFACA
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFACA.MSGCNF = 'Deseja retornar para Verifica��o?');

--Alterar Nome de Exibi��o das Atividades

UPDATE TWKFATV
SET TWKFATV.NMEEXB = 'Analise'
WHERE TWKFATV.IDEWKFATV IN (SELECT TWKFATV.IDEWKFATV
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFATV.NMEEXB = 'An�lise');

UPDATE TWKFATV
SET TWKFATV.NMEEXB = 'Aprovacao'
WHERE TWKFATV.IDEWKFATV IN (SELECT TWKFATV.IDEWKFATV
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFATV.NMEEXB = 'Aprova��o');

UPDATE TWKFATV
SET TWKFATV.NMEEXB = 'CheckDeEficacia'
WHERE TWKFATV.IDEWKFATV IN (SELECT TWKFATV.IDEWKFATV
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFATV.NMEEXB = 'Check de Efic�cia');

UPDATE TWKFATV
SET TWKFATV.NMEEXB = 'Execucao'
WHERE TWKFATV.IDEWKFATV IN (SELECT TWKFATV.IDEWKFATV
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFATV.NMEEXB = 'Execu��o');

UPDATE TWKFATV
SET TWKFATV.NMEEXB = 'Identificacao'
WHERE TWKFATV.IDEWKFATV IN (SELECT TWKFATV.IDEWKFATV
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFATV.NMEEXB = 'Identifica��o');

UPDATE TWKFATV
SET TWKFATV.NMEEXB = 'Verificacao'
WHERE TWKFATV.IDEWKFATV IN (SELECT TWKFATV.IDEWKFATV
							FROM TWKF 
							INNER JOIN TWKFFAS ON TWKF.IDEWKF = TWKFFAS.IDEWKF
							INNER JOIN TWKFATV ON TWKFATV.IDEWKFFAS = TWKFFAS.IDEWKFFAS
							INNER JOIN TWKFACA ON TWKFACA.IDEWKFATV = TWKFATV.IDEWKFATV
							WHERE TWKF.TYPTIP = 'PortalSIM.Domain.ModuloDeMelhorias.SolucaoDeProblema'
							AND TWKFATV.NMEEXB = 'Verifica��o');


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('36002', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 36291');
END;
/
/*Alterar nome da coluna LINIGN para LININI e tipo de int para nvarchar(60) na tabela TMODIMPEXC.*/
/*********************************************************/
/********************** CASO 36291 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '36291';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TMODIMPEXC DROP COLUMN LINIGN ';
EXECUTE IMMEDIATE 'ALTER TABLE TMODIMPEXC ADD LININI VARCHAR2(60)';

EXECUTE IMMEDIATE 'ALTER TABLE TMODIMPEXC DROP COLUMN LINFIN';
EXECUTE IMMEDIATE 'ALTER TABLE TMODIMPEXC ADD LINFIN VARCHAR2(60)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('36291', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 36271');
END;
/
/*Adicionar coluna DATCRI na tabela TANT.*/
/*********************************************************/
/********************** CASO 36271 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '36271';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE '
alter table TANT
   add DATCRI DATE NULL';
   
EXECUTE IMMEDIATE 'UPDATE TANT SET DATCRI = DAT - 3/24 WHERE DATCRI IS NULL';



/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('36271', SYSDATE);

		COMMIT;

	END IF;
END;
/
								 
								
BEGIN
	dbms_output.put_line('CASO 36229');
END;
/
/*Criar tabela TDESGRFIND*/
/*********************************************************/
/********************** CASO 36229 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '36229';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQDESGRFIND
INCREMENT BY 1
START WITH 1110000000000';

/*==============================================================*/
/* TABLE: TDESGRFIND                                            */
/*==============================================================*/
EXECUTE IMMEDIATE 'CREATE TABLE TDESGRFIND  (
   IDEDESGRFIND         NUMBER(13)                      NOT NULL,
   IDEGRFIND            NUMBER(13)                      NOT NULL,
   IDEUSU               NUMBER(13)                      NOT NULL,
   UPDTME               DATE                            NOT NULL
)';

EXECUTE IMMEDIATE 'ALTER TABLE TDESGRFIND
   ADD CONSTRAINT PK_TDESGRFIND PRIMARY KEY (IDEDESGRFIND)';

/*==============================================================*/
/* INDEX: TUSU2TDESGRFIND_FK                                    */
/*==============================================================*/
EXECUTE IMMEDIATE 'CREATE INDEX TUSU2TDESGRFIND_FK ON TDESGRFIND (
   IDEUSU ASC
)';

/*==============================================================*/
/* INDEX: TGRFIND2TDESGRFIND_FK                                 */
/*==============================================================*/
EXECUTE IMMEDIATE 'CREATE INDEX TGRFIND2TDESGRFIND_FK ON TDESGRFIND (
   IDEGRFIND ASC
)';

EXECUTE IMMEDIATE 'ALTER TABLE TDESGRFIND
   ADD CONSTRAINT TGRFIND2TDESGRFIND_FK FOREIGN KEY (IDEGRFIND)
      REFERENCES TGRFIND (IDEGRFIND)
      ON DELETE CASCADE';

EXECUTE IMMEDIATE 'ALTER TABLE TDESGRFIND
   ADD CONSTRAINT TUSU2TDESGRFIND_FK FOREIGN KEY (IDEUSU)
      REFERENCES TUSU (IDEUSU)';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('36229', SYSDATE);

		COMMIT;

	END IF;
END;
/

			 
								
BEGIN
	dbms_output.put_line('CASO 36874');
END;
/
/*Adicionar coluna IDEEMP no index TGRUIND_X1*/
/*********************************************************/
/********************** CASO 36874 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
    index_exists NUMBER := 0;
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '36874';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
    SELECT COUNT(*) INTO index_exists FROM dual 
    WHERE EXISTS (SELECT * FROM user_indexes WHERE index_name = 'TGRUIND_X1');  
    
    IF index_exists > 0 THEN
       EXECUTE IMMEDIATE 'DROP INDEX TGRUIND_X1';
    END IF;
      EXECUTE IMMEDIATE '
      CREATE UNIQUE INDEX TGRUIND_X1 ON TGRUIND (
          NME ASC,
          ORD ASC,
          IDEEMP ASC)';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('36874', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 36815');
END;
/
/*Criar tabela de Preferencias do usu�rio TPRFUSU*/
/*********************************************************/
/********************** CASO 36815 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '36815';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQPRFUSU
INCREMENT BY 1
START WITH 1110000000000';


/*==============================================================*/
/* TABLE: TPRFUSU                                               */
/*==============================================================*/
EXECUTE IMMEDIATE 'CREATE TABLE TPRFUSU  (
   IDEPRFUSU            NUMBER(13)                      NOT NULL,
   IDEUSU               NUMBER(13)                      NOT NULL,
   IDEPAG               NUMBER(13),
   UPDTME               DATE                            NOT NULL,
   ABAPAIUNI            NUMBER(1)                       NOT NULL
)';

EXECUTE IMMEDIATE 'ALTER TABLE TPRFUSU
   ADD CONSTRAINT PK_TPRFUSU PRIMARY KEY (IDEPRFUSU)';

/*==============================================================*/
/* INDEX: TUSU2TPRFUSU_FK                                       */
/*==============================================================*/
EXECUTE IMMEDIATE 'CREATE INDEX TUSU2TPRFUSU_FK ON TPRFUSU (
   IDEUSU ASC
)';

/*==============================================================*/
/* INDEX: TPAG2TPRFUSU_FK                                       */
/*==============================================================*/
EXECUTE IMMEDIATE 'CREATE INDEX TPAG2TPRFUSU_FK ON TPRFUSU (
   IDEPAG ASC
)';

EXECUTE IMMEDIATE 'ALTER TABLE TPRFUSU
   ADD CONSTRAINT TPAG2TPRFUSU_FK FOREIGN KEY (IDEPAG)
      REFERENCES TPAG (IDEPAG)';

EXECUTE IMMEDIATE 'ALTER TABLE TPRFUSU
   ADD CONSTRAINT TUSU2TPRFUSU_FK FOREIGN KEY (IDEUSU)
      REFERENCES TUSU (IDEUSU)
      ON DELETE CASCADE';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('36815', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 36777');
END;
/
/*Criar tabela TTEV*/
/*********************************************************/
/********************** CASO 36777 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '36777';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQTEV
INCREMENT BY 1
START WITH 1110000000000';

/*==============================================================*/
/* TABLE: TTEV                                            */
/*==============================================================*/

EXECUTE IMMEDIATE 'CREATE TABLE TTEV (
   IDETEV        		DECIMAL(13)    		NOT NULL,
   IDEUNI               NUMBER(13)          NOT NULL,
   IDEUSU               NUMBER(13)          NOT NULL,
   IDEAPRPNL			NUMBER(13)			NULL,
   NME					NVARCHAR2(100)		NOT NULL,
   COD					NVARCHAR2(30)		NOT NULL,
   UPDTME               DATE                NOT NULL
)';

EXECUTE IMMEDIATE 'ALTER TABLE TTEV
   ADD CONSTRAINT PK_TTEV PRIMARY KEY (IDETEV)';


/*==============================================================*/
/* INDEX: TUNI2TTEV_FK                                */
/*==============================================================*/

EXECUTE IMMEDIATE 'CREATE INDEX TUNI2TTEV_FK ON TTEV (
IDEUNI ASC
)';


/*==============================================================*/
/* INDEX: TUSU2TTEV_FK                                 */
/*==============================================================*/

EXECUTE IMMEDIATE 'CREATE INDEX TUSU2TTEV_FK ON TTEV (
IDEUSU ASC
)' ;


EXECUTE IMMEDIATE 'ALTER TABLE TTEV
   ADD CONSTRAINT TUNI2TTEV_FK FOREIGN KEY (IDEUNI)
      REFERENCES TUNI (IDEUNI)
         ON DELETE CASCADE';


EXECUTE IMMEDIATE 'ALTER TABLE TTEV
   ADD CONSTRAINT TUSU2TTEV_FK FOREIGN KEY (IDEUSU)
      REFERENCES TUSU (IDEUSU)
         ON DELETE CASCADE';

EXECUTE IMMEDIATE 'ALTER TABLE TTEV
   ADD CONSTRAINT TAPRPNL2TTEV_FK FOREIGN KEY (IDEAPRPNL)
      REFERENCES TAPRPNL (IDEAPRPNL)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('36777', SYSDATE);

		COMMIT;

	END IF;
END;
/

								 
								
BEGIN
	dbms_output.put_line('CASO 37227');
END;
/
/*Adicionando IDEPAG na TUNI e remover TPAG_X1*/
/*********************************************************/
/********************** CASO 37227 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
    index_exists NUMBER := 0;
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '37227';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
    SELECT COUNT(*) INTO index_exists FROM dual 
    WHERE EXISTS (SELECT * FROM user_indexes WHERE index_name = 'TPAG_X1');  
    
    IF index_exists > 0 THEN
       EXECUTE IMMEDIATE 'DROP INDEX TPAG_X1';
    END IF;
     
     
	EXECUTE IMMEDIATE 'alter table TUNI add IDEPAG NUMBER(13) NULL';

	EXECUTE IMMEDIATE 'alter table TUNI
	add constraint TPAG2TUNI_FK foreign key (IDEPAG)
      references TPAG (IDEPAG)';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('37227', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 37240');
END;
/
/*Rempver IDEEMP da TTMPPNL*/
/*********************************************************/
/********************** CASO 37240 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '37240';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
    SELECT COUNT(1) INTO lExists FROM user_indexes WHERE index_name = 'TEMP2TTMPPNL_FK';  
    
    IF lExists > 0 THEN
       EXECUTE IMMEDIATE 'DROP INDEX TEMP2TTMPPNL_FK';
    END IF;
	
	SELECT COUNT(1) INTO lExists FROM USER_CONSTRAINTS WHERE CONSTRAINT_NAME = 'TEMP2TTMPPNL_FK';  
    
    IF lExists > 0 THEN
       EXECUTE IMMEDIATE 'ALTER TABLE TTMPPNL DROP CONSTRAINT TEMP2TTMPPNL_FK';
    END IF;
    
	SELECT COUNT(1) INTO lExists FROM USER_TAB_COLUMNS WHERE TABLE_NAME = 'TTMPPNL' AND COLUMN_NAME = 'IDEEMP';
	IF lExists > 0 THEN
		EXECUTE IMMEDIATE 'ALTER TABLE TTMPPNL DROP COLUMN IDEEMP';
	END IF;


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('37240', SYSDATE);

		COMMIT;

	END IF;
END;
/

								
BEGIN
	dbms_output.put_line('CASO 37298');
END;
/
/*Criar tabela de Destinat�rios de Relat�rio TPAGUSU*/
/*********************************************************/
/********************** CASO 37298 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '37298';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		
/*==============================================================*/
/* Table: TPAGUSU                                               */
/*==============================================================*/
EXECUTE IMMEDIATE(
'create table TPAGUSU  (
   IDEPAG               NUMBER(13),
   IDEUSU               NUMBER(13)
)');

/*==============================================================*/
/* Index: TPAG2TPAGUSU_FK                                       */
/*==============================================================*/
EXECUTE IMMEDIATE(
'create index TPAG2TPAGUSU_FK on TPAGUSU (
   IDEPAG ASC
)');

/*==============================================================*/
/* Index: TUSU2TPAGUSU_FK                                       */
/*==============================================================*/
EXECUTE IMMEDIATE(
'create index TUSU2TPAGUSU_FK on TPAGUSU (
   IDEUSU ASC
)');

/*==============================================================*/
/* Index: TPAGUSU_X1                                            */
/*==============================================================*/
EXECUTE IMMEDIATE(
'create unique index TPAGUSU_X1 on TPAGUSU (
   IDEPAG ASC,
   IDEUSU ASC
)');

EXECUTE IMMEDIATE(
'alter table TPAGUSU
   add constraint TPAG2TPAGUSU_FK foreign key (IDEPAG)
      references TPAG (IDEPAG)
      on delete cascade');

EXECUTE IMMEDIATE(
'alter table TPAGUSU
   add constraint TUSU2TPAGUSU_FK foreign key (IDEUSU)
      references TUSU (IDEUSU)
      on delete cascade');


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('37298', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 37300');
END;
/
/*Adicionar colunas PERENV, DATENV e DATULTENV na TPAG*/
/*********************************************************/
/********************** CASO 37300 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '37300';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		   
EXECUTE IMMEDIATE '
  ALTER TABLE TPAG
    ADD PERENV NUMBER(2) DEFAULT 0 NOT NULL';
	
EXECUTE IMMEDIATE '
  ALTER TABLE TPAG
    ADD DATENV DATE';

EXECUTE IMMEDIATE '
  ALTER TABLE TPAG
    ADD DATULTENV DATE';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('37300', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 37292');
END;
/
/*Criar tabela de Iframes SIMPart TSIMPARIFR*/
/*********************************************************/
/********************** CASO 37292 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '37292';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		/*==============================================================*/
/* TABLE: TSIMPARIFR                                            */
/*==============================================================*/
EXECUTE IMMEDIATE 'CREATE TABLE TSIMPARIFR  (
   IDESIMPARIFR         NUMBER(13)                      NOT NULL,
   LIN                  NVARCHAR2(255)                  NOT NULL,
   HEI                  INT,
   UPDTME               DATE                            NOT NULL
)';

EXECUTE IMMEDIATE 'ALTER TABLE TSIMPARIFR
   ADD CONSTRAINT PK_TSIMPARIFR PRIMARY KEY (IDESIMPARIFR)';

EXECUTE IMMEDIATE 'ALTER TABLE TSIMPARIFR
   ADD CONSTRAINT TSIMPAR2TSIMPARIFR_FK FOREIGN KEY (IDESIMPARIFR)
      REFERENCES TSIMPAR (IDESIMPAR)
      ON DELETE CASCADE';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('37292', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 20150623-34075');
END;
/
/*Corre��es de scripts do Dashboards (script migrado da pasta de 2014)*/
/*********************************************************/
/********************** CASO 20150623-34075 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20150623-34075';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		    SELECT COUNT(*)
      INTO lExists
      FROM USER_TAB_COLUMNS 
     WHERE UPPER(TABLE_NAME) = 'TSIMNTC' 
       AND UPPER(COLUMN_NAME) = 'NME';
       
    IF lExists > 0 THEN
        EXECUTE IMMEDIATE 'ALTER TABLE TSIMNTC DROP COLUMN NME';
    END IF;
    
    SELECT COUNT(*)
      INTO lExists
      FROM USER_TAB_COLUMNS 
     WHERE UPPER(TABLE_NAME) = 'TSIMPARLISNTC' 
       AND UPPER(COLUMN_NAME) = 'TIT';
       
    IF lExists > 0 THEN
        EXECUTE IMMEDIATE 'ALTER TABLE TSIMPARLISNTC DROP COLUMN TIT';
    END IF;

    SELECT COUNT(*)
      INTO lExists
      FROM USER_TAB_COLUMNS 
     WHERE UPPER(TABLE_NAME) = 'TSIMPARLISNTC' 
       AND UPPER(COLUMN_NAME) = 'FRMVIS';
       
    IF lExists > 0 THEN
        EXECUTE IMMEDIATE 'ALTER TABLE TSIMPARLISNTC DROP COLUMN FRMVIS';
    END IF;

    SELECT COUNT(*)
      INTO lExists
      FROM USER_TAB_COLUMNS 
     WHERE UPPER(TABLE_NAME) = 'TCRDIND' 
       AND UPPER(COLUMN_NAME) = 'USADESPER';
       
    IF lExists > 0 THEN
        EXECUTE IMMEDIATE 'ALTER TABLE TCRDIND DROP COLUMN USADESPER';
    END IF;
    DECLARE lNullable NVARCHAR2(100);
    BEGIN
		SELECT COUNT(1)
		  INTO lExists
		  FROM USER_TAB_COLUMNS 
		 WHERE UPPER(TABLE_NAME) = 'TTMPPNL' 
		   AND UPPER(COLUMN_NAME) = 'NME';
	    
		IF lExists > 0 THEN
			SELECT NULLABLE
			  INTO lNullable
			  FROM USER_TAB_COLUMNS 
			 WHERE UPPER(TABLE_NAME) = 'TTMPPNL' 
			   AND UPPER(COLUMN_NAME) = 'NME';
		END IF;
		IF lNullable = 'N' THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TTMPPNL MODIFY NME NVARCHAR2(80) NULL';
		END IF;
    END;
	



/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20150623-34075', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 20150623-34075_1');
END;
/
/*Adicionar Identity na TLISDIS (script migrado da pasta de 2014)*/
/*********************************************************/
/********************** CASO 20150623-34075_1 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20150623-34075_1';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		
    SELECT NVL(MAX(IDELISDIS), 1110000000000) + 1 INTO lProximoIde FROM TLISDIS;
      EXECUTE IMMEDIATE '
      CREATE SEQUENCE SEQLISDIS
      START WITH ' || TO_CHAR(lProximoIde) || '
      INCREMENT BY 1';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20150623-34075_1', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 37623');
END;
/
/*Adicionar colunas para Matriz de Avalia��o*/
/*********************************************************/
/********************** CASO 37623 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '37623';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE '
	ALTER TABLE TMAT
		ADD TYP NVARCHAR2(200) NULL';

EXECUTE IMMEDIATE '
	ALTER TABLE TMATPER
		ADD GRP NVARCHAR2(200) NULL';

EXECUTE IMMEDIATE '
	ALTER TABLE TMATRES
		ADD IDEMAT NUMBER(13) NULL';

EXECUTE IMMEDIATE '
	ALTER TABLE TMATRES
		MODIFY IDEMATPER NUMBER(13) NULL';
		
EXECUTE IMMEDIATE '
	ALTER TABLE TMATRES
	   ADD CONSTRAINT TMAT2TMATRES_FK FOREIGN KEY (IDEMAT)
		  REFERENCES TMAT (IDEMAT)';
		  
EXECUTE IMMEDIATE ('UPDATE TMAT SET TYP = ''PortalSIM.Domain.ModuloDeMelhorias.Ferramentas.MatrizDePriorizacao'' WHERE TYP IS NULL');


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('37623', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 37639');
END;
/
/*Adicionar tabelas para os ciclos de Avalia��o*/
/*********************************************************/
/********************** CASO 37639 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '37639';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		BEGIN
/*==============================================================*/
/* Table: TCICAVLDES                                            */
/*==============================================================*/

EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQCICAVLDES
INCREMENT BY 1
START WITH 1110000000000';

EXECUTE IMMEDIATE '
create table TCICAVLDES  (
   IDECICAVLDES         NUMBER(13)                      not null,
   IDEPLAGES            NUMBER(13)                      not null,
   IDEPGRRST            NUMBER(13),
   IDEMAT               NUMBER(13)                      not null,
   DES                  NVARCHAR2(100)                   not null,
   DATINIAVL            DATE                            not null,
   DATFIMAVL            DATE                            not null,
   AVLCHE               NUMBER(1)                       not null,
   QTDMINMESEMP         INT,
   QTDMINMESFUN         INT,
   AVLNINBOX            NUMBER(1)                       not null,
   STT                  NUMBER(1)                       not null,
   UPDTME               DATE                            not null
)';

EXECUTE IMMEDIATE 'alter table TCICAVLDES
   add constraint PK_TCICAVLDES primary key (IDECICAVLDES)';

EXECUTE IMMEDIATE 'alter table TCICAVLDES
   add constraint TPGRRST2TCICAVLDES_FK foreign key (IDEPGRRST)
      references TPGRRST (IDEPGRRST)
      on delete cascade';

EXECUTE IMMEDIATE 'alter table TCICAVLDES
   add constraint TPLAGES2TCICAVLDES_FK foreign key (IDEPLAGES)
      references TPLAGES (IDEPLAGES)';
      
EXECUTE IMMEDIATE 'alter table TCICAVLDES
   add constraint TMAT2TCICAVLDES foreign key (IDEMAT)
      references TMAT (IDEMAT)';      

/*==============================================================*/
/* Table: TFXAAVL                                               */
/*==============================================================*/

EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQFXAAVL
INCREMENT BY 1
START WITH 1110000000000';

EXECUTE IMMEDIATE 'create table TFXAAVL  (
   IDEFXAAVL            NUMBER(13)                      not null,
   IDECICAVLDES         NUMBER(13)                      not null,
   DES                  NVARCHAR2(100)                   not null,
   LIMNOTAVLDES         INT                             not null,
   LIMNOTPGRRES         INT                             not null,
   FXAPRAPCOTMP         NUMBER(1)                       not null,
   COR                  VARCHAR2(25)                    not null,
   UPDTME               DATE                            not null
)';

EXECUTE IMMEDIATE 'alter table TFXAAVL
   add constraint PK_TFXAAVL primary key (IDEFXAAVL)';

EXECUTE IMMEDIATE 'alter table TFXAAVL
   add constraint TCICAVLDES2TFXAAVL_FK foreign key (IDECICAVLDES)
      references TCICAVLDES (IDECICAVLDES)
      on delete cascade';

END;

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('37639', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 37657');
END;
/
/*Adicionar tabelas Avalia��o de Desempenho (TAVLDES, TAVLDESITE)*/
/*********************************************************/
/********************** CASO 37657 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '37657';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		/*==============================================================*/
/* Table: TAVLDES                                               */
/*==============================================================*/

EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQAVLDES INCREMENT BY 1 START WITH 1110000000000';

EXECUTE IMMEDIATE '
	create table TAVLDES  (
	   IDEAVLDES            NUMBER(13)                      not null,
	   IDECICAVLDES         NUMBER(13),
	   IDEUSU               NUMBER(13),
	   IDEUSUAVL            NUMBER(13),
	   IDEPLAACO            NUMBER(13),
	   IDECMTSYS            NUMBER(13),
	   IDEWKFFAS            NUMBER(13),
	   TOTNOTAVL            NUMBER(13,2),
	   UPDTME               DATE                            not null
	)';

EXECUTE IMMEDIATE '
	alter table TAVLDES
	   add constraint PK_TAVLDES primary key (IDEAVLDES)';

/*==============================================================*/
/* Index: TCICAVLDES2TAVLDES_FK                                 */
/*==============================================================*/

EXECUTE IMMEDIATE '
	create index TCICAVLDES2TAVLDES_FK on TAVLDES (
	   IDECICAVLDES ASC
	)';

/*==============================================================*/
/* Index: TUSU2TAVLDES                                          */
/*==============================================================*/
EXECUTE IMMEDIATE '
	create index TUSU2TAVLDES on TAVLDES (
	   IDEUSU ASC
	)';

/*==============================================================*/
/* Index: TUSUAVL2TAVLDES_FK                                    */
/*==============================================================*/
EXECUTE IMMEDIATE '
	create index TUSUAVL2TAVLDES_FK on TAVLDES (
	   IDEUSUAVL ASC
	)';

/*==============================================================*/
/* Index: TPLAACO2TAVLDES_FK                                    */
/*==============================================================*/

EXECUTE IMMEDIATE '
	create index TPLAACO2TAVLDES_FK on TAVLDES (
	   IDEPLAACO ASC
	)';

/*==============================================================*/
/* Index: TCMTSYS2TAVLDES_FK                                    */
/*==============================================================*/

EXECUTE IMMEDIATE '
	create index TCMTSYS2TAVLDES_FK on TAVLDES (
	   IDECMTSYS ASC
	)';

/*==============================================================*/
/* Index: TWKFFAS2TAVLDES_FK                                    */
/*==============================================================*/
EXECUTE IMMEDIATE '
	create index TWKFFAS2TAVLDES_FK on TAVLDES (
	   IDEWKFFAS ASC
	)';

/*==============================================================*/
/* Index: TAVLDES_X1                                            */
/*==============================================================*/
EXECUTE IMMEDIATE '
	create unique index TAVLDES_X1 on TAVLDES (
	   IDECICAVLDES ASC,
	   IDEUSU ASC
	)';

EXECUTE IMMEDIATE '
	alter table TAVLDES
	   add constraint TCICAVLDES2TAVLDES_FK foreign key (IDECICAVLDES)
		  references TCICAVLDES (IDECICAVLDES)
		  ON DELETE CASCADE';

EXECUTE IMMEDIATE '
	alter table TAVLDES
	   add constraint TCMTSYS2TAVLDES_FK foreign key (IDECMTSYS)
		  references TCMTSYS (IDECMTSYS)';

EXECUTE IMMEDIATE '
	alter table TAVLDES
	   add constraint TPLAACO2TAVLDES_FK foreign key (IDEPLAACO)
		  references TPLAACO (IDEPLAACO)';

EXECUTE IMMEDIATE '
	alter table TAVLDES
	   add constraint TUSU2TAVLDES_FK foreign key (IDEUSU)
		  references TUSU (IDEUSU)';

EXECUTE IMMEDIATE '
	alter table TAVLDES
	   add constraint TUSUAVL2TAVLDES_FK foreign key (IDEUSUAVL)
		  references TUSU (IDEUSU)';

EXECUTE IMMEDIATE '
	alter table TAVLDES
	   add constraint TWKFFAS2TAVLDES_FK foreign key (IDEWKFFAS)
		  references TWKFFAS (IDEWKFFAS)';
	  
/*==============================================================*/
/* Table: TAVLDESITE                                            */
/*==============================================================*/

EXECUTE IMMEDIATE 'create sequence SEQAVLDESITE increment by 1 start with 1110000000000';

EXECUTE IMMEDIATE '
	create table TAVLDESITE  (
	   IDEAVLDESITE         NUMBER(13)                      not null,
	   IDEAVLDES            NUMBER(13),
	   IDEUSUAVL            NUMBER(13),
	   IDEMATPER            NUMBER(13),
	   IDEMATRES            NUMBER(13),
	   UPDTME               DATE                            not null
	)';

EXECUTE IMMEDIATE '
	alter table TAVLDESITE
	   add constraint PK_TAVLDESITE primary key (IDEAVLDESITE)';

/*==============================================================*/
/* Index: TAVLDES2TAVLDESITE_FK                                 */
/*==============================================================*/
EXECUTE IMMEDIATE '
	create index TAVLDES2TAVLDESITE_FK on TAVLDESITE (
	   IDEAVLDES ASC
	)';

/*==============================================================*/
/* Index: TUSU2TAVLDESITE_FK                                    */
/*==============================================================*/
EXECUTE IMMEDIATE '
	create index TUSU2TAVLDESITE_FK on TAVLDESITE (
	   IDEUSUAVL ASC
	)';

/*==============================================================*/
/* Index: TMATPER2TAVLDESITE_FK                                 */
/*==============================================================*/
EXECUTE IMMEDIATE '
	create index TMATPER2TAVLDESITE_FK on TAVLDESITE (
	   IDEMATPER ASC
	)';

/*==============================================================*/
/* Index: TMATRES2TAVLDESITE_FK                                 */
/*==============================================================*/
EXECUTE IMMEDIATE '
	create index TMATRES2TAVLDESITE_FK on TAVLDESITE (
	   IDEMATRES ASC
	)';

EXECUTE IMMEDIATE '
	alter table TAVLDESITE
	   add constraint TAVLDES2TAVLDESITE_FK foreign key (IDEAVLDES)
		  references TAVLDES (IDEAVLDES)
		  on delete cascade';

EXECUTE IMMEDIATE '
	alter table TAVLDESITE
	   add constraint TMATPER2TAVLDESITE_FK foreign key (IDEMATPER)
		  references TMATPER (IDEMATPER)';

EXECUTE IMMEDIATE '
	alter table TAVLDESITE
	   add constraint TMATRES2TAVLDESITE_FK foreign key (IDEMATRES)
		  references TMATRES (IDEMATRES)';

EXECUTE IMMEDIATE '
	alter table TAVLDESITE
	   add constraint TUSU2TAVLDESITE_FK foreign key (IDEUSUAVL)
		  references TUSU (IDEUSU)';



/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('37657', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 37703');
END;
/
/*Adicionar a coluna EXCCARCHF na TUSU*/
/*********************************************************/
/********************** CASO 37703 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '37703';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TUSU ADD EXCCARCHF NUMBER(1) DEFAULT 0 NOT NULL';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('37703', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 37728');
END;
/
/*Alterar tipo da coluna ORD das tabelas TMATPER e TMATRES*/
/*********************************************************/
/********************** CASO 37728 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '37728';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE '
	ALTER TABLE TMATPER
		MODIFY ORD INT';

EXECUTE IMMEDIATE '
	ALTER TABLE TMATRES
		MODIFY ORD INT';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('37728', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 37744');
END;
/
/*Adicionar coluna IDEEMP na TWKF*/
/*********************************************************/
/********************** CASO 37744 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '37744';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'ALTER TABLE TWKF ADD IDEEMP NUMBER(13) NULL';

EXECUTE IMMEDIATE 'CREATE INDEX TEMP2TWKF_FK ON TWKF (
					   IDEEMP ASC
					)';

EXECUTE IMMEDIATE 'ALTER TABLE TWKF
				   ADD CONSTRAINT TEMP2TWKF_FK FOREIGN KEY (IDEEMP)
					  REFERENCES TEMP (IDEEMP)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('37744', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 38286');
END;
/
/*Atualizar cascade TACO2TFRMCALITE_FK, TFRMCAL2TFRMCALITE_FK, TACO2TMDLGRA_FK, TMDLGRA2TMDLSECGRA_FK*/
/*********************************************************/
/********************** CASO 38286 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
    const_exists NUMBER := 0;
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '38286';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
  
	SELECT COUNT(1) INTO const_exists FROM SYS.user_constraints WHERE CONSTRAINT_NAME = 'TACO2TFRMCALITE_FK';
	IF const_exists = 1 THEN
		EXECUTE IMMEDIATE 'ALTER TABLE TFRMCALITE DROP CONSTRAINT TACO2TFRMCALITE_FK';
	END IF;

	SELECT COUNT(1) INTO const_exists FROM  SYS.user_constraints WHERE CONSTRAINT_NAME = 'TFRMCAL2TFRMCALITE_FK';
	IF const_exists = 1 THEN
		EXECUTE IMMEDIATE 'ALTER TABLE TFRMCALITE DROP CONSTRAINT TFRMCAL2TFRMCALITE_FK';
	END IF;

	SELECT COUNT(1) INTO const_exists FROM  SYS.user_constraints WHERE CONSTRAINT_NAME = 'TACO2TMDLGRA_FK';
	IF const_exists = 1 THEN
		EXECUTE IMMEDIATE 'ALTER TABLE TMDLGRA DROP CONSTRAINT TACO2TMDLGRA_FK';
	END IF;

	SELECT COUNT(1) INTO const_exists FROM  SYS.user_constraints WHERE CONSTRAINT_NAME = 'TMDLGRA2TMDLSECGRA_FK';
	IF const_exists = 1 THEN
		EXECUTE IMMEDIATE 'ALTER TABLE TMDLSECGRA DROP CONSTRAINT TMDLGRA2TMDLSECGRA_FK';
	END IF;

	EXECUTE IMMEDIATE 'alter table TFRMCALITE
	   add constraint TACO2TFRMCALITE_FK foreign key (IDEACO)
		  references TACO (IDEACO)
			 on delete cascade';

	EXECUTE IMMEDIATE 'alter table TFRMCALITE
	   add constraint TFRMCAL2TFRMCALITE_FK foreign key (IDEFRMCAL)
		  references TFRMCAL (IDEFRMCAL)
			 on delete cascade';

	EXECUTE IMMEDIATE 'alter table TMDLGRA
	   add constraint TACO2TMDLGRA_FK foreign key (IDEACO)
		  references TACO (IDEACO)
			 on delete cascade';

	EXECUTE IMMEDIATE 'alter table TMDLSECGRA
	   add constraint TMDLGRA2TMDLSECGRA_FK foreign key (IDEMDLGRA)
		  references TMDLGRA (IDEMDLGRA)
			 on delete cascade';



/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('38286', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 38265');
END;
/
/*Adicionar coluna para o Agregador de Coment�rios na Solu��o de Problemas*/
/*********************************************************/
/********************** CASO 38265 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '38265';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'alter table TSOLPRB add IDECMTSYS NUMBER(13)';
   
EXECUTE IMMEDIATE 'alter table TSOLPRB
   add constraint TCMTSYS2TSOLPRB_FK foreign key (IDECMTSYS)
      references TCMTSYS (IDECMTSYS)
      on delete cascade';
	  
EXECUTE IMMEDIATE 'create index TCMTSYS2TSOLPRB_FK on TSOLPRB ( IDECMTSYS ASC )';


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('38265', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 38262');
END;
/
/*Adicionar coluna para o Agregador de Coment�rios na Reuni�o*/
/*********************************************************/
/********************** CASO 38262 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '38262';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'alter table TAGD add IDECMTSYS NUMBER(13)';

EXECUTE IMMEDIATE 'alter table TAGD
   add constraint TAGD2TCMTSYS_FK foreign key (IDECMTSYS)
      references TCMTSYS (IDECMTSYS)
      on delete cascade';

EXECUTE IMMEDIATE 'create index TCMTSYS2TAGD_FK on TAGD (IDECMTSYS ASC)';

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('38262', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 20151124-38329');
END;
/
/*Adicionar �ndice TMSGSRV_X1 na TMSGSRV*/
/*********************************************************/
/********************** CASO 20151124-38329 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
    index_exists NUMBER := 0;
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '20151124-38329';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
	SELECT COUNT(*) INTO index_exists 
	  FROM dual 
	 WHERE EXISTS (SELECT * FROM user_indexes WHERE index_name = 'TMSGSRV_X1');  
  
	IF index_exists = 0 THEN
		EXECUTE IMMEDIATE 'CREATE INDEX TMSGSRV_X1 ON TMSGSRV (
							FLGENV ASC
						)';		
	END IF;


/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('20151124-38329', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
BEGIN
	dbms_output.put_line('CASO 38283');
END;
/
/*Adicionar coluna IDECMTREF na TCMT*/
/*********************************************************/
/********************** CASO 38283 ***********************/
/*********************************************************/

DECLARE lExists		INT;
		lProximoIde NUMBER(13);
BEGIN

	SELECT COUNT(1) INTO lExists
	  FROM TSQLUPD
	 WHERE COD = '38283';

	IF lExists = 0 THEN

  
/*==============================================================*/
    
		EXECUTE IMMEDIATE 'alter table TCMT add IDECMTREF NUMBER(13) NULL';

EXECUTE IMMEDIATE 'alter table TCMT
	add constraint FK_TCMT2TCMT foreign key (IDECMTREF)
		references TCMT (IDECMT)';
	

/*==============================================================*/
  	INSERT INTO TSQLUPD(COD, DATEXE) VALUES('38283', SYSDATE);

		COMMIT;

	END IF;
END;
/


								 
								
/*==============================================================*/
/* ATUALIZA��O DA VERS�O DO BANCO DE DADOS                      */
/*==============================================================*/
DECLARE LVERSION DATE := TO_DATE('01-12-2015', 'DD-MM-YYYY');
        DUMMY    DATE;
        FOUND    BOOLEAN;
		VERSAO 	 NVARCHAR2(10) := '1512.1';
 
    CURSOR CURSORVERSAO(CPVERSION DATE) IS
    SELECT VRS FROM TVRS WHERE VRS = LVERSION AND NUMVRS = VERSAO;
BEGIN
    OPEN  CURSORVERSAO(LVERSION);
    FETCH CURSORVERSAO INTO DUMMY;
    FOUND := CURSORVERSAO%FOUND;
    CLOSE CURSORVERSAO;
    IF FOUND THEN
        UPDATE TVRS SET DTATBL = SYSDATE WHERE VRS = LVERSION AND NUMVRS = VERSAO;
    ELSE
        INSERT INTO TVRS (VRS, DTATBL , NUMVRS) VALUES (LVERSION, SYSDATE , VERSAO);
    END IF;
END;
/

BEGIN
dbms_output.put_line('1512.1');
END;
/
